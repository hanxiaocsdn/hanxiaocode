package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.EsgGisLocTrajectory;
import com.sf.gis.java.sds.pojo.PathFix;
import com.sf.gis.java.sds.pojo.TrackAoi;
import com.sf.gis.java.sds.pojo.waybillaoi.FvpCoreFactRoute;
import com.sf.gis.java.sds.pojo.waybillaoi.IncSgsTaskFlowNew;
import com.sf.gis.java.sds.pojo.waybillaoi.ScheduleWidthData;
import com.sf.gis.scala.base.util.DistanceTool;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;


/**
 * 需求：小哥状态停留统计
 * 业务方：丁汀（01430258）
 * 研发：匡仁衡(01399581)
 * 任务id:780688 任务已冻结
 */
public class AppXiaoGeStayStatusStat {
    private static Logger logger = LoggerFactory.getLogger(AppXiaoGeStayStatusStat.class);
    private static String getAoiByXy = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy2?ak=24ea1d3d40fa4c319b8ce4f29348a938&x=%s&y=%s";
    private static String getTrackAois = "http://sds-core-datarun.sf-express.com/datarun/track/getTrackAois?showAoiCode=1";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppXiaoGeStayStatusStat");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String trajectory_sql = String.format("                select\n" +
                "                  a.un emp_code,\n" +
                "                  a.zx zx,\n" +
                "                  a.zy zy,\n" +
                "                  a.bn dept_code,\n" +
                "                  a.city city,\n" +
                "                  a.tm tm,\n" +
                "                  a.fixx fixx,\n" +
                "                  a.fixy fixy,\n" +
                "                  b.name emp_name,\n" +
                "                  c.longitude longitude,\n" +
                "                  c.latitude latitude,\n" +
                "                  d.working_time working_time,\n" +
                "                  a.inc_day inc_day\n" +
                "                from\n" +
                "                  (\n" +
                "                    select\n" +
                "                      un,\n" +
                "                      zx,\n" +
                "                      zy,\n" +
                "                      bn,\n" +
                "                      citycode city,\n" +
                "                      tm,\n" +
                "                      fixx,\n" +
                "                      fixy,\n" +
                "                      inc_day\n" +
                "                    from\n" +
                "                      dm_gis.aoi_accuracy_gj_detail_new\n" +
                "                    where\n" +
                "                      inc_day = '%s'\n" +
                "                      and citycode in ('431','432','433','434','435','436','437','438','439','482')\n" +
                "                      and cast(ac as int) < 100\n" +
                "                  ) a\n" +
                "                  left join (\n" +
                "                    select\n" +
                "                      loginid,\n" +
                "                      name\n" +
                "                    from\n" +
                "                      ods_rmds.tb_res_user\n" +
                "                    where\n" +
                "                      inc_day = '%s'\n" +
                "                      and position_property = '0010'\n" +
                "                      and substr(org_code, 1, 3) in ('431','432','433','434','435','436','437','438','439','482')\n" +
                "                      and loginid is not null and loginid <>''\n" +
                "                  ) b on a.un = b.loginid\n" +
                "                  left join (\n" +
                "                      select\n" +
                "                        dept_code,\n" +
                "                        longitude,\n" +
                "                        latitude\n" +
                "                      from\n" +
                "                        dim.dim_dept_info_df\n" +
                "                      where\n" +
                "                        inc_day = '%s'\n" +
                "                        and (longitude is not null and longitude <> '')\n" +
                "                        and (latitude is not null and latitude <> '')\n" +
                "                        and substr(dept_code, 1, 3) in ('431','432','433','434','435','436','437','438','439','482')\n" +
                "                  )c on a.bn = c.dept_code\n" +
                "                  left join (\n" +
                "                      select\n" +
                "                        couriercode,\n" +
                "                        (max(barscantm) - min(barscantm)) working_time\n" +
                "                      from\n" +
                "                        ods_kafka_fvp.fvp_core_fact_route_op\n" +
                "                      where\n" +
                "                        inc_day = '%s'\n" +
                "                        and couriercode is not null\n" +
                "                        and couriercode <> ''\n" +
                "                        and couriercode <> 'null'\n" +
                "                        and from_unixtime(cast(barscantm / 1000 as bigint), 'yyyyMMdd') = '%s'\n" +
                "                        group by couriercode\n" +
                "                  )d on a.un = d.couriercode", date, date, date, date, date);
        JavaRDD<EsgGisLocTrajectory> trajectoryRdd = DataUtil.loadData(spark, sc, trajectory_sql, EsgGisLocTrajectory.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trajectoryRdd cnt:{}", trajectoryRdd.count());

        JavaRDD<EsgGisLocTrajectory> stayAoiIdRdd = trajectoryRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey().flatMap(tp -> {
            List<EsgGisLocTrajectory> list = Lists.newArrayList(tp._2);
            String most_stay_aoiid = "";
            String most_stay_name = "";
            String stay_time = "";
            String stay_time_duration = "";
            String busy_hour = "";
            String easy_hour = "";
            List<EsgGisLocTrajectory> sortList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getFixx()) && StringUtils.isNotEmpty(o.getFixy()) && StringUtils.isNotEmpty(o.getTm()))
                    .sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).collect(Collectors.toList());

            if (sortList.size() > 0) {
                ArrayList<EsgGisLocTrajectory> hour_list = new ArrayList<>();
                for (int i = 0; i < sortList.size(); i++) {
                    if (i != (sortList.size() - 1)) {
                        EsgGisLocTrajectory o = new EsgGisLocTrajectory();
                        EsgGisLocTrajectory temp = sortList.get(i);
                        String tm = temp.getTm();
                        String x = temp.getFixx();
                        String y = temp.getFixy();
                        String hour = DateUtil.tmToDate(tm + "000", "HH");
                        o.setHour(hour);

                        EsgGisLocTrajectory temp2 = sortList.get(i + 1);
                        String x1 = temp2.getFixx();
                        String y1 = temp2.getFixy();
                        if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y) && StringUtils.isNotEmpty(x1) && StringUtils.isNotEmpty(y1)) {
                            double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(x1), Double.parseDouble(y1));
                            o.setDistance(distance);
                        }
                        hour_list.add(o);
                    }
                }

                ArrayList<EsgGisLocTrajectory> hour_last_list = new ArrayList<>();
                Map<String, List<EsgGisLocTrajectory>> hour_map = hour_list.stream().collect(Collectors.groupingBy(EsgGisLocTrajectory::getHour));
                for (Map.Entry<String, List<EsgGisLocTrajectory>> stringListEntry : hour_map.entrySet()) {
                    EsgGisLocTrajectory hour_last = new EsgGisLocTrajectory();
                    String hour = stringListEntry.getKey();
                    double distanceAll = stringListEntry.getValue().stream().map(EsgGisLocTrajectory::getDistance).reduce(Double::sum).get();
                    hour_last.setHour(hour);
                    hour_last.setDistance(distanceAll);
                    hour_last_list.add(hour_last);
                }
                logger.error("hour_last_list cnt:{}", hour_last_list.size());
                if (hour_last_list.size() > 0) {
                    List<EsgGisLocTrajectory> collect = hour_last_list.stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
                    busy_hour = collect.get(0).getHour();
                    easy_hour = collect.get(collect.size() - 1).getHour();
                }

                List<JSONObject> param = sortList.stream().map(o -> {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("lng", o.getFixx());
                    jsonObject.put("lat", o.getFixy());
                    jsonObject.put("tm", o.getTm());
                    return jsonObject;
                }).collect(Collectors.toList());

                List<TrackAoi> trackAoiList = getTrackAoi(param.toString());
                if (trackAoiList.size() > 0) {
                    List<TrackAoi> sortTmList = trackAoiList.stream().sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).collect(Collectors.toList());
                    ArrayList<TrackAoi> evaList = new ArrayList<>();
                    long starTm = 0;
                    long endTm;
                    long diffTm;
                    for (int i = 0; i < sortTmList.size(); i++) {
                        TrackAoi o = sortTmList.get(i);
                        String aoiid = o.getAoiId();
                        String tm = o.getTm();

                        if (starTm == 0 && i == 0) {
                            starTm = Long.parseLong(tm);
                        } else if (starTm == 0) {
                            starTm = (Long.parseLong(sortTmList.get(i - 1).getTm()) + Long.parseLong(tm)) / 2;
                        }

                        if (i < sortTmList.size() - 1 && !StringUtils.equals(aoiid, sortTmList.get(i + 1).getAoiId())) {
                            endTm = (Long.parseLong(sortTmList.get(i + 1).getTm()) + Long.parseLong(tm)) / 2;
                            diffTm = endTm - starTm;

                            o.setAoistart(starTm + "");
                            o.setAoiend(endTm + "");
                            o.setAoiduration(diffTm + "");
                            evaList.add(o);
                            starTm = 0;
                        } else if (i == sortTmList.size() - 1) {
                            endTm = Long.parseLong(tm);
                            diffTm = endTm - starTm;
                            o.setAoistart(starTm + "");
                            o.setAoiend(endTm + "");
                            o.setAoiduration(diffTm + "");
                            evaList.add(o);
                        }
                    }
                    if (evaList.size() > 0) {
                        ArrayList<TrackAoi> tempList = new ArrayList<>();
                        Map<String, List<TrackAoi>> map = evaList.stream().collect(Collectors.groupingBy(TrackAoi::getAoiId));
                        for (Map.Entry<String, List<TrackAoi>> stringListEntry : map.entrySet()) {
                            TrackAoi trackAoi = new TrackAoi();
                            String aoiId = stringListEntry.getKey();
                            List<TrackAoi> value = stringListEntry.getValue();
                            String aoiName = value.get(0).getAoiName();
                            long sum_stay_time = value.stream().map(o -> StringUtils.isNotEmpty(o.getAoiduration()) ? Long.parseLong(o.getAoiduration()) : 0).reduce(Long::sum).get();

                            trackAoi.setAoiId(aoiId);
                            trackAoi.setAoiName(aoiName);
                            trackAoi.setSum_stay_time(sum_stay_time);
                            tempList.add(trackAoi);
                        }

                        TrackAoi last = tempList.stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0);
                        most_stay_aoiid = last.getAoiId();
                        most_stay_name = last.getAoiName();
                        stay_time = last.getSum_stay_time() + "";
                        stay_time_duration = map.get(most_stay_aoiid).stream().map(o -> o.getAoistart() + "-" + o.getAoiend()).collect(Collectors.joining(","));
                    }
                }
            }

            String finalMost_stay_aoiid = most_stay_aoiid;
            String finalMost_stay_name = most_stay_name;
            String finalStay_time = stay_time;
            String finalStay_time_duration = stay_time_duration;
            String finalBusy_hour = busy_hour;
            String finalEasy_hour = easy_hour;
            return list.stream().peek(o -> {
                o.setMost_stay_aoiid(finalMost_stay_aoiid);
                o.setMost_stay_name(finalMost_stay_name);
                o.setStay_time(finalStay_time);
                o.setStay_time_duration(finalStay_time_duration);
                o.setBusy_hour(finalBusy_hour);
                o.setEasy_hour(finalEasy_hour);
            }).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stayAoiIdRdd cnt:{}", stayAoiIdRdd.count());
        trajectoryRdd.unpersist();

        String schedule_width_data_sql = String.format("select\n" +
                "  loginid,\n" +
                "  aoi_area_id,\n" +
                "  batch_code,\n" +
                "  start_time,\n" +
                "  end_time\n" +
                "from\n" +
                "  dm_tc_waybillinfo.schedule_width_data\n" +
                "where\n" +
                "  inc_day = '%s'\n" +
                "  and substr(dept_code, 1, 3) in ('431','432','433','434','435','436','437','438','439','482')" +
                "  group by loginid,aoi_area_id,batch_code,start_time,end_time", date);
        JavaRDD<ScheduleWidthData> scheduleWidthDataRdd = DataUtil.loadData(spark, sc, schedule_width_data_sql, ScheduleWidthData.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataRdd cnt:{}", scheduleWidthDataRdd.count());

        JavaRDD<EsgGisLocTrajectory> trajectoryScheduleWidthDataRdd = stayAoiIdRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()
                .leftOuterJoin(scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).groupByKey()).map(tp -> {
                    List<EsgGisLocTrajectory> list_1 = Lists.newArrayList(tp._2._1);
                    EsgGisLocTrajectory esgGisLocTrajectory = list_1.get(0);
                    String stay_batch_code = "";
                    String aoi_area_id = "";
                    String batch_1_start_time_in_dept_aoi = "-1";
                    String batch_1_end_time_in_dept_aoi = "-1";
                    String batch_2_start_time_in_dept_aoi = "-1";
                    String batch_2_end_time_in_dept_aoi = "-1";
                    String batch_3_start_time_in_dept_aoi = "-1";
                    String batch_3_end_time_in_dept_aoi = "-1";

                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<ScheduleWidthData> list_2 = Lists.newArrayList(tp._2._2.get());
                        String stay_time_duration = esgGisLocTrajectory.getStay_time_duration();
                        if (StringUtils.isNotEmpty(stay_time_duration)) {
                            HashSet<String> set = new HashSet<>();
                            String[] split = stay_time_duration.split(",");
                            for (String s : split) {
                                String[] split1 = s.split("-");
                                String start = split1[0];
                                String end = split1[1];
                                Set<String> collect = list_2.stream().filter(o -> StringUtils.isNotEmpty(o.getStart_time()) && StringUtils.isNotEmpty(o.getEnd_time()) && Long.parseLong(o.getStart_time()) <= Long.parseLong(start) && Long.parseLong(o.getEnd_time()) >= Long.parseLong(end)).map(ScheduleWidthData::getBatch_code).collect(Collectors.toSet());
                                set.addAll(collect);
                            }
                            stay_batch_code = String.join(",", set);
                        }

                        aoi_area_id = list_2.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_area_id())).map(ScheduleWidthData::getAoi_area_id).distinct().collect(Collectors.joining(","));
                        List<EsgGisLocTrajectory> deptXyList = list_1.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(EsgGisLocTrajectory::getDept_code))), ArrayList::new))
                                .stream().filter(o -> StringUtils.isNotEmpty(o.getLongitude()) && StringUtils.isNotEmpty(o.getLatitude())).collect(Collectors.toList());
                        if (deptXyList.size() > 0) {
                            HashSet<String> deptAoiSet = getAoiSet(deptXyList);
                            //网点经纬度aoi不为空
                            if (!deptAoiSet.isEmpty()) {
                                //获取派件班次（batch_code以D结尾）
                                List<ScheduleWidthData> batch_code_list = list_2.stream().filter(o -> StringUtils.isNotEmpty(o.getBatch_code()) && o.getBatch_code().endsWith("D") && StringUtils.isNotEmpty(o.getStart_time()) && StringUtils.isNotEmpty(o.getEnd_time())).collect(Collectors.toList());
                                if (batch_code_list.size() > 0) {
                                    List<ScheduleWidthData> sortList = batch_code_list.stream().sorted((o1, o2) -> o1.getStart_time().compareTo(o2.getStart_time())).collect(Collectors.toList());

                                    //班次1开始时间
                                    ScheduleWidthData batch_1 = sortList.get(0);
                                    String batch_1_start_time = batch_1.getStart_time();
                                    HashSet<String> batch_1_start_time_trajectory_aoi_set = getTrajectoryAoi(batch_1_start_time, list_1);
                                    if (!batch_1_start_time_trajectory_aoi_set.isEmpty()) {
                                        batch_1_start_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_1_start_time_trajectory_aoi_set);
                                    }

                                    //班次1结束时间
                                    String batch_1_end_time = batch_1.getEnd_time();
                                    HashSet<String> batch_1_end_time_trajectory_aoi_set = getTrajectoryAoi(batch_1_end_time, list_1);
                                    if (!batch_1_end_time_trajectory_aoi_set.isEmpty()) {
                                        batch_1_end_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_1_end_time_trajectory_aoi_set);
                                    }

                                    if (sortList.size() > 1) {
                                        //班次2开始时间
                                        ScheduleWidthData batch_2 = sortList.get(1);
                                        String batch_2_start_time = batch_2.getStart_time();
                                        HashSet<String> batch_2_start_time_trajectory_aoi_set = getTrajectoryAoi(batch_2_start_time, list_1);
                                        if (!batch_2_start_time_trajectory_aoi_set.isEmpty()) {
                                            batch_2_start_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_2_start_time_trajectory_aoi_set);
                                        }

                                        //班次2结束时间
                                        String batch_2_end_time = batch_2.getEnd_time();
                                        HashSet<String> batch_2_end_time_trajectory_aoi_set = getTrajectoryAoi(batch_2_end_time, list_1);
                                        if (!batch_2_end_time_trajectory_aoi_set.isEmpty()) {
                                            batch_2_end_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_2_end_time_trajectory_aoi_set);
                                        }
                                    }

                                    //班次3开始时间
                                    ScheduleWidthData batch_3 = sortList.get(sortList.size() - 1);
                                    String batch_3_start_time = batch_3.getStart_time();
                                    HashSet<String> batch_3_start_time_trajectory_aoi_set = getTrajectoryAoi(batch_3_start_time, list_1);
                                    if (!batch_3_start_time_trajectory_aoi_set.isEmpty()) {
                                        batch_3_start_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_3_start_time_trajectory_aoi_set);
                                    }

                                    //班次3结束时间
                                    String batch_3_end_time = batch_3.getEnd_time();
                                    HashSet<String> batch_3_end_time_trajectory_aoi_set = getTrajectoryAoi(batch_3_end_time, list_1);
                                    if (!batch_3_end_time_trajectory_aoi_set.isEmpty()) {
                                        batch_3_end_time_in_dept_aoi = dept_aoi_in_trajectory_aoi(deptAoiSet, batch_3_end_time_trajectory_aoi_set);
                                    }

                                }
                            }
                        }
                    }

                    esgGisLocTrajectory.setAoi_area_id(aoi_area_id);
                    esgGisLocTrajectory.setBatch_1_start_time_in_dept_aoi(batch_1_start_time_in_dept_aoi);
                    esgGisLocTrajectory.setBatch_1_end_time_in_dept_aoi(batch_1_end_time_in_dept_aoi);
                    esgGisLocTrajectory.setBatch_2_start_time_in_dept_aoi(batch_2_start_time_in_dept_aoi);
                    esgGisLocTrajectory.setBatch_2_end_time_in_dept_aoi(batch_2_end_time_in_dept_aoi);
                    esgGisLocTrajectory.setBatch_3_start_time_in_dept_aoi(batch_3_start_time_in_dept_aoi);
                    esgGisLocTrajectory.setBatch_3_end_time_in_dept_aoi(batch_3_end_time_in_dept_aoi);
                    esgGisLocTrajectory.setStay_batch_code(stay_batch_code);

                    return esgGisLocTrajectory;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trajectoryScheduleWidthDataRdd cnt:{}", trajectoryScheduleWidthDataRdd.count());
        stayAoiIdRdd.unpersist();

        String inc_sgs_task_flow_new_sql = String.format("select userid,eventlng,eventlat from ods_inc_sgs_core.inc_sgs_task_flow_new where inc_day = '%s' and eventlng is not null and eventlng <>'' and city_code in('431','432','433','434','435','436','437','438','439','482') group by userid,eventlng,eventlat", date);
        JavaRDD<IncSgsTaskFlowNew> incSgsTaskFlowNewRdd = DataUtil.loadData(spark, sc, inc_sgs_task_flow_new_sql, IncSgsTaskFlowNew.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("incSgsTaskFlowNewRdd cnt:{}", incSgsTaskFlowNewRdd.count());

        JavaRDD<EsgGisLocTrajectory> incSgsRdd = trajectoryScheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(incSgsTaskFlowNewRdd.mapToPair(o -> new Tuple2<>(o.getUserid(), o)).groupByKey()).map(tp -> {
                    EsgGisLocTrajectory esgGisLocTrajectory = tp._2._1;
                    String is_bq_op = "0";
                    String most_stay_aoiid = esgGisLocTrajectory.getMost_stay_aoiid();
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<IncSgsTaskFlowNew> list_2 = Lists.newArrayList(tp._2._2.get());

                        List<JSONObject> param = list_2.stream().map(o -> {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("lng", o.getEventlng());
                            jsonObject.put("lat", o.getEventlat());
                            return jsonObject;
                        }).collect(Collectors.toList());

                        String content = HttpInvokeUtil.sendPost(getTrackAois, param.toString(), FixedConstant.MAX_TRY_TIME_ONCE);
                        HashSet<String> aoiSet = new HashSet<>();
                        try {
                            JSONArray data = JSON.parseObject(content).getJSONArray("data");
                            for (int i = 0; i < data.size(); i++) {
                                JSONObject jsonObject = data.getJSONObject(i);
                                String aoiId = jsonObject.getString("aoiId");
                                if (StringUtils.isNotEmpty(aoiId)) {
                                    aoiSet.add(aoiId);
                                }
                            }
                        } catch (Exception e) {
//                e.printStackTrace();
                        }

//                        List<EsgGisLocTrajectory> collect = list_2.stream().map(o -> {
//                            EsgGisLocTrajectory trajectory = new EsgGisLocTrajectory();
//                            trajectory.setZx(o.getEventlng());
//                            trajectory.setZy(o.getEventlat());
//                            return trajectory;
//                        }).collect(Collectors.toList());
//                        HashSet<String> aoiSet = getAoiSet(collect);


                        if (aoiSet.size() > 0 && StringUtils.isNotEmpty(most_stay_aoiid) && aoiSet.contains(most_stay_aoiid)) {
                            is_bq_op = "1";
                        }

                    }
                    esgGisLocTrajectory.setIs_bq_op(is_bq_op);
                    return esgGisLocTrajectory;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("incSgsRdd cnt:{}", incSgsRdd.count());
        trajectoryScheduleWidthDataRdd.unpersist();
        incSgsTaskFlowNewRdd.unpersist();

        String op_sql = String.format("select\n" +
                "  baroprcode,\n" +
                "  from_unixtime(cast(barscantm / 1000 as bigint), 'HH') hour,\n" +
                "  ordinal\n" +
                "from\n" +
                "  ods_kafka_fvp.fvp_core_fact_route_op\n" +
                "where\n" +
                "  inc_day = '%s'\n" +
                "  and baroprcode is not null\n" +
                "  and baroprcode <>''\n" +
                "  and baroprcode <>'null'\n" +
                "  and substr(zonecode, 1, 3) in ('431','432','433','434','435','436','437','438','439','482')\n" +
                "group by\n" +
                "  baroprcode,\n" +
                "  from_unixtime(cast(barscantm / 1000 as bigint), 'HH'),\n" +
                "  ordinal", date);
        JavaRDD<FvpCoreFactRoute> hourOrdinalRdd = DataUtil.loadData(spark, sc, op_sql, FvpCoreFactRoute.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("hourOrdinalRdd cnt:{}", hourOrdinalRdd.count());

        JavaRDD<FvpCoreFactRoute> ordinalCntRdd = hourOrdinalRdd.mapToPair(o -> new Tuple2<>(o.getBaroprcode() + "_" + o.getHour(), o)).groupByKey().map(tp -> {
            List<FvpCoreFactRoute> list = Lists.newArrayList(tp._2);
            FvpCoreFactRoute fvpCoreFactRoute = list.get(0);
            long count = list.stream().map(FvpCoreFactRoute::getOrdinal).distinct().count();
            fvpCoreFactRoute.setOrdinal_cnt(count);
            return fvpCoreFactRoute;
        }).mapToPair(o -> new Tuple2<>(o.getBaroprcode(), o)).groupByKey().map(tp -> {
            List<FvpCoreFactRoute> list = Lists.newArrayList(tp._2);
            return list.stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ordinalCntRdd cnt:{}", ordinalCntRdd.count());
        hourOrdinalRdd.unpersist();

        JavaRDD<EsgGisLocTrajectory> opHourRdd = incSgsRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(ordinalCntRdd.mapToPair(o -> new Tuple2<>(o.getBaroprcode(), o))).map(tp -> {
            EsgGisLocTrajectory o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                FvpCoreFactRoute fvpCoreFactRoute = tp._2._2.get();
                o.setOp_hour(fvpCoreFactRoute.getHour());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("opHourRdd cnt:{}", opHourRdd.count());
        incSgsRdd.unpersist();
        ordinalCntRdd.unpersist();

//        String path_sql = String.format("select\n" +
//                "  un,\n" +
//                "  req\n" +
//                "from\n" +
//                "  dm_gis.path_fix\n" +
//                "where\n" +
//                "  inc_day = '%s'\n" +
//                "  and tp = 'bike'\n" +
//                "  and un is not null\n" +
//                "  and un <>''\n" +
//                "  and req is not null\n" +
//                "  and req <>''\n" +
//                "  and substr(bn, 1, 3) in ('431','432','433','434','435','436','437','438','439','482')\n" +
//                "group by\n" +
//                "  un,\n" +
//                "  req", date);
//        JavaRDD<PathFix> pathRdd = DataUtil.loadData(spark, sc, path_sql, PathFix.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("pathRdd cnt:{}", pathRdd.count());
//
//        JavaRDD<PathFix> distanceRdd = pathRdd.flatMap(o -> {
//            ArrayList<PathFix> list = new ArrayList<>();
//            String req = o.getReq();
//            String un = o.getUn();
//            if (StringUtils.isNotEmpty(req)) {
//                JSONObject jsonObject = JSON.parseObject(req);
//                if (jsonObject != null) {
//                    JSONArray tracks = jsonObject.getJSONArray("tracks");
//                    for (int i = 0; i < tracks.size(); i++) {
//                        if (i != (tracks.size() - 1)) {
//                            PathFix pathFix = new PathFix();
//                            pathFix.setUn(un);
//                            JSONObject temp = tracks.getJSONObject(i);
//                            String time = temp.getString("time");
//                            String x = temp.getString("x");
//                            String y = temp.getString("y");
//                            String hour = DateUtil.tmToDate(time + "000", "HH");
//                            pathFix.setHour(hour);
//
//                            JSONObject temp2 = tracks.getJSONObject(i + 1);
//                            String x1 = temp2.getString("x");
//                            String y1 = temp2.getString("y");
//                            if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y) && StringUtils.isNotEmpty(x1) && StringUtils.isNotEmpty(y1)) {
//                                double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(x1), Double.parseDouble(y1));
//                                pathFix.setDistance(distance);
//                            }
//                            list.add(pathFix);
//                        }
//                    }
//                }
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("distanceRdd cnt:{}", distanceRdd.count());
//        pathRdd.unpersist();
//
//        JavaRDD<PathFix> sumDistanceRdd = distanceRdd.mapToPair(o -> new Tuple2<>(o.getUn() + "_" + o.getHour(), o)).groupByKey().map(tp -> {
//            List<PathFix> list = Lists.newArrayList(tp._2);
//            PathFix pathFix = list.get(0);
//            double distance = list.stream().map(PathFix::getDistance).reduce(Double::sum).get();
//            pathFix.setDistance(distance);
//            return pathFix;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("sumDistanceRdd cnt:{}", sumDistanceRdd.count());
//        distanceRdd.unpersist();
//
//        JavaRDD<EsgGisLocTrajectory> resultRdd = opHourRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
//                .leftOuterJoin(sumDistanceRdd.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey()).map(tp -> {
//                    EsgGisLocTrajectory o = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        List<PathFix> list = Lists.newArrayList(tp._2._2.get());
//                        List<PathFix> sortList = list.stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
//                        String busy_hour = sortList.get(0).getHour();
//                        String easy_hour = sortList.get(sortList.size() - 1).getHour();
//
//                        o.setBusy_hour(busy_hour);
//                        o.setEasy_hour(easy_hour);
//                    }
//                    return o;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        opHourRdd.unpersist();
//        sumDistanceRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.xiaoge_stay_status", EsgGisLocTrajectory.class, opHourRdd, "inc_day");
        opHourRdd.unpersist();

        sc.stop();
        logger.error("end...");
    }

    public static List<TrackAoi> getTrackAoi(String param) {
        ArrayList<TrackAoi> list = new ArrayList<>();
        try {
            String content = HttpInvokeUtil.sendPost(getTrackAois, param, FixedConstant.MAX_TRY_TIME_ONCE);
            JSONArray data = JSON.parseObject(content).getJSONArray("data");
            for (int i = 0; i < data.size(); i++) {
                TrackAoi o = new TrackAoi();
                JSONObject jsonObject = data.getJSONObject(i);
                String aoiId = jsonObject.getString("aoiId");
                String aoiName = jsonObject.getString("aoiName");
                if (StringUtils.isNotEmpty(aoiId)) {
                    o.setAoiId(aoiId);
                    o.setAoiName(aoiName);
                    String lng = jsonObject.getJSONArray("coors").getJSONObject(0).getString("lng");
                    String lat = jsonObject.getJSONArray("coors").getJSONObject(0).getString("lat");
                    String tm = jsonObject.getJSONArray("coors").getJSONObject(0).getString("tm");

                    o.setLng(lng);
                    o.setLat(lat);
                    o.setTm(tm);
                    list.add(o);
                }
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return list;
    }

    public static String dept_aoi_in_trajectory_aoi(HashSet<String> deptAoiSet, HashSet<String> trajectory_aoi_set) {
        String batch_1_start_time_in_dept_aoi = "0";
        for (String dept_aoi : deptAoiSet) {
            if (trajectory_aoi_set.contains(dept_aoi)) {
                batch_1_start_time_in_dept_aoi = "1";
                break;
            }
        }
        return batch_1_start_time_in_dept_aoi;
    }

    public static HashSet<String> getTrajectoryAoi(String tm, List<EsgGisLocTrajectory> list) {
        HashSet<String> set = new HashSet<>();
        long before = Long.parseLong(tm) - 300;
        long after = Long.parseLong(tm) + 300;
        List<EsgGisLocTrajectory> tm_list = list.stream().filter(o -> StringUtils.isNotEmpty(o.getTm()) && Long.parseLong(o.getTm()) <= after && Long.parseLong(o.getTm()) >= before && StringUtils.isNotEmpty(o.getZx()) && StringUtils.isNotEmpty(o.getZy())).collect(Collectors.toList());
        if (tm_list.size() > 0) {
            List<JSONObject> param = tm_list.stream().sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).map(o -> {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("lng", o.getZx());
                jsonObject.put("lat", o.getZy());
                jsonObject.put("tm", o.getTm());
                return jsonObject;
            }).collect(Collectors.toList());

            String content = HttpInvokeUtil.sendPost(getTrackAois, param.toString(), FixedConstant.MAX_TRY_TIME_ONCE);
            try {
                JSONArray data = JSON.parseObject(content).getJSONArray("data");
                for (int i = 0; i < data.size(); i++) {
                    JSONObject jsonObject = data.getJSONObject(i);
                    String aoiId = jsonObject.getString("aoiId");
                    if (StringUtils.isNotEmpty(aoiId)) {
                        set.add(aoiId);
                    }
                }
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return set;
    }


    public static HashSet<String> getAoiSet(List<EsgGisLocTrajectory> list) {
        HashSet<String> set = new HashSet<>();
        List<EsgGisLocTrajectory> collect = list.stream().peek(o -> {
            String zx = o.getZx();
            String zy = o.getZy();
            String aoi = getAoiByXy(zx, zy);
            if (StringUtils.isNotEmpty(aoi)) {
                set.add(aoi);
            }
        }).collect(Collectors.toList());

        return set;
    }

    public static String getAoiByXy(String x, String y) {
        String aoi = "";
        String req = String.format(getAoiByXy, x, y);
        String content = HttpInvokeUtil.sendGet(req);
        try {
            aoi = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONObject("aoi").getString("aoi_id");
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return aoi;
    }
}
