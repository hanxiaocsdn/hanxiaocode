package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.WlEcoReturnConsigneeAddrDtl;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * 任务id:801182(【退货地址联想】运单地址推redis)
 * 业务方：01381101（匡可心）
 * 研发：01399581（匡仁衡）
 */
public class AppWlEcoReturnConsigneeAddrDtl {
    private static Logger logger = LoggerFactory.getLogger(AppWlEcoReturnConsigneeAddrDtl.class);
    private static String url = "http://gis-gw.int.sfdc.com.cn:9080/rtip/addressPut";
    private static int limitSec = 1000 / 10;
    private static String account = "01399581";
    private static String taskId = "801182";
    private static String taskName = "运单地址推redis";

    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        logger.error("date1:{}, date2:{}", date1, date2);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppWlEcoReturnConsigneeAddrDtl");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select consignee_addr,dest_dist_code from dm_gis.wl_eco_return_consignee_addr_dtl where inc_day between '%s' and '%s' and (consignee_addr is not null and consignee_addr <>'') group by consignee_addr,dest_dist_code", date1, date2);
        JavaRDD<WlEcoReturnConsigneeAddrDtl> rdd = DataUtil.loadData(spark, sc, sql, WlEcoReturnConsigneeAddrDtl.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, url, "eeb85bf572b24957b299b674d95726c1", rdd.count(), 10);
        JavaRDD<WlEcoReturnConsigneeAddrDtl> lastRdd = getApi(rdd, 10);
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        JavaRDD<WlEcoReturnConsigneeAddrDtl> sucRdd = lastRdd.filter(t -> StringUtils.isNotEmpty(t.getContent()) && t.getContent().contains("推送成功")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<WlEcoReturnConsigneeAddrDtl> failRdd = lastRdd.filter(t -> StringUtils.isEmpty(t.getContent()) || (StringUtils.isNotEmpty(t.getContent()) && !t.getContent().contains("推送成功"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long failCnt = failRdd.count();
        logger.error("sucRdd cnt:{}", sucRdd.count());
        logger.error("failRdd cnt:{}", failCnt);
        failRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        lastRdd.unpersist();

        if (failCnt > 0) {
            String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, url, "eeb85bf572b24957b299b674d95726c1", rdd.count(), 1);
            JavaRDD<WlEcoReturnConsigneeAddrDtl> secRdd = getApi(failRdd, 1);
            BdpTaskRecordUtil.endNetworkInterface(account, id2);
            JavaRDD<WlEcoReturnConsigneeAddrDtl> secSucRdd = secRdd.filter(t -> StringUtils.isNotEmpty(t.getContent()) && t.getContent().contains("推送成功")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<WlEcoReturnConsigneeAddrDtl> secFailRdd = secRdd.filter(t -> StringUtils.isEmpty(t.getContent()) || (StringUtils.isNotEmpty(t.getContent()) && !t.getContent().contains("推送成功"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("secSucRdd cnt:{}", secSucRdd.count());
            logger.error("secFailRdd cnt:{}", secFailRdd.count());
            secFailRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            secRdd.unpersist();
        }
        sc.stop();
    }

    public static JavaRDD<WlEcoReturnConsigneeAddrDtl> getApi(JavaRDD<WlEcoReturnConsigneeAddrDtl> rdd, int partition) {
        JavaRDD<WlEcoReturnConsigneeAddrDtl> lastRdd = rdd.repartition(partition).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<WlEcoReturnConsigneeAddrDtl> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitSec) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 1000) {
                        logger.error("每秒钟访问量超过限制:{},休眠:{}ms中", limitSec, 1000 - endTime);
                        Thread.sleep(1000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                WlEcoReturnConsigneeAddrDtl o = itr.next();
                String consignee_addr = o.getConsignee_addr();
                String dest_dist_code = o.getDest_dist_code();
                if (StringUtils.isNotEmpty(consignee_addr)) {
                    JSONArray param = new JSONArray();
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("address", consignee_addr);
                    jsonObject.put("city", dest_dist_code);
                    param.add(jsonObject);

                    String content = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", "eeb85bf572b24957b299b674d95726c1", "utf-8", "utf-8");
                    o.setContent(content);
                }
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        rdd.unpersist();
        return lastRdd;
    }
}
