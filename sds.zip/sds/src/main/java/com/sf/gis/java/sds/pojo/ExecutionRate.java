package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ExecutionRate implements Serializable {
    @Column(name="task_id")
    private String taskId;
    @Column(name="len_new")
    private String lenNew;
    @Column(name = "time_new")
    private String timeNew;
    @Column(name="inc_month")
    private String incMonth;
    @Column(name="day")
    private String day;
    @Column(name = "status")
    private String status;
    @Column(name = "conduct_type")
    private String conductType;
    @Column(name = "inc_day")
    private String incDay;
    @Column(name = "toll_charge")
    private String tollCharge;
    @Column(name = "etc_toll_charge")
    private String etcTollCharge;
    @Column(name = "is_navi")
    private String isNavi;
    @Column(name = "is_navi_noyaw")
    private String isNaviNoyaw;
    @Column(name="task_area_code")
    private String taskAreaCode;
    @Column(name="src_province")
    private String srcProvince;
    @Column(name="dest_province")
    private String destProvince;
    @Column(name="src_city_name")
    private String srcCityName;
    @Column(name="dest_city_name")
    private String destCityName;
    @Column(name = "biz_type")
    private int bizType;
    @Column(name = "main_driver_account")
    private String mainDriverAccount;
    @Column(name = "driver_name")
    private String driverName;
    @Column(name = "actual_run_time")
    private long actualRunTime;
    @Column(name = "app_time_actual_distance")
    private double appTimeActualDistance;
    @Column(name = "plan_run_time")
    private long planRunTime;
    @Column(name = "carrier_type")
    private int carrierType;
    @Column(name = "plf_flag")
    private int plfFlag;
    @Column(name = "is_zy")
    private int isZy;
    @Column(name = "is_db")
    private int isDb;
    @Column(name = "nodb_delay_min")
    private long nodbDelayMin;
    @Column(name = "line_code")
    private String lineCode;
    @Column(name = "is_push_line")
    private String isPushLine;
    @Column(name = "base_line_mile")
    private String baseLineMile;
    @Column(name = "base_line_time")
    private String baseLineTime;
    @Column(name = "base_line_etctoll")
    private String baseLineEtctoll;
    @Column(name = "base_line_toll")
    private String baseLineToll;
    @Column(name = "line_area")
    private String line_area;

    @Column(name = "error_type")
    private String error_type;

    private int shuttleNumber;                      //班次数
    private int taskNumber;                         //任务量
    private int executionNumber;                    //执行量
    private int selfSupportTaskNumber;              //自营任务量
    private int selfSupportExecutionNumber;         //自营执行量
    private int noSelfSupportTaskNumber;            //非自营任务量
    private int noSelfSupportExecutionNumber;       //非自营执行量
    private int selfSupportOtherExecutionNumber;    //自营其他执行任务量

    public String getError_type() {
        return error_type;
    }

    public void setError_type(String error_type) {
        this.error_type = error_type;
    }

    public String getLine_area() {
        return line_area;
    }

    public void setLine_area(String line_area) {
        this.line_area = line_area;
    }

    public String getBaseLineToll() {
        return baseLineToll;
    }

    public void setBaseLineToll(String baseLineToll) {
        this.baseLineToll = baseLineToll;
    }

    public String getBaseLineEtctoll() {
        return baseLineEtctoll;
    }

    public void setBaseLineEtctoll(String baseLineEtctoll) {
        this.baseLineEtctoll = baseLineEtctoll;
    }

    public int getSelfSupportOtherExecutionNumber() {
        return selfSupportOtherExecutionNumber;
    }

    public void setSelfSupportOtherExecutionNumber(int selfSupportOtherExecutionNumber) {
        this.selfSupportOtherExecutionNumber = selfSupportOtherExecutionNumber;
    }

    public String getIsPushLine() {
        return isPushLine;
    }

    public void setIsPushLine(String isPushLine) {
        this.isPushLine = isPushLine;
    }

    public String getBaseLineMile() {
        return baseLineMile;
    }

    public void setBaseLineMile(String baseLineMile) {
        this.baseLineMile = baseLineMile;
    }

    public String getBaseLineTime() {
        return baseLineTime;
    }

    public void setBaseLineTime(String baseLineTime) {
        this.baseLineTime = baseLineTime;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getLenNew() {
        return lenNew;
    }

    public void setLenNew(String lenNew) {
        this.lenNew = lenNew;
    }

    public String getTimeNew() {
        return timeNew;
    }

    public void setTimeNew(String timeNew) {
        this.timeNew = timeNew;
    }

    public String getIncMonth() {
        return incMonth;
    }

    public void setIncMonth(String incMonth) {
        this.incMonth = incMonth;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getConductType() {
        return conductType;
    }

    public void setConductType(String conductType) {
        this.conductType = conductType;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getTollCharge() {
        return tollCharge;
    }

    public void setTollCharge(String tollCharge) {
        this.tollCharge = tollCharge;
    }

    public String getEtcTollCharge() {
        return etcTollCharge;
    }

    public void setEtcTollCharge(String etcTollCharge) {
        this.etcTollCharge = etcTollCharge;
    }

    public String getIsNavi() {
        return isNavi;
    }

    public void setIsNavi(String isNavi) {
        this.isNavi = isNavi;
    }

    public String getIsNaviNoyaw() {
        return isNaviNoyaw;
    }

    public void setIsNaviNoyaw(String isNaviNoyaw) {
        this.isNaviNoyaw = isNaviNoyaw;
    }

    public String getTaskAreaCode() {
        return taskAreaCode;
    }

    public void setTaskAreaCode(String taskAreaCode) {
        this.taskAreaCode = taskAreaCode;
    }

    public String getSrcProvince() {
        return srcProvince;
    }

    public void setSrcProvince(String srcProvince) {
        this.srcProvince = srcProvince;
    }

    public String getDestProvince() {
        return destProvince;
    }

    public void setDestProvince(String destProvince) {
        this.destProvince = destProvince;
    }

    public String getSrcCityName() {
        return srcCityName;
    }

    public void setSrcCityName(String srcCityName) {
        this.srcCityName = srcCityName;
    }

    public String getDestCityName() {
        return destCityName;
    }

    public void setDestCityName(String destCityName) {
        this.destCityName = destCityName;
    }

    public int getBizType() {
        return bizType;
    }

    public void setBizType(int bizType) {
        this.bizType = bizType;
    }

    public String getMainDriverAccount() {
        return mainDriverAccount;
    }

    public void setMainDriverAccount(String mainDriverAccount) {
        this.mainDriverAccount = mainDriverAccount;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public long getActualRunTime() {
        return actualRunTime;
    }

    public void setActualRunTime(long actualRunTime) {
        this.actualRunTime = actualRunTime;
    }

    public double getAppTimeActualDistance() {
        return appTimeActualDistance;
    }

    public void setAppTimeActualDistance(double appTimeActualDistance) {
        this.appTimeActualDistance = appTimeActualDistance;
    }

    public long getPlanRunTime() {
        return planRunTime;
    }

    public void setPlanRunTime(long planRunTime) {
        this.planRunTime = planRunTime;
    }

    public int getCarrierType() {
        return carrierType;
    }

    public void setCarrierType(int carrierType) {
        this.carrierType = carrierType;
    }

    public int getPlfFlag() {
        return plfFlag;
    }

    public void setPlfFlag(int plfFlag) {
        this.plfFlag = plfFlag;
    }

    public int getIsZy() {
        return isZy;
    }

    public void setIsZy(int isZy) {
        this.isZy = isZy;
    }

    public int getIsDb() {
        return isDb;
    }

    public void setIsDb(int isDb) {
        this.isDb = isDb;
    }

    public long getNodbDelayMin() {
        return nodbDelayMin;
    }

    public void setNodbDelayMin(long nodbDelayMin) {
        this.nodbDelayMin = nodbDelayMin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public int getShuttleNumber() {
        return shuttleNumber;
    }

    public void setShuttleNumber(int shuttleNumber) {
        this.shuttleNumber = shuttleNumber;
    }

    public int getTaskNumber() {
        return taskNumber;
    }

    public void setTaskNumber(int taskNumber) {
        this.taskNumber = taskNumber;
    }

    public int getExecutionNumber() {
        return executionNumber;
    }

    public void setExecutionNumber(int executionNumber) {
        this.executionNumber = executionNumber;
    }

    public int getSelfSupportTaskNumber() {
        return selfSupportTaskNumber;
    }

    public void setSelfSupportTaskNumber(int selfSupportTaskNumber) {
        this.selfSupportTaskNumber = selfSupportTaskNumber;
    }

    public int getSelfSupportExecutionNumber() {
        return selfSupportExecutionNumber;
    }

    public void setSelfSupportExecutionNumber(int selfSupportExecutionNumber) {
        this.selfSupportExecutionNumber = selfSupportExecutionNumber;
    }

    public int getNoSelfSupportTaskNumber() {
        return noSelfSupportTaskNumber;
    }

    public void setNoSelfSupportTaskNumber(int noSelfSupportTaskNumber) {
        this.noSelfSupportTaskNumber = noSelfSupportTaskNumber;
    }

    public int getNoSelfSupportExecutionNumber() {
        return noSelfSupportExecutionNumber;
    }

    public void setNoSelfSupportExecutionNumber(int noSelfSupportExecutionNumber) {
        this.noSelfSupportExecutionNumber = noSelfSupportExecutionNumber;
    }
}
