package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class UpdateAddr implements Serializable {
    @Column(name = "operusername")
    private String operusername;
    @Column(name = "opersouce")
    private String opersouce;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "address")
    private String address;
    @Column(name = "znocode")
    private String znocode;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "aoisource")
    private String aoisource;
    @Column(name = "addressid")
    private String addressid;
    @Column(name = "response")
    private String response;
    @Column(name = "unitid")
    private String unitid;
    @Column(name = "type")
    private String type;
    @Column(name = "inc_day")
    private String inc_day;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUnitid() {
        return unitid;
    }

    public void setUnitid(String unitid) {
        this.unitid = unitid;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getOperusername() {
        return operusername;
    }

    public void setOperusername(String operusername) {
        this.operusername = operusername;
    }

    public String getOpersouce() {
        return opersouce;
    }

    public void setOpersouce(String opersouce) {
        this.opersouce = opersouce;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZnocode() {
        return znocode;
    }

    public void setZnocode(String znocode) {
        this.znocode = znocode;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getAoisource() {
        return aoisource;
    }

    public void setAoisource(String aoisource) {
        this.aoisource = aoisource;
    }

    public String getAddressid() {
        return addressid;
    }

    public void setAddressid(String addressid) {
        this.addressid = addressid;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
