package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;

@Table
public class FcPu {
    @Column(name = "hq_code")
    private String hqCode;
    @Column(name = "hq_name")
    private String hqName;
    @Column(name = "area_code")
    private String areaCode;
    @Column(name = "area_name")
    private String areaName;
    @Column(name = "division_code")
    private String divisionCode;
    @Column(name = "division_name")
    private String division_name;
    @Column(name = "deptid")
    private String deptId;
    @Column(name = "dept_name")
    private String deptName;
    @Column(name = "teamid")
    private String teamId;
    @Column(name = "couriercode")
    private String couriercode;
    @Column(name = "orderid")
    private String orderId;
    @Column(name = "addr")
    private String addr;
    @Column(name = "firstsendtime_sgs")
    private String firstSendTimeSgs;
    @Column(name = "latest_pickup_tm")
    private String latestPickupTm;
    @Column(name = "op_54_50time")
    private String op5450time;
    @Column(name = "bno")
    private String bno;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_area_id")
    private String aoiAreaId;
    @Column(name = "aoi_area_type")
    private String aoiAreaType;
    @Column(name = "lng_track")
    private String lngTrack;
    @Column(name = "lat_track")
    private String latTrack;
    @Column(name = "tm_track")
    private String tmTrack;
    @Column(name = "tp_track")
    private String tpTrack;
    @Column(name = "track_cnt")
    private String trackCnt;
    @Column(name = "type")
    private String type;
    @Column(name = "addr_tag")
    private String addrTag;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "inc_day")
    private String incDay;

    public String getHqCode() {
        return hqCode;
    }

    public void setHqCode(String hqCode) {
        this.hqCode = hqCode;
    }

    public String getHqName() {
        return hqName;
    }

    public void setHqName(String hqName) {
        this.hqName = hqName;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getDivisionCode() {
        return divisionCode;
    }

    public void setDivisionCode(String divisionCode) {
        this.divisionCode = divisionCode;
    }

    public String getDivision_name() {
        return division_name;
    }

    public void setDivision_name(String division_name) {
        this.division_name = division_name;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getTeamId() {
        return teamId;
    }

    public void setTeamId(String teamId) {
        this.teamId = teamId;
    }

    public String getCouriercode() {
        return couriercode;
    }

    public void setCouriercode(String couriercode) {
        this.couriercode = couriercode;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getFirstSendTimeSgs() {
        return firstSendTimeSgs;
    }

    public void setFirstSendTimeSgs(String firstSendTimeSgs) {
        this.firstSendTimeSgs = firstSendTimeSgs;
    }

    public String getLatestPickupTm() {
        return latestPickupTm;
    }

    public void setLatestPickupTm(String latestPickupTm) {
        this.latestPickupTm = latestPickupTm;
    }

    public String getOp5450time() {
        return op5450time;
    }

    public void setOp5450time(String op5450time) {
        this.op5450time = op5450time;
    }

    public String getBno() {
        return bno;
    }

    public void setBno(String bno) {
        this.bno = bno;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiAreaId() {
        return aoiAreaId;
    }

    public void setAoiAreaId(String aoiAreaId) {
        this.aoiAreaId = aoiAreaId;
    }

    public String getAoiAreaType() {
        return aoiAreaType;
    }

    public void setAoiAreaType(String aoiAreaType) {
        this.aoiAreaType = aoiAreaType;
    }

    public String getLngTrack() {
        return lngTrack;
    }

    public void setLngTrack(String lngTrack) {
        this.lngTrack = lngTrack;
    }

    public String getLatTrack() {
        return latTrack;
    }

    public void setLatTrack(String latTrack) {
        this.latTrack = latTrack;
    }

    public String getTmTrack() {
        return tmTrack;
    }

    public void setTmTrack(String tmTrack) {
        this.tmTrack = tmTrack;
    }

    public String getTpTrack() {
        return tpTrack;
    }

    public void setTpTrack(String tpTrack) {
        this.tpTrack = tpTrack;
    }

    public String getTrackCnt() {
        return trackCnt;
    }

    public void setTrackCnt(String trackCnt) {
        this.trackCnt = trackCnt;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAddrTag() {
        return addrTag;
    }

    public void setAddrTag(String addrTag) {
        this.addrTag = addrTag;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "FcPu{" +
                "hqCode='" + hqCode + '\'' +
                ", hqName='" + hqName + '\'' +
                ", areaCode='" + areaCode + '\'' +
                ", areaName='" + areaName + '\'' +
                ", divisionCode='" + divisionCode + '\'' +
                ", division_name='" + division_name + '\'' +
                ", deptId='" + deptId + '\'' +
                ", deptName='" + deptName + '\'' +
                ", teamId='" + teamId + '\'' +
                ", couriercode='" + couriercode + '\'' +
                ", orderId='" + orderId + '\'' +
                ", addr='" + addr + '\'' +
                ", firstSendTimeSgs='" + firstSendTimeSgs + '\'' +
                ", latestPickupTm='" + latestPickupTm + '\'' +
                ", op5450time='" + op5450time + '\'' +
                ", bno='" + bno + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiAreaId='" + aoiAreaId + '\'' +
                ", aoiAreaType='" + aoiAreaType + '\'' +
                ", lngTrack='" + lngTrack + '\'' +
                ", latTrack='" + latTrack + '\'' +
                ", tmTrack='" + tmTrack + '\'' +
                ", tpTrack='" + tpTrack + '\'' +
                ", trackCnt='" + trackCnt + '\'' +
                ", type='" + type + '\'' +
                ", addrTag='" + addrTag + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
