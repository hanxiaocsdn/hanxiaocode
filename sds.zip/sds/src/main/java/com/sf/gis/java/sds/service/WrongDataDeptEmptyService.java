package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.DruidManager;
import com.sf.gis.java.sds.db.GislgDbManager;
import com.sf.gis.java.sds.pojo.WrongDataDeptEmpty;
import com.sf.gis.java.sds.service.impl.IWrongDataDeptEmptyService;
import com.sf.gis.java.sds.utils.IDGenerator;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;


public class WrongDataDeptEmptyService extends BaseService implements IWrongDataDeptEmptyService {
    private static final Logger logger = LoggerFactory.getLogger(WrongDataDeptEmptyService.class);

    DruidManager druidManager;

    public WrongDataDeptEmptyService() {
        druidManager = GislgDbManager.getInstance().getDruidManager();
    }

    public final static String TABLE_NAME = "sss_gis_miss";

    public final static String[] columns = {"id", "address_md5", "address", "deptcode", "req_time", "data_time",
            "frequency", "city_code", "waybillNo", "is_done"};
    private final static String[] updateColumns = {"waybillNo", "deptcode", "req_time"};

    @Override
    public void insert(List<WrongDataDeptEmpty> list) throws Exception {
        druidManager.excuBatch(list, 5000, new com.sf.gis.java.sds.db.DruidManager.ExcuBatchListener() {

            @Override
            public String createSql() {
                StringBuilder sb = new StringBuilder();
                String insertSql = druidManager.crateInsertSqlWithOutValue(columns, TABLE_NAME);
                sb.append(insertSql);
                sb.append(" on  DUPLICATE key update frequency=frequency+? , ");
                sb.append(druidManager.crateSetSqlWithOutValue(updateColumns));
                return sb.toString();
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);
                for (int i = 0; i < columns.length; i++) {
                    if (columns[i].equals("id")) {
                        stmt.setString(i + 1, IDGenerator.getID());
                    } else {
                        stmt.setString(i + 1, (String) map.get(columns[i]));
                    }
                }
                stmt.setString(columns.length + 1, (String) map.get("frequency"));
                for (int i = 0; i < updateColumns.length; i++) {
                    String column = updateColumns[i];
                    stmt.setString(columns.length + i + 2, (String) map.get(column));
                }
                // LogUtil.d(((SssGisData)data).getAddress());
            }

        });
    }

    @Override
    public void createTable() {
        StringBuilder sb = new StringBuilder("create table IF NOT EXISTS " + TABLE_NAME + "(");
        for (String column : columns) {
            if (column.equals("address")) {
                sb.append(column + " text  ,");
            } else {
                sb.append(column + " VARCHAR(50)  ,");
            }
        }
        sb.append("CREATE_TIME  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,");
        sb.append("UPDATE_TIME  timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP ,");
        sb.append(" PRIMARY KEY ( id ), unique INDEX address_src_index(address_md5, city_code, data_time) ");
        sb.append(")ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        logger.error(sb.toString());
        druidManager.update(sb.toString());
    }

    @Override
    public void deleteData(String date, String cityCode) {
        String deleteSql = "delete from " + TABLE_NAME + " where data_time = '" + date + "' ";
        if (cityCode != null) {
            deleteSql += " and city_code = '" + cityCode + "'";
        }
        logger.error("delte today:" + deleteSql);
        druidManager.update(deleteSql);
    }

}