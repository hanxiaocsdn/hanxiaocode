package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.EdcsWaybillContentSwsKafkaSjOutAreaController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 需求：外区件aoi补全
 * 业务方：田野
 * 研发：匡仁衡
 */

public class AppEdcsWaybillContentSwsKafkaSjOutArea {
    private static Logger logger = LoggerFactory.getLogger(AppEdcsWaybillContentSwsKafkaSjOutArea.class);

    public static void main(String[] args) {
        String date = args[0];
        String minDate = args[1];
        String[] split = minDate.split("#");
        minDate = split[0] + " " + split[1];
        logger.error("date:{},minDate:{}", date, minDate);
        new EdcsWaybillContentSwsKafkaSjOutAreaController().process(date, minDate);
        logger.error("process end...");
    }
}
