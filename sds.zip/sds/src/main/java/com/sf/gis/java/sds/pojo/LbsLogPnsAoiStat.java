package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
@Table
public class LbsLogPnsAoiStat implements Serializable {
    @Column(name = "standard_num")
    private String standardNum;
    @Column(name = "less_tracks")
    private String lessTracks;
    @Column(name = "standard")
    private String standard;
    @Column(name = "empty_tracks")
    private String emptyTracks;
    @Column(name = "not_aoi_err")
    private String notAoiErr;
    @Column(name = "param_err")
    private String paramErr;
    @Column(name = "unknown_gid")
    private String unknownGid;
    @Column(name = "unknown_err")
    private String unknownErr;
    @Column(name = "no_standard_num")
    private String noStandardNum;
    @Column(name = "aoi_side_limit")
    private String aoiSideLimit;
    @Column(name = "aoi_distance_limit")
    private String aoiDistanceLimit;
    @Column(name = "poi_side_limit")
    private String poiSideLimit;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "inc_day")
    private String incDay;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getStandardNum() {
        return standardNum;
    }

    public void setStandardNum(String standardNum) {
        this.standardNum = standardNum;
    }

    public String getLessTracks() {
        return lessTracks;
    }

    public void setLessTracks(String lessTracks) {
        this.lessTracks = lessTracks;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getEmptyTracks() {
        return emptyTracks;
    }

    public void setEmptyTracks(String emptyTracks) {
        this.emptyTracks = emptyTracks;
    }

    public String getNotAoiErr() {
        return notAoiErr;
    }

    public void setNotAoiErr(String notAoiErr) {
        this.notAoiErr = notAoiErr;
    }

    public String getParamErr() {
        return paramErr;
    }

    public void setParamErr(String paramErr) {
        this.paramErr = paramErr;
    }

    public String getUnknownGid() {
        return unknownGid;
    }

    public void setUnknownGid(String unknownGid) {
        this.unknownGid = unknownGid;
    }

    public String getUnknownErr() {
        return unknownErr;
    }

    public void setUnknownErr(String unknownErr) {
        this.unknownErr = unknownErr;
    }

    public String getNoStandardNum() {
        return noStandardNum;
    }

    public void setNoStandardNum(String noStandardNum) {
        this.noStandardNum = noStandardNum;
    }

    public String getAoiSideLimit() {
        return aoiSideLimit;
    }

    public void setAoiSideLimit(String aoiSideLimit) {
        this.aoiSideLimit = aoiSideLimit;
    }

    public String getAoiDistanceLimit() {
        return aoiDistanceLimit;
    }

    public void setAoiDistanceLimit(String aoiDistanceLimit) {
        this.aoiDistanceLimit = aoiDistanceLimit;
    }

    public String getPoiSideLimit() {
        return poiSideLimit;
    }

    public void setPoiSideLimit(String poiSideLimit) {
        this.poiSideLimit = poiSideLimit;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }
}
