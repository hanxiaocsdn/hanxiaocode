package com.sf.gis.java.sds.pojo.aoicompletion;

import org.jetbrains.annotations.NotNull;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class OrderWaybillHook implements Serializable, Comparable<OrderWaybillHook> {
    @Column(name = "emp_code")
    private String emp_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_zc")
    private String aoi_zc;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "aoi_count")
    private String aoi_count;
    @Column(name = "pick_jiti")
    private String pick_jiti;
    @Column(name = "send_jiti")
    private String send_jiti;

    private String jiti;
    private String similarity;

    public String getJiti() {
        return jiti;
    }

    public void setJiti(String jiti) {
        this.jiti = jiti;
    }

    public String getSimilarity() {
        return similarity;
    }

    public void setSimilarity(String similarity) {
        this.similarity = similarity;
    }

    public String getPick_jiti() {
        return pick_jiti;
    }

    public void setPick_jiti(String pick_jiti) {
        this.pick_jiti = pick_jiti;
    }

    public String getSend_jiti() {
        return send_jiti;
    }

    public void setSend_jiti(String send_jiti) {
        this.send_jiti = send_jiti;
    }

    public String getAoi_count() {
        return aoi_count;
    }

    public void setAoi_count(String aoi_count) {
        this.aoi_count = aoi_count;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_zc() {
        return aoi_zc;
    }

    public void setAoi_zc(String aoi_zc) {
        this.aoi_zc = aoi_zc;
    }

    @Override
    public int compareTo(OrderWaybillHook o) {
        String aoi_count = this.getAoi_count();
        String aoi_count1 = o.getAoi_count();
        if (Integer.parseInt(aoi_count) > Integer.parseInt(aoi_count1)) {
            return 1;
        } else if (Integer.parseInt(aoi_count) < Integer.parseInt(aoi_count1)) {
            return -1;
        }
        return 0;
    }
}
