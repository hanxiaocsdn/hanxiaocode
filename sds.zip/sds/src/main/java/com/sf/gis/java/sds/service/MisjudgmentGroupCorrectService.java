package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.OperationBottomcorrected;
import com.sf.gis.java.sds.utils.DesUtils;
import com.sf.gis.java.sds.utils.GzipUtils;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MisjudgmentGroupCorrectService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(MisjudgmentGroupCorrectService.class);

    public JavaRDD<OperationBottomcorrected> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected.sql", startDate, endDate);
        logger.error("aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected sql: {}", sql);

//        String sql = "select * from dm_gis.citycode_gis_to_sys_groupid";
        //加载数据
        return DataUtil.loadData(spark, sc, sql, OperationBottomcorrected.class);
    }

    public JavaRDD<OperationBottomcorrected> processCms(String getAddrByCityCodeAndAddrUrl, JavaRDD<OperationBottomcorrected> initRdd) {
        initRdd = initRdd.map(o -> {
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                String content = runGetCmsAoi(getAddrByCityCodeAndAddrUrl, city_code, gis_to_sys_groupid);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if (data != null) {
                                String address = data.getString("address");
                                String keyword = data.getString("keyword");
                                String aoiId = data.getString("aoiId");
                                String adcode = data.getString("adcode");
                                String znoCode = data.getString("znoCode");

                                address = replaceSymbol(transformNumber(exChange(address)));
                                keyword = replaceSymbol(transformNumber(exChange(keyword)));
                                o.setStd_address(address);
                                o.setKeyword(keyword);
                                o.setAoiId(aoiId);
                                o.setAdcode(adcode);
                                o.setZnoCode(znoCode);
                            }
                        }
                    }
                }
            }
            return o;
        });
        return initRdd;
    }


    public JavaRDD<OperationBottomcorrected> processCms_aoiname(String getAddrByCityCodeAndAddrUrl, JavaRDD<OperationBottomcorrected> initRdd) {
        initRdd = initRdd.map(o -> {
            String aoiId = o.getAoiId();
            if (StringUtils.isNotEmpty(aoiId)) {
                String content = runGetCmsAoiName(getAddrByCityCodeAndAddrUrl, aoiId);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    Integer status = jsonObject.getInteger("status");
                    if (status == 0) {
                        JSONObject result = jsonObject.getJSONObject("result");
                        if (result != null) {
                            JSONArray data = result.getJSONArray("data");
                            if (data.size() > 0) {
                                String aoi_name = data.getJSONObject(0).getString("aoi_name");
                                logger.error("cms_aoi_name:{}", aoi_name);
                                aoi_name = transformNumber(exChange(aoi_name));
                                o.setCms_aoiname(aoi_name);
                            }
                        }
                    }
                }
            }
            return o;
        });
        return initRdd;
    }

    public String runGetCmsAoiName(String urlPattern, String aoiId) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, aoiId);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request cms error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public String runGetCmsAoi(String urlPattern, String cityCode, String addressId) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, cityCode, addressId);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request cms error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String getGdPoi(String url, OperationBottomcorrected o) {
        String std_address = o.getStd_address();
        String city_code = o.getCity_code();
        JSONObject json = new JSONObject();
        json.put("keywords", std_address);
        json.put("city", city_code);
        json.put("extensions", "all");
        json.put("pageSize", 10);
        json.put("pageCount", 1);
        DesUtils desUtils = new DesUtils();
        String content = "";
        try {
            String parm = desUtils.encrypt(json.toJSONString(), "utf-8");
            JSONObject map = new JSONObject();
            map.put("ak", "ae9c0205b5834a8da2cd362f1fe3d713");
            map.put("param", parm);

            logger.error("request url:{}", url);
            byte[] res = UrlUtil.postGetByte(url, map, 3);
            byte[] decRes = desUtils.decryptByte(res);
            byte[] unzipRes = GzipUtils.uncompress(decRes);
            content = new String(unzipRes, "UTF-8");
            if (StringUtils.isEmpty(content)) {
                return "";
            }

        } catch (Exception e) {
            logger.error("request error url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

//    public boolean processKeyword(String keyword) {
//        boolean flag = true;
//        if (StringUtils.isNotEmpty(keyword)) {
//            if (keyword.endsWith("制品有限公司") || keyword.endsWith("电镀有限公司") || keyword.endsWith("有限责任公司") || keyword.endsWith("股份有限公司") || keyword.endsWith("科技有限公司")
//                    || keyword.endsWith("有限公司") || keyword.endsWith("公司") || keyword.endsWith("制品厂") || keyword.endsWith("大酒店") || keyword.endsWith("酒店") || keyword.endsWith("商场")
//                    || keyword.endsWith("小区") || keyword.endsWith("栋") || keyword.endsWith("号楼") || keyword.endsWith("幢")) {
//                flag = false;
//            }
//        }
//        return flag;
//    }

    public boolean processAddress(String address) {
        boolean flag = true;
        if (StringUtils.isNotEmpty(address)) {
            if (address.endsWith("业园") || address.endsWith("业区") || address.endsWith("业园区") || address.endsWith("社区") || address.endsWith("商业街")
                    || address.endsWith("广场") || address.endsWith("村")) {
                flag = false;
            }
        }
        return flag;
    }

    public String exChange(String str) {
        StringBuffer sb = new StringBuffer();
        if (StringUtils.isNotEmpty(str)) {
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (Character.isUpperCase(c)) {
                    sb.append(Character.toLowerCase(c));
                } else {
                    sb.append(c);
                }
            }
        }
        return sb.toString();
    }

    public String transformNumber(String str) {
        if (StringUtils.isNotEmpty(str)) {
            for (int i = 0; i < 9; i++) {
                str = str.replace("一二三四五六七八九".charAt(i), (char) ('0' + i));
            }
            return str;
        }
        return "";
    }

    public String replaceSymbol(String str) {
        if (StringUtils.isNotEmpty(str)) {
            str = str.replaceAll("[`~!@#$%^&*()+=|{}':;',\\[\\].<>/?~！@#￥%……& amp;*（）——+|{}【】‘；：”“’。，、？]", "");
            return str;
        }
        return "";
    }

    public String runAoi(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            logger.error("aoi url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request aoi error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runCheckTag(String url, String param) {
        String content = "";
        try {
            logger.error("check tag url:{}", url);
            content = UrlUtil.sendPost(url, param);
            logger.error("content:{}", content);
        } catch (Exception e) {
            logger.error("check tag error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public boolean compareAoinameAndAddress(OperationBottomcorrected o) {
        boolean flag = true;
        String gdaoi_name = o.getGdaoi_name();
        String std_address = o.getStd_address();
        Pattern pattern1 = Pattern.compile("([0-9]){1,4}(-)([0-9]){1,4}([栋/幢/号])");
        Pattern pattern2 = Pattern.compile("(\\d+)");
        if (StringUtils.isNotEmpty(gdaoi_name) && StringUtils.isNotEmpty(std_address)) {
            Matcher matcher1 = pattern1.matcher(gdaoi_name);
            String[] numberList = null;
            List<String> matchStrings = new ArrayList<>();
            if (matcher1.find()) {
                String number = matcher1.group(0);
                number = number.replaceAll("[栋/幢/号]", "");
                numberList = number.split("-");
            }
            Matcher matcher2 = pattern2.matcher(std_address);
            while (matcher2.find()) {
                matchStrings.add(matcher2.group());
            }
            int i = 0;

            if (numberList != null && matchStrings.size() > 0) {
                for (String s : numberList) {
                    if (matchStrings.contains(s)) {
                        i++;
                    }
                }
                if (i == 0) {
                    flag = false;
                }
            } else if (numberList == null || matchStrings.size() == 0) {
                flag = true;
            }
        }
        return flag;
    }

    public boolean processAoinameAndAddress(OperationBottomcorrected o) {
        boolean flag = false;
        String gdaoi_name = o.getGdaoi_name();
        String std_address = o.getStd_address();
        Pattern pattern = Pattern.compile("[A-Za-z0-9]{1,4}(号楼|号院|栋|座|幢|坐|区|期|组)");
        if (StringUtils.isNotEmpty(gdaoi_name) && StringUtils.isNotEmpty(std_address)) {
            Matcher matcher1 = pattern.matcher(gdaoi_name);
            Matcher matcher2 = pattern.matcher(std_address);
            String group1 = "";
            String group2 = "";
            if (matcher1.find()) {
                group1 = matcher1.group(0);
            }
            if (matcher2.find()) {
                group2 = matcher2.group(0);
            }
            if (StringUtils.isNotEmpty(group1) && StringUtils.isNotEmpty(group2) && group1.equals(group2)) {
                flag = true;
            } else if (StringUtils.isEmpty(group1) || StringUtils.isEmpty(group2)) {
                flag = true;
            }

        }
        return flag;
    }

    public String runAddrUpdateAoi(String url, String param) {
        String content = "";
        try {
            logger.error("addr update aoi url:{}", url);
            content = UrlUtil.sendPost(url, param);
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public void saveData(SparkSession spark, JavaRDD<OperationBottomcorrected> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCity_code(), o.getReq_addresseeaddr(), o.getFinalzc(), o.getGis_to_sys_groupid(), o.getGj_aoiid_t(),
                    o.getStd_address(), o.getKeyword(), o.getAoiId(), o.getAdcode(), o.getZnoCode(), o.getGd_name(), o.getGd_address(), o.getLocation(), o.getGdaoi_id(), o.getGdaoi_name(), o.getGdaoi_zc(),
                    o.getCms_aoiname()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"city_code", "req_addresseeaddr", "finalzc", "gis_to_sys_groupid", "gj_aoiid_t",
                "std_address", "keyword", "aoiId", "adcode", "znoCode",
                "gd_name", "gd_address", "location", "gdaoi_id", "gdaoi_name", "gdaoi_zc", "cms_aoiname"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "mis_judgment_group_correct_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", table, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }


    public static void main(String[] args) {
        MisjudgmentGroupCorrectService service = new MisjudgmentGroupCorrectService();
        OperationBottomcorrected o = new OperationBottomcorrected();
        o.setGdaoi_name("上梅林凯伦花园");
        o.setStd_address("广东省深圳市福田区上梅林凯伦花园");
        System.out.println(service.compareAoinameAndAddress(o));
//        System.out.println(service.processAoinameAndAddress(o));
//        List<String> matchStrings = new ArrayList<>();
//        matchStrings.add("1");
//        matchStrings.add("2");
//        matchStrings.add("3");
//        System.out.println(matchStrings.contains("1"));
    }

}
