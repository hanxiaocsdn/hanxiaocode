package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BtDetail implements Serializable {
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "zc")
    private String zc;
    @Column(name = "emp_no")
    private String empNo;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "aoi_type")
    private String aoiType;
    @Column(name = "center_x")
    private String centerX;
    @Column(name = "center_y")
    private String centerY;
    @Column(name = "tm_tag")
    private String tmTag;
    @Column(name = "dis")
    private String dis;
    @Column(name = "duration")
    private String duration;
    @Column(name = "bt_rate")
    private String btRate;
    @Column(name = "opcode")
    private String opcode;
    @Column(name = "opname")
    private String opname;
    @Column(name = "op_time")
    private String opTime;
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "inc_day")
    private String incDay;

    private String empWbCount;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getEmpNo() {
        return empNo;
    }

    public void setEmpNo(String empNo) {
        this.empNo = empNo;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getAoiType() {
        return aoiType;
    }

    public void setAoiType(String aoiType) {
        this.aoiType = aoiType;
    }

    public String getCenterX() {
        return centerX;
    }

    public void setCenterX(String centerX) {
        this.centerX = centerX;
    }

    public String getCenterY() {
        return centerY;
    }

    public void setCenterY(String centerY) {
        this.centerY = centerY;
    }

    public String getTmTag() {
        return tmTag;
    }

    public void setTmTag(String tmTag) {
        this.tmTag = tmTag;
    }

    public String getDis() {
        return dis;
    }

    public void setDis(String dis) {
        this.dis = dis;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getBtRate() {
        return btRate;
    }

    public void setBtRate(String btRate) {
        this.btRate = btRate;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    public String getOpname() {
        return opname;
    }

    public void setOpname(String opname) {
        this.opname = opname;
    }

    public String getOpTime() {
        return opTime;
    }

    public void setOpTime(String opTime) {
        this.opTime = opTime;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getEmpWbCount() {
        return empWbCount;
    }

    public void setEmpWbCount(String empWbCount) {
        this.empWbCount = empWbCount;
    }

    @Override
    public String toString() {
        return "Bt{" +
                "cityCode='" + cityCode + '\'' +
                ", zc='" + zc + '\'' +
                ", empNo='" + empNo + '\'' +
                ", x='" + x + '\'' +
                ", y='" + y + '\'' +
                ", aoi='" + aoi + '\'' +
                ", aoiType='" + aoiType + '\'' +
                ", centerX='" + centerX + '\'' +
                ", centerY='" + centerY + '\'' +
                ", tmTag='" + tmTag + '\'' +
                ", dis='" + dis + '\'' +
                ", duration='" + duration + '\'' +
                ", btRate='" + btRate + '\'' +
                ", opcode='" + opcode + '\'' +
                ", opname='" + opname + '\'' +
                ", opTime='" + opTime + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", incDay='" + incDay + '\'' +
                ", empWbCount='" + empWbCount + '\'' +
                '}';
    }
}
