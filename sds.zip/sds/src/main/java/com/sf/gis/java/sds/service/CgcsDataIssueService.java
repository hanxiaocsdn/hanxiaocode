package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrong2ReviewSuc;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.pojo.CghsResultData;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CgcsDataIssueService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(CgcsDataIssueService.class);

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadWeekStat(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.aoi_real_acctury_rate_judge_wrong_operation_week_stat where operate_date = '%s'", date);
        logger.error("aoi_real_acctury_rate_judge_wrong_operation_week_stat sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrong2ReviewSuc> loadWaybillNo(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select * from dm_gis.aoi_real_acctury_rate_judge_wrong_2_review_suc where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("aoi_real_acctury_rate_judge_wrong_2_review_suc sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrong2ReviewSuc.class);
    }

    public JavaRDD<CghsResultData> loadCghsResultData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.cghs_result_data where inc_day = '%s' and state = 1 and check_data_type in ('3','4','6','7','8') and source in ('chkn_WRONG_AOI_PN', 'norm_WRONG_AOI_PN', 'norm_WRONG_AOI_SAME')", date);
        logger.error("cghs_result_data sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CghsResultData.class);
    }

    public JavaRDD<CghsResultData> loadCghsResultBlackData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select address from dm_gis.cgcss_misclassification_data_shunt_black";
        logger.error("cgcss_misclassification_data_shunt_black sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CghsResultData.class);
    }

    public void saveBlackData(SparkSession spark, JavaRDD<CghsResultData> inRdd, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getRegion(), o.getCity(), o.getCheck_date_day(), o.getCheck_date_week(), o.getCheck_date_month(), o.getCheck_date_quarter(), o.getCheck_date_year(), o.getId() + "",
                    o.getCity_code(), o.getSch_code(), o.getAoi_code(),o.getAoi_name(), o.getSys_code(), o.getAddress(), o.getAddress_md5(), o.getWaybill_no(), o.getCreate_date(),
                    o.getState() + "", o.getGid(), o.getCheck_x() + "", o.getCheck_y() + "", o.getCheck_dept_code(), o.getCheck_sch_code(), o.getCheck_aoi_code(), o.getCheck_aoi_name(), o.getCheck_aoi_id(),
                    o.getCheck_data_type(), o.getCheck_date(), o.getCheck_by(), o.getDel_flag() + "", o.getDel_date(), o.getDept_type(), o.getIs_encrypt() + "", o.getProvince(), o.getZno_code(), o.getCity_origin(),
                    o.getCounty(), o.getSource(), o.getCms_check_state() + "", o.getDone_state() + "", o.getData_time(), o.getEmp_id(), o.getGis_sch_code(), o.getGis_aoi_code(), o.getBatch_no(), o.getOrigin_id(),
                    o.getOld_team_id(), o.getNew_team_id(), o.getFlag(), o.getTask_source(), o.getInc_day(), o.getFreq() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "region", "city", "check_date_day", "check_date_week", "check_date_month", "check_date_quarter","check_date_year", "id","city_code","sch_code",
                "aoi_code", "aoi_name", "sys_code", "address", "address_md5", "waybill_no","create_date", "state","gid","check_x",
                "check_y", "check_dept_code", "check_sch_code", "check_aoi_code", "check_aoi_name", "check_aoi_id","check_data_type", "check_date","check_by","del_flag",
                "del_date", "dept_type", "is_encrypt", "province", "zno_code", "city_origin","county", "source","cms_check_state","done_state",
                "data_time", "emp_id", "gis_sch_code", "gis_aoi_code", "batch_no", "origin_id", "old_team_id", "new_team_id","flag", "task_source","inc_day","freq"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cgcss_misclassification_data_shunt_black_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadRateJudgeWrongData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select address from dm_gis.cgcss_misclassification_data_shunt where operate_date between '%s' and '%s' ", startDate, endDate);
        logger.error("cgcss_misclassification_data_shunt sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }


    public String runGetCmsAoi(String urlPattern, String cityCode, String addressId) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, cityCode, addressId);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request cms error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> processCms(String getAddrByCityCodeAndAddrUrl, JavaRDD<AoiRealAccturyRateJudgeWrongOperation> initRdd) {
        initRdd = initRdd.map(o -> {
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                String content = runGetCmsAoi(getAddrByCityCodeAndAddrUrl, city_code, gis_to_sys_groupid);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if (data != null) {
                                String address = data.getString("address");
                                String aoiId = data.getString("aoiId");
                                String adcode = data.getString("adcode");

                                o.setCms_address(address);
                                o.setOld_cms_aoiid(aoiId);
                                o.setCms_adcode(adcode);
                            }
                        }
                    }
                }
            }
            return o;
        }).filter(o -> !StringUtils.equals(o.getCms_adcode(), "1"));
        return initRdd;
    }

    public String runHp(String urlPattern, String cityCode, String id, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, cityCode, id);
            logger.error("hp url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runCompany(String urlPattern, String p, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(p, "UTF-8"));
            logger.error("company url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public boolean judgeAddr(String addr) {
        boolean flag = true;
        if (StringUtils.isNotEmpty(addr)) {
            if (addr.endsWith("村") || addr.endsWith("镇") || addr.endsWith("工业园") || addr.endsWith("产业园") || addr.endsWith("创业园") || addr.endsWith("工业区")
                    || addr.endsWith("工业园区") || addr.endsWith("创新区")) {
                flag = false;
            }
        }
        return flag;
    }

    public void saveData(SparkSession spark, JavaRDD<AoiRealAccturyRateJudgeWrongOperation> inRdd, String date, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCity_code(), o.getOrg_code(), o.getGis_to_sys_groupid(), o.getGisaoisrc(), o.getAddress(), o.getFinalaoicode(),
                    o.getFinalaoiid(), o.getOld_cms_aoiid(), o.getGj_aoiid_t(), o.getGj_aoiid_t(), o.getGj_aoiname_t(), o.getMapa_aoiid(),
                    o.getMapa_aoicode(), o.getMapa_aoiname(), o.getR_aoi(), o.getGd_aoiid(), o.getGd_aoicode(), o.getGd_aoiname(),
                    o.getAoi_80_code(), o.getAoi_80_name(), o.getKey_word(), o.getKey_tag(), o.getTag1(), o.getTag2(),
                    o.getTag3(), o.getGroup_freq(), o.getAddress_freq(), o.getGuid(), o.getLabel(), o.getRight_percent(), o.getInc_day(), o.getCms_adcode()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "city_code", "org_code", "gis_to_sys_groupid", "gisaoisrc", "address", "finalaoicode",
                "finalaoiid", "old_cms_aoiid", "gj_aoiid_t", "gj_aoicode_t", "gj_aoiname_t", "mapa_aoiid",
                "mapa_aoicode", "mapa_aoiname", "r_aoi", "gd_aoiid", "gd_aoicode", "gd_aoiname",
                "80_aoi_code", "80_aoi_name", "key_word", "key_tag", "tag1", "tag2",
                "tag3", "group_freq", "address_freq", "guid", "label", "right_percent", "inc_day", "adcode"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cgcss_misclassification_data_shunt_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(operate_date = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
