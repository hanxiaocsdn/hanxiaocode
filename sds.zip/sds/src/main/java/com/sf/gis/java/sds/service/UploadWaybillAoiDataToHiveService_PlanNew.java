package com.sf.gis.java.sds.service;


import com.csvreader.CsvReader;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.ShellExcutor;
import com.sf.gis.java.sds.bean.FtpClient;
import com.sf.gis.java.sds.bean.HookTableInfo;
import com.sf.gis.java.sds.db.GisRdsDbManager;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.enumtype.HookCalDimen;
import com.sf.gis.java.sds.enumtype.MapType;
import com.sf.gis.java.sds.pojo.AoiHook;
import com.sf.gis.java.sds.pojo.AreaInfo;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.Serializable;
import java.net.SocketException;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.util.*;

/**
 * 此版本为预上线版本,目前挂接文件都是单文件上传
 * 单个数据量太大
 * 上传容易卡住，这个版本为切片后的版本 需要测试,配合服务器数据端一起(服务器处理已测试)
 * 暂未启用，先注释，勿删
 */
public class UploadWaybillAoiDataToHiveService_PlanNew implements Serializable {
//    private static final Logger logger = LoggerFactory.getLogger(UploadWaybillAoiDataToHiveService_PlanNew.class);
//
//    /**
//     * 临时类型
//     *
//     * @author 01374443
//     */
//    enum AoiSaveType {
//        withoutType, withType
//    }
//
//    /**
//     *
//     */
//    private static final long serialVersionUID = 8028863965782523787L;
//    private SparkSession sparkSession;
//    private String TT_WAYBILL_INFO = "dm_gis.tt_waybill_info";
//    private String HDFS_HOOK_AOI_RSLT = "hdfs://sfbdp1/user/hive/warehouse/dm_gis.db/aoi_hook_waybill_rslt_";
//    private String HOOK_AOI_RSLT_TABLE = "dm_gis.aoi_hook_waybill_rslt_";
//    public static String TT_WAYBILL_AOI_INFO = "dm_gis.tt_waybill_hook";
//    public static String TT_ORDER_AOI_INFO = "dm_gis.tt_order_hook";
//    private String TT_ORDER_INFO = "gdl.tt_order_info";
//    private String RDS_OMS_FROM = "dm_gis.gis_rds_omsfrom";
//    private String TT_FEE = "dm_bdp_datamining.tt_waybill_fee_mo_discou";
//    private String[] aoi_columns_pai = new String[]{"aoi_id", "aoi_name", "aoi_alias", "aoi_address", "aoi_x",
//            "aoi_y", "hook_src", "aoi_type_code", "aoi_type_name", "aoi_code", "aoi_zc"};
//    private String[] aoi_columns_shou = new String[]{"aoi_id", "aoi_name", "aoi_alias", "aoi_address", "aoi_x",
//            "aoi_y", "aoi_code", "hook_src", "aoi_type_code", "aoi_type_name", "aoi_zc"};
//    @SuppressWarnings("unused")
//    private String[] aoi_columns_with_type = new String[]{"aoi_id", "aoi_name", "aoi_alias", "aoi_address", "aoi_x",
//            "aoi_y", "aoi_type_code", "aoi_type_name", "aoi_code"};
//    private String[] tt_order_column = new String[]{"order_type_code", "call_needflg", "src_sys_type",
//            "is_sch_order"};
//    private String[] gis_rds_omsfrom_column = new String[]{"call_needflg_gis"};
//    private String[] tt_fee_column = new String[]{"all_fee", "cod_fee", "tean_fee", "rebate_amt", "baojia_fee",
//            "zh_all_fee", "freight_rmb", "baozhuang_fee", "property_value", "zh_freight_rmb", "all_service_fee",
//            "other_service_fee", "zh_all_service_fee"};
//    private List<String> array_columns = Arrays
//            .asList(new String[]{"service_prod_code", "cons_name", "cons_category"});
//    private String[] waybill_shou_origin_columns = new String[]{"waybill_id", "waybill_no", "source_zone_code",
//            "src_dist_code", "src_city_code", "src_county", "src_division_code", "src_area_code", "src_hq_code",
//            "src_type_code", "src_lgt", "src_lat", "meterage_weight_qty", "real_weight_qty", "consignee_emp_code",
//            "consigned_tm", "cargo_type_code", "limit_type_code", "express_type_code", "ackbill_type_code",
//            "waybill_type", "order_no", "contacts_id", "consignor_comp_name", "consignor_addr", "consignor_phone",
//            "consignor_cont_name", "consignor_mobile", "consignor_addr_native", "freight_monthly_acct_code",
//            "freight_payment_type_code", "freight_payment_dept_code", "cod_monthly_acct_code", "all_fee", "all_fee_rmb",
//            "freight", "freight_rmb", "consignor_post_code", "service_prod_code", "is_value_insured", "cons_name",
//            "cvs_code", "signed_back_waybill_no", "source_waybill_no", "goods_deal_type", "inner_parcel_flag",
//            "self_send_flag", "self_pickup_flag", "transfer_parcel_flag", "order_id", "order_type", "order_tm",
//            "source_unit_code", "recv_bar_tm", "consign_lgt", "consign_lat", "load_tm", "pay_cust_type",
//            "consignor_cust_type", "recv_bar_dept_code", "waybill_source_type", "real_monthly_acct_code",
//            "real_product_code", "real_all_fee", "real_cod_fee_rmb", "cons_category", "src_province"};
//    private String[] waybill_shou_origin_extends = new String[]{"consign_ac", "consign_xy_dept", "consign_xy_aoiid"};
//    private String[] waybill_pai_origin_columns = new String[]{"waybill_id", "waybill_no", "dest_zone_code",
//            "dest_dist_code", "dest_city_code", "dest_county", "dest_division_code", "dest_area_code", "dest_hq_code",
//            "dest_type_code", "dest_lgt", "dest_lat", "meterage_weight_qty", "real_weight_qty", "deliver_emp_code",
//            "signer_name", "signin_tm", "cargo_type_code", "limit_type_code", "express_type_code", "ackbill_type_code",
//            "waybill_type", "order_no", "consignee_comp_name", "consignee_addr", "consignee_phone",
//            "consignee_cont_name", "consignee_mobile", "consignee_addr_native", "freight_monthly_acct_code",
//            "freight_payment_type_code", "freight_payment_dept_code", "cod_monthly_acct_code", "all_fee", "all_fee_rmb",
//            "freight", "freight_rmb", "consignee_post_code", "service_prod_code", "is_value_insured", "cons_name",
//            "receipt_cvs_code", "signed_back_waybill_no", "source_waybill_no", "goods_deal_type", "inner_parcel_flag",
//            "self_send_flag", "self_pickup_flag", "transfer_parcel_flag", "order_id", "dest_unit_code",
//            "change_addr_flag", "delivery_lgt", "delivery_lat", "waybill_status", "load_tm", "pay_cust_type",
//            "send_bar_dept_code", "first_loading_dept_code", "last_unloading_dept_code", "waybill_source_type",
//            "real_monthly_acct_code", "real_product_code", "real_all_fee", "real_cod_fee_rmb", "cons_category",
//            "dest_province"};
//    private String[] waybill_pai_origin_extends = new String[]{"delivery_ac", "delivery_xy_dept", "delivery_xy_aoiid"};
//
//    public static String aoi_hook_state_table = "dm_gis.aoi_hook_t_3_";
//    // 加密包
//    // private static String encrypt_jar_path =
//    // "hdfs:///tmp/udf/01374443/MyEncrypt-0.0.1.jar";
//    // private static String encrypt_key = "aoi@aoi";
//
//    public UploadWaybillAoiDataToHiveService_PlanNew() {
//        sparkSession = Spark.getSparkSession(UploadWaybillAoiDataToHiveService_PlanNew.class.getSimpleName(), null, false, 2);
//    }
//
//    public String[] pushToHive(Map<String, String> configMap, String ftpFileName) throws Exception {
//        FtpClient ftpClient = creattFtpClient(configMap, ftpFileName);
//        File localDir = downLoadFtpFile(ftpClient);
//        String[] info = parseIncDay(localDir,ftpClient.getFtpFileName()+".aa");
//        logger.error("删除分区");
//        sparkSession.sql("ALTER TABLE " + HOOK_AOI_RSLT_TABLE + info[1] + " DROP IF EXISTS PARTITION (inc_day='"
//                + info[0] + "')");
//        logger.error("新建分区");
//        sparkSession.sql("ALTER TABLE " + HOOK_AOI_RSLT_TABLE + info[1] + " add if not exists partition(inc_day='"
//                + info[0] + "')");
//        logger.error("put hdfs");
//        ShellExcutor.exeCmd("sed -i '1d' " + localDir.getAbsolutePath()+ "/"+ ftpClient.getFtpFileName()+".aa"
//                + " &&  hdfs dfs -put "
//                + localDir.getAbsolutePath()+"/"+ftpClient.getFtpFileName()+".a*" + " " + HDFS_HOOK_AOI_RSLT + info[1] + "/inc_day=" + info[0]
//                + " && rm -f " +localDir.getAbsolutePath()+"/"+ftpClient.getFtpFileName()+".a*" );
////        logger.error("删除临时文件");
////        deleteTmpFile(ftpClient, localFile);
//        saveToResultTable(info);
//        deleteFtpFile(ftpClient);
//        return info;
//    }
//
//    /**
//     * 删除ftp文件
//     *
//     * @param ftpClient
//     * @throws IOException
//     * @throws SocketException
//     */
//    private void deleteFtpFile(FtpClient ftpClient) throws SocketException, IOException {
//        ftpClient.delete(ftpClient.getFtpFilePath(), ftpClient.getFtpFileName() + ".zip");
//    }
//
//    /**
//     * 关联宽表获取数据，保存到最终数据库
//     *
//     * @param info
//     * @throws ParseException
//     */
//    public void saveToResultTable(String[] info) throws ParseException {
//
//        // mergeMidTable(info[1], info[0]);
//        String targetTable = TT_WAYBILL_AOI_INFO;
//        if (info[1].equals(MapType.shou.name())) {
//            targetTable = TT_ORDER_AOI_INFO;
//        }
//        String sql = createJoinSql(info[0], info[1], AoiSaveType.withoutType);
//        logger.error("删除分区");
//        sparkSession.sql("ALTER TABLE " + targetTable + " DROP IF EXISTS PARTITION (inc_day='" + info[0] + "')");
//        logger.error("新建分区");
//        sparkSession.sql("ALTER TABLE " + targetTable + " add if not exists partition(inc_day='" + info[0] + "')");
//        logger.error(sql);
//        // sparkSession.sql("add jar " + encrypt_jar_path);
//        // sparkSession
//        // .sql("create function aes_encrypt_aes as 'com.sf.myaes.Aes' using
//        // jar" + " '" + encrypt_jar_path + "'");
//        sparkSession.sql(sql);
//        // if (Integer.valueOf(info[0]) >= 20190901 && Integer.valueOf(info[0])
//        // <= 20190930) {
//        // // 插入小区临时表
//        // sql = createJoinSql(info[0], info[1], AoiSaveType.withType);
//        // targetTable = targetTable + "_house";
//        // logger.error("删除分区");
//        // sparkSession.sql("ALTER TABLE " + targetTable + " DROP IF EXISTS
//        // PARTITION (inc_day='" + info[0] + "')");
//        // logger.error("新建分区");
//        // sparkSession.sql("ALTER TABLE " + targetTable + " add if not exists
//        // partition(inc_day='" + info[0] + "')");
//        // logger.error(sql);
//        // sparkSession.sql(sql);
//        // }
//        updateSyncStatus(info[0], info[1]);
//    }
//
//    private void updateSyncStatus(String incDay, String dataType) {
//        String table = aoi_hook_state_table + dataType;
//        logger.error("数据准备好了，写hive标记一下");
//        logger.error("删除分区");
//        sparkSession.sql("ALTER TABLE " + table + " DROP IF EXISTS PARTITION (inc_day='" + incDay + "')");
//        logger.error("新建分区");
//        sparkSession.sql("ALTER TABLE " + table + " add if not exists partition(inc_day='" + incDay + "')");
//        String sql = "insert into " + table + " partition(inc_day = '" + incDay + "') values('1')";
//        logger.error(sql);
//        sparkSession.sql(sql);
//    }
//
//    /**
//     * 创建关联表语句
//     *
//     * @return
//     * @throws ParseException
//     */
//    private String createJoinSql(String inc_day, String dataType, AoiSaveType aoiSaveType) throws ParseException {
//        // 原始数据表字段
//        String[] targetColumns = waybill_pai_origin_columns;
//        String targetTable = TT_WAYBILL_AOI_INFO;
//        String hookTable = HOOK_AOI_RSLT_TABLE + dataType;
//        String[] tmp_aoi_columns = aoi_columns_pai;
//        String[] originExtendColumns = waybill_pai_origin_extends;
//        if (dataType.equals(MapType.shou.name())) {
//            targetColumns = waybill_shou_origin_columns;
//            targetTable = TT_ORDER_AOI_INFO;
//            tmp_aoi_columns = aoi_columns_shou;
//            originExtendColumns = waybill_shou_origin_extends;
//        }
//        // 插入语句
//        StringBuilder sb = new StringBuilder(
//                "insert overwrite table " + targetTable + " partition(inc_day = '" + inc_day + "') select ");
//        for (String column : targetColumns) {
//            if (array_columns.contains(column)) {
//                sb.append(" if(size(a." + column + ") <> 0, a." + column + ", null),");
//            } else {
//                sb.append("a." + column + ",");
//            }
//        }
//
//        // 添加aoi列
//        String aoiColumn = createAoiColumns(tmp_aoi_columns, sb);
//        // 添加tt_order_info列
//        String orderColumn = createTtOrderColumns(dataType, sb);
//        // 添加tt_fee_column列
//        String ttFeeColumn = createTtFeeColumn(sb);
//        sb.append(" if( b.hook_source  is not null, b.hook_source, ''),");
//        sb.append(" if( b.aoi_parent  is not null, b.aoi_parent, ''),");
//        //添加原始表扩展字段
//        for (String column : originExtendColumns) {
//            sb.append("a." + column + ",");
//        }
//        sb.deleteCharAt(sb.length() - 1);
//        // 宽表查询语句
//        String tt_waybill_select_sql = createTtWaybillSelectSql(targetColumns, inc_day, dataType, originExtendColumns);
//        sb.append(" from ( " + tt_waybill_select_sql + " )a left join ( " + "select waybillno," + aoiColumn + " from "
//                + hookTable + " where inc_day='" + inc_day + "'" + ")b on a.waybill_no=b.waybillno ");
//
//        if (dataType.equals(MapType.shou.name())) {
//            // 添加tt_order_info查询语句
//            updateTtOrderInfoSelectSql(inc_day, orderColumn, sb);
//            updateGisRdsOmsFromSelectSql(inc_day, sb);
//        }
//        updateFeeSelectSql(ttFeeColumn, inc_day, sb, dataType);
//        return sb.toString();
//    }
//
//    /**
//     * 更新
//     *
//     * @param ttFeeColumn
//     * @param inc_day
//     * @param sb
//     * @param dataType
//     * @throws ParseException
//     */
//    private void updateFeeSelectSql(String ttFeeColumn, String inc_day, StringBuilder sb, String dataType)
//            throws ParseException {
//        String beginDay = DateUtil.getDayBefore(inc_day, "yyyyMMdd", dataType.equals(MapType.pai.name()) ? 10 : 1);
//        String beginMonth = beginDay.substring(0, beginDay.length() - 2);
//        String endDay = DateUtil.getDayBefore(inc_day, "yyyyMMdd", -1);
//        String endMonth = endDay.substring(0, endDay.length() - 2);
//
//        String fee_sql = " select waybill_no," + ttFeeColumn
//                + ",row_number() over(partition BY waybill_no ORDER BY inc_day desc ) as rank from " + TT_FEE
//                + " where inc_month between '" + beginMonth + "' and '" + endMonth + "' and inc_day between '"
//                + beginDay + "' and '" + endDay + "' ";
//        sb.append("left join ( select * from (" + fee_sql + ") e where e.rank=1 ) f on a.waybill_no=f.waybill_no ");
//    }
//
//    /***
//     * 费用列
//     *
//     * @param sb
//     * @return
//     */
//    private String createTtFeeColumn(StringBuilder sb) {
//        StringBuilder ttFeeColumnBuilder = new StringBuilder();
//        for (String column : tt_fee_column) {
//            sb.append(" if(f." + column + " is not null, f." + column + ", ''),");
//            ttFeeColumnBuilder.append(column + ",");
//        }
//        ttFeeColumnBuilder.deleteCharAt(ttFeeColumnBuilder.length() - 1);
//        return ttFeeColumnBuilder.toString();
//    }
//
//    /***
//     * 更新rds_oms_from查询语句
//     *
//     * @param inc_day
//     * @param sb
//     * @throws ParseException
//     */
//    private void updateGisRdsOmsFromSelectSql(String inc_day, StringBuilder sb) throws ParseException {
//        String beginDay = DateUtil.getDayBefore(inc_day,  "yyyyMMdd",1);
//        String endDay = DateUtil.getDayBefore(inc_day, "yyyyMMdd",-1);
//        String gis_omsfrom_sql = " select distinct(orderno) as orderno from " + RDS_OMS_FROM
//                + " where inc_day between '" + beginDay + "' and '" + endDay
//                + "' and (isnotundercall is null or isnotundercall<>'1') ";
//        sb.append(" left join (" + gis_omsfrom_sql + ") d on a.order_no=d.orderno ");
//    }
//
//    /**
//     * 更新tt_order_info查询语句
//     *
//     * @param inc_day
//     * @param orderColumn
//     * @param sb
//     * @throws ParseException
//     */
//    private void updateTtOrderInfoSelectSql(String inc_day, String orderColumn, StringBuilder sb)
//            throws ParseException {
//        String preDay = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1);
//        String inc_days = preDay + "','" + inc_day;
//
//        String tt_order_info_sql = "select inner_order_no," + orderColumn
//                + ",row_number() over(partition BY inner_order_no ORDER BY inc_day) as rank from " + TT_ORDER_INFO
//                + " where inc_day in ('" + inc_days + "') ";
//        sb.append("left join ( select * from (" + tt_order_info_sql
//                + ") d where d.rank=1 ) c on a.order_no=c.inner_order_no ");
//    }
//
//    /**
//     * 创建宽表查询语句
//     *
//     * @param targetColumns
//     * @param inc_day
//     * @param dataType
//     * @return
//     * @throws ParseException
//     */
//    private String createTtWaybillSelectSql(String[] targetColumns, String inc_day, String dataType,
//                                            String[] originExtendColumns)
//            throws ParseException {
//        StringBuffer selectWayPaiBuffer = new StringBuffer(" select ");
//        for (String column : targetColumns) {
//            selectWayPaiBuffer.append(column + ",");
//        }
//        for (String column : originExtendColumns) {
//            selectWayPaiBuffer.append(column + ",");
//        }
//        selectWayPaiBuffer.deleteCharAt(selectWayPaiBuffer.length() - 1);
//        if (dataType.equals(MapType.shou.name())) {
//            selectWayPaiBuffer.append(" from " + TT_WAYBILL_INFO + " where inc_day='" + inc_day + "' ");
//        } else {
//            String inc_day_begin = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 14);
//            String inc_day_end = inc_day;
//            String signin_tm = DateUtil.getDayBefore(inc_day, 0, "yyyyMMdd", "yyyy-MM-dd");
//            selectWayPaiBuffer.append(" from " + TT_WAYBILL_INFO + " where inc_day between '" + inc_day_begin
//                    + "' and '" + inc_day_end + "' and signin_tm like '" + signin_tm + "%'");
//        }
//
//        return selectWayPaiBuffer.toString();
//    }
//
//    /**
//     * 生成ttorder列
//     *
//     * @param dataType
//     * @param sb
//     * @return
//     */
//    private String createTtOrderColumns(String dataType, StringBuilder sb) {
//        StringBuilder ttOrderInfoColumnBuilder = new StringBuilder();
//        if (dataType.equals(MapType.shou.name())) {
//            for (String column : tt_order_column) {
//                sb.append(" if(c." + column + " is not null, c." + column + ", ''),");
//                ttOrderInfoColumnBuilder.append(column + ",");
//            }
//            for (@SuppressWarnings("unused")
//                    String column : gis_rds_omsfrom_column) {
//                sb.append(" if(d.orderno is not null, '1' ,'0'),");
//            }
//            ttOrderInfoColumnBuilder.deleteCharAt(ttOrderInfoColumnBuilder.length() - 1);
//        }
//        return ttOrderInfoColumnBuilder.toString();
//    }
//
//    /**
//     * 合并aoi列
//     *
//     * @param sb
//     * @param tmp_aoi_columns
//     * @return
//     */
//    private String createAoiColumns(String[] tmp_aoi_columns, StringBuilder sb) {
//        StringBuilder aoiColumnBuilder = new StringBuilder();
//        for (String column : tmp_aoi_columns) {
//            sb.append(" if(b." + column + " is not null, b." + column + ", ''),");
//            String mid_column = column;
//            if (column.equals("aoi_zc")) {
//                mid_column = "zno_code aoi_zc";
//            }
//            aoiColumnBuilder.append(mid_column + ",");
//        }
//        aoiColumnBuilder.append("hook_source,");
//        aoiColumnBuilder.append("aoi_parent,");
//        aoiColumnBuilder.deleteCharAt(aoiColumnBuilder.length() - 1);
//        return aoiColumnBuilder.toString();
//    }
//
//    private void deleteTmpFile(FtpClient ftpClient, File localFile) {
//        localFile.delete();
//    }
//
//    /**
//     * 解析第一条数据，得出日期和收派类型
//     *
//     * @param localFile
//     * @return
//     * @throws IOException
//     */
//    private String[] parseIncDay(File localFile,String fileName) throws IOException {
//        CsvReader reader = new CsvReader(localFile.getAbsolutePath()+"/"+fileName, ',', Charset.forName("utf-8"));
//        reader.readRecord();
//        String[] headers = reader.getValues();
//        reader.readRecord();
//        String[] data = reader.getValues();
//        String incDay = "";
//        String dataType = "";
//        for (int i = 0; i < headers.length; i++) {
//            if (headers[i].equals("data_time")) {
//                incDay = data[i];
//            } else if (headers[i].equals("data_type")) {
//                dataType = data[i];
//                if (dataType.equals("B")) {
//                    dataType = MapType.pai.name();
//                } else {
//                    dataType = MapType.shou.name();
//                }
//            }
//
//        }
//        logger.error("日期：" + incDay);
//        logger.error("数据类型：" + dataType);
//        return new String[]{incDay, dataType};
//    }
//
//    /**
//     * 下载ftp文件
//     *
//     * @throws Exception
//     */
//    private File downLoadFtpFile(FtpClient ftpClient) throws Exception {
//
//        File zipFile = new File(ftpClient.getFtpFileName() + ".zip");
//        if (zipFile.exists()) {
//            zipFile.delete();
//        }
//        logger.error("开始下载ftp文件：" + ftpClient.getFtpFilePath() + "," + ftpClient.getFtpFileName() + ".zip");
//        ftpClient.downloadFile(ftpClient.getFtpFilePath(), ".", ftpClient.getFtpFileName() + ".zip");
////        File csvFile = new File(ftpClient.getFtpFileName() + ".csv");
////        if (csvFile.exists()) {
////            csvFile.delete();
////        }
//        logger.error("开始解压zip文件：" + zipFile.getAbsolutePath());
//        ShellExcutor.exeCmd("unzip -o " + zipFile);
//        // ZipCompress.unZip(zipFile, ".");
//        zipFile.delete();
//        File curDir = new File(".");
//        File[] targetFiles = curDir.listFiles(new FilenameFilter() {
//            @Override
//            public boolean accept(File dir, String name) {
//                if(name.startsWith(ftpClient.getFtpFileName()+".a")){
//                    return true;
//                }
//                return false;
//            }
//        });
//        logger.error("文件数量:"+targetFiles.length);
//        for(File file :targetFiles){
//            logger.error(file.getAbsolutePath());
//        }
//        return curDir;
//    }
//
//    /**
//     * 创建ftp客户端
//     *
//     * @param configMap
//     * @param inc_day
//     * @return
//     */
//    private FtpClient creattFtpClient(Map<String, String> configMap, String ftpFileName) {
//        String ftpPath = configMap.get(ConfigKey.sshPath.name());
//        // String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
//        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
//                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));
//
//        ftpClient.setFtpFilePath(ftpPath);
//        ftpClient.setFtpFileName(ftpFileName);
//        return ftpClient;
//    }
//
//    /**
//     * 统计挂接状况
//     *
//     * @param incDay:  日期
//     * @param mapType: 收派类型
//     */
//    public List<AoiHook> calHookInfo(String incDay, String mapType, String cityCodes) {
//        HookTableInfo tableInfo = findHookTableInfo(mapType);
//        JavaRDD<AoiHook> rdd = fetchDataFromHive(incDay, mapType, tableInfo, cityCodes);
//        List<AoiHook> rslt = new ArrayList<>();
//        JavaRDD<AoiHook> zcRdd = calHookInfoByDimen(rdd, HookCalDimen.zc, mapType);
//        logger.error("网点维度数量:" + zcRdd.count());
//        // rslt.addAll(zcRdd.collect());
//        JavaRDD<AoiHook> cityRdd = calHookInfoByDimen(zcRdd, HookCalDimen.cityCode, mapType);
//        logger.error("城市维度数量:" + cityRdd.count());
//        rslt.addAll(cityRdd.collect());
//        JavaRDD<AoiHook> regionRdd = calHookInfoByDimen(cityRdd, HookCalDimen.region, mapType);
//        logger.error("大区维度数量:" + regionRdd.count());
//        rslt.addAll(regionRdd.collect());
//        JavaRDD<AoiHook> dateRdd = calHookInfoByDimen(regionRdd, HookCalDimen.date, mapType);
//        logger.error("日期维度数量:" + dateRdd.count());
//        rslt.addAll(dateRdd.collect());
//        return rslt;
//    }
//
//    /**
//     * 转换收派件类型参数
//     *
//     * @param mapType
//     * @return
//     */
//    public String convertDataType(String mapType) {
//        String tmpDataType = null;
//        if (mapType.equals(MapType.pai.name())) {
//            tmpDataType = "DLV";
//        } else if (mapType.equals(MapType.shou.name())) {
//            tmpDataType = "PU";
//        }
//        return tmpDataType;
//    }
//
//    /**
//     * 获取各维度的rdd数据
//     *
//     * @param rdd
//     */
//    public JavaRDD<AoiHook> calHookInfoByDimen(JavaRDD<AoiHook> rdd, HookCalDimen dimen, String mapType) {
//
//        final String dataType = convertDataType(mapType);
//        JavaRDD<AoiHook> pairRdd = null;
//        if (HookCalDimen.zc.equals(dimen)) {
//            pairRdd = rdd.map(obj -> {
//                obj.setDataType(dataType);
//                obj.setStatType("ZC");
//                obj.setStatTypeContent(obj.getZonecode());
//                obj.createId();
//                return obj;
//            });
//        } else if (HookCalDimen.cityCode.equals(dimen)) {
//            pairRdd = rdd.map(obj -> {
//                obj.setZonecode("ALL");
//                obj.setDataType(dataType);
//                obj.setStatType("CITY");
//                obj.setStatTypeContent(obj.getCityCode());
//                obj.createId();
//                return obj;
//            });
//        } else if (HookCalDimen.region.equals(dimen)) {
//            pairRdd = rdd.map(obj -> {
//                obj.setCityCode("ALL");
//                obj.setZonecode("ALL");
//                obj.setDataType(dataType);
//                obj.setStatType("REGION");
//                obj.setStatTypeContent(obj.getRegion());
//                obj.createId();
//                return obj;
//            });
//        } else if (HookCalDimen.date.equals(dimen)) {
//            pairRdd = rdd.filter(obj -> !"".equals(obj.getCityCode()) && !"852".equals(obj.getCityCode())
//                    && !"886".equals(obj.getCityCode()) && !"853".equals(obj.getCityCode())).map(obj -> {
//                obj.setRegion("ALL");
//                obj.setCityCode("ALL");
//                obj.setZonecode("ALL");
//                obj.setDataType(dataType);
//                obj.setStatType("ALL");
//                obj.setStatTypeContent("ALL");
//                obj.createId();
//                return obj;
//            });
//        }
//
//        return pairRdd.mapToPair(obj -> new Tuple2<String, AoiHook>(obj.getId(), obj))
//                .reduceByKey((obj1, obj2) -> mergeHookRsltCallInfo(obj1, obj2)).values().map(obj -> {
//                    obj.md5Id();
//                    return obj;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//    }
//
//    /**
//     * 合并挂接信息
//     *
//     * @param obj1
//     * @param obj2
//     * @return
//     */
//    private AoiHook mergeHookRsltCallInfo(AoiHook obj1, AoiHook obj2) {
//        obj1.update(obj2);
//        return obj1;
//    }
//
//    /**
//     * 获取大区信息
//     *
//     * @return
//     */
//    private Map<String, List<AreaInfo>> fecthCityInfo() {
//        List<AreaInfo> areaInfo = GisRdsDbManager.getInstance().queryAreaInfo();
//        Map<String, List<AreaInfo>> rsltMap = new HashMap<>();
//        for (AreaInfo item : areaInfo) {
//            if (rsltMap.containsKey(item.getCitycode())) {
//                rsltMap.get(item.getCitycode()).add(item);
//            } else {
//                List<AreaInfo> tmpList = new ArrayList<>();
//                tmpList.add(item);
//                rsltMap.put(item.getCitycode(), tmpList);
//            }
//        }
//        return rsltMap;
//    }
//
//    /**
//     * 获取zc维度的rdd
//     *
//     * @param incDay
//     * @param mapType
//     * @param tableInfoMap
//     * @return
//     */
//    @SuppressWarnings("resource")
//    private JavaRDD<AoiHook> fetchDataFromHive(String incDay, String mapType, HookTableInfo tableInfo,
//                                               String cityCodes) {
//        Map<String, List<AreaInfo>> areaInfoMap = fecthCityInfo();
//        logger.error("城市代码数量:" + areaInfoMap.size());
//        Broadcast<Map<String, List<AreaInfo>>> areaBroadcast = new JavaSparkContext(sparkSession.sparkContext())
//                .broadcast(areaInfoMap);
//        String sql = "select 1, if(aoi_id<>'',1,0),if(aoi_id<>'',if(aoi_type_code<>'',1,0),0)," + tableInfo.cityColumn
//                + "," + tableInfo.zcColumn + " from " + tableInfo.tableName + " where inc_day='" + incDay + "' and "
//                + tableInfo.cityColumn + " in ('" + cityCodes + "')";
//        JavaRDD<AoiHook> rdd = sparkSession.sql(sql).javaRDD()
//                .map(row -> calHookRsltCalInfo(row, areaBroadcast.value(), incDay))
//                .persist(StorageLevel.MEMORY_AND_DISK_SER());
//
//        return rdd;
//    }
//
//    /**
//     * 生成hook结果
//     *
//     * @param row
//     * @param areaInfo
//     * @param date
//     * @return
//     */
//    private AoiHook calHookRsltCalInfo(Row row, Map<String, List<AreaInfo>> areaInfo, String date) {
//        int totalFlag = row.getInt(0);
//        int hookAoiFlag = row.getInt(1);
//        int hookAoiTypeCodeFlag = row.getInt(2);
//        String cityCode = row.getString(3);
//        String zc = row.getString(4);
//        String region = "-";
//        if (areaInfo.containsKey(cityCode)) {
//            List<AreaInfo> areaInfoList = areaInfo.get(cityCode);
//            region = areaInfoList.get(0).getRegion();
//        }
//        return new AoiHook(null, null, null, null, date, region, cityCode, zc, totalFlag, hookAoiFlag,
//                hookAoiTypeCodeFlag);
//    }
//
//    /**
//     * 获取挂接表信息
//     *
//     * @param mapType
//     * @return
//     */
//    private HookTableInfo findHookTableInfo(String mapType) {
//        if (mapType.equals(MapType.pai.name())) {
//            return new HookTableInfo(TT_WAYBILL_AOI_INFO, "dest_dist_code", "aoi_zc", "consignee_addr");
//        } else if (mapType.equals(MapType.shou.name())) {
//            return new HookTableInfo(TT_ORDER_AOI_INFO, "src_dist_code", "aoi_zc", "consignor_addr");
//        }
//        return null;
//    }

}