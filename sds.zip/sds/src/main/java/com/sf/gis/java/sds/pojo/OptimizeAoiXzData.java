package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class OptimizeAoiXzData implements Serializable {
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoitowninterinfo_resp")
    private String aoitowninterinfo_resp;
    @Column(name = "area_max")
    private String area_max;
    @Column(name = "town")
    private String town;
    @Column(name = "shortest_dist")
    private String shortest_dist;
    @Column(name = "geotype")
    private String geotype;

    @Column(name = "l45_waybill")
    private String l45_waybill;
    @Column(name = "freq45_waybill")
    private String freq45_waybill;

    @Column(name = "finalprovince")
    private String finalprovince;
    @Column(name = "finalcity")
    private String finalcity;
    @Column(name = "finalcounty")
    private String finalcounty;
    @Column(name = "l5_norm")
    private String l5_norm;
    @Column(name = "freq5_norm")
    private String freq5_norm;

    @Column(name = "finaltown")
    private String finaltown;
    @Column(name = "tag")
    private String tag;

    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "inc_day")
    private String inc_day;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getFinalprovince() {
        return finalprovince;
    }

    public void setFinalprovince(String finalprovince) {
        this.finalprovince = finalprovince;
    }

    public String getFinalcity() {
        return finalcity;
    }

    public void setFinalcity(String finalcity) {
        this.finalcity = finalcity;
    }

    public String getFinalcounty() {
        return finalcounty;
    }

    public void setFinalcounty(String finalcounty) {
        this.finalcounty = finalcounty;
    }

    public String getFinaltown() {
        return finaltown;
    }

    public void setFinaltown(String finaltown) {
        this.finaltown = finaltown;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getL5_norm() {
        return l5_norm;
    }

    public void setL5_norm(String l5_norm) {
        this.l5_norm = l5_norm;
    }

    public String getFreq5_norm() {
        return freq5_norm;
    }

    public void setFreq5_norm(String freq5_norm) {
        this.freq5_norm = freq5_norm;
    }

    public String getL45_waybill() {
        return l45_waybill;
    }

    public void setL45_waybill(String l45_waybill) {
        this.l45_waybill = l45_waybill;
    }

    public String getFreq45_waybill() {
        return freq45_waybill;
    }

    public void setFreq45_waybill(String freq45_waybill) {
        this.freq45_waybill = freq45_waybill;
    }

    public String getGeotype() {
        return geotype;
    }

    public void setGeotype(String geotype) {
        this.geotype = geotype;
    }

    private boolean success;

    public String getArea_max() {
        return area_max;
    }

    public void setArea_max(String area_max) {
        this.area_max = area_max;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getShortest_dist() {
        return shortest_dist;
    }

    public void setShortest_dist(String shortest_dist) {
        this.shortest_dist = shortest_dist;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getAoitowninterinfo_resp() {
        return aoitowninterinfo_resp;
    }

    public void setAoitowninterinfo_resp(String aoitowninterinfo_resp) {
        this.aoitowninterinfo_resp = aoitowninterinfo_resp;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }
}
