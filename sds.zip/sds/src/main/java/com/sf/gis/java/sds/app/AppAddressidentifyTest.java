package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.sds.pojo.GisRssSegCloudLogCollectStd;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * 任务id：26（新平台测试环境：地址识别测试环境跑数）
 * 业务方：01381101（匡可心）
 * 研发：01399581（匡仁衡）
 */
public class AppAddressidentifyTest {
    private static Logger logger = LoggerFactory.getLogger(AppAddressidentifyTest.class);
    private static String url = "http://gis-int.intsit.sfdc.com.cn:1080/pai/api/addressidentify";
    private static String ak = "663ee55ce37c42b182c17e37e66171a7";

    public static void main(String[] args) {
        SparkSession spark = Spark.getSparkSession("AppAddressidentifyTest", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        JavaRDD<String> lineRdd = sc.textFile("hdfs://node1:8020/tmp/gis_rss_seg_cloud_log_collect_std.csv", 20).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lineRdd cnt:{}", lineRdd.count());
        String head = lineRdd.first();
        logger.error("head:{}", head);
        JavaRDD<GisRssSegCloudLogCollectStd> rdd = lineRdd.filter(o -> !StringUtils.equals(o, head)).map(AppAddressidentifyTest::getField).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        lineRdd.unpersist();
        logger.error("调接口");
        JavaRDD<GisRssSegCloudLogCollectStd> respRdd = api(rdd);

//        String sql = "select * from dm_gis.address_identify_test where inc_day = '20240219'";
//        JavaRDD<GisRssSegCloudLogCollectStd> respRdd = DataUtil.loadData(spark, sc, sql, GisRssSegCloudLogCollectStd.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("respRdd cnt:{}", respRdd.count());

        logger.error("比对");
        JavaRDD<GisRssSegCloudLogCollectStd> resultRdd = compare(respRdd);
        logger.error("存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.address_identify_test", GisRssSegCloudLogCollectStd.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static JavaRDD<GisRssSegCloudLogCollectStd> compare(JavaRDD<GisRssSegCloudLogCollectStd> respRdd) {
        JavaRDD<GisRssSegCloudLogCollectStd> resultRdd = respRdd.map(o -> {
            String personname = o.getPersonname();
            String personname_sit = o.getPersonname_sit();
            String phonenumber_sit = o.getPhonenumber_sit();
            String phonenumber = o.getPhonenumber();
            String addresstext = o.getAddresstext();
            String address = o.getAddress();
            String address_sit = o.getAddress_sit();
            ArrayList<String> list = new ArrayList<>();
            if (StringUtils.isNotEmpty(personname) && StringUtils.isNotEmpty(personname_sit)) {
                if (!StringUtils.equals(personname.replaceAll("\"|\\\\|\\u200B", ""), personname_sit.replaceAll("\"|\\\\|\\u200B", ""))) {
                    list.add("personname");
                }
            }
            if ((StringUtils.isNotEmpty(phonenumber) && StringUtils.isEmpty(phonenumber_sit)) || (StringUtils.isNotEmpty(phonenumber_sit) && !addresstext.replaceAll(" ", "").contains(phonenumber_sit))) {
                list.add("phonenumber");
            }

            if (!StringUtils.equals(address.replaceAll("\\u200B", ""), address_sit.replaceAll("\\u200B", ""))) {
                list.add("address");
            }
            o.setFlag(list.size() > 0 ? String.join("|", list) : "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        respRdd.unpersist();
        return resultRdd;
    }

    public static JavaRDD<GisRssSegCloudLogCollectStd> api(JavaRDD<GisRssSegCloudLogCollectStd> rdd) {
        JavaRDD<GisRssSegCloudLogCollectStd> respRdd = rdd.map(o -> {
            String addresstext = o.getAddresstext();
            if (StringUtils.isNotEmpty(addresstext)) {
                String personname_sit = "";
                String phonenumber_sit = "";
                String address_sit = "";
                String syscode = o.getSyscode();
                JSONObject param = new JSONObject();
                param.put("ak", ak);
                param.put("syscode", syscode);
                param.put("addresstext", URLEncoder.encode(addresstext, "UTF-8"));
                String resp = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", ak, "UTF-8", "UTF-8");
                o.setResp(resp);

                try {
                    personname_sit = JSON.parseObject(resp).getJSONObject("result").getJSONObject("paidata").getString("personName");
                    phonenumber_sit = JSON.parseObject(resp).getJSONObject("result").getJSONObject("paidata").getString("phoneNumber");
                    address_sit = JSON.parseObject(resp).getJSONObject("result").getJSONObject("paidata").getString("address");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                o.setPersonname_sit(personname_sit);
                o.setPhonenumber_sit(phonenumber_sit);
                o.setAddress_sit(address_sit);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("respRdd cnt:{}", respRdd.count());
        rdd.unpersist();
        return respRdd;
    }

    public static GisRssSegCloudLogCollectStd getField(String line) {
        GisRssSegCloudLogCollectStd o = new GisRssSegCloudLogCollectStd();
        String[] split = line.split("\t");

        try {
            o.setAddresstext(split[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setSyscode(split[1]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setAk(split[2]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setPersonname(split[3]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setPhonenumber(split[4]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setAddress(split[5]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setInc_day(split[6]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return o;
    }
}
