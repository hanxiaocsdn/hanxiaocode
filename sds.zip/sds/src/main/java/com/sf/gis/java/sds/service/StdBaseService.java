package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.*;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class StdBaseService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(StdBaseService.class);

    public JavaRDD<TalsGisRdsOmsto> loadRdsOmstoData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("tals_gis_rds_omsto.sql", date, date);
        logger.error("tals_gis_rds_omsto sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TalsGisRdsOmsto.class);
    }

    public JavaRDD<CityNameMap> loadCityNameMap(SparkSession spark, JavaSparkContext sc) {
        String sql = "select province,region,city,citycode,area,adcode from dm_gis.city_name_map where inc_day = '20210317'";
        logger.error("city_name_map sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CityNameMap.class);
    }

    public JavaRDD<CityNameMap> loadCityNameMapNew(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select dist_code citycode,dist_name city,area_name area,region_name region from dm_gis.dim_city_info_df where inc_day = '%s'", date);
        logger.error("city_name_map sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CityNameMap.class);
    }

    public JavaRDD<StDepartment> loadStDepartment(SparkSession spark, JavaSparkContext sc) {
        String sql = "select zno_code,type_code from dm_gis.st_department where zno_code is not null and zno_code <>''";
        logger.error("st_department sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, StDepartment.class);
    }

    public void getCmsDept(SparkSession spark) {
        logger.error("适配代码，生成znocode_departcode_mapping临时表");
        String sql = "select distinct zno_code znocode,depart_code departcode,type_code typecode from dm_gis.st_department ";
        logger.error(sql);
        spark.sql(sql).createOrReplaceTempView("znocode_departcode_mapping");
    }

    public JavaRDD<ZnocodeDepartcodeMapping> loadZnoCodeDepartCode(SparkSession spark, JavaSparkContext sc) {
        getCmsDept(spark);
        String sql = "select * from znocode_departcode_mapping";
        logger.error("znocode_departcode sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ZnocodeDepartcodeMapping.class);
    }

    public String runAtdispatch(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runDepartCode(String urlPattern, String cityCode, String znoCode) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, cityCode, znoCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public JavaRDD<TalsGisRdsOmsto> loadNormTtPai(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.norm_tt_pai1 where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TalsGisRdsOmsto.class);
    }

    public void saveData(SparkSession spark, JavaRDD<TalsGisRdsOmsto> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getReq_waybillno(), o.getReq_destcitycode(), o.getReq_addresseeaddr(), o.getReq_comp_name(), o.getAtdept(),
                    o.getAtdept_src(), o.getGis_to_sys_groupid(), o.getGroupids(), o.getMatchids(), o.getFilters(),
                    o.getKeywords(), o.getDeptcode(), o.getGroupids_chkn(), o.getFilters_chkn(), o.getDept_chkn(),
                    o.getGroupid_chkn(), o.getYs_dept_chkn(), o.getYs_atdept(), o.getYs_deptcode(), o.getRegion(), o.getAoi_chkn(), o.getAtaoi_src(), o.getGisaoicode(), o.getArea(), o.getReq_city(),
                    o.getDept_hp(), o.getAoi_hp(), o.getDept_phone(), o.getAoi_phone(), o.getAt_abnormSrc(),
                    o.getKsdept_src(), o.getKsaoi_src(), o.getDept_ks(), o.getAoi_ks(), o.getResp()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"req_waybillno", "req_destcitycode", "req_addresseeaddr", "req_comp_name", "atdept",
                "atdept_src", "gis_to_sys_groupid", "groupids", "matchids", "filters",
                "keywords", "deptcode", "groupids_chkn", "filters_chkn", "dept_chkn",
                "groupid_chkn", "ys_dept_chkn", "ys_atdept", "ys_deptcode", "region", "aoi_chkn", "ataoi_src", "gisaoicode", "area", "req_city",
                "dept_hp", "aoi_hp", "dept_phone", "aoi_phone", "at_abnormsrc",
                "ksdept_src", "ksaoi_src", "dept_ks", "aoi_ks", "resp"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "norm_tt_pai_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.norm_tt_pai1";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveStatData(SparkSession spark, JavaRDD<StatNormTtPai> inRdd, String table, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getId(), o.getStat_type(), o.getStat_type_content(), o.getStat_date(), o.getArea(), o.getRegion(), o.getCity(), o.getCityCode(),
                    o.getTt_num() + "", o.getChkn_num() + "", o.getOther_num() + "", o.getLog_norm_num() + "", o.getChkn_norm_num() + "", o.getLog_muti_group_num() + "",
                    o.getChkn_muti_group_num() + "", o.getLog_zc_num() + "", o.getLog_zc_num_new() + "", o.getChkn_zc_num() + "", o.getLog_zc_correct_num() + "", o.getLog_zc_correct_num_new() + "",
                    o.getChkn_zc_correct_num() + "", o.getLog_aoi_num() + "", o.getChkn_aoi_num() + "", o.getOther_num_aoi() + "", o.getChkn_num_aoi() + "",
                    o.getHp_zc_num() + "", o.getHp_aoi_num() + "", o.getPhone_zc_num() + "", o.getPhone_aoi_num() + "",
                    o.getKs_zc_num() + "", o.getKs_aoi_num() + ""

            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "id", "stat_type", "stat_type_content", "stat_date", "area", "region", "city", "city_code",
                "tt_num", "chkn_num", "other_num", "log_norm_num", "chkn_norm_num", "log_muti_group_num",
                "chkn_muti_group_num", "log_zc_num", "log_zc_num_new", "chkn_zc_num", "log_zc_correct_num", "log_zc_correct_num_new",
                "chkn_zc_correct_num", "log_aoi_num", "chkn_aoi_num", "other_num_aoi", "chkn_num_aoi",
                "hp_zc_num", "hp_aoi_num", "phone_zc_num", "phone_aoi_num",
                "ks_zc_num", "ks_aoi_num"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "norm_tt_pai_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = table;
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public boolean judge_groupids(String groupids) {
        boolean flag = false;
        if (StringUtils.isNotEmpty(groupids)) {
            groupids = groupids.replace("$", "");
            if (StringUtils.isNotEmpty(groupids)) {
                flag = true;
            }
        }
        return flag;
    }

    public boolean judge_filters(String filters) {
        boolean flag = false;
        if (StringUtils.isNotEmpty(filters)) {
            String[] splitList = filters.split("\\$");
            for (String s : splitList) {
                if (StringUtils.equals(s, "1") || StringUtils.equals(s, "2") || StringUtils.equals(s, "8")) {
                    return true;
                }
            }
        }
        return flag;
    }

    public int calGroupidNum(String groupids) {
        int num = 0;
        if (StringUtils.isNotEmpty(groupids)) {
            String[] groupidsList = groupids.split("\\$");
            HashMap<String, Integer> map = new HashMap<String, Integer>();
            for (String s : groupidsList) {
                map.put(s, 1);
            }
            num = map.size();
        }
        return num;
    }

    public static void main(String[] args) {

    }
}
