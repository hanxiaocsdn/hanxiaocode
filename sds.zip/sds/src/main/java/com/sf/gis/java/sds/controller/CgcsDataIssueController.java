package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.ConfigurationUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrong2ReviewSuc;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.pojo.CghsResultData;
import com.sf.gis.java.sds.service.CgcsDataIssueService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class CgcsDataIssueController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(CgcsDataIssueController.class);
    CgcsDataIssueService service = new CgcsDataIssueService();

    public void start(String today, String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> cmsGetAddrByCityCodeAndAddrUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s&ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1");
        Broadcast<String> cmsHpUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/atdispatch/hpAlter/find?city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&id=%s");
        Broadcast<String> cmsCompanyUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/atalter/company/findbatch?ak=3eb300d2e06947f7945cd02530a32fd2&p=%s");
        Broadcast<List<String>> configBc = sc.broadcast(ConfigurationUtil.loadFileByConf("config.csv"));


        logger.error("获取初始数据源");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> statRdd = service.loadWeekStat(spark, sc, today).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:{}", statRdd.count());
        statRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        if (statRdd.count() > 0) {
            logger.error("从初始数据源区分三类数据源");
            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> statRdd1 = statRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "chkn") && StringUtils.equals(o.getLabel(), "wrong")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statRdd1 cnt:{}", statRdd1.count());
            statRdd1.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> statRdd2 = statRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm") && StringUtils.equals(o.getLabel(), "wrong") && StringUtils.isNotEmpty(o.getRight_percent()) && Double.valueOf(o.getRight_percent()) <= 0.5).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statRdd2 cnt:{}", statRdd2.count());
            statRdd2.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> statRdd3 = statRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm") && StringUtils.equals(o.getLabel(), "wrong") && StringUtils.isNotEmpty(o.getRight_percent()) && Double.valueOf(o.getRight_percent()) > 0.5).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statRdd3 cnt:{}", statRdd3.count());
            statRdd3.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            statRdd.unpersist();

            logger.error("三类数据跑cms接口获取adcode");

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> cmsStatRdd1 = service.processCms(cmsGetAddrByCityCodeAndAddrUrlBc.value(), statRdd1).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsStatRdd1 cnt:{}", cmsStatRdd1.count());
            cmsStatRdd1.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            statRdd1.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> cmsStatRdd2 = service.processCms(cmsGetAddrByCityCodeAndAddrUrlBc.value(), statRdd2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsStatRdd2 cnt:{}", cmsStatRdd2.count());
            cmsStatRdd2.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            statRdd2.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> cmsStatRdd3 = service.processCms(cmsGetAddrByCityCodeAndAddrUrlBc.value(), statRdd3).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsStatRdd3 cnt:{}", cmsStatRdd3.count());
            cmsStatRdd3.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            statRdd3.unpersist();

            logger.error("statRdd1 处理");
            JavaRDD<AoiRealAccturyRateJudgeWrong2ReviewSuc> waybillNoRdd = service.loadWaybillNo(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("waybillNoRdd cnt:{}", waybillNoRdd.count());
            waybillNoRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalStatRdd1 = cmsStatRdd1
                    .filter(o -> {
                        boolean flag = true;
                        String req_addresseeaddr = o.getReq_addresseeaddr();
                        List<String> suffixs = configBc.value();
                        if (StringUtils.isNotEmpty(req_addresseeaddr)) {
                            for (String suffix : suffixs) {
                                if (req_addresseeaddr.endsWith(suffix)) {
                                    flag = false;
                                    break;
                                }
                            }
                        }
                        return flag;
                    })
                    .filter(o -> service.judgeAddr(o.getReq_addresseeaddr()))
                    .mapToPair(o -> new Tuple2<>(o.getWaybillno(), o))
                    .leftOuterJoin(waybillNoRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)))
                    .map(tp -> {
                        AoiRealAccturyRateJudgeWrongOperation o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            o.setFilterFlag("1");
                        }
                        return o;
                    })
                    .filter(o -> !StringUtils.equals(o.getFilterFlag(), "1"))
                    .mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getCity_code(), o.getOrg_code(), o.getReq_addresseeaddr()}, "_"), o))
                    .reduceByKey((o1, o2) -> o1)
                    .map(tp -> tp._2)
                    .map(o -> {
                        o.setAddress(o.getReq_addresseeaddr());
                        o.setGuid("chkn");
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalStatRdd1 cnt:{}", finalStatRdd1.count());
            finalStatRdd1.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            cmsStatRdd1.unpersist();
            waybillNoRdd.unpersist();

            logger.error("statRdd2 处理");
            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> hpAndCompanyRdd = cmsStatRdd2.filter(o -> StringUtils.equals(o.getOld_cms_aoiid(), o.getFinalaoiid())).map(o -> {
                String city_code = o.getCity_code();
                String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                    //跑号铺接口
                    String content1 = service.runHp(cmsHpUrlBc.value(), city_code, gis_to_sys_groupid, acLimitCodeSetBc.value());
                    if (StringUtils.isNotEmpty(content1)) {
                        JSONObject jsonObject = JSON.parseObject(content1);
                        int status = jsonObject.getInteger("status");
                        if (status == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            JSONArray hps = result.getJSONArray("hps");
                            if (hps != null) {
                                for (int i = 0; i < hps.size(); i++) {
                                    JSONObject jsonObject1 = hps.getJSONObject(i);
                                    String hp = jsonObject1.getString("hp");
                                    if (StringUtils.isNotEmpty(hp)) {
                                        o.setHpFlag("1");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    //跑公司名接口
                    JSONArray jsonArray = new JSONArray();
                    JSONObject jsonObject = new JSONObject();
                    JSONObject jsonObject1 = new JSONObject();

                    jsonObject.put("citycode", city_code);
                    jsonObject.put("groupid", gis_to_sys_groupid);
                    jsonArray.add(jsonObject);
                    jsonObject1.put("query", jsonArray);
                    String content2 = service.runCompany(cmsCompanyUrlBc.value(), jsonObject1.toString(), acLimitCodeSetBc.value());
                    if (StringUtils.isNotEmpty(content2)) {
                        JSONObject jsonObject2 = JSON.parseObject(content2);
                        int status = jsonObject2.getInteger("status");
                        if (status == 0) {
                            JSONArray result = jsonObject2.getJSONArray("result");
                            JSONObject jsonObject3 = result.getJSONObject(0);
                            JSONObject result1 = jsonObject3.getJSONObject("result");
                            int status1 = result1.getInteger("status");
                            if (status1 == 0) {
                                JSONArray result2 = result1.getJSONArray("result");
                                for (int i = 0; i < result2.size(); i++) {
                                    JSONObject jsonObject4 = result2.getJSONObject(i);
                                    String company = jsonObject4.getString("company");
                                    if (StringUtils.isNotEmpty(company)) {
                                        o.setCompanyFlag("1");
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
                return o;
            }).filter(o -> !StringUtils.equals(o.getHpFlag(), "1") && !StringUtils.equals(o.getCompanyFlag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("hpAndCompanyRdd cnt:{}", hpAndCompanyRdd.count());
            hpAndCompanyRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            cmsStatRdd2.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalStatRdd2 = hpAndCompanyRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getCity_code(), o.getOrg_code(), o.getGis_to_sys_groupid()}, "_"), o))
                    .reduceByKey((o1, o2) -> o1)
                    .map(tp -> tp._2)
                    .map(o -> {
                        o.setAddress(o.getCms_address());
                        o.setGuid("norm_wrong");
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalStatRdd2 cnt:{}", finalStatRdd2.count());
            finalStatRdd2.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            hpAndCompanyRdd.unpersist();

            logger.error("statRdd3 处理");
            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalStatRdd3 = cmsStatRdd3.filter(o -> !StringUtils.equals(o.getGisaoisrc(), "normcompany"))
                    .filter(o -> service.judgeAddr(o.getReq_addresseeaddr()))
                    .filter(o -> {
                        boolean flag = true;
                        String req_addresseeaddr = o.getReq_addresseeaddr();
                        List<String> suffixs = configBc.value();
                        if (StringUtils.isNotEmpty(req_addresseeaddr)) {
                            for (String suffix : suffixs) {
                                if (req_addresseeaddr.endsWith(suffix)) {
                                    flag = false;
                                    break;
                                }
                            }
                        }
                        return flag;
                    })
                    .mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o))
                    .groupByKey()
                    .flatMap(tp -> {
                        List<AoiRealAccturyRateJudgeWrongOperation> list = Lists.newArrayList(tp._2);
                        int size = list.size();
                        list = list.stream().map(o -> {
                            o.setAddress_freq(size + "");
                            return o;
                        }).collect(Collectors.toList());
                        return list.iterator();
                    })
                    .mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getCity_code(), o.getOrg_code(), o.getReq_addresseeaddr()}, "_"), o))
                    .reduceByKey((o1, o2) -> o1)
                    .map(tp -> tp._2)
                    .map(o -> {
                        o.setAddress(o.getReq_addresseeaddr());
                        o.setGuid("norm_same");
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalStatRdd3 cnt:{}", finalStatRdd3.count());
            finalStatRdd3.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            cmsStatRdd3.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> unionRdd = finalStatRdd1.union(finalStatRdd2).union(finalStatRdd3).mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("unionRdd cnt:{}", unionRdd.count());
            unionRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            finalStatRdd1.unpersist();
            finalStatRdd2.unpersist();
            finalStatRdd3.unpersist();

            logger.error("查询黑名单数据");
            JavaRDD<CghsResultData> cghsResultBlackDataRdd = service.loadCghsResultBlackData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cghsResultBlackDataRdd cnt:{}", cghsResultBlackDataRdd.count());
            cghsResultBlackDataRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));


            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalRdd = unionRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o))
                    .leftOuterJoin(cghsResultBlackDataRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                    .map(tp -> {
                        AoiRealAccturyRateJudgeWrongOperation o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            o.setCghsResultData_address_flag("1");
                        }
                        return o;
                    }).filter(o -> !StringUtils.equals(o.getCghsResultData_address_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            unionRdd.unpersist();
            cghsResultBlackDataRdd.unpersist();

//            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalRdd = aoiRealAccturyRateJudgeWrongOperationCghsResultDataAddressFlagRdd.filter(o -> !StringUtils.equals(o.getCghsResultData_address_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("finalRdd cnt:{}", finalRdd.count());

//            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> blackFinalRdd = aoiRealAccturyRateJudgeWrongOperationCghsResultDataAddressFlagRdd.filter(o -> StringUtils.equals(o.getCghsResultData_address_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("blackFinalRdd cnt:{}", blackFinalRdd.count());
//            aoiRealAccturyRateJudgeWrongOperationCghsResultDataAddressFlagRdd.unpersist();

//            logger.error("黑名单数据入库");
//            String executeBlackSql = String.format("alter table dm_gis.cgcss_misclassification_data_shunt_black drop if EXISTS partition(operate_date='%s')", today);
//            logger.error("executeBlackSql :{}", executeBlackSql);
//            spark.sql(executeBlackSql);
//            service.saveData(spark, blackFinalRdd, today, "dm_gis.cgcss_misclassification_data_shunt_black");
//            blackFinalRdd.unpersist();

            logger.error("与过去三次的数据进行关联，若地址重复，则本次不推");
            String start = DateUtil.getDaysBefore(today, 21);
            String end = DateUtil.getDaysBefore(today, 7);
            logger.error("start:{}, end:{}", start, end);
            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> rateJudgeWrongRdd = service.loadRateJudgeWrongData(spark, sc, start, end).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rateJudgeWrongRdd cnt:{}", rateJudgeWrongRdd.count());
            rateJudgeWrongRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> joinRdd = finalRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o))
                    .leftOuterJoin(rateJudgeWrongRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                    .map(tp -> {
                        AoiRealAccturyRateJudgeWrongOperation o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            o.setRepeat_address_flag("1");
                        }
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("joinRdd cnt:{}", joinRdd.count());
            finalRdd.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> lastRdd = joinRdd.filter(o -> !StringUtils.equals(o.getRepeat_address_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> filterRdd = joinRdd.filter(o -> StringUtils.equals(o.getRepeat_address_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("lastRdd cnt:{}", lastRdd.count());
            logger.error("filterRdd cnt:{}", filterRdd.count());
            joinRdd.unpersist();

            logger.error("重复过滤数据入库");
            String executeSql1 = String.format("alter table dm_gis.cgcss_misclassification_data_shunt_filter drop if EXISTS partition(operate_date='%s')", today);
            logger.error("executeSql1 :{}", executeSql1);
            spark.sql(executeSql1);
            service.saveData(spark, filterRdd, today, "dm_gis.cgcss_misclassification_data_shunt_filter");
            filterRdd.unpersist();

            logger.error("数据入库");
            String executeSql = String.format("alter table dm_gis.cgcss_misclassification_data_shunt drop if EXISTS partition(operate_date='%s')", today);
            logger.error("executeSql :{}", executeSql);
            spark.sql(executeSql);
            service.saveData(spark, lastRdd, today, "dm_gis.cgcss_misclassification_data_shunt");
            lastRdd.unpersist();

        } else {
            logger.error("date:{},查无数据", today);
        }

        spark.stop();
    }
}
