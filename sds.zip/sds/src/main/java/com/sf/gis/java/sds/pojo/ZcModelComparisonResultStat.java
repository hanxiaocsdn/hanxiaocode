package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ZcModelComparisonResultStat implements Serializable {
    @Column(name = "waybill_total")
    private String waybill_total;
    @Column(name = "old_dept_sbl_total")
    private String old_dept_sbl_total;
    @Column(name = "new_dept_sbl_total")
    private String new_dept_sbl_total;
    @Column(name = "old_dept_sbl")
    private String old_dept_sbl;
    @Column(name = "new_dept_sbl")
    private String new_dept_sbl;
    @Column(name = "old_dept_zql_total")
    private String old_dept_zql_total;
    @Column(name = "new_dept_zql_total")
    private String new_dept_zql_total;
    @Column(name = "old_dept_zql")
    private String old_dept_zql;
    @Column(name = "new_dept_zql")
    private String new_dept_zql;

    @Column(name = "waybill_total_ka")
    private String waybill_total_ka;
    @Column(name = "old_dept_sbl_total_ka")
    private String old_dept_sbl_total_ka;
    @Column(name = "new_dept_sbl_total_ka")
    private String new_dept_sbl_total_ka;
    @Column(name = "old_dept_sbl_ka")
    private String old_dept_sbl_ka;
    @Column(name = "new_dept_sbl_ka")
    private String new_dept_sbl_ka;
    @Column(name = "old_dept_zql_total_ka")
    private String old_dept_zql_total_ka;
    @Column(name = "new_dept_zql_total_ka")
    private String new_dept_zql_total_ka;
    @Column(name = "old_dept_zql_ka")
    private String old_dept_zql_ka;
    @Column(name = "new_dept_zql_ka")
    private String new_dept_zql_ka;

    @Column(name = "waybill_total_no_ka")
    private String waybill_total_no_ka;
    @Column(name = "old_dept_sbl_total_no_ka")
    private String old_dept_sbl_total_no_ka;
    @Column(name = "new_dept_sbl_total_no_ka")
    private String new_dept_sbl_total_no_ka;
    @Column(name = "old_dept_sbl_no_ka")
    private String old_dept_sbl_no_ka;
    @Column(name = "new_dept_sbl_no_ka")
    private String new_dept_sbl_no_ka;
    @Column(name = "old_dept_zql_total_no_ka")
    private String old_dept_zql_total_no_ka;
    @Column(name = "new_dept_zql_total_no_ka")
    private String new_dept_zql_total_no_ka;
    @Column(name = "old_dept_zql_no_ka")
    private String old_dept_zql_no_ka;
    @Column(name = "new_dept_zql_no_ka")
    private String new_dept_zql_no_ka;

    @Column(name = "inc_day")
    private String inc_day;

    public ZcModelComparisonResultStat() {
    }

    public ZcModelComparisonResultStat(String waybill_total, String old_dept_sbl_total, String new_dept_sbl_total, String old_dept_sbl, String new_dept_sbl, String old_dept_zql_total, String new_dept_zql_total, String old_dept_zql, String new_dept_zql, String waybill_total_ka, String old_dept_sbl_total_ka, String new_dept_sbl_total_ka, String old_dept_sbl_ka, String new_dept_sbl_ka, String old_dept_zql_total_ka, String new_dept_zql_total_ka, String old_dept_zql_ka, String new_dept_zql_ka, String waybill_total_no_ka, String old_dept_sbl_total_no_ka, String new_dept_sbl_total_no_ka, String old_dept_sbl_no_ka, String new_dept_sbl_no_ka, String old_dept_zql_total_no_ka, String new_dept_zql_total_no_ka, String old_dept_zql_no_ka, String new_dept_zql_no_ka, String inc_day) {
        this.waybill_total = waybill_total;
        this.old_dept_sbl_total = old_dept_sbl_total;
        this.new_dept_sbl_total = new_dept_sbl_total;
        this.old_dept_sbl = old_dept_sbl;
        this.new_dept_sbl = new_dept_sbl;
        this.old_dept_zql_total = old_dept_zql_total;
        this.new_dept_zql_total = new_dept_zql_total;
        this.old_dept_zql = old_dept_zql;
        this.new_dept_zql = new_dept_zql;
        this.waybill_total_ka = waybill_total_ka;
        this.old_dept_sbl_total_ka = old_dept_sbl_total_ka;
        this.new_dept_sbl_total_ka = new_dept_sbl_total_ka;
        this.old_dept_sbl_ka = old_dept_sbl_ka;
        this.new_dept_sbl_ka = new_dept_sbl_ka;
        this.old_dept_zql_total_ka = old_dept_zql_total_ka;
        this.new_dept_zql_total_ka = new_dept_zql_total_ka;
        this.old_dept_zql_ka = old_dept_zql_ka;
        this.new_dept_zql_ka = new_dept_zql_ka;
        this.waybill_total_no_ka = waybill_total_no_ka;
        this.old_dept_sbl_total_no_ka = old_dept_sbl_total_no_ka;
        this.new_dept_sbl_total_no_ka = new_dept_sbl_total_no_ka;
        this.old_dept_sbl_no_ka = old_dept_sbl_no_ka;
        this.new_dept_sbl_no_ka = new_dept_sbl_no_ka;
        this.old_dept_zql_total_no_ka = old_dept_zql_total_no_ka;
        this.new_dept_zql_total_no_ka = new_dept_zql_total_no_ka;
        this.old_dept_zql_no_ka = old_dept_zql_no_ka;
        this.new_dept_zql_no_ka = new_dept_zql_no_ka;
        this.inc_day = inc_day;
    }

    public String getWaybill_total() {
        return waybill_total;
    }

    public void setWaybill_total(String waybill_total) {
        this.waybill_total = waybill_total;
    }

    public String getOld_dept_sbl_total() {
        return old_dept_sbl_total;
    }

    public void setOld_dept_sbl_total(String old_dept_sbl_total) {
        this.old_dept_sbl_total = old_dept_sbl_total;
    }

    public String getNew_dept_sbl_total() {
        return new_dept_sbl_total;
    }

    public void setNew_dept_sbl_total(String new_dept_sbl_total) {
        this.new_dept_sbl_total = new_dept_sbl_total;
    }

    public String getOld_dept_sbl() {
        return old_dept_sbl;
    }

    public void setOld_dept_sbl(String old_dept_sbl) {
        this.old_dept_sbl = old_dept_sbl;
    }

    public String getNew_dept_sbl() {
        return new_dept_sbl;
    }

    public void setNew_dept_sbl(String new_dept_sbl) {
        this.new_dept_sbl = new_dept_sbl;
    }

    public String getOld_dept_zql_total() {
        return old_dept_zql_total;
    }

    public void setOld_dept_zql_total(String old_dept_zql_total) {
        this.old_dept_zql_total = old_dept_zql_total;
    }

    public String getNew_dept_zql_total() {
        return new_dept_zql_total;
    }

    public void setNew_dept_zql_total(String new_dept_zql_total) {
        this.new_dept_zql_total = new_dept_zql_total;
    }

    public String getOld_dept_zql() {
        return old_dept_zql;
    }

    public void setOld_dept_zql(String old_dept_zql) {
        this.old_dept_zql = old_dept_zql;
    }

    public String getNew_dept_zql() {
        return new_dept_zql;
    }

    public void setNew_dept_zql(String new_dept_zql) {
        this.new_dept_zql = new_dept_zql;
    }

    public String getWaybill_total_ka() {
        return waybill_total_ka;
    }

    public void setWaybill_total_ka(String waybill_total_ka) {
        this.waybill_total_ka = waybill_total_ka;
    }

    public String getOld_dept_sbl_total_ka() {
        return old_dept_sbl_total_ka;
    }

    public void setOld_dept_sbl_total_ka(String old_dept_sbl_total_ka) {
        this.old_dept_sbl_total_ka = old_dept_sbl_total_ka;
    }

    public String getNew_dept_sbl_total_ka() {
        return new_dept_sbl_total_ka;
    }

    public void setNew_dept_sbl_total_ka(String new_dept_sbl_total_ka) {
        this.new_dept_sbl_total_ka = new_dept_sbl_total_ka;
    }

    public String getOld_dept_sbl_ka() {
        return old_dept_sbl_ka;
    }

    public void setOld_dept_sbl_ka(String old_dept_sbl_ka) {
        this.old_dept_sbl_ka = old_dept_sbl_ka;
    }

    public String getNew_dept_sbl_ka() {
        return new_dept_sbl_ka;
    }

    public void setNew_dept_sbl_ka(String new_dept_sbl_ka) {
        this.new_dept_sbl_ka = new_dept_sbl_ka;
    }

    public String getOld_dept_zql_total_ka() {
        return old_dept_zql_total_ka;
    }

    public void setOld_dept_zql_total_ka(String old_dept_zql_total_ka) {
        this.old_dept_zql_total_ka = old_dept_zql_total_ka;
    }

    public String getNew_dept_zql_total_ka() {
        return new_dept_zql_total_ka;
    }

    public void setNew_dept_zql_total_ka(String new_dept_zql_total_ka) {
        this.new_dept_zql_total_ka = new_dept_zql_total_ka;
    }

    public String getOld_dept_zql_ka() {
        return old_dept_zql_ka;
    }

    public void setOld_dept_zql_ka(String old_dept_zql_ka) {
        this.old_dept_zql_ka = old_dept_zql_ka;
    }

    public String getNew_dept_zql_ka() {
        return new_dept_zql_ka;
    }

    public void setNew_dept_zql_ka(String new_dept_zql_ka) {
        this.new_dept_zql_ka = new_dept_zql_ka;
    }

    public String getWaybill_total_no_ka() {
        return waybill_total_no_ka;
    }

    public void setWaybill_total_no_ka(String waybill_total_no_ka) {
        this.waybill_total_no_ka = waybill_total_no_ka;
    }

    public String getOld_dept_sbl_total_no_ka() {
        return old_dept_sbl_total_no_ka;
    }

    public void setOld_dept_sbl_total_no_ka(String old_dept_sbl_total_no_ka) {
        this.old_dept_sbl_total_no_ka = old_dept_sbl_total_no_ka;
    }

    public String getNew_dept_sbl_total_no_ka() {
        return new_dept_sbl_total_no_ka;
    }

    public void setNew_dept_sbl_total_no_ka(String new_dept_sbl_total_no_ka) {
        this.new_dept_sbl_total_no_ka = new_dept_sbl_total_no_ka;
    }

    public String getOld_dept_sbl_no_ka() {
        return old_dept_sbl_no_ka;
    }

    public void setOld_dept_sbl_no_ka(String old_dept_sbl_no_ka) {
        this.old_dept_sbl_no_ka = old_dept_sbl_no_ka;
    }

    public String getNew_dept_sbl_no_ka() {
        return new_dept_sbl_no_ka;
    }

    public void setNew_dept_sbl_no_ka(String new_dept_sbl_no_ka) {
        this.new_dept_sbl_no_ka = new_dept_sbl_no_ka;
    }

    public String getOld_dept_zql_total_no_ka() {
        return old_dept_zql_total_no_ka;
    }

    public void setOld_dept_zql_total_no_ka(String old_dept_zql_total_no_ka) {
        this.old_dept_zql_total_no_ka = old_dept_zql_total_no_ka;
    }

    public String getNew_dept_zql_total_no_ka() {
        return new_dept_zql_total_no_ka;
    }

    public void setNew_dept_zql_total_no_ka(String new_dept_zql_total_no_ka) {
        this.new_dept_zql_total_no_ka = new_dept_zql_total_no_ka;
    }

    public String getOld_dept_zql_no_ka() {
        return old_dept_zql_no_ka;
    }

    public void setOld_dept_zql_no_ka(String old_dept_zql_no_ka) {
        this.old_dept_zql_no_ka = old_dept_zql_no_ka;
    }

    public String getNew_dept_zql_no_ka() {
        return new_dept_zql_no_ka;
    }

    public void setNew_dept_zql_no_ka(String new_dept_zql_no_ka) {
        this.new_dept_zql_no_ka = new_dept_zql_no_ka;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
