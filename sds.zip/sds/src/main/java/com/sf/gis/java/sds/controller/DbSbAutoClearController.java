package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.DbPressSb;
import com.sf.gis.java.sds.pojo.DbSbClear;
import com.sf.gis.java.sds.pojo.DbSbClear;
import com.sf.gis.java.sds.pojo.DbSbClear;
import com.sf.gis.java.sds.utils.UrlUtil;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import javax.persistence.Column;
import java.io.Serializable;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class DbSbAutoClearController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DbSbAutoClearController.class);
    private static String queryZc = "http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon/query?ak=3a191e7427e8470c86271a069411c66b&parent_code=%s";
    private static String depponUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=%s&show=1";
    private static String deleteUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon/his/del?citycode=%s&address=%s&adcode=%s&type=%s&ak=3a191e7427e8470c86271a069411c66b";
    private static String pressUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon/his/opt?citycode=%s&address=%s&adcode=%s&type=%s&zc=%s&tc=&ak=3a191e7427e8470c86271a069411c66b";

    private static String normUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/opt/norm?ak=ffc9595f015e4d2a96b565fc2dc1157a&address=%s&showserver=true";
    private static String atpUrl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=&company=&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh";
    private static String queryUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/cache/query?ak=3a191e7427e8470c86271a069411c66b&type=3&aoi=%s";

    private static String taskId = "1147";
    private static String taskName = "德邦错分审补自动清洗工艺";
    private static String account = "01399581";

    public void start(String startDate, String endDate, String period) {
        //初始化spark
        SparkSession spark = Spark.getSparkSession("DbSbAutoClearController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        logger.error("获取德邦错分数据");
        JavaRDD<DbSbClear> rdd = loadData(spark, sc, startDate, endDate, DateUtil.getDaysBefore(startDate, 30)).map(o -> {
            o.setPeriod(period);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        logger.error("签收网点是否有效");
        JavaRDD<DbSbClear> signZcRdd = signZcInvalid(rdd, spark);
        JavaRDD<DbSbClear> trueRdd = signZcRdd.filter(o -> "true".equals(o.getSign_zc_invalid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbSbClear> otherRdd = signZcRdd.filter(o -> !"true".equals(o.getSign_zc_invalid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trueRdd cnt:{}", trueRdd.count());
        logger.error("otherRdd cnt:{}", otherRdd.count());
        signZcRdd.unpersist();

        logger.error("v1.2新增逻辑，获取adcode,key_word,zc_aoi");
        JavaRDD<DbSbClear> adcodeKeyWordAndZcRdd = getAdcodeKeyWordAndZc(trueRdd, spark);

        logger.error("调取德邦分单，获取最新识别结果zc_new");
        JavaRDD<DbSbClear> zcNewRdd = depponFd(adcodeKeyWordAndZcRdd, spark);

        logger.error("v1.2新增逻辑,打标签");
        JavaRDD<DbSbClear> modifyTagRdd = modifyTag(zcNewRdd);
        JavaRDD<DbSbClear> modifyFalseRdd = modifyTagRdd.filter(o -> StringUtils.equals(o.getIs_modify(), "false")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbSbClear> modifyTrueRdd = modifyTagRdd.filter(o -> StringUtils.equals(o.getIs_modify(), "true")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyFalseRdd cnt:{}, modifyTrueRdd cnt:{}", modifyFalseRdd.count(), modifyTrueRdd.count());
        modifyTagRdd.unpersist();

        JavaRDD<DbSbClear> auto_keywordRdd = modifyFalseRdd.filter(o -> StringUtils.equals("AUTO_KEYWORD", o.getSource_new())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbSbClear> auto_textRdd = modifyFalseRdd.filter(o -> StringUtils.equals("AUTO_TEXT", o.getSource_new())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("auto_keywordRdd cnt:{},auto_textRdd cnt:{}", auto_keywordRdd.count(), auto_textRdd.count());
        modifyFalseRdd.unpersist();

        logger.error("AUTO_KEYWORD处理");
        JavaRDD<DbSbClear> autoKeywordProcessRdd = processAutoKeyWord(auto_keywordRdd, spark);

        logger.error("AUTO_TEXT处理");
        JavaRDD<DbSbClear> auto_textProcessRdd = processAutoText(auto_textRdd, spark);

        logger.error("结果数据存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_deppon_auto_clear_sb_period_di", DbSbClear.class, otherRdd.union(modifyTrueRdd).union(autoKeywordProcessRdd).union(auto_textProcessRdd), "period", "inc_day");
        otherRdd.unpersist();
        modifyTrueRdd.unpersist();
        autoKeywordProcessRdd.unpersist();
        auto_textProcessRdd.unpersist();

        spark.stop();
    }

    public JavaRDD<DbSbClear> modifyTag(JavaRDD<DbSbClear> zcNewRdd) {
        JavaRDD<DbSbClear> modifyTagRdd = zcNewRdd.mapToPair(o -> new Tuple2<>(o.getKeyword_at(), o)).groupByKey().flatMap(tp -> {
            List<DbSbClear> list = Lists.newArrayList(tp._2);
            long size = list.stream().map(DbSbClear::getDepponZc).distinct().count();
            return list.stream().peek(o -> o.setKey_diff_zc_num(size + "")).iterator();
        }).map(o -> {
            String zc_new = o.getZc_new();
            String depponZc = o.getDepponZc();
            String is_right = "";
            String is_modify = "";
            if (StringUtils.equals(zc_new, depponZc)) {
                is_right = "true";
                is_modify = "true";
            } else {
                is_right = "false";
                if (Arrays.asList("AUTO_KEYWORD,AUTO_TEXT".split(",")).contains(o.getSource_new())) {
                    is_modify = "false";
                } else {
                    is_modify = "true";
                }
            }
            o.setIs_right(is_right);
            o.setIs_modify(is_modify);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyTagRdd cnt:" + modifyTagRdd.count());
        zcNewRdd.unpersist();
        return modifyTagRdd;
    }

    public JavaRDD<DbSbClear> getAdcodeKeyWordAndZc(JavaRDD<DbSbClear> trueRdd, SparkSession spark) {
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", normUrl, "ffc9595f015e4d2a96b565fc2dc1157a", trueRdd.count(), 5);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atpUrl, "3eb300d2e06947f7945cd02530a32fd2", trueRdd.count(), 5);
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", queryUrl, "3a191e7427e8470c86271a069411c66b", trueRdd.count(), 5);
        JavaRDD<DbSbClear> adcodeKeyWordAndZcRdd = trueRdd.map(o -> {
            String address = o.getAddress();
            String city = o.getCity();
            if (StringUtils.isNotEmpty(address)) {
                logger.error("获取adcode");
                String norm_req = String.format(normUrl, URLEncoder.encode(address, "UTF-8"));
                String norm_rs = HttpInvokeUtil.sendGet(norm_req);
                String adcode = "";
                try {
                    adcode = JSON.parseObject(norm_rs).getJSONObject("result").getJSONObject("data").getString("adcode");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setAdcode_normal(adcode);
                logger.error("跑atp获取keyword");
                String atp_req = String.format(atpUrl, URLEncoder.encode(address, "UTF-8"), city);
                String atp_rs = HttpInvokeUtil.sendGet(atp_req);
                String aoiid_at = "";
                String keyword_at = "";
                String level_at = "";
                String splitresult_at = "";
                String splitinfo_at = "";

                try {
                    aoiid_at = JSON.parseObject(atp_rs).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                    keyword_at = JSON.parseObject(atp_rs).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("keyWord");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    splitresult_at = JSON.parseObject(atp_rs).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    level_at = JSON.parseObject(atp_rs).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("level");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    splitinfo_at = JSON.parseObject(atp_rs).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("addrSplitInfo").getJSONObject(0).toJSONString();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                o.setAoiid_at(aoiid_at);
                o.setKeyword_at(keyword_at);
                o.setSplitresult_at(splitresult_at);
                o.setLevel_at(level_at);
                o.setSplitinfo_at(splitinfo_at);

                if (StringUtils.isNotEmpty(aoiid_at)) {
                    String aoi_req = String.format(queryUrl, aoiid_at);
                    String aoi_rs = HttpInvokeUtil.sendGet(aoi_req);
                    String type = "";
                    try {
                        type = JSON.parseObject(aoi_rs).getJSONObject("result").getJSONObject("query").getString("type");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setType_aoi(type);
                    StringBuilder sb = new StringBuilder();
                    try {
                        JSONArray deppon = JSON.parseObject(aoi_rs).getJSONObject("result").getJSONArray("deppon");
                        for (int i = 0; i < deppon.size(); i++) {
                            JSONObject jsonObject = deppon.getJSONObject(i);
                            String dept = jsonObject.getString("dept");
                            if (i == deppon.size() - 1) {
                                sb.append(dept);
                            } else {
                                sb.append(dept).append("|");
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    String rds_zc = sb.toString();
                    o.setZc_aoi(rds_zc);
                    if (StringUtils.isNotEmpty(rds_zc)) {
                        long count = Arrays.stream(rds_zc.split("\\|")).distinct().count();
                        o.setZc_aoi_num(count + "");
                    } else {
                        o.setZc_aoi_num("0");
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("adcodeKeyWordAndZcRdd cnt:" + adcodeKeyWordAndZcRdd.count());
        trueRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        BdpTaskRecordUtil.endNetworkInterface(account, id3);
        return adcodeKeyWordAndZcRdd;
    }

    public JavaRDD<DbSbClear> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate, String beforeDate) {
        String sql = SqlUtil.getSqlStr("db_sb_clear.sql", startDate, endDate, beforeDate, endDate);
        return DataUtil.loadData(spark, sc, sql, DbSbClear.class);
    }

    public JavaRDD<DbSbClear> processAutoText(JavaRDD<DbSbClear> auto_textRdd, SparkSession spark) {
        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", deleteUrl, "3a191e7427e8470c86271a069411c66b", auto_textRdd.count(), 5);
        String id6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", pressUrl, "3a191e7427e8470c86271a069411c66b", auto_textRdd.count(), 5);
        JavaRDD<DbSbClear> auto_textProcessRdd = auto_textRdd.map(o -> {
            int his_zc_diff_num = Integer.parseInt(o.getHis_zc_diff_num());
            String address = o.getAddress();
            String city = o.getCity();
            String zc = o.getDepponZc();
            String zc_aoi = o.getZc_aoi();
            if (his_zc_diff_num > 1 || (StringUtils.isNotEmpty(zc_aoi) && zc_aoi.contains(zc))) {
                o.setDeal_type("del");
                if (StringUtils.isNotEmpty(address)) {
                    String req1 = String.format(deleteUrl, city, URLEncoder.encode(address, "UTF-8"), "", "1");
                    String content1 = HttpInvokeUtil.sendGet(req1);
                    String status_deal = "";
                    try {
                        status_deal = JSON.parseObject(content1).getString("status");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setStatus_deal(status_deal);
                    if ("1".equals(status_deal)) {
                        //如果第一次删除失败，要先压审补，再删除
                        String req2 = String.format(pressUrl, city, URLEncoder.encode(address, "UTF-8"), "", "1", zc);
                        String press_content = HttpInvokeUtil.sendGet(req2);
                        //第二次删除
                        content1 = HttpInvokeUtil.sendGet(req1);
                        try {
                            status_deal = JSON.parseObject(content1).getString("status");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        o.setStatus_deal(status_deal);
                    }
                }
            } else {
                o.setDeal_type("fix");
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(pressUrl, city, URLEncoder.encode(address, "UTF-8"), "", "1", zc);
                    String content = HttpInvokeUtil.sendGet(req);
                    String status_deal = "";
                    try {
                        status_deal = JSON.parseObject(content).getString("status");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setStatus_deal(status_deal);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("auto_textProcessRdd cnt:{}", auto_textProcessRdd.count());
        auto_textRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id5);
        BdpTaskRecordUtil.endNetworkInterface(account, id6);
        return auto_textProcessRdd;
    }

    public JavaRDD<DbSbClear> processAutoKeyWord(JavaRDD<DbSbClear> auto_keywordRdd, SparkSession spark) {
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", deleteUrl, "3a191e7427e8470c86271a069411c66b", auto_keywordRdd.count(), 5);
        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", pressUrl, "3a191e7427e8470c86271a069411c66b", auto_keywordRdd.count(), 5);
        JavaRDD<DbSbClear> autoKeywordProcessRdd = auto_keywordRdd.map(o -> {
            int key_diff_zc_num = Integer.parseInt(o.getKey_diff_zc_num());
            int his_zc_diff_num = StringUtils.isNotEmpty(o.getHis_zc_diff_num()) ? Integer.parseInt(o.getHis_zc_diff_num()) : 0;
            String keyword_at = o.getKeyword_at();
            String adcode_normal = o.getAdcode_normal();
            String city = o.getCity();
            String zc = o.getDepponZc();
            int zc_aoi_num = StringUtils.isNotEmpty(o.getZc_aoi_num()) ? Integer.parseInt(o.getZc_aoi_num()) : 0;
            String zc_aoi = o.getZc_aoi();
            if (key_diff_zc_num > 1 || his_zc_diff_num > 1 || (zc_aoi_num == 1 && StringUtils.isNotEmpty(zc_aoi) && zc_aoi.contains(zc))) {
                o.setDeal_type("del");
                if (StringUtils.isNotEmpty(keyword_at)) {
                    String req1 = String.format(deleteUrl, "", URLEncoder.encode(keyword_at, "UTF-8"), adcode_normal, "2");
                    String content1 = HttpInvokeUtil.sendGet(req1);
                    String status_deal = "";
                    try {
                        status_deal = JSON.parseObject(content1).getString("status");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setStatus_deal(status_deal);
                    if ("1".equals(status_deal)) {
                        //如果第一次删除失败，要先压审补，再删除
                        String req2 = String.format(pressUrl, city, URLEncoder.encode(keyword_at, "UTF-8"), adcode_normal, "2", zc);
                        String press_content = HttpInvokeUtil.sendGet(req2);
                        //第二次删除
                        content1 = HttpInvokeUtil.sendGet(req1);
                        try {
                            status_deal = JSON.parseObject(content1).getString("status");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        o.setStatus_deal(status_deal);
                    }
                }
            } else {
                o.setDeal_type("fix");
                if (StringUtils.isNotEmpty(keyword_at)) {
                    String req = String.format(pressUrl, city, URLEncoder.encode(keyword_at, "UTF-8"), adcode_normal, "2", zc);
                    String content = HttpInvokeUtil.sendGet(req);
                    String status_deal = "";
                    try {
                        status_deal = JSON.parseObject(content).getString("status");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setStatus_deal(status_deal);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("autoKeywordProcessRdd cnt:{}", autoKeywordProcessRdd.count());
        auto_keywordRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);
        BdpTaskRecordUtil.endNetworkInterface(account, id4);
        return autoKeywordProcessRdd;
    }

    public JavaRDD<DbSbClear> depponFd(JavaRDD<DbSbClear> trueRdd, SparkSession spark) {
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", depponUrl, "3a191e7427e8470c86271a069411c66b", trueRdd.count(), 1);
        JavaRDD<DbSbClear> zcNewRdd = trueRdd.repartition(1).map(o -> {
            String address = o.getAddress();
            String citycode = o.getCitycode();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(depponUrl, citycode, URLEncoder.encode(address, "UTF-8"), "zh");
                String content = HttpInvokeUtil.sendGet(req);

                String source_new = "";
                String keyword_new = "";
                String zc_new = "";
                String tc_new = "";
                String match_new = "";
                String adcode_new = "";
                String msg_new = "";

                try {
                    keyword_new = JSON.parseObject(content).getJSONObject("result").getString("keyword");
                    msg_new = JSON.parseObject(content).getJSONObject("result").getString("msg");
                } catch (Exception e) {
                }
                try {
                    source_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("source");
                    match_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("match");
                    adcode_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("adcode");
                } catch (Exception e) {
                }
                try {
                    zc_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("zc");
                    tc_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("tc");
                } catch (Exception e) {
                }

                o.setKeyword_new(keyword_new);
                o.setMsg_new(msg_new);
                o.setSource_new(source_new);
                o.setMatch_new(match_new);
                o.setAdcode_new(adcode_new);
                o.setZc_new(zc_new);
                o.setTc_new(tc_new);

            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcNewRdd cnt:{}", zcNewRdd.count());
        trueRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        return zcNewRdd;
    }

    public JavaRDD<DbSbClear> signZcInvalid(JavaRDD<DbSbClear> rdd, SparkSession spark) {
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", queryZc, "3a191e7427e8470c86271a069411c66b", rdd.count(), 5);
        JavaRDD<DbSbClear> signZcRdd = rdd.map(o -> {
            String depponZc = o.getDepponZc();
            if (StringUtils.isNotEmpty(depponZc)) {
                String req = String.format(queryZc, depponZc);
                String content = HttpInvokeUtil.sendGet(req);
                String status = "";
                try {
                    status = JSON.parseObject(content).getString("status");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                if ("0".equals(status)) {
                    o.setSign_zc_invalid("true");
                } else if ("1".equals(status)) {
                    o.setSign_zc_invalid("false");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("signZcRdd cnt:{}", signZcRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        return signZcRdd;
    }
}
