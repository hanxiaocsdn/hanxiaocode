package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DkhRdsInfoClear implements Serializable {
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "detail_addr")
    private String detailAddr;
    @Column(name = "addr")
    private String addr;
    @Column(name = "aoi_80xy")
    private String aoi80xy;
    @Column(name = "phone")
    private String phone;
    @Column(name = "comp_name")
    private String compName;
    @Column(name = "ttl_cnt")
    private String ttlCnt;
    @Column(name = "ttl_freight")
    private String ttlFreight;
    @Column(name = "cnt")
    private String cnt;
    @Column(name = "freight")
    private String freight;
    @Column(name = "zc")
    private String zc;
    @Column(name = "zc_src")
    private String zcSrc;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_src")
    private String aoiSrc;
    @Column(name = "aoi_unit")
    private String aoiUnit;
    @Column(name = "group_id")
    private String groupId;
    @Column(name = "tag")
    private String tag;

    @Column(name = "arsresult")
    private String arsresult;
    @Column(name = "arsnormresult")
    private String arsnormresult;
    @Column(name = "segcitycode")
    private String segcitycode;
    @Column(name = "segnormcitycode")
    private String segnormcitycode;

    @Column(name = "aoi_id_at")
    private String aoi_id_at;
    @Column(name = "aoi_code_at")
    private String aoi_code_at;
    @Column(name = "aoi_src_at")
    private String aoi_src_at;
    @Column(name = "group1_at")
    private String group1_at;
    @Column(name = "deptsrc_at")
    private String deptsrc_at;
    @Column(name = "dept_at")
    private String dept_at;

    @Column(name = "vip_tag")
    private String vip_tag;
    @Column(name = "aoi_src_new")
    private String aoi_src_new;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "aoi_unit_at")
    private String aoi_unit_at;
    @Column(name = "inc_day")
    private String incDay;

    public String getAoi_unit_at() {
        return aoi_unit_at;
    }

    public void setAoi_unit_at(String aoi_unit_at) {
        this.aoi_unit_at = aoi_unit_at;
    }

    public String getVip_tag() {
        return vip_tag;
    }

    public void setVip_tag(String vip_tag) {
        this.vip_tag = vip_tag;
    }

    public String getAoi_src_new() {
        return aoi_src_new;
    }

    public void setAoi_src_new(String aoi_src_new) {
        this.aoi_src_new = aoi_src_new;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getAoi_id_at() {
        return aoi_id_at;
    }

    public void setAoi_id_at(String aoi_id_at) {
        this.aoi_id_at = aoi_id_at;
    }

    public String getAoi_code_at() {
        return aoi_code_at;
    }

    public void setAoi_code_at(String aoi_code_at) {
        this.aoi_code_at = aoi_code_at;
    }

    public String getAoi_src_at() {
        return aoi_src_at;
    }

    public void setAoi_src_at(String aoi_src_at) {
        this.aoi_src_at = aoi_src_at;
    }


    public String getGroup1_at() {
        return group1_at;
    }

    public void setGroup1_at(String group1_at) {
        this.group1_at = group1_at;
    }

    public String getDeptsrc_at() {
        return deptsrc_at;
    }

    public void setDeptsrc_at(String deptsrc_at) {
        this.deptsrc_at = deptsrc_at;
    }

    public String getDept_at() {
        return dept_at;
    }

    public void setDept_at(String dept_at) {
        this.dept_at = dept_at;
    }

    public String getSegcitycode() {
        return segcitycode;
    }

    public void setSegcitycode(String segcitycode) {
        this.segcitycode = segcitycode;
    }

    public String getSegnormcitycode() {
        return segnormcitycode;
    }

    public void setSegnormcitycode(String segnormcitycode) {
        this.segnormcitycode = segnormcitycode;
    }

    public String getArsresult() {
        return arsresult;
    }

    public void setArsresult(String arsresult) {
        this.arsresult = arsresult;
    }

    public String getArsnormresult() {
        return arsnormresult;
    }

    public void setArsnormresult(String arsnormresult) {
        this.arsnormresult = arsnormresult;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getDetailAddr() {
        return detailAddr;
    }

    public void setDetailAddr(String detailAddr) {
        this.detailAddr = detailAddr;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAoi80xy() {
        return aoi80xy;
    }

    public void setAoi80xy(String aoi80xy) {
        this.aoi80xy = aoi80xy;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getTtlCnt() {
        return ttlCnt;
    }

    public void setTtlCnt(String ttlCnt) {
        this.ttlCnt = ttlCnt;
    }

    public String getTtlFreight() {
        return ttlFreight;
    }

    public void setTtlFreight(String ttlFreight) {
        this.ttlFreight = ttlFreight;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getFreight() {
        return freight;
    }

    public void setFreight(String freight) {
        this.freight = freight;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getZcSrc() {
        return zcSrc;
    }

    public void setZcSrc(String zcSrc) {
        this.zcSrc = zcSrc;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiSrc() {
        return aoiSrc;
    }

    public void setAoiSrc(String aoiSrc) {
        this.aoiSrc = aoiSrc;
    }

    public String getAoiUnit() {
        return aoiUnit;
    }

    public void setAoiUnit(String aoiUnit) {
        this.aoiUnit = aoiUnit;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }
}
