package com.sf.gis.java.sds.db;


import com.sf.gis.java.base.util.SystemProperty;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

public class GisAoiDbManager implements IDbManager {
    private static GisAoiDbManager instance;
    private DruidManager druidManager;

    public static GisAoiDbManager getInstance() {
        if (instance == null) {
            synchronized (GisAoiDbManager.class) {
                if (instance == null) {
                    try {
                        instance = new GisAoiDbManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return instance;
    }

    private GisAoiDbManager() throws IOException {
        druidManager = new DruidManager( "conf/aoi_hook/druid_config_aoi.properties");
    }

    public DruidManager getDruidManager() {
        return druidManager;
    }

    public void close() {
        druidManager.close();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return druidManager.getConnection();
    }

    @Override
    public void update(String sql) {
        druidManager.update(sql);
    }
}