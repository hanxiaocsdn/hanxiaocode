package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoimodelWdAoi implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "phone")
    private String phone;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "tag3")
    private String tag3;
    @Column(name = "bottomcorrected")
    private String bottomcorrected;
    @Column(name = "80_aoi_code")
    private String aoi_80_code;
    @Column(name = "80_aoi_name")
    private String aoi_80_name;
    @Column(name = "gd_aoicode")
    private String gd_aoicode;
    @Column(name = "mapa_aoicode")
    private String mapa_aoicode;
    @Column(name = "gj_aoicode_t")
    private String gj_aoicode_t;
    @Column(name = "errortype")
    private String errortype;
    @Column(name = "finalresult")
    private String finalresult;
    @Column(name = "ks16aoi")
    private String ks16aoi;
    @Column(name = "ks16aoicode")
    private String ks16aoicode;
    @Column(name = "dept")
    private String dept;

    @Column(name = "std_address")
    private String std_address;
    @Column(name = "std_aoiid")
    private String std_aoiid;
    @Column(name = "std_zc")
    private String std_zc;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "key_word")
    private String key_word;

    @Column(name = "gd_result")
    private String gd_result;
    @Column(name = "gd_aoiid")
    private String gd_aoiid;
    @Column(name = "gd_name")
    private String gd_name;
    @Column(name = "result")
    private String result;
    @Column(name = "gdzno_code")
    private String gdzno_code;

    @Column(name = "inc_day")
    private String inc_day;

    public String getGdzno_code() {
        return gdzno_code;
    }

    public void setGdzno_code(String gdzno_code) {
        this.gdzno_code = gdzno_code;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getGd_result() {
        return gd_result;
    }

    public void setGd_result(String gd_result) {
        this.gd_result = gd_result;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getGd_name() {
        return gd_name;
    }

    public void setGd_name(String gd_name) {
        this.gd_name = gd_name;
    }

    public String getStd_address() {
        return std_address;
    }

    public void setStd_address(String std_address) {
        this.std_address = std_address;
    }

    public String getStd_aoiid() {
        return std_aoiid;
    }

    public void setStd_aoiid(String std_aoiid) {
        this.std_aoiid = std_aoiid;
    }

    public String getStd_zc() {
        return std_zc;
    }

    public void setStd_zc(String std_zc) {
        this.std_zc = std_zc;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getBottomcorrected() {
        return bottomcorrected;
    }

    public void setBottomcorrected(String bottomcorrected) {
        this.bottomcorrected = bottomcorrected;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getAoi_80_name() {
        return aoi_80_name;
    }

    public void setAoi_80_name(String aoi_80_name) {
        this.aoi_80_name = aoi_80_name;
    }

    public String getGd_aoicode() {
        return gd_aoicode;
    }

    public void setGd_aoicode(String gd_aoicode) {
        this.gd_aoicode = gd_aoicode;
    }

    public String getMapa_aoicode() {
        return mapa_aoicode;
    }

    public void setMapa_aoicode(String mapa_aoicode) {
        this.mapa_aoicode = mapa_aoicode;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getErrortype() {
        return errortype;
    }

    public void setErrortype(String errortype) {
        this.errortype = errortype;
    }

    public String getFinalresult() {
        return finalresult;
    }

    public void setFinalresult(String finalresult) {
        this.finalresult = finalresult;
    }

    public String getKs16aoi() {
        return ks16aoi;
    }

    public void setKs16aoi(String ks16aoi) {
        this.ks16aoi = ks16aoi;
    }

    public String getKs16aoicode() {
        return ks16aoicode;
    }

    public void setKs16aoicode(String ks16aoicode) {
        this.ks16aoicode = ks16aoicode;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
