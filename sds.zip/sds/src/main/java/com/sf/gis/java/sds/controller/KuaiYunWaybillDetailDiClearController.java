package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.KuaiYunWaybillDetailDi;
import com.sf.gis.java.sds.pojo.KuaiYunWaybillDetailDiFilter;
import com.sf.gis.java.sds.pojo.TcAoiRelationship;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


public class KuaiYunWaybillDetailDiClearController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(KuaiYunWaybillDetailDiClearController.class);

    public void start(String date) {
        //初始化spark
//        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
//        JavaSparkContext sc = sparkInfo.getContext();
//        SparkSession spark = sparkInfo.getSession();
        SparkSession spark = Spark.getSparkSession("KuaiYunWaybillDetailDiClearController",null,false,2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        String today = DateUtil.getDaysBefore(0, FixedConstant.DATE_FROMAT_YYYYMMDD_GAPLESS);
        logger.error("today:{}", today);

        logger.error("获取数据源");
        JavaRDD<KuaiYunWaybillDetailDi> kuaiYunWaybillDetailDiRdd = loadData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kuaiYunWaybillDetailDiRdd cnt:{}", kuaiYunWaybillDetailDiRdd.count());
        kuaiYunWaybillDetailDiRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("根据【citycode】+【keyword】进行去重");
        JavaRDD<KuaiYunWaybillDetailDi> distinctRdd = kuaiYunWaybillDetailDiRdd.mapToPair(o -> new Tuple2<>(o.getCitycode() + "_" + o.getKeyWord(), o)).groupByKey().map(tp -> {
            List<KuaiYunWaybillDetailDi> list = Lists.newArrayList(tp._2);
            KuaiYunWaybillDetailDi o = list.stream().sorted((o1, o2) -> o2.getStatDate().compareTo(o1.getStatDate())).collect(Collectors.toList()).get(0);
            return o;
        });
        logger.error("distinctRdd cnt:{}", distinctRdd.count());
        distinctRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        kuaiYunWaybillDetailDiRdd.unpersist();

        logger.error("获取tc有效表");
        JavaRDD<TcAoiRelationship> tcRdd = loadCodeData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tcRdd cnt:{}", tcRdd.count());
        tcRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<KuaiYunWaybillDetailDi> validTcRdd = distinctRdd.mapToPair(o -> new Tuple2<>(o.getTc(), o)).leftOuterJoin(tcRdd.mapToPair(o -> new Tuple2<>(o.getCode(), o)))
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("validTcRdd cnt:{}", validTcRdd.count());
        validTcRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        distinctRdd.unpersist();
        tcRdd.unpersist();

        logger.error("获取aoi有效表");
        JavaRDD<CmsAoiSch> cmsAoiSchRdd = getCmsAoiSch(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());
        cmsAoiSchRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<KuaiYunWaybillDetailDi> resultRdd = validTcRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        resultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        validTcRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        JavaRDD<TcAoiRelationship> aoiRelationshipRdd = getEmapEfsmsKyunit(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRelationshipRdd cnt:{}", aoiRelationshipRdd.count());

        JavaRDD<KuaiYunWaybillDetailDi> finalRdd = resultRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).leftOuterJoin(aoiRelationshipRdd.mapToPair(o -> new Tuple2<>(o.getAoi(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalRdd cnt:{}", finalRdd.count());
        resultRdd.unpersist();
        aoiRelationshipRdd.unpersist();

        //剔除数据打上标签和更新时间
        JavaPairRDD<String, KuaiYunWaybillDetailDiFilter> filterRdd = loadCodeFilterData(spark, sc, today).mapToPair(o -> new Tuple2<>(o.getCode(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());

        JavaRDD<KuaiYunWaybillDetailDi> lastRdd = finalRdd.mapToPair(o -> new Tuple2<>(o.getTc(), o)).leftOuterJoin(filterRdd).map(tp -> {
            KuaiYunWaybillDetailDi o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setOper_time(DateUtil.getTheTimeInSeconds());
                o.setOper("1");
            } else {
                o.setOper("0");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        finalRdd.unpersist();
        filterRdd.unpersist();


        logger.error("结果数据存储");
        saveData(spark, lastRdd,date);
        lastRdd.unpersist();
        spark.stop();
    }

    public JavaRDD<KuaiYunWaybillDetailDiFilter> loadCodeFilterData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("kuaiyun_wyabill_norm_di_kafka_filter.sql", date, date);
        logger.error("kuaiyun_wyabill_norm_di_kafka_filter sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KuaiYunWaybillDetailDiFilter.class);
    }


    public JavaRDD<TcAoiRelationship> getEmapEfsmsKyunit(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select aoi from dm_gis.emap_efsms_kyunit_relate_aoi_incday a lateral view explode(split(a.relate_aoi,'\\\\|')) r as aoi where inc_day = '%s' and tc_type = 'kytc'", date);
        logger.error("emap_efsms_kyunit_relate_aoi_incday sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TcAoiRelationship.class);
    }

    public void saveData(SparkSession spark, JavaRDD<KuaiYunWaybillDetailDi> inRdd,String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getMd5(), o.getCitycode(), o.getKeyWord(), o.getAoiid(), o.getAoiName(), o.getTc(), o.getStatus(), o.getStatDate(), o.getOper(), o.getOper_time(),date
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "md5", "citycode", "keyword", "aoiid", "aoiname", "tc", "status", "statdate", "oper", "oper_time","inc_day"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "kuaiyun_wyabill_norm_di" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.kuaiyun_wyabill_norm_di";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert overwrite table %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_name from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<KuaiYunWaybillDetailDi> loadData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select * from dm_gis.kuaiyun_wyabill_norm_di_from";
        logger.error("kuaiyun_wyabill_norm_di sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KuaiYunWaybillDetailDi.class);
    }

    public JavaRDD<TcAoiRelationship> loadCodeData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select code from dm_gis.emap_layer_feature where layer_id='3'";
        logger.error("emap_layer_feature sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TcAoiRelationship.class);
    }
}
