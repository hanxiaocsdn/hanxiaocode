package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class ProxyDept {
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String citycode;
    @Column(name = "way_bill_no")
    private String waybillno;
    @Column(name = "address")
    private String address;
    @Column(name = "log_gisdeptcode")
    private String log_gisdeptcode;
    @Column(name = "zonecode")
    private String zonecode;
    @Column(name = "xiaoge_no")
    private String xiaoge_no;
    @Column(name = "xiaoge_zonecode")
    private String xiaoge_zonecode;
    @Column(name = "gis_to_sys_src")
    private String gis_to_sys_src;
    @Column(name = "group_id")
    private String groupid;


    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLog_gisdeptcode() {
        return log_gisdeptcode;
    }

    public void setLog_gisdeptcode(String log_gisdeptcode) {
        this.log_gisdeptcode = log_gisdeptcode;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getXiaoge_no() {
        return xiaoge_no;
    }

    public void setXiaoge_no(String xiaoge_no) {
        this.xiaoge_no = xiaoge_no;
    }

    public String getXiaoge_zonecode() {
        return xiaoge_zonecode;
    }

    public void setXiaoge_zonecode(String xiaoge_zonecode) {
        this.xiaoge_zonecode = xiaoge_zonecode;
    }

    public String getGis_to_sys_src() {
        return gis_to_sys_src;
    }

    public void setGis_to_sys_src(String gis_to_sys_src) {
        this.gis_to_sys_src = gis_to_sys_src;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public ProxyDept(String inc_day, String citycode, String waybillno, String address, String log_gisdeptcode,
                     String zonecode, String xiaoge_no, String xiaoge_zonecode, String gis_to_sys_src, String groupid) {
        this.inc_day = inc_day;
        this.citycode = citycode;
        this.waybillno = waybillno;
        this.address = address;
        this.log_gisdeptcode = log_gisdeptcode;
        this.zonecode = zonecode;
        this.xiaoge_no = xiaoge_no;
        this.xiaoge_zonecode = xiaoge_zonecode;
        this.gis_to_sys_src = gis_to_sys_src;
        this.groupid = groupid;
    }

}
