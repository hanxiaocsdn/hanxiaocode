package com.sf.gis.java.sds.controller;

import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.GeometryUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CpaSrc;
import com.sf.gis.java.sds.pojo.CpaStat;
import com.sf.gis.java.sds.service.CpAnalysisService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;

/**
 * 竞品分析（analysis for competitive products，）（竞对位置数据挖掘）
 * @author 01370539 Created On: Jun.22 2021
 */
public class CpAnalysisController {
    private static final Logger logger = LoggerFactory.getLogger(CpAnalysisController.class);

    private static final CpAnalysisService cpaService = new CpAnalysisService();

    public void process(String cityCode, String startDate, String endDate, String isFromOrig) {
        logger.error("process start. cityCode - {}, startDate - {}, endDate - {}, isFromOrig - {}", cityCode, startDate, endDate, isFromOrig);
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        JavaRDD<CpaSrc> rddSrc = cpaService.loadSrcData(ss, jsc, cityCode, startDate, endDate, isFromOrig).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("startDate:{}, endDate: {}, data count: {}", startDate, endDate, rddSrc.count());

        JavaRDD<CpaSrc> rddNeedCal = rddSrc.filter(temp -> StringUtils.isNotEmpty(temp.getHashLatLng())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddNeedCal count: {}", rddNeedCal.count());
        rddSrc.unpersist();

        JavaPairRDD<String, Iterable<CpaSrc>> rddTpNeedCal = rddNeedCal.mapToPair(temp -> new Tuple2<>(temp.getDestDistCode() + "#" + temp.getDeliverAddress() + "#" + temp.getHashLatLng(), temp)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("after group by rddNeedCal, rddTpNeedCal count : {}", rddTpNeedCal.count());
        rddNeedCal.unpersist();

        JavaRDD<CpaStat> rddStatDetail = cpaService.calDetail(rddTpNeedCal).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddStat count that cal detail: {}.", rddStatDetail.count());
        rddTpNeedCal.unpersist();

        logger.error("after the first calculation, the stat count: {}, the detail count: {}", rddStatDetail.count(), rddStatDetail.flatMap(temp -> temp.getSubList().iterator()).count());

        JavaPairRDD<String, Iterable<CpaStat>> rddTpStat = rddStatDetail.mapToPair(temp -> new Tuple2<>(temp.getDestDistCode() + "#" + temp.getDeliverAddress(), temp)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddTpStat count : {}", rddTpStat.count());
        rddStatDetail.unpersist();

        JavaRDD<CpaStat> rddStatStat = cpaService.calStat(rddTpStat).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddStat count that cal stat: {}.", rddStatStat.count());
        rddTpStat.unpersist();

        JavaPairRDD<String, Object> rddFinal = rddStatStat.flatMapToPair(temp -> {
            LinkedList<LatLong> llList = new LinkedList<>(temp.getLlList());
            LatLong center = GeometryUtil.getCenter(llList);
            temp.setLat(String.valueOf(center.getLat()));
            temp.setLng(String.valueOf(center.getLon()));
            String id = DigestUtils.md5Hex(temp.getDestDistCode() + "#" + temp.getDeliverAddress() + "#" + temp.getLat() + "#" + temp.getLng());
            temp.setId(id);
            List<CpaSrc> csList = temp.getSubList();
            csList.forEach(cs -> cs.setId(id));
            List<Tuple2<String, Object>> result = new ArrayList<>();
            result.add(new Tuple2<>("detail", csList));
            result.add(new Tuple2<>("stat", temp));
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddFinal.take(2).forEach(tp -> logger.error("key : {}", tp._1));
        rddStatStat.unpersist();

        JavaRDD<CpaStat> rddStat = rddFinal.filter(tp -> "stat".equals(tp._1)).map(tp -> (CpaStat) tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CpaSrc> rddDetail = rddFinal.filter(tp -> "detail".equals(tp._1)).flatMap(tp -> ((List<CpaSrc>) tp._2).iterator()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("after the second calculation, the stat count: {}, the detail count: {}", rddStat.count(), rddDetail.count());
        rddFinal.unpersist();

        DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_cpa_stat", CpaStat.class, rddStat, "dest_dist_code");
        DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_cpa_mid", CpaSrc.class, rddDetail, "dest_dist_code");
        rddStat.unpersist();
        rddDetail.unpersist();

        logger.error("process end.");
    }
}
