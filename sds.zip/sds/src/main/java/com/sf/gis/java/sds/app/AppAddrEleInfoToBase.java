package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AddrEleInfoToBaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 需求方：李嘉欣
 * 需求名：【派件上楼】地址电梯信息入库
 * 任务id：666131
 */
public class AppAddrEleInfoToBase {
    private static Logger logger = LoggerFactory.getLogger(AppAddrEleInfoToBase.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String date2 = args[2];
        logger.error("startDate:{},endDate:{}, date2:{}", startDate, endDate, date2);
        logger.error("run start");
        new AddrEleInfoToBaseController().start(startDate, endDate, date2);
        logger.error("run end");
    }
}
