package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.SplitAoiNameCheckCleanAddr;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sf.gis.java.base.util.StringNumUtils.*;

/**
 * 任务id:807152(【壹竿-SD】拆分AOI名称校验清洗地址库)
 * 业务方：01394694（郭本婕）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月7日16:18:58
 */
public class AppSplitAoiNameCheckCleanAddr {
    private static Logger logger = LoggerFactory.getLogger(AppSplitAoiNameCheckCleanAddr.class);
    private static String url = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiId";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSplitAoiNameCheckCleanAddr");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        Set<String> county_set = new HashSet<>(sc.textFile("/user/01399581/upload/yunying_demand/data/county.csv").collect());
        logger.error("county_set size:{}", county_set.size());
        Broadcast<Set<String>> county_set_bc = sc.broadcast(county_set);

        Set<String> city_set = new HashSet<>(sc.textFile("/user/01399581/upload/yunying_demand/data/city.csv").collect());
        logger.error("city_set size:{}", city_set.size());
        Broadcast<Set<String>> city_set_bc = sc.broadcast(city_set);

        String sql = String.format("select\n" +
                "  t1.city_code city_code,\n" +
                "  t1.zno_code zno_code,\n" +
                "  t1.new_aoi_id new_aoi_id,\n" +
                "  t1.old_aoi_id old_aoi_id,\n" +
                "  t1.inc_day inc_day,\n" +
                "  t2.zc_aoi_name_list zc_aoi_name_list\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      city_code,\n" +
                "      zno_code,\n" +
                "      new_aoi_id,\n" +
                "      old_aoi_id,\n" +
                "      inc_day\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_change_task\n" +
                "    where\n" +
                "      inc_day = '%s' and date_format(create_date, 'yyyyMMdd') > '20230914'\n" +
                "      and del_flag = '0'\n" +
                "      and oper_type = 'S'\n" +
                "    group by\n" +
                "      city_code,\n" +
                "      zno_code,\n" +
                "      new_aoi_id,\n" +
                "      old_aoi_id,\n" +
                "      inc_day\n" +
                "  ) t1\n" +
                "  left join (\n" +
                "    select\n" +
                "      zno_code,\n" +
                "      concat_ws(',', collect_set(aoi_name)) zc_aoi_name_list\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_sch\n" +
                "    group by\n" +
                "      zno_code\n" +
                "  ) t2 on t1.zno_code = t2.zno_code", date);
        JavaRDD<SplitAoiNameCheckCleanAddr> rdd = DataUtil.loadData(spark, sc, sql, SplitAoiNameCheckCleanAddr.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String aoi_name_sql = "select aoi_id,aoi_name from dm_gis.cms_aoi_sch group by aoi_id,aoi_name";
        JavaPairRDD<String, String> aoiNameRdd = DataUtil.loadData(spark, sc, aoi_name_sql, CmsAoiSch.class).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o.getAoi_name())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiNameRdd cnt:{}", aoiNameRdd.count());

        JavaRDD<SplitAoiNameCheckCleanAddr> nameRdd = rdd.mapToPair(o -> new Tuple2<>(o.getNew_aoi_id(), o)).leftOuterJoin(aoiNameRdd).map(tp -> {
            SplitAoiNameCheckCleanAddr o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setNew_aoi_name(tp._2._2.get());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getOld_aoi_id(), o)).leftOuterJoin(aoiNameRdd).map(tp -> {
            SplitAoiNameCheckCleanAddr o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setOld_aoi_name(tp._2._2.get());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("nameRdd cnt:{}", nameRdd.count());
        rdd.unpersist();
        aoiNameRdd.unpersist();

        //获取addressid和address
        JavaRDD<SplitAoiNameCheckCleanAddr> addressRdd = nameRdd.mapPartitions(itr -> {
            Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
            Statement stmt = conn.createStatement();
            List<SplitAoiNameCheckCleanAddr> list = new ArrayList<>();
            try {
                while (itr.hasNext()) {
                    SplitAoiNameCheckCleanAddr o = itr.next();
                    String old_aoi_id = o.getOld_aoi_id();
                    String city_code = o.getCity_code();
                    if (StringUtils.isNotEmpty(old_aoi_id) && StringUtils.isNotEmpty(city_code)) {
                        String temp_sql = String.format("select address,address_id,adcode from cms_address_%s where city_code='%s' and aoi_id = '%s' group by address,address_id", cityDbPro.getProperty(city_code), city_code, old_aoi_id);
                        logger.info("temp_sql:{}", temp_sql);
                        if (StringUtils.isNotEmpty(temp_sql)) {
                            ResultSet rs = stmt.executeQuery(temp_sql);
                            List<SplitAoiNameCheckCleanAddr> temp_list = new ArrayList<>();
                            while (rs.next()) {
                                SplitAoiNameCheckCleanAddr newO = new SplitAoiNameCheckCleanAddr();
                                BeanUtils.copyProperties(newO, o);
                                String address = rs.getString("address");
                                String address_id = rs.getString("address_id");
                                String adcode = rs.getString("adcode");
                                newO.setAddress(address);
                                newO.setAddress_id(address_id);
                                newO.setAdcode(adcode);
                                temp_list.add(newO);
                            }
                            if (temp_list.size() > 0) {
                                list.addAll(temp_list);
                            } else {
                                list.add(o);
                            }
                        } else {
                            list.add(o);
                        }
                    } else {
                        list.add(o);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                stmt.close();
                conn.close();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addressRdd cnt:{}", addressRdd.count());

        String split_aoi_data_cleansing_c_sql = String.format("select groupid address_id from dm_gis.split_aoi_data_cleansing_c where inc_day between '20230801' and '%s' group by groupid", date);
        Map<String, Integer> map = DataUtil.loadData(spark, sc, split_aoi_data_cleansing_c_sql, SplitAoiNameCheckCleanAddr.class).collect().stream().collect(Collectors.toMap(SplitAoiNameCheckCleanAddr::getAddress_id, t -> 1, (key1, key2) -> key2));
        logger.error("map size:{}", map.size());
        Broadcast<Map<String, Integer>> mapBc = sc.broadcast(map);

        JavaRDD<SplitAoiNameCheckCleanAddr> filterRdd = addressRdd.filter(o -> {
            boolean flag = true;
            String address_id = o.getAddress_id();
            if (StringUtils.isNotEmpty(address_id)) {
                Map<String, Integer> value = mapBc.value();
                int orDefault = value.getOrDefault(address_id, 0);
                if (orDefault == 1) {
                    flag = false;
                }
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        addressRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> addressNewRdd = filterRdd.map(o -> {
            o.setAddress_new(processAddr(o.getAddress()));
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addressNewRdd cnt:{}", addressNewRdd.count());
        filterRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> positionRdd = addressNewRdd.filter(o -> {
            boolean flag = true;
            String address_new = o.getAddress_new();
            if (StringUtils.isNotEmpty(address_new) && (address_new.contains("对面") || address_new.contains("旁边") || address_new.contains("隔壁") || address_new.contains("后面") || address_new.contains("社区") || address_new.contains("附近") || address_new.contains("旁"))) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("positionRdd cnt:{}", positionRdd.count());
        addressNewRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> new_old_rdd = positionRdd.map(o -> {
            Set<String> temp_county_set = county_set_bc.value();
            Set<String> temp_city_set = city_set_bc.value();
            String new_name = processAoiName(o.getNew_aoi_name(), o.getAddress_new(), temp_county_set, temp_city_set);
            String old_name = processAoiName(o.getOld_aoi_name(), o.getAddress_new(), temp_county_set, temp_city_set);
            o.setNew_name(new_name);
            o.setOld_name(old_name);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("new_old_rdd cnt:{}", new_old_rdd.count());
        positionRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> filterEndWithRdd = new_old_rdd.filter(o -> {
            boolean flag = true;
            String new_aoi_name = o.getNew_aoi_name();
            if (StringUtils.isNotEmpty(new_aoi_name) && (new_aoi_name.endsWith("镇") || new_aoi_name.endsWith("工业园") || new_aoi_name.endsWith("工业区") || new_aoi_name.endsWith("物流园") || new_aoi_name.endsWith("产业园"))) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterEndWithRdd cnt:{}", filterEndWithRdd.count());
        new_old_rdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> containsRdd = filterEndWithRdd.filter(o -> {
            boolean flag = true;
            String new_name = o.getNew_name();
            String old_name = o.getOld_name();
            if (StringUtils.isNotEmpty(new_name) && StringUtils.isNotEmpty(old_name) && old_name.contains(new_name)) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("containsRdd cnt:{}", containsRdd.count());
        filterEndWithRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> lengthRdd = containsRdd.filter(o -> StringUtils.isNotEmpty(o.getNew_name()) && o.getNew_name().length() >= 3).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lengthRdd cnt:{}", lengthRdd.count());
        containsRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> cntRdd = lengthRdd.mapToPair(o -> new Tuple2<>(o.getOld_aoi_id(), o)).groupByKey().flatMap(tp -> {
            List<SplitAoiNameCheckCleanAddr> list = Lists.newArrayList(tp._2);
            List<String> newNameList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getNew_name())).map(SplitAoiNameCheckCleanAddr::getNew_name).distinct().collect(Collectors.toList());
            return list.stream().peek(o -> {
                String address_new = o.getAddress_new();
                int cnt = 0;
                if (StringUtils.isNotEmpty(address_new) && newNameList.size() > 0) {
                    for (String new_name : newNameList) {
                        if (address_new.contains(new_name)) {
                            ++cnt;
                        }
                    }
                }
                o.setCnt(cnt);
            }).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cntRdd cnt:{}", cntRdd.count());
        lengthRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> tagRdd = cntRdd.map(o -> {
            String tag = "";
            String address_new = o.getAddress_new();
            String new_name = o.getNew_name();
            String old_name = o.getOld_name();
            long cnt = o.getCnt();
            if (StringUtils.isNotEmpty(address_new) && StringUtils.isNotEmpty(new_name) && StringUtils.isNotEmpty(old_name) && address_new.contains(new_name) && !address_new.contains(old_name) && cnt == 1) {
                if (address_new.contains(new_name + "镇") && !address_new.endsWith("镇")) {
                    tag = "other";
                } else {
                    String zc_aoi_name_list = o.getZc_aoi_name_list();
                    long count = 0;
                    if (StringUtils.isNotEmpty(zc_aoi_name_list)) {
                        count = Arrays.stream(zc_aoi_name_list.split(",")).filter(t -> !StringUtils.equals(t, new_name)).filter(t -> t.startsWith(new_name)).count();
                    }
                    boolean matches = new_name.matches("[\\u4e00-\\u9fa5]+\\d+$");
                    if (count == 0 && !matches) {
                        tag = "contains";
                    } else {
                        tag = "other";
                    }
                }
            } else {
                String pre_new_name = (StringUtils.isNotEmpty(new_name) && new_name.length() >= 3) ? new_name.substring(0, 3) : "";
                String pre_old_name = (StringUtils.isNotEmpty(old_name) && old_name.length() >= 3) ? old_name.substring(0, 3) : "";
                if (StringUtils.isNotEmpty(address_new) && StringUtils.isNotEmpty(pre_new_name) && StringUtils.isNotEmpty(pre_old_name) && address_new.contains(pre_new_name) && !address_new.contains(pre_old_name) && !match(pre_new_name, ".*?镇")) {
                    tag = "pre_contains";
                } else {
                    String suffix_new_name = (StringUtils.isNotEmpty(new_name) && new_name.length() >= 3) ? new_name.substring(new_name.length() - 3, new_name.length()) : "";
                    String suffix_old_name = (StringUtils.isNotEmpty(old_name) && old_name.length() >= 3) ? old_name.substring(old_name.length() - 3, old_name.length()) : "";
                    if (StringUtils.isNotEmpty(address_new) && StringUtils.isNotEmpty(suffix_new_name) && StringUtils.isNotEmpty(suffix_old_name) && address_new.contains(suffix_new_name) && !address_new.contains(suffix_old_name) && !Arrays.asList("工业园,工业区,物流园,产业园,项目部,住宅区".split(",")).contains(suffix_new_name)) {
                        tag = "suffix_contains";
                    } else {
                        tag = "other";
                    }
                }
            }
            o.setTag(tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:{}", tagRdd.count());
        cntRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> eqContainsRdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "contains")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SplitAoiNameCheckCleanAddr> noEqContainsRdd = tagRdd.filter(o -> !StringUtils.equals(o.getTag(), "contains")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqContainsRdd cnt:{}", eqContainsRdd.count());
        logger.error("noEqContainsRdd cnt:{}", noEqContainsRdd.count());
        tagRdd.unpersist();

        JavaRDD<SplitAoiNameCheckCleanAddr> resultRdd = eqContainsRdd.repartition(10).map(o -> {
            String city_code = o.getCity_code();
            String address_id = o.getAddress_id();
            String new_aoi_id = o.getNew_aoi_id();
            if (StringUtils.isNotEmpty(address_id)) {
                JSONObject param = new JSONObject();
                param.put("cityCode", city_code);
                param.put("addressId", address_id);
                param.put("checkZnoCode", "1");
                param.put("aoiId", new_aoi_id);
                param.put("operSource", "拆分aoi修正_名称");
                param.put("operUserName", "01394694");
//                String content = HttpInvokeUtil.sendPost(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
//                o.setResp(content);
            }
            return o;
        }).union(noEqContainsRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        eqContainsRdd.unpersist();
        noEqContainsRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.aoi_change_name drop if EXISTS partition( inc_day='%s' )", date));
        DataUtil.saveOverwrite(spark, sc, "dm_gis.aoi_change_name", SplitAoiNameCheckCleanAddr.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();

    }

    public static String processAddr(String address) {
        if (StringUtils.isNotEmpty(address)) {
            return changeToSimpleChinese(outputArabNumberString(address.toLowerCase(), "[一二三四五六七八九]+"));
        }
        return "";
    }

    public static boolean match(String str, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    public static String processAoiName(String aoi_name, String address_new, Set<String> county_set, Set<String> city_set) {
        if (StringUtils.isNotEmpty(aoi_name)) {
            if (aoi_name.endsWith("(建设中)") || aoi_name.endsWith("（建设中）")) {
                aoi_name = aoi_name.replaceAll("(建设中)|（建设中）", "");
            }
            if (StringUtils.isNotEmpty(aoi_name)) {
                String regex = ".*?自治区|.*?省|.*?行政区|(有限责任公司|有限公司|发展有限公司|科技有限公司|股份有限公司|集团|有限公司厂区|公司厂区)$";
                aoi_name = aoi_name.replaceAll(regex, "");
                if (StringUtils.isNotEmpty(aoi_name)) {

                    for (String county : county_set) {
                        if (aoi_name.contains(county)) {
                            if (!(aoi_name.endsWith("区") && county.matches(".*?区"))) {
                                aoi_name = aoi_name.replace(county, "");
                            }
                            break;
                        }
                    }

                    for (String city : city_set) {
                        if (aoi_name.contains(city)) {
                            aoi_name = aoi_name.replace(city, "");
                            break;
                        }
                    }

                    if (StringUtils.isNotEmpty(aoi_name)) {
                        aoi_name = changeToSimpleChinese(outputArabNumberString(aoi_name.toLowerCase(), "[一二三四五六七八九]+"));
                        if (StringUtils.isNotEmpty(address_new) && StringUtils.isNotEmpty(aoi_name)) {
                            String address_pre = address_new.length() >= 2 ? address_new.substring(0, 2) : "";
                            String aoi_name_pre = aoi_name.length() >= 2 ? aoi_name.substring(0, 2) : "";
                            if (StringUtils.isNotEmpty(address_pre) && StringUtils.equals(address_pre, aoi_name_pre)) {
                                aoi_name = aoi_name.substring(2, aoi_name.length());
                            }
                        }
                    }
                }
            }
        }
        return aoi_name;
    }
}
