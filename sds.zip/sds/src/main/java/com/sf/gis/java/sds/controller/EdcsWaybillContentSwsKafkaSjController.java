package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.graph.aoi.common.util.KeyWordUtil;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.DimDeptInfoDf;
import com.sf.gis.java.sds.pojo.aoicompletion.*;
import com.sf.gis.java.sds.pojo.waybillaoi.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.pojo.waybillaoi.ScheduleWidthData;
import com.sf.gis.java.sds.pojo.waybillaoi.ZnocodeToAoi;
import com.sf.gis.java.sds.service.EdcsWaybillContentSwsKafkaService;
import com.sf.shiva.oms.csm.utils.NsCfgUtils;
import com.sf.shiva.oms.csm.utils.WaybillNoExtendUtils;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Table;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.Optional;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class EdcsWaybillContentSwsKafkaSjController implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(EdcsWaybillContentSwsKafkaSjController.class);
    EdcsWaybillContentSwsKafkaService service = new EdcsWaybillContentSwsKafkaService();
    private static final String ats = "http://gis-int.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&province=%s&cityName=%s&district=%s&city=%s&tel=%s&mobile=%s&company=%s&ak=2d56aff133e7456584abd3c1be674f0f&opt=zh&callDispatch=1&isNotUnderCall=%s&contacts=&customerAccount=%s";
    private static final String ks = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam";
    private static final String majorCode = "http://bdus-gw-apis.int.sfcloud.local:8000/bdus-api/employees/%s?fields=empNum,empName,majorCode";
    private static final String getAoiByXyUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/coord";

    private static final int limitMin = 30000 / 100;

    public void process(String date, String minDate) {

        //初始化spark
        SparkInfo si = SparkUtil.getSpark(this.getClass().getName());

        JavaPairRDD<String, GisRdsOmsto> rdsOmstoRdd = service.loadRdsOmstoPretreatmentAoiData(si).mapToPair(o -> new Tuple2<>(o.getReq_orderno(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmstoRdd cnt:{}", rdsOmstoRdd.count());

        JavaRDD<ScheduleWidthData> scheduleWidthDataRdd = service.loadScheduleWidthPretreatmentData(si, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataRdd cnt:{}", scheduleWidthDataRdd.count());

        JavaRDD<GisRdsOmsfrom> rdsOmsfromRdd = service.loadRdsOmsfromPretreatmentEmpCodeData(si, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmsfromRdd cnt:{}", rdsOmsfromRdd.count());

        JavaRDD<OrderWaybillHook> orderWaybillHookRdd = service.loadTtOrderWaybillPretreatmentData(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookRdd cnt:{}", orderWaybillHookRdd.count());

        JavaRDD<FvpCoreFactRouteRt> extsRdd = service.loadFvpCoreFactRouteRtExtsPretreatmentData(si, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("extsRdd cnt:{}", extsRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> sjRdd = service.loadData(si, date, minDate, "1", "")
                .filter(o -> !StringUtils.equals(o.getEmp_code(), "999999") && !StringUtils.equals(o.getEmp_code(), "00999999"))
                .map(o -> {
                    o.setOriginal_city_code(service.getCityCode(o.getOriginal_zone_code()));
                    o.setDestination_city_code(service.getCityCode(o.getDestination_zone_code()));
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sjRdd cnt:{}", sjRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafkaSj> sjTagAoiRdd = service.loadSjTagAoi(si, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sjTagAoiRdd cnt:{}", sjTagAoiRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> filterTagSjRdd = sjRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                .leftOuterJoin(sjTagAoiRdd.mapToPair(o -> new Tuple2<>(o.getOriginal_waybill_no(), o))).filter(tp -> {
                    boolean flag = true;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = false;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterTagSjRdd cnt:{}", filterTagSjRdd.count());
        sjRdd.unpersist();
        sjTagAoiRdd.unpersist();

        Properties operationInfo = ConfigurationUtil.loadProperties2("operationwaybillhbase.properties");
        logger.error("operationInfo:{}", operationInfo.toString());
        Broadcast<Properties> operationInfoBc = si.getContext().broadcast(operationInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> cityCodeRdd = filterTagSjRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = operationInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("opw" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getOperationWaybill(jsonList, tempList, "sj"));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getOperationWaybill(jsonList, tempList, "sj"));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityCodeRdd cnt:{}", cityCodeRdd.count());
        filterTagSjRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> decryptRdd = service.processAddr(si.getSession(), cityCodeRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("decryptRdd cnt:{}", decryptRdd.count());
        cityCodeRdd.unpersist();

        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤1处理:以运单号通过号段SDK判断运单是否为签回单 ☆☆☆☆☆☆☆☆☆☆");
        List<NsCfgDto> nsCfgList = service.getNsCfgList();
        logger.error("nsCfgList size:{}", nsCfgList.size());
        Broadcast<List<NsCfgDto>> nsCfgListBc = si.getContext().broadcast(nsCfgList);

        JavaRDD<EdcsWaybillContentSwsKafka> signReceiptRdd = decryptRdd.map(o -> {
            boolean cacheFlag = NsCfgUtils.cache(nsCfgListBc.value());
            logger.error("缓存返回标志:{}", cacheFlag);
            boolean signReceipt = WaybillNoExtendUtils.isSignReceipt(o.getWaybill_no());
            o.setSignReceipt(signReceipt);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("signReceiptRdd cnt:{}", signReceiptRdd.count());
        decryptRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> yesSignReceiptRdd = signReceiptRdd.filter(EdcsWaybillContentSwsKafka::isSignReceipt).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> noSignReceiptRdd = signReceiptRdd.filter(o -> !o.isSignReceipt()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("yesSignReceiptRdd cnt:{}", yesSignReceiptRdd.count());
        logger.error("noSignReceiptRdd cnt:{}", noSignReceiptRdd.count());
        signReceiptRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> noEmpSourceWabillRdd = yesSignReceiptRdd.filter(o -> StringUtils.isNotEmpty(o.getSourceWaybillNo())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> empSourceWabillRdd = yesSignReceiptRdd.filter(o -> StringUtils.isEmpty(o.getSourceWaybillNo())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpSourceWabillRdd cnt:{}", noEmpSourceWabillRdd.count());
        logger.error("empSourceWabillRdd cnt:{}", empSourceWabillRdd.count());
        yesSignReceiptRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> orderNoRdd = noEmpSourceWabillRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = operationInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("opw" + "_" + o.getSourceWaybillNo(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getOrderNo(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getOrderNo(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderNoRdd cnt:{}", orderNoRdd.count());
        noEmpSourceWabillRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdSourceWaybillRdd = orderNoRdd.mapToPair(o -> new Tuple2<>(o.getOrderNo(), o))
                .leftOuterJoin(rdsOmstoRdd).map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    String original_zone_code = o.getOriginal_zone_code();
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        GisRdsOmsto gisRdsOmsto = tp._2._2.get();
                        String finalzc = gisRdsOmsto.getFinalzc();
                        if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, finalzc)) {
                            String finalaoiid = gisRdsOmsto.getFinalaoiid();
                            if (StringUtils.isNotEmpty(finalaoiid)) {
                                o.setLastAoiid(finalaoiid);
                                o.setTag("aoi_id_source_waybill");
                            }
                        }
                    }
                    return o;
                }).union(empSourceWabillRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdSourceWaybillRdd cnt:{}", aoiIdSourceWaybillRdd.count());
        orderNoRdd.unpersist();
        rdsOmstoRdd.unpersist();
        empSourceWabillRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdSourceWaybillAoiRdd = aoiIdSourceWaybillRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdSourceWaybillEmpAoiRdd = aoiIdSourceWaybillRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdSourceWaybillAoiRdd cnt:{}", aoiIdSourceWaybillAoiRdd.count());
        logger.error("aoiIdSourceWaybillEmpAoiRdd cnt:{}", aoiIdSourceWaybillEmpAoiRdd.count());
        aoiIdSourceWaybillRdd.unpersist();

        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤2处理:调at和ks ☆☆☆☆☆☆☆☆☆☆");
        JavaRDD<EdcsWaybillContentSwsKafka> atsRdd = noSignReceiptRdd.union(aoiIdSourceWaybillEmpAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atsRdd cnt:{}", atsRdd.count());
        noSignReceiptRdd.unpersist();
        aoiIdSourceWaybillEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> noEmpAddrAtsRdd = atsRdd.filter(o -> StringUtils.isNotEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> empAddrAtsRdd = atsRdd.filter(o -> StringUtils.isEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpAddrAtsRdd cnt:{}", noEmpAddrAtsRdd.count());
        logger.error("empAddrAtsRdd cnt:{}", empAddrAtsRdd.count());
        atsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> atsAoiIdTcRdd = noEmpAddrAtsRdd.repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<EdcsWaybillContentSwsKafka> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                EdcsWaybillContentSwsKafka o = itr.next();
                String aoi = service.getAtsAoi(ats, o);
                if (StringUtils.isNotEmpty(aoi)) {
                    o.setLastAoiid(aoi);
                    o.setTag("aoi_id_tc");
                }
                list.add(o);
            }
            return list.iterator();
        }).union(empAddrAtsRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atsAoiIdTcRdd cnt:{}", atsAoiIdTcRdd.count());
        noEmpAddrAtsRdd.unpersist();
        empAddrAtsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> atsAoiIdTcAoiRdd = atsAoiIdTcRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> atsAoiIdTcEmpAoiRdd = atsAoiIdTcRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atsAoiIdTcAoiRdd cnt:{}", atsAoiIdTcAoiRdd.count());
        logger.error("atsAoiIdTcEmpAoiRdd cnt:{}", atsAoiIdTcEmpAoiRdd.count());
        atsAoiIdTcRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd1 = aoiIdSourceWaybillAoiRdd.union(atsAoiIdTcAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd1 cnt:{}", rdd1.count());
        aoiIdSourceWaybillAoiRdd.unpersist();
        atsAoiIdTcAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> noEmpAddrKsRdd = atsAoiIdTcEmpAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getAddr()) && StringUtils.isNotEmpty(o.getCityCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> empAddrKsRdd = atsAoiIdTcEmpAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getAddr()) && StringUtils.isNotEmpty(o.getCityCode()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpAddrKsRdd cnt:{}", noEmpAddrKsRdd.count());
        logger.error("empAddrKsRdd cnt:{}", empAddrKsRdd.count());
        atsAoiIdTcEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> ksAoiIdTcRdd = noEmpAddrKsRdd.repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<EdcsWaybillContentSwsKafka> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                EdcsWaybillContentSwsKafka o = itr.next();
                String aoi = service.getKsAoi(ks, o);
                if (StringUtils.isNotEmpty(aoi)) {
                    o.setLastAoiid(aoi);
                    o.setTag("aoi_id_tc");
                }
                list.add(o);
            }
            return list.iterator();
        }).union(empAddrKsRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ksAoiIdTcRdd cnt:{}", ksAoiIdTcRdd.count());
        noEmpAddrKsRdd.unpersist();
        empAddrKsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> ksAoiIdTcAoiRdd = ksAoiIdTcRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> ksAoiIdTcEmpAoiRdd = ksAoiIdTcRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).map(o -> {
            String emp_code = o.getEmp_code();
            if (StringUtils.isNotEmpty(emp_code)) {
                emp_code = service.processTakeoverMemberNo(emp_code);
                o.setEmp_code(emp_code);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ksAoiIdTcAoiRdd cnt:{}", ksAoiIdTcAoiRdd.count());
        logger.error("ksAoiIdTcEmpAoiRdd cnt:{}", ksAoiIdTcEmpAoiRdd.count());
        ksAoiIdTcRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd2 = rdd1.union(ksAoiIdTcAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd2 cnt:{}", rdd2.count());
        rdd1.unpersist();
        ksAoiIdTcAoiRdd.unpersist();

        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤3处理:获取员工岗位主岗 ☆☆☆☆☆☆☆☆☆☆");
        String before1Date = DateUtil.getDaysBefore(date, 1);
        logger.error("before1Date:{}", before1Date);
        JavaRDD<EmpInfoDtlDf> empInfoDtlDfRdd = service.loadEmpInfoAll(si, before1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empInfoDtlDfRdd cnt:{}", empInfoDtlDfRdd.count());

        JavaPairRDD<String, EmpInfoDtlDf> empInfoDtlDfXzRdd = empInfoDtlDfRdd.filter(o -> StringUtils.equals(o.getPosition_name(), "协助员")).mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empInfoDtlDfXzRdd cnt:{}", empInfoDtlDfXzRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzRdd = ksAoiIdTcEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(empInfoDtlDfXzRdd).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                EmpInfoDtlDf empInfoDtlDf = tp._2._2.get();
                o.setPosition_name(empInfoDtlDf.getPosition_name());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("positionNameXzRdd cnt:{}", positionNameXzRdd.count());
        ksAoiIdTcEmpAoiRdd.unpersist();
        empInfoDtlDfXzRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzNoEmpRdd = positionNameXzRdd.filter(o -> StringUtils.equals(o.getPosition_name(), "协助员")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzEmpRdd = positionNameXzRdd.filter(o -> !StringUtils.equals(o.getPosition_name(), "协助员")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("positionNameXzNoEmpRdd cnt:{}", positionNameXzNoEmpRdd.count());
        logger.error("positionNameXzEmpRdd cnt:{}", positionNameXzEmpRdd.count());
        positionNameXzRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> majorCodeRdd = positionNameXzNoEmpRdd.map(o -> {
            String emp_code = o.getEmp_code();
            if (StringUtils.isNotEmpty(emp_code)) {
                String req = String.format(majorCode, emp_code);
                String content = service.doGet(req, "6265fafb263ab0e4cab9513e");
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        String majorCode = jsonObject.getString("majorCode");
                        logger.error("majorCode:{}", majorCode);
                        if (StringUtils.isNotEmpty(majorCode)) {
                            majorCode = service.processTakeoverMemberNo(majorCode);
                            o.setEmp_code(majorCode);
                        }
                    }
                }
            }
            return o;
        }).union(positionNameXzEmpRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("majorCodeRdd cnt:{}", majorCodeRdd.count());
        positionNameXzNoEmpRdd.unpersist();
        positionNameXzEmpRdd.unpersist();

        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤4处理:关联排班表 ☆☆☆☆☆☆☆☆☆☆");

        JavaRDD<ScheduleWidthData> scheduleWidthDataSizeRdd = scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).groupByKey().map(tp -> {
            List<ScheduleWidthData> list = Lists.newArrayList(tp._2);
            ScheduleWidthData scheduleWidthData = list.get(0);
            List<ScheduleWidthData> distinctList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ScheduleWidthData::getAoi_id))), ArrayList::new));
            int size = distinctList.size();
            if (size >= 1) {
                List<CmsAoiSch> cmsAoiSchList = distinctList.stream().map(o -> {
                    CmsAoiSch cmsAoiSch = new CmsAoiSch();

                    cmsAoiSch.setAoi_id(o.getAoi_id());
                    cmsAoiSch.setDept_code(o.getDept_code());
                    cmsAoiSch.setAoi_name(o.getAoi_name());
                    cmsAoiSch.setJiti(o.getPick_jiti());
                    cmsAoiSch.setAoi_count(o.getAoi_count());
                    return cmsAoiSch;
                }).collect(Collectors.toList());
                scheduleWidthData.setList(cmsAoiSchList);
            }
            scheduleWidthData.setAoi_size(size);
            return scheduleWidthData;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataSizeRdd cnt:{}", scheduleWidthDataSizeRdd.count());
//        scheduleWidthDataRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> majorCodeScheduleWidthRdd = majorCodeRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(scheduleWidthDataSizeRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o))).map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        ScheduleWidthData scheduleWidthData = tp._2._2.get();
                        o.setAoi_size(scheduleWidthData.getAoi_size());
                        o.setList(scheduleWidthData.getList());
                    } else {
                        o.setTag("no_consignee_emp");
                    }
                    return o;
                }).map(o -> {
                    String takeover_tm = o.getTakeover_tm();
                    if (StringUtils.isNotEmpty(takeover_tm)) {
                        String barscantmstd = DateUtil.dateToStamp(takeover_tm);
                        long barscantmstdL = Long.parseLong(barscantmstd);
                        long before = barscantmstdL - 10 * 60 * 1000;
                        long after = barscantmstdL + 10 * 60 * 1000;

                        o.setBarscantmstd(barscantmstd);
                        o.setBefore10min(before + "");
                        o.setAfter10min(after + "");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("majorCodeScheduleWidthRdd cnt:{}", majorCodeScheduleWidthRdd.count());
        majorCodeRdd.unpersist();
        scheduleWidthDataSizeRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiSizeEq1Rdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() == 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiSizeGt1Rdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() > 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> otherRdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() == 0).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiSizeEq1Rdd cnt:{}", aoiSizeEq1Rdd.count());
        logger.error("aoiSizeGt1Rdd cnt:{}", aoiSizeGt1Rdd.count());
        logger.error("otherRdd cnt:{}", otherRdd.count());
        majorCodeScheduleWidthRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueRdd = aoiSizeEq1Rdd.map(o -> {
            CmsAoiSch cmsAoiSch = o.getList().get(0);
            String original_zone_code = o.getOriginal_zone_code();
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, cmsAoiSch.getDept_code())) {
                o.setLastAoiid(cmsAoiSch.getAoi_id());
                o.setTag("aoi_id_unique");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdUniqueRdd cnt:{}", aoiIdUniqueRdd.count());
        aoiSizeEq1Rdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueAoiRdd = aoiIdUniqueRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueEmpAoiRdd = aoiIdUniqueRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdUniqueAoiRdd cnt:{}", aoiIdUniqueAoiRdd.count());
        logger.error("aoiIdUniqueEmpAoiRdd cnt:{}", aoiIdUniqueEmpAoiRdd.count());
        aoiIdUniqueRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd3 = rdd2.union(aoiIdUniqueAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd3 cnt:{}", rdd3.count());
        rdd2.unpersist();
        aoiIdUniqueAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeRdd = aoiSizeGt1Rdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(rdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            String before10min = o.getBefore10min();
            String after10min = o.getAfter10min();
            String barscantmstd = o.getBarscantmstd();
            String original_zone_code = o.getOriginal_zone_code();
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<GisRdsOmsfrom> list = Lists.newArrayList(tp._2._2.get());
                list = list.stream().filter(t -> {
                    boolean flag = false;
                    String reqtimetm = t.getReqtimetm();
                    if (StringUtils.isNotEmpty(reqtimetm) && StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min)) {
                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                            flag = true;
                        }
                    }
                    return flag;
                }).collect(Collectors.toList());

                List<GisRdsOmsfrom> gtList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) < Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                List<GisRdsOmsfrom> ltList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) > Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                String gt_aoi = "";
                String lt_aoi = "";
                String dept_code = "";
                if (gtList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = gtList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0);
                    gt_aoi = gisRdsOmsfrom.getAoi_id();
                    dept_code = gisRdsOmsfrom.getDeptcode();
                }
                if (ltList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = ltList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0);
                    lt_aoi = gisRdsOmsfrom.getAoi_id();
                }
                if (StringUtils.isNotEmpty(gt_aoi) && StringUtils.equals(gt_aoi, lt_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, dept_code)) {
                    o.setLastAoiid(gt_aoi);
                    o.setTag("aoi_id_54_time");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeRdd cnt:{}", aoiId54TimeRdd.count());
        aoiSizeGt1Rdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeAoiRdd = aoiId54TimeRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeEmpAoiRdd = aoiId54TimeRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeAoiRdd cnt:{}", aoiId54TimeAoiRdd.count());
        logger.error("aoiId54TimeEmpAoiRdd cnt:{}", aoiId54TimeEmpAoiRdd.count());
        aoiId54TimeRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd4 = rdd3.union(aoiId54TimeAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd4 cnt:{}", rdd4.count());
        rdd3.unpersist();
        aoiId54TimeAoiRdd.unpersist();

        Properties bizlogsjInfo = ConfigurationUtil.loadProperties2("bizlogsjhbase.properties");
        logger.error("bizlogsjInfo:{}", bizlogsjInfo.toString());
        Broadcast<Properties> bizlogsjInfoBc = si.getContext().broadcast(bizlogsjInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> eventXyRdd = aoiId54TimeEmpAoiRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = bizlogsjInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("sks" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getEventlngXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getEventlngXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eventXyRdd cnt:{}", eventXyRdd.count());
        aoiId54TimeEmpAoiRdd.unpersist();

        Properties ttappointadditionInfo = ConfigurationUtil.loadProperties2("ttappointadditionhbase.properties");
        logger.error("ttappointadditionInfo:{}", ttappointadditionInfo.toString());
        Broadcast<Properties> ttappointadditionInfoBc = si.getContext().broadcast(ttappointadditionInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> srcXyRdd = eventXyRdd.filter(o -> StringUtils.isNotEmpty(o.getWaybillnoOrderNo())).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = ttappointadditionInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("taa" + "_" + o.getWaybillnoOrderNo(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getSrcXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getSrcXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).union(eventXyRdd.filter(o -> StringUtils.isEmpty(o.getWaybillnoOrderNo()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("srcXyRdd cnt:{}", srcXyRdd.count());
        eventXyRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordRdd = srcXyRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            String eventlng = o.getEventlng();
            String eventlat = o.getEventlat();
            String event_aoiAndzc = "";

            String src_lgt = o.getSrc_lgt();
            String src_lat = o.getSrc_lat();
            String src_aoiAndzc = "";

            if (StringUtils.isNotEmpty(eventlng) && StringUtils.isNotEmpty(eventlat)) {
                event_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, eventlng, eventlat);
            }
            if (StringUtils.isNotEmpty(src_lgt) && StringUtils.isNotEmpty(src_lat)) {
                src_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, src_lgt, src_lat);
            }
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(event_aoiAndzc) && event_aoiAndzc.split(",").length == 2
                    && StringUtils.isNotEmpty(src_aoiAndzc) && src_aoiAndzc.split(",").length == 2 && StringUtils.equals(event_aoiAndzc.split(",")[0], src_aoiAndzc.split(",")[0]) && StringUtils.equals(event_aoiAndzc.split(",")[1], original_zone_code)) {
                o.setLastAoiid(event_aoiAndzc.split(",")[0]);
                o.setTag("aoi_id_54_coord");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordRdd cnt:{}", aoiId54CoordRdd.count());
        srcXyRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordAoiRdd = aoiId54CoordRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordEmpAoiRdd = aoiId54CoordRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordAoiRdd cnt:{}", aoiId54CoordAoiRdd.count());
        logger.error("aoiId54CoordEmpAoiRdd cnt:{}", aoiId54CoordEmpAoiRdd.count());
        aoiId54CoordRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd5 = rdd4.union(aoiId54CoordAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd5 cnt:{}", rdd5.count());
        rdd4.unpersist();
        aoiId54CoordAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsRdd = aoiId54CoordEmpAoiRdd.map(o -> {
            String addr = o.getAddr();
            String original_zone_code = o.getOriginal_zone_code();
            if (StringUtils.isNotEmpty(addr)) {
                List<CmsAoiSch> list = o.getList();
                for (CmsAoiSch cmsAoiSch : list) {
                    String aoi_name = cmsAoiSch.getAoi_name();
                    if (StringUtils.isNotEmpty(aoi_name) && addr.contains(aoi_name)) {
                        String aoi_id = cmsAoiSch.getAoi_id();
                        String dept_code = cmsAoiSch.getDept_code();
                        if (StringUtils.isNotEmpty(aoi_id) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(dept_code, original_zone_code)) {
                            o.setLastAoiid(aoi_id);
                            o.setTag("similar");
                            break;
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarContainsRdd cnt:{}", similarContainsRdd.count());
        aoiId54CoordEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsAoiRdd = similarContainsRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsEmpAoiRdd = similarContainsRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarContainsAoiRdd cnt:{}", similarContainsAoiRdd.count());
        logger.error("similarContainsEmpAoiRdd cnt:{}", similarContainsEmpAoiRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> rdd6 = rdd5.union(similarContainsAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd6 cnt:{}", rdd6.count());
        rdd5.unpersist();
        similarContainsAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameRdd = similarContainsEmpAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getAddr())).repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                String addr = o.getAddr();
                String original_zone_code = o.getOriginal_zone_code();
                List<CmsAoiSch> list = o.getList().stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_name()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getAoi_name))), ArrayList::new));
                for (CmsAoiSch cmsAoiSch : list) {
                    String aoi_name = cmsAoiSch.getAoi_name();
                    double similarity = KeyWordUtil.similarity(addr, aoi_name);
                    cmsAoiSch.setSimilarity(similarity + "");
                }
                List<CmsAoiSch> sortList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7 && StringUtils.isNotEmpty(t.getDept_code()) && StringUtils.equals(t.getDept_code(), original_zone_code))
                        .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                        .collect(Collectors.toList());

                if (sortList.size() > 0) {
                    CmsAoiSch cmsAoiSch = sortList.get(0);
                    String aoi_id = cmsAoiSch.getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("similar");
                    }
                }
                result.add(o);
            }
            return result.iterator();
        }).union(similarContainsEmpAoiRdd.filter(o -> StringUtils.isEmpty(o.getAddr()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarAddrAoiNameRdd cnt:{}", similarAddrAoiNameRdd.count());
        similarContainsEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameAoiRdd = similarAddrAoiNameRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameEmpAoiRdd = similarAddrAoiNameRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarAddrAoiNameAoiRdd cnt:{}", similarAddrAoiNameAoiRdd.count());
        logger.error("similarAddrAoiNameEmpAoiRdd cnt:{}", similarAddrAoiNameEmpAoiRdd.count());
        similarAddrAoiNameRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd7 = rdd6.union(similarAddrAoiNameAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd7 cnt:{}", rdd7.count());
        rdd6.unpersist();
        similarAddrAoiNameAoiRdd.unpersist();

        JavaRDD<ZnocodeToAoi> znocodeToAoiRdd = service.loadZnocodeToAoi(si, before1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("znocodeToAoiRdd cnt:{}", znocodeToAoiRdd.count());

        JavaRDD<TmDepartment> tmDepartmentRdd = service.loadTmDepartment(si, before1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tmDepartmentRdd cnt:{}", tmDepartmentRdd.count());

        JavaRDD<EmapLayerFeatureCmsemap> emapLayerFeatureCmsemapRdd = service.loadEmapLayer(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("emapLayerFeatureCmsemapRdd cnt:{}", emapLayerFeatureCmsemapRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> supPositionNameRdd = service.joinPositionName(similarAddrAoiNameEmpAoiRdd, tmDepartmentRdd, empInfoDtlDfRdd, emapLayerFeatureCmsemapRdd, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("supPositionNameRdd cnt:{}", supPositionNameRdd.count());
        similarAddrAoiNameEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransRdd = service.joinZnocodeToAoi(supPositionNameRdd, znocodeToAoiRdd, getAoiByXyUrl, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransRdd cnt:{}", zcAndTransRdd.count());
        supPositionNameRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransAoiRdd = zcAndTransRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransEmpAoiRdd = zcAndTransRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransAoiRdd cnt:{}", zcAndTransAoiRdd.count());
        logger.error("zcAndTransEmpAoiRdd cnt:{}", zcAndTransEmpAoiRdd.count());
        zcAndTransRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd8 = rdd7.union(zcAndTransAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd8 cnt:{}", rdd8.count());
        rdd7.unpersist();
        zcAndTransAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomRdd = zcAndTransEmpAoiRdd.map(o -> {
            List<CmsAoiSch> list = o.getList();
            if (list.size() > 0) {
                ArrayList<CmsAoiSch> uniqueList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getJiti()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getJiti))), ArrayList::new));
                if (uniqueList.size() == 1) {
                    String aoi_id = uniqueList.get(0).getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("aoi_id_random");
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdRandomRdd cnt:{}", aoiIdRandomRdd.count());
        zcAndTransEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomAoiRdd = aoiIdRandomRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomEmpAoiRdd = aoiIdRandomRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdRandomAoiRdd cnt:{}", aoiIdRandomAoiRdd.count());
        logger.error("aoiIdRandomEmpAoiRdd cnt:{}", aoiIdRandomEmpAoiRdd.count());
        aoiIdRandomRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd9 = rdd8.union(aoiIdRandomAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd9 cnt:{}", rdd9.count());
        rdd8.unpersist();
        aoiIdRandomAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatRdd = aoiIdRandomEmpAoiRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            List<CmsAoiSch> list = o.getList();
            if (list.size() > 0) {
                List<CmsAoiSch> aoiCountList = list.stream()
                        .filter(t -> StringUtils.isNotEmpty(t.getDept_code()) && StringUtils.equals(original_zone_code, t.getDept_code()) && StringUtils.isNotEmpty(t.getAoi_count()))
                        .sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
                if (aoiCountList.size() > 0) {
                    String aoi_id = aoiCountList.get(0).getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("aoi_id_stat");
                    }
                } else {
                    o.setTag("no_stat");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatRdd cnt:{}", aoiIdStatRdd.count());
        aoiIdRandomEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatAoiRdd = aoiIdStatRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatEmpAoiRdd = aoiIdStatRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatAoiRdd cnt:{}", aoiIdStatAoiRdd.count());
        logger.error("aoiIdStatEmpAoiRdd cnt:{}", aoiIdStatEmpAoiRdd.count());
        aoiIdStatRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd10 = rdd9.union(aoiIdStatAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd10 cnt:{}", rdd10.count());
        rdd9.unpersist();
        aoiIdStatAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleRdd = otherRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(rdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            String before10min = o.getBefore10min();
            String after10min = o.getAfter10min();
            String barscantmstd = o.getBarscantmstd();
            String original_zone_code = o.getOriginal_zone_code();
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<GisRdsOmsfrom> list = Lists.newArrayList(tp._2._2.get());
                list = list.stream().filter(t -> {
                    boolean flag = false;
                    String reqtimetm = t.getReqtimetm();
                    if (StringUtils.isNotEmpty(reqtimetm) && StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min)) {
                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                            flag = true;
                        }
                    }
                    return flag;
                }).collect(Collectors.toList());

                List<GisRdsOmsfrom> gtList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) < Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                List<GisRdsOmsfrom> ltList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) > Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                String gt_aoi = "";
                String lt_aoi = "";
                String dept_code = "";
                if (gtList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = gtList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0);
                    gt_aoi = gisRdsOmsfrom.getAoi_id();
                    dept_code = gisRdsOmsfrom.getDeptcode();
                }
                if (ltList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = ltList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0);
                    lt_aoi = gisRdsOmsfrom.getAoi_id();
                }
                if (StringUtils.isNotEmpty(gt_aoi) && StringUtils.equals(gt_aoi, lt_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, dept_code)) {
                    o.setLastAoiid(gt_aoi);
                    o.setTag("aoi_id_54_time_no_schedule");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleRdd cnt:{}", aoiId54TimeNoScheduleRdd.count());
        otherRdd.unpersist();
        rdsOmsfromRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleAoiRdd = aoiId54TimeNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiRdd = aoiId54TimeNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleAoiRdd cnt:{}", aoiId54TimeNoScheduleAoiRdd.count());
        logger.error("aoiId54TimeNoScheduleEmpAoiRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiRdd.count());
        aoiId54TimeNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd11 = rdd10.union(aoiId54TimeNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd11 cnt:{}", rdd11.count());
        rdd10.unpersist();
        aoiId54TimeNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiEventXyRdd = aoiId54TimeNoScheduleEmpAoiRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = bizlogsjInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("sks" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getEventlngXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getEventlngXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleEmpAoiEventXyRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiEventXyRdd.count());
        aoiId54TimeNoScheduleEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiSrcXyRdd = aoiId54TimeNoScheduleEmpAoiEventXyRdd.filter(o -> StringUtils.isNotEmpty(o.getWaybillnoOrderNo())).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = ttappointadditionInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("taa" + "_" + o.getWaybillnoOrderNo(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getSrcXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getSrcXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).union(aoiId54TimeNoScheduleEmpAoiEventXyRdd.filter(o -> StringUtils.isEmpty(o.getWaybillnoOrderNo()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleEmpAoiSrcXyRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiSrcXyRdd.count());
        aoiId54TimeNoScheduleEmpAoiEventXyRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleRdd = aoiId54TimeNoScheduleEmpAoiSrcXyRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            String eventlng = o.getEventlng();
            String eventlat = o.getEventlat();
            String event_aoiAndzc = "";

            String src_lgt = o.getSrc_lgt();
            String src_lat = o.getSrc_lat();
            String src_aoiAndzc = "";

            if (StringUtils.isNotEmpty(eventlng) && StringUtils.isNotEmpty(eventlat)) {
                event_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, eventlng, eventlat);
            }
            if (StringUtils.isNotEmpty(src_lgt) && StringUtils.isNotEmpty(src_lat)) {
                src_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, src_lgt, src_lat);
            }
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(event_aoiAndzc) && StringUtils.isNotEmpty(src_aoiAndzc) && event_aoiAndzc.split(",").length == 2 && src_aoiAndzc.split(",").length == 2
                    && StringUtils.equals(event_aoiAndzc.split(",")[0], src_aoiAndzc.split(",")[0]) && StringUtils.equals(event_aoiAndzc.split(",")[1], original_zone_code)) {
                o.setLastAoiid(event_aoiAndzc.split(",")[0]);
                o.setTag("aoi_id_54_coord_no_schedule");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleRdd cnt:{}", aoiId54CoordNoScheduleRdd.count());
        aoiId54TimeNoScheduleEmpAoiSrcXyRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleAoiRdd = aoiId54CoordNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleEmpAoiRdd = aoiId54CoordNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleAoiRdd cnt:{}", aoiId54CoordNoScheduleAoiRdd.count());
        logger.error("aoiId54CoordNoScheduleEmpAoiRdd cnt:{}", aoiId54CoordNoScheduleEmpAoiRdd.count());
        aoiId54CoordNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd12 = rdd11.union(aoiId54CoordNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd12 cnt:{}", rdd12.count());
        rdd11.unpersist();
        aoiId54CoordNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd = service.joinPositionName(aoiId54CoordNoScheduleEmpAoiRdd, tmDepartmentRdd, empInfoDtlDfRdd, emapLayerFeatureCmsemapRdd, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd cnt:{}", aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd.count());
        aoiId54CoordNoScheduleEmpAoiRdd.unpersist();
        tmDepartmentRdd.unpersist();
        emapLayerFeatureCmsemapRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleRdd = service.joinZnocodeToAoi(aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd, znocodeToAoiRdd, getAoiByXyUrl, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransNoScheduleRdd cnt:{}", zcAndTransNoScheduleRdd.count());
        aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd.unpersist();
        znocodeToAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleAoiRdd = zcAndTransNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleEmpAoiRdd = zcAndTransNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransNoScheduleAoiRdd cnt:{}", zcAndTransNoScheduleAoiRdd.count());
        logger.error("zcAndTransNoScheduleEmpAoiRdd cnt:{}", zcAndTransNoScheduleEmpAoiRdd.count());
        zcAndTransNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd13 = rdd12.union(zcAndTransNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd13 cnt:{}", rdd13.count());
        rdd12.unpersist();
        zcAndTransNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleRdd = zcAndTransNoScheduleEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(orderWaybillHookRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey())
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    String addr = o.getAddr();
                    String original_zone_code = o.getOriginal_zone_code();
                    if (StringUtils.isNotEmpty(addr)) {
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<OrderWaybillHook> list = Lists.newArrayList(tp._2._2.get()).stream()
                                    .filter(t -> StringUtils.isNotEmpty(t.getAoi_zc()) && StringUtils.equals(t.getAoi_zc(), original_zone_code))
                                    .collect(Collectors.toList());
                            String last_aoi = "";
                            for (OrderWaybillHook orderWaybillHook : list) {
                                String aoi_name = orderWaybillHook.getAoi_name();
                                if (StringUtils.isNotEmpty(aoi_name) && addr.contains(aoi_name)) {
                                    last_aoi = orderWaybillHook.getAoi_id();
                                    break;
                                }
                            }
                            if (StringUtils.isNotEmpty(last_aoi)) {
                                o.setLastAoiid(last_aoi);
                                o.setTag("similar_no_schedule");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarNoScheduleRdd cnt:{}", similarNoScheduleRdd.count());
        zcAndTransNoScheduleEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleAoiRdd = similarNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleEmpAoiRdd = similarNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarNoScheduleAoiRdd cnt:{}", similarNoScheduleAoiRdd.count());
        logger.error("similarNoScheduleEmpAoiRdd cnt:{}", similarNoScheduleEmpAoiRdd.count());
        similarNoScheduleRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleRdd = similarNoScheduleEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(orderWaybillHookRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey(), SysConstant.PARTITION_COUNT)
                .mapPartitions(itr -> {
                    List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
                    while (itr.hasNext()) {
                        Tuple2<String, Tuple2<EdcsWaybillContentSwsKafka, Optional<Iterable<OrderWaybillHook>>>> tp = itr.next();
                        EdcsWaybillContentSwsKafka o = tp._2._1;
                        String original_zone_code = o.getOriginal_zone_code();
                        String addr = o.getAddr();
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<OrderWaybillHook> list = Lists.newArrayList(tp._2._2.get()).stream()
                                    .filter(t -> StringUtils.isNotEmpty(t.getAoi_zc()) && StringUtils.equals(t.getAoi_zc(), original_zone_code))
                                    .collect(Collectors.toList());
                            String last_aoi = "";
                            if (StringUtils.isNotEmpty(addr)) {
                                List<OrderWaybillHook> aoiNameList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_name()))
                                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getAoi_name))), ArrayList::new));
                                for (OrderWaybillHook orderWaybillHook : aoiNameList) {
                                    String aoi_name = orderWaybillHook.getAoi_name();
                                    double similarity = KeyWordUtil.similarity(addr, aoi_name);
                                    orderWaybillHook.setSimilarity(similarity + "");
                                }
                                List<OrderWaybillHook> sortList = aoiNameList.stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7)
                                        .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                                        .collect(Collectors.toList());
                                if (sortList.size() > 0) {
                                    OrderWaybillHook orderWaybillHook = sortList.get(0);
                                    last_aoi = orderWaybillHook.getAoi_id();
                                    if (StringUtils.isNotEmpty(last_aoi)) {
                                        o.setLastAoiid(last_aoi);
                                        o.setTag("similar_no_schedule");
                                    }
                                }
                            }
                            if (StringUtils.isEmpty(last_aoi)) {
                                ArrayList<OrderWaybillHook> uniqueList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getAoi_id))), ArrayList::new));
                                if (uniqueList.size() == 1) {
                                    String aoi_id = uniqueList.get(0).getAoi_id();
                                    o.setLastAoiid(aoi_id);
                                    o.setTag("aoi_id_unique_no_schedule");
                                } else if (uniqueList.size() > 1) {
                                    ArrayList<OrderWaybillHook> jitiList = uniqueList.stream().filter(t -> StringUtils.isNotEmpty(t.getPick_jiti()))
                                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getPick_jiti))), ArrayList::new));
                                    if (jitiList.size() == 1) {
                                        String aoi_id = jitiList.get(0).getAoi_id();
                                        o.setLastAoiid(aoi_id);
                                        o.setTag("aoi_id_random_no_schedule");
                                    } else if (jitiList.size() > 1) {
                                        List<OrderWaybillHook> aoiCountList = uniqueList.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_count()))
                                                .sorted((o1, o2) -> o2.compareTo(o1))
                                                .collect(Collectors.toList());
                                        if (aoiCountList.size() > 0) {
                                            String aoi_id = aoiCountList.get(0).getAoi_id();
                                            o.setLastAoiid(aoi_id);
                                            o.setTag("aoi_id_stat_no_schedule");
                                        }
                                    }
                                }
                            }
                        }
                        result.add(o);
                    }
                    return result.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatNoScheduleRdd cnt:{}", aoiIdStatNoScheduleRdd.count());
        similarNoScheduleEmpAoiRdd.unpersist();
        orderWaybillHookRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleAoiRdd = aoiIdStatNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleEmpAoiRdd = aoiIdStatNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatNoScheduleAoiRdd cnt:{}", aoiIdStatNoScheduleAoiRdd.count());
        logger.error("aoiIdStatNoScheduleEmpAoiRdd cnt:{}", aoiIdStatNoScheduleEmpAoiRdd.count());
        aoiIdStatNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd14 = rdd13.union(similarNoScheduleAoiRdd).union(aoiIdStatNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd14 cnt:{}", rdd14.count());
        rdd13.unpersist();
        similarNoScheduleAoiRdd.unpersist();
        aoiIdStatNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> empAoiRdd = aoiIdUniqueEmpAoiRdd.union(aoiIdStatEmpAoiRdd).union(aoiIdStatNoScheduleEmpAoiRdd)
                .map(o -> {
                    o.setTag("no_sj_no_pj");
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
        aoiIdUniqueEmpAoiRdd.unpersist();
        aoiIdStatEmpAoiRdd.unpersist();
        aoiIdStatNoScheduleEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> empAoiExtsRdd = empAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(extsRdd.mapToPair(o -> new Tuple2<>(o.getMainwaybillno(), o))).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                FvpCoreFactRouteRt fvpCoreFactRouteRt = tp._2._2.get();
                o.setExts(fvpCoreFactRouteRt.getExts());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empAoiExtsRdd cnt:{}", empAoiExtsRdd.count());
        empAoiRdd.unpersist();
        extsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> ext24And25Rdd = empAoiExtsRdd.map(o -> {
            String exts = o.getExts();
            if (StringUtils.isNotEmpty(exts)) {
                String[] split = exts.replaceAll("\\{|\\}", "").split(",");
                String ext24 = "";
                String ext25 = "";
                for (String ext : split) {
                    if (StringUtils.isNotEmpty(ext)) {
                        String[] split1 = ext.split("=");
                        if (split1.length >= 2) {
                            String s = split1[0].replaceAll(" ", "");
                            if (StringUtils.equals(s, "ext24")) {
                                ext24 = split1[1];
                            }
                            if (StringUtils.equals(s, "ext25")) {
                                ext25 = split1[1];
                            }
                        }
                    }
                }
                o.setExt24(ext24);
                o.setExt25(ext25);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ext24And25Rdd cnt:{}", ext24And25Rdd.count());
        empAoiExtsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordRdd = ext24And25Rdd.filter(o -> StringUtils.isNotEmpty(o.getExt24())).map(o -> {
            String ext24 = o.getExt24();
            String[] splits = ext24.split("\\|");
            if (splits.length >= 2) {
                String x = splits[0];
                String y = splits[1];
                if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                    String aoiAndzc = service.getAoiByXy(getAoiByXyUrl, x, y);
                    if (StringUtils.isNotEmpty(aoiAndzc) && aoiAndzc.split(",").length > 0) {
                        String aoi = aoiAndzc.split(",")[0];
                        if (StringUtils.isNotEmpty(aoi)) {
                            o.setLastAoiid(aoi);
                            o.setTag("aoi_id_36_coord");
                        }
                    }
                }
            }
            return o;
        }).union(ext24And25Rdd.filter(o -> StringUtils.isEmpty(o.getExt24()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordRdd cnt:{}", aoiId36CoordRdd.count());
        ext24And25Rdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAoiRdd = aoiId36CoordRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordEmpAoiRdd = aoiId36CoordRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordAoiRdd cnt:{}", aoiId36CoordAoiRdd.count());
        logger.error("aoiId36CoordEmpAoiRdd cnt:{}", aoiId36CoordEmpAoiRdd.count());
        aoiId36CoordRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd15 = rdd14.union(aoiId36CoordAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd15 cnt:{}", rdd15.count());
        rdd14.unpersist();
        aoiId36CoordAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAtsRdd = aoiId36CoordEmpAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getExt25())).repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<EdcsWaybillContentSwsKafka> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                EdcsWaybillContentSwsKafka o = itr.next();
                o.setAddr(o.getExt25());
                String aoi = service.getAtsAoi(ats, o);
                if (StringUtils.isNotEmpty(aoi)) {
                    o.setLastAoiid(aoi);
                    o.setTag("aoi_id_36_coord");
                }
                list.add(o);
            }
            return list.iterator();
        }).union(aoiId36CoordEmpAoiRdd.filter(o -> StringUtils.isEmpty(o.getExt25()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordAtsRdd cnt:{}", aoiId36CoordAtsRdd.count());
        aoiId36CoordEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAtsAoiRdd = aoiId36CoordAtsRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAtsEmpAoiRdd = aoiId36CoordAtsRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordAtsAoiRdd cnt:{}", aoiId36CoordAtsAoiRdd.count());
        logger.error("aoiId36CoordAtsEmpAoiRdd cnt:{}", aoiId36CoordAtsEmpAoiRdd.count());
        aoiId36CoordAtsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd16 = rdd15.union(aoiId36CoordAtsAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd16 cnt:{}", rdd16.count());
        rdd15.unpersist();
        aoiId36CoordAtsAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAtsEmpAoiAddrRdd = aoiId36CoordAtsEmpAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getExt25()) && StringUtils.isNotEmpty(o.getCityCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAtsEmpAoiEmpAddrRdd = aoiId36CoordAtsEmpAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getExt25()) && StringUtils.isNotEmpty(o.getCityCode()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordAtsEmpAoiAddrRdd cnt:{}", aoiId36CoordAtsEmpAoiAddrRdd.count());
        logger.error("aoiId36CoordAtsEmpAoiEmpAddrRdd cnt:{}", aoiId36CoordAtsEmpAoiEmpAddrRdd.count());
        aoiId36CoordAtsEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordKsRdd = aoiId36CoordAtsEmpAoiAddrRdd.repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<EdcsWaybillContentSwsKafka> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                EdcsWaybillContentSwsKafka o = itr.next();
                o.setAddr(o.getExt25());
                String aoi = service.getKsAoi(ks, o);
                if (StringUtils.isNotEmpty(aoi)) {
                    o.setLastAoiid(aoi);
                    o.setTag("aoi_id_36_coord");
                }
                list.add(o);
            }
            return list.iterator();
        }).union(aoiId36CoordAtsEmpAoiEmpAddrRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordKsRdd cnt:{}", aoiId36CoordKsRdd.count());
        aoiId36CoordAtsEmpAoiAddrRdd.unpersist();
        aoiId36CoordAtsEmpAoiEmpAddrRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordKsAoiRdd = aoiId36CoordKsRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordKsEmpAoiRdd = aoiId36CoordKsRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordKsAoiRdd cnt:{}", aoiId36CoordKsAoiRdd.count());
        logger.error("aoiId36CoordKsEmpAoiRdd cnt:{}", aoiId36CoordKsEmpAoiRdd.count());
        aoiId36CoordKsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd17 = rdd16.union(aoiId36CoordKsAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd17 cnt:{}", rdd17.count());
        rdd16.unpersist();
        aoiId36CoordKsAoiRdd.unpersist();

        JavaPairRDD<String, TmDepartment> tmDepartmentWageLevelRdd = service.loadTmDepartmentWageLevel(si, before1Date).mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tmDepartmentWageLevelRdd cnt:{}", tmDepartmentWageLevelRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcRdd = aoiId36CoordKsEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(empInfoDtlDfRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        EmpInfoDtlDf empInfoDtlDf = tp._2._2.get();
                        o.setPosition_name(empInfoDtlDf.getPosition_name());
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getOriginal_zone_code(), o))
                .leftOuterJoin(tmDepartmentWageLevelRdd)
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TmDepartment tmDepartment = tp._2._2.get();
                        String position_name = o.getPosition_name();
                        if (StringUtils.isNotEmpty(position_name) && position_name.contains("收派")) {
                            String pick_wage_aoi_id = tmDepartment.getPick_wage_aoi_id();
                            if (StringUtils.isNotEmpty(pick_wage_aoi_id)) {
                                o.setLastAoiid(pick_wage_aoi_id);
                                o.setTag("aoi_id_doudi_zc");
                            } else {
                                String dept_aoi_id = tmDepartment.getDept_aoi_id();
                                if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                    o.setLastAoiid(dept_aoi_id);
                                    o.setTag("aoi_id_doudi_zc");
                                }
                            }
                        } else {
                            String dept_aoi_id = tmDepartment.getDept_aoi_id();
                            if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                o.setLastAoiid(dept_aoi_id);
                                o.setTag("aoi_id_doudi_zc");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcRdd cnt:{}", aoiIdDoudiZcRdd.count());
        aoiId36CoordKsEmpAoiRdd.unpersist();
        empInfoDtlDfRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcAoiRdd = aoiIdDoudiZcRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcEmpAoiRdd = aoiIdDoudiZcRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcAoiRdd cnt:{}", aoiIdDoudiZcAoiRdd.count());
        logger.error("aoiIdDoudiZcEmpAoiRdd cnt:{}", aoiIdDoudiZcEmpAoiRdd.count());
        aoiIdDoudiZcRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd18 = rdd17.union(aoiIdDoudiZcAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd18 cnt:{}", rdd18.count());
        rdd17.unpersist();
        aoiIdDoudiZcAoiRdd.unpersist();

        JavaPairRDD<String, DimDeptInfoDf> dimDeptInfoDfRdd = service.loadDimDeptInfoDf(si, date)
                .mapToPair(o -> new Tuple2<>(o.getDept_code(), o))
                .reduceByKey((o1, o2) -> o1)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("dimDeptInfoDfRdd cnt:{}", dimDeptInfoDfRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> parentDeptCodeRdd = aoiIdDoudiZcEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getOriginal_zone_code(), o))
                .leftOuterJoin(dimDeptInfoDfRdd).map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        DimDeptInfoDf dimDeptInfoDf = tp._2._2.get();
                        String dept_type_name = dimDeptInfoDf.getDept_type_name();
                        if (StringUtils.equals(dept_type_name, "营业站") || StringUtils.equals(dept_type_name, "营运站")
                                || StringUtils.equals(dept_type_name, "临时站") || StringUtils.equals(dept_type_name, "合作点")) {
                            o.setParent_dept_code(dimDeptInfoDf.getParent_dept_code());
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("parentDeptCodeRdd cnt:{}", parentDeptCodeRdd.count());
        aoiIdDoudiZcEmpAoiRdd.unpersist();
        dimDeptInfoDfRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcParentRdd = parentDeptCodeRdd.filter(o -> StringUtils.isNotEmpty(o.getParent_dept_code()))
                .mapToPair(o -> new Tuple2<>(o.getParent_dept_code(), o))
                .leftOuterJoin(tmDepartmentWageLevelRdd)
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TmDepartment tmDepartment = tp._2._2.get();
                        String position_name = o.getPosition_name();
                        if (StringUtils.isNotEmpty(position_name) && position_name.contains("收派")) {
                            String pick_wage_aoi_id = tmDepartment.getPick_wage_aoi_id();
                            if (StringUtils.isNotEmpty(pick_wage_aoi_id)) {
                                o.setLastAoiid(pick_wage_aoi_id);
                                o.setTag("aoi_id_doudi_zc_parent");
                            } else {
                                String dept_aoi_id = tmDepartment.getDept_aoi_id();
                                if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                    o.setLastAoiid(dept_aoi_id);
                                    o.setTag("aoi_id_doudi_zc_parent");
                                }
                            }
                        } else {
                            String dept_aoi_id = tmDepartment.getDept_aoi_id();
                            if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                o.setLastAoiid(dept_aoi_id);
                                o.setTag("aoi_id_doudi_zc_parent");
                            }
                        }
                    }
                    return o;
                }).union(parentDeptCodeRdd.filter(o -> StringUtils.isEmpty(o.getParent_dept_code()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcParentRdd cnt:{}", aoiIdDoudiZcParentRdd.count());
        parentDeptCodeRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcParentAoiRdd = aoiIdDoudiZcParentRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcParentEmpAoiRdd = aoiIdDoudiZcParentRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcParentAoiRdd cnt:{}", aoiIdDoudiZcParentAoiRdd.count());
        logger.error("aoiIdDoudiZcParentEmpAoiRdd cnt:{}", aoiIdDoudiZcParentEmpAoiRdd.count());
        aoiIdDoudiZcParentRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcParentEmpAoiDeptRdd = aoiIdDoudiZcParentEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).groupByKey())
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<ScheduleWidthData> list = Lists.newArrayList(tp._2._2.get());
                        String dept_code = list.stream()
                                .filter(t -> StringUtils.isNotEmpty(t.getDept_code()))
                                .collect(Collectors.groupingBy(ScheduleWidthData::getDept_code))
                                .values()
                                .stream()
                                .sorted((a, b) -> b.size() - a.size())
                                .collect(Collectors.toList())
                                .get(0)
                                .get(0)
                                .getDept_code();
                        o.setNew_dept_code(dept_code);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcParentEmpAoiDeptRdd cnt:{}", aoiIdDoudiZcParentEmpAoiDeptRdd.count());
        aoiIdDoudiZcParentEmpAoiRdd.unpersist();
        scheduleWidthDataRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> newDeptRdd = aoiIdDoudiZcParentEmpAoiDeptRdd.filter(o -> StringUtils.isNotEmpty(o.getNew_dept_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> empNewDeptRdd = aoiIdDoudiZcParentEmpAoiDeptRdd.filter(o -> StringUtils.isEmpty(o.getNew_dept_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newDeptRdd cnt:{}", newDeptRdd.count());
        logger.error("empNewDeptRdd cnt:{}", empNewDeptRdd.count());
        aoiIdDoudiZcParentEmpAoiDeptRdd.unpersist();

        JavaPairRDD<String, TbResUser> tbResUserRdd = service.loadTbResUser(si, before1Date).mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).reduceByKey((o1, o2) -> o1).map(tp -> {
            TbResUser o = tp._2;
            String loginid = o.getLoginid();
            if (StringUtils.isNotEmpty(loginid)) {
                loginid = service.processTakeoverMemberNo(loginid);
                o.setLoginid(loginid);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tbResUserRdd cnt:{}", tbResUserRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> empNewDeptUserRdd = empNewDeptRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(tbResUserRdd).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TbResUser tbResUser = tp._2._2.get();
                o.setNew_dept_code(tbResUser.getService_dept());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empNewDeptUserRdd cnt:{}", empNewDeptUserRdd.count());
        empNewDeptRdd.unpersist();
        tbResUserRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcXgRdd = empNewDeptUserRdd.union(newDeptRdd).map(o -> {
            String new_dept_code = o.getNew_dept_code();
            if (StringUtils.isNotEmpty(new_dept_code)) {
                o.setOriginal_zone_code(new_dept_code);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getOriginal_zone_code(), o))
                .leftOuterJoin(tmDepartmentWageLevelRdd)
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TmDepartment tmDepartment = tp._2._2.get();
                        String position_name = o.getPosition_name();
                        if (StringUtils.isNotEmpty(position_name) && position_name.contains("收派")) {
                            String pick_wage_aoi_id = tmDepartment.getPick_wage_aoi_id();
                            if (StringUtils.isNotEmpty(pick_wage_aoi_id)) {
                                o.setLastAoiid(pick_wage_aoi_id);
                                o.setTag("aoi_id_doudi_zc_xg");
                            } else {
                                String dept_aoi_id = tmDepartment.getDept_aoi_id();
                                if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                    o.setLastAoiid(dept_aoi_id);
                                    o.setTag("aoi_id_doudi_zc_xg");
                                }
                            }
                        } else {
                            String dept_aoi_id = tmDepartment.getDept_aoi_id();
                            if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                o.setLastAoiid(dept_aoi_id);
                                o.setTag("aoi_id_doudi_zc_xg");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcXgRdd cnt:{}", aoiIdDoudiZcXgRdd.count());
        empNewDeptUserRdd.unpersist();
        newDeptRdd.unpersist();
        tmDepartmentWageLevelRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> lastAoiRdd = rdd18.repartition(1200).union(aoiIdDoudiZcParentAoiRdd.repartition(1200)).union(aoiIdDoudiZcXgRdd.repartition(1200)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastAoiRdd cnt:{}", lastAoiRdd.count());
        rdd18.unpersist();
        aoiIdDoudiZcParentAoiRdd.unpersist();
        aoiIdDoudiZcXgRdd.unpersist();

        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> aoiCodeRdd = lastAoiRdd.mapToPair(o -> new Tuple2<>(o.getLastAoiid(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        String aoi_code = cmsAoiSch.getAoi_code();
                        String fa_type = cmsAoiSch.getFa_type();
                        o.setAoi_code(aoi_code);
                        o.setFa_type(fa_type);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiCodeRdd cnt:{}", aoiCodeRdd.count());
        lastAoiRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        JavaRDD<AoiAreaAoi> aoiAreaAoiRdd = service.loadAoiAreaAoiData(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaAoiRdd cnt:{}", aoiAreaAoiRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafkaSj> resultRdd = aoiCodeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
                .leftOuterJoin(aoiAreaAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        o.setAoi_area_code(aoiAreaAoi.getAoi_area_code());
                    }
                    return o;
                }).map(o -> {
                    EdcsWaybillContentSwsKafkaSj sj = new EdcsWaybillContentSwsKafkaSj();
                    sj.setOriginal_waybill_no(o.getWaybill_no());
                    sj.setOriginal_zone_code(o.getOriginal_zone_code());
                    sj.setOriginal_city_code(o.getOriginal_city_code());
                    sj.setOriginal_member_no(o.getEmp_code());
                    sj.setOriginal_tm(o.getTakeover_tm());
                    sj.setOriginal_aoi_id(o.getLastAoiid());
                    sj.setOriginal_aoi_code(o.getAoi_code());
                    sj.setOriginal_aoi_area_code(o.getAoi_area_code());
                    sj.setOriginal_fa_type(o.getFa_type());
                    sj.setOriginal_tag(o.getTag());
                    sj.setDestination_zone_code(o.getDestination_zone_code());
                    sj.setDestination_city_code(o.getDestination_city_code());
                    sj.setInc_day(date);

                    return sj;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        aoiCodeRdd.unpersist();
        aoiAreaAoiRdd.unpersist();

        DataUtil.saveInto(si, "dm_gis.sj_aoi", EdcsWaybillContentSwsKafkaSj.class, resultRdd, "inc_day");

//        service.saveSjData(spark, resultRdd, "dm_gis.sj_aoi_new", date);

        resultRdd.unpersist();
        si.getContext().stop();
    }

}
