package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.KuaiYunWaybillDetailDiClearController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *  * 匡仁衡
 *  * 已迁移新集群
 *  业务：郭本婕
 *  开发：匡仁衡
 *  任务id:173
 *  说明：目前已冻结，因为上下游都已冻结，等待业务再次需要开启
 */
public class AppKuaiYunWaybillDetailDiClear {
    private static Logger logger = LoggerFactory.getLogger(AppKuaiYunWaybillDetailDiClear.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new KuaiYunWaybillDetailDiClearController().start(date);
        logger.error("run end");
    }
}
