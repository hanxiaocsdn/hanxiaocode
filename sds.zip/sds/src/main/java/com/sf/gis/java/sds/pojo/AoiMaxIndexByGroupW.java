package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiMaxIndexByGroupW implements Serializable {

    @Column(name = "waybillno")
    private String waybillno;

    @Column(name = "req_destcitycode")
    private String req_destcitycode;

    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;

    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;

    @Column(name = "80_aoi_code")
    private String aoi_80_code;

    @Column(name = "r_aoi")
    private String r_aoi;

    @Column(name = "ts_aoi_code")
    private String ts_aoi_code;

    @Column(name = "std_addr")
    private String std_addr;

    @Column(name = "cms_aoi_id")
    private String cms_aoi_id;

    @Column(name = "max_r_aoi")
    private String max_r_aoi;

    @Column(name = "max_r_aoi_cnt")
    private String max_r_aoi_cnt;

    @Column(name = "max_80_aoi")
    private String max_80_aoi;

    @Column(name = "max_80_aoi_cnt")
    private String max_80_aoi_cnt;

    @Column(name = "group_size")
    private String group_size;

    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "byxy_resp")
    private String byxy_resp;

    @Column(name = "max_r_aoi_freq")
    private String max_r_aoi_freq;

    @Column(name = "max_80_aoi_freq")
    private String max_80_aoi_freq;

    @Column(name = "ts_aoi_id")
    private String ts_aoi_id;

    private String content;
    private boolean flag;

    private String cmsAoi;
    private String cmsAdcode;
    private String cmsZnoCode;
    private boolean checkFlag;

    public boolean isCheckFlag() {
        return checkFlag;
    }

    public void setCheckFlag(boolean checkFlag) {
        this.checkFlag = checkFlag;
    }

    public String getCmsAdcode() {
        return cmsAdcode;
    }

    public void setCmsAdcode(String cmsAdcode) {
        this.cmsAdcode = cmsAdcode;
    }

    public String getCmsZnoCode() {
        return cmsZnoCode;
    }

    public void setCmsZnoCode(String cmsZnoCode) {
        this.cmsZnoCode = cmsZnoCode;
    }

    public String getCmsAoi() {
        return cmsAoi;
    }

    public void setCmsAoi(String cmsAoi) {
        this.cmsAoi = cmsAoi;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getTs_aoi_id() {
        return ts_aoi_id;
    }

    public void setTs_aoi_id(String ts_aoi_id) {
        this.ts_aoi_id = ts_aoi_id;
    }

    public String getByxy_resp() {
        return byxy_resp;
    }

    public void setByxy_resp(String byxy_resp) {
        this.byxy_resp = byxy_resp;
    }

    public String getMax_r_aoi_freq() {
        return max_r_aoi_freq;
    }

    public void setMax_r_aoi_freq(String max_r_aoi_freq) {
        this.max_r_aoi_freq = max_r_aoi_freq;
    }

    public String getMax_80_aoi_freq() {
        return max_80_aoi_freq;
    }

    public void setMax_80_aoi_freq(String max_80_aoi_freq) {
        this.max_80_aoi_freq = max_80_aoi_freq;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getR_aoi() {
        return r_aoi;
    }

    public void setR_aoi(String r_aoi) {
        this.r_aoi = r_aoi;
    }

    public String getTs_aoi_code() {
        return ts_aoi_code;
    }

    public void setTs_aoi_code(String ts_aoi_code) {
        this.ts_aoi_code = ts_aoi_code;
    }

    public String getStd_addr() {
        return std_addr;
    }

    public void setStd_addr(String std_addr) {
        this.std_addr = std_addr;
    }

    public String getCms_aoi_id() {
        return cms_aoi_id;
    }

    public void setCms_aoi_id(String cms_aoi_id) {
        this.cms_aoi_id = cms_aoi_id;
    }

    public String getMax_r_aoi() {
        return max_r_aoi;
    }

    public void setMax_r_aoi(String max_r_aoi) {
        this.max_r_aoi = max_r_aoi;
    }

    public String getMax_r_aoi_cnt() {
        return max_r_aoi_cnt;
    }

    public void setMax_r_aoi_cnt(String max_r_aoi_cnt) {
        this.max_r_aoi_cnt = max_r_aoi_cnt;
    }

    public String getMax_80_aoi() {
        return max_80_aoi;
    }

    public void setMax_80_aoi(String max_80_aoi) {
        this.max_80_aoi = max_80_aoi;
    }

    public String getMax_80_aoi_cnt() {
        return max_80_aoi_cnt;
    }

    public void setMax_80_aoi_cnt(String max_80_aoi_cnt) {
        this.max_80_aoi_cnt = max_80_aoi_cnt;
    }

    public String getGroup_size() {
        return group_size;
    }

    public void setGroup_size(String group_size) {
        this.group_size = group_size;
    }

}
