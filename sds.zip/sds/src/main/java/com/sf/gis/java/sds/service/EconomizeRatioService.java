package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.EconomizeRatio;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class EconomizeRatioService implements Serializable {

    private Logger logger = LoggerFactory.getLogger(EconomizeRatioService.class);

    public JavaRDD<EconomizeRatio> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("tals_get_target_data.sql", date, date, date);
        logger.error("tals_get_target_data.sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, EconomizeRatio.class);
    }

    public double calcMtc(List<EconomizeRatio> list) {
        double sumTollCharge = 0;
        double mtc = 0;
        for (EconomizeRatio economizeRatio : list) {
            sumTollCharge = sumTollCharge + Double.parseDouble(StringUtils.isNotEmpty(economizeRatio.getTollCharge()) ? economizeRatio.getTollCharge() : "0");
        }
        mtc = (double) Math.round((sumTollCharge / list.size()) * 10) / 10;
        return mtc;
    }

    public double calcEtc(List<EconomizeRatio> list) {
        double sumEtcTollCharge = 0;
        double etc = 0;
        for (EconomizeRatio economizeRatio : list) {
            sumEtcTollCharge = sumEtcTollCharge + Double.parseDouble(StringUtils.isNotEmpty(economizeRatio.getEtcTollCharge()) ? economizeRatio.getEtcTollCharge() : "0");
        }
        etc = (double) Math.round((sumEtcTollCharge / list.size()) * 10) / 10;
        return etc;
    }

    public void saveData(SparkSession spark, JavaRDD<EconomizeRatio> inRdd) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getIncMonth(), o.getIncDay(), o.getDay(), o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(),
                    o.getZy_taskNumber() + "", o.getZy_sumEtcTollCharge() + "", o.getZy_sumBaseLineEtctoll() + "", o.getNo_zy_taskNumber() + "", o.getNo_zy_sumEtcTollCharge() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"STAT_MONTH", "STAT_DATE", "STAT_WEEK", "SRC_PROVINCE", "DESC_PROVINCE", "AREA", "SRC_CITYCODE", "DESC_CITYCODE",
                "ZY_TASK_COUNT", "ZY_TOTAL_ETC", "ZY_BASE_TOTAL_ETC", "WB_TASK_COUNT", "WB_TOTAL_ETC"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "ETA_ECONOMICAL_RATIO_STAT_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.ETA_ECONOMICAL_RATIO_STAT";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveToMysql(JavaSparkContext sc, JavaRDD<EconomizeRatio> rdd) {
        String dbConfig = "mysql.properties";
        logger.error("rdd cnt: {}", rdd.count());

        logger.error("insert into mysql");
        Broadcast<String> dbConfigBc = sc.broadcast(dbConfig);
        rdd.repartition(16).foreachPartition(p -> {
            java.sql.Connection conn = DbUtil.getInstance(dbConfigBc.value()).getConn();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement(
                    String.format("insert into ETA_ECONOMICAL_RATIO_STAT(`STAT_MONTH`, `STAT_DATE`, `STAT_WEEK`, `SRC_PROVINCE`, `DESC_PROVINCE`, `AREA`, `SRC_CITYCODE`, `DESC_CITYCODE`, " +
                            "`ZY_TASK_COUNT`,`ZY_TOTAL_ETC`,`ZY_BASE_TOTAL_ETC`,`WB_TASK_COUNT`,`WB_TOTAL_ETC`) " +
                            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            );
            while (p.hasNext()) {
                EconomizeRatio o = p.next();
                pstmt.setString(1, o.getIncMonth());
                pstmt.setString(2, o.getIncDay());
                pstmt.setString(3, o.getDay());
                pstmt.setString(4, o.getSrcProvince());
                pstmt.setString(5, o.getDestProvince());
                pstmt.setString(6, o.getTaskAreaCode());
                pstmt.setString(7, o.getSrcCityName());
                pstmt.setString(8, o.getDestCityName());

                pstmt.setInt(9, o.getZy_taskNumber());
                pstmt.setDouble(10, o.getZy_sumEtcTollCharge());
                pstmt.setDouble(11, o.getZy_sumBaseLineEtctoll());
                pstmt.setInt(12, o.getNo_zy_taskNumber());
                pstmt.setDouble(13, o.getNo_zy_sumEtcTollCharge());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            pstmt.close();
            conn.close();
        });
        logger.error("insert into mysql end");
    }

    //删除mysql数据
    public void delete(String date) {
        java.sql.Connection conn = DbUtil.getInstance("mysql.properties").getConn();
        String sql = String.format("delete from ETA_ECONOMICAL_RATIO_STAT where STAT_DATE = '%s'", date);
        PreparedStatement pst = null;
        try {
            // 创建预编译语句
            pst = conn.prepareStatement(sql);
            // 执行SQL
            pst.executeUpdate();
            logger.error("删除成功");
            // 关闭资源
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("删除失败");
        }
    }

}
