package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class XzcVillage implements Serializable {
    @Column(name = "ogc_fid")
    private String ogc_fid;
    @Column(name = "name")
    private String name;
    @Column(name = "guid_v")
    private String guid_v;
    @Column(name = "name_v")
    private String name_v;

    private double sim_text;
    private double sim_pinyin;
    private String neighbor_name;
    private String neighbor_ogc_fid;

    public String getNeighbor_ogc_fid() {
        return neighbor_ogc_fid;
    }

    public void setNeighbor_ogc_fid(String neighbor_ogc_fid) {
        this.neighbor_ogc_fid = neighbor_ogc_fid;
    }

    public String getNeighbor_name() {
        return neighbor_name;
    }

    public void setNeighbor_name(String neighbor_name) {
        this.neighbor_name = neighbor_name;
    }

    public double getSim_text() {
        return sim_text;
    }

    public void setSim_text(double sim_text) {
        this.sim_text = sim_text;
    }

    public double getSim_pinyin() {
        return sim_pinyin;
    }

    public void setSim_pinyin(double sim_pinyin) {
        this.sim_pinyin = sim_pinyin;
    }

    public String getOgc_fid() {
        return ogc_fid;
    }

    public void setOgc_fid(String ogc_fid) {
        this.ogc_fid = ogc_fid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGuid_v() {
        return guid_v;
    }

    public void setGuid_v(String guid_v) {
        this.guid_v = guid_v;
    }

    public String getName_v() {
        return name_v;
    }

    public void setName_v(String name_v) {
        this.name_v = name_v;
    }
}
