package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.aoichannel.*;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AoiChannelInformationQueryService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiChannelInformationQueryService.class);

    public JavaRDD<FengChao> loadFengChao(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("dim_hive_cabinet_info_df.sql", date);
        logger.error("dim_hive_cabinet_info_df sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, FengChao.class);
    }

    public JavaRDD<ConvenienceStore> loadConvenienceStore(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("cx_service_network.sql", date);
        logger.error("cx_service_network sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ConvenienceStore.class);
    }

    public JavaRDD<Cnyz> loadCnyz(SparkSession spark, JavaSparkContext sc) {
        String sql = "select * from dm_gis.js_net_all_info_shange_report";
        logger.error("js_net_all_info_shange_report sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, Cnyz.class);
    }

    public JavaRDD<CityStation> loadCityStation(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("cvs_pickup_deliver_aoi_sum_di.sql", date);
        logger.error("cvs_pickup_deliver_aoi_sum_di sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CityStation.class);
    }

    public JavaRDD<AoiChannelStat> getAoiChannelStat(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("aoi_channel_stat.sql", date, date, date);
        logger.error("aoi_channel_stat sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiChannelStat.class);
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,city_code from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<VillageStation> loadVillageStation(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("network_base_info.sql", date);
        logger.error("network_base_info sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, VillageStation.class);
    }

    public JavaRDD<AoiChannelStat> getVillageStation(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("villagestation.sql", date);
        logger.error("villagestation sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiChannelStat.class);
    }

    public JavaRDD<AoiAreaAoi> loadAoiAreaAoi(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = "select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi where status=1";
        logger.error("aoi_area_aoi sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiAreaAoi.class);
    }

    public static void main(String[] args) {
        String url = "http://10.202.43.231:7170/qm_point";

        //http://10.202.43.231:7170/about?detail=1

        JSONObject json = new JSONObject();
//        json.put("points","113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925|113.831711,22.660925");
        json.put("points", "113.831711,22.660925");
        json.put("origin", "113.831711,22.660925");
        json.put("destination", "113.831711,22.660925");
        json.put("plate", "豫FC2085");
        json.put("plateColor", 2);
        json.put("emitStand", 0);
        json.put("energy", 2);
        json.put("weight", 14.0);
        json.put("vehicle", 8);
        json.put("mload", 14.0);
        json.put("height", 0.0);
        json.put("width", 0.0);
        json.put("size", 9.6);
        json.put("axleweight", "");
        json.put("axlenumber", 3);
        json.put("speed", 1);
        json.put("no", "111Y8622360");
        json.put("date", "202108210405");
        json.put("stype", 0);
        json.put("etype", 0);
        json.put("passport", 100000);
        json.put("mode", 2);
        json.put("toll", 1);
        String result = HttpInvokeUtil.sendPost(url, json.toJSONString());
        System.out.println(result);
    }

    public void saveFengChaoData(SparkSession spark, JavaRDD<FengChao> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCabinetid(), o.getCabinetcode(), o.getProvince(), o.getCity(), o.getDistrict(), o.getCitycode(), o.getLongitude(), o.getLatitude(),
                    o.getAoi_id(), o.getAoi_code(), o.getAoi_name(), o.getReq(), o.getResJson()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"cabinetid", "cabinetcode", "province", "city", "district", "citycode", "longitude", "latitude",
                "aoi_id", "aoi_code", "aoi_name", "req", "resJson"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "dim_hive_cabinet_info_df_aoi_info_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.dim_hive_cabinet_info_df_aoi_info";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveConvenienceStoreData(SparkSession spark, JavaRDD<ConvenienceStore> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getService_code(), o.getService_name(), o.getService_type(), o.getService_addr(), o.getProvince(), o.getCityid(), o.getLongitude(), o.getLatitude(),
                    o.getAoi_id(), o.getAoi_code(), o.getAoi_name(), o.getReq(), o.getResJson()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"service_code", "service_name", "service_type", "service_addr", "province", "cityid", "longitude", "latitude",
                "aoi_id", "aoi_code", "aoi_name", "req", "resJson"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cx_service_network_aoi_info_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.cx_service_network_aoi_info";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveCnyzData(SparkSession spark, JavaRDD<Cnyz> inRdd) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getProvince(), o.getCity(), o.getCounty(), o.getTown(), o.getPointname(), o.getNettype(), o.getLongitude(), o.getLatitude(), o.getAddress(), o.getZno_code(), o.getRegion(), o.getCompany(), o.getPingtai(),
                    o.getAoi_id(), o.getAoi_code(), o.getAoi_name(), o.getReq(), o.getResJson()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"province", "city", "county", "town", "pointname", "nettype", "longitude", "latitude", "address", "zno_code", "region", "company", "pingtai",
                "aoi_id", "aoi_code", "aoi_name", "req", "resJson"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cnyz_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.cnyz";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveCityStationData(SparkSession spark, JavaRDD<CityStation> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getDist_code(), o.getCvs_code(), o.getStore_id(), o.getCvs_name(), o.getAoi_dist_code(), o.getStore_address(), o.getStore_lng(), o.getStore_lat(),
                    o.getAoi_id(), o.getAoi_code(), o.getAoi_name(), o.getReq(), o.getResJson()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"dist_code", "cvs_code", "store_id", "cvs_name", "aoi_dist_code", "store_address", "store_lng", "store_lat",
                "aoi_id", "aoi_code", "aoi_name", "req", "resJson"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cvs_pickup_deliver_aoi_sum_di_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.cvs_pickup_deliver_aoi_sum_di";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveVillageStationData(SparkSession spark, JavaRDD<VillageStation> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getNetwork_id(), o.getNetwork_name(), o.getType(), o.getProvince_code(), o.getProvince_name(), o.getCity_code(), o.getCity_name(), o.getDistrict_code(), o.getDistrict_name(), o.getAddress(), o.getLongitude(), o.getLatitude(),
                    o.getAoi_id(), o.getAoi_code(), o.getAoi_name(), o.getReq(), o.getResJson()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"network_id", "network_name", "type", "province_code", "province_name", "city_code", "city_name", "district_code", "district_name", "address", "longitude", "latitude",
                "aoi_id", "aoi_code", "aoi_name", "req", "resJson"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "network_base_info_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.network_base_info";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveStatData(SparkSession spark, JavaRDD<AoiChannelStat> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCitycode(), o.getAoiid(), o.getAoi_channel(), o.getFc_code_list(), o.getBld_code_list()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"city_code", "aoi_id", "aoi_channel", "fc_code_list", "bld_code_list"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_channel_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_channel_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }


    public void saveAoiData(SparkSession spark, JavaRDD<AoiChannelStat> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAoiid()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"aoi_id"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_black_kuang_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_black_kuang";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }


}
