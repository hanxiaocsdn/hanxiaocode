package com.sf.gis.java.sds.controller;

import com.sf.gis.java.sds.appoms.MainOmsDailyShou;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.service.PullOmsShouService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class PullOmsDataShouController {

    private Map<String, String> configMap;

    public PullOmsDataShouController(Map<String, String> configMap) {

        this.configMap = configMap;
    }

    public void start() {
        PullOmsShouService pullOmsService = new PullOmsShouService();
        int commonDayAgo = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        int bigCityDayAgo = Integer.valueOf(configMap.get(ConfigKey.bigCityDayAgo.name()));
        int smallCityDayAgo = Integer.valueOf(configMap.get(ConfigKey.smallCityDayAgo.name()));
        pullOmsService.pullData(commonDayAgo, bigCityDayAgo, smallCityDayAgo, configMap);
    }

    /**
     * 下载tc缺失数据
     */
    public void startDownloadTcEmpty() {
        PullOmsShouService pullOmsService = new PullOmsShouService();
        int commonDayAgo = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        pullOmsService.pullTcEmptyData(commonDayAgo, configMap);
//		for(int i = 1 ; i <=15 ;i++){
//			pullOmsService.pullTcEmptyData(i,configMap);
//		}
    }
}