package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.ProDbManager;
import com.sf.gis.java.sds.pojo.ProxyDept;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

public class ProxyDeptDbService extends BaseService {
    private final static String TABLE_NAME = "deputy_point_analyze_task";
    private static String[] columns = {"city_code", "group_id", "way_bill_no", "address", "log_gisdeptcode",
            "zonecode", "xiaoge_no", "xiaoge_zonecode", "gis_to_sys_src", "inc_day"};
    private static final Logger logger = LoggerFactory.getLogger(ProxyDeptDbService.class);

    public ProxyDeptDbService() {
        super(ProDbManager.getInstance());
    }

    public void delete_day(String data_time) {
        String sql = "delete from " + TABLE_NAME + " where inc_day ='" + data_time + "'";
        logger.error("del sql:" + sql);
        dbManager.update(sql);
    }

    public void insertBatch(List<ProxyDept> list) throws Exception {
        excuBatch(list, 5000, new ExcuBatchListener() {
            @Override
            public String createSql() {
                return crateInsertSqlWithOutValue(columns, TABLE_NAME);
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);
                int i = 0;
                for (String column : columns) {
                    stmt.setString(++i, (String) map.get(column));
                }
            }

        });
    }
}
