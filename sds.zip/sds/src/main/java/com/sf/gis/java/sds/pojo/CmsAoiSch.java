package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;
@Table
public class CmsAoiSch implements Serializable {

    @Column(name = "city_code")
    private String city_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "fa_type")
    private String fa_type;
    @Column(name = "aoi_code")
    private String aoi_code;

    private String aoi_par_poitype_cg_2;

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_par_poitype_cg_2() {
        return aoi_par_poitype_cg_2;
    }

    public void setAoi_par_poitype_cg_2(String aoi_par_poitype_cg_2) {
        this.aoi_par_poitype_cg_2 = aoi_par_poitype_cg_2;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }
}
