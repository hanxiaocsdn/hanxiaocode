package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SpecialInboundAddrGroupController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppSpecialInboundAddrGroup {
    private static Logger logger = LoggerFactory.getLogger(AppSpecialInboundAddrGroup.class);

    /**
     * 需求：【特殊入仓】冷运场景下在库数据聚合逻辑表输出
     * 需求方：谭雨祯（01425216）
     * 研发：匡仁衡（01399581）
     * 任务id：762332
     */
    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new SpecialInboundAddrGroupController().start(date);
        logger.error("run end");
    }
}
