package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.ProductIncUbasNextApp;
import com.sf.gis.java.sds.pojo.StAreaCityRelation;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AoiAndPoiErrorStatService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiAndPoiErrorStatService.class);

    public JavaRDD<ProductIncUbasNextApp> loadProductIncUbasNextApp(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("product_inc_ubas_next_app.sql", date);
        logger.error("product_inc_ubas_next_app sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ProductIncUbasNextApp.class);
    }

    public JavaRDD<StAreaCityRelation> loadAreaCityRelation(SparkSession spark, JavaSparkContext sc) {
        String sql = "select city_code,area_code from dm_gis.st_area_city_relation";
        logger.error("st_area_city_relation sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, StAreaCityRelation.class);
    }

    public String getCityCode(String zonecode) {
        zonecode = zonecode.trim();
        String str = "";
        if (StringUtils.isNotEmpty(zonecode)) {
            for (int i = 0; i < zonecode.length(); i++) {
                char c = zonecode.charAt(i);
                if (Character.isLowerCase(c) || Character.isUpperCase(c)) {
                    break;
                }
                if (c >= 48 && c <= 57) {
                    str += c;
                }
            }

        }
        return str;
    }

    public void saveDetailData(SparkSession spark, JavaRDD<ProductIncUbasNextApp> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getArea(), o.getCityCode(), o.getZonecode(), o.getWaybillno(), o.getUserid(), o.getError_type(), o.getSource(),
                    o.getCorrect_aoi_id(), o.getCorrect_aoi_name(), o.getLocation()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"area", "cityCode", "zonecode", "waybillno", "userid", "error_type", "source", "correct_aoi_id", "correct_aoi_name", "location"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_poi_detail_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_poi_detail";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(dt = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveStatlData(SparkSession spark, JavaRDD<ProductIncUbasNextApp> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getArea(), o.getCityCode(), o.getUserid(), o.getZonecode(), o.getSource(), o.getAoi_internal_cnt() + "", o.getAoi_between_cnt() + "", o.getException_addr_cnt() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"area", "cityCode", "userid", "zonecode", "source", "aoi_internal_cnt", "aoi_between_cnt", "exception_addr_cnt"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_poi_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_poi_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(dt = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public static void main(String[] args) {
        AoiAndPoiErrorStatService service = new AoiAndPoiErrorStatService();
        System.out.println(service.getCityCode("755bY6"));
    }
}
