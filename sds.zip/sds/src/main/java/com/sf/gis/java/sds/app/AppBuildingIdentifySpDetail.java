package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.BuildingIdentify;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AppBuildingIdentifySpDetail {
    private static Logger logger = LoggerFactory.getLogger(AppBuildingIdentifySpDetail.class);
    private static String url = "http://gis-gw.int.sfdc.com.cn:9080/atpoi/api";
    private static int limitMin = 3000 / 10;
    private static String  splitUrl = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=4ee00c498e334e4da3cc6e35469d5afd";
    private static  String pjTable = "dm_gis.bld_recognition_rate_delivery_detail_tmp";
    private static String sjTable = "dm_gis.bld_recognition_rate_pickup_detail_tmp";
    /**
     * 需求:(【壹竿-SD】楼栋识别服务收件&派件统计)
     * 需求方：谢皓旸（01424739）
     * 研发：匡仁衡（01399581）
     * 任务id：778436
     */
    public static void main(String[] args) {
        String date = args[0];
        String tag = args[1];
        logger.error("date:{},tag:{}", date, tag);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppBuildingIdentifySpDetail");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String bdrec_target_aoi_lastest_date = spark.sql("show partitions dm_gis.bdrec_target_aoi").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("bdrec_target_aoi_lastest_date:{}", bdrec_target_aoi_lastest_date);

        if (StringUtils.equals(tag, "sj")) {
            logger.error("收件");
            String sj_sql = String.format("select\n" +
                    "  b.src_order_no as waybillno,\n" +
                    "  b.isnotundercall as fei_call,\n" +
                    "  b.req_address as address,\n" +
                    "  b.finalaoicode as aoi_code,\n" +
                    "  b.finalaoiid as aoi_id,\n" +
                    "  b.citycode as citycode,\n" +
                    "  b.split_info as split,\n" +
                    "  a.is_complete as is_complete,\n" +
                    "  b.finalzc as zno_code,\n" +
                    "  b.inc_day as inc_day,\n" +
                    "  'waybill' as waybillno_src,\n" +
                    "  'fendan' as aoi_src\n" +
                    "from\n" +
                    "  (\n" +
                    "    SELECT\n" +
                    "      src_order_no ,\n" +
                    "      isnotundercall,\n" +
                    "      zonecode,\n" +
                    "      regexp_replace(req_address, '[\\r\\n, \\s, \\.,\\,,\\t]+', '') as req_address,\n" +
                    "      finalaoicode,\n" +
                    "      finalaoiid,\n" +
                    "      regexp_replace(split_info, '[\\r\\n, \\s, \\.,\\,,\\t]+', '') as split_info,\n" +
                    "       regexp_replace(substr(finalzc, 0, 4), '([^0-9]+)', '') as citycode,\n" +
                    "       finalzc,\n" +
                    "      inc_day\n" +
                    "    FROM\n" +
                    "      dm_gis.aoi_accuracy_54_aoiname_ret_bsp\n" +
                    "    where\n" +
                    "      inc_day = '%s' \n" +
                    "      and (\n" +
                    "        finalaoicode is not null\n" +
                    "        and finalaoicode <> ''\n" +

                    "      )\n" +
                    "  ) b\n" +
                    "  inner join (\n" +
                    "    select\n" +
                    "      aoi_id,\n" +
                    "      zno_code,\n" +
                    "      is_complete\n" +
                    "    from\n" +
                    "      dm_gis.bdrec_target_aoi\n" +
                    "    where\n" +
                    "      inc_day = '%s'\n" +
                    "  ) a on a.aoi_id = b.finalaoiid", date, bdrec_target_aoi_lastest_date);
            JavaRDD<BuildingIdentify> preSjRdd = DataUtil.loadData(spark, sc, sj_sql, BuildingIdentify.class)
                    .filter(o->"010".equals(o.getCitycode()));

            logger.error("过滤后的数据量 cnt:{}", preSjRdd.count());
            JavaRDD<BuildingIdentify> unique_sjRdd = preSjRdd.filter(o -> StringUtils.isNotEmpty(o.getAddress())).mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("unique_sjRdd cnt:{}", unique_sjRdd.count());

            JavaRDD<BuildingIdentify> unique_sj_resultRdd = url(unique_sjRdd);
            JavaRDD<BuildingIdentify> sjResultRdd = preSjRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o)).leftOuterJoin(unique_sj_resultRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o))).map(tp -> {
                BuildingIdentify o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    BuildingIdentify buildingIdentify = tp._2._2.get();
                    o = copy(o, buildingIdentify);
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sjResultRdd cnt:{}", sjResultRdd.count());
            preSjRdd.unpersist();
            unique_sj_resultRdd.unpersist();


            JavaRDD<BuildingIdentify> sjRdd = sjResultRdd.repartition(10).mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<BuildingIdentify> list = new ArrayList<>();
                while (itr.hasNext()) {


                    cnt = cnt + 1;
                    if (cnt == 5000) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", 5000, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    BuildingIdentify o = itr.next();

                    if(StringUtils.isNotEmpty(o.getSplitResult())){
                        o.setFinal_split(o.getSplitResult());
                    }
                    else if (StringUtils.isNotEmpty(o.getSplit())){

                        String split = o.getSplit();

                        String[] split_list = split.split(";")[0].split("\\|");
                        String  preSplit = "";

                        for (int i = 0 ;i< split_list.length ;i++) {
                            String s = split_list[i];
                            String[] split1 = s.split("\\^");
                            if (split1.length >= 2) {
                                String level = split1[1];
                                String name = split1[0];
                                String after = level.substring(1, level.length());
                                String bef = level.substring(0, 1);
                                preSplit+=name+"^"+after+"^"+bef;
                                if(i < split_list.length -1 ) preSplit+="|";
                            }
                        }
                        o.setFinal_split(preSplit);

//                    o.setFinal_split(o.getSplit());

                    }
                    else if (StringUtils.isNotEmpty(o.getAddress())){
                        //调分词接口
                        String req_addresseeaddr = o.getAddress();
                        String city_code = o.getCitycode();

                        String splitReq = String.format( splitUrl, URLEncoder.encode(req_addresseeaddr),city_code);
//                    JSONObject splitResp = Utils.retryGet(splitReq);

                        String splitResp = HttpInvokeUtil.sendGet(splitReq);

                        JSONArray splitArr = null;
                        try{
                            splitArr =   JSON.parseObject(splitResp).getJSONObject("result").getJSONObject("data").getJSONArray("info");
                        }catch (Exception e){
                            splitArr = null;
                        }

                        //拼接split result
                        String result = "";
                        if( splitArr != null && splitArr.size() > 0 ) {
                            for(int  i = 0 ;i < splitArr.size() ;i++){
                                JSONObject json =  splitArr.getJSONObject(i);
                                result += json.getString("name") + "^" +json.getString("level")+ "^" + json.getString("prop");
                                if( i < splitArr.size()-1 ) result +=  "|";
                            }
                        }
                        o.setFinal_split(result);
                    }


//                String split = o.getSplit();
                    String split = o.getFinal_split();

//                String split = o.getSplit();
                    if (StringUtils.isNotEmpty(split)) {
                        o.setLvl14_info(getlvl14_info(split));
                    }
                    String fei_call = o.getFei_call();
                    if (StringUtils.isEmpty(fei_call)) {
                        o.setFei_call("0");
                    }
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sjRdd cnt:{}", sjRdd.count());
            logger.error("落结果表:{}", sjTable);


//            JavaRDD<BuildingIdentify> sjRdd = sjResultRdd.map(o -> {
//                return o;
//            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("sjRdd cnt:{}", sjRdd.count());

//            DataUtil.saveOverwrite(spark, sc, sjTable, BuildingIdentify.class, sjRdd, "inc_day");
            DataUtil.saveOverwrite(spark, sc, sjTable, BuildingIdentify.class, sjRdd, "inc_day");
            sjRdd.unpersist();
        } else if (StringUtils.equals(tag, "pj")) {
            logger.error("派件");
            String pj_sql = String.format("select\n" +
                    "  a.req_waybillno as waybillno,\n" +
                    "  a.finalaoicode as aoi_code,\n" +
                    "  a.req_addresseeaddr as address,\n" +
                    "  a.split as split,\n" +
                    "  a.inc_day as inc_day,\n" +
                    "  a.citycode as citycode,\n" +
                    "  b.aoi_id as aoi_id,\n" +
                    "  a.finalzc as zno_code,\n" +
                    "  b.is_complete is_complete,\n" +
                    "  'waybill' as waybillno_src,\n" +
                    "  'fendan' as aoi_src\n" +
                    "from\n" +
                    "  (\n" +
                    "    SELECT\n" +
                    "      req_waybillno,\n" +
                    "      finalaoicode,\n" +
                    "      regexp_replace(req_addresseeaddr, '[\\r\\n, \\s, \\.,\\,,\\t]+', '') as req_addresseeaddr,\n" +
                    "      regexp_replace(splitresult, '[\\r\\n, \\s, \\.,\\,,\\t]+', '') as split,\n" +
                    "      regexp_replace(substr(finalzc, 0, 4), '([^0-9]+)', '') as citycode,\n" +
                    "      finalzc,\n" +
                    "      inc_day\n" +
                    "    FROM\n" +
                    "      dm_gis.aoi_recognition_rate_delivery_dimensionality_detail_di\n" +
                    "    where\n" +
                    "      inc_day = '%s' \n" +
                    "      and finalaoicode != ''\n" +
                    "      and finalaoicode is not null\n" +
                    "  ) a\n" +
                    "  inner join (\n" +
                    "    select\n" +
                    "      aoi_code,\n" +
                    "      aoi_id,\n" +
                    "      zno_code,\n" +
                    "      is_complete\n" +
                    "    from\n" +
                    "      dm_gis.bdrec_target_aoi\n" +
                    "    where\n" +
                    "      inc_day = '%s'\n" +
                    "  ) b on a.finalaoicode = b.aoi_code", date, bdrec_target_aoi_lastest_date);
            JavaRDD<BuildingIdentify> prePjRdd = DataUtil.loadData(spark, sc, pj_sql, BuildingIdentify.class)
                    .filter(o->"010".equals(o.getCitycode()));

            logger.error("过滤后的数据量 cnt:{}", prePjRdd.count());
            JavaRDD<BuildingIdentify> unique_pjRdd = prePjRdd.filter(o -> StringUtils.isNotEmpty(o.getAddress())).mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("unique_pjRdd cnt:{}", unique_pjRdd.count());

            JavaRDD<BuildingIdentify> unique_pj_resultRdd = url(unique_pjRdd);
            JavaRDD<BuildingIdentify> pjResultRdd = prePjRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o)).leftOuterJoin(unique_pj_resultRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getAoi_id(), o))).map(tp -> {
                BuildingIdentify o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    BuildingIdentify buildingIdentify = tp._2._2.get();
                    o = copy(o, buildingIdentify);
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pjResultRdd cnt:{}", pjResultRdd.count());
            prePjRdd.unpersist();
            unique_pj_resultRdd.unpersist();


            JavaRDD<BuildingIdentify> pjRdd = pjResultRdd.repartition(10).mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<BuildingIdentify> list = new ArrayList<>();
                while (itr.hasNext()) {


                    cnt = cnt + 1;
                    if (cnt == 5000) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", 5000, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    BuildingIdentify o = itr.next();

                    //新增修改逻辑
                    if(StringUtils.isNotEmpty(o.getSplitResult())){
                        o.setFinal_split(o.getSplitResult());
                    }
                    else if (StringUtils.isNotEmpty(o.getSplit())){



                        String split = o.getSplit();

                        String[] split_list = split.split(";")[0].split("\\|");
                        String  preSplit = "";
                        for (int i = 0 ;i< split_list.length ;i++) {
                            String s = split_list[i];
                            String[] split1 = s.split("\\^");
                            if (split1.length >= 2) {
                                String level = split1[1];
                                String name = split1[0];
                                String after = level.substring(1, level.length());
                                String bef = level.substring(0, 1);
                                preSplit+=name+"^"+after+"^"+bef;
                                if(i < split_list.length -1 ) preSplit+="|";
                            }
                        }


                        o.setFinal_split(preSplit);
                    }
                    else if (StringUtils.isNotEmpty(o.getAddress())){
                        //调分词接口
                        String req_addresseeaddr = o.getAddress();
                        String city_code = o.getCitycode();

                        String splitReq = String.format( splitUrl, URLEncoder.encode(req_addresseeaddr),city_code);
//                    JSONObject splitResp = Utils.retryGet(splitReq);

                        String splitResp = HttpInvokeUtil.sendGet(splitReq);

                        JSONArray splitArr = null;
                        try{
                            splitArr =   JSON.parseObject(splitResp).getJSONObject("result").getJSONObject("data").getJSONArray("info");
                        }catch (Exception e){
                            splitArr = null;
                        }

                        //拼接split result
                        String result = "";
                        if( splitArr != null && splitArr.size() > 0 ) {
                            for(int  i = 0 ;i < splitArr.size() ;i++){
                                JSONObject json =  splitArr.getJSONObject(i);
                                result += json.getString("name") + "^" +json.getString("level")+ "^" + json.getString("prop");
                                if( i < splitArr.size()-1 ) result +=  "|";
                            }
                        }
                        o.setFinal_split(result);
                    }


                    String split = o.getFinal_split();


//                String split = o.getSplit();
                    if (StringUtils.isNotEmpty(split)) {
                        o.setLvl14_info(getlvl14_info(split));
                    }


                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pjRdd cnt:{}", pjRdd.count());




//            JavaRDD<BuildingIdentify> pjRdd = pjResultRdd.map(o -> {
//
//
//
//                return o;
//            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("pjRdd cnt:{}", pjRdd.count());
//新增派件数据 20240116  01424739 谢皓旸
                String newSql =String.format("select \n" +
                        " waybillno\n" +
                        ",fei_call\n" +
                        ",address\n" +
                        ",aoi_code\n" +
                        ",aoi_id\n" +
                        ",citycode\n" +
                        ",split\n" +
                        ",if(type = '全部完备','1','0') is_complete\n" +
                        ",lvl14_info\n" +
                        ",response\n" +
                        ",status\n" +
                        ",a.aoiid\n" +
                        ",splitresult\n" +
                        ",buildingid\n" +
                        ",buildingname\n" +
                        ",bulidingtype\n" +
                        ",x\n" +
                        ",y\n" +
                        ",levelsrc\n" +
                        ",detailsrc\n" +
                        ",nametag\n" +
                        ",final_split\n" +
                        ",zno_code\n" +
                        ",waybillno_src\n" +
                        ",aoi_src\n" +
                        ",inc_day\n" +
                        "from (\n" +
                        "SELECT \n" +
                        " waybill_no as waybillno\n" +
                        ",'' as fei_call\n" +
                        ",consignee_addr as address\n" +
                        ",aoicode as aoi_code\n" +
                        ",aoi_id as aoi_id\n" +
                        ",dest_dist_code as citycode\n" +
                        ",'' as split\n" +
                        ",'0' as lvl14_info\n" +
                        ",climb_err_msg as response\n" +
                        ",get_json_object(climb_err_msg,'$.status') as status\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.aoiId') as aoiid\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.splitResult') as splitresult\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.buildingId') as  buildingid\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.buildingName') as buildingname\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.buildingType') as bulidingtype\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.x') as x\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.y') as y\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.levelSrc') as levelsrc\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.detailSrc') as detailsrc\n" +
                        ",get_json_object(climb_err_msg,'$.result.data.nameTag.matchbdname14') as  nametag\n" +
                        ",'' as final_split\n" +
                        ",dest_zone_code as zno_code\n" +
                        ",'onsite' as waybillno_src\n" +
                        ",'onsite' as aoi_src\n" +
                        ",inc_day\n" +
                        "FROM dm_gis.gis_onsite_service_build_discern_info where inc_day='%s' )a\n" +
                        "inner join (\n" +
                        "SELECT aoiid,type FROM dm_gis.aoi_building\n" +
                        ")b \n" +
                        "on b.aoiid=a.aoi_id ", date);

            JavaRDD<BuildingIdentify> newPrePjRdd = DataUtil.loadData(spark, sc, newSql, BuildingIdentify.class)
                    .filter(o->"010".equals(o.getCitycode()))
                    .map(o->{
                String split= o.getSplitResult();
            if (StringUtils.isNotEmpty(split)) {
                o.setLvl14_info(getlvl14_info(split));
            }
           return o;
            });
            JavaRDD<BuildingIdentify> allPjRdd = newPrePjRdd.union(pjRdd);
            logger.error("最终落表数据:{}", allPjRdd.count());

            logger.error("落结果表:{}",pjTable);
//            DataUtil.saveOverwrite(spark, sc, pjTable, BuildingIdentify.class, allPjRdd, "inc_day");
            DataUtil.saveOverwrite(spark, sc,pjTable , BuildingIdentify.class, allPjRdd, "inc_day");
            pjResultRdd.unpersist();

        }
        sc.stop();
    }

    public static JavaRDD<BuildingIdentify> url(JavaRDD<BuildingIdentify> rdd) {
        JavaRDD<BuildingIdentify> atpoiRdd = run(rdd);

        JavaRDD<BuildingIdentify> secondRdd = atpoiRdd.filter(o -> StringUtils.isEmpty(o.getResponse()) || o.getResponse().contains("too many request by limit count")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<BuildingIdentify> noSecondRdd = atpoiRdd.filter(o -> !(StringUtils.isEmpty(o.getResponse()) || o.getResponse().contains("too many request by limit count"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("secondRdd cnt:{}, noSecondRdd cnt:{}", secondRdd.count(), noSecondRdd.count());
        atpoiRdd.unpersist();

        JavaRDD<BuildingIdentify> runSecondRdd = run(secondRdd);

        JavaRDD<BuildingIdentify> lastRdd = runSecondRdd.union(noSecondRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        runSecondRdd.unpersist();
        noSecondRdd.unpersist();

        return lastRdd;
    }

    public static JavaRDD<BuildingIdentify> run(JavaRDD<BuildingIdentify> rdd) {
        JavaRDD<BuildingIdentify> atpoiRdd = rdd.repartition(10).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<BuildingIdentify> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                BuildingIdentify o = itr.next();
                String address = o.getAddress();
                String aoi_id = o.getAoi_id();
                String citycode = o.getCitycode();
                if (StringUtils.isNotEmpty(address)) {
                    JSONObject param = new JSONObject();

                    param.put("cityCode", citycode);
                    param.put("address", address);
                    param.put("aoiId", aoi_id);
                    param.put("requestId", System.currentTimeMillis());

                    String content = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", "668ad914f8f2466eb3efa0ac5c862264", "utf-8", "utf-8");
                    o = parse(o, content);
                }
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atpoiRdd cnt:{}", atpoiRdd.count());
        rdd.unpersist();

        return atpoiRdd;
    }

    public static BuildingIdentify parse(BuildingIdentify o, String content) {
        if (StringUtils.isNotEmpty(content)) {
            o.setResponse(content);
            try {
                int status = JSON.parseObject(content).getInteger("status");
                o.setStatus(status + "");
                JSONObject result = JSON.parseObject(content).getJSONObject("result");
                if (status == 0 && result != null) {
                    JSONObject data = result.getJSONObject("data");
                    if (data != null) {
                        String aoiId = data.getString("aoiId");
                        String splitResult = data.getString("splitResult");
                        String buildingId = data.getString("buildingId");
                        String x = data.getString("x");
                        String y = data.getString("y");
                        String bulidingType = data.getString("buildingType");
                        String buildingName = data.getString("buildingName");
                        String levelSrc = data.getString("levelSrc");
                        String detailSrc = data.getString("detailSrc");
                        JSONObject nameTag = data.getJSONObject("nameTag");
                        o.setAoiId(aoiId);
                        o.setSplitResult(splitResult);
                        o.setBuildingId(buildingId);
                        o.setX(x);
                        o.setY(y);
                        o.setBulidingType(bulidingType);
                        o.setBuildingName(buildingName);
                        o.setLevelSrc(levelSrc);
                        o.setDetailSrc(detailSrc);
                        if (nameTag != null) {
                            o.setNameTag(nameTag.toJSONString());
                        }
                    }
                }

            } catch (Exception e) {
//                    e.printStackTrace();
            }
        }
        return o;
    }

    public static String getlvl14_info(String split) {
        String lvl14_info = "0";
//        江苏省^11|盐城市^12|盐都区^13|盐龙街道^15|马家牛肉汤馆^213;13
        String[] split_list = split.split(";")[0].split("\\|");
        for (String s : split_list) {
            String[] split1 = s.split("\\^");
            if (split1.length >= 2) {
                String level = split1[1];
//                String after = level.substring(1, level.length());
                if (StringUtils.equals(level, "14")) {
                    lvl14_info = "1";
                    break;
                }
            }
        }
        return lvl14_info;
    }

    public static boolean getStatus(String response) {
        if (StringUtils.isNotEmpty(response)) {
            String msg = JSON.parseObject(response).getJSONObject("result").getString("msg");
            if (StringUtils.equals(msg, "too many request by limit count")) {
                return true;
            }
        }
        return false;
    }

    public static JavaRDD<BuildingIdentify> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.building_identify where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, BuildingIdentify.class);
    }


    public static BuildingIdentify copy(BuildingIdentify o, BuildingIdentify buildingIdentify) {
        o.setResponse(buildingIdentify.getResponse());
        o.setStatus(buildingIdentify.getStatus());
        o.setAoiId(buildingIdentify.getAoiId());
        o.setSplitResult(buildingIdentify.getSplitResult());
        o.setBuildingId(buildingIdentify.getBuildingId());
        o.setX(buildingIdentify.getX());
        o.setY(buildingIdentify.getY());
        o.setBulidingType(buildingIdentify.getBulidingType());
        o.setBuildingName(buildingIdentify.getBuildingName());
        o.setLevelSrc(buildingIdentify.getLevelSrc());
        o.setDetailSrc(buildingIdentify.getDetailSrc());
        o.setNameTag(buildingIdentify.getNameTag());

        return o;
    }

}
