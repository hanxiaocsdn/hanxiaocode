package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class HnYnXiaoge implements Serializable {
    @Column(name = "un")
    private String un;
    @Column(name = "name")
    private String name;
    @Column(name = "dept")
    private String dept;
    @Column(name = "area")
    private String area;
    @Column(name = "start_zx")
    private String start_zx;
    @Column(name = "start_zy")
    private String start_zy;
    @Column(name = "radius")
    private String radius;
    @Column(name = "inc_day")
    private String inc_day;

    public HnYnXiaoge() {
    }

    public HnYnXiaoge(String un, String name, String dept, String area) {
        this.un = un;
        this.name = name;
        this.dept = dept;
        this.area = area;
    }

    public String getStart_zx() {
        return start_zx;
    }

    public void setStart_zx(String start_zx) {
        this.start_zx = start_zx;
    }

    public String getStart_zy() {
        return start_zy;
    }

    public void setStart_zy(String start_zy) {
        this.start_zy = start_zy;
    }

    public String getRadius() {
        return radius;
    }

    public void setRadius(String radius) {
        this.radius = radius;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getUn() {
        return un;
    }

    public void setUn(String un) {
        this.un = un;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
