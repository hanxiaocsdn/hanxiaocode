package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.ClassExecutionConditionController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppClassExecutionCondition {
    private static Logger logger = LoggerFactory.getLogger(AppClassExecutionCondition.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new ClassExecutionConditionController().start(startDate, endDate);
        logger.error("run end");
    }
}
