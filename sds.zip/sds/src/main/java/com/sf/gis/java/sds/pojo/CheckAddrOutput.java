package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CheckAddrOutput implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "receiver_city_number")
    private String receiver_city_number;
    @Column(name = "receiver_website_code")
    private String receiver_website_code;
    @Column(name = "receiver_province_name")
    private String receiver_province_name;
    @Column(name = "receiver_city_name")
    private String receiver_city_name;
    @Column(name = "receiver_area_name")
    private String receiver_area_name;
    @Column(name = "receiver_company")
    private String receiver_company;
    @Column(name = "receiver_name")
    private String receiver_name;
    @Column(name = "address")
    private String address;

    private String fulladdress;
    private String fulladdress_r;
    private int status;
    private String addr_wsbfreq;
    private String splitResult;
    private String join_level;

    private String term1;
    private String type;
    private String term2;
    private String term3;
    private String area;
    private String finalarea;

    private String term1_addr;
    private String term2_addr;
    private String term3_addr;

    private String term1_freq;
    private String term2_freq;
    private String term3_freq;

    public String getTerm1_addr() {
        return term1_addr;
    }

    public void setTerm1_addr(String term1_addr) {
        this.term1_addr = term1_addr;
    }

    public String getTerm2_addr() {
        return term2_addr;
    }

    public void setTerm2_addr(String term2_addr) {
        this.term2_addr = term2_addr;
    }

    public String getTerm3_addr() {
        return term3_addr;
    }

    public void setTerm3_addr(String term3_addr) {
        this.term3_addr = term3_addr;
    }

    public String getTerm1_freq() {
        return term1_freq;
    }

    public void setTerm1_freq(String term1_freq) {
        this.term1_freq = term1_freq;
    }

    public String getTerm2_freq() {
        return term2_freq;
    }

    public void setTerm2_freq(String term2_freq) {
        this.term2_freq = term2_freq;
    }

    public String getTerm3_freq() {
        return term3_freq;
    }

    public void setTerm3_freq(String term3_freq) {
        this.term3_freq = term3_freq;
    }

    public String getFinalarea() {
        return finalarea;
    }

    public void setFinalarea(String finalarea) {
        this.finalarea = finalarea;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getTerm3() {
        return term3;
    }

    public void setTerm3(String term3) {
        this.term3 = term3;
    }

    public String getTerm2() {
        return term2;
    }

    public void setTerm2(String term2) {
        this.term2 = term2;
    }

    public String getTerm1() {
        return term1;
    }

    public void setTerm1(String term1) {
        this.term1 = term1;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getJoin_level() {
        return join_level;
    }

    public void setJoin_level(String join_level) {
        this.join_level = join_level;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getAddr_wsbfreq() {
        return addr_wsbfreq;
    }

    public void setAddr_wsbfreq(String addr_wsbfreq) {
        this.addr_wsbfreq = addr_wsbfreq;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getFulladdress() {
        return fulladdress;
    }

    public void setFulladdress(String fulladdress) {
        this.fulladdress = fulladdress;
    }

    public String getFulladdress_r() {
        return fulladdress_r;
    }

    public void setFulladdress_r(String fulladdress_r) {
        this.fulladdress_r = fulladdress_r;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getReceiver_city_number() {
        return receiver_city_number;
    }

    public void setReceiver_city_number(String receiver_city_number) {
        this.receiver_city_number = receiver_city_number;
    }

    public String getReceiver_website_code() {
        return receiver_website_code;
    }

    public void setReceiver_website_code(String receiver_website_code) {
        this.receiver_website_code = receiver_website_code;
    }

    public String getReceiver_province_name() {
        return receiver_province_name;
    }

    public void setReceiver_province_name(String receiver_province_name) {
        this.receiver_province_name = receiver_province_name;
    }

    public String getReceiver_city_name() {
        return receiver_city_name;
    }

    public void setReceiver_city_name(String receiver_city_name) {
        this.receiver_city_name = receiver_city_name;
    }

    public String getReceiver_area_name() {
        return receiver_area_name;
    }

    public void setReceiver_area_name(String receiver_area_name) {
        this.receiver_area_name = receiver_area_name;
    }

    public String getReceiver_company() {
        return receiver_company;
    }

    public void setReceiver_company(String receiver_company) {
        this.receiver_company = receiver_company;
    }

    public String getReceiver_name() {
        return receiver_name;
    }

    public void setReceiver_name(String receiver_name) {
        this.receiver_name = receiver_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
