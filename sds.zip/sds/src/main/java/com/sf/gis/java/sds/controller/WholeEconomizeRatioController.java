package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.WholeEconomizeRatio;
import com.sf.gis.java.sds.service.WholeEconomizeRatioService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class WholeEconomizeRatioController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(WholeEconomizeRatioController.class);
    WholeEconomizeRatioService service = new WholeEconomizeRatioService();

    public void start(String startDate, String endDate) {
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<WholeEconomizeRatio> wholeEconomizeRatioRdd = service.loadData(spark, sc, date).filter(o -> (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.isNotEmpty(o.getTaskAreaCode())).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("wholeEconomizeRatioRdd cnt:{}", wholeEconomizeRatioRdd.count());
            wholeEconomizeRatioRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<WholeEconomizeRatio> wholeEconomizeRatioResultRdd = wholeEconomizeRatioRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<WholeEconomizeRatio> list = Lists.newArrayList(tp._2);
                WholeEconomizeRatio wholeEconomizeRatio = list.get(0);

                // [自营]任务量
                int zy_taskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(WholeEconomizeRatio::getTaskId))), ArrayList::new))
                        .size();

                //[自营]基准总etc
                double zy_sumBaseLineToll = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));


                //[自营]总etc
                double zy_sumEtcTollCharge = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                wholeEconomizeRatio.setZy_taskNumber(zy_taskNumber);
                wholeEconomizeRatio.setZy_sumBaseLineToll(zy_sumBaseLineToll);
                wholeEconomizeRatio.setZy_sumEtcTollCharge(zy_sumEtcTollCharge);

                return wholeEconomizeRatio;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("wholeEconomizeRatioResultRdd cnt:{}", wholeEconomizeRatioResultRdd.count());
            wholeEconomizeRatioResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            wholeEconomizeRatioRdd.unpersist();
            if (wholeEconomizeRatioResultRdd.count() > 0) {
                if (flag != size) {
                    //删除数据
                    spark.sql(String.format("insert overwrite table dm_gis.ETA_WHOLE_ECONOMICAL_RATIO_STAT select * from dm_gis.ETA_WHOLE_ECONOMICAL_RATIO_STAT where stat_date != '%s'", date));
                    service.delete(date);
                }
                service.saveData(spark, wholeEconomizeRatioResultRdd);
                service.saveToMysql(sc, wholeEconomizeRatioResultRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            wholeEconomizeRatioResultRdd.unpersist();
        }
        spark.stop();
    }
}
