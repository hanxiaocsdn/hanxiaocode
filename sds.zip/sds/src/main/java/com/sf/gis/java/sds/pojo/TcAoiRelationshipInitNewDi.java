package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TcAoiRelationshipInitNewDi implements Serializable {
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "tccode")
    private String tccode;

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getTccode() {
        return tccode;
    }

    public void setTccode(String tccode) {
        this.tccode = tccode;
    }
}
