package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class AdsTransferSdsAoiReport implements Serializable {
    @Column(name = "create_time")
    private String create_time;
    @Column(name = "ak")
    private String ak;
    @Column(name = "remote_ip")
    private String remote_ip;
    @Column(name = "url")
    private String url;
    @Column(name = "order_id")
    private String order_id;
    @Column(name = "address")
    private String address;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "staff_id")
    private String staff_id;
    @Column(name = "opt_date")
    private String opt_date;
    @Column(name = "update_date")
    private String update_date;
    @Column(name = "cd_flag")
    private String cd_flag;
    @Column(name = "address_check")
    private String address_check;
    @Column(name = "aoi_area_code")
    private String aoi_area_code;
    @Column(name = "aoi_area_code_chk")
    private String aoi_area_code_chk;
    @Column(name = "aoi_area_code_remark")
    private String aoi_area_code_remark;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_id_check")
    private String aoi_id_check;
    @Column(name = "aoi_id_remark")
    private String aoi_id_remark;
    @Column(name = "aoi_type")
    private String aoi_type;
    @Column(name = "aoi_type_check")
    private String aoi_type_check;
    @Column(name = "aoi_type_remark")
    private String aoi_type_remark;
    @Column(name = "waybill_date")
    private String waybill_date;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "aoi_id_remark_name")
    private String aoi_id_remark_name;
    @Column(name = "standardization")
    private String standardization;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "apply_addr13")
    private String apply_addr13;
    @Column(name = "origin_aoi13")
    private String origin_aoi13;
    @Column(name = "sim_text_ori")
    private String sim_text_ori;
    @Column(name = "sim_pinyin_ori")
    private String sim_pinyin_ori;
    @Column(name = "submit_aoiname")
    private String submit_aoiname;
    @Column(name = "sim_text_sub")
    private String sim_text_sub;
    @Column(name = "sim_pinyin_sub")
    private String sim_pinyin_sub;

    @Column(name = "submit_village_id")
    private String submit_village_id;
    @Column(name = "submit_village_name")
    private String submit_village_name;

    @Column(name = "navillagetextsim_dict")
    private String navillagetextsim_dict;
    @Column(name = "navillagetextsim_max")
    private String navillagetextsim_max;

    @Column(name = "navillagepinyinsim_dict")
    private String navillagepinyinsim_dict;
    @Column(name = "navillagepinyinsim_max")
    private String navillagepinyinsim_max;

    @Column(name = "ogcnearestaoi_resp")
    private String ogcnearestaoi_resp;
    @Column(name = "submitvillage_aoiid")
    private String submitvillage_aoiid;
    @Column(name = "submitvillage_aoiname")
    private String submitvillage_aoiname;
    @Column(name = "submitvillage_znocode")
    private String submitvillage_znocode;
    @Column(name = "conti_navlillag")
    private String conti_navlillag;
    @Column(name = "contivillage_aoiid")
    private String contivillage_aoiid;
    @Column(name = "conti_navillagesim_return")
    private String conti_navillagesim_return;
    @Column(name = "gd_result")
    private String gd_result;
    @Column(name = "amappois")
    private String amappois;
    @Column(name = "gd_return")
    private String gd_return;
    @Column(name = "gd_aoiid")
    private String gd_aoiid;
    @Column(name = "twokm_gd_return")
    private String twokm_gd_return;
    @Column(name = "twokm_gd_aoiid")
    private String twokm_gd_aoiid;

    @Column(name = "result")
    private String result;
    @Column(name = "tag")
    private String tag;
    @Column(name = "aoiid_apply")
    private String aoiid_apply;
    @Column(name = "aoiid_tag")
    private String aoiid_tag;

    @Column(name = "new_aoi_id_remark")
    private String new_aoi_id_remark;
    @Column(name = "dept_type_code")
    private String dept_type_code;
    @Column(name = "inc_day")
    private String inc_day;

    private double sim_text_max;
    private double sim_pinyin_max;
    private String near_guid;
    private List<XzcVillage> list;
    private List<GdPoi> gd_list;

    public String getDept_type_code() {
        return dept_type_code;
    }

    public void setDept_type_code(String dept_type_code) {
        this.dept_type_code = dept_type_code;
    }

    public String getNew_aoi_id_remark() {
        return new_aoi_id_remark;
    }

    public void setNew_aoi_id_remark(String new_aoi_id_remark) {
        this.new_aoi_id_remark = new_aoi_id_remark;
    }

    public String getTwokm_gd_return() {
        return twokm_gd_return;
    }

    public void setTwokm_gd_return(String twokm_gd_return) {
        this.twokm_gd_return = twokm_gd_return;
    }

    public String getTwokm_gd_aoiid() {
        return twokm_gd_aoiid;
    }

    public void setTwokm_gd_aoiid(String twokm_gd_aoiid) {
        this.twokm_gd_aoiid = twokm_gd_aoiid;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getGd_return() {
        return gd_return;
    }

    public void setGd_return(String gd_return) {
        this.gd_return = gd_return;
    }

    public String getAmappois() {
        return amappois;
    }

    public void setAmappois(String amappois) {
        this.amappois = amappois;
    }

    public List<GdPoi> getGd_list() {
        return gd_list;
    }

    public void setGd_list(List<GdPoi> gd_list) {
        this.gd_list = gd_list;
    }

    public String getGd_result() {
        return gd_result;
    }

    public void setGd_result(String gd_result) {
        this.gd_result = gd_result;
    }

    public String getConti_navillagesim_return() {
        return conti_navillagesim_return;
    }

    public void setConti_navillagesim_return(String conti_navillagesim_return) {
        this.conti_navillagesim_return = conti_navillagesim_return;
    }

    public String getContivillage_aoiid() {
        return contivillage_aoiid;
    }

    public void setContivillage_aoiid(String contivillage_aoiid) {
        this.contivillage_aoiid = contivillage_aoiid;
    }

    public List<XzcVillage> getList() {
        return list;
    }

    public void setList(List<XzcVillage> list) {
        this.list = list;
    }

    public String getConti_navlillag() {
        return conti_navlillag;
    }

    public void setConti_navlillag(String conti_navlillag) {
        this.conti_navlillag = conti_navlillag;
    }

    public String getNear_guid() {
        return near_guid;
    }

    public void setNear_guid(String near_guid) {
        this.near_guid = near_guid;
    }

    public String getOgcnearestaoi_resp() {
        return ogcnearestaoi_resp;
    }

    public void setOgcnearestaoi_resp(String ogcnearestaoi_resp) {
        this.ogcnearestaoi_resp = ogcnearestaoi_resp;
    }

    public String getSubmitvillage_aoiid() {
        return submitvillage_aoiid;
    }

    public void setSubmitvillage_aoiid(String submitvillage_aoiid) {
        this.submitvillage_aoiid = submitvillage_aoiid;
    }

    public String getSubmitvillage_aoiname() {
        return submitvillage_aoiname;
    }

    public void setSubmitvillage_aoiname(String submitvillage_aoiname) {
        this.submitvillage_aoiname = submitvillage_aoiname;
    }

    public String getSubmitvillage_znocode() {
        return submitvillage_znocode;
    }

    public void setSubmitvillage_znocode(String submitvillage_znocode) {
        this.submitvillage_znocode = submitvillage_znocode;
    }

    public double getSim_text_max() {
        return sim_text_max;
    }

    public void setSim_text_max(double sim_text_max) {
        this.sim_text_max = sim_text_max;
    }

    public double getSim_pinyin_max() {
        return sim_pinyin_max;
    }

    public void setSim_pinyin_max(double sim_pinyin_max) {
        this.sim_pinyin_max = sim_pinyin_max;
    }

    public String getNavillagetextsim_dict() {
        return navillagetextsim_dict;
    }

    public void setNavillagetextsim_dict(String navillagetextsim_dict) {
        this.navillagetextsim_dict = navillagetextsim_dict;
    }

    public String getNavillagepinyinsim_dict() {
        return navillagepinyinsim_dict;
    }

    public void setNavillagepinyinsim_dict(String navillagepinyinsim_dict) {
        this.navillagepinyinsim_dict = navillagepinyinsim_dict;
    }

    public String getNavillagetextsim_max() {
        return navillagetextsim_max;
    }

    public void setNavillagetextsim_max(String navillagetextsim_max) {
        this.navillagetextsim_max = navillagetextsim_max;
    }

    public String getNavillagepinyinsim_max() {
        return navillagepinyinsim_max;
    }

    public void setNavillagepinyinsim_max(String navillagepinyinsim_max) {
        this.navillagepinyinsim_max = navillagepinyinsim_max;
    }

    public String getSubmit_village_id() {
        return submit_village_id;
    }

    public void setSubmit_village_id(String submit_village_id) {
        this.submit_village_id = submit_village_id;
    }

    public String getSubmit_village_name() {
        return submit_village_name;
    }

    public void setSubmit_village_name(String submit_village_name) {
        this.submit_village_name = submit_village_name;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getAoiid_apply() {
        return aoiid_apply;
    }

    public void setAoiid_apply(String aoiid_apply) {
        this.aoiid_apply = aoiid_apply;
    }

    public String getAoiid_tag() {
        return aoiid_tag;
    }

    public void setAoiid_tag(String aoiid_tag) {
        this.aoiid_tag = aoiid_tag;
    }

    public String getOrigin_aoi13() {
        return origin_aoi13;
    }

    public void setOrigin_aoi13(String origin_aoi13) {
        this.origin_aoi13 = origin_aoi13;
    }

    public String getSim_text_ori() {
        return sim_text_ori;
    }

    public void setSim_text_ori(String sim_text_ori) {
        this.sim_text_ori = sim_text_ori;
    }

    public String getSim_pinyin_ori() {
        return sim_pinyin_ori;
    }

    public void setSim_pinyin_ori(String sim_pinyin_ori) {
        this.sim_pinyin_ori = sim_pinyin_ori;
    }

    public String getSim_text_sub() {
        return sim_text_sub;
    }

    public void setSim_text_sub(String sim_text_sub) {
        this.sim_text_sub = sim_text_sub;
    }

    public String getSim_pinyin_sub() {
        return sim_pinyin_sub;
    }

    public void setSim_pinyin_sub(String sim_pinyin_sub) {
        this.sim_pinyin_sub = sim_pinyin_sub;
    }

    public String getSubmit_aoiname() {
        return submit_aoiname;
    }

    public void setSubmit_aoiname(String submit_aoiname) {
        this.submit_aoiname = submit_aoiname;
    }


    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getAoi_id_remark_name() {
        return aoi_id_remark_name;
    }

    public void setAoi_id_remark_name(String aoi_id_remark_name) {
        this.aoi_id_remark_name = aoi_id_remark_name;
    }

    public String getApply_addr13() {
        return apply_addr13;
    }

    public void setApply_addr13(String apply_addr13) {
        this.apply_addr13 = apply_addr13;
    }

    public String getStandardization() {
        return standardization;
    }

    public void setStandardization(String standardization) {
        this.standardization = standardization;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getRemote_ip() {
        return remote_ip;
    }

    public void setRemote_ip(String remote_ip) {
        this.remote_ip = remote_ip;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getStaff_id() {
        return staff_id;
    }

    public void setStaff_id(String staff_id) {
        this.staff_id = staff_id;
    }

    public String getOpt_date() {
        return opt_date;
    }

    public void setOpt_date(String opt_date) {
        this.opt_date = opt_date;
    }

    public String getUpdate_date() {
        return update_date;
    }

    public void setUpdate_date(String update_date) {
        this.update_date = update_date;
    }

    public String getCd_flag() {
        return cd_flag;
    }

    public void setCd_flag(String cd_flag) {
        this.cd_flag = cd_flag;
    }

    public String getAddress_check() {
        return address_check;
    }

    public void setAddress_check(String address_check) {
        this.address_check = address_check;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getAoi_area_code_chk() {
        return aoi_area_code_chk;
    }

    public void setAoi_area_code_chk(String aoi_area_code_chk) {
        this.aoi_area_code_chk = aoi_area_code_chk;
    }

    public String getAoi_area_code_remark() {
        return aoi_area_code_remark;
    }

    public void setAoi_area_code_remark(String aoi_area_code_remark) {
        this.aoi_area_code_remark = aoi_area_code_remark;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_id_check() {
        return aoi_id_check;
    }

    public void setAoi_id_check(String aoi_id_check) {
        this.aoi_id_check = aoi_id_check;
    }

    public String getAoi_id_remark() {
        return aoi_id_remark;
    }

    public void setAoi_id_remark(String aoi_id_remark) {
        this.aoi_id_remark = aoi_id_remark;
    }

    public String getAoi_type() {
        return aoi_type;
    }

    public void setAoi_type(String aoi_type) {
        this.aoi_type = aoi_type;
    }

    public String getAoi_type_check() {
        return aoi_type_check;
    }

    public void setAoi_type_check(String aoi_type_check) {
        this.aoi_type_check = aoi_type_check;
    }

    public String getAoi_type_remark() {
        return aoi_type_remark;
    }

    public void setAoi_type_remark(String aoi_type_remark) {
        this.aoi_type_remark = aoi_type_remark;
    }

    public String getWaybill_date() {
        return waybill_date;
    }

    public void setWaybill_date(String waybill_date) {
        this.waybill_date = waybill_date;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
