package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GisRdsOmsto implements Serializable {

    @Column(name = "req_waybillno")
    private String req_waybillno;
    @Column(name = "req_destcitycode")
    private String req_destcitycode;
    @Column(name = "address")
    private String address;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "req_addresseephone")
    private String req_addresseephone;
    @Column(name = "req_addresseemobile")
    private String req_addresseemobile;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "id")
    private String id;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "standardization")
    private String standardization;

    private String src;
    private String groupid;
    private String aoiid;

    private String cf_aoiid;
    private String buildingId;
    private String buildingName;
    private String source;
    private String geoPrecision;
    @Column(name = "splitresult")
    private String splitResult;

    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getStandardization() {
        return standardization;
    }

    public void setStandardization(String standardization) {
        this.standardization = standardization;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getCf_aoiid() {
        return cf_aoiid;
    }

    public void setCf_aoiid(String cf_aoiid) {
        this.cf_aoiid = cf_aoiid;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(String buildingId) {
        this.buildingId = buildingId;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getGeoPrecision() {
        return geoPrecision;
    }

    public void setGeoPrecision(String geoPrecision) {
        this.geoPrecision = geoPrecision;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getReq_waybillno() {
        return req_waybillno;
    }

    public void setReq_waybillno(String req_waybillno) {
        this.req_waybillno = req_waybillno;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getReq_addresseephone() {
        return req_addresseephone;
    }

    public void setReq_addresseephone(String req_addresseephone) {
        this.req_addresseephone = req_addresseephone;
    }

    public String getReq_addresseemobile() {
        return req_addresseemobile;
    }

    public void setReq_addresseemobile(String req_addresseemobile) {
        this.req_addresseemobile = req_addresseemobile;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
