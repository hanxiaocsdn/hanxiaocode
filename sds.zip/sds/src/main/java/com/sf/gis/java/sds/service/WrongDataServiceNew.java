package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.bean.DeptData;
import com.sf.gis.java.sds.service.impl.IWrongDataService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.List;


public class WrongDataServiceNew extends BaseService implements IWrongDataService, Serializable {
    private static final Logger logger = LoggerFactory.getLogger(WrongDataServiceNew.class);

    /**
     *
     */
    private static final long serialVersionUID = 4747144253264366403L;
    private final static String HIVE_WRONG_DATA_DIFF = "dm_gis.sss_gis_diff_origin_data_by_day";
    private final static String HIVE_WRONG_DATA_DEPT_EMPTY = "dm_gis.sss_gis_miss_new";
    public static final String RDS_TABLE = "dm_gis.gis_toaddr_stat_new2";

    public WrongDataServiceNew() {
        this(null);
    }

    public WrongDataServiceNew(SparkSession sparkSession) {
        super(sparkSession);
    }

    private void insertHiveDiff(String date, String cityCodes) {
        String insertSql = "insert into table " + HIVE_WRONG_DATA_DIFF + " partition(inc_day='" + date
                + "')  select req_waybillno waybillNo, req_addresseeaddr address,"
                + "max(gis_to_sys_gisdeptcodeto) gisDeptcode,max(gis_to_sys_sssdeptcodeto) sssDeptcode,"
                + "max(arss_dept_req_address) arssRequest,max(arss_dept_re_identrs) arssDeptCode,"
                + "max(gis_to_sys_gisteamcodeto) gisTeamCodeTo,max(gis_to_sys_src) src," + "req_destcitycode cityCode, "
                + "max(gis_to_sys_groupid) group_id,max(gis_to_sys_depttoretby) deptBy, "
                + "max(req_time) req_time from " + RDS_TABLE + " where " + "inc_day = '" + date + "' "
                + (cityCodes == null ? " and req_destcitycode is not null and req_destcitycode <> '' "
                : (" and req_destcitycode in " + cityCodes))
                + " and gis_to_sys_gisdeptcodeto is not null and gis_to_sys_gisdeptcodeto <> '' "
                + " and gis_to_sys_sssdeptcodeto is not null and gis_to_sys_sssdeptcodeto <> '' "
                + " and gis_to_sys_gisdeptcodeto <> gis_to_sys_sssdeptcodeto "
                + " group by req_waybillno,req_addresseeaddr,req_destcitycode ";
        logger.error("insertSql:" + insertSql);
        sparkSession.sql(insertSql);
    }

    private void deleteHiveRepeatDataDiff(String date) {
        String deleteSql = "ALTER TABLE " + HIVE_WRONG_DATA_DIFF + " DROP IF EXISTS PARTITION (inc_day='" + date + "')";
        logger.error("deleteSql:" + deleteSql);
        sparkSession.sql(deleteSql);
    }

    @SuppressWarnings("serial")
    @Override
    public List<DeptData> getWrongDataDiff(String date) {
        String selectSql = "select waybillNo,  address, gisDeptcode, sssDeptcode, arssRequest, arssDeptCode,"
                + " gisTeamCodeTo, src, cityCode,  group_id,deptBy,inc_day from " + HIVE_WRONG_DATA_DIFF
                + " where inc_day='" + date + "'";
        logger.error("selectSql:" + selectSql);
        JavaRDD<DeptData> rdd = sparkSession.sql(selectSql).javaRDD().map(new Function<Row, DeptData>() {
            @Override
            public DeptData call(Row v1) throws Exception {
                return new DeptData(v1.getString(2), v1.getString(3), v1.getString(4), v1.getString(5),
                        v1.getString(10), v1.getString(0), v1.getString(1), v1.getString(7), v1.getString(6),
                        v1.getString(11), v1.getString(8), null, null);
            }
        });
        return rdd.collect();
    }

    private void createHiveDiff() {
        String createSql = "create table IF NOT EXISTS " + HIVE_WRONG_DATA_DIFF + "(waybillNo String, address String,"
                + "gisDeptcode String, sssDeptcode String,arssRequest String, arssDeptCode String,"
                + "gisTeamCodeTo String,src String,cityCode String,"
                + "group_id String,deptBy String,req_time String) PARTITIONED BY (inc_day String)";
        logger.error("createSql:" + createSql);
        sparkSession.sql(createSql);
    }

    @SuppressWarnings("serial")
    @Override
    public List<DeptData> getWrongDataDeptEmpty(String date, String cityCode) {
        String selectSql = "select waybillNo,  address, gisDeptcode, sssDeptcode, arssRequest, arssDeptCode,"
                + " gisTeamCodeTo, src, cityCode,  group_id,deptBy,inc_day,req_time,deptcode from " + HIVE_WRONG_DATA_DEPT_EMPTY
                + " where inc_day='" + date + "' and cityCode ='" + cityCode + "'";
        logger.error("selectSql:" + selectSql);
        JavaRDD<DeptData> rdd = sparkSession.sql(selectSql).javaRDD().map(new Function<Row, DeptData>() {
            @Override
            public DeptData call(Row v1) throws Exception {
                return new DeptData(v1.getString(2), v1.getString(3), v1.getString(4), v1.getString(5),
                        v1.getString(10), v1.getString(0), v1.getString(1), v1.getString(7), v1.getString(6),
                        v1.getString(11), v1.getString(8), v1.getString(12), v1.getString(13));
            }
        });
        return rdd.collect();
    }

    private void insertHiveDeptEmpty(String date, String cityCodes, String gisEmptyCity) {
        String insertSql = "insert into table " + HIVE_WRONG_DATA_DEPT_EMPTY + " partition(inc_day='" + date
                + "')  select  waybillno, address,"
                + "max(log_gisdeptcode) gisDeptcode,max(log_sssdeptcode) sssDeptcode," + "'',''," + "'','',"
                + "citycode cityCode, " + "'',''," + "max(req_time) req_time ,max(deptcode) deptcode from " + RDS_TABLE + " where " + "inc_day = '" + date + "' "
                + (cityCodes == null ? " and citycode is not null and citycode <> '' "
                : (" and citycode in " + cityCodes))
                + " and (log_gisdeptcode is  null or log_gisdeptcode like '') " + " and ("
                + (gisEmptyCity == null ? "" : ("citycode in " + gisEmptyCity + " or "))
                + "log_sssdeptcode is  null or log_sssdeptcode like '') " + " group by waybillno,address,citycode ";
        logger.error("insertSql:" + insertSql);
        sparkSession.sql(insertSql);
    }

    private void deleteHiveRepeatDataDeptEmpty(String date) {
        String deleteSql = "ALTER TABLE " + HIVE_WRONG_DATA_DEPT_EMPTY + " DROP IF EXISTS PARTITION (inc_day='" + date
                + "')";
        logger.error("deleteSql:" + deleteSql);
        sparkSession.sql(deleteSql);
    }

    private void createHiveDeptEmpty() {
        String createSql = "create table IF NOT EXISTS " + HIVE_WRONG_DATA_DEPT_EMPTY
                + "(waybillNo String, address String,"
                + "gisDeptcode String, sssDeptcode String,arssRequest String, arssDeptCode String,"
                + "gisTeamCodeTo String,src String,cityCode String,"
                + "group_id String,deptBy String,req_time String,deptcode String) PARTITIONED BY (inc_day String)";
        logger.error("createSql:" + createSql);
        sparkSession.sql(createSql);
    }

    @Override
    public void createDiffData(String date) {
        createHiveDiff();
        deleteHiveRepeatDataDiff(date);
        insertHiveDiff(date, null);
    }

    @Override
    public void createDeptEmptyData(String date, String gisEmptyCity) {
        createHiveDeptEmpty();
        deleteHiveRepeatDataDeptEmpty(date);
        insertHiveDeptEmpty(date, null, gisEmptyCity);
    }
}