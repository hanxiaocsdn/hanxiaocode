package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class SssGisRdsOmsto implements Serializable {
    @Column(name = "req_waybillno")
    private String req_waybillno;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_destcitycode")
    private String req_destcitycode;
    @Column(name = "req_addresseephone")
    private String req_addresseephone;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "gis_to_sys_src")
    private String gis_to_sys_src;

    private String new_splitresult;
    private List<SssDwdWaybillInfoDtlDi> list;

    private String tags;

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public List<SssDwdWaybillInfoDtlDi> getList() {
        return list;
    }

    public void setList(List<SssDwdWaybillInfoDtlDi> list) {
        this.list = list;
    }

    public String getNew_splitresult() {
        return new_splitresult;
    }

    public void setNew_splitresult(String new_splitresult) {
        this.new_splitresult = new_splitresult;
    }

    public String getReq_waybillno() {
        return req_waybillno;
    }

    public void setReq_waybillno(String req_waybillno) {
        this.req_waybillno = req_waybillno;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getReq_addresseephone() {
        return req_addresseephone;
    }

    public void setReq_addresseephone(String req_addresseephone) {
        this.req_addresseephone = req_addresseephone;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getGis_to_sys_src() {
        return gis_to_sys_src;
    }

    public void setGis_to_sys_src(String gis_to_sys_src) {
        this.gis_to_sys_src = gis_to_sys_src;
    }
}
