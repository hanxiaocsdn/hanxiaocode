package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.FalseControlsController;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 虚假管控：实时弹窗逻辑修正验证（程序入口）（需求方：刘雨婷）
 * @author 01370539
 * Created on Jun.20 2022
 */
public class FalseControlsApp {
    private static final Logger logger = LoggerFactory.getLogger(FalseControlsApp.class);

    public static void main(String[] args) {
        logger.error(">>>>>>>> start <<<<<<<<");
        if (args.length >= 4) {
            String cityCode = args[0];
            String incDay = args[1];
            String isFromRs = args[2];
            String operType = args[3];
            int chkAoiBuffer = 200;
            if ("DLV".equals(operType)) {
                if (args.length >= 5) {
                    chkAoiBuffer = Integer.parseInt(args[4]);
                }
                new FalseControlsController().processDlv(cityCode, incDay, isFromRs, chkAoiBuffer);
            } else {
//                new FalseControlsController().processPu(cityCode, incDay, isFromRs);
            }
        } else {
            logger.error("there's no valid param. cur param is: {}", args);
        }
        logger.error(">>>>>>>> end <<<<<<<<");
    }

}
