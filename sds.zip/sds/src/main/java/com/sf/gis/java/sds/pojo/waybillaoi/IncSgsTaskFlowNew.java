package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class IncSgsTaskFlowNew implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "operatime_new")
    private String operatime_new;
    @Column(name = "eventlng")
    private String eventlng;
    @Column(name = "eventlat")
    private String eventlat;
    @Column(name = "eventtype")
    private String eventtype;
    @Column(name = "userid")
    private String userid;
    @Column(name = "inc_day")
    private String inc_day;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getOperatime_new() {
        return operatime_new;
    }

    public void setOperatime_new(String operatime_new) {
        this.operatime_new = operatime_new;
    }

    public String getEventlng() {
        return eventlng;
    }

    public void setEventlng(String eventlng) {
        this.eventlng = eventlng;
    }

    public String getEventlat() {
        return eventlat;
    }

    public void setEventlat(String eventlat) {
        this.eventlat = eventlat;
    }

    public String getEventtype() {
        return eventtype;
    }

    public void setEventtype(String eventtype) {
        this.eventtype = eventtype;
    }
}
