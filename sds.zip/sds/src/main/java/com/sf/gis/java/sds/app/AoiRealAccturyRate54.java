package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiAccuracyAddrTsAoiJoinTrajShouRet;
import com.sf.gis.java.sds.service.AoiRealAccturyRateService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class AoiRealAccturyRate54 {
    private static Logger logger = LoggerFactory.getLogger(AoiRealAccturyRate54.class);

    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[0];
        logger.error("date1:{},date2:{}", date1, date2);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AoiRealAccturyRate54");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        AoiRealAccturyRateService service = new AoiRealAccturyRateService();

        List<String> dateList = DateUtil.getDateList(date1, date2, "yyyyMMdd");
        for (String date : dateList) {
            logger.error("date:{}", date);
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> sourceRdd = loadSourceData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sourceRdd cnt:{}", sourceRdd.count());

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> resultRdd = sourceRdd.map(o -> {
                String tag1 = o.getTag1();
                if (StringUtils.isNotEmpty(tag1) && StringUtils.equals(tag1, "wrong")) {
                    String aoi_code_54 = o.getAoi_code_54();
                    String finalaoicode = o.getFinalaoicode();
                    if (StringUtils.isNotEmpty(aoi_code_54) && StringUtils.isNotEmpty(finalaoicode) && StringUtils.equals(aoi_code_54, finalaoicode)) {
                        o.setTag1("correct");
                        o.setTag2("final_54");
                    } else {
                        String req_address = o.getReq_address();
                        String gis_aoi_name = o.getGis_aoi_name();
                        String aoi_name_54 = o.getAoi_name_54();
                        if (StringUtils.isNotEmpty(req_address) && StringUtils.isNotEmpty(gis_aoi_name)) {
                            String new_address = StringNumUtils.outputArabNumberString(req_address).toUpperCase();
                            String new_aoi_name = StringNumUtils.outputArabNumberString(gis_aoi_name).toUpperCase();
                            if (new_address.contains(new_aoi_name)) {
                                if (StringUtils.isEmpty(aoi_name_54)) {
                                    o.setTag1("correct");
                                    o.setTag2("final_aoiname");
                                } else {
                                    String new_aoi_name_54 = StringNumUtils.outputArabNumberString(aoi_name_54).toUpperCase();
                                    if (!new_address.contains(new_aoi_name_54)) {
                                        o.setTag1("correct");
                                        o.setTag2("final_aoiname");
                                    }
                                }
                            }
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            sourceRdd.unpersist();

            spark.sql(String.format("alter table dm_gis.aoi_accuracy_54_aoiname_ret drop if EXISTS partition(inc_day='%s')", date));
            service.saveData(spark, resultRdd, date, "dm_gis.aoi_accuracy_54_aoiname_ret");
            resultRdd.unpersist();

        }
        logger.error("end...");
    }

    public static JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> loadSourceData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.aoi_accuracy_53_forward_plan_ret where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiAccuracyAddrTsAoiJoinTrajShouRet.class);
    }
}
