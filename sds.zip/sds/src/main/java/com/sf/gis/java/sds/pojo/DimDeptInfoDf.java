package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DimDeptInfoDf implements Serializable {
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "parent_dept_code")
    private String parent_dept_code;
    @Column(name = "dept_type_code")
    private String dept_type_code;
    @Column(name = "dept_type_name")
    private String dept_type_name;

    public String getDept_type_name() {
        return dept_type_name;
    }

    public void setDept_type_name(String dept_type_name) {
        this.dept_type_name = dept_type_name;
    }

    public String getDept_type_code() {
        return dept_type_code;
    }

    public void setDept_type_code(String dept_type_code) {
        this.dept_type_code = dept_type_code;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getParent_dept_code() {
        return parent_dept_code;
    }

    public void setParent_dept_code(String parent_dept_code) {
        this.parent_dept_code = parent_dept_code;
    }
}
