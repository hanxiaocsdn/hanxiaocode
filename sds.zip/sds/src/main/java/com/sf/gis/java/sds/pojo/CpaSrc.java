package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CpaSrc implements Serializable {
    @Column(name = "uuid")
    private String uuid;
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "deliver_address")
    private String deliverAddress;
    @Column(name = "deliver_address_type")
    private String deliverAddressType;
    @Column(name = "signer_namet")
    private String signerNamet;
    @Column(name = "order_no")
    private String orderNo;
    @Column(name = "deliver_emp_code")
    private String deliverEmpCode;
    @Column(name = "signer_nameg")
    private String signerNameg;
    @Column(name = "signin_tm")
    private String signinTm;
    @Column(name = "consignee_comp_name")
    private String consigneeCompName;
    @Column(name = "consignee_addr")
    private String consigneeAddr;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "eventtype")
    private String eventType;
    @Column(name = "eventlat")
    private String eventLat;
    @Column(name = "eventlng")
    private String eventLng;
    @Column(name = "id")
    private String id;
    @Column(name = "hash_lat_lng")
    private String hashLatLng;
    @Column(name = "inc_day")
    private String incDay;
    @Column(name = "dest_dist_code")
    private String destDistCode;

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getDeliverAddress() {
        return deliverAddress;
    }

    public void setDeliverAddress(String deliverAddress) {
        this.deliverAddress = deliverAddress;
    }

    public String getDeliverAddressType() {
        return deliverAddressType;
    }

    public void setDeliverAddressType(String deliverAddressType) {
        this.deliverAddressType = deliverAddressType;
    }

    public String getSignerNamet() {
        return signerNamet;
    }

    public void setSignerNamet(String signerNamet) {
        this.signerNamet = signerNamet;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getDeliverEmpCode() {
        return deliverEmpCode;
    }

    public void setDeliverEmpCode(String deliverEmpCode) {
        this.deliverEmpCode = deliverEmpCode;
    }

    public String getSignerNameg() {
        return signerNameg;
    }

    public void setSignerNameg(String signerNameg) {
        this.signerNameg = signerNameg;
    }

    public String getSigninTm() {
        return signinTm;
    }

    public void setSigninTm(String signinTm) {
        this.signinTm = signinTm;
    }

    public String getConsigneeCompName() {
        return consigneeCompName;
    }

    public void setConsigneeCompName(String consigneeCompName) {
        this.consigneeCompName = consigneeCompName;
    }

    public String getConsigneeAddr() {
        return consigneeAddr;
    }

    public void setConsigneeAddr(String consigneeAddr) {
        this.consigneeAddr = consigneeAddr;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventLat() {
        return eventLat;
    }

    public void setEventLat(String eventLat) {
        this.eventLat = eventLat;
    }

    public String getEventLng() {
        return eventLng;
    }

    public void setEventLng(String eventLng) {
        this.eventLng = eventLng;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHashLatLng() {
        return hashLatLng;
    }

    public void setHashLatLng(String hashLatLng) {
        this.hashLatLng = hashLatLng;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getDestDistCode() {
        return destDistCode;
    }

    public void setDestDistCode(String destDistCode) {
        this.destDistCode = destDistCode;
    }

    @Override
    public String toString() {
        return "CpaSrc{" +
                "uuid='" + uuid + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", deliverAddress='" + deliverAddress + '\'' +
                ", deliverAddressType='" + deliverAddressType + '\'' +
                ", signerNamet='" + signerNamet + '\'' +
                ", orderNo='" + orderNo + '\'' +
                ", deliverEmpCode='" + deliverEmpCode + '\'' +
                ", signerNameg='" + signerNameg + '\'' +
                ", signinTm='" + signinTm + '\'' +
                ", consigneeCompName='" + consigneeCompName + '\'' +
                ", consigneeAddr='" + consigneeAddr + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", eventLat='" + eventLat + '\'' +
                ", eventLng='" + eventLng + '\'' +
                ", id='" + id + '\'' +
                ", hashLatLng='" + hashLatLng + '\'' +
                ", incDay='" + incDay + '\'' +
                ", destDistCode='" + destDistCode + '\'' +
                '}';
    }
}
