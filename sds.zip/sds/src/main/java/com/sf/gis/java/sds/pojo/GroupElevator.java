package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GroupElevator implements Serializable {
    @Column(name = "group_id")
    private String group_id;
    @Column(name = "citycode")
    private String cityCode;
    @Column(name = "source")
    private String source;
    @Column(name = "norm_address")
    private String norm_address;
    @Column(name = "aoi_id")
    private String aoi_id;
    private String is_elevator;
    @Column(name = "elevator_cnt")
    private String elevator_cnt;
    @Column(name = "no_elevator_cnt")
    private String no_elevator_cnt;
    private String floor;

    private String tag;
    private String waybill_no;
    private String consignee_addr;
    private String pickup_tm;
    private String deliver_emp_code;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city")
    private String city;

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getPickup_tm() {
        return pickup_tm;
    }

    public void setPickup_tm(String pickup_tm) {
        this.pickup_tm = pickup_tm;
    }

    public String getDeliver_emp_code() {
        return deliver_emp_code;
    }

    public void setDeliver_emp_code(String deliver_emp_code) {
        this.deliver_emp_code = deliver_emp_code;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getElevator_cnt() {
        return elevator_cnt;
    }

    public void setElevator_cnt(String elevator_cnt) {
        this.elevator_cnt = elevator_cnt;
    }

    public String getNo_elevator_cnt() {
        return no_elevator_cnt;
    }

    public void setNo_elevator_cnt(String no_elevator_cnt) {
        this.no_elevator_cnt = no_elevator_cnt;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getNorm_address() {
        return norm_address;
    }

    public void setNorm_address(String norm_address) {
        this.norm_address = norm_address;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getIs_elevator() {
        return is_elevator;
    }

    public void setIs_elevator(String is_elevator) {
        this.is_elevator = is_elevator;
    }
}
