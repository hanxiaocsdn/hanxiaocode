package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class In45AddedvalueIndex implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "stat_type")
    private String stat_type;
    @Column(name = "stat_type_content")
    private String stat_type_content;
    @Column(name = "stat_date")
    private String stat_date;
    @Column(name = "region")
    private String region;
    @Column(name = "citycode")
    private String cityCode;
    @Column(name = "city")
    private String city;

    @Column(name = "cnt")
    private String cnt;
    @Column(name = "sum_fee")
    private String sum_fee;
    @Column(name = "gis_cnt")
    private String gis_cnt;
    @Column(name = "gis_sum_fee")
    private String gis_sum_fee;
    @Column(name = "climb_cnt")
    private String climb_cnt;
    @Column(name = "climb_sum_fee")
    private String climb_sum_fee;
    @Column(name = "no_elevator_cnt")
    private String no_elevator_cnt;
    @Column(name = "no_elevator_sum_fee")
    private String no_elevator_sum_fee;
    @Column(name = "no_climb_cnt")
    private String no_climb_cnt;
    @Column(name = "no_climb_sum_fee")
    private String no_climb_sum_fee;
    @Column(name = "no_distinguish_cnt")
    private String no_distinguish_cnt;
    @Column(name = "no_distinguish_sum_fee")
    private String no_distinguish_sum_fee;

    @Column(name = "residence_climb_cnt")
    private String residence_climb_cnt;

    @Column(name = "residence_climb_sum_fee")
    private String residence_climb_sum_fee;

    @Column(name = "residence_no_elevator_cnt")
    private String residence_no_elevator_cnt;

    @Column(name = "residence_no_elevator_sum_fee")
    private String residence_no_elevator_sum_fee;

    @Column(name = "residence_no_climb_cnt")
    private String residence_no_climb_cnt;

    @Column(name = "residence_no_climb_sum_fee")
    private String residence_no_climb_sum_fee;

    @Column(name = "residence_no_distinguish_cnt")
    private String residence_no_distinguish_cnt;

    @Column(name = "residence_no_distinguish_sum_fee")
    private String residence_no_distinguish_sum_fee;

    @Column(name = "other_residence_climb_cnt")
    private String other_residence_climb_cnt;

    @Column(name = "other_residence_climb_sum_fee")
    private String other_residence_climb_sum_fee;

    @Column(name = "other_residence_no_elevator_cnt")
    private String other_residence_no_elevator_cnt;

    @Column(name = "other_residence_no_elevator_sum_fee")
    private String other_residence_no_elevator_sum_fee;

    @Column(name = "other_residence_no_climb_cnt")
    private String other_residence_no_climb_cnt;

    @Column(name = "other_residence_no_climb_sum_fee")
    private String other_residence_no_climb_sum_fee;

    @Column(name = "other_residence_no_distinguish_cnt")
    private String other_residence_no_distinguish_cnt;

    @Column(name = "other_residence_no_distinguish_sum_fee")
    private String other_residence_no_distinguish_sum_fee;

    @Column(name = "opcode_50_climb_cnt")
    private String opcode_50_climb_cnt;

    @Column(name = "opcode_50_climb_sum_fee")
    private String opcode_50_climb_sum_fee;

    @Column(name = "opcode_50_no_elevator_cnt")
    private String opcode_50_no_elevator_cnt;

    @Column(name = "opcode_50_no_elevator_sum_fee")
    private String opcode_50_no_elevator_sum_fee;

    @Column(name = "opcode_50_no_climb_cnt")
    private String opcode_50_no_climb_cnt;

    @Column(name = "opcode_50_no_climb_sum_fee")
    private String opcode_50_no_climb_sum_fee;

    @Column(name = "opcode_50_no_distinguish_cnt")
    private String opcode_50_no_distinguish_cnt;

    @Column(name = "opcode_50_no_distinguish_sum_fee")
    private String opcode_50_no_distinguish_sum_fee;

    @Column(name = "other_opcode_50_climb_cnt")
    private String other_opcode_50_climb_cnt;

    @Column(name = "other_opcode_50_climb_sum_fee")
    private String other_opcode_50_climb_sum_fee;

    @Column(name = "other_opcode_50_no_elevator_cnt")
    private String other_opcode_50_no_elevator_cnt;

    @Column(name = "other_opcode_50_no_elevator_sum_fee")
    private String other_opcode_50_no_elevator_sum_fee;

    @Column(name = "other_opcode_50_no_climb_cnt")
    private String other_opcode_50_no_climb_cnt;

    @Column(name = "other_opcode_50_no_climb_sum_fee")
    private String other_opcode_50_no_climb_sum_fee;

    @Column(name = "other_opcode_50_no_distinguish_cnt")
    private String other_opcode_50_no_distinguish_cnt;

    @Column(name = "other_opcode_50_no_distinguish_sum_fee")
    private String other_opcode_50_no_distinguish_sum_fee;

    @Column(name = "sfkh_climb_cnt")
    private String sfkh_climb_cnt;

    @Column(name = "sfkh_climb_sum_fee")
    private String sfkh_climb_sum_fee;

    @Column(name = "sfkh_no_elevator_cnt")
    private String sfkh_no_elevator_cnt;

    @Column(name = "sfkh_no_elevator_sum_fee")
    private String sfkh_no_elevator_sum_fee;

    @Column(name = "sfkh_no_climb_cnt")
    private String sfkh_no_climb_cnt;

    @Column(name = "sfkh_no_climb_sum_fee")
    private String sfkh_no_climb_sum_fee;

    @Column(name = "sfkh_no_distinguish_cnt")
    private String sfkh_no_distinguish_cnt;

    @Column(name = "sfkh_no_distinguish_sum_fee")
    private String sfkh_no_distinguish_sum_fee;

    @Column(name = "bzld_climb_cnt")
    private String bzld_climb_cnt;

    @Column(name = "bzld_climb_sum_fee")
    private String bzld_climb_sum_fee;

    @Column(name = "bzld_no_elevator_cnt")
    private String bzld_no_elevator_cnt;

    @Column(name = "bzld_no_elevator_sum_fee")
    private String bzld_no_elevator_sum_fee;

    @Column(name = "bzld_no_climb_cnt")
    private String bzld_no_climb_cnt;

    @Column(name = "bzld_no_climb_sum_fee")
    private String bzld_no_climb_sum_fee;

    @Column(name = "bzld_no_distinguish_cnt")
    private String bzld_no_distinguish_cnt;

    @Column(name = "bzld_no_distinguish_sum_fee")
    private String bzld_no_distinguish_sum_fee;

    @Column(name = "sfgp_climb_cnt")
    private String sfgp_climb_cnt;

    @Column(name = "sfgp_climb_sum_fee")
    private String sfgp_climb_sum_fee;

    @Column(name = "sfgp_no_elevator_cnt")
    private String sfgp_no_elevator_cnt;

    @Column(name = "sfgp_no_elevator_sum_fee")
    private String sfgp_no_elevator_sum_fee;

    @Column(name = "sfgp_no_climb_cnt")
    private String sfgp_no_climb_cnt;

    @Column(name = "sfgp_no_climb_sum_fee")
    private String sfgp_no_climb_sum_fee;

    @Column(name = "sfgp_no_distinguish_cnt")
    private String sfgp_no_distinguish_cnt;

    @Column(name = "sfgp_no_distinguish_sum_fee")
    private String sfgp_no_distinguish_sum_fee;

    @Column(name = "cztp_climb_cnt")
    private String cztp_climb_cnt;

    @Column(name = "cztp_climb_sum_fee")
    private String cztp_climb_sum_fee;

    @Column(name = "cztp_no_elevator_cnt")
    private String cztp_no_elevator_cnt;

    @Column(name = "cztp_no_elevator_sum_fee")
    private String cztp_no_elevator_sum_fee;

    @Column(name = "cztp_no_climb_cnt")
    private String cztp_no_climb_cnt;

    @Column(name = "cztp_no_climb_sum_fee")
    private String cztp_no_climb_sum_fee;

    @Column(name = "cztp_no_distinguish_cnt")
    private String cztp_no_distinguish_cnt;

    @Column(name = "cztp_no_distinguish_sum_fee")
    private String cztp_no_distinguish_sum_fee;

    @Column(name = "other_prod_name_type_climb_cnt")
    private String other_prod_name_type_climb_cnt;

    @Column(name = "other_prod_name_type_climb_sum_fee")
    private String other_prod_name_type_climb_sum_fee;

    @Column(name = "other_prod_name_type_no_elevator_cnt")
    private String other_prod_name_type_no_elevator_cnt;

    @Column(name = "other_prod_name_type_no_elevator_sum_fee")
    private String other_prod_name_type_no_elevator_sum_fee;

    @Column(name = "other_prod_name_type_no_climb_cnt")
    private String other_prod_name_type_no_climb_cnt;

    @Column(name = "other_prod_name_type_no_climb_sum_fee")
    private String other_prod_name_type_no_climb_sum_fee;

    @Column(name = "other_prod_name_type_no_distinguish_cnt")
    private String other_prod_name_type_no_distinguish_cnt;

    @Column(name = "other_prod_name_type_no_distinguish_sum_fee")
    private String other_prod_name_type_no_distinguish_sum_fee;

    @Column(name = "yj_climb_cnt")
    private String yj_climb_cnt;

    @Column(name = "yj_climb_sum_fee")
    private String yj_climb_sum_fee;

    @Column(name = "yj_no_elevator_cnt")
    private String yj_no_elevator_cnt;

    @Column(name = "yj_no_elevator_sum_fee")
    private String yj_no_elevator_sum_fee;

    @Column(name = "yj_no_climb_cnt")
    private String yj_no_climb_cnt;

    @Column(name = "yj_no_climb_sum_fee")
    private String yj_no_climb_sum_fee;

    @Column(name = "yj_no_distinguish_cnt")
    private String yj_no_distinguish_cnt;

    @Column(name = "yj_no_distinguish_sum_fee")
    private String yj_no_distinguish_sum_fee;

    @Column(name = "hy_climb_cnt")
    private String hy_climb_cnt;

    @Column(name = "hy_climb_sum_fee")
    private String hy_climb_sum_fee;

    @Column(name = "hy_no_elevator_cnt")
    private String hy_no_elevator_cnt;

    @Column(name = "hy_no_elevator_sum_fee")
    private String hy_no_elevator_sum_fee;

    @Column(name = "hy_no_climb_cnt")
    private String hy_no_climb_cnt;

    @Column(name = "hy_no_climb_sum_fee")
    private String hy_no_climb_sum_fee;

    @Column(name = "hy_no_distinguish_cnt")
    private String hy_no_distinguish_cnt;

    @Column(name = "hy_no_distinguish_sum_fee")
    private String hy_no_distinguish_sum_fee;

    @Column(name = "sk_climb_cnt")
    private String sk_climb_cnt;

    @Column(name = "sk_climb_sum_fee")
    private String sk_climb_sum_fee;

    @Column(name = "sk_no_elevator_cnt")
    private String sk_no_elevator_cnt;

    @Column(name = "sk_no_elevator_sum_fee")
    private String sk_no_elevator_sum_fee;

    @Column(name = "sk_no_climb_cnt")
    private String sk_no_climb_cnt;

    @Column(name = "sk_no_climb_sum_fee")
    private String sk_no_climb_sum_fee;

    @Column(name = "sk_no_distinguish_cnt")
    private String sk_no_distinguish_cnt;

    @Column(name = "sk_no_distinguish_sum_fee")
    private String sk_no_distinguish_sum_fee;

    @Column(name = "other_pay_cust_type_climb_cnt")
    private String other_pay_cust_type_climb_cnt;

    @Column(name = "other_pay_cust_type_climb_sum_fee")
    private String other_pay_cust_type_climb_sum_fee;

    @Column(name = "other_pay_cust_type_no_elevator_cnt")
    private String other_pay_cust_type_no_elevator_cnt;

    @Column(name = "other_pay_cust_type_no_elevator_sum_fee")
    private String other_pay_cust_type_no_elevator_sum_fee;

    @Column(name = "other_pay_cust_type_no_climb_cnt")
    private String other_pay_cust_type_no_climb_cnt;

    @Column(name = "other_pay_cust_type_no_climb_sum_fee")
    private String other_pay_cust_type_no_climb_sum_fee;

    @Column(name = "other_pay_cust_type_no_distinguish_cnt")
    private String other_pay_cust_type_no_distinguish_cnt;

    @Column(name = "other_pay_cust_type_no_distinguish_sum_fee")
    private String other_pay_cust_type_no_distinguish_sum_fee;

    @Column(name = "sgs_core_climb_cnt")
    private String sgs_core_climb_cnt;

    @Column(name = "sgs_core_climb_sum_fee")
    private String sgs_core_climb_sum_fee;

    @Column(name = "sgs_core_no_elevator_cnt")
    private String sgs_core_no_elevator_cnt;

    @Column(name = "sgs_core_no_elevator_sum_fee")
    private String sgs_core_no_elevator_sum_fee;

    @Column(name = "sgs_core_no_climb_cnt")
    private String sgs_core_no_climb_cnt;

    @Column(name = "sgs_core_no_climb_sum_fee")
    private String sgs_core_no_climb_sum_fee;

    @Column(name = "sgs_core_no_distinguish_cnt")
    private String sgs_core_no_distinguish_cnt;

    @Column(name = "sgs_core_no_distinguish_sum_fee")
    private String sgs_core_no_distinguish_sum_fee;

    @Column(name = "fop_climb_cnt")
    private String fop_climb_cnt;

    @Column(name = "fop_climb_sum_fee")
    private String fop_climb_sum_fee;

    @Column(name = "fop_no_elevator_cnt")
    private String fop_no_elevator_cnt;

    @Column(name = "fop_no_elevator_sum_fee")
    private String fop_no_elevator_sum_fee;

    @Column(name = "fop_no_climb_cnt")
    private String fop_no_climb_cnt;

    @Column(name = "fop_no_climb_sum_fee")
    private String fop_no_climb_sum_fee;

    @Column(name = "fop_no_distinguish_cnt")
    private String fop_no_distinguish_cnt;

    @Column(name = "fop_no_distinguish_sum_fee")
    private String fop_no_distinguish_sum_fee;

    @Column(name = "other_pickup_barsn_climb_cnt")
    private String other_pickup_barsn_climb_cnt;

    @Column(name = "other_pickup_barsn_climb_sum_fee")
    private String other_pickup_barsn_climb_sum_fee;

    @Column(name = "other_pickup_barsn_no_elevator_cnt")
    private String other_pickup_barsn_no_elevator_cnt;

    @Column(name = "other_pickup_barsn_no_elevator_sum_fee")
    private String other_pickup_barsn_no_elevator_sum_fee;

    @Column(name = "other_pickup_barsn_no_climb_cnt")
    private String other_pickup_barsn_no_climb_cnt;

    @Column(name = "other_pickup_barsn_no_climb_sum_fee")
    private String other_pickup_barsn_no_climb_sum_fee;

    @Column(name = "other_pickup_barsn_no_distinguish_cnt")
    private String other_pickup_barsn_no_distinguish_cnt;

    @Column(name = "other_pickup_barsn_no_distinguish_sum_fee")
    private String other_pickup_barsn_no_distinguish_sum_fee;

    @Column(name = "inc_day")
    private String inc_day;

    public String getResidence_climb_cnt() {
        return residence_climb_cnt;
    }

    public void setResidence_climb_cnt(String residence_climb_cnt) {
        this.residence_climb_cnt = residence_climb_cnt;
    }

    public String getResidence_climb_sum_fee() {
        return residence_climb_sum_fee;
    }

    public void setResidence_climb_sum_fee(String residence_climb_sum_fee) {
        this.residence_climb_sum_fee = residence_climb_sum_fee;
    }

    public String getResidence_no_elevator_cnt() {
        return residence_no_elevator_cnt;
    }

    public void setResidence_no_elevator_cnt(String residence_no_elevator_cnt) {
        this.residence_no_elevator_cnt = residence_no_elevator_cnt;
    }

    public String getResidence_no_elevator_sum_fee() {
        return residence_no_elevator_sum_fee;
    }

    public void setResidence_no_elevator_sum_fee(String residence_no_elevator_sum_fee) {
        this.residence_no_elevator_sum_fee = residence_no_elevator_sum_fee;
    }

    public String getResidence_no_climb_cnt() {
        return residence_no_climb_cnt;
    }

    public void setResidence_no_climb_cnt(String residence_no_climb_cnt) {
        this.residence_no_climb_cnt = residence_no_climb_cnt;
    }

    public String getResidence_no_climb_sum_fee() {
        return residence_no_climb_sum_fee;
    }

    public void setResidence_no_climb_sum_fee(String residence_no_climb_sum_fee) {
        this.residence_no_climb_sum_fee = residence_no_climb_sum_fee;
    }

    public String getResidence_no_distinguish_cnt() {
        return residence_no_distinguish_cnt;
    }

    public void setResidence_no_distinguish_cnt(String residence_no_distinguish_cnt) {
        this.residence_no_distinguish_cnt = residence_no_distinguish_cnt;
    }

    public String getResidence_no_distinguish_sum_fee() {
        return residence_no_distinguish_sum_fee;
    }

    public void setResidence_no_distinguish_sum_fee(String residence_no_distinguish_sum_fee) {
        this.residence_no_distinguish_sum_fee = residence_no_distinguish_sum_fee;
    }

    public String getOther_residence_climb_cnt() {
        return other_residence_climb_cnt;
    }

    public void setOther_residence_climb_cnt(String other_residence_climb_cnt) {
        this.other_residence_climb_cnt = other_residence_climb_cnt;
    }

    public String getOther_residence_climb_sum_fee() {
        return other_residence_climb_sum_fee;
    }

    public void setOther_residence_climb_sum_fee(String other_residence_climb_sum_fee) {
        this.other_residence_climb_sum_fee = other_residence_climb_sum_fee;
    }

    public String getOther_residence_no_elevator_cnt() {
        return other_residence_no_elevator_cnt;
    }

    public void setOther_residence_no_elevator_cnt(String other_residence_no_elevator_cnt) {
        this.other_residence_no_elevator_cnt = other_residence_no_elevator_cnt;
    }

    public String getOther_residence_no_elevator_sum_fee() {
        return other_residence_no_elevator_sum_fee;
    }

    public void setOther_residence_no_elevator_sum_fee(String other_residence_no_elevator_sum_fee) {
        this.other_residence_no_elevator_sum_fee = other_residence_no_elevator_sum_fee;
    }

    public String getOther_residence_no_climb_cnt() {
        return other_residence_no_climb_cnt;
    }

    public void setOther_residence_no_climb_cnt(String other_residence_no_climb_cnt) {
        this.other_residence_no_climb_cnt = other_residence_no_climb_cnt;
    }

    public String getOther_residence_no_climb_sum_fee() {
        return other_residence_no_climb_sum_fee;
    }

    public void setOther_residence_no_climb_sum_fee(String other_residence_no_climb_sum_fee) {
        this.other_residence_no_climb_sum_fee = other_residence_no_climb_sum_fee;
    }

    public String getOther_residence_no_distinguish_cnt() {
        return other_residence_no_distinguish_cnt;
    }

    public void setOther_residence_no_distinguish_cnt(String other_residence_no_distinguish_cnt) {
        this.other_residence_no_distinguish_cnt = other_residence_no_distinguish_cnt;
    }

    public String getOther_residence_no_distinguish_sum_fee() {
        return other_residence_no_distinguish_sum_fee;
    }

    public void setOther_residence_no_distinguish_sum_fee(String other_residence_no_distinguish_sum_fee) {
        this.other_residence_no_distinguish_sum_fee = other_residence_no_distinguish_sum_fee;
    }

    public String getOpcode_50_climb_cnt() {
        return opcode_50_climb_cnt;
    }

    public void setOpcode_50_climb_cnt(String opcode_50_climb_cnt) {
        this.opcode_50_climb_cnt = opcode_50_climb_cnt;
    }

    public String getOpcode_50_climb_sum_fee() {
        return opcode_50_climb_sum_fee;
    }

    public void setOpcode_50_climb_sum_fee(String opcode_50_climb_sum_fee) {
        this.opcode_50_climb_sum_fee = opcode_50_climb_sum_fee;
    }

    public String getOpcode_50_no_elevator_cnt() {
        return opcode_50_no_elevator_cnt;
    }

    public void setOpcode_50_no_elevator_cnt(String opcode_50_no_elevator_cnt) {
        this.opcode_50_no_elevator_cnt = opcode_50_no_elevator_cnt;
    }

    public String getOpcode_50_no_elevator_sum_fee() {
        return opcode_50_no_elevator_sum_fee;
    }

    public void setOpcode_50_no_elevator_sum_fee(String opcode_50_no_elevator_sum_fee) {
        this.opcode_50_no_elevator_sum_fee = opcode_50_no_elevator_sum_fee;
    }

    public String getOpcode_50_no_climb_cnt() {
        return opcode_50_no_climb_cnt;
    }

    public void setOpcode_50_no_climb_cnt(String opcode_50_no_climb_cnt) {
        this.opcode_50_no_climb_cnt = opcode_50_no_climb_cnt;
    }

    public String getOpcode_50_no_climb_sum_fee() {
        return opcode_50_no_climb_sum_fee;
    }

    public void setOpcode_50_no_climb_sum_fee(String opcode_50_no_climb_sum_fee) {
        this.opcode_50_no_climb_sum_fee = opcode_50_no_climb_sum_fee;
    }

    public String getOpcode_50_no_distinguish_cnt() {
        return opcode_50_no_distinguish_cnt;
    }

    public void setOpcode_50_no_distinguish_cnt(String opcode_50_no_distinguish_cnt) {
        this.opcode_50_no_distinguish_cnt = opcode_50_no_distinguish_cnt;
    }

    public String getOpcode_50_no_distinguish_sum_fee() {
        return opcode_50_no_distinguish_sum_fee;
    }

    public void setOpcode_50_no_distinguish_sum_fee(String opcode_50_no_distinguish_sum_fee) {
        this.opcode_50_no_distinguish_sum_fee = opcode_50_no_distinguish_sum_fee;
    }

    public String getOther_opcode_50_climb_cnt() {
        return other_opcode_50_climb_cnt;
    }

    public void setOther_opcode_50_climb_cnt(String other_opcode_50_climb_cnt) {
        this.other_opcode_50_climb_cnt = other_opcode_50_climb_cnt;
    }

    public String getOther_opcode_50_climb_sum_fee() {
        return other_opcode_50_climb_sum_fee;
    }

    public void setOther_opcode_50_climb_sum_fee(String other_opcode_50_climb_sum_fee) {
        this.other_opcode_50_climb_sum_fee = other_opcode_50_climb_sum_fee;
    }

    public String getOther_opcode_50_no_elevator_cnt() {
        return other_opcode_50_no_elevator_cnt;
    }

    public void setOther_opcode_50_no_elevator_cnt(String other_opcode_50_no_elevator_cnt) {
        this.other_opcode_50_no_elevator_cnt = other_opcode_50_no_elevator_cnt;
    }

    public String getOther_opcode_50_no_elevator_sum_fee() {
        return other_opcode_50_no_elevator_sum_fee;
    }

    public void setOther_opcode_50_no_elevator_sum_fee(String other_opcode_50_no_elevator_sum_fee) {
        this.other_opcode_50_no_elevator_sum_fee = other_opcode_50_no_elevator_sum_fee;
    }

    public String getOther_opcode_50_no_climb_cnt() {
        return other_opcode_50_no_climb_cnt;
    }

    public void setOther_opcode_50_no_climb_cnt(String other_opcode_50_no_climb_cnt) {
        this.other_opcode_50_no_climb_cnt = other_opcode_50_no_climb_cnt;
    }

    public String getOther_opcode_50_no_climb_sum_fee() {
        return other_opcode_50_no_climb_sum_fee;
    }

    public void setOther_opcode_50_no_climb_sum_fee(String other_opcode_50_no_climb_sum_fee) {
        this.other_opcode_50_no_climb_sum_fee = other_opcode_50_no_climb_sum_fee;
    }

    public String getOther_opcode_50_no_distinguish_cnt() {
        return other_opcode_50_no_distinguish_cnt;
    }

    public void setOther_opcode_50_no_distinguish_cnt(String other_opcode_50_no_distinguish_cnt) {
        this.other_opcode_50_no_distinguish_cnt = other_opcode_50_no_distinguish_cnt;
    }

    public String getOther_opcode_50_no_distinguish_sum_fee() {
        return other_opcode_50_no_distinguish_sum_fee;
    }

    public void setOther_opcode_50_no_distinguish_sum_fee(String other_opcode_50_no_distinguish_sum_fee) {
        this.other_opcode_50_no_distinguish_sum_fee = other_opcode_50_no_distinguish_sum_fee;
    }

    public String getSfkh_climb_cnt() {
        return sfkh_climb_cnt;
    }

    public void setSfkh_climb_cnt(String sfkh_climb_cnt) {
        this.sfkh_climb_cnt = sfkh_climb_cnt;
    }

    public String getSfkh_climb_sum_fee() {
        return sfkh_climb_sum_fee;
    }

    public void setSfkh_climb_sum_fee(String sfkh_climb_sum_fee) {
        this.sfkh_climb_sum_fee = sfkh_climb_sum_fee;
    }

    public String getSfkh_no_elevator_cnt() {
        return sfkh_no_elevator_cnt;
    }

    public void setSfkh_no_elevator_cnt(String sfkh_no_elevator_cnt) {
        this.sfkh_no_elevator_cnt = sfkh_no_elevator_cnt;
    }

    public String getSfkh_no_elevator_sum_fee() {
        return sfkh_no_elevator_sum_fee;
    }

    public void setSfkh_no_elevator_sum_fee(String sfkh_no_elevator_sum_fee) {
        this.sfkh_no_elevator_sum_fee = sfkh_no_elevator_sum_fee;
    }

    public String getSfkh_no_climb_cnt() {
        return sfkh_no_climb_cnt;
    }

    public void setSfkh_no_climb_cnt(String sfkh_no_climb_cnt) {
        this.sfkh_no_climb_cnt = sfkh_no_climb_cnt;
    }

    public String getSfkh_no_climb_sum_fee() {
        return sfkh_no_climb_sum_fee;
    }

    public void setSfkh_no_climb_sum_fee(String sfkh_no_climb_sum_fee) {
        this.sfkh_no_climb_sum_fee = sfkh_no_climb_sum_fee;
    }

    public String getSfkh_no_distinguish_cnt() {
        return sfkh_no_distinguish_cnt;
    }

    public void setSfkh_no_distinguish_cnt(String sfkh_no_distinguish_cnt) {
        this.sfkh_no_distinguish_cnt = sfkh_no_distinguish_cnt;
    }

    public String getSfkh_no_distinguish_sum_fee() {
        return sfkh_no_distinguish_sum_fee;
    }

    public void setSfkh_no_distinguish_sum_fee(String sfkh_no_distinguish_sum_fee) {
        this.sfkh_no_distinguish_sum_fee = sfkh_no_distinguish_sum_fee;
    }

    public String getBzld_climb_cnt() {
        return bzld_climb_cnt;
    }

    public void setBzld_climb_cnt(String bzld_climb_cnt) {
        this.bzld_climb_cnt = bzld_climb_cnt;
    }

    public String getBzld_climb_sum_fee() {
        return bzld_climb_sum_fee;
    }

    public void setBzld_climb_sum_fee(String bzld_climb_sum_fee) {
        this.bzld_climb_sum_fee = bzld_climb_sum_fee;
    }

    public String getBzld_no_elevator_cnt() {
        return bzld_no_elevator_cnt;
    }

    public void setBzld_no_elevator_cnt(String bzld_no_elevator_cnt) {
        this.bzld_no_elevator_cnt = bzld_no_elevator_cnt;
    }

    public String getBzld_no_elevator_sum_fee() {
        return bzld_no_elevator_sum_fee;
    }

    public void setBzld_no_elevator_sum_fee(String bzld_no_elevator_sum_fee) {
        this.bzld_no_elevator_sum_fee = bzld_no_elevator_sum_fee;
    }

    public String getBzld_no_climb_cnt() {
        return bzld_no_climb_cnt;
    }

    public void setBzld_no_climb_cnt(String bzld_no_climb_cnt) {
        this.bzld_no_climb_cnt = bzld_no_climb_cnt;
    }

    public String getBzld_no_climb_sum_fee() {
        return bzld_no_climb_sum_fee;
    }

    public void setBzld_no_climb_sum_fee(String bzld_no_climb_sum_fee) {
        this.bzld_no_climb_sum_fee = bzld_no_climb_sum_fee;
    }

    public String getBzld_no_distinguish_cnt() {
        return bzld_no_distinguish_cnt;
    }

    public void setBzld_no_distinguish_cnt(String bzld_no_distinguish_cnt) {
        this.bzld_no_distinguish_cnt = bzld_no_distinguish_cnt;
    }

    public String getBzld_no_distinguish_sum_fee() {
        return bzld_no_distinguish_sum_fee;
    }

    public void setBzld_no_distinguish_sum_fee(String bzld_no_distinguish_sum_fee) {
        this.bzld_no_distinguish_sum_fee = bzld_no_distinguish_sum_fee;
    }

    public String getSfgp_climb_cnt() {
        return sfgp_climb_cnt;
    }

    public void setSfgp_climb_cnt(String sfgp_climb_cnt) {
        this.sfgp_climb_cnt = sfgp_climb_cnt;
    }

    public String getSfgp_climb_sum_fee() {
        return sfgp_climb_sum_fee;
    }

    public void setSfgp_climb_sum_fee(String sfgp_climb_sum_fee) {
        this.sfgp_climb_sum_fee = sfgp_climb_sum_fee;
    }

    public String getSfgp_no_elevator_cnt() {
        return sfgp_no_elevator_cnt;
    }

    public void setSfgp_no_elevator_cnt(String sfgp_no_elevator_cnt) {
        this.sfgp_no_elevator_cnt = sfgp_no_elevator_cnt;
    }

    public String getSfgp_no_elevator_sum_fee() {
        return sfgp_no_elevator_sum_fee;
    }

    public void setSfgp_no_elevator_sum_fee(String sfgp_no_elevator_sum_fee) {
        this.sfgp_no_elevator_sum_fee = sfgp_no_elevator_sum_fee;
    }

    public String getSfgp_no_climb_cnt() {
        return sfgp_no_climb_cnt;
    }

    public void setSfgp_no_climb_cnt(String sfgp_no_climb_cnt) {
        this.sfgp_no_climb_cnt = sfgp_no_climb_cnt;
    }

    public String getSfgp_no_climb_sum_fee() {
        return sfgp_no_climb_sum_fee;
    }

    public void setSfgp_no_climb_sum_fee(String sfgp_no_climb_sum_fee) {
        this.sfgp_no_climb_sum_fee = sfgp_no_climb_sum_fee;
    }

    public String getSfgp_no_distinguish_cnt() {
        return sfgp_no_distinguish_cnt;
    }

    public void setSfgp_no_distinguish_cnt(String sfgp_no_distinguish_cnt) {
        this.sfgp_no_distinguish_cnt = sfgp_no_distinguish_cnt;
    }

    public String getSfgp_no_distinguish_sum_fee() {
        return sfgp_no_distinguish_sum_fee;
    }

    public void setSfgp_no_distinguish_sum_fee(String sfgp_no_distinguish_sum_fee) {
        this.sfgp_no_distinguish_sum_fee = sfgp_no_distinguish_sum_fee;
    }

    public String getCztp_climb_cnt() {
        return cztp_climb_cnt;
    }

    public void setCztp_climb_cnt(String cztp_climb_cnt) {
        this.cztp_climb_cnt = cztp_climb_cnt;
    }

    public String getCztp_climb_sum_fee() {
        return cztp_climb_sum_fee;
    }

    public void setCztp_climb_sum_fee(String cztp_climb_sum_fee) {
        this.cztp_climb_sum_fee = cztp_climb_sum_fee;
    }

    public String getCztp_no_elevator_cnt() {
        return cztp_no_elevator_cnt;
    }

    public void setCztp_no_elevator_cnt(String cztp_no_elevator_cnt) {
        this.cztp_no_elevator_cnt = cztp_no_elevator_cnt;
    }

    public String getCztp_no_elevator_sum_fee() {
        return cztp_no_elevator_sum_fee;
    }

    public void setCztp_no_elevator_sum_fee(String cztp_no_elevator_sum_fee) {
        this.cztp_no_elevator_sum_fee = cztp_no_elevator_sum_fee;
    }

    public String getCztp_no_climb_cnt() {
        return cztp_no_climb_cnt;
    }

    public void setCztp_no_climb_cnt(String cztp_no_climb_cnt) {
        this.cztp_no_climb_cnt = cztp_no_climb_cnt;
    }

    public String getCztp_no_climb_sum_fee() {
        return cztp_no_climb_sum_fee;
    }

    public void setCztp_no_climb_sum_fee(String cztp_no_climb_sum_fee) {
        this.cztp_no_climb_sum_fee = cztp_no_climb_sum_fee;
    }

    public String getCztp_no_distinguish_cnt() {
        return cztp_no_distinguish_cnt;
    }

    public void setCztp_no_distinguish_cnt(String cztp_no_distinguish_cnt) {
        this.cztp_no_distinguish_cnt = cztp_no_distinguish_cnt;
    }

    public String getCztp_no_distinguish_sum_fee() {
        return cztp_no_distinguish_sum_fee;
    }

    public void setCztp_no_distinguish_sum_fee(String cztp_no_distinguish_sum_fee) {
        this.cztp_no_distinguish_sum_fee = cztp_no_distinguish_sum_fee;
    }

    public String getOther_prod_name_type_climb_cnt() {
        return other_prod_name_type_climb_cnt;
    }

    public void setOther_prod_name_type_climb_cnt(String other_prod_name_type_climb_cnt) {
        this.other_prod_name_type_climb_cnt = other_prod_name_type_climb_cnt;
    }

    public String getOther_prod_name_type_climb_sum_fee() {
        return other_prod_name_type_climb_sum_fee;
    }

    public void setOther_prod_name_type_climb_sum_fee(String other_prod_name_type_climb_sum_fee) {
        this.other_prod_name_type_climb_sum_fee = other_prod_name_type_climb_sum_fee;
    }

    public String getOther_prod_name_type_no_elevator_cnt() {
        return other_prod_name_type_no_elevator_cnt;
    }

    public void setOther_prod_name_type_no_elevator_cnt(String other_prod_name_type_no_elevator_cnt) {
        this.other_prod_name_type_no_elevator_cnt = other_prod_name_type_no_elevator_cnt;
    }

    public String getOther_prod_name_type_no_elevator_sum_fee() {
        return other_prod_name_type_no_elevator_sum_fee;
    }

    public void setOther_prod_name_type_no_elevator_sum_fee(String other_prod_name_type_no_elevator_sum_fee) {
        this.other_prod_name_type_no_elevator_sum_fee = other_prod_name_type_no_elevator_sum_fee;
    }

    public String getOther_prod_name_type_no_climb_cnt() {
        return other_prod_name_type_no_climb_cnt;
    }

    public void setOther_prod_name_type_no_climb_cnt(String other_prod_name_type_no_climb_cnt) {
        this.other_prod_name_type_no_climb_cnt = other_prod_name_type_no_climb_cnt;
    }

    public String getOther_prod_name_type_no_climb_sum_fee() {
        return other_prod_name_type_no_climb_sum_fee;
    }

    public void setOther_prod_name_type_no_climb_sum_fee(String other_prod_name_type_no_climb_sum_fee) {
        this.other_prod_name_type_no_climb_sum_fee = other_prod_name_type_no_climb_sum_fee;
    }

    public String getOther_prod_name_type_no_distinguish_cnt() {
        return other_prod_name_type_no_distinguish_cnt;
    }

    public void setOther_prod_name_type_no_distinguish_cnt(String other_prod_name_type_no_distinguish_cnt) {
        this.other_prod_name_type_no_distinguish_cnt = other_prod_name_type_no_distinguish_cnt;
    }

    public String getOther_prod_name_type_no_distinguish_sum_fee() {
        return other_prod_name_type_no_distinguish_sum_fee;
    }

    public void setOther_prod_name_type_no_distinguish_sum_fee(String other_prod_name_type_no_distinguish_sum_fee) {
        this.other_prod_name_type_no_distinguish_sum_fee = other_prod_name_type_no_distinguish_sum_fee;
    }

    public String getYj_climb_cnt() {
        return yj_climb_cnt;
    }

    public void setYj_climb_cnt(String yj_climb_cnt) {
        this.yj_climb_cnt = yj_climb_cnt;
    }

    public String getYj_climb_sum_fee() {
        return yj_climb_sum_fee;
    }

    public void setYj_climb_sum_fee(String yj_climb_sum_fee) {
        this.yj_climb_sum_fee = yj_climb_sum_fee;
    }

    public String getYj_no_elevator_cnt() {
        return yj_no_elevator_cnt;
    }

    public void setYj_no_elevator_cnt(String yj_no_elevator_cnt) {
        this.yj_no_elevator_cnt = yj_no_elevator_cnt;
    }

    public String getYj_no_elevator_sum_fee() {
        return yj_no_elevator_sum_fee;
    }

    public void setYj_no_elevator_sum_fee(String yj_no_elevator_sum_fee) {
        this.yj_no_elevator_sum_fee = yj_no_elevator_sum_fee;
    }

    public String getYj_no_climb_cnt() {
        return yj_no_climb_cnt;
    }

    public void setYj_no_climb_cnt(String yj_no_climb_cnt) {
        this.yj_no_climb_cnt = yj_no_climb_cnt;
    }

    public String getYj_no_climb_sum_fee() {
        return yj_no_climb_sum_fee;
    }

    public void setYj_no_climb_sum_fee(String yj_no_climb_sum_fee) {
        this.yj_no_climb_sum_fee = yj_no_climb_sum_fee;
    }

    public String getYj_no_distinguish_cnt() {
        return yj_no_distinguish_cnt;
    }

    public void setYj_no_distinguish_cnt(String yj_no_distinguish_cnt) {
        this.yj_no_distinguish_cnt = yj_no_distinguish_cnt;
    }

    public String getYj_no_distinguish_sum_fee() {
        return yj_no_distinguish_sum_fee;
    }

    public void setYj_no_distinguish_sum_fee(String yj_no_distinguish_sum_fee) {
        this.yj_no_distinguish_sum_fee = yj_no_distinguish_sum_fee;
    }

    public String getHy_climb_cnt() {
        return hy_climb_cnt;
    }

    public void setHy_climb_cnt(String hy_climb_cnt) {
        this.hy_climb_cnt = hy_climb_cnt;
    }

    public String getHy_climb_sum_fee() {
        return hy_climb_sum_fee;
    }

    public void setHy_climb_sum_fee(String hy_climb_sum_fee) {
        this.hy_climb_sum_fee = hy_climb_sum_fee;
    }

    public String getHy_no_elevator_cnt() {
        return hy_no_elevator_cnt;
    }

    public void setHy_no_elevator_cnt(String hy_no_elevator_cnt) {
        this.hy_no_elevator_cnt = hy_no_elevator_cnt;
    }

    public String getHy_no_elevator_sum_fee() {
        return hy_no_elevator_sum_fee;
    }

    public void setHy_no_elevator_sum_fee(String hy_no_elevator_sum_fee) {
        this.hy_no_elevator_sum_fee = hy_no_elevator_sum_fee;
    }

    public String getHy_no_climb_cnt() {
        return hy_no_climb_cnt;
    }

    public void setHy_no_climb_cnt(String hy_no_climb_cnt) {
        this.hy_no_climb_cnt = hy_no_climb_cnt;
    }

    public String getHy_no_climb_sum_fee() {
        return hy_no_climb_sum_fee;
    }

    public void setHy_no_climb_sum_fee(String hy_no_climb_sum_fee) {
        this.hy_no_climb_sum_fee = hy_no_climb_sum_fee;
    }

    public String getHy_no_distinguish_cnt() {
        return hy_no_distinguish_cnt;
    }

    public void setHy_no_distinguish_cnt(String hy_no_distinguish_cnt) {
        this.hy_no_distinguish_cnt = hy_no_distinguish_cnt;
    }

    public String getHy_no_distinguish_sum_fee() {
        return hy_no_distinguish_sum_fee;
    }

    public void setHy_no_distinguish_sum_fee(String hy_no_distinguish_sum_fee) {
        this.hy_no_distinguish_sum_fee = hy_no_distinguish_sum_fee;
    }

    public String getSk_climb_cnt() {
        return sk_climb_cnt;
    }

    public void setSk_climb_cnt(String sk_climb_cnt) {
        this.sk_climb_cnt = sk_climb_cnt;
    }

    public String getSk_climb_sum_fee() {
        return sk_climb_sum_fee;
    }

    public void setSk_climb_sum_fee(String sk_climb_sum_fee) {
        this.sk_climb_sum_fee = sk_climb_sum_fee;
    }

    public String getSk_no_elevator_cnt() {
        return sk_no_elevator_cnt;
    }

    public void setSk_no_elevator_cnt(String sk_no_elevator_cnt) {
        this.sk_no_elevator_cnt = sk_no_elevator_cnt;
    }

    public String getSk_no_elevator_sum_fee() {
        return sk_no_elevator_sum_fee;
    }

    public void setSk_no_elevator_sum_fee(String sk_no_elevator_sum_fee) {
        this.sk_no_elevator_sum_fee = sk_no_elevator_sum_fee;
    }

    public String getSk_no_climb_cnt() {
        return sk_no_climb_cnt;
    }

    public void setSk_no_climb_cnt(String sk_no_climb_cnt) {
        this.sk_no_climb_cnt = sk_no_climb_cnt;
    }

    public String getSk_no_climb_sum_fee() {
        return sk_no_climb_sum_fee;
    }

    public void setSk_no_climb_sum_fee(String sk_no_climb_sum_fee) {
        this.sk_no_climb_sum_fee = sk_no_climb_sum_fee;
    }

    public String getSk_no_distinguish_cnt() {
        return sk_no_distinguish_cnt;
    }

    public void setSk_no_distinguish_cnt(String sk_no_distinguish_cnt) {
        this.sk_no_distinguish_cnt = sk_no_distinguish_cnt;
    }

    public String getSk_no_distinguish_sum_fee() {
        return sk_no_distinguish_sum_fee;
    }

    public void setSk_no_distinguish_sum_fee(String sk_no_distinguish_sum_fee) {
        this.sk_no_distinguish_sum_fee = sk_no_distinguish_sum_fee;
    }

    public String getOther_pay_cust_type_climb_cnt() {
        return other_pay_cust_type_climb_cnt;
    }

    public void setOther_pay_cust_type_climb_cnt(String other_pay_cust_type_climb_cnt) {
        this.other_pay_cust_type_climb_cnt = other_pay_cust_type_climb_cnt;
    }

    public String getOther_pay_cust_type_climb_sum_fee() {
        return other_pay_cust_type_climb_sum_fee;
    }

    public void setOther_pay_cust_type_climb_sum_fee(String other_pay_cust_type_climb_sum_fee) {
        this.other_pay_cust_type_climb_sum_fee = other_pay_cust_type_climb_sum_fee;
    }

    public String getOther_pay_cust_type_no_elevator_cnt() {
        return other_pay_cust_type_no_elevator_cnt;
    }

    public void setOther_pay_cust_type_no_elevator_cnt(String other_pay_cust_type_no_elevator_cnt) {
        this.other_pay_cust_type_no_elevator_cnt = other_pay_cust_type_no_elevator_cnt;
    }

    public String getOther_pay_cust_type_no_elevator_sum_fee() {
        return other_pay_cust_type_no_elevator_sum_fee;
    }

    public void setOther_pay_cust_type_no_elevator_sum_fee(String other_pay_cust_type_no_elevator_sum_fee) {
        this.other_pay_cust_type_no_elevator_sum_fee = other_pay_cust_type_no_elevator_sum_fee;
    }

    public String getOther_pay_cust_type_no_climb_cnt() {
        return other_pay_cust_type_no_climb_cnt;
    }

    public void setOther_pay_cust_type_no_climb_cnt(String other_pay_cust_type_no_climb_cnt) {
        this.other_pay_cust_type_no_climb_cnt = other_pay_cust_type_no_climb_cnt;
    }

    public String getOther_pay_cust_type_no_climb_sum_fee() {
        return other_pay_cust_type_no_climb_sum_fee;
    }

    public void setOther_pay_cust_type_no_climb_sum_fee(String other_pay_cust_type_no_climb_sum_fee) {
        this.other_pay_cust_type_no_climb_sum_fee = other_pay_cust_type_no_climb_sum_fee;
    }

    public String getOther_pay_cust_type_no_distinguish_cnt() {
        return other_pay_cust_type_no_distinguish_cnt;
    }

    public void setOther_pay_cust_type_no_distinguish_cnt(String other_pay_cust_type_no_distinguish_cnt) {
        this.other_pay_cust_type_no_distinguish_cnt = other_pay_cust_type_no_distinguish_cnt;
    }

    public String getOther_pay_cust_type_no_distinguish_sum_fee() {
        return other_pay_cust_type_no_distinguish_sum_fee;
    }

    public void setOther_pay_cust_type_no_distinguish_sum_fee(String other_pay_cust_type_no_distinguish_sum_fee) {
        this.other_pay_cust_type_no_distinguish_sum_fee = other_pay_cust_type_no_distinguish_sum_fee;
    }

    public String getSgs_core_climb_cnt() {
        return sgs_core_climb_cnt;
    }

    public void setSgs_core_climb_cnt(String sgs_core_climb_cnt) {
        this.sgs_core_climb_cnt = sgs_core_climb_cnt;
    }

    public String getSgs_core_climb_sum_fee() {
        return sgs_core_climb_sum_fee;
    }

    public void setSgs_core_climb_sum_fee(String sgs_core_climb_sum_fee) {
        this.sgs_core_climb_sum_fee = sgs_core_climb_sum_fee;
    }

    public String getSgs_core_no_elevator_cnt() {
        return sgs_core_no_elevator_cnt;
    }

    public void setSgs_core_no_elevator_cnt(String sgs_core_no_elevator_cnt) {
        this.sgs_core_no_elevator_cnt = sgs_core_no_elevator_cnt;
    }

    public String getSgs_core_no_elevator_sum_fee() {
        return sgs_core_no_elevator_sum_fee;
    }

    public void setSgs_core_no_elevator_sum_fee(String sgs_core_no_elevator_sum_fee) {
        this.sgs_core_no_elevator_sum_fee = sgs_core_no_elevator_sum_fee;
    }

    public String getSgs_core_no_climb_cnt() {
        return sgs_core_no_climb_cnt;
    }

    public void setSgs_core_no_climb_cnt(String sgs_core_no_climb_cnt) {
        this.sgs_core_no_climb_cnt = sgs_core_no_climb_cnt;
    }

    public String getSgs_core_no_climb_sum_fee() {
        return sgs_core_no_climb_sum_fee;
    }

    public void setSgs_core_no_climb_sum_fee(String sgs_core_no_climb_sum_fee) {
        this.sgs_core_no_climb_sum_fee = sgs_core_no_climb_sum_fee;
    }

    public String getSgs_core_no_distinguish_cnt() {
        return sgs_core_no_distinguish_cnt;
    }

    public void setSgs_core_no_distinguish_cnt(String sgs_core_no_distinguish_cnt) {
        this.sgs_core_no_distinguish_cnt = sgs_core_no_distinguish_cnt;
    }

    public String getSgs_core_no_distinguish_sum_fee() {
        return sgs_core_no_distinguish_sum_fee;
    }

    public void setSgs_core_no_distinguish_sum_fee(String sgs_core_no_distinguish_sum_fee) {
        this.sgs_core_no_distinguish_sum_fee = sgs_core_no_distinguish_sum_fee;
    }

    public String getFop_climb_cnt() {
        return fop_climb_cnt;
    }

    public void setFop_climb_cnt(String fop_climb_cnt) {
        this.fop_climb_cnt = fop_climb_cnt;
    }

    public String getFop_climb_sum_fee() {
        return fop_climb_sum_fee;
    }

    public void setFop_climb_sum_fee(String fop_climb_sum_fee) {
        this.fop_climb_sum_fee = fop_climb_sum_fee;
    }

    public String getFop_no_elevator_cnt() {
        return fop_no_elevator_cnt;
    }

    public void setFop_no_elevator_cnt(String fop_no_elevator_cnt) {
        this.fop_no_elevator_cnt = fop_no_elevator_cnt;
    }

    public String getFop_no_elevator_sum_fee() {
        return fop_no_elevator_sum_fee;
    }

    public void setFop_no_elevator_sum_fee(String fop_no_elevator_sum_fee) {
        this.fop_no_elevator_sum_fee = fop_no_elevator_sum_fee;
    }

    public String getFop_no_climb_cnt() {
        return fop_no_climb_cnt;
    }

    public void setFop_no_climb_cnt(String fop_no_climb_cnt) {
        this.fop_no_climb_cnt = fop_no_climb_cnt;
    }

    public String getFop_no_climb_sum_fee() {
        return fop_no_climb_sum_fee;
    }

    public void setFop_no_climb_sum_fee(String fop_no_climb_sum_fee) {
        this.fop_no_climb_sum_fee = fop_no_climb_sum_fee;
    }

    public String getFop_no_distinguish_cnt() {
        return fop_no_distinguish_cnt;
    }

    public void setFop_no_distinguish_cnt(String fop_no_distinguish_cnt) {
        this.fop_no_distinguish_cnt = fop_no_distinguish_cnt;
    }

    public String getFop_no_distinguish_sum_fee() {
        return fop_no_distinguish_sum_fee;
    }

    public void setFop_no_distinguish_sum_fee(String fop_no_distinguish_sum_fee) {
        this.fop_no_distinguish_sum_fee = fop_no_distinguish_sum_fee;
    }

    public String getOther_pickup_barsn_climb_cnt() {
        return other_pickup_barsn_climb_cnt;
    }

    public void setOther_pickup_barsn_climb_cnt(String other_pickup_barsn_climb_cnt) {
        this.other_pickup_barsn_climb_cnt = other_pickup_barsn_climb_cnt;
    }

    public String getOther_pickup_barsn_climb_sum_fee() {
        return other_pickup_barsn_climb_sum_fee;
    }

    public void setOther_pickup_barsn_climb_sum_fee(String other_pickup_barsn_climb_sum_fee) {
        this.other_pickup_barsn_climb_sum_fee = other_pickup_barsn_climb_sum_fee;
    }

    public String getOther_pickup_barsn_no_elevator_cnt() {
        return other_pickup_barsn_no_elevator_cnt;
    }

    public void setOther_pickup_barsn_no_elevator_cnt(String other_pickup_barsn_no_elevator_cnt) {
        this.other_pickup_barsn_no_elevator_cnt = other_pickup_barsn_no_elevator_cnt;
    }

    public String getOther_pickup_barsn_no_elevator_sum_fee() {
        return other_pickup_barsn_no_elevator_sum_fee;
    }

    public void setOther_pickup_barsn_no_elevator_sum_fee(String other_pickup_barsn_no_elevator_sum_fee) {
        this.other_pickup_barsn_no_elevator_sum_fee = other_pickup_barsn_no_elevator_sum_fee;
    }

    public String getOther_pickup_barsn_no_climb_cnt() {
        return other_pickup_barsn_no_climb_cnt;
    }

    public void setOther_pickup_barsn_no_climb_cnt(String other_pickup_barsn_no_climb_cnt) {
        this.other_pickup_barsn_no_climb_cnt = other_pickup_barsn_no_climb_cnt;
    }

    public String getOther_pickup_barsn_no_climb_sum_fee() {
        return other_pickup_barsn_no_climb_sum_fee;
    }

    public void setOther_pickup_barsn_no_climb_sum_fee(String other_pickup_barsn_no_climb_sum_fee) {
        this.other_pickup_barsn_no_climb_sum_fee = other_pickup_barsn_no_climb_sum_fee;
    }

    public String getOther_pickup_barsn_no_distinguish_cnt() {
        return other_pickup_barsn_no_distinguish_cnt;
    }

    public void setOther_pickup_barsn_no_distinguish_cnt(String other_pickup_barsn_no_distinguish_cnt) {
        this.other_pickup_barsn_no_distinguish_cnt = other_pickup_barsn_no_distinguish_cnt;
    }

    public String getOther_pickup_barsn_no_distinguish_sum_fee() {
        return other_pickup_barsn_no_distinguish_sum_fee;
    }

    public void setOther_pickup_barsn_no_distinguish_sum_fee(String other_pickup_barsn_no_distinguish_sum_fee) {
        this.other_pickup_barsn_no_distinguish_sum_fee = other_pickup_barsn_no_distinguish_sum_fee;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getStat_date() {
        return stat_date;
    }

    public void setStat_date(String stat_date) {
        this.stat_date = stat_date;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getSum_fee() {
        return sum_fee;
    }

    public void setSum_fee(String sum_fee) {
        this.sum_fee = sum_fee;
    }

    public String getGis_cnt() {
        return gis_cnt;
    }

    public void setGis_cnt(String gis_cnt) {
        this.gis_cnt = gis_cnt;
    }

    public String getGis_sum_fee() {
        return gis_sum_fee;
    }

    public void setGis_sum_fee(String gis_sum_fee) {
        this.gis_sum_fee = gis_sum_fee;
    }

    public String getClimb_cnt() {
        return climb_cnt;
    }

    public void setClimb_cnt(String climb_cnt) {
        this.climb_cnt = climb_cnt;
    }

    public String getClimb_sum_fee() {
        return climb_sum_fee;
    }

    public void setClimb_sum_fee(String climb_sum_fee) {
        this.climb_sum_fee = climb_sum_fee;
    }

    public String getNo_elevator_cnt() {
        return no_elevator_cnt;
    }

    public void setNo_elevator_cnt(String no_elevator_cnt) {
        this.no_elevator_cnt = no_elevator_cnt;
    }

    public String getNo_elevator_sum_fee() {
        return no_elevator_sum_fee;
    }

    public void setNo_elevator_sum_fee(String no_elevator_sum_fee) {
        this.no_elevator_sum_fee = no_elevator_sum_fee;
    }

    public String getNo_climb_cnt() {
        return no_climb_cnt;
    }

    public void setNo_climb_cnt(String no_climb_cnt) {
        this.no_climb_cnt = no_climb_cnt;
    }

    public String getNo_climb_sum_fee() {
        return no_climb_sum_fee;
    }

    public void setNo_climb_sum_fee(String no_climb_sum_fee) {
        this.no_climb_sum_fee = no_climb_sum_fee;
    }

    public String getNo_distinguish_cnt() {
        return no_distinguish_cnt;
    }

    public void setNo_distinguish_cnt(String no_distinguish_cnt) {
        this.no_distinguish_cnt = no_distinguish_cnt;
    }

    public String getNo_distinguish_sum_fee() {
        return no_distinguish_sum_fee;
    }

    public void setNo_distinguish_sum_fee(String no_distinguish_sum_fee) {
        this.no_distinguish_sum_fee = no_distinguish_sum_fee;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
