package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class AddressInfoMapDi implements Serializable {
    @Column(name = "province")
    private String province;
    @Column(name = "region")
    private String region;
    @Column(name = "city")
    private String city;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "area")
    private String area;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
