package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BeeLogsGisGeoParse implements Serializable {
    @Column(name = "ak")
    private String ak;
    @Column(name = "address")
    private String address;
    @Column(name = "city")
    private String city;
    @Column(name = "opt")
    private String opt;
    @Column(name = "cc")
    private String cc;

    @Column(name = "src")
    private String src;
    @Column(name = "match_level")
    private String match_level;
    @Column(name = "data_type")
    private String data_type;
    @Column(name = "precision")
    private String precision;
    @Column(name = "xcoord")
    private String xcoord;
    @Column(name = "ycoord")
    private String ycoord;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "regcode")
    private String regcode;
    @Column(name = "adname")
    private String adname;
    @Column(name = "src_address")
    private String src_address;
    @Column(name = "datasrc")
    private String datasrc;

    @Column(name = "src_test")
    private String src_test;
    @Column(name = "match_level_test")
    private String match_level_test;
    @Column(name = "data_type_test")
    private String data_type_test;
    @Column(name = "precision_test")
    private String precision_test;
    @Column(name = "xcoord_test")
    private String xcoord_test;
    @Column(name = "ycoord_test")
    private String ycoord_test;
    @Column(name = "adcode_test")
    private String adcode_test;
    @Column(name = "regcode_test")
    private String regcode_test;
    @Column(name = "adname_test")
    private String adname_test;
    @Column(name = "src_address_test")
    private String src_address_test;
    @Column(name = "datasrc_test")
    private String datasrc_test;

    @Column(name = "flag")
    private String flag;
    @Column(name = "inc_day")
    private String inc_day;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getSrc_test() {
        return src_test;
    }

    public void setSrc_test(String src_test) {
        this.src_test = src_test;
    }

    public String getMatch_level_test() {
        return match_level_test;
    }

    public void setMatch_level_test(String match_level_test) {
        this.match_level_test = match_level_test;
    }

    public String getData_type_test() {
        return data_type_test;
    }

    public void setData_type_test(String data_type_test) {
        this.data_type_test = data_type_test;
    }

    public String getPrecision_test() {
        return precision_test;
    }

    public void setPrecision_test(String precision_test) {
        this.precision_test = precision_test;
    }

    public String getXcoord_test() {
        return xcoord_test;
    }

    public void setXcoord_test(String xcoord_test) {
        this.xcoord_test = xcoord_test;
    }

    public String getYcoord_test() {
        return ycoord_test;
    }

    public void setYcoord_test(String ycoord_test) {
        this.ycoord_test = ycoord_test;
    }

    public String getAdcode_test() {
        return adcode_test;
    }

    public void setAdcode_test(String adcode_test) {
        this.adcode_test = adcode_test;
    }

    public String getRegcode_test() {
        return regcode_test;
    }

    public void setRegcode_test(String regcode_test) {
        this.regcode_test = regcode_test;
    }

    public String getAdname_test() {
        return adname_test;
    }

    public void setAdname_test(String adname_test) {
        this.adname_test = adname_test;
    }

    public String getSrc_address_test() {
        return src_address_test;
    }

    public void setSrc_address_test(String src_address_test) {
        this.src_address_test = src_address_test;
    }

    public String getDatasrc_test() {
        return datasrc_test;
    }

    public void setDatasrc_test(String datasrc_test) {
        this.datasrc_test = datasrc_test;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getCc() {
        return cc;
    }

    public void setCc(String cc) {
        this.cc = cc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getMatch_level() {
        return match_level;
    }

    public void setMatch_level(String match_level) {
        this.match_level = match_level;
    }

    public String getData_type() {
        return data_type;
    }

    public void setData_type(String data_type) {
        this.data_type = data_type;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getXcoord() {
        return xcoord;
    }

    public void setXcoord(String xcoord) {
        this.xcoord = xcoord;
    }

    public String getYcoord() {
        return ycoord;
    }

    public void setYcoord(String ycoord) {
        this.ycoord = ycoord;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getRegcode() {
        return regcode;
    }

    public void setRegcode(String regcode) {
        this.regcode = regcode;
    }

    public String getAdname() {
        return adname;
    }

    public void setAdname(String adname) {
        this.adname = adname;
    }

    public String getSrc_address() {
        return src_address;
    }

    public void setSrc_address(String src_address) {
        this.src_address = src_address;
    }

    public String getDatasrc() {
        return datasrc;
    }

    public void setDatasrc(String datasrc) {
        this.datasrc = datasrc;
    }
}
