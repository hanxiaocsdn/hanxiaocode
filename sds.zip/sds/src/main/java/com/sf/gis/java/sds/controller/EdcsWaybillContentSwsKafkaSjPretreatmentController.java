package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.aoicompletion.FvpCoreFactRouteRt;
import com.sf.gis.java.sds.pojo.aoicompletion.GisRdsOmsfrom;
import com.sf.gis.java.sds.pojo.aoicompletion.GisRdsOmsto;
import com.sf.gis.java.sds.pojo.aoicompletion.OrderWaybillHook;
import com.sf.gis.java.sds.pojo.waybillaoi.AoiStatAoiid;
import com.sf.gis.java.sds.pojo.waybillaoi.AoiValue;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.pojo.waybillaoi.ScheduleWidthData;
import com.sf.gis.java.sds.service.EdcsWaybillContentSwsKafkaService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.List;

public class EdcsWaybillContentSwsKafkaSjPretreatmentController implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(EdcsWaybillContentSwsKafkaSjPretreatmentController.class);
    EdcsWaybillContentSwsKafkaService service = new EdcsWaybillContentSwsKafkaService();

    public void process(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("gis_rds_omsto预处理");
        String before10Date = DateUtil.getDaysBefore(date, 10);
        JavaRDD<GisRdsOmsto> rdsOmstoRdd = service.loadRdsOmstoData(sparkInfo, before10Date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmstoRdd cnt:{}", rdsOmstoRdd.count());

        DataUtil.saveOverwrite(spark, sc, "dm_gis.gis_rds_omsto_pretreatment", GisRdsOmsto.class, rdsOmstoRdd, "");
        rdsOmstoRdd.unpersist();

        logger.error("排班表预处理");
        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<AoiValue> aoiValueRdd = service.loadAoiValueApplacation(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiValueRdd cnt:{}", aoiValueRdd.count());

        String before30Date = DateUtil.getDaysBefore(date, 30);
        logger.error("before30Date:{}", before30Date);
        JavaRDD<AoiStatAoiid> aoiStatAoiidRdd = service.loadAoiStatAoiid(sparkInfo, before30Date, date).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey().map(tp -> {
            List<AoiStatAoiid> list = Lists.newArrayList(tp._2);
            AoiStatAoiid aoiStatAoiid = list.get(0);
            int sum = list.stream().filter(o -> StringUtils.isNotEmpty(o.getCount())).map(o -> Integer.valueOf(o.getCount())).reduce((o1, o2) -> o1 + o2).orElse(0);
            aoiStatAoiid.setCount(sum + "");
            return aoiStatAoiid;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiStatAoiidRdd cnt:{}", aoiStatAoiidRdd.count());

        JavaRDD<ScheduleWidthData> scheduleWidthDataRdd = service.loadScheduleWidthData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataRdd cnt:{}", scheduleWidthDataRdd.count());

        JavaRDD<ScheduleWidthData> scheduleWidthDataPretreatmentRdd = scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))).map(tp -> {
            ScheduleWidthData o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                o.setAoi_name(cmsAoiSch.getAoi_name());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(aoiValueRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
            ScheduleWidthData o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                AoiValue aoiValue = tp._2._2.get();
                o.setJiti(aoiValue.getPick_wage_level());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(aoiStatAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))).map(tp -> {
            ScheduleWidthData o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                AoiStatAoiid aoiStatAoiid = tp._2._2.get();
                o.setAoi_count(aoiStatAoiid.getCount());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataPretreatmentRdd cnt:{}", scheduleWidthDataPretreatmentRdd.count());
        scheduleWidthDataRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.tm_schedule_width_data_v2_pretreatment", ScheduleWidthData.class, scheduleWidthDataPretreatmentRdd, "inc_day");
        scheduleWidthDataPretreatmentRdd.unpersist();

        logger.error("gis_rds_omsfrom 预处理");
        JavaRDD<GisRdsOmsfrom> rdsOmsfromRdd = service.loadRdsOmsfromData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmsfromRdd cnt:{}", rdsOmsfromRdd.count());

        JavaPairRDD<String, FvpCoreFactRouteRt> fvpCoreFactRouteRtRdd = service.loadFvpCoreFactRouteRtData(sparkInfo, date).mapToPair(o -> new Tuple2<>(o.getMainwaybillno(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fvpCoreFactRouteRtRdd cnt:{}", fvpCoreFactRouteRtRdd.count());

        JavaRDD<GisRdsOmsfrom> rdsOmsfromAoiRdd = rdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).leftOuterJoin(fvpCoreFactRouteRtRdd).map(tp -> {
            GisRdsOmsfrom o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                FvpCoreFactRouteRt fvpCoreFactRouteRt = tp._2._2.get();
                o.setEmp_code(fvpCoreFactRouteRt.getCouriercode());
            }
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getEmp_code())).map(o -> {
            String syncreqdatetime = o.getSyncreqdatetime();
            if (StringUtils.isNotEmpty(syncreqdatetime)) {
                String barscantmstd = DateUtil.dateToStamp(syncreqdatetime);
                o.setReqtimetm(barscantmstd);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getFinalaoicode(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
            GisRdsOmsfrom o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                o.setAoi_id(cmsAoiSch.getAoi_id());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmsfromAoiRdd cnt:{}", rdsOmsfromAoiRdd.count());
        rdsOmsfromRdd.unpersist();
        fvpCoreFactRouteRtRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.gis_rds_omsfrom_pretreatment", GisRdsOmsfrom.class, rdsOmsfromAoiRdd, "inc_day");
        rdsOmsfromAoiRdd.unpersist();

        logger.error("hook 预处理");
        JavaRDD<OrderWaybillHook> orderWaybillHookRdd = service.loadTtOrderWaybillData(sparkInfo, before30Date, date)
                .filter(o -> StringUtils.isNotEmpty(o.getEmp_code()) && StringUtils.isNotEmpty(o.getAoi_id()))
                .map(o -> {
                    String emp_code = o.getEmp_code();
                    if (StringUtils.isNotEmpty(emp_code)) {
                        o.setEmp_code(service.processTakeoverMemberNo(emp_code));
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookRdd cnt:{}", orderWaybillHookRdd.count());

        JavaRDD<OrderWaybillHook> orderWaybillHookAoiNameRdd = orderWaybillHookRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                    OrderWaybillHook o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setAoi_name(cmsAoiSch.getAoi_name());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookAoiNameRdd cnt:{}", orderWaybillHookAoiNameRdd.count());
        orderWaybillHookRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        JavaRDD<OrderWaybillHook> orderWaybillHookAoiCountRdd = orderWaybillHookAoiNameRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(aoiStatAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    OrderWaybillHook o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiStatAoiid aoiStatAoiid = tp._2._2.get();
                        String count = aoiStatAoiid.getCount();
                        o.setAoi_count(count);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookAoiCountRdd cnt:{}", orderWaybillHookAoiCountRdd.count());
        orderWaybillHookAoiNameRdd.unpersist();
        aoiStatAoiidRdd.unpersist();

        JavaRDD<OrderWaybillHook> orderWaybillHookAoiJitiRdd = orderWaybillHookAoiCountRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(aoiValueRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OrderWaybillHook o = tp._2._1;
                    if (tp._2._2() != null && tp._2._2.isPresent()) {
                        AoiValue aoiJiTi = tp._2._2.get();
                        //o.setJiti(aoiJiTi.getPick_wage_level());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookAoiJitiRdd cnt:{}", orderWaybillHookAoiJitiRdd.count());
        orderWaybillHookAoiCountRdd.unpersist();
        aoiValueRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.hook_pretreatment", OrderWaybillHook.class, orderWaybillHookAoiJitiRdd, "");
        orderWaybillHookAoiJitiRdd.unpersist();

        sc.stop();

    }
}
