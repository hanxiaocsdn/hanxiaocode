package com.sf.gis.java.sds.pojo;


import com.sf.gis.java.base.util.MD5Util;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.Serializable;


@Entity
public class AoiHook implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 6403897719935230187L;
    @Column(name = "ID")
    private String id;
    @Column(name = "DATA_TYPE")
    private String dataType;
    @Column(name = "STAT_TYPE")
    private String statType;
    @Column(name = "STAT_TYPE_CONTENT")
    private String statTypeContent;
    @Column(name = "STAT_DATE")
    private String statDate;
    @Column(name = "REGION")
    private String region;
    @Column(name = "CITY_CODE")
    private String cityCode;
    @Column(name = "ZONECODE")
    private String zonecode;
    @Column(name = "WB_COUNT")
    private int wbCount;
    @Column(name = "WB_HOOK")
    private int wbHook;
    @Column(name = "WB_HOOK_TYPE")
    private int wbHookType;

    public AoiHook(String id, String dataType, String statType, String statTypeContent, String statDate, String region,
                   String cityCode, String zonecode, int wbCount, int wbHook, int wbHookType) {
        this.id = id;
        this.dataType = dataType;
        this.statType = statType;
        this.statTypeContent = statTypeContent;
        this.statDate = statDate;
        this.region = region;
        this.cityCode = cityCode;
        this.zonecode = zonecode;
        this.wbCount = wbCount;
        this.wbHook = wbHook;
        this.wbHookType = wbHookType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getStatTypeContent() {
        return statTypeContent;
    }

    public void setStatTypeContent(String statTypeContent) {
        this.statTypeContent = statTypeContent;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public int getWbCount() {
        return wbCount;
    }

    public void setWbCount(int wbCount) {
        this.wbCount = wbCount;
    }

    public int getWbHook() {
        return wbHook;
    }

    public void setWbHook(int wbHook) {
        this.wbHook = wbHook;
    }

    public int getWbHookType() {
        return wbHookType;
    }

    public void setWbHookType(int wbHookType) {
        this.wbHookType = wbHookType;
    }

    public void update(AoiHook obj) {
        this.wbCount = this.wbCount + obj.getWbCount();
        this.wbHook = this.wbHook + obj.getWbHook();
        this.wbHookType = this.wbHookType + obj.getWbHookType();
    }

    public void createId() {
        this.id = this.dataType + "_" + this.statDate
                + "_" + this.region + "_" + this.cityCode + "_" + this.zonecode;
    }

    public void md5Id() {
        this.id = MD5Util.getMD5(this.id);
    }

    public AoiHook() {
    }
}