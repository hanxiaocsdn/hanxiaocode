package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CmsAddress;
import com.sf.gis.java.sds.service.StdAddrCoincideJudgeService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class StdAddrCoincideJudgeSameAoiBuildingController {
    private static Logger logger = LoggerFactory.getLogger(StdAddrCoincideJudgeSameAoiBuildingController.class);
    StdAddrCoincideJudgeService service = new StdAddrCoincideJudgeService();

    private static String atp = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&showserver=true&ak=dec044d089524419b371bc94555c539d&opt=zh";
    private static String similarUrl = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=3eb300d2e06947f7945cd02530a32fd2&beforeAddress=%s&afterAddress=%s";
    private static String distanceaoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept/routeplan/aoi?aoi_code1=%s&city_code1=%s&aoi_code2=%s&city_code2=%s&ak=3eb300d2e06947f7945cd02530a32fd2";

    private static int limitSec = 2000 / 40;

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        for (Map.Entry<Object, Object> objectObjectEntry : cityDbPro.entrySet()) {
            String city = (String) objectObjectEntry.getKey();
            if (!StringUtils.equals(city, "010")) {
                continue;
            }

            JavaRDD<CmsAddress> rdd = service.loadCoincideJudgeData(spark, sc, date, city).filter(o -> StringUtils.equals(o.getMax_split_key(), "14")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());

            rdd.mapToPair(o -> new Tuple2<>(o.getKey_14(), o)).leftOuterJoin(rdd.mapToPair(o -> new Tuple2<>(o.getKey_14(), o)).groupByKey()).map(tp -> {
                CmsAddress o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<CmsAddress> list = Lists.newArrayList(tp._2._2.get());
                }
                return null;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());


        }
    }
}
