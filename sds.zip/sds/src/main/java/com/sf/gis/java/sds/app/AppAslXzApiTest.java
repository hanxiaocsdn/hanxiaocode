package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AslXz;
import com.sf.gis.scala.base.pojo.Cnt;
import com.sf.gis.scala.base.pojo.StratTime;
import com.sf.gis.scala.base.spark.SparkUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.util.ArrayList;

/**
 * 任务id：	795785（乡村达灰度接口测试）
 * 业务：01425243（敖少良）
 * 研发：01399581（匡仁衡）
 */
public class AppAslXzApiTest {
    private static final Logger logger = Logger.getLogger(AppAslXzApiTest.class);
    private static String url = "http://gis-gw.int.sfdc.com.cn:9080/village/api";
    private static String match = "http://gis-gw.int.sfdc.com.cn:9080/village/match";
    private static String ak = "7ae7a15377f34c74b3885d017f74a7a9";
    private static String pro_ak = "5686a2aca02e42c9807158558446a455";

    private static int limitMin1 = 20000 / 20;
    private static int limitMin2 = 20000 / 20;

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAslXzApiTest");
        SparkSession spark = sparkInfo.getSession();
        JavaSparkContext sc = sparkInfo.getContext();

        logger.error("获取数据源");
        JavaRDD<AslXz> uniqueRdd = getData(spark, sc, date);
        logger.error("调灰度接口");
        JavaRDD<AslXz> greRdd = url(uniqueRdd, ak, limitMin1, "gre");
        logger.error("灰度打标签");
        JavaRDD<AslXz> tagRdd = tag(greRdd, "gre");

        JavaRDD<AslXz> eq1Rdd = tagRdd.filter(o -> "1".equals(o.getCompare())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AslXz> eq0Rdd = tagRdd.filter(o -> "0".equals(o.getCompare())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1Rdd cnt:" + eq1Rdd.count());
        logger.error("eq0Rdd cnt:" + eq0Rdd.count());
        tagRdd.unpersist();

        logger.error("调生产接口");
        JavaRDD<AslXz> proRdd = url(eq0Rdd, pro_ak, limitMin2, "pro");
        logger.error("生产打标签");
        JavaRDD<AslXz> proTagRdd = tag(proRdd, "pro");
        logger.error("结果存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_village_log_asl_xz_api_test_result_di", AslXz.class, eq1Rdd.union(proTagRdd), "inc_day");
        eq1Rdd.unpersist();
        proTagRdd.unpersist();
        sc.stop();

    }

    public static JavaRDD<AslXz> tag(JavaRDD<AslXz> greRdd, String tag) {
        JavaRDD<AslXz> tagRdd = greRdd.map(o -> {
            String r_vil_space_code = o.getR_vil_space_code();
            String vilSpaceCode = o.getVilSpaceCode();
            String pro_vilSpaceCode = o.getPro_vilSpaceCode();
            if ("gre".equals(tag)) {
                if (StringUtils.equals(vilSpaceCode, r_vil_space_code)) {
                    o.setCompare("1");
                } else {
                    o.setCompare("0");
                }
            } else {
                if (StringUtils.equals(pro_vilSpaceCode, vilSpaceCode)) {
                    o.setPro_compare("1");
                } else {
                    o.setPro_compare("0");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:" + tagRdd.count());
        greRdd.unpersist();
        return tagRdd;
    }

    public static JavaRDD<AslXz> url(JavaRDD<AslXz> uniqueRdd, String run_ak, int limitMin, String tag) {
        JavaRDD<AslXz> processRdd = uniqueRdd.mapPartitionsWithIndex(((index, itr) -> {
            ArrayList<AslXz> list = new ArrayList<>();
            StratTime stratTime = new StratTime(System.currentTimeMillis());
            Cnt cnt = new Cnt(0);
            while (itr.hasNext()) {
                SparkUtils.limitAkUse(stratTime, cnt, index, limitMin, logger);
                AslXz o = itr.next();
                String addr = o.getP_address();
                String citycode = o.getP_city_code();
                String p_sys_code = o.getP_sys_code();
                String p_aoiid = o.getP_aoiid();
                String p_at_aoi_src = o.getP_at_aoi_src();
                String p_aoi_code = o.getP_aoi_code();
                String p_split_result = o.getP_split_result();
                String p_standardization = o.getP_standardization();
                String sysCode = "YYPS";

                JSONObject param = new JSONObject();
                param.put("address", addr);
                param.put("cityCode", citycode);
                param.put("sysCode", sysCode);
                param.put("aoiid", p_aoiid);
                param.put("atAoiSrc", p_at_aoi_src);
                param.put("aoiCode", p_aoi_code);
                param.put("splitResult", p_split_result);
                param.put("standardization", p_standardization);
                if (p_sys_code.contains("GIS-ASS-EDS-SX")) {
                    String opt = "all";
                    param.put("opt", opt);
                    o.setOpt(opt);
                }
                String content = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", run_ak, "UTF-8", "UTF-8");
                if (StringUtils.equals(tag, "gre")) {
                    o.setXz_result(content);
                    try {
                        JSONObject data = JSON.parseObject(content).getJSONObject("result").getJSONObject("data");
                        if (data != null) {
                            String province = data.getString("province");
                            String city = data.getString("city");
                            String county = data.getString("county");
                            String town = data.getString("town");
                            String src = data.getString("src");
                            String x = data.getString("x");
                            String y = data.getString("y");
                            String vilName = data.getString("vilName");
                            String vilSpaceCode = data.getString("vilSpaceCode");
                            String classCode = data.getString("classCode");
                            String aoiId = data.getString("aoiId");
                            String vilcode = data.getString("vilCode");
                            String townAdcode = data.getString("townAdCode");
                            String geoX = data.getString("geoX");
                            String geoY = data.getString("geoY");
                            String groupId = data.getString("groupId");
                            String splitResult = data.getString("splitResult");
                            String standardization = data.getString("standardization");
                            String atAoisrc = data.getString("atAoiSrc");
                            String townX = data.getString("townX");
                            String townY = data.getString("townY");
                            String distance = data.getString("distance");
                            String aoiCode = data.getString("aoiCode");
                            String deptCode = data.getString("deptCode");
                            String filter = data.getString("filter");
                            String level = data.getString("level");

                            logger.error("gre vilSpaceCode:" + vilSpaceCode);

                            o.setProvince(province);
                            o.setCity(city);
                            o.setCounty(county);
                            o.setTown(town);
                            o.setSrc(src);
                            o.setX(x);
                            o.setY(y);
                            o.setVilName(vilName);
                            o.setVilSpaceCode(vilSpaceCode);
                            o.setClassCode(classCode);
                            o.setAoiid(aoiId);
                            o.setVilcode(vilcode);
                            o.setTownAdcode(townAdcode);
                            o.setGeoX(geoX);
                            o.setGeoY(geoY);
                            o.setGroupId(groupId);
                            o.setSplitResult(splitResult);
                            o.setStandardization(standardization);
                            o.setAtAoiSrc(atAoisrc);
                            o.setTownX(townX);
                            o.setTownY(townY);
                            o.setDistance(distance);
                            o.setAoiCode(aoiCode);
                            o.setDeptCode(deptCode);
                            o.setFilter(filter);
                            o.setLevel(level);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                } else {
                    o.setPro_xz_result(content);
                    try {
                        JSONObject data = JSON.parseObject(content).getJSONObject("result").getJSONObject("data");
                        if (data != null) {
                            String province = data.getString("province");
                            String city = data.getString("city");
                            String county = data.getString("county");
                            String town = data.getString("town");
                            String src = data.getString("src");
                            String x = data.getString("x");
                            String y = data.getString("y");
                            String vilName = data.getString("vilName");
                            String vilSpaceCode = data.getString("vilSpaceCode");
                            String classCode = data.getString("classCode");
                            String aoiId = data.getString("aoiId");
                            String vilcode = data.getString("vilCode");
                            String townAdcode = data.getString("townAdCode");
                            String geoX = data.getString("geoX");
                            String geoY = data.getString("geoY");
                            String groupId = data.getString("groupId");
                            String splitResult = data.getString("splitResult");
                            String standardization = data.getString("standardization");
                            String atAoisrc = data.getString("atAoiSrc");
                            String townX = data.getString("townX");
                            String townY = data.getString("townY");
                            String distance = data.getString("distance");
                            String aoiCode = data.getString("aoiCode");
                            String deptCode = data.getString("deptCode");
                            String filter = data.getString("filter");
                            String level = data.getString("level");

                            logger.error("pro vilSpaceCode:" + vilSpaceCode);

                            o.setPro_province(province);
                            o.setPro_city(city);
                            o.setPro_county(county);
                            o.setPro_town(town);
                            o.setPro_src(src);
                            o.setPro_x(x);
                            o.setPro_y(y);
                            o.setPro_vilName(vilName);
                            o.setPro_vilSpaceCode(vilSpaceCode);
                            o.setPro_classCode(classCode);
                            o.setPro_aoiid(aoiId);
                            o.setPro_vilcode(vilcode);
                            o.setPro_townAdcode(townAdcode);
                            o.setPro_geoX(geoX);
                            o.setPro_geoY(geoY);
                            o.setPro_groupId(groupId);
                            o.setPro_splitResult(splitResult);
                            o.setPro_standardization(standardization);
                            o.setPro_atAoiSrc(atAoisrc);
                            o.setPro_townX(townX);
                            o.setPro_townY(townY);
                            o.setPro_distance(distance);
                            o.setPro_aoiCode(aoiCode);
                            o.setPro_deptCode(deptCode);
                            o.setPro_filter(filter);
                            o.setPro_level(level);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("processRdd cnt:" + processRdd.count());
        uniqueRdd.unpersist();
        return processRdd;
    }

    public static JavaRDD<AslXz> getData(SparkSession spark, JavaSparkContext sc, String date) {
//        String sql = String.format("select " +
//                "  p_address, " +
//                "  p_city_code, " +
//                "  p_sys_code, " +
//                "  p_aoiid, " +
//                "  p_at_aoi_src, " +
//                "  p_aoi_code, " +
//                "  p_split_result, " +
//                "  p_standardization, " +
//                "  r_vilname, " +
//                "  r_vilcode, " +
//                "  r_vil_space_code, " +
//                "  r_class_code, " +
//                "  r_aoiid, " +
//                "  r_distance, " +
//                "  r_filter, " +
//                "  r_level, " +
//                "  r_src, " +
//                "  r_msg, " +
//                "  inc_day " +
//                "from " +
//                "  dm_gis.village_log_flink_res " +
//                "where " +
//                "  inc_day = '%s' " +
//                "  and (p_address is not null and p_address <>'') " +
//                "  and (p_sys_code like '%%CHK%%' or p_sys_code like '%%GIS-ASS-EDS-SX%%')", date);

        String sql = "select\n" +
                "  p_address,\n" +
                "  p_city_code,\n" +
                "  p_sys_code,\n" +
                "  p_aoiid,\n" +
                "  p_at_aoi_src,\n" +
                "  p_aoi_code,\n" +
                "  p_split_result,\n" +
                "  p_standardization,\n" +
                "  r_vilname,\n" +
                "  r_vilcode,\n" +
                "  r_vil_space_code,\n" +
                "  r_class_code,\n" +
                "  r_aoiid,\n" +
                "  r_distance,\n" +
                "  r_filter,\n" +
                "  r_level,\n" +
                "  r_src,\n" +
                "  r_msg,\n" +
                "  '20240109' inc_day\n" +
                "from\n" +
                "  tmp_dm_gis.compare_village2\n" +
                "where\n" +
                "  bj = '0'";
        JavaRDD<AslXz> rdd = DataUtil.loadData(spark, sc, sql, AslXz.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());

        JavaRDD<AslXz> uniqueRdd = rdd.mapToPair(o -> new Tuple2<>(o.getP_address() + "_" + o.getP_city_code() + "_" + o.getP_sys_code(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueRdd cnt:" + uniqueRdd.count());
        rdd.unpersist();

        return uniqueRdd;
    }

    public static AslXz url(AslXz o, String opt) {
        String addr = o.getP_address();
        String citycode = o.getP_city_code();
        o.setOpt(opt);
        if (StringUtils.isNotEmpty(addr)) {

            JSONObject param1 = new JSONObject();
            param1.put("address", addr);
            if (StringUtils.isNotEmpty(opt)) {
                param1.put("opt", opt);
            }
            String content1 = HttpInvokeUtil.sendPostHeader(match, param1.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", ak, "UTF-8", "UTF-8");
            String vilcode_match = "";
            try {
                vilcode_match = JSON.parseObject(content1).getJSONObject("result").getJSONObject("data").getString("vilCode");
            } catch (Exception e) {
                e.printStackTrace();
            }
//            o.setVilcode_match(vilcode_match);

            JSONObject param = new JSONObject();
            param.put("address", addr);
            param.put("cityCode", citycode);
            param.put("sysCode", "YYPS");
            if (StringUtils.isNotEmpty(opt)) {
                param.put("opt", opt);
            }
            String content = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", ak, "UTF-8", "UTF-8");
            o.setXz_result(content);
            try {
                JSONObject data = JSON.parseObject(content).getJSONObject("result").getJSONObject("data");
                if (data != null) {
                    String province = data.getString("province");
                    String city = data.getString("city");
                    String county = data.getString("county");
                    String town = data.getString("town");
                    String src = data.getString("src");
                    String x = data.getString("x");
                    String y = data.getString("y");
                    String vilName = data.getString("vilName");
                    String vilSpaceCode = data.getString("vilSpaceCode");
                    String classCode = data.getString("classCode");
                    String aoiId = data.getString("aoiId");
                    String vilcode = data.getString("vilCode");
                    String townAdcode = data.getString("townAdCode");
                    String geoX = data.getString("geoX");
                    String geoY = data.getString("geoY");
                    String groupId = data.getString("groupId");
                    String splitResult = data.getString("splitResult");
                    String standardization = data.getString("standardization");
                    String atAoisrc = data.getString("atAoiSrc");
                    String townX = data.getString("townX");
                    String townY = data.getString("townY");
                    String distance = data.getString("distance");
                    String aoiCode = data.getString("aoiCode");
                    String deptCode = data.getString("deptCode");
                    String filter = data.getString("filter");
                    String level = data.getString("level");

                    o.setProvince(province);
                    o.setCity(city);
                    o.setCounty(county);
                    o.setTown(town);
                    o.setSrc(src);
                    o.setX(x);
                    o.setY(y);
                    o.setVilName(vilName);
                    o.setVilSpaceCode(vilSpaceCode);
                    o.setClassCode(classCode);
                    o.setAoiid(aoiId);
                    o.setVilcode(vilcode);
                    o.setTownAdcode(townAdcode);
                    o.setGeoX(geoX);
                    o.setGeoY(geoY);
                    o.setGroupId(groupId);
                    o.setSplitResult(splitResult);
                    o.setStandardization(standardization);
                    o.setAtAoiSrc(atAoisrc);
                    o.setTownX(townX);
                    o.setTownY(townY);
                    o.setDistance(distance);
                    o.setAoiCode(aoiCode);
                    o.setDeptCode(deptCode);
                    o.setFilter(filter);
                    o.setLevel(level);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return o;
    }
}
