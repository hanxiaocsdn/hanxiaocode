package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.AddrInfo;
import com.sf.gis.java.base.dto.AoiInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.Addr4Ho;
import com.sf.gis.java.sds.service.AddrService;
import jodd.util.StringUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.sql.Connection;
import java.util.*;

/**
 * 标杆库分流地址库控制器
 *
 * @author 01370539 Created On: May.27 2021
 */
public class BgHoStdController {
    private static final Logger logger = LoggerFactory.getLogger(BgHoStdController.class);

    private final static AddrService addrService = new AddrService();

    /**
     * 控制器主入口
     *
     * @param statDate 数据所属时间
     * @param citys    需要处理的城市
     */
    public void process(String statDate, String[] citys) {
        logger.error("process start. ");
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        JavaRDD<Addr4Ho> rddStdOrig;
        for (String city : citys) {
            logger.error("process statDate - {}, city - {}", statDate, city);

            rddStdOrig = addrService.loadZc(jsc, JdbcUtil.getMysqlConnection("mysql_wchka.properties"), city).repartition(20).mapToPair(zc -> new Tuple2<>(DigestUtils.md5Hex(zc).hashCode(), zc)).groupByKey().mapPartitions(iter -> {
                Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
                List<Addr4Ho> list = new ArrayList<>();
                while (iter.hasNext()) {
                    Lists.newArrayList(iter.next()._2).forEach(zc -> {
                        logger.error("load city {} zc {} data.", city, zc);
                        String sql = "select address_id id, city_code city_code, address address, keyword keyword, zno_code zc, aoi_id aoi_id from cms_address_" + cityDbPro.getProperty(city) + " where city_code = '" + city + "' and zno_code = '" + zc + "' and type = 1 and del_flag = 0 and aoi_id != '' and aoi_id is not null";
                        list.addAll(DataUtil.loadData(conn, sql, Addr4Ho.class));
                    });
                }
                conn.close();
                return list.iterator();
            }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());

            logger.error("stdLib data count - {}", rddStdOrig.count());
            rddStdOrig.take(1).forEach(temp -> logger.error("stdLib - {}", temp.toString()));

            process(ss, jsc, statDate, city, rddStdOrig);
        }
        logger.error("process end. ");
    }

    // 数据处理
    private static void process(SparkSession ss, JavaSparkContext jsc, String statDate, String city, JavaRDD<Addr4Ho> rddStdOrig) {
        JavaPairRDD<String, Addr4Ho> rddTpStd = rddStdOrig.map(temp -> {
            AddrInfo addrInfo = AddrApi.split("4ee00c498e334e4da3cc6e35469d5afd", temp.getCityCode(), temp.getAddress());
            temp.setKwAddr(StringUtils.isEmpty(addrInfo.getKeyword()) ? "" : addrInfo.getKeyword());
            temp.setKeyTag(StringUtils.isEmpty(addrInfo.getKeytag()) ? "" : addrInfo.getKeytag());
            temp.setLast13(StringUtils.isEmpty(addrInfo.getLast13()) ? "" : addrInfo.getLast13());
            temp.setLast613(StringUtils.isEmpty(addrInfo.getLast613()) ? "" : addrInfo.getLast613());
            temp.setLast14(StringUtils.isEmpty(addrInfo.getLast14()) ? "" : addrInfo.getLast14());
            temp.setSplitStd(StringUtils.isEmpty(addrInfo.getSplit()) ? "" : addrInfo.getSplit());
            return temp;
        }).mapToPair(temp -> new Tuple2<>(temp.getZc() + "#" + temp.getKwAddr() + "#" + temp.getLast13() + "#" + temp.getLast613() + "#" + temp.getLast14(), temp)).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("stdLib tp count - {}", rddTpStd.count());
        rddTpStd.take(1).forEach(tp -> logger.error("stdLib: tpKey - {}, tpValue - {}", tp._1, tp._2.toString()));
        rddStdOrig.unpersist();

        JavaRDD<Addr4Ho> rddBgOrig = addrService.loadBgLib(ss, jsc, statDate, city).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("bgLib data count - {}", rddBgOrig.count());
        rddBgOrig.take(1).forEach(temp -> logger.error("bgLib - {}", temp.toString()));

        JavaPairRDD<String, Addr4Ho> rddTpBg = rddBgOrig.map(temp -> {
            temp.setKeyword(AddrUtil.transferNumber(temp.getKeyword()));
            temp.setKeyTag(AddrUtil.transferNumber(temp.getKeyTag()));
            temp.setLast13(AddrUtil.transferNumber(temp.getLast13()));
            temp.setLast613(AddrUtil.transferNumber(temp.getLast613()));
            temp.setLast14(AddrUtil.transferNumber(temp.getLast14()));
            return temp;
        }).mapToPair(temp -> new Tuple2<>(temp.getZc() + "#" + temp.getKeyword(), temp)).groupByKey().filter(tp -> {
            List<Addr4Ho> list = Lists.newArrayList(tp._2);
            Map<String, Integer> tmpMap = new HashMap<>();
            for (Addr4Ho addr4Ho : list) {
                tmpMap.put(addr4Ho.getAoiId(), 1);
            }
            return tmpMap.size() == 1;
        }).flatMap(tp -> Lists.newArrayList(tp._2).iterator()).mapToPair(temp -> new Tuple2<>(temp.getZc() + "#" + temp.getKeyword() + "#" + temp.getLast13() + "#" + temp.getLast613() + "#" + temp.getLast14(), temp)).groupByKey().mapToPair(tp -> {
            List<Addr4Ho> list = Lists.newArrayList(tp._2);
            Addr4Ho result = list.get(0);
            Map<String, Integer> tempMap = new HashMap<>();
            String[] tagArr;
            for (Addr4Ho o : list) {
                if (StringUtil.isNotEmpty(o.getKeyTag())) {
                    tagArr = o.getKeyTag().split("#");
                    for (String tag : tagArr) {
                        tempMap.put(tag, 1);
                    }
                }
            }
            String finalTag = "";
            for (String tag : tempMap.keySet()) {
                finalTag += (StringUtils.isEmpty(finalTag) ? "" : "#") + tag;
            }
            result.setKeyTag(finalTag);
            return new Tuple2<>(tp._1, result);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("bgLib tp count - {}", rddTpBg.count());
        rddTpBg.take(1).forEach(tp -> logger.error("bgLib: tpKey - {}, tpValue - {}", tp._1, tp._2.toString()));
        rddBgOrig.unpersist();

        JavaPairRDD<String, Addr4Ho> rddTpStdDisp = rddTpStd.join(rddTpBg).filter(tp -> {
            boolean result = false;
            if (StringUtils.isEmpty(tp._2._1.getKeyTag())) {
                result = true;
            } else {
                String[] stdTagArr = tp._2._1.getKeyTag().split("#");
                List<String> bgTagList = Arrays.asList(tp._2._2.getKeyTag().split("#"));
                for (String stdTag : stdTagArr) {
                    if (bgTagList.contains(stdTag)) {
                        result = true;
                        break;
                    }
                }
            }
            return result;
        }).mapToPair(tp -> {
            boolean result = tp._2._1.getAoiId().equals(tp._2._2.getAoiIdBg());
            tp._2._1.setAoiIdBg(tp._2._2.getAoiIdBg());
            tp._2._1.setAoiCodeBg(tp._2._2.getAoiCodeBg());
            tp._2._1.setAoiNameBg(tp._2._2.getAoiNameBg());
            tp._2._1.setKtBg(tp._2._2.getKeyTag());
            tp._2._1.setType(result ? "match" : "unmatch");
            return new Tuple2<>(tp._2._1.getType(), tp._2._1);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("rddTpStdDisp count - {}", rddTpStdDisp.count());
        rddTpStd.unpersist();
        rddTpBg.unpersist();

        JavaRDD<Addr4Ho> rddStdMatch = rddTpStdDisp.filter(tp -> tp._1.equals("match")).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<Addr4Ho> rddStdUnmatch = rddTpStdDisp.filter(tp -> tp._1.equals("unmatch")).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("std & bg, match count - {}, unmatch count - {}", rddStdMatch.count(), rddStdUnmatch.count());
        rddTpStdDisp.unpersist();

        JavaRDD<Addr4Ho> rddStdUnmatchFinal = rddStdUnmatch.map(temp -> {
            AddrInfo addr = AddrApi.geo("3a191e7427e8470c86271a069411c66b", "gd2", temp.getCityCode(), temp.getAddress());
            temp.setLngTs(addr.getLng());
            temp.setLatTs(addr.getLat());
            temp.setPrecisionTs(addr.getPrecision());
            if (StringUtils.isNotEmpty(addr.getLng()) && StringUtils.isNotEmpty(addr.getLat())) {
                AoiInfo aoi = AoiApi.byxy("c2ee00ecb0164098b58569b5bdffe60d", "aoi", addr.getLng(), addr.getLat());
                temp.setAoiIdTs(aoi.getAoiId());
                temp.setAoiNameTs(aoi.getAoiName());
                temp.setAoiCodeTs(aoi.getAoiCode());
            }
            return temp;
        }).filter(temp -> !("2".equals(temp.getPrecisionTs()) && temp.getAoiId().equals(temp.getAoiIdTs()))).filter(temp -> !(StringUtils.isNotEmpty(temp.getAddress()) && StringUtils.isNotEmpty(temp.getAoiNameTs()) && temp.getAddress().endsWith(temp.getAoiNameTs()))).map(temp -> {
            temp.setAddress(AddrUtil.transferNumber(temp.getAddress()).toLowerCase());
            temp.setAoiNameBg(AddrUtil.transferNumber(temp.getAoiNameBg()).toLowerCase());
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("std & ts, unmatch final count - {}", rddStdUnmatchFinal.count());
        rddStdUnmatch.unpersist();

        DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_std_shunt", Addr4Ho.class, rddStdMatch.union(rddStdUnmatchFinal), "city_code");
        rddStdUnmatch.unpersist();
        rddStdMatch.unpersist();
    }
}
