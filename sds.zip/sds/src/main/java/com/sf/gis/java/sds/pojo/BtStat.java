package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BtStat implements Serializable {
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "zc")
    private String zc;
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "aoi_type")
    private String aoiType;
    @Column(name = "aoi_pu_cnt")
    private String aoiPuCnt;
    @Column(name = "aoi_dlv_cnt")
    private String aoiDlvCnt;
    @Column(name = "inc_day")
    private String incDay;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getAoiType() {
        return aoiType;
    }

    public void setAoiType(String aoiType) {
        this.aoiType = aoiType;
    }

    public String getAoiPuCnt() {
        return aoiPuCnt;
    }

    public void setAoiPuCnt(String aoiPuCnt) {
        this.aoiPuCnt = aoiPuCnt;
    }

    public String getAoiDlvCnt() {
        return aoiDlvCnt;
    }

    public void setAoiDlvCnt(String aoiDlvCnt) {
        this.aoiDlvCnt = aoiDlvCnt;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "BtStat{" +
                "cityCode='" + cityCode + '\'' +
                ", zc='" + zc + '\'' +
                ", aoi='" + aoi + '\'' +
                ", aoiType='" + aoiType + '\'' +
                ", aoiPuCnt='" + aoiPuCnt + '\'' +
                ", aoiDlvCnt='" + aoiDlvCnt + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
