package com.sf.gis.java.sds.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateUtil {

    /**
     * 返回当前时间戳差值的分钟值
     * @param tm1
     * @param tm2
     * @return
     */
    public static long getCurrentMinDiff(long tm1,long tm2){
        long res = (tm2 - tm1) / (1000 * 60);
        return res > 1440 || res < 0 ? -1 : res ;
    }


    /**
     * 返回当前时间yymmdd格式，减多少天
     * @param date
     * @param diff
     * @return
     */
    public static String getCurrentDayDiff(String date, int diff) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date dt = sdf.parse( date );
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(dt);
        rightNow.add( Calendar.DATE, diff );
        Date dateTmp = rightNow.getTime();
        String currentDate = sdf.format(dateTmp);

        return currentDate ;
    }


    /**
     * 返回当前时间yymmdd格式，减多少天
     * @param month
     * @param diff
     * @return
     */
    public static String getCurrentMonthDiff(String month, int diff) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        Date dt = sdf.parse( month );
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(dt);
        rightNow.add( Calendar.MONTH, diff );
        Date monthTmp = rightNow.getTime();
        String currentMonth = sdf.format(monthTmp);

        return currentMonth ;
    }

    public static void main(String[] args) throws ParseException {
        System.out.println( getCurrentMonthDiff("202103", -7) );
    }
}
