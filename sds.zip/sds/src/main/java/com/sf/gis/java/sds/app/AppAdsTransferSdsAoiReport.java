package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.graph.aoi.common.util.KeyWordUtil;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 任务id：827916（【乡村达】履约运营小哥事后反馈审核）
 * 业务方：01422529（刘桓）
 * 研发：01399581（匡仁衡）
 */

public class AppAdsTransferSdsAoiReport {
    private static Logger logger = LoggerFactory.getLogger(AppAdsTransferSdsAoiReport.class);
    private static String split_url = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=3eb300d2e06947f7945cd02530a32fd2";
    private static String getOgcNearestAoi_url = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getOgcNearestAoi?ogcFid=%s";
    private static String getNearVillages_url = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/getNearVillages?guid=%s";
    private static String gdpoi_url = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s";
    private static String getaoibyxy_url = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=3eb300d2e06947f7945cd02530a32fd2&x=%s&y=%s&opt=aoi&geom=0";
    private static String getcooraoi_url = "http://10.119.72.206:8086/data/aoiSdk/getCoorAoi";
    private static String atp_url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=e9106d80834e483189c3439938bac5d2&opt=zh&showserver=true";
    private static int limitMinGd = 1000 / 10;
    private static String taskId = "827916";
    private static String taskName = "履约运营小哥事后反馈审核";
    private static String account = "01399581";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAdsTransferSdsAoiReport");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String gis_ads_transfer_sds_aoi_report_sql = String.format("select\n" +
                "  a.*,\n" +
                "  b.aoi_name aoi_name,\n" +
                "  c.aoi_name aoi_id_remark_name,\n" +
                "  c.aoi_id new_aoi_id_remark,\n" +
                "  d.dept_type_code dept_type_code\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "        get_json_object(data,'$.createTime') create_time,\n" +
                "        get_json_object(data,'$.ak') ak,\n" +
                "        get_json_object(data,'$.remoteIp') remote_ip,\n" +
                "        get_json_object(data,'$.url') url,\n" +
                "        get_json_object(data,'$.order_id') order_id,\n" +
                "        get_json_object(data,'$.address') address,\n" +
                "        get_json_object(data,'$.zno_code') zno_code,\n" +
                "        get_json_object(data,'$.city_code') city_code,\n" +
                "        get_json_object(data,'$.staff_id') staff_id,\n" +
                "        get_json_object(data,'$.opt_date') opt_date,\n" +
                "        get_json_object(data,'$.update_date') update_date,\n" +
                "        get_json_object(data,'$.cd_flag') cd_flag,\n" +
                "        get_json_object(data,'$.address_check') address_check,\n" +
                "        get_json_object(data,'$.aoi_area_code') aoi_area_code,\n" +
                "        get_json_object(data,'$.aoi_area_code_chk') aoi_area_code_chk,\n" +
                "        get_json_object(data,'$.aoi_area_code_remark') aoi_area_code_remark,\n" +
                "        get_json_object(data,'$.aoi_id') aoi_id,\n" +
                "        get_json_object(data,'$.aoi_id_check') aoi_id_check,\n" +
                "        get_json_object(data,'$.aoi_id_remark') aoi_id_remark,\n" +
                "        get_json_object(data,'$.aoi_type') aoi_type,\n" +
                "        get_json_object(data,'$.aoi_type_check') aoi_type_check,\n" +
                "        get_json_object(data,'$.aoi_type_remark') aoi_type_remark,\n" +
                "        get_json_object(data,'$.waybill_date') waybill_date,\n" +
                "        inc_day\n" +
                "    from\n" +
                "      dm_gis.gis_ads_transfer_sds_aoi_report\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and (get_json_object(data,'$.aoi_id_remark') is not null and get_json_object(data,'$.aoi_id_remark') <>'')\n" +
                "  ) a left join (\n" +
                "      select aoi_id,aoi_code,aoi_name from dm_gis.cms_aoi where inc_day = '%s'\n" +
                "  ) b on a.aoi_id = b.aoi_id\n" +
                "  left join (\n" +
                "      select aoi_id,aoi_code,aoi_name from dm_gis.cms_aoi where inc_day = '%s'\n" +
                "  ) c on a.aoi_id_remark = if(length(a.aoi_id_remark)=32,c.aoi_id,c.aoi_code)\n" +
                "  join (\n" +
                "      select dept_code,dept_type_code from dim.dim_dept_info_df where inc_day = '%s' and dept_type_code = 'DB05-DLD' group by dept_code,dept_type_code\n" +
                "  ) d on a.zno_code = d.dept_code", date, date, date, date);
        JavaRDD<AdsTransferSdsAoiReport> rdd = DataUtil.loadData(spark, sc, gis_ads_transfer_sds_aoi_report_sql, AdsTransferSdsAoiReport.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, atp_url, "e9106d80834e483189c3439938bac5d2", rdd.count(), 2);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, split_url, "3eb300d2e06947f7945cd02530a32fd2", rdd.count(), 2);
        JavaRDD<AdsTransferSdsAoiReport> gisaoisrcRdd = rdd.repartition(2).map(o -> {
            String address = o.getAddress();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(atp_url, URLEncoder.encode(address, "UTF-8"), city_code);
                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                String gisaoisrc = "";
                String standardization = "";
                String splitresult = "";

                try {
                    gisaoisrc = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("atAoiSrc");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    standardization = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("standardization");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    splitresult = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                o.setGisaoisrc(gisaoisrc);
                o.setStandardization(standardization);
                o.setSplitresult(StringUtils.isNotEmpty(splitresult) ? splitresult.split(";")[0] : "");
            }
            return o;
        }).map(o -> {
            String splitresult = o.getSplitresult();
            if (StringUtils.isEmpty(splitresult)) {
                String address = o.getAddress();
                String city_code = o.getCity_code();
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(split_url, URLEncoder.encode(address, "UTF-8"), city_code);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    try {
                        String split = getSplit(content);
                        o.setSplitresult(split);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisaoisrcRdd cnt:{}", gisaoisrcRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);


        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, split_url, "3eb300d2e06947f7945cd02530a32fd2", gisaoisrcRdd.count(), 2);
        JavaRDD<AdsTransferSdsAoiReport> applyAddr13Rdd = gisaoisrcRdd.map(o -> {
            String gisaoisrc = o.getGisaoisrc();
            if (StringUtils.equals(gisaoisrc, "norm")) {
                String standardization = o.getStandardization();
                String city_code = o.getCity_code();
                if (StringUtils.isNotEmpty(standardization)) {
                    String req = String.format(split_url, URLEncoder.encode(standardization, "UTF-8"), city_code);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    String standardization_split = getSplit(content);
                    o = process_apply_addr13(standardization_split, o);
                }
            } else {
                String splitresult = o.getSplitresult();
                if (StringUtils.isNotEmpty(splitresult)) {
                    o = process_apply_addr13(splitresult, o);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("applyAddr13Rdd cnt:{}", applyAddr13Rdd.count());
        gisaoisrcRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        JavaRDD<AdsTransferSdsAoiReport> simRdd = applyAddr13Rdd.map(o -> {
            String aoi_name = o.getAoi_name();
            String origin_aoi13 = processAoiName(aoi_name);
            o.setOrigin_aoi13(origin_aoi13);

            String aoi_id_remark_name = o.getAoi_id_remark_name();
            String submit_aoiname = processAoiName(aoi_id_remark_name);
            o.setSubmit_aoiname(submit_aoiname);

            String apply_addr13 = o.getApply_addr13();
            if (StringUtils.isNotEmpty(apply_addr13)) {

                if (StringUtils.isNotEmpty(origin_aoi13)) {
                    double sim_text_ori = KeyWordUtil.similarity(apply_addr13, origin_aoi13);
                    double sim_pinyin_ori = KeyWordUtil.similarity(apply_addr13, origin_aoi13);
                    o.setSim_text_ori(sim_text_ori + "");
                    o.setSim_pinyin_ori(sim_pinyin_ori + "");
                }

                if (StringUtils.isNotEmpty(submit_aoiname)) {
                    double sim_text_sub = KeyWordUtil.similarity(apply_addr13, submit_aoiname);
                    double sim_pinyin_sub = KeyWordUtil.similarity(apply_addr13, submit_aoiname);
                    o.setSim_text_sub(sim_text_sub + "");
                    o.setSim_pinyin_sub(sim_pinyin_sub + "");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("simRdd cnt:{}", simRdd.count());
        applyAddr13Rdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> tagRdd = simRdd.map(o -> {
            double sim_text_ori = StringUtils.isNotEmpty(o.getSim_text_ori()) ? Double.parseDouble(o.getSim_text_ori()) : 0;
            double sim_pinyin_ori = StringUtils.isNotEmpty(o.getSim_pinyin_ori()) ? Double.parseDouble(o.getSim_pinyin_ori()) : 0;
            double sim_text_sub = StringUtils.isNotEmpty(o.getSim_text_sub()) ? Double.parseDouble(o.getSim_text_sub()) : 0;
            double sim_pinyin_sub = StringUtils.isNotEmpty(o.getSim_pinyin_sub()) ? Double.parseDouble(o.getSim_pinyin_sub()) : 0;

            String result = "";
            String tag = "";
            String aoiid_apply = "";
            String aoiid_tag = "";

            String apply_addr13 = o.getApply_addr13();
            String origin_aoi13 = o.getOrigin_aoi13();
            String submit_aoiname = o.getSubmit_aoiname();

            if (sim_text_ori >= 1) {
                result = "驳回";
                tag = "origin_sim";
                aoiid_apply = o.getAoi_id();
                aoiid_tag = "origin";
            } else if (StringUtils.isNotEmpty(apply_addr13) && StringUtils.isNotEmpty(origin_aoi13) && (apply_addr13.contains(origin_aoi13) || origin_aoi13.contains(apply_addr13))) {
                result = "驳回";
                tag = "origin_include";
                aoiid_apply = o.getAoi_id();
                aoiid_tag = "origin";
            } else if (sim_text_sub >= 1) {
                result = "通过";
                tag = "submit_sim";
                aoiid_apply = o.getNew_aoi_id_remark();
                aoiid_tag = "submit";
            } else if (StringUtils.isNotEmpty(apply_addr13) && StringUtils.isNotEmpty(submit_aoiname) && (apply_addr13.contains(submit_aoiname) || submit_aoiname.contains(apply_addr13))) {
                result = "通过";
                tag = "submit_include";
                aoiid_apply = o.getNew_aoi_id_remark();
                aoiid_tag = "submit";
            }

            o.setResult(result);
            o.setTag(tag);
            o.setAoiid_apply(aoiid_apply);
            o.setAoiid_tag(aoiid_tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:{}", tagRdd.count());
        simRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> empTagRdd = tagRdd.filter(o -> StringUtils.isEmpty(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> noEmpTagRdd = tagRdd.filter(o -> StringUtils.isNotEmpty(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empTagRdd cnt:{}, noEmpTagRdd cnt:{}", empTagRdd.count(), noEmpTagRdd.count());
        tagRdd.unpersist();

        String beforeDate = DateUtil.getDaysBefore(date, 3);
        String emap_district_village_aoi_sql = String.format("select aoi_id new_aoi_id_remark,guid submit_village_id,name submit_village_name from dm_gis.emap_district_village_aoi where inc_day = '%s' and (aoi_id is not null and aoi_id <>'')", beforeDate);
        JavaPairRDD<String, AdsTransferSdsAoiReport> districtVillageRdd = DataUtil.loadData(spark, sc, emap_district_village_aoi_sql, AdsTransferSdsAoiReport.class).mapToPair(o -> new Tuple2<>(o.getNew_aoi_id_remark(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("districtVillageRdd cnt:{}", districtVillageRdd.count());

        JavaRDD<AdsTransferSdsAoiReport> villageRdd = empTagRdd.mapToPair(o -> new Tuple2<>(o.getNew_aoi_id_remark(), o)).leftOuterJoin(districtVillageRdd).map(tp -> {
            AdsTransferSdsAoiReport o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                AdsTransferSdsAoiReport adsTransferSdsAoiReport = tp._2._2.get();
                o.setSubmit_village_id(adsTransferSdsAoiReport.getSubmit_village_id());
                o.setSubmit_village_name(adsTransferSdsAoiReport.getSubmit_village_name());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("villageRdd cnt:{}", villageRdd.count());
        empTagRdd.unpersist();
        districtVillageRdd.unpersist();

        String xzc_filter_sql = "select * from dm_gis.xzc_filter";
        JavaRDD<XzcVillage> xzcRdd = DataUtil.loadData(spark, sc, xzc_filter_sql, XzcVillage.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xzcVillageRdd cnt:{}", xzcRdd.count());

        JavaRDD<AdsTransferSdsAoiReport> simVillageRdd = villageRdd.mapToPair(o -> new Tuple2<>(o.getSubmit_village_id(), o)).leftOuterJoin(xzcRdd.mapToPair(o -> new Tuple2<>(o.getGuid_v(), o)).groupByKey()).map(tp -> {
            AdsTransferSdsAoiReport o = tp._2._1;
            String apply_addr13 = o.getApply_addr13();
            if (StringUtils.isNotEmpty(apply_addr13) && tp._2._2 != null && tp._2._2.isPresent()) {
                List<XzcVillage> list = Lists.newArrayList(tp._2._2().get());

                List<XzcVillage> sim_list = list.stream().peek(t -> {
                    String name = t.getName();
                    double sim_text = KeyWordUtil.similarity(apply_addr13, name);
                    double sim_pinyin = KeyWordUtil.similarity(apply_addr13, name);
                    t.setSim_text(sim_text);
                    t.setSim_pinyin(sim_pinyin);
                }).collect(Collectors.toList());

                JSONObject navillagetextsim_dict = new JSONObject();
                JSONObject navillagetextsim_max = new JSONObject();

                JSONObject navillagepinyinsim_dict = new JSONObject();
                JSONObject navillagepinyinsim_max = new JSONObject();
                sim_list.forEach(t -> {
                    String ogc_fid = t.getOgc_fid();
                    String name = t.getName();
                    double sim_text = t.getSim_text();
                    double sim_pinyin = t.getSim_pinyin();

                    navillagetextsim_dict.put(ogc_fid + "_" + name, sim_text);
                    navillagepinyinsim_dict.put(ogc_fid + "_" + name, sim_pinyin);
                });

                XzcVillage xzcVillage_text = sim_list.stream().sorted((o1, o2) -> Double.compare(o2.getSim_text(), o1.getSim_text())).collect(Collectors.toList()).get(0);
                o.setSim_text_max(xzcVillage_text.getSim_text());
                navillagetextsim_max.put(xzcVillage_text.getOgc_fid(), xzcVillage_text.getSim_text());

                XzcVillage xzcVillage_pinyin = sim_list.stream().sorted((o1, o2) -> Double.compare(o2.getSim_pinyin(), o1.getSim_pinyin())).collect(Collectors.toList()).get(0);
                o.setSim_pinyin_max(xzcVillage_pinyin.getSim_pinyin());
                navillagepinyinsim_max.put(xzcVillage_pinyin.getOgc_fid(), xzcVillage_pinyin.getSim_pinyin());

                o.setNavillagetextsim_dict(navillagetextsim_dict.toJSONString());
                o.setNavillagepinyinsim_dict(navillagepinyinsim_dict.toJSONString());
                o.setNavillagetextsim_max(navillagetextsim_max.toJSONString());
                o.setNavillagepinyinsim_max(navillagepinyinsim_max.toJSONString());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("simVillageRdd cnt:{}", simVillageRdd.count());
        villageRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> ogcNearestAoiRdd = simVillageRdd.filter(o -> (o.getSim_text_max() >= 1) || (o.getSim_text_max() < 1 && o.getSim_pinyin_max() >= 1)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> noOgcNearestAoiRdd = simVillageRdd.filter(o -> !((o.getSim_text_max() >= 1) || (o.getSim_text_max() < 1 && o.getSim_pinyin_max() >= 1))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ogcNearestAoiRdd cnt:{}", ogcNearestAoiRdd.count());
        logger.error("noOgcNearestAoiRdd cnt:{}", noOgcNearestAoiRdd.count());
        simVillageRdd.unpersist();

        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, getOgcNearestAoi_url, "", ogcNearestAoiRdd.count(), 10);
        //获取指定自然村aoi和网点
        JavaRDD<AdsTransferSdsAoiReport> villageIdRdd = ogcNearestAoiRdd.map(o -> {
            double sim_text_max = o.getSim_text_max();
            String navillagesim_max = "";
            String ogc_fid = "";
            if (sim_text_max >= 1) {
                navillagesim_max = o.getNavillagetextsim_max();
            } else {
                navillagesim_max = o.getNavillagepinyinsim_max();
            }
            if (StringUtils.isNotEmpty(navillagesim_max)) {
                JSONObject jsonObject = JSON.parseObject(navillagesim_max);
                for (Map.Entry<String, Object> stringObjectEntry : jsonObject.entrySet()) {
                    ogc_fid = stringObjectEntry.getKey();
                }
            }

            if (StringUtils.isNotEmpty(ogc_fid)) {
                String req = String.format(getOgcNearestAoi_url, ogc_fid);
                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                o.setOgcnearestaoi_resp(content);
                String aoiId = "";
                String name = "";
                String znoCode = "";

                try {
                    aoiId = JSON.parseObject(content).getJSONObject("data").getString("aoiId");
                    name = JSON.parseObject(content).getJSONObject("data").getString("name");
                    znoCode = JSON.parseObject(content).getJSONObject("data").getString("znoCode");
                } catch (Exception e) {
//                    e.printStackTrace();
                }

                o.setSubmitvillage_aoiid(aoiId);
                o.setSubmitvillage_aoiname(name);
                o.setSubmitvillage_znocode(znoCode);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("villageIdRdd cnt:{}", villageIdRdd.count());
        ogcNearestAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id4);

        JavaRDD<AdsTransferSdsAoiReport> empSubmitvillageAoiidRdd = villageIdRdd.filter(o -> StringUtils.isEmpty(o.getSubmitvillage_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> noEmpSubmitvillageAoiidRdd = villageIdRdd.filter(o -> StringUtils.isNotEmpty(o.getSubmitvillage_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empSubmitvillageAoiidRdd cnt:{}", empSubmitvillageAoiidRdd.count());
        logger.error("noEmpSubmitvillageAoiidRdd cnt:{}", noEmpSubmitvillageAoiidRdd.count());
        villageIdRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> submitVillageAoiidTagRdd = noEmpSubmitvillageAoiidRdd.map(o -> {
            String result = "";
            String tag = "";
            String aoiid_apply = "";
            String aoiid_tag = "";

            String submitvillage_aoiid = o.getSubmitvillage_aoiid();
            String aoi_id_remark = o.getNew_aoi_id_remark();
            if (StringUtils.equals(submitvillage_aoiid, aoi_id_remark)) {
                result = "通过";
                tag = "submitVillage_aoiidTrue";
                aoiid_apply = aoi_id_remark;
                aoiid_tag = "submitVillage_aoiid";
            } else {
                result = "驳回";
                tag = "submitVillage_aoiidFalse";
                aoiid_apply = submitvillage_aoiid;
                aoiid_tag = "submitVillage_aoiid";
            }
            o.setResult(result);
            o.setTag(tag);
            o.setAoiid_apply(aoiid_apply);
            o.setAoiid_tag(aoiid_tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("submitVillageAoiidTagRdd cnt:{}", submitVillageAoiidTagRdd.count());
        noEmpSubmitvillageAoiidRdd.unpersist();

        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, getNearVillages_url, "", empSubmitvillageAoiidRdd.count() + noOgcNearestAoiRdd.count(), 10);
        //获取行政村附近的行政村
        JavaRDD<AdsTransferSdsAoiReport> nearGuidRdd = empSubmitvillageAoiidRdd.union(noOgcNearestAoiRdd).flatMap(o -> {
            ArrayList<AdsTransferSdsAoiReport> list = new ArrayList<>();
            String submit_village_id = o.getSubmit_village_id();
            if (StringUtils.isNotEmpty(submit_village_id)) {
                String req = String.format(getNearVillages_url, submit_village_id);
                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);

                try {
                    JSONArray jsonArray = JSON.parseObject(content).getJSONObject("data").getJSONArray("list");
                    for (int i = 0; i < jsonArray.size(); i++) {
                        AdsTransferSdsAoiReport adsTransferSdsAoiReport = new AdsTransferSdsAoiReport();
                        BeanUtils.copyProperties(adsTransferSdsAoiReport, o);
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String guid = jsonObject.getString("guid");
                        adsTransferSdsAoiReport.setNear_guid(guid);
                        list.add(adsTransferSdsAoiReport);
                    }
                } catch (Exception e) {
                    list.add(o);
                }

            } else {
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("nearGuidRdd cnt:{}", nearGuidRdd.count());
        empSubmitvillageAoiidRdd.unpersist();
        noOgcNearestAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id5);

        //计算与相邻行政村的所有自然村的相似度
        JavaRDD<AdsTransferSdsAoiReport> conti_navillageSimRdd = nearGuidRdd.mapToPair(o -> new Tuple2<>(o.getNear_guid(), o)).leftOuterJoin(xzcRdd.mapToPair(o -> new Tuple2<>(o.getGuid_v(), o)).groupByKey()).map(tp -> {
            AdsTransferSdsAoiReport o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<XzcVillage> list = Lists.newArrayList(tp._2._2.get());
                o.setList(list);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getCreate_time() + "_" + o.getOrder_id() + "_" + o.getWaybill_date(), o)).groupByKey().map(tp -> {
            List<AdsTransferSdsAoiReport> list = Lists.newArrayList(tp._2);
            AdsTransferSdsAoiReport o = list.get(0);
            List<String> collect = list.stream().filter(t -> StringUtils.isNotEmpty(t.getNear_guid())).map(AdsTransferSdsAoiReport::getNear_guid).distinct().collect(Collectors.toList());
            o.setConti_navlillag(collect.size() > 0 ? String.join(",", collect) : "");

            List<XzcVillage> allList = new ArrayList<>();
            for (AdsTransferSdsAoiReport adsTransferSdsAoiReport : list) {
                List<XzcVillage> xzcVillageList = adsTransferSdsAoiReport.getList();
                if (xzcVillageList != null && xzcVillageList.size() > 0) {
                    allList.addAll(xzcVillageList);
                }
            }

            String apply_addr13 = o.getApply_addr13();
            if (StringUtils.isNotEmpty(apply_addr13) && allList.size() > 0) {
                List<XzcVillage> simTextList = allList.stream().peek(t -> {
                    String name = t.getName();
                    double similarity = KeyWordUtil.similarity(apply_addr13, name);
                    t.setSim_text(similarity);
                }).collect(Collectors.toList());

                o.setList(simTextList);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("conti_navillageSimRdd cnt:{}", conti_navillageSimRdd.count());
        nearGuidRdd.unpersist();
        xzcRdd.unpersist();

//        JavaRDD<AdsTransferSdsAoiReport> lg1Conti_navillageSimRdd = conti_navillageSimRdd.filter(o -> o.getList() != null && o.getList().size() > 0 && o.getList().stream().filter(t -> t.getSim_text() >= 1).count() > 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<AdsTransferSdsAoiReport> lt1Conti_navillageSimRdd = conti_navillageSimRdd.filter(o -> !(o.getList() != null && o.getList().size() > 0 && o.getList().stream().filter(t -> t.getSim_text() >= 1).count() > 1)).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("lg1Conti_navillageSimRdd cnt:{}", lg1Conti_navillageSimRdd.count());
//        logger.error("lt1Conti_navillageSimRdd cnt:{}", lt1Conti_navillageSimRdd.count());
//        conti_navillageSimRdd.unpersist();
//
//        JavaRDD<AdsTransferSdsAoiReport> checkRdd1 = lg1Conti_navillageSimRdd.map(o -> {
//            o.setResult("流入审核");
//            o.setTag("多个自然村相似");
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("checkRdd1 cnt:{}", checkRdd1.count());
//        lg1Conti_navillageSimRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> lg0Conti_navillageSimRdd = conti_navillageSimRdd.filter(o -> o.getList() != null && o.getList().size() > 0 && o.getList().stream().filter(t -> t.getSim_text() >= 1).count() > 0).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> lt0Conti_navillageSimRdd = conti_navillageSimRdd.filter(o -> !(o.getList() != null && o.getList().size() > 0 && o.getList().stream().filter(t -> t.getSim_text() >= 1).count() > 0)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lg0Conti_navillageSimRdd cnt:{}", lg0Conti_navillageSimRdd.count());
        logger.error("lt0Conti_navillageSimRdd cnt:{}", lt0Conti_navillageSimRdd.count());
        conti_navillageSimRdd.unpersist();

        String id6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, getOgcNearestAoi_url, "", lg0Conti_navillageSimRdd.count(), 10);
        JavaRDD<AdsTransferSdsAoiReport> contivillage_aoiidRdd = lg0Conti_navillageSimRdd.map(o -> {
            String ogc_fid = o.getList().stream().filter(t -> t.getSim_text() >= 1).sorted(Comparator.comparing(XzcVillage::getSim_text, Comparator.reverseOrder())).collect(Collectors.toList()).get(0).getOgc_fid();
            if (StringUtils.isNotEmpty(ogc_fid)) {
                String req = String.format(getOgcNearestAoi_url, ogc_fid);
                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                o.setOgcnearestaoi_resp(content);
                String aoiId = "";
                try {
                    aoiId = JSON.parseObject(content).getJSONObject("data").getString("aoiId");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setContivillage_aoiid(aoiId);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("contivillage_aoiidRdd cnt:{}", contivillage_aoiidRdd.count());
        lg0Conti_navillageSimRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id6);

        JavaRDD<AdsTransferSdsAoiReport> noEmpContivillage_aoiidRdd = contivillage_aoiidRdd.filter(o -> StringUtils.isNotEmpty(o.getContivillage_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> empContivillage_aoiidRdd = contivillage_aoiidRdd.filter(o -> StringUtils.isEmpty(o.getContivillage_aoiid())).map(o -> {
            o.setConti_navillagesim_return("0");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpContivillage_aoiidRdd cnt:{}", noEmpContivillage_aoiidRdd.count());
        logger.error("empContivillage_aoiidRdd cnt:{}", empContivillage_aoiidRdd.count());
        contivillage_aoiidRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> noEmpContivillage_aoiidTagRdd = noEmpContivillage_aoiidRdd.map(o -> {
            o.setConti_navillagesim_return("1");
            o.setResult("驳回");
            o.setTag("contiVillage_aoiidFalse");
            o.setAoiid_apply(o.getContivillage_aoiid());
            o.setAoiid_tag("contiVillage_aoiid");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpContivillage_aoiidTagRdd cnt:{}", noEmpContivillage_aoiidTagRdd.count());
        noEmpContivillage_aoiidRdd.unpersist();

        String id7 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, gdpoi_url, "87106f6380af4df0845a693eee58843c", empContivillage_aoiidRdd.count() + lt0Conti_navillageSimRdd.count(), 10);
        //获取高德结果
        JavaRDD<AdsTransferSdsAoiReport> gdResultRdd = getGdResult(empContivillage_aoiidRdd.union(lt0Conti_navillageSimRdd));
        empContivillage_aoiidRdd.unpersist();
        lt0Conti_navillageSimRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id7);


        JavaRDD<AdsTransferSdsAoiReport> containsRdd = gdResultRdd.filter(AppAdsTransferSdsAoiReport::containsJudge).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AdsTransferSdsAoiReport> noContainsRdd = gdResultRdd.filter(o -> !containsJudge(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("containsRdd cnt:{}", containsRdd.count());
        logger.error("noContainsRdd cnt:{}", noContainsRdd.count());
        gdResultRdd.unpersist();

        JavaRDD<AdsTransferSdsAoiReport> checkRdd2 = noContainsRdd.map(o -> {
            o.setAmappois("0");
            o.setResult("流入审核");
            o.setTag("高德无覆盖");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd2 cnt:{}", checkRdd2.count());
        noContainsRdd.unpersist();

        String id8 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, getaoibyxy_url, "3eb300d2e06947f7945cd02530a32fd2", containsRdd.count(), 10);
        JavaRDD<AdsTransferSdsAoiReport> containsLastRdd = containsRdd.map(o -> {
            o.setAmappois("1");
            String apply_addr13 = o.getApply_addr13();
            String aoi_id_remark = o.getNew_aoi_id_remark();
            List<GdPoi> list = o.getGd_list().stream().filter(t -> (StringUtils.isNotEmpty(t.getGd_address()) && t.getGd_address().contains(apply_addr13)) || (StringUtils.isNotEmpty(t.getGd_name()) && t.getGd_name().contains(apply_addr13))).filter(t -> StringUtils.isNotEmpty(t.getLocation())).collect(Collectors.toList());
            if (list.size() > 0) {
                String location = list.get(0).getLocation();
                if (StringUtils.isNotEmpty(location)) {
                    String[] split = location.split(",");
                    String x = split[0];
                    String y = split[1];
                    String req = String.format(getaoibyxy_url, x, y);

                    String content = HttpInvokeUtil.sendGet(req);
                    String aoi = "";

                    try {
                        aoi = JSON.parseObject(content).getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id");
                    } catch (Exception e) {
//                    e.printStackTrace();
                    }

                    if (StringUtils.isNotEmpty(aoi)) {
                        o.setGd_return("1");
                        o.setGd_aoiid(aoi);

                        if (StringUtils.equals(aoi, aoi_id_remark)) {
                            o.setResult("通过");
                            o.setTag("gd_aoiidTrue");
                            o.setAoiid_apply(aoi);
                            o.setAoiid_tag("gd_aoiid");
                        } else {
                            o.setResult("驳回");
                            o.setTag("gd_aoiidFalse");
                            o.setAoiid_apply(aoi);
                            o.setAoiid_tag("gd_aoiid");
                        }
                    } else {
                        o.setGd_return("0");
                        JSONArray jsonArray = new JSONArray();
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("lng", x);
                        jsonObject.put("lat", y);
                        jsonArray.add(jsonObject);

                        String rs = HttpInvokeUtil.sendPost(getcooraoi_url, jsonArray.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);

                        try {
                            aoi = JSON.parseObject(rs).getJSONArray("data").getJSONObject(0).getString("aoiId");
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        if (StringUtils.isNotEmpty(aoi)) {
                            o.setTwokm_gd_return("1");
                            o.setTwokm_gd_aoiid(aoi);
                            if (StringUtils.equals(aoi, aoi_id_remark)) {
                                o.setResult("通过");
                                o.setTag("twokm_gd_aoiidTrue");
                                o.setAoiid_apply(aoi);
                                o.setAoiid_tag("twokm_gd_aoiid");
                            } else {
                                o.setResult("驳回");
                                o.setTag("twokm_gd_aoiidFalse");
                                o.setAoiid_apply(aoi);
                                o.setAoiid_tag("twokm_gd_aoiid");
                            }
                        } else {
                            o.setTwokm_gd_return("0");
                            o.setResult("AOI缺失");
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("containsLastRdd cnt:{}", containsLastRdd.count());
        containsRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id8);

        JavaRDD<AdsTransferSdsAoiReport> lastRdd = containsLastRdd.union(noEmpTagRdd).union(submitVillageAoiidTagRdd).union(noEmpContivillage_aoiidTagRdd).union(checkRdd2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        containsLastRdd.unpersist();
        noEmpTagRdd.unpersist();
        submitVillageAoiidTagRdd.unpersist();
        noEmpContivillage_aoiidTagRdd.unpersist();
        checkRdd2.unpersist();

        spark.sql(String.format("alter table dm_gis.xcd_performance_xiaoge_afterwards_feedback_check drop if EXISTS partition(inc_day='%s')", date));
        DataUtil.saveOverwrite(spark, sc, "dm_gis.xcd_performance_xiaoge_afterwards_feedback_check", AdsTransferSdsAoiReport.class, lastRdd, "inc_day");
        sc.stop();
    }

    private static boolean containsJudge(AdsTransferSdsAoiReport o) {
        boolean flag = false;
        String apply_addr13 = o.getApply_addr13();
        List<GdPoi> gd_list = o.getGd_list();
        if (StringUtils.isNotEmpty(apply_addr13) && gd_list != null && gd_list.size() > 0) {
            for (GdPoi gdPoi : gd_list) {
                String gd_address = gdPoi.getGd_address();
                String gd_name = gdPoi.getGd_name();
                if ((StringUtils.isNotEmpty(gd_address) && gd_address.contains(apply_addr13)) || (StringUtils.isNotEmpty(gd_name) && gd_name.contains(apply_addr13))) {
                    return true;
                }
            }
        }
        return flag;
    }

    private static JavaRDD<AdsTransferSdsAoiReport> getGdResult(JavaRDD<AdsTransferSdsAoiReport> rdd) {
        JavaRDD<AdsTransferSdsAoiReport> gdResultRdd = rdd.repartition(20).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<AdsTransferSdsAoiReport> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMinGd) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMinGd, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                AdsTransferSdsAoiReport o = itr.next();
                String gisaoisrc = o.getGisaoisrc();
                String standardization = "";
                if (StringUtils.equals(gisaoisrc, "norm")) {
                    standardization = o.getStandardization();
                } else {
                    standardization = o.getAddress();
                }
                if (StringUtils.isNotEmpty(standardization)) {
                    String req = String.format(gdpoi_url, URLEncoder.encode(standardization, "UTF-8"));
                    o = processGdPoi(req, o);
                    Thread.sleep(100);
                }
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdResultRdd cnt:{}", gdResultRdd.count());
        return gdResultRdd;
    }

    public static AdsTransferSdsAoiReport processGdPoi(String req, AdsTransferSdsAoiReport o) {
        List<GdPoi> list = new ArrayList<>();
        String content = getJsonByGet(req);
        o.setGd_result(content);
        if (StringUtils.isNotEmpty(content)) {
            JSONObject jsonObject = null;
            try {
                jsonObject = JSON.parseObject(content);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                JSONObject result = jsonObject.getJSONObject("result");
                if (result != null) {
                    JSONArray pois = result.getJSONArray("pois");
                    if (pois != null && pois.size() > 0) {
                        logger.error("pois size:{}", pois.size());
                        int length = Math.min(pois.size(), 10);
                        for (int i = 0; i < length; i++) {
                            JSONObject jsonObject1 = pois.getJSONObject(i);
                            if (jsonObject1 != null) {
                                GdPoi gdPoi = new GdPoi();
                                String location = jsonObject1.getString("location");
                                String name = jsonObject1.getString("name");
                                String address = jsonObject1.getString("address");
                                gdPoi.setLocation(location);
                                gdPoi.setGd_name(name);
                                gdPoi.setGd_address(address);
                                list.add(gdPoi);
                            }
                        }
                    }
                }
            }
        }
        o.setGd_list(list);
        return o;
    }

    public static String getJsonByGet(String url) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        String stringEntity = "";
        try {
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader("ak", "87106f6380af4df0845a693eee58843c");
            CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                HttpEntity httpEntity = httpResponse.getEntity();
                try {
                    stringEntity = EntityUtils.toString(httpEntity, "UTF-8");
                } catch (Exception e) {
                    logger.error(">>>获取stringEntity异常：" + e);
                }
            }
            httpResponse.close();
            httpClient.close();
        } catch (Exception e) {
            logger.error(">>>获取httpResponse异常：" + e);
        }
        return stringEntity;
    }


    private static String processAoiName(String aoi_name) {
        String rs = "";
        if (StringUtils.isNotEmpty(aoi_name)) {
            rs = aoi_name.replaceAll("[村|行政村|社区|村民委员会|居民委员会|居委会]$", "");
        }
        return rs;
    }


    private static AdsTransferSdsAoiReport process_apply_addr13(String split_info, AdsTransferSdsAoiReport o) {
        StringBuilder apply_addr13 = new StringBuilder();
        if (StringUtils.isNotEmpty(split_info)) {
            String[] split = split_info.split(",");
            for (String s : split) {
                String[] split1 = s.split("\\^");
                if (split1.length >= 2) {
                    String word = split1[0];
                    String level = split1[1];
                    String before = level.substring(0, 1);
                    String after = level.substring(1, level.length());
                    if ((!StringUtils.equals(level, "613") && StringUtils.equals(after, "13")) || (StringUtils.equals(after, "6"))) {
                        apply_addr13.append(word);
                    }
                }
            }
        }
        o.setApply_addr13(processAoiName(apply_addr13.toString()));
        return o;
    }

    private static String getSplit(String content) {
        String rs = "";
        if (StringUtils.isNotEmpty(content)) {
            JSONObject jsonObject = JSON.parseObject(content);
            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                JSONObject result = jsonObject.getJSONObject("result");
                if (result != null) {
                    JSONObject data = result.getJSONObject("data");
                    if (data != null) {
                        ArrayList<String> list = new ArrayList<>();
                        JSONArray info = data.getJSONArray("info");
                        if (info != null && info.size() > 0) {
                            for (int i = 0; i < info.size(); i++) {
                                JSONObject jsonObject1 = info.getJSONObject(i);
                                Integer level = jsonObject1.getInteger("level");
                                String name = jsonObject1.getString("name");
                                String prop = jsonObject1.getString("prop");
                                list.add(name + "^" + prop + level);
                            }
                        }
                        rs = list.size() > 0 ? String.join(",", list) : "";
                    }
                }
            }
        }
        return rs;
    }
}
