package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.GisDistrict;
import com.sf.gis.java.sds.pojo.TbOrder;
import com.sf.gis.java.sds.utils.AesEncryptUtil;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.Map;
import java.util.stream.Collectors;

public class SwCityMatchSceneController {
    private static Logger logger = LoggerFactory.getLogger(SwCityMatchSceneController.class);
    private static String url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=9c1d529c40f54877a9a6372e686fee47&address=%s&city=%s&opt=zh&company=";
    private static String account = "01399581";
    private static String taskId = "712312";
    private static String taskName = "特殊入仓城配场景数据跑数";

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Map<String, String> map = loadCityNameMap(spark, sc, date).collect().stream().collect(Collectors.toMap(GisDistrict::getCity_name, GisDistrict::getCity, (key1, key2) -> key2));
        Broadcast<Map<String, String>> mapBc = sc.broadcast(map);

        JavaRDD<TbOrder> rdd = loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<TbOrder> cityRdd = rdd.map(o -> {
            Map<String, String> value = mapBc.value();

            String place = o.getPlace();
            if (StringUtils.isNotEmpty(place)) {
                o.setPlace_citycode(value.get(place));
            }

            String destination_city = o.getDestination_city();
            if (StringUtils.isNotEmpty(destination_city)) {
                o.setDestination_citycode(value.get(destination_city));
            }

            String move_in_address = o.getMove_in_address();
            if (StringUtils.isNotEmpty(move_in_address)) {
                o.setMove_in_address_new(AesEncryptUtil.desEncrypt(move_in_address));
            }

            String move_out_address = o.getMove_out_address();
            if (StringUtils.isNotEmpty(move_out_address)) {
                o.setMove_out_address_new(AesEncryptUtil.desEncrypt(move_out_address));
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityRdd cnt:{}", cityRdd.count());
        cityRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        rdd.unpersist();

        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, "9c1d529c40f54877a9a6372e686fee47", cityRdd.count(), 10);
        JavaRDD<TbOrder> resultRdd = cityRdd.map(o -> {
            String move_in_address_new = o.getMove_in_address_new();
            String destination_citycode = o.getDestination_citycode();
            if (StringUtils.isNotEmpty(move_in_address_new)) {
                String req = String.format(url, URLEncoder.encode(move_in_address_new, "UTF-8"), destination_citycode);
                String content = UrlUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                String aoi = "";
                try {
                    aoi = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                o.setMove_in_address_aoi(aoi);
            }

            String move_out_address_new = o.getMove_out_address_new();
            String place_citycode = o.getPlace_citycode();
            if (StringUtils.isNotEmpty(move_out_address_new)) {
                String req = String.format(url, URLEncoder.encode(move_out_address_new, "UTF-8"), place_citycode);
                String content = UrlUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                String aoi = "";
                try {
                    aoi = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                o.setMove_out_address_aoi(aoi);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        cityRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        DataUtil.saveOverwrite(spark, sc, "dm_gis.fop_uftl_tb_order", TbOrder.class, resultRdd, "inc_day");
        resultRdd.unpersist();
    }

    public JavaRDD<GisDistrict> loadCityNameMap(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select city_name,city from dm_gis.gis_district where inc_day = '%s' group by city_name,city", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, GisDistrict.class);
    }

    public JavaRDD<TbOrder> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select\n" +
                "  cast(order_category as string) order_category,\n" +
                "  order_no,\n" +
                "  order_time,\n" +
                "  move_in_address,\n" +
                "  move_out_address,\n" +
                "  cast(total_fee as string) as total_fee,\n" +
                "  cast(actual_mileage_fee as string) as actual_mileage_fee,\n" +
                "  cast(actual_order_payment as string) as actual_order_payment,\n" +
                "  place,\n" +
                "  month_settlement_card,\n" +
                "  company_name,\n" +
                "  year,\n" +
                "  cast(vas_total as string) as vas_total,\n" +
                "  destination_city,\n" +
                "  cast(total_weight as string) as total_weight,\n" +
                "  cast(total_num as string) as total_num,\n" +
                "  customer_name,\n" +
                "  business_city,\n" +
                "  inc_day\n" +
                "from\n" +
                "  dm_gis.ods_fop_uftl_tb_order\n" +
                "where\n" +
                "  inc_day = '%s'", date);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TbOrder.class);
    }
}
