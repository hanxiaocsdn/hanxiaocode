package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.github.davidmoten.geo.GeoHash;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.svc.ZcService;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.Fcg;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;

/**
 * 丰巢柜数据挖掘（最优AOI串）
 * @author 01370539 Created On: Mar.10 2022
 */
public class FcgAnalysisController {
    private static final Logger logger = LoggerFactory.getLogger(FcgAnalysisController.class);

    private final ZcService zcService = new ZcService();

    public void process(String cityCode, String fileUrl, String incDay, int disUl, int wbCntDl, int wbCntUl, int aoiCntUl) {
        logger.error("process start. cityCode - {}, fileUrl - {}, indDay - {}, disUl, wbCntDl, wbCntUl, aoiCntUl", cityCode, fileUrl, incDay, disUl, wbCntDl, wbCntUl, aoiCntUl);
        // 初始化spark
        SparkInfo si = SparkUtil.getSpark4File(this.getClass().getSimpleName());

        // 获取初始化数据
        JavaRDD<Fcg> rddInit = DataUtil.loadFile(si, fileUrl, FixedConstant.CHARSET_UTF, Fcg.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("init data count: {}", rddInit.count());

        SparkUtil.setCfgSplit(si);

        Set<String> incDaySet = rddInit.mapToPair(tmp -> new Tuple2<>(tmp.getIncDay(), 1)).reduceByKey((a, b) -> a).collectAsMap().keySet();
        String incDayStr = "";
        for (String ids : incDaySet) {
            incDayStr += "'" + ids + "',";
        }
        incDayStr = incDayStr.substring(0, incDayStr.length() - 1);
        logger.error("incDayStr ------ {}", incDayStr);

        JavaRDD<Fcg> rddFcgCnt = getAoiFcgCnt(si, incDayStr).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("获取到的fcg数据：{}", rddFcgCnt.count());
        rddFcgCnt.take(3).forEach(o -> logger.error(">>>>>>>>>>>>> {}", o.toString()));

        JavaRDD<Fcg> rddInitCnt = rddInit.mapToPair(tmp -> new Tuple2<>(tmp.getAoiId() + "_" + tmp.getIncDay(), tmp)).groupByKey().leftOuterJoin(rddFcgCnt.mapToPair(tmp -> new Tuple2<>(tmp.getAoiId() + "_" + tmp.getIncDay(), tmp)).groupByKey()).flatMap(tmp -> {
            List<Fcg> rsList = Lists.newArrayList(tmp._2._1);
            if (tmp._2._2.isPresent()) {
                String fcgCnt = Lists.newArrayList(tmp._2._2.get()).get(0).getFcgCnt();
                rsList.forEach(o -> o.setFcgCnt(fcgCnt));
            }
            return rsList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("填充丰巢柜数量后初始化数据的数量为：{}", rddInitCnt.count());
        rddFcgCnt.unpersist();
        rddInit.unpersist();

        // 数据过滤
        JavaRDD<Fcg> rddFcg = rddInitCnt.filter(tmp -> StringUtils.isNotEmpty(tmp.getDeptCode()) && StringUtils.isNotEmpty(tmp.getDeptCenterX()) && StringUtils.isNotEmpty(tmp.getAoiAreaCode()) && StringUtils.isNotEmpty(tmp.getAoiAreaNear()) & StringUtils.isNotEmpty(tmp.getAoiCenterX()) && StringUtils.isNotEmpty(tmp.getTotalCount()) && Integer.parseInt(tmp.getTotalCount()) > 0 && StringUtils.isNotEmpty(tmp.getmCount()) && Integer.parseInt(tmp.getmCount()) >= 10 && StringUtils.isNotEmpty(tmp.getFcgCnt())).map(tmp -> {
            String key = GeoHash.encodeHash(Double.parseDouble(tmp.getAoiCenterY()), Double.parseDouble(tmp.getAoiCenterX()), 5);
            tmp.setKey(key);
            return tmp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("data count after filter: {}", rddFcg.count());
        rddFcg.take(3).forEach(tmp -> logger.error("tmp -------> {}", tmp.toString()));
        rddInit.unpersist();



        // 对数据进行分组（按照数据时间，城市编码，网点，和AOI区域进行分组）
        JavaPairRDD<String, Iterable<Fcg>> rddTpFcg = rddFcg.mapToPair(o -> new Tuple2<>(o.getIncDay() + "_" + o.getCityCode() + "_" + o.getDeptCode() + "_" + o.getAoiAreaCode(), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("按照AOI区域分组，分组数量: {}", rddTpFcg.count());
        rddTpFcg.take(3).forEach(o -> logger.error("{} -------> {}", o._1, Lists.newArrayList(o._2).size()));
        rddFcg.unpersist();
        logger.error("按照aoi区域分组后，aoi数量大于{}个的分组： {}", aoiCntUl, rddTpFcg.filter(o -> Lists.newArrayList(o._2).size() > aoiCntUl).count());

        JavaRDD<Fcg> rddSameAoiArea = rddTpFcg.flatMap(o -> {
            List<Fcg> fcgList = Lists.newArrayList(o._2);
            Map<String, List<Fcg>> fcgMap = new HashMap<>();
            Map<String, Fcg> rsMap = new HashMap<>();
            fcgList.sort((a, b) -> Integer.valueOf(b.getTotalCount()).compareTo(Integer.valueOf(a.getTotalCount())));
            return processAoiSeq(o._1, fcgList, disUl, wbCntDl, wbCntUl, aoiCntUl).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("after check the same area aoi. rddSameAoiArea count: {}", rddSameAoiArea.count());
        rddSameAoiArea.take(3).forEach(o -> logger.error("o  ----->  {}", o.toString()));
        logger.error("after check the same area aoi. have tag count: {}", rddSameAoiArea.filter(o -> StringUtils.isNotEmpty(o.getTag())).count());
        rddTpFcg.unpersist();

        rddTpFcg = rddSameAoiArea.mapToPair(o -> new Tuple2<>(o.getIncDay() + "_" + o.getCityCode() + "_" + o.getDeptCode() + "_" + o.getKey(), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("按照geoHash分组后分组数量: {}", rddTpFcg.count());
        rddTpFcg.take(3).forEach(o -> logger.error("{} -------> {}", o._1, Lists.newArrayList(o._2).size()));
        rddFcg.unpersist();
        logger.error("按照aoi区域分组后，aoi数量大于{}个的分组： {}", aoiCntUl, rddTpFcg.filter(o -> Lists.newArrayList(o._2).size() > aoiCntUl).count());

        JavaRDD<Fcg> rddResult = rddTpFcg.flatMap(o -> {
            List<Fcg> fcgList = Lists.newArrayList(o._2);

            List<Fcg> unTagList = getAoiData(fcgList, false);
            List<Fcg> rsList = null;
            int curIndex = 0;
            int LastIndex = unTagList.size();
            while (curIndex < LastIndex) {
                rsList = processUnsameAreaAoi(o._1, unTagList, curIndex, disUl, wbCntDl, wbCntUl, aoiCntUl);
                if (rsList.size() == 0) {
                    curIndex++;
                } else {
                    for (Fcg rs : rsList) {
                        for (Fcg fcg : fcgList) {
                            if (StringUtils.isEmpty(fcg.getTag()) && fcg.getAoiId().equals(rs.getAoiId())) {
                                fcg.setTag(rs.getTag());
                                break;
                            }
                        }
                    }
                    unTagList = getAoiData(fcgList, false);
                    curIndex = 0;
                    LastIndex = unTagList.size();
                }
            }

            fcgList.forEach(tmp -> {
                tmp.setDeptCenterY("");
                tmp.setDeptCenterX("");
                tmp.setAoiCenterY("");
                tmp.setAoiCenterX("");
            });

            return fcgList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("after check aoi area near. rddResult count: {}", rddResult.count());
        rddResult.take(3).forEach(o -> logger.error("o  ----->  {}", o.toString()));
        logger.error("after check the same area aoi. have tag count: {}", rddResult.filter(o -> StringUtils.isNotEmpty(o.getTag())).count());
        rddTpFcg.unpersist();

        DataUtil.saveOverwrite(si, "dm_gis.fcg_rs", Fcg.class, rddResult, "inc_day");

        logger.error("process end. ");
    }

    private JavaRDD<Fcg> getAoiFcgCnt(SparkInfo si, String incDay) {
        String sql = "select aoi_id, count(aoi_id) fcg_cnt, inc_day from dm_gis.dim_hive_cabinet_info_df_aoi_info where inc_day in (" + incDay + ") and aoi_id != '' and aoi_id is not null group by aoi_id, inc_day";
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, Fcg.class);
    }

    // 获取没有被选中的数据
    private static List<Fcg> getAoiData(List<Fcg> fcgList, boolean isTag) {
        List<Fcg> rsList = new ArrayList<>();
        for (Fcg fcg : fcgList) {
            if (isTag) {
                if (StringUtils.isNotEmpty(fcg.getTag())) {
                    rsList.add(fcg);
                }
            } else {
                if (StringUtils.isEmpty(fcg.getTag())) {
                    rsList.add(fcg);
                }
            }
        }
        return rsList;
    }

    // 没有被选中的数据先以运单量倒序，选择运单量最大的aoi附近的单进行聚合，判断是否可以组成AOI串
    private static List<Fcg> processUnsameAreaAoi(String prefix, List<Fcg> fcgList, int index, int disUl, int wbCntDl, int wbCntUl, int aoiCntUl) {
        fcgList.sort((a, b) -> Integer.valueOf(b.getTotalCount()).compareTo(Integer.valueOf(a.getTotalCount())));
        Fcg fcg = fcgList.get(index);
        List<Fcg> tmpList = new ArrayList<>();
        tmpList.add(fcg);
        for (Fcg tmp : fcgList) {
            if (!fcg.getAoiId().equals(tmp.getAoiId()) && fcg.getAoiAreaNear().contains(tmp.getAoiAreaCode())) {
                tmpList.add(tmp);
            }
        }
        return getAoiData(processAoiSeq(prefix, tmpList, disUl, wbCntDl, wbCntUl, aoiCntUl), true);
    }

    private static List<Fcg> processAoiSeq(String prefix, List<Fcg> fcgList, int disUl, int wbCntDl, int wbCntUl, int aoiCntUl) {
        logger.error("prefix - {}, fcgList count - {}, disUl - {}, wbCntDl - {}, wbCntUl - {}, aoiCntUl - {}", prefix, fcgList.size(), disUl, wbCntDl, wbCntUl, aoiCntUl);
        for (Fcg fcg : fcgList) {
            logger.error("prefix - {}, fcg - {}", prefix, fcg.toString());
        }

        Map<String, List<Fcg>> aoiSeqMap = new HashMap<>();    // 形成的AOI串Map
        List<Fcg> tmpList = new ArrayList<>();   // 临时存储可成为同一组的AOI

        int wbTtlCount = 0;  // 当前累计的aoi运单数量总和
        int lastWbTtlCount = 0;    // 截止到上一个aoi累计的运单数量总和

        double fnlDis = 0;   // 当前累计的aoi运单距离总和
        double lastFnlDis = 0;    // 截止到上一个aoi累计的距离总和
        double curDis = 0;   // 当前AOI串的当前距离累计
        double tmpDis = 0;     // 临时计算距离

        Fcg lastFcg = null;     // 上一个aoi数据详细信息
        String tag = null;    // aoi串的tag

        for (Fcg fcg : fcgList) {
            if (tmpList.size() == 0) {
                logger.error("1, prefix - {}", prefix);
                wbTtlCount = 0;
                lastWbTtlCount = 0;

                fnlDis = 0;
                lastFnlDis = 0;
                curDis = 0;
                tmpDis = 0;

                lastFcg = null;
            }

            logger.error("2, prefix - {}, aoiSeq count - {}, curAoiSeq aoi count - {}, wbTtlCount - {}, lastWbTtlCount - {}, fnlDis - {}, lastFnlDis - {}, curDis - {}", prefix, aoiSeqMap.size(), tmpList.size(), wbTtlCount, lastWbTtlCount, fnlDis, lastFnlDis, curDis);
            if (tmpList.size() < aoiCntUl) {
                wbTtlCount += Integer.parseInt(fcg.getTotalCount());
                if (tmpList.size() == 0) {
                    tmpDis = GeometryUtil.getDistance(GeometryUtil.createPoint(fcg.getDeptCenterX(), fcg.getDeptCenterY()), GeometryUtil.createPoint(fcg.getAoiCenterX(), fcg.getAoiCenterY()));
                } else {
                    tmpDis = GeometryUtil.getDistance(GeometryUtil.createPoint(lastFcg.getAoiCenterX(), lastFcg.getAoiCenterY()), GeometryUtil.createPoint(fcg.getAoiCenterX(), fcg.getAoiCenterY()));
                }
                curDis += tmpDis;

                fnlDis = curDis + GeometryUtil.getDistance(GeometryUtil.createPoint(fcg.getDeptCenterX(), fcg.getDeptCenterY()), GeometryUtil.createPoint(fcg.getAoiCenterX(), fcg.getAoiCenterY()));

                logger.error("3: prefix - {}, curAoi - {}, wbTtlCount - {}, tmpDis - {}, curDis - {}, fnlDis - {}", prefix, fcg.getAoiId(), wbTtlCount, tmpDis, curDis, fnlDis);
                if (wbTtlCount <= wbCntUl && fnlDis <= disUl) {
                    tmpList.add(fcg);
                    lastWbTtlCount = wbTtlCount;
                    lastFnlDis = fnlDis;
                    lastFcg = fcg;
                    logger.error("4: add aoi, prefix - {}, aoiid - {}, lastWbTtlCount - {}, lastFnlDis - {}", prefix, fcg.getAoiId(), lastWbTtlCount, lastFnlDis);
                } else {
                    if (lastWbTtlCount >= wbCntDl && lastWbTtlCount <= wbCntUl && lastFnlDis <= disUl) {
                        tag = prefix + "_" + aoiSeqMap.size() + "_" + tmpList.size() + "_" + lastWbTtlCount + "_" + lastFnlDis;
                        aoiSeqMap.put(tag, new ArrayList<>(tmpList));
                        logger.error("5: 第{}组AOI串生成， prefix - {}, tag - {} ", aoiSeqMap.size(), prefix, tag);
                        tmpList.clear();

                        wbTtlCount = 0;
                        lastWbTtlCount = 0;
                        fnlDis = 0;
                        lastFnlDis = 0;
                        curDis = 0;
                        tmpDis = 0;
                        lastFcg = null;
                        logger.error("6, prefix - {}, aoiSeq count - {}, curAoiSeq aoi count - {}, wbTtlCount - {}, lastWbTtlCount - {}, fnlDis - {}, lastFnlDis - {}, curDis - {}", prefix, aoiSeqMap.size(), tmpList.size(), wbTtlCount, lastWbTtlCount, fnlDis, lastFnlDis, curDis);

                        wbTtlCount += Integer.parseInt(fcg.getTotalCount());
                        tmpDis = GeometryUtil.getDistance(GeometryUtil.createPoint(fcg.getDeptCenterX(), fcg.getDeptCenterY()), GeometryUtil.createPoint(fcg.getAoiCenterX(), fcg.getAoiCenterY()));
                        curDis += tmpDis;
                        fnlDis = curDis + tmpDis;
                        logger.error("7: prefix - {}, curAoi - {}, wbTtlCount - {}, tmpDis - {}, curDis - {}, fnlDis - {}", prefix, fcg.getAoiId(), wbTtlCount, tmpDis, curDis, fnlDis);
                        if (wbTtlCount <= wbCntUl && fnlDis <= disUl) {
                            tmpList.add(fcg);
                            lastWbTtlCount = wbTtlCount;
                            lastFnlDis = fnlDis;
                            lastFcg = fcg;
                            logger.error("8: add aoi, prefix - {}, aoiid - {}, lastWbTtlCount - {}, lastFnlDis - {}", prefix, fcg.getAoiId(), lastWbTtlCount, lastFnlDis);
                        } else {
                            logger.error("9: curAoi not match, prefix - {}, aoiid - {}, wbTtlCount - {}, tmpDis - {}, curDis - {}, fnlDis - {}", prefix, fcg.getAoiId(), wbTtlCount, tmpDis, curDis, fnlDis);
                            continue;
                        }
                    } else {
                        logger.error("10: curAoiSeq not match, prefix - {}, aoiCount - {}, lastWbTtlCount - {}, lastFnlDis - {}", prefix, fcg.getAoiId(), lastWbTtlCount, lastFnlDis);
                        continue;
                    }
                }
            } else {
                if (wbTtlCount >= wbCntDl && wbTtlCount <= wbCntUl && fnlDis <= disUl) {
                    tag = prefix + "_" + aoiSeqMap.size() + "_" + tmpList.size() + "_" + lastWbTtlCount + "_" + lastFnlDis;
                    aoiSeqMap.put(prefix + "_" + wbTtlCount + "_" + fnlDis, new ArrayList<>(tmpList));
                    logger.error("11: 第{}组AOI串生成， prefix - {}, tag - {} ", aoiSeqMap.size(), prefix, tag);
                } else {
                    logger.error("12: end check， prefix - {}, curAoi - {} ", prefix, fcg.getAoiId());
                }
                tmpList.clear();
            }
        }
        logger.error("13: start set tag for each aoiSeq");
        for (String key : aoiSeqMap.keySet()) {
            for (Fcg aoiSeq : aoiSeqMap.get(key)) {
                for (Fcg tempFcg : fcgList) {
                    if (tempFcg.getAoiId().equals(aoiSeq.getAoiId())) {
                        tempFcg.setTag(key);
                    }
                }
            }
        }
        return fcgList;
    }

}
