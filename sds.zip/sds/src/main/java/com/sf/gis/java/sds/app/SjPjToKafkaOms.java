package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SjPjToKafkaOmsController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SjPjToKafkaOms {
    private static Logger logger = LoggerFactory.getLogger(SjPjToKafkaOms.class);

    public static void main(String[] args) {
        String date = args[0];
        String citycodes_sp = args[1];
        String citycodes_report = args[2];
        logger.error("date:{}", date);
        logger.error("citycodes_sp:{},citycodes_report:{}", citycodes_sp, citycodes_report);
        logger.error("run start");
        new SjPjToKafkaOmsController().start(date, citycodes_sp, citycodes_report);
        logger.error("run end");
    }
}
