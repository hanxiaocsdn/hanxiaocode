package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class In45WaybillIndex implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "stat_type")
    private String stat_type;
    @Column(name = "stat_type_content")
    private String stat_type_content;
    @Column(name = "stat_date")
    private String stat_date;
    @Column(name = "region")
    private String region;
    @Column(name = "citycode")
    private String cityCode;
    @Column(name = "city")
    private String city;
    @Column(name = "tag")
    private String tag;

    @Column(name = "gis_cnt")
    private String gis_cnt;
    @Column(name = "distinguish_cnt")
    private String distinguish_cnt;
    @Column(name = "fee_cnt")
    private String fee_cnt;
    @Column(name = "climb_cnt")
    private String climb_cnt;
    @Column(name = "climb_fee_cnt")
    private String climb_fee_cnt;
    @Column(name = "no_elevator_cnt")
    private String no_elevator_cnt;
    @Column(name = "no_elevator_fee_cnt")
    private String no_elevator_fee_cnt;
    @Column(name = "no_climb_cnt")
    private String no_climb_cnt;
    @Column(name = "no_climb_fee_cnt")
    private String no_climb_fee_cnt;
    @Column(name = "no_distinguish_cnt")
    private String no_distinguish_cnt;
    @Column(name = "no_distinguish_fee_cnt")
    private String no_distinguish_fee_cnt;
    @Column(name = "inc_day")
    private String inc_day;

    private String requesttype;

    public String getRequesttype() {
        return requesttype;
    }

    public void setRequesttype(String requesttype) {
        this.requesttype = requesttype;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getStat_date() {
        return stat_date;
    }

    public void setStat_date(String stat_date) {
        this.stat_date = stat_date;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getGis_cnt() {
        return gis_cnt;
    }

    public void setGis_cnt(String gis_cnt) {
        this.gis_cnt = gis_cnt;
    }

    public String getDistinguish_cnt() {
        return distinguish_cnt;
    }

    public void setDistinguish_cnt(String distinguish_cnt) {
        this.distinguish_cnt = distinguish_cnt;
    }

    public String getFee_cnt() {
        return fee_cnt;
    }

    public void setFee_cnt(String fee_cnt) {
        this.fee_cnt = fee_cnt;
    }

    public String getClimb_cnt() {
        return climb_cnt;
    }

    public void setClimb_cnt(String climb_cnt) {
        this.climb_cnt = climb_cnt;
    }

    public String getClimb_fee_cnt() {
        return climb_fee_cnt;
    }

    public void setClimb_fee_cnt(String climb_fee_cnt) {
        this.climb_fee_cnt = climb_fee_cnt;
    }

    public String getNo_elevator_cnt() {
        return no_elevator_cnt;
    }

    public void setNo_elevator_cnt(String no_elevator_cnt) {
        this.no_elevator_cnt = no_elevator_cnt;
    }

    public String getNo_elevator_fee_cnt() {
        return no_elevator_fee_cnt;
    }

    public void setNo_elevator_fee_cnt(String no_elevator_fee_cnt) {
        this.no_elevator_fee_cnt = no_elevator_fee_cnt;
    }

    public String getNo_climb_cnt() {
        return no_climb_cnt;
    }

    public void setNo_climb_cnt(String no_climb_cnt) {
        this.no_climb_cnt = no_climb_cnt;
    }

    public String getNo_climb_fee_cnt() {
        return no_climb_fee_cnt;
    }

    public void setNo_climb_fee_cnt(String no_climb_fee_cnt) {
        this.no_climb_fee_cnt = no_climb_fee_cnt;
    }

    public String getNo_distinguish_cnt() {
        return no_distinguish_cnt;
    }

    public void setNo_distinguish_cnt(String no_distinguish_cnt) {
        this.no_distinguish_cnt = no_distinguish_cnt;
    }

    public String getNo_distinguish_fee_cnt() {
        return no_distinguish_fee_cnt;
    }

    public void setNo_distinguish_fee_cnt(String no_distinguish_fee_cnt) {
        this.no_distinguish_fee_cnt = no_distinguish_fee_cnt;
    }
}
