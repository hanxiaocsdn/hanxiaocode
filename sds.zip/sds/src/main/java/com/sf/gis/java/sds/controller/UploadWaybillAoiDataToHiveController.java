package com.sf.gis.java.sds.controller;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.enumtype.MapType;
import com.sf.gis.java.sds.pojo.AoiHook;
import com.sf.gis.java.sds.service.ProDbService;
import com.sf.gis.java.sds.service.RdsStaDbService;
import com.sf.gis.java.sds.service.UploadWaybillAoiDataToHiveService;
import com.sf.gis.scala.base.util.HttpClientUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;


public class UploadWaybillAoiDataToHiveController {
    private UploadWaybillAoiDataToHiveService service;
    private Map<String, String> configMap;
    private static final Logger logger = LoggerFactory.getLogger(UploadWaybillAoiDataToHiveController.class);

    public UploadWaybillAoiDataToHiveController(Map<String, String> configMap) {
        service = new UploadWaybillAoiDataToHiveService();
        this.configMap = configMap;
    }

    public void start() throws Exception {
        ProDbService proDbService = new ProDbService();
        String aoiOrderTask = configMap.get(ConfigKey.aoi_order_task.name());
        String cityCodes = configMap.get(ConfigKey.openCity.name()).replaceAll(",", "','");
        String flag = configMap.get(ConfigKey.flag.name());
        String fileName = proDbService.findWaybillAoiToHiveRecordFileName(aoiOrderTask, flag);
        if (fileName != null) {
            proDbService.deleteWaybillAoiToHiveRecordFileName(fileName);
            String[] fileInfo = service.pushToHive(configMap, fileName);
            // 统计最新的挂接信息
            List<AoiHook> hookRsltCalInfo = service.calHookInfo(fileInfo[0], fileInfo[1], cityCodes);
            RdsStaDbService rdsService = new RdsStaDbService();
            rdsService.insertBatch(hookRsltCalInfo);
            String checkDate = DateUtil.getCurrentDateBefore("yyyyMMdd", 2);
            // 派件为t-1,此处需要修改了...20220423,还未修改,暂时不发邮件,下次改动一并修改
            if (checkDate.equals(fileInfo[0])) {
                logger.error("比对前一天的数据指标");
                String yesterDay = DateUtil.getDayBefore(fileInfo[0], "yyyyMMdd", 1);
                compareWithLastDay(rdsService, hookRsltCalInfo, yesterDay, fileInfo[1]);
            }

        } else {
            logger.error("没有需要入库的文件~");
        }
    }

    private void compareWithLastDay(RdsStaDbService rdsService, List<AoiHook> hookRsltCalInfo,
                                    String yesterday, String mapType) {
        logger.error("当前获取城市维度指标");
        List<AoiHook> curCityData = hookRsltCalInfo.stream()
                .filter(obj -> "CITY".equals(obj.getStatType())).collect(Collectors.toList());
        logger.error("获取昨天城市维度指标");
        List<AoiHook> yesterdayData = rdsService.selectRcg(yesterday, "CITY", mapType.equals(MapType.pai.name()) ? "DLV" : "PU");
        Map<String, String> badRcgMap = new HashMap<>();
        Set<String> moreCitySet = new HashSet<>();
        Set<String> lessCitySet = new HashSet<>();
        for (AoiHook todayItem : curCityData) {
            String cityCode = todayItem.getCityCode();
            double hookRateToday = (double) Math.round(todayItem.getWbHook() * 1.0 / todayItem.getWbCount() * 10000) / 10000;
            boolean exist = false;
            for (AoiHook yesterdayItem : yesterdayData) {
                if (cityCode.equals(yesterdayItem.getCityCode())) {
                    double hookRateYestoday = (double) Math.round(yesterdayItem.getWbHook() * 1.0 / yesterdayItem.getWbCount() * 10000) / 10000;
                    if ((hookRateToday + 0.05) < hookRateYestoday) {
                        badRcgMap.put(cityCode, hookRateToday + "_" + hookRateYestoday);
                    }
                    exist = true;
                    break;
                }
            }
            if (!exist) {
                moreCitySet.add(cityCode);
            }
        }
        for (AoiHook yesterdayItem : yesterdayData) {
            String cityCode = yesterdayItem.getCityCode();

            boolean exist = false;
            for (AoiHook todayItem : curCityData) {
                if (cityCode.equals(todayItem.getCityCode())) {
                    exist = true;
                    break;
                }
            }
            if (!exist) {
                lessCitySet.add(cityCode);
            }
        }
        if (!badRcgMap.isEmpty() || !moreCitySet.isEmpty() || !lessCitySet.isEmpty()) {
            logger.error("存在异常");
        } else {
            logger.error("无异常");
        }
        StringBuilder badRcgSb = new StringBuilder();
        for (Map.Entry<String, String> entry : badRcgMap.entrySet()) {
            if (badRcgSb.length() != 0) {
                badRcgSb.append(",");
            }
            badRcgSb.append(entry.getKey() + "_" + entry.getValue());

        }
        String warningUrl = "http://10.119.72.205:8083/buildByToken/buildWithParameters?job=报警_aoi智域历史件量还原"
                + "&token=74b4ae32780f8ab5e9b383945be09d51&dataType=%s&badRcg=%s&lessRcg=%s&moreRcg=%s";
        logger.error(warningUrl);
        String finalUrl = String.format(warningUrl, mapType, badRcgSb.toString(), lessCitySet.stream()
                .collect(Collectors.joining("_")), moreCitySet.stream()
                .collect(Collectors.joining("_")));
        HttpClientUtil.getStrByGet(finalUrl,"UTF-8");
    }

    public static void main(String[] args) {
        List<String> tmp = new ArrayList<String>();
        tmp.add("dd");
        tmp.add("xx");
        List<String> curCityData = tmp.stream()
                .filter(obj -> "dd".equals(obj)).collect(Collectors.toList());
        System.out.println(curCityData.get(0));
    }
}