package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.GeometryUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.FcDlv;
import com.sf.gis.java.sds.pojo.LbsLctCtrl;
import com.sf.gis.java.sds.service.LbsLctCtrlService;
import com.sf.shiva.oms.csm.utils.FwExpressUtils;
import com.sf.shiva.oms.csm.utils.NsCfgUtils;
import com.sf.shiva.oms.csm.utils.SJUtils;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import jodd.util.StringUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.datanucleus.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;
import com.sf.gis.java.base.util.AesUtil;

import java.util.*;

/**
 * lbs定位管控重构（需求：刘雨婷）
 * @author 01370539
 * 2022年7月20日
 */
public class LbsLctCtrlController {
    private static final Logger logger = LoggerFactory.getLogger(LbsLctCtrlController.class);

    private static final LbsLctCtrlService llcSvc = new LbsLctCtrlService();

    public void process(String incDays, String isFromRs) {
        SparkInfo si = SparkUtil.getSpark4File(LbsLctCtrlController.class.getName());
        si.getSession().sql("set mapred.min.split.size.per.node = 2000000");
        si.getSession().sql("set mapred.min.split.size.per.rack = 2000000");
        JavaRDD<FcDlv> rddCnyz = DataUtil.loadFile(si, "/user/01370539/upload/cnyz.csv", "GBK", FcDlv.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("------------ 菜鸟驿站信息数据量：{} ------------", rddCnyz.count());
        logger.error("------------ 菜鸟驿站有AOI信息的数据量：{} ------------", rddCnyz.filter(o -> org.apache.commons.lang.StringUtils.isNotEmpty(o.getAoiId())).count());
        rddCnyz.filter(o -> org.apache.commons.lang.StringUtils.isNotEmpty(o.getAoiId())).take(3).forEach(o -> logger.error("菜鸟驿站数据详细信息：{}", o.toString()));
        SparkUtil.setCfgSplit(si);

        String[] incDayArr = incDays.split(",");
        for (String incDay : incDayArr) {
            logger.error("------------------------ 开始处理数据日期：{} ------------------------", incDay);
            JavaRDD<LbsLctCtrl> rddFistStep;
            if ("true".equals(isFromRs)) {
                rddFistStep = llcSvc.loadRs(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 补充巴枪扫描信息后运单的数据量：{} ------------", rddFistStep.count());
                rddFistStep.take(3).forEach(o -> logger.error("补充巴枪扫描信息后运单详细信息：{}", o.toString()));
                logger.error("补充巴枪扫描信息后运单的巴枪扫描时间为空的数据量：{} ------------", rddFistStep.filter(o -> StringUtils.isEmpty(o.getBarscantm())).count());
            } else {
                JavaRDD<LbsLctCtrl> rddWbh = llcSvc.loadWbHook(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 运单数据量：{} ------------", rddWbh.count());
                rddWbh.take(3).forEach(o -> logger.error("运单详细信息：{}", o.toString()));

                JavaRDD<LbsLctCtrl> rddWbDlvBatch = rddWbh.mapToPair(o -> new Tuple2<>(o.getCouriercode() + "_" + o.getConsigneePhone() + "_" + o.getIncDay(), o)).groupByKey().flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2);
                    if (wbs.size() >= 100) {
                        wbs.forEach(wb -> wb.setIsDlvBatch("Y"));
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 计算是否集派场景后运单数据量：{} ------------", rddWbDlvBatch.count());
                rddWbDlvBatch.filter(o -> StringUtil.isNotEmpty(o.getIsDlvBatch())).take(3).forEach(o -> logger.error("计算是否集派场景后运单数据详细信息：{}", o.toString()));
                rddWbh.unpersist();

                JavaRDD<LbsLctCtrl> rddBox = llcSvc.loadToBox(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 投柜数据量：{} ------------", rddBox.count());
                rddBox.take(3).forEach(o -> logger.error("投柜详细信息：{}", o.toString()));
                JavaRDD<LbsLctCtrl> rddShop = llcSvc.loadToShop(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 投店数据量：{} ------------", rddShop.count());
                rddShop.take(3).forEach(o -> logger.error("投店详细信息：{}", o.toString()));
                JavaRDD<LbsLctCtrl> rddBoxShop = rddBox.union(rddShop).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 投柜和投店总数据量：{} ------------", rddShop.count());
                rddShop.take(3).forEach(o -> logger.error("投柜和投店详细信息：{}", o.toString()));
                rddBox.unpersist();
                rddShop.unpersist();

                List<NsCfgDto> nsCfgList = DbUtil.getNsCfgList();   // 获取号段信息
                logger.error("------------ 丰网双捷号段信息数据量：{} ------------", nsCfgList.size());
                Broadcast<List<NsCfgDto>> nsCfgListBc = si.getContext().broadcast(nsCfgList);

                JavaRDD<LbsLctCtrl> rddWbBoxShop = rddWbDlvBatch.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddBoxShop.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        wbs.forEach(wb -> wb.setIs2box("Y"));
                    }
                    NsCfgUtils.cache(nsCfgListBc.getValue());
                    wbs.forEach(wb -> {
                        if (FwExpressUtils.isWaybillNo(wb.getWaybillNo()) || SJUtils.isWaybillNo(wb.getWaybillNo())) {
                            wb.setIsFwsj("Y");
                        }
                        if (StringUtil.isNotEmpty(wb.getAoiLng()) && StringUtil.isNotEmpty(wb.getDlvLng())) {
                            wb.setDlvAoiCenterDis(GeometryUtil.getDistance(GeometryUtil.createPoint(AesUtil.AESDncode("aoi@aoi", wb.getAoiLng()), AesUtil.AESDncode("aoi@aoi", wb.getAoiLat())), GeometryUtil.createPoint(wb.getDlvLng(), wb.getDlvLat())) + "");
                        }
                        if (StringUtil.isNotEmpty(wb.getAoiId()) && StringUtil.isNotEmpty(wb.getDlvLng())) {
                            wb.setDlvAoiSideDis(AoiApi.getCoorAoiDist(wb.getAoiId(), wb.getDlvLng(), wb.getDlvLat()) + "");
                        }
                    });
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 填充投柜信息后运单数据量：{} ------------", rddWbBoxShop.count());
                rddWbBoxShop.filter(o -> StringUtil.isNotEmpty(o.getIs2box()) || StringUtil.isNotEmpty(o.getIsFwsj())).take(3).forEach(o -> logger.error("填充投柜信息后运单数据详细信息：{}", o.toString()));
                rddWbDlvBatch.unpersist();

                JavaRDD<LbsLctCtrl> rddComplaint = llcSvc.loadComplaint(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 客诉数据量：{} ------------", rddComplaint.count());
                rddComplaint.take(3).forEach(o -> logger.error("客诉详细信息：{}", o.toString()));

                JavaRDD<LbsLctCtrl> rddWbComplaint = rddWbBoxShop.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddComplaint.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        List<LbsLctCtrl> complaints = Lists.newArrayList(o._2._2.get());
                        if (wbs.size() == 1 && complaints.size() == 1) {
                            wbs.get(0).setIsComplaint("Y");
                            wbs.get(0).setComplaint1(complaints.get(0).getComplaint1());
                            wbs.get(0).setComplaint2(complaints.get(0).getComplaint2());
                            wbs.get(0).setComplaint3(complaints.get(0).getComplaint3());
                        }
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 填充客诉信息后运单数据量：{} ------------", rddWbComplaint.count());
                rddWbComplaint.filter(o -> StringUtil.isNotEmpty(o.getIsComplaint())).take(3).forEach(o -> logger.error("填充客诉信息后运单数据详细信息：{}", o.toString()));
                rddWbBoxShop.unpersist();
                rddComplaint.unpersist();

                JavaRDD<LbsLctCtrl> rddEvent = llcSvc.loadEvent(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 事件信息数据量：{} ------------", rddEvent.count());
                rddEvent.take(3).forEach(o -> logger.error("事件详细信息：{}", o.toString()));

                JavaRDD<LbsLctCtrl> rddWbEvent = rddWbComplaint.mapToPair(o -> new Tuple2<>(o.getCouriercode() + "_" + o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddEvent.mapToPair(o -> new Tuple2<>(o.getCouriercode() + "_" + o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        List<LbsLctCtrl> events = Lists.newArrayList(o._2._2.get());
                        for (LbsLctCtrl wb : wbs) {
                            for (LbsLctCtrl event : events) {
                                if ("21510".equals(event.getEventId())) {
                                    wb.setIsCopyPhone("Y");
                                } else if ("21506".equals(event.getEventId())) {
                                    wb.setIsCallClient("Y");
                                }
                            }
                        }
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 填充拨打客户电话信息后运单数据量：{} ------------", rddWbEvent.count());
                rddWbEvent.filter(o -> StringUtil.isNotEmpty(o.getIsCallClient()) || StringUtil.isNotEmpty(o.getIsCopyPhone())).take(3).forEach(o -> logger.error("填充拨打客户电话信息后运单数据详细信息：{}", o.toString()));
                rddWbComplaint.unpersist();
                rddEvent.unpersist();

                JavaRDD<LbsLctCtrl> rddDld = llcSvc.loadDb05Dld(si).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 代理点数据量：{} ------------", rddDld.count());
                rddDld.take(3).forEach(o -> logger.error("代理点详细信息：{}", o.toString()));

                JavaRDD<LbsLctCtrl> rddWbDld = rddWbEvent.mapToPair(o -> new Tuple2<>(o.getDestZoneCode(), o)).groupByKey().leftOuterJoin(rddDld.mapToPair(o -> new Tuple2<>(o.getDestZoneCode(), o)).groupByKey()).flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        wbs.forEach(wb -> wb.setIsDld("Y"));
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 填充代理点信息后运单数据量：{} ------------", rddWbDld.count());
                rddWbDld.filter(o -> StringUtil.isNotEmpty(o.getIsDld())).take(3).forEach(o -> logger.error("填充代理点信息后运单数据详细信息：{}", o.toString()));
                rddWbEvent.unpersist();
                rddDld.unpersist();


                JavaRDD<LbsLctCtrl> rddRout = llcSvc.loadFvpRout(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 路由数据量：{} ------------", rddRout.count());
                rddRout.take(3).forEach(o -> logger.error("路由详细信息：{}", o.toString()));

                rddFistStep = rddWbDld.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddRout.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                    if (wbs.size() == 1) {
                        if (o._2._2.isPresent()) {
                            List<LbsLctCtrl> routes = Lists.newArrayList(o._2._2.get());
                            LbsLctCtrl wb = wbs.get(0);
                            String[] spcArr = wb.getServiceProdCode().split(",");
                            Map<String, Integer> spcMap = new HashMap<>();
                            for (String spc : spcArr) {
                                spcMap.put(spc, 1);
                            }
                            if (spcMap.get("1080") != null || spcMap.get("1081") != null || spcMap.get("21813") != null || spcMap.get("10065") != null || spcMap.get("1052") != null) {
                                wb.setIsToken("Y");
                            }
                            if (wb.getWaybillNo().startsWith("SF111")) {
                                wb.setIsInternal("Y");
                            }
                            for (LbsLctCtrl tmp : routes) {
                                if ("80".equals(tmp.getOpcode())) {
                                    wb.setBarscantm(routes.get(0).getBarscantm());
                                } else if ("130".equals(tmp.getOpcode()) || "125".equals(tmp.getOpcode())) {
                                    wb.setIs2box("Y");
                                } else if ("83".equals(tmp.getOpcode())) {
                                    wb.setIsOperSelf("Y");
                                } else if ("72".equals(tmp.getOpcode())) {
                                    wb.setIsDlvErr("Y");
                                } else if ("67".equals(tmp.getOpcode()) || "82".equals(tmp.getOpcode()) || "99".equals(tmp.getOpcode())) {
                                    wb.setIsRdrctOrBack("Y");
                                }
                            }
                        }
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("------------ 补充巴枪扫描信息后运单数据量：{} ------------", rddFistStep.count());
                rddFistStep.take(3).forEach(o -> logger.error("补充巴枪扫描信息后运单详细信息：{}", o.toString()));
                logger.error("补充巴枪扫描信息后运单的巴枪扫描时间为空的数据量：{} ------------", rddFistStep.filter(o -> StringUtils.isEmpty(o.getBarscantm())).count());
                rddWbDld.unpersist();
                rddRout.unpersist();

                DataUtil.saveOverwrite(si, "dm_gis.lbs_lctctrl_dpp", LbsLctCtrl.class, rddFistStep, "inc_day");
            }

            JavaRDD<LbsLctCtrl> rddWbhCnyz = rddFistStep.mapToPair(o -> new Tuple2<>(o.getAoiId(), o)).groupByKey().leftOuterJoin(rddCnyz.filter(o -> StringUtil.isNotEmpty(o.getAoiId())).mapToPair(o -> new Tuple2<>(o.getAoiId(), o)).groupByKey()).flatMap(o -> {
                List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                if (o._2._2.isPresent()) {
                    List<FcDlv> cnyzList = Lists.newArrayList(o._2._2.get());
                    wbs.forEach(tmp -> tmp.setCnyzList(cnyzList));
                }
                return wbs.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("------------ 挂接菜鸟驿站后运单数据量：{} ------------", rddWbhCnyz.count());
            rddWbhCnyz.filter(o -> o.getCnyzList().size() > 0).take(3).forEach(o -> logger.error("挂接菜鸟驿站后运单数据详细信息：{}", o.toString()));
            rddFistStep.unpersist();
            rddCnyz.unpersist();

            JavaRDD<LbsLctCtrl> rddTrack = llcSvc.loadLocTrack(si, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("------------ 轨迹数据量：{} ------------", rddTrack.count());
            rddTrack.take(3).forEach(o -> logger.error("轨迹详细信息：{}", o.toString()));

            JavaRDD<LbsLctCtrl> rddFinal = rddWbhCnyz.mapToPair(o -> new Tuple2<>(o.getCouriercode(), o)).groupByKey().leftOuterJoin(rddTrack.mapToPair(o -> new Tuple2<>(o.getCouriercode(), o)).groupByKey()).flatMap(o -> {
                List<LbsLctCtrl> wbs = Lists.newArrayList(o._2._1);
                List<LbsLctCtrl> results = new ArrayList<>();
                if (o._2._2.isPresent()) {
                    List<LbsLctCtrl> tracks = Lists.newArrayList(o._2._2().get());
                    logger.error("小哥 {} 运单数据量：{}, 轨迹点数据量：{}", o._1, wbs.size(), tracks.size());
                    // 根据时间对运单数据和轨迹数据排序，以AOI的时间为时间节点照前两分钟的轨迹
                    List<LbsLctCtrl> tmpList = new ArrayList<>();
                    for (LbsLctCtrl wb : wbs) {
                        if (StringUtil.isEmpty(wb.getBarscantm()) || StringUtil.isEmpty(wb.getAoiId()) || "Y".equals(wb.getIsToken()) || "Y".equals(wb.getIsInternal()) || "Y".equals(wb.getIs2box()) || "Y".equals(wb.getIsCallClient())
                                || "Y".equals(wb.getIsOperSelf()) || "Y".equals(wb.getIsDld()) || "Y".equals(wb.getIsFwsj()) || "Y".equals(wb.getIsRdrctOrBack()) || "Y".equals(wb.getIsDlvBatch()) || "Y".equals(wb.getIsDlvErr())) {
                            results.add(wb);
                        } else {
                            tmpList.add(wb);
                        }
                    }
                    tmpList.sort(Comparator.comparing(LbsLctCtrl::getBarscantm));
                    tracks.sort(Comparator.comparing(LbsLctCtrl::getTrackTm));
                    logger.error("小哥 {} 运单数据量：{}, 轨迹点数据量：{}", o._1, tmpList.size(), tracks.size());

                    List<LbsLctCtrl> track5mInAoi200Gpss = new ArrayList<>();
                    long trackTm;
                    long barScanTm;
                    int track30sCnt;
                    int track30sInAoiCnt;
                    int track30sInAoi200Cnt;
                    int track30sInCnyz100Cnt;
                    double dis2Aoi;

                    for (LbsLctCtrl wb : tmpList) {
                        track5mInAoi200Gpss.clear();
                        track30sCnt = 0;
                        track30sInAoiCnt = 0;
                        track30sInAoi200Cnt = 0;
                        track30sInCnyz100Cnt = 0;
                        dis2Aoi = 0;
                        barScanTm = Long.parseLong(wb.getBarscantm());
                        for (LbsLctCtrl track : tracks) {
                            trackTm = Long.parseLong(track.getTrackTm()) * 1000;

                            if ((barScanTm - trackTm <= 300000 && barScanTm - trackTm > 30000) || (barScanTm - trackTm <= 0 && barScanTm - trackTm >= 300000)) {
                                if ("1".equals(track.getTrackTp())) {
                                    dis2Aoi = AoiApi.getCoorAoiDist(wb.getAoiId(), track.getTrackLng(), track.getTrackLat());
                                    if (dis2Aoi <= 200 && "1".equals(track.getTrackTp())) {
                                        track5mInAoi200Gpss.add(track);
                                    }
                                }
                            } else if (barScanTm - trackTm <= 30000 && barScanTm - trackTm >= 0) {
                                dis2Aoi = AoiApi.getCoorAoiDist(wb.getAoiId(), track.getTrackLng(), track.getTrackLat());
                                track30sCnt++;
                                if (dis2Aoi == 0) {
                                    track30sInAoiCnt++;
                                } else if (dis2Aoi <= 200) {
                                    track30sInAoi200Cnt++;
                                }
                                if (wb.getCnyzList() != null && wb.getCnyzList().size() > 0) {
                                    for (FcDlv cnyz : wb.getCnyzList()) {
                                        if (GeometryUtil.getDistance(GeometryUtil.createPoint(track.getTrackLng(), track.getTrackLat()), GeometryUtil.createPoint(cnyz.getLngTrack(), cnyz.getLatTrack())) <= 100) {
                                            track30sInCnyz100Cnt++;
                                        }
                                    }
                                }
                                if (dis2Aoi <= 200 && "1".equals(track.getTrackTp())) {
                                    track5mInAoi200Gpss.add(track);
                                }
                            }
                        }
                        wb.setTrack30sCnt(String.valueOf(track30sCnt));
                        wb.setTrack30sInAoiCnt(String.valueOf(track30sInAoiCnt));
                        wb.setTrack30sInAoi200Cnt(String.valueOf(track30sInAoi200Cnt));
                        wb.setTrack5mInAoi200GpsCnt(String.valueOf(track5mInAoi200Gpss.size()));
                        wb.setTrack30sInCnyz100Cnt(String.valueOf(track30sInCnyz100Cnt));
                        if (track5mInAoi200Gpss.size() >= 5) {
                            LbsLctCtrl track25 = null;
                            LbsLctCtrl track75 = null;
                            int curIndex = 0;
                            long index25 = Math.round(track5mInAoi200Gpss.size() * 0.25);
                            long index75 = Math.round(track5mInAoi200Gpss.size() * 0.75);
                            for (LbsLctCtrl track : track5mInAoi200Gpss) {
                                if (curIndex == index25) {
                                    track25 = track;
                                } else if (curIndex == index75) {
                                    track75 = track;
                                }
                                curIndex++;
                            }
                            if (track25 != null && track75 != null && StringUtil.isNotEmpty(track75.getTrackAd()) && StringUtil.isNotEmpty(track25.getTrackAd()) && Math.abs(Double.parseDouble(track75.getTrackAd()) - Double.parseDouble(track25.getTrackAd())) >= 20) {
                                wb.setIsTrack5mAdChange("Y");
                            }
                        }
                        if (track30sCnt >= 1 && track30sInCnyz100Cnt >= 1 && "Y".equals(wb.getIsCopyPhone())) {
                            wb.setActionType("DLV_COMPETE");
                        } else if (track30sCnt > 1 && track30sInAoi200Cnt == 0) {
                            wb.setActionType("NEVER_BEEN_CLIENT_AOI200");
                        } else if (track30sCnt > 1 && track30sInAoi200Cnt > 1 && "Y".equals(wb.getIsTrack5mAdChange()) && track5mInAoi200Gpss.size() >= 2) {
                            wb.setActionType("NEVER_BEEN_CLIENT_HOME");
                        }

                        results.add(wb);
                    }
                } else {
                    results.addAll(wbs);
                }
                return results.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("------------ 处理完成后运单数据量：{} ------------", rddFinal.count());
            rddFinal.take(3).forEach(o -> logger.error("处理完成后运单详细信息：{}", o.toString()));
            rddWbhCnyz.unpersist();
            rddTrack.unpersist();

            DataUtil.saveOverwrite(si, "dm_gis.lbs_lctctrl_dpp", LbsLctCtrl.class, rddFinal, "inc_day");
            logger.error("------------------------ 处理完成数据日期：{} ------------------------", incDay);
            si.getSession().catalog().clearCache();
        }
    }
}
