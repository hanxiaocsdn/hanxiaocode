package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.TtWaybillHookController1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppTtWaybillHook1 {
    private static Logger logger = LoggerFactory.getLogger(AppTtWaybillHook1.class);

    public static void main(String[] args) {
        String date = args[0];
        String citycodes = args[1];
        logger.error("date:{}", date);
        logger.error("citycodes:{}", citycodes);
        logger.error("run start");
        new TtWaybillHookController1().start(date, citycodes);
        logger.error("run end");
    }
}
