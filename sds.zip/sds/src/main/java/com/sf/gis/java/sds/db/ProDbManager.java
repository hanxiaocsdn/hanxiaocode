package com.sf.gis.java.sds.db;



import com.sf.gis.java.base.util.SystemProperty;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ProDbManager implements IDbManager {
    private static ProDbManager instance;
    private DruidManager druidManager;

    public static ProDbManager getInstance() {
        if (instance == null) {
            synchronized (ProDbManager.class) {
                if (instance == null) {
                    try {
                        instance = new ProDbManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return instance;
    }

    private ProDbManager() throws IOException {
        druidManager = new DruidManager(
                "conf/aoi_hook/druid_config_pro.properties");
    }

    public DruidManager getDruidManager() {
        return druidManager;
    }

    public void close() {
        druidManager.close();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return druidManager.getConnection();
    }

    @Override
    public void update(String sql) {
        druidManager.update(sql);
    }

    public String getString(String sql) {
        @SuppressWarnings("unchecked")
        List<String> list = druidManager.getStringList(sql);
        if (list.size() == 0) {
            return null;
        } else {
            return list.get(0);
        }
    }
}