package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiRealAccRateReport implements Serializable {
    @Column(name = "region")
    private String region;
    @Column(name = "city")
    private String city;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "zonecode")
    private String zonecode;
    @Column(name = "stat_type")
    private String stat_type;
    @Column(name = "rw_search_w_amount")
    private String rw_search_w_amount;
    @Column(name = "aoi_name_chk_w_amount")
    private String aoi_name_chk_w_amount;
    @Column(name = "suspected_wrong_amount")
    private String suspected_wrong_amount;
    @Column(name = "business_wrong_amount")
    private String business_wrong_amount;
    @Column(name = "xg_track_seq_amount")
    private String xg_track_seq_amount;
    @Column(name = "rw_search_c_amount")
    private String rw_search_c_amount;
    @Column(name = "aoi_name_chk_c_amount")
    private String aoi_name_chk_c_amount;
    @Column(name = "special_business_amount")
    private String special_business_amount;
    @Column(name = "business_correct_amount")
    private String business_correct_amount;

    private String stat_type_content;
    private String wrong_amount;
    private String right_amount;

    private String totalWrongAmount;
    private String totalRightAmount;
    private String totalAddrZcAmount;
    private String right_rate;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getTotalWrongAmount() {
        return totalWrongAmount;
    }

    public void setTotalWrongAmount(String totalWrongAmount) {
        this.totalWrongAmount = totalWrongAmount;
    }

    public String getTotalRightAmount() {
        return totalRightAmount;
    }

    public void setTotalRightAmount(String totalRightAmount) {
        this.totalRightAmount = totalRightAmount;
    }

    public String getTotalAddrZcAmount() {
        return totalAddrZcAmount;
    }

    public void setTotalAddrZcAmount(String totalAddrZcAmount) {
        this.totalAddrZcAmount = totalAddrZcAmount;
    }

    public String getRight_rate() {
        return right_rate;
    }

    public void setRight_rate(String right_rate) {
        this.right_rate = right_rate;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getWrong_amount() {
        return wrong_amount;
    }

    public void setWrong_amount(String wrong_amount) {
        this.wrong_amount = wrong_amount;
    }

    public String getRight_amount() {
        return right_amount;
    }

    public void setRight_amount(String right_amount) {
        this.right_amount = right_amount;
    }

    private String address_count_zc;

    public String getAddress_count_zc() {
        return address_count_zc;
    }

    public void setAddress_count_zc(String address_count_zc) {
        this.address_count_zc = address_count_zc;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getRw_search_w_amount() {
        return rw_search_w_amount;
    }

    public void setRw_search_w_amount(String rw_search_w_amount) {
        this.rw_search_w_amount = rw_search_w_amount;
    }

    public String getAoi_name_chk_w_amount() {
        return aoi_name_chk_w_amount;
    }

    public void setAoi_name_chk_w_amount(String aoi_name_chk_w_amount) {
        this.aoi_name_chk_w_amount = aoi_name_chk_w_amount;
    }

    public String getSuspected_wrong_amount() {
        return suspected_wrong_amount;
    }

    public void setSuspected_wrong_amount(String suspected_wrong_amount) {
        this.suspected_wrong_amount = suspected_wrong_amount;
    }

    public String getBusiness_wrong_amount() {
        return business_wrong_amount;
    }

    public void setBusiness_wrong_amount(String business_wrong_amount) {
        this.business_wrong_amount = business_wrong_amount;
    }

    public String getXg_track_seq_amount() {
        return xg_track_seq_amount;
    }

    public void setXg_track_seq_amount(String xg_track_seq_amount) {
        this.xg_track_seq_amount = xg_track_seq_amount;
    }

    public String getRw_search_c_amount() {
        return rw_search_c_amount;
    }

    public void setRw_search_c_amount(String rw_search_c_amount) {
        this.rw_search_c_amount = rw_search_c_amount;
    }

    public String getAoi_name_chk_c_amount() {
        return aoi_name_chk_c_amount;
    }

    public void setAoi_name_chk_c_amount(String aoi_name_chk_c_amount) {
        this.aoi_name_chk_c_amount = aoi_name_chk_c_amount;
    }

    public String getSpecial_business_amount() {
        return special_business_amount;
    }

    public void setSpecial_business_amount(String special_business_amount) {
        this.special_business_amount = special_business_amount;
    }

    public String getBusiness_correct_amount() {
        return business_correct_amount;
    }

    public void setBusiness_correct_amount(String business_correct_amount) {
        this.business_correct_amount = business_correct_amount;
    }
}
