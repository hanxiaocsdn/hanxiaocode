package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SjSameAddrIntoTelWhite implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "userid")
    private String userid;
    @Column(name = "req_address")
    private String req_address;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "gj_aoicode_t")
    private String gj_aoicode_t;
    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "r_aoi")
    private String r_aoi;
    @Column(name = "isnotundercall")
    private String isnotundercall;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "extra")
    private String extra;

    @Column(name = "tel")
    private String tel;
    @Column(name = "correctness")
    private String correctness;
    @Column(name = "r_zc")
    private String r_zc;
    @Column(name = "r_aoiid")
    private String r_aoiid;
    @Column(name = "press_groupid")
    private String press_groupid;
    @Column(name = "gongyi")
    private String gongyi;
    @Column(name = "result")
    private String result;

    @Column(name = "teltc_response")
    private String teltc_response;
    @Column(name = "rgsbadd_response")
    private String rgsbadd_response;

    @Column(name = "check_aoi")
    private String check_aoi;

    @Column(name = "inc_day")
    private String inc_day;

    private String tag;
    private String temp_flag;

    public String getCheck_aoi() {
        return check_aoi;
    }

    public void setCheck_aoi(String check_aoi) {
        this.check_aoi = check_aoi;
    }

    public String getTemp_flag() {
        return temp_flag;
    }

    public void setTemp_flag(String temp_flag) {
        this.temp_flag = temp_flag;
    }

    public String getTeltc_response() {
        return teltc_response;
    }

    public void setTeltc_response(String teltc_response) {
        this.teltc_response = teltc_response;
    }

    public String getRgsbadd_response() {
        return rgsbadd_response;
    }

    public void setRgsbadd_response(String rgsbadd_response) {
        this.rgsbadd_response = rgsbadd_response;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCorrectness() {
        return correctness;
    }

    public void setCorrectness(String correctness) {
        this.correctness = correctness;
    }

    public String getR_zc() {
        return r_zc;
    }

    public void setR_zc(String r_zc) {
        this.r_zc = r_zc;
    }

    public String getR_aoiid() {
        return r_aoiid;
    }

    public void setR_aoiid(String r_aoiid) {
        this.r_aoiid = r_aoiid;
    }

    public String getPress_groupid() {
        return press_groupid;
    }

    public void setPress_groupid(String press_groupid) {
        this.press_groupid = press_groupid;
    }

    public String getGongyi() {
        return gongyi;
    }

    public void setGongyi(String gongyi) {
        this.gongyi = gongyi;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getReq_address() {
        return req_address;
    }

    public void setReq_address(String req_address) {
        this.req_address = req_address;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getR_aoi() {
        return r_aoi;
    }

    public void setR_aoi(String r_aoi) {
        this.r_aoi = r_aoi;
    }

    public String getIsnotundercall() {
        return isnotundercall;
    }

    public void setIsnotundercall(String isnotundercall) {
        this.isnotundercall = isnotundercall;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }
}
