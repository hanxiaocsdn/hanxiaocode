package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.LbsLogPnsAoi;
import com.sf.gis.java.sds.service.LbsLogAnalysisService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Row;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LBS定位管控日志解析
 *
 * @author 01370539 Created On: Sep.16 2021
 */
public class LbsLogAnalysisController {
    private static final Logger logger = LoggerFactory.getLogger(LbsLogAnalysisController.class);

    private final LbsLogAnalysisService lbsLogAnalysisService = new LbsLogAnalysisService();

    public void process(String startDate, String endDate) throws Exception {
        logger.error("process start. statDate - {}", startDate);

        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());

        JavaRDD<Row> rddRow = lbsLogAnalysisService.loadOrigLog(sparkInfo, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddRow.take(1).forEach(row -> logger.error("log -> {}", row.getString(0)));

        if (rddRow.count() == 0) {
            throw new Exception(startDate + ",无数据!!!");
        }
        JavaRDD<LbsLogPnsAoi> rddLog = lbsLogAnalysisService.analysis(rddRow, startDate).filter(temp -> startDate.equals(temp.getMsgTm())).repartition(1200).persist(StorageLevel.MEMORY_AND_DISK_SER());

        JavaRDD<Row> rddRow2 = lbsLogAnalysisService.loadOrigLog2(sparkInfo, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddRow.unpersist();

        JavaRDD<LbsLogPnsAoi> rddLog2 = lbsLogAnalysisService.analysis2(rddRow2, startDate).filter(o -> StringUtils.isNotEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddLog2 cnt:{}", rddLog2.count());
        rddLog2.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        rddRow2.unpersist();

        JavaRDD<Row> rddRow3 = lbsLogAnalysisService.loadOrigLog3(sparkInfo, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());

        JavaRDD<LbsLogPnsAoi> rddLog3 = lbsLogAnalysisService.analysis3(rddRow3, startDate).filter(o -> StringUtils.isNotEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddLog3 cnt:{}", rddLog2.count());
        rddLog3.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        rddRow3.unpersist();

        JavaRDD<LbsLogPnsAoi> joinWifiRdd = lbsLogAnalysisService.join2(rddLog, rddLog3).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<LbsLogPnsAoi> resultRdd = lbsLogAnalysisService.join(joinWifiRdd, rddLog2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rddLog.unpersist();
        rddLog2.unpersist();
        joinWifiRdd.unpersist();

        String executeSql = String.format("alter table dm_gis.lbs_log_pnsaoi drop if EXISTS partition( inc_day='%s' )", startDate);
        logger.error("executeSql :{}", executeSql);
        sparkInfo.getSession().sql(executeSql);
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.lbs_log_pnsaoi", LbsLogPnsAoi.class, resultRdd, "inc_day");
        resultRdd.unpersist();

        logger.error("process: end ");
    }
}
