package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CgcsErrorAddressResult implements Serializable {
    @Column(name = "check_result")
    private String check_result;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "address")
    private String address;
    @Column(name = "check_by")
    private String check_by;
    @Column(name = "check_aoi_id")
    private String check_aoi_id;
    @Column(name = "check_dept_code")
    private String check_dept_code;
    @Column(name = "guid")
    private String guid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "old_cms_aoiid")
    private String old_cms_aoiid;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "flag")
    private String flag;
    @Column(name = "updateaddraoicheck_response")
    private String updateaddraoicheck_response;
    @Column(name = "updateaddraoicheck_tag")
    private String updateaddraoicheck_tag;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "check_aoi_code")
    private String check_aoi_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "gd_result")
    private String gd_result;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "gj_aoiid_t")
    private String gj_aoiid_t;
    @Column(name = "80_aoi_code")
    private String aoi_80_code;
    @Column(name = "gdps_aoiid")
    private String gdps_aoiid;
    @Column(name = "gd_aoiid")
    private String gd_aoiid;
    @Column(name = "mapa_aoiid")
    private String mapa_aoiid;
    @Column(name = "bd_aoiid")
    private String bd_aoiid;
    @Column(name = "tc_aoiid")
    private String tc_aoiid;
    @Column(name = "updateaddraoiid_tag")
    private String updateaddraoiid_tag;
    @Column(name = "updateaddraoiid_response")
    private String updateaddraoiid_response;
    @Column(name = "inc_day")
    private String inc_day;

    public String getUpdateaddraoiid_tag() {
        return updateaddraoiid_tag;
    }

    public void setUpdateaddraoiid_tag(String updateaddraoiid_tag) {
        this.updateaddraoiid_tag = updateaddraoiid_tag;
    }

    public String getUpdateaddraoiid_response() {
        return updateaddraoiid_response;
    }

    public void setUpdateaddraoiid_response(String updateaddraoiid_response) {
        this.updateaddraoiid_response = updateaddraoiid_response;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getMapa_aoiid() {
        return mapa_aoiid;
    }

    public void setMapa_aoiid(String mapa_aoiid) {
        this.mapa_aoiid = mapa_aoiid;
    }

    public String getBd_aoiid() {
        return bd_aoiid;
    }

    public void setBd_aoiid(String bd_aoiid) {
        this.bd_aoiid = bd_aoiid;
    }

    public String getTc_aoiid() {
        return tc_aoiid;
    }

    public void setTc_aoiid(String tc_aoiid) {
        this.tc_aoiid = tc_aoiid;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getGdps_aoiid() {
        return gdps_aoiid;
    }

    public void setGdps_aoiid(String gdps_aoiid) {
        this.gdps_aoiid = gdps_aoiid;
    }

    public String getGj_aoiid_t() {
        return gj_aoiid_t;
    }

    public void setGj_aoiid_t(String gj_aoiid_t) {
        this.gj_aoiid_t = gj_aoiid_t;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getGd_result() {
        return gd_result;
    }

    public void setGd_result(String gd_result) {
        this.gd_result = gd_result;
    }

    public String getUpdateaddraoicheck_response() {
        return updateaddraoicheck_response;
    }

    public void setUpdateaddraoicheck_response(String updateaddraoicheck_response) {
        this.updateaddraoicheck_response = updateaddraoicheck_response;
    }

    public String getUpdateaddraoicheck_tag() {
        return updateaddraoicheck_tag;
    }

    public void setUpdateaddraoicheck_tag(String updateaddraoicheck_tag) {
        this.updateaddraoicheck_tag = updateaddraoicheck_tag;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getCheck_aoi_code() {
        return check_aoi_code;
    }

    public void setCheck_aoi_code(String check_aoi_code) {
        this.check_aoi_code = check_aoi_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getOld_cms_aoiid() {
        return old_cms_aoiid;
    }

    public void setOld_cms_aoiid(String old_cms_aoiid) {
        this.old_cms_aoiid = old_cms_aoiid;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getCheck_result() {
        return check_result;
    }

    public void setCheck_result(String check_result) {
        this.check_result = check_result;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCheck_by() {
        return check_by;
    }

    public void setCheck_by(String check_by) {
        this.check_by = check_by;
    }

    public String getCheck_aoi_id() {
        return check_aoi_id;
    }

    public void setCheck_aoi_id(String check_aoi_id) {
        this.check_aoi_id = check_aoi_id;
    }

    public String getCheck_dept_code() {
        return check_dept_code;
    }

    public void setCheck_dept_code(String check_dept_code) {
        this.check_dept_code = check_dept_code;
    }
}
