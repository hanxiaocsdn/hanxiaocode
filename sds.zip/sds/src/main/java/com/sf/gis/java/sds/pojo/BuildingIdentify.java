package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BuildingIdentify implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "fei_call")
    private String fei_call;
    @Column(name = "address")
    private String address;
    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "split")
    private String split;
    @Column(name = "is_complete")
    private String is_complete;
    @Column(name = "lvl14_info")
    private String lvl14_info;
    @Column(name = "response")
    private String response;
    @Column(name = "status")
    private String status;
    @Column(name = "aoiid")
    private String aoiId;
    @Column(name = "splitresult")
    private String splitResult;
    @Column(name = "buildingid")
    private String buildingId;
    @Column(name = "buildingname")
    private String buildingName;
    @Column(name = "bulidingtype")
    private String bulidingType;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "levelsrc")
    private String levelSrc;
    @Column(name = "detailsrc")
    private String detailSrc;
    @Column(name = "nametag")
    private String nameTag;
    @Column(name = "final_split")
    private String final_split;
    @Column(name = "zno_code")
    private String zno_code;

    @Column(name = "waybillno_src")
    private String waybillno_src;
    @Column(name = "aoi_src")
    private String aoi_src;
    @Column(name = "inc_day")
    private String inc_day;



    public String getAoi_src() {return aoi_src;}

    public void setAoi_src(String aoi_src) {this.aoi_src = aoi_src;}

    public String getFinal_split() {
        return final_split;
    }

    public void setFinal_split(String final_split) {
        this.final_split = final_split;
    }


    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getWaybillno_src() {return waybillno_src;}

    public void setWaybillno_src(String waybillno_src) {this.waybillno_src = waybillno_src;}

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(String buildingId) {
        this.buildingId = buildingId;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getBulidingType() {
        return bulidingType;
    }

    public void setBulidingType(String bulidingType) {
        this.bulidingType = bulidingType;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getLevelSrc() {
        return levelSrc;
    }

    public void setLevelSrc(String levelSrc) {
        this.levelSrc = levelSrc;
    }

    public String getDetailSrc() {
        return detailSrc;
    }

    public void setDetailSrc(String detailSrc) {
        this.detailSrc = detailSrc;
    }

    public String getNameTag() {
        return nameTag;
    }

    public void setNameTag(String nameTag) {
        this.nameTag = nameTag;
    }

    public String getLvl14_info() {
        return lvl14_info;
    }

    public void setLvl14_info(String lvl14_info) {
        this.lvl14_info = lvl14_info;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getFei_call() {
        return fei_call;
    }

    public void setFei_call(String fei_call) {
        this.fei_call = fei_call;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getIs_complete() {
        return is_complete;
    }

    public void setIs_complete(String is_complete) {
        this.is_complete = is_complete;
    }
}
