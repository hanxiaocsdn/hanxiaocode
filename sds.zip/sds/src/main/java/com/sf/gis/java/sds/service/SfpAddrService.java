package com.sf.gis.java.sds.service;

import com.github.davidmoten.geo.GeoHash;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.dto.KeyInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.constant.SdsConstant;
import com.sf.gis.java.sds.pojo.*;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 地址画像服务类
 */
public class SfpAddrService {
    private static final Logger logger = LoggerFactory.getLogger(SfpAddrService.class);

    /**
     * 加载初始化地址库需要的数据，包含运单的收寄件信息信息，订单号，以及巴枪的54坐标
     * @param sparkInfo spark相关信息
     * @param region 大区
     * @param cityCode 城市编码
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 加载初始化地址库需要的数据，包含运单的收寄件信息信息，订单号，以及巴枪的54坐标
     */
    public JavaRDD<SfpAddrInit> load4Init(SparkInfo sparkInfo, String region, String cityCode, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("sfp_addr_init_shou_city.sql", startDate, endDate, region, cityCode, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate);
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrInit.class);
    }

    /**
     * 加载初始化地址库需要的数据，包含运单的收寄件信息信息，订单号，以及巴枪的54坐标
     * @param sparkInfo spark相关信息
     * @param region 大区
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 加载初始化地址库需要的数据，包含运单的收寄件信息信息，订单号，以及巴枪的54坐标
     */
    public JavaRDD<SfpAddrInit> load4Init(SparkInfo sparkInfo, String region, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("sfp_addr_init_shou_region.sql", startDate, endDate, region, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate, startDate, endDate);
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrInit.class);
    }

    /**
     * 为下一步地址拆分提取功能加载初始化数据
     * @param sparkInfo spark相关信息
     * @param cityCode 城市编码
     * @return 初始化数据
     */
    public JavaRDD<SfpAddrInit> load4Split(SparkInfo sparkInfo, String cityCode) {
        String sql = "select * from dm_gis.sfp_addr_init where city_code = '" + cityCode + "'";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrInit.class);
    }

    /**
     * 处理初始化数据，包括处理切词，提取主体，生成坐标hash key，生成数据ID，生成地址归一ID等
     * @param rddInit 初始化数据
     * @return 处理初始化数据，包括处理切词，提取主体，生成坐标hash key，生成数据ID，生成地址归一ID等
     */
    public JavaRDD<SfpAddrInit> split(JavaRDD<SfpAddrInit> rddInit) {
        return rddInit.map(temp -> {
            String split = temp.getSplit();
            if (StringUtils.isNotEmpty(split)) {
                String[] keyArr = split.split(";")[0].split("\\|");
                String[] klArr;
                for(String key : keyArr) {
                    klArr = key.split("\\^");
                    if (StringUtils.isEmpty(temp.getDistrict()) && "3".equals(klArr[1].substring(1))) {
                        temp.setDistrict(klArr[0]);
                    } else if ("13".equals(klArr[1].substring(1))) {
                        if (StringUtils.isEmpty(temp.getBuilding())) {
                            if ("6".equalsIgnoreCase(klArr[1].substring(0, 1))) {
                                if (StringUtils.isNotEmpty(temp.getPoi())) {
                                    temp.setPoi(temp.getPoi() + "|" + AddrUtil.transferNumber(klArr[0]));
                                    temp.setPoiLevel(temp.getPoiLevel() + "|" + klArr[1].substring(0, 1));
                                }
                            } else {
                                temp.setPoiLevel(klArr[1].substring(0, 1));
                                temp.setPoi(AddrUtil.transferNumber(klArr[0]));
                            }
                        }
                    } else if ("14".equals(klArr[1].substring(1))) {
                        if (StringUtils.isEmpty(temp.getBuilding())) {
                            temp.setBuildingLevel(klArr[1].substring(0, 1));
                            temp.setBuilding(AddrUtil.transferNumber(klArr[0]));
                        } else {
                            temp.setBuildingLevel(temp.getBuildingLevel() + "|" + klArr[1].substring(0, 1));
                            temp.setBuilding(temp.getBuilding() + "|" + AddrUtil.transferNumber(klArr[0]));
                        }
                    }
                }
                KeyInfo keyInfo = AddrUtil.getKeyInfo(split);
                temp.setSplitKey(keyInfo.getKey());
                temp.setSplitKeyLevel(keyInfo.getKeyLevel());
                temp.setKeyId(DigestUtils.md5Hex(temp.getProvince() + temp.getCity() + temp.getDistrict() + temp.getSplitKey()));
            }
            if (StringUtils.isNotEmpty(temp.getLatBq()) && StringUtils.isNotEmpty(temp.getLngBq()) && Double.parseDouble(temp.getLatBq()) <= 90 && Double.parseDouble(temp.getLatBq()) >= -90) {
                String key = GeoHash.encodeHash(Double.parseDouble(temp.getLatBq()), Double.parseDouble(temp.getLngBq()), 5);
                temp.setHashLatLngBq(key);
            }
            temp.setUuid(UUID.randomUUID().toString());
            return temp;
        });
    }

    /**
     * 加载已经拆分的信息
     * @param sparkInfo spark相关信息
     * @param cityCode 城市编码
     * @return 已经拆分的信息
     */
    public JavaRDD<SfpAddrInit> load4Coord(SparkInfo sparkInfo, String cityCode) {
        String sql = "select * from dm_gis.sfp_addr_split where city_code = '" + cityCode + "' and poi != '' and poi is not null and building != '' and building is not null and split_key != '' and split_key is not null and order_no_oms != '' and order_no_oms is not null and under_call != '1' and lat_bq != '' and lat_bq != '0.0' and lat_bq is not null and lng_bq != '' and lng_bq != '0.0' and lng_bq is not null and hash_latlng_bq != '' and hash_latlng_bq is not null";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrInit.class);
    }

    /**
     * 加载进行了坐标聚合填充的明细数据
     * @param sparkInfo spark相关信息
     * @param cityCode 城市编码
     * @return 坐标聚合填充的明细数据
     */
    public JavaRDD<SfpAddrInit> load4Norm(SparkInfo sparkInfo, String cityCode) {
        String sql = "select * from dm_gis.sfp_addr_coord where city_code = '" + cityCode + "'";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrInit.class);
    }

    /**
     * 加载要推送的数据
     * @param sparkInfo spark相关信息
     * @param cityCode 城市编码
     * @param effectType 有效类型
     * @param xyAoiType 坐标对应的AOI类型
     * @return 要推送的数据
     */
    public JavaRDD<SfpAddrNorm> load4Push(SparkInfo sparkInfo, String cityCode, String effectType, String xyAoiType) {
        String sql = "select * from dm_gis.sfp_addr_norm where city_code = '" + cityCode + "' and effect_type in (" + effectType + ") and aoi_xy_type in (" + xyAoiType + ")";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrNorm.class);
    }

    /**
     * 加载要推送的数据
     * @param sparkInfo spark相关信息
     * @param cityCode 城市编码
     * @param effectType 有效类型
     * @param xyAoiType 坐标对应的AOI类型
     * @return 要推送的数据
     */
    public JavaRDD<SfpAddrNorm> load4PushCoord(SparkInfo sparkInfo, String cityCode, String effectType, String xyAoiType) {
        String sql = "select * from dm_gis.sfp_addr_verify where city_code = '" + cityCode + "' and status_building = 'match_coord' and effect_type in (" + effectType + ") and aoi_xy_type in (" + xyAoiType + ")";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrNorm.class);
    }

    /**
     * 提取规则
     * @param rddNorm 要推送的数据
     * @return 提取了规则的要推送的数据
     */
    public JavaRDD<SfpAddrPush> extractSkRule(JavaRDD<SfpAddrNorm> rddNorm, String processMode) {
        return rddNorm.map(temp -> {
            SfpAddrPush sap = new SfpAddrPush();
            String splitKey = temp.getSplitKey();
            if (splitKey.indexOf("|") > 0) {
                String poi = splitKey.substring(0, splitKey.indexOf("|"));
                String ruleStr = splitKey.substring(splitKey.indexOf("|") + 1);
                Pattern pChinese = Pattern.compile("([\u4e00-\u9fa5]+)");
                Pattern pNumber = Pattern.compile("(.*[0-9A-Za-z].*)");
                Matcher mChinese = null;
                Matcher mNumber = null;
                String[] rsArr = ruleStr.split("\\|");
                String rule;
                List<String> ruleList = new LinkedList<>();
                for (String rs : rsArr) {
                    mNumber = pNumber.matcher(rs);
                    if (mNumber.find()) {
                        mChinese = pChinese.matcher(rs);
                        rule = "";
                        while (mChinese.find()) {
                            rule = mChinese.group(0);
                        }
                        if (StringUtils.isNotEmpty(rule) && !ruleList.contains(rule)) {
                            ruleList.add(rule);
                        }
                    }
                }
                sap.setSkPoi(poi);
                sap.setSkRule(ruleList.toString().replace("[", "").replaceAll(" ", "").replace("]", ""));
            }
            sap.setProvince(temp.getProvince());
            sap.setCity(temp.getCity());
            sap.setCityCode(temp.getCityCode());
            sap.setDistrict(temp.getDistrict());
            sap.setAoiXy(temp.getAoiXy());
            sap.setAoiXyType(temp.getAoiXyType());
            sap.setAoiXyTypeName(temp.getAoiXyTypeName());
            sap.setAddr(temp.getAddr());
            sap.setSplit(temp.getSplit());
            sap.setSplitKey(temp.getSplitKey());
            sap.setSplitKeyLevel(temp.getSplitKeyLevel());
            sap.setKeyId(temp.getKeyId());
            sap.setPoi(temp.getPoi());
            sap.setBuilding(temp.getBuilding());
            sap.setLng(temp.getLng());
            sap.setLat(temp.getLat());
            sap.setFreq(temp.getFreq());
            sap.setIsEffect(temp.getIsEffect());
            sap.setEffectType(temp.getEffectType());
            sap.setSource(SdsConstant.SFP_ADDR_PROCESS_PUSH.equalsIgnoreCase(processMode) ? "norm" : "verify");
            sap.setPushTime(DateUtil.getCurrentDatetime());
            sap.setIncDay(DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY));
            return sap;
        });
    }

    /**
     * 获取标准库数据，进行准确性校验
     * @param sparkInfo Spark相关信息
     * @return 标准库数据
     */
    public JavaRDD<SfpAddrNorm> load4Verify(SparkInfo sparkInfo) {
        String sql = "select * from dm_gis.sfp_addr_norm where aoi_xy != ''";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SfpAddrNorm.class);
    }

    /**
     * 获取标准库数据，进行准确性校验
     * @param sparkInfo Spark相关信息
     * @return 标准库数据
     */
    public JavaRDD<Building> loadBuilding(SparkInfo sparkInfo) {
        String sql = "select * from dm_gis.sfp_addr_building where aoi != ''";
        return DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, Building.class);
    }

    public JavaRDD<Building> load4Building(SparkInfo sparkInfo, Connection conn) {
        JavaRDD<Building> rddBuilding = null;
        try {
            List<Building> buildingList = new ArrayList<>();
            String sql = "select id, name, alias, x, y, adcode_mark from fruit_task_vw where task_type = '2' and name !='' and x != '' and y != ''";
            logger.error("select sql: {}", sql);
            PreparedStatement pstm = conn.prepareStatement(sql);
            ResultSet rs = pstm.executeQuery();
            Building building;
            while (rs.next()) {
                building = new Building();
                building.setId(rs.getString(1));
                building.setName(rs.getString(2));
                building.setAlias(rs.getString(3));
                building.setLng(rs.getString(4));
                building.setLat(rs.getString(5));
                building.setAdcode(rs.getString(6));
                buildingList.add(building);
            }
            logger.error("select count: {}", buildingList.size());
            rddBuilding = sparkInfo.getContext().parallelize(buildingList);
            rs.close();
            pstm.close();
        } catch (Exception e) {
            logger.error("loadBuilding execute error. {}", e);
        }
        return rddBuilding;
    }
}
