package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DwdWaybillInfoDtlDi implements Serializable {
    @Column(name = "consignor_addr_decrypt")
    private String consignor_addr_decrypt;
    @Column(name = "src_dist_code")
    private String src_dist_code;
    @Column(name = "consignor_aoi_id")
    private String consignor_aoi_id;
    @Column(name = "consignee_addr_decrypt")
    private String consignee_addr_decrypt;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "addressee_aoi_id")
    private String addressee_aoi_id;
    @Column(name = "inc_day")
    private String inc_day;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getConsignor_addr_decrypt() {
        return consignor_addr_decrypt;
    }

    public void setConsignor_addr_decrypt(String consignor_addr_decrypt) {
        this.consignor_addr_decrypt = consignor_addr_decrypt;
    }

    public String getSrc_dist_code() {
        return src_dist_code;
    }

    public void setSrc_dist_code(String src_dist_code) {
        this.src_dist_code = src_dist_code;
    }

    public String getConsignor_aoi_id() {
        return consignor_aoi_id;
    }

    public void setConsignor_aoi_id(String consignor_aoi_id) {
        this.consignor_aoi_id = consignor_aoi_id;
    }

    public String getConsignee_addr_decrypt() {
        return consignee_addr_decrypt;
    }

    public void setConsignee_addr_decrypt(String consignee_addr_decrypt) {
        this.consignee_addr_decrypt = consignee_addr_decrypt;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getAddressee_aoi_id() {
        return addressee_aoi_id;
    }

    public void setAddressee_aoi_id(String addressee_aoi_id) {
        this.addressee_aoi_id = addressee_aoi_id;
    }
}
