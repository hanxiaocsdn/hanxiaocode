package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class EsgGisLocTrajectory implements Serializable, Comparable<EsgGisLocTrajectory> {
    @Column(name = "emp_code")
    private String emp_code;
    @Column(name = "zx")
    private String zx;
    @Column(name = "zy")
    private String zy;
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "city")
    private String city;
    @Column(name = "tm")
    private String tm;
    @Column(name = "fixx")
    private String fixx;
    @Column(name = "fixy")
    private String fixy;
    @Column(name = "emp_name")
    private String emp_name;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;

    @Column(name = "working_time")
    private String working_time;
    @Column(name = "aoi_area_id")
    private String aoi_area_id;
    @Column(name = "batch_1_start_time_in_dept_aoi")
    private String batch_1_start_time_in_dept_aoi;
    @Column(name = "batch_1_end_time_in_dept_aoi")
    private String batch_1_end_time_in_dept_aoi;
    @Column(name = "batch_2_start_time_in_dept_aoi")
    private String batch_2_start_time_in_dept_aoi;
    @Column(name = "batch_2_end_time_in_dept_aoi")
    private String batch_2_end_time_in_dept_aoi;
    @Column(name = "batch_3_start_time_in_dept_aoi")
    private String batch_3_start_time_in_dept_aoi;
    @Column(name = "batch_3_end_time_in_dept_aoi")
    private String batch_3_end_time_in_dept_aoi;
    @Column(name = "most_stay_aoiid")
    private String most_stay_aoiid;
    @Column(name = "most_stay_name")
    private String most_stay_name;
    @Column(name = "stay_time")
    private String stay_time;
    @Column(name = "stay_time_duration")
    private String stay_time_duration;
    @Column(name = "stay_batch_code")
    private String stay_batch_code;
    @Column(name = "is_bq_op")
    private String is_bq_op;
    @Column(name = "busy_hour")
    private String busy_hour;
    @Column(name = "easy_hour")
    private String easy_hour;
    @Column(name = "op_hour")
    private String op_hour;
    @Column(name = "inc_day")
    private String inc_day;

    private String hour;
    private double distance;

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getBusy_hour() {
        return busy_hour;
    }

    public void setBusy_hour(String busy_hour) {
        this.busy_hour = busy_hour;
    }

    public String getEasy_hour() {
        return easy_hour;
    }

    public void setEasy_hour(String easy_hour) {
        this.easy_hour = easy_hour;
    }

    public String getOp_hour() {
        return op_hour;
    }

    public void setOp_hour(String op_hour) {
        this.op_hour = op_hour;
    }

    public String getIs_bq_op() {
        return is_bq_op;
    }

    public void setIs_bq_op(String is_bq_op) {
        this.is_bq_op = is_bq_op;
    }

    public String getWorking_time() {
        return working_time;
    }

    public void setWorking_time(String working_time) {
        this.working_time = working_time;
    }

    public String getStay_batch_code() {
        return stay_batch_code;
    }

    public void setStay_batch_code(String stay_batch_code) {
        this.stay_batch_code = stay_batch_code;
    }

    public String getMost_stay_aoiid() {
        return most_stay_aoiid;
    }

    public void setMost_stay_aoiid(String most_stay_aoiid) {
        this.most_stay_aoiid = most_stay_aoiid;
    }

    public String getMost_stay_name() {
        return most_stay_name;
    }

    public void setMost_stay_name(String most_stay_name) {
        this.most_stay_name = most_stay_name;
    }

    public String getStay_time() {
        return stay_time;
    }

    public void setStay_time(String stay_time) {
        this.stay_time = stay_time;
    }

    public String getStay_time_duration() {
        return stay_time_duration;
    }

    public void setStay_time_duration(String stay_time_duration) {
        this.stay_time_duration = stay_time_duration;
    }

    public String getFixx() {
        return fixx;
    }

    public void setFixx(String fixx) {
        this.fixx = fixx;
    }

    public String getFixy() {
        return fixy;
    }

    public void setFixy(String fixy) {
        this.fixy = fixy;
    }

    public String getAoi_area_id() {
        return aoi_area_id;
    }

    public void setAoi_area_id(String aoi_area_id) {
        this.aoi_area_id = aoi_area_id;
    }

    public String getBatch_1_start_time_in_dept_aoi() {
        return batch_1_start_time_in_dept_aoi;
    }

    public void setBatch_1_start_time_in_dept_aoi(String batch_1_start_time_in_dept_aoi) {
        this.batch_1_start_time_in_dept_aoi = batch_1_start_time_in_dept_aoi;
    }

    public String getBatch_1_end_time_in_dept_aoi() {
        return batch_1_end_time_in_dept_aoi;
    }

    public void setBatch_1_end_time_in_dept_aoi(String batch_1_end_time_in_dept_aoi) {
        this.batch_1_end_time_in_dept_aoi = batch_1_end_time_in_dept_aoi;
    }

    public String getBatch_2_start_time_in_dept_aoi() {
        return batch_2_start_time_in_dept_aoi;
    }

    public void setBatch_2_start_time_in_dept_aoi(String batch_2_start_time_in_dept_aoi) {
        this.batch_2_start_time_in_dept_aoi = batch_2_start_time_in_dept_aoi;
    }

    public String getBatch_2_end_time_in_dept_aoi() {
        return batch_2_end_time_in_dept_aoi;
    }

    public void setBatch_2_end_time_in_dept_aoi(String batch_2_end_time_in_dept_aoi) {
        this.batch_2_end_time_in_dept_aoi = batch_2_end_time_in_dept_aoi;
    }

    public String getBatch_3_start_time_in_dept_aoi() {
        return batch_3_start_time_in_dept_aoi;
    }

    public void setBatch_3_start_time_in_dept_aoi(String batch_3_start_time_in_dept_aoi) {
        this.batch_3_start_time_in_dept_aoi = batch_3_start_time_in_dept_aoi;
    }

    public String getBatch_3_end_time_in_dept_aoi() {
        return batch_3_end_time_in_dept_aoi;
    }

    public void setBatch_3_end_time_in_dept_aoi(String batch_3_end_time_in_dept_aoi) {
        this.batch_3_end_time_in_dept_aoi = batch_3_end_time_in_dept_aoi;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getZx() {
        return zx;
    }

    public void setZx(String zx) {
        this.zx = zx;
    }

    public String getZy() {
        return zy;
    }

    public void setZy(String zy) {
        this.zy = zy;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    @Override
    public int compareTo(EsgGisLocTrajectory o) {
        double distance = this.getDistance();
        double distance1 = o.getDistance();
        if (distance > distance1) {
            return 1;
        } else if (distance < distance1) {
            return -1;
        }
        return 0;
    }
}
