package com.sf.gis.java.sds.pojo.waybillaoi;

import java.io.Serializable;

public class HiveToKafkaOms implements Serializable {
    private String waybillNo;
    private String consAoiTypeCode;
    private String consDeptCode;
    private String consAoiId;
    private String consAoiCode;
    private String consTeamCode;
    private String dispAoiId;
    private String dispAoiCode;
    private String dispAoiArea;
    private String dispAoiTypeCode;

    private String toOmsTm;
    private String aoiCategory;
    private String tag;

    public String getToOmsTm() {
        return toOmsTm;
    }

    public void setToOmsTm(String toOmsTm) {
        this.toOmsTm = toOmsTm;
    }

    public String getAoiCategory() {
        return aoiCategory;
    }

    public void setAoiCategory(String aoiCategory) {
        this.aoiCategory = aoiCategory;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getConsAoiTypeCode() {
        return consAoiTypeCode;
    }

    public void setConsAoiTypeCode(String consAoiTypeCode) {
        this.consAoiTypeCode = consAoiTypeCode;
    }

    public String getConsDeptCode() {
        return consDeptCode;
    }

    public void setConsDeptCode(String consDeptCode) {
        this.consDeptCode = consDeptCode;
    }

    public String getConsAoiId() {
        return consAoiId;
    }

    public void setConsAoiId(String consAoiId) {
        this.consAoiId = consAoiId;
    }

    public String getConsAoiCode() {
        return consAoiCode;
    }

    public void setConsAoiCode(String consAoiCode) {
        this.consAoiCode = consAoiCode;
    }

    public String getConsTeamCode() {
        return consTeamCode;
    }

    public void setConsTeamCode(String consTeamCode) {
        this.consTeamCode = consTeamCode;
    }

    public String getDispAoiId() {
        return dispAoiId;
    }

    public void setDispAoiId(String dispAoiId) {
        this.dispAoiId = dispAoiId;
    }

    public String getDispAoiCode() {
        return dispAoiCode;
    }

    public void setDispAoiCode(String dispAoiCode) {
        this.dispAoiCode = dispAoiCode;
    }

    public String getDispAoiArea() {
        return dispAoiArea;
    }

    public void setDispAoiArea(String dispAoiArea) {
        this.dispAoiArea = dispAoiArea;
    }

    public String getDispAoiTypeCode() {
        return dispAoiTypeCode;
    }

    public void setDispAoiTypeCode(String dispAoiTypeCode) {
        this.dispAoiTypeCode = dispAoiTypeCode;
    }
}
