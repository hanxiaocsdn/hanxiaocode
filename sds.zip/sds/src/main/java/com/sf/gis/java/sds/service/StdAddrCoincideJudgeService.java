package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.CmsAddress;
import com.sf.gis.java.sds.pojo.CmsAddressDuplicate;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StdAddrCoincideJudgeService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(StdAddrCoincideJudgeService.class);

    public JavaRDD<CmsAddress> loadCoincideJudgeData(SparkSession spark, JavaSparkContext sc, String date, String city_code) {
        String sql = String.format("select * from dm_gis.cms_address_std_coincide_judge where inc_day = '%s' and city_code = '%s'", date, city_code);
        return DataUtil.loadData(spark, sc, sql, CmsAddress.class);
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_code,aoi_name,fa_type from dm_gis.cms_aoi_sch";
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<AoiAreaAoi> loadAoiAreaAoiData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi";
        return DataUtil.loadData(spark, sc, sql, AoiAreaAoi.class);
    }

    public CmsAddress processGdj(CmsAddress o, Statement stmt) {
        try {
            String address_id = o.getAddress_id();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(address_id) && StringUtils.isNotEmpty(city_code)) {
                String sql_group2 = String.format("select alias,type from st_group2 where city_adcode = '%s' and id = '%s'", city_code, address_id);
                logger.error("sql_group2:{}", sql_group2);
                if (StringUtils.isNotEmpty(sql_group2)) {
                    ResultSet rs = stmt.executeQuery(sql_group2);
                    while (rs.next()) {
                        String alias = rs.getString("alias");
                        int type = rs.getInt("type");

                        o.setGroup_alias(alias);
                        o.setGroup_type(type + "");
                    }
                }
                String sql_group1 = String.format("select name,adcode from st_group1 where city_adcode = '%s' and new_group_id = '%s'", city_code, address_id);
                logger.error("sql_group1:{}", sql_group1);
                if (StringUtils.isNotEmpty(sql_group1)) {
                    ResultSet rs = stmt.executeQuery(sql_group1);
                    ArrayList<String> list_name = new ArrayList<>();
                    ArrayList<String> list_adcode = new ArrayList<>();
                    while (rs.next()) {
                        String name = rs.getString("name");
                        String adcode = rs.getString("adcode");

                        list_name.add(name);
                        list_adcode.add(adcode);
                    }

                    o.setGroup_name(list_name.size() > 0 ? String.join("$", list_name) : "");
                    o.setGroup_adcode(list_adcode.size() > 0 ? String.join("$", list_adcode) : "");
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return o;
    }

    public String replaceSplit(String split_info, String city, List<String> config_list) {
        ArrayList<String> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(split_info)) {
            for (String s : split_info.split(",")) {
                if (StringUtils.isNotEmpty(s) && s.split("\\^").length >= 2) {
                    String word = s.split("\\^")[0];
                    String level = s.split("\\^")[1];

                    String prefix = level.substring(0, 1);
                    String after = level.substring(1, level.length());

                    if (StringUtils.isNotEmpty(prefix) && Integer.parseInt(prefix) >= 1 && Integer.parseInt(prefix) <= 5) {
                        if (StringUtils.equals(after, "14")) {
                            if (word.matches("^[a-z0-9A-Z]+$")) {
                                word = word + "号楼";
                            } else {
                                word = word.replaceAll("栋|号|幢|座", "号楼");
                            }
                        }

                        if (StringUtils.equals(after, "13")) {
                            word = word.replaceAll("小区|住宅楼|住宅区|校区|科技有限公司|有限责任公司|科技股份公司|股份有限公司|有限公司|科技公司|分公司|公司", "").replace(city, "");
                            for (String config : config_list) {
                                String[] split = config.split(",");
                                int flag = 0;
                                for (String s1 : split) {
                                    if (StringUtils.equals(s1, word)) {
                                        word = split[split.length - 1];
                                        flag = 1;
                                        break;
                                    }
                                }
                                if (flag == 1) {
                                    break;
                                }
                            }
                        }
                    }
                    list.add(word + "^" + level);
                }
            }
        }
        return list.size() > 0 ? String.join(",", list) : "";
    }

    public boolean judge(String word, String level) {
        String prefix = level.substring(0, 1);
        String after = level.substring(1, level.length());
        if (StringUtils.isNotEmpty(prefix) && Integer.parseInt(prefix) >= 0 && Integer.parseInt(prefix) <= 5) {
            if (Integer.parseInt(prefix) == 0) {
                return false;
            }
            if (StringUtils.equals(after, "18")) {
                List<String> list = Arrays.asList("东,南,西,北,东北,东南,西北,西南,门".split(","));
                return list.contains(word);
            }
        }
        return true;
    }

    public boolean judgeLevel(String level) {
        if (StringUtils.isNotEmpty(level) && level.length() == 2) {
            String after = level.substring(1, level.length());
            if (StringUtils.isNotEmpty(after) && Integer.parseInt(after) <= 5) {
                return false;
            }
        }
        return true;
    }

    public boolean judgeKey18(String word, String level) {
        String after = level.substring(1, level.length());
        if (StringUtils.equals(after, "18")) {
            List<String> list = Arrays.asList("东,南,西,北,东北,东南,西北,西南,门".split(","));
            return list.contains(word);
        }
        return true;
    }

    public String processKeyNew(String splitInfo) {
        StringBuilder result = new StringBuilder();
        if (StringUtils.isNotEmpty(splitInfo)) {
            String[] split = splitInfo.split(",");
            for (String s : split) {
                String word = s.split("\\^")[0];
                result.append(word);
            }
        }
        return result.toString();
    }

    public CmsAddress processKeyDeny14(CmsAddress o) {
        String key_split_info = o.getKey_split_info();
        if (StringUtils.isNotEmpty(key_split_info)) {
            String[] split = key_split_info.split(",");
            StringBuilder sb = new StringBuilder();
            for (String s : split) {
                String word = s.split("\\^")[0];
                String level = s.split("\\^")[1];
                String prefix = level.substring(0, 1);
                String after = level.substring(1, level.length());
                if (!StringUtils.equals(after, "14")) {
                    sb.append(word);
                }
            }
            String key_deny14 = sb.toString();
            o.setKey_deny14(key_deny14);

            if (StringUtils.isNotEmpty(key_deny14)) {
                String key_deny14_t = key_deny14.replaceAll("[0-9]+号院", "");
                o.setKey_deny14_t(key_deny14_t);
            }
        }
        return o;
    }

    public CmsAddress process13CntLevel(CmsAddress o) {
        String splitInfo = o.getKey_split_info();
        if (StringUtils.isNotEmpty(splitInfo)) {
            String[] split = splitInfo.split(",");
            int key_cnt13 = 0;
            for (String s : split) {
                String level = s.split("\\^")[1];
                String prefix = level.substring(0, 1);
                String after = level.substring(1, level.length());
                if (StringUtils.isNotEmpty(prefix) && Integer.parseInt(prefix) >= 1 && Integer.parseInt(prefix) <= 5 && StringUtils.equals(after, "13")) {
                    key_cnt13++;
                }
            }
            o.setKey_cnt13(key_cnt13 + "");
        }
        return o;
    }

    public CmsAddress process14Level(CmsAddress o) {
        String splitInfo = o.getKey_split_info();
        if (StringUtils.isNotEmpty(splitInfo)) {
            String[] split = splitInfo.split(",");
            for (String s : split) {
                String word = s.split("\\^")[0];
                String level = s.split("\\^")[1];
                if (StringUtils.isNotEmpty(level) && StringUtils.equals(level.substring(1, level.length()), "14")) {
                    if (StringUtils.isNotEmpty(word)) {
                        String key_14 = word.replaceAll("[^(a-zA-Z0-9)]", "");
                        o.setKey_14(key_14);
                    }
                }
            }
        }
        return o;
    }

    public CmsAddress process13Level(CmsAddress o) {
        String splitInfo = o.getKey_split_info();
        if (StringUtils.isNotEmpty(splitInfo)) {
            ArrayList<String> list = new ArrayList<>();
            if (contains13(splitInfo)) {
                String[] split = splitInfo.split(",");
                for (String s : split) {
                    String word = s.split("\\^")[0];
                    String level = s.split("\\^")[1];
                    if (!(StringUtils.isNotEmpty(word) && (word.contains("路") || word.contains("号")))) {
                        list.add(word + "^" + level);
                    }
                }
                o.setKey_split_info(list.size() > 0 ? String.join(",", list) : "");
            }
        }
        return o;
    }

    public boolean contains13(String splitInfo) {
        String[] split = splitInfo.split(",");
        for (String s : split) {
            String level = s.split("\\^")[1];
            if (StringUtils.isNotEmpty(level) && !StringUtils.equals(level, "613") && StringUtils.equals(level.substring(1, level.length()), "13")) {
                return true;
            }
        }
        return false;
    }

    public CmsAddressDuplicate copy(CmsAddressDuplicate o, CmsAddress a, CmsAddress b, String flag) {
        o.setAddress_id_a(a.getAddress_id());
        o.setAddress_md5_a(a.getAddress_md5());
        o.setAddress_a(a.getAddress());
        o.setKeyword_a(a.getKeyword());
        o.setZno_code_a(a.getZno_code());
        o.setReceipt_zno_code_a(a.getReceipt_zno_code());
        o.setX_a(a.getX());
        o.setY_a(a.getY());
        o.setType_a(a.getType());
        o.setDelivery_type_a(a.getDelivery_type());
        o.setStatus_a(a.getStatus());
        o.setAoi_id_a(a.getAoi_id());
        o.setSrc_a(a.getSrc());
        o.setAoi_code_a(a.getAoi_code());
        o.setAoi_name_a(a.getAoi_name());
        o.setFa_type_a(a.getFa_type());
        o.setAoi_area_code_a(a.getAoi_area_code());
        o.setGroup_alias_a(a.getGroup_alias());
        o.setGroup_type_a(a.getGroup_type());
        o.setGroup_name_a(a.getGroup_name());
        o.setGroup_adcode_a(a.getGroup_adcode());
        o.setAddress_split_info_a(a.getAddress_split_info());
        o.setKey_split_info_a(a.getKey_split_info());
        o.setMax_split_addr_a(a.getMax_split_addr());
        o.setMax_split_key_a(a.getMax_split_key());
        o.setKey_14_a(a.getKey_14());
        o.setKey_cnt13_a(a.getKey_cnt13());
        o.setKey_deny14_a(a.getKey_deny14());
        o.setKey_deny14_t_a(a.getKey_deny14_t());
        o.setAddress_new_a(a.getAddress_new());
        o.setKey_new_a(a.getKey_new());
        o.setAddress_new_sp_a(a.getAddress_new_sp());
        o.setKey_new_sp_a(a.getKey_new_sp());
        o.setKey_deny14_t_sp_a(a.getKey_deny14_t_sp());
        o.setAddress_new_qp_a(a.getAddress_new_qp());
        o.setKey_new_qp_a(a.getKey_new_qp());
        o.setKey_deny14_t_qp_a(a.getKey_deny14_t_qp());

        o.setAddress_id_b(b.getAddress_id());
        o.setAddress_md5_b(b.getAddress_md5());
        o.setAddress_b(b.getAddress());
        o.setKeyword_b(b.getKeyword());
        o.setZno_code_b(b.getZno_code());
        o.setReceipt_zno_code_b(b.getReceipt_zno_code());
        o.setX_b(b.getX());
        o.setY_b(b.getY());
        o.setType_b(b.getType());
        o.setDelivery_type_b(b.getDelivery_type());
        o.setStatus_b(b.getStatus());
        o.setAoi_id_b(b.getAoi_id());
        o.setSrc_b(b.getSrc());
        o.setAoi_code_b(b.getAoi_code());
        o.setAoi_name_b(b.getAoi_name());
        o.setFa_type_b(b.getFa_type());
        o.setAoi_area_code_b(b.getAoi_area_code());
        o.setGroup_alias_b(b.getGroup_alias());
        o.setGroup_type_b(b.getGroup_type());
        o.setGroup_name_b(b.getGroup_name());
        o.setGroup_adcode_b(b.getGroup_adcode());
        o.setAddress_split_info_b(b.getAddress_split_info());
        o.setKey_split_info_b(b.getKey_split_info());
        o.setMax_split_addr_b(b.getMax_split_addr());
        o.setMax_split_key_b(b.getMax_split_key());
        o.setKey_14_b(b.getKey_14());
        o.setKey_cnt13_b(b.getKey_cnt13());
        o.setKey_deny14_b(b.getKey_deny14());
        o.setKey_deny14_t_b(b.getKey_deny14_t());
        o.setAddress_new_b(b.getAddress_new());
        o.setKey_new_b(b.getKey_new());
        o.setAddress_new_sp_b(b.getAddress_new_sp());
        o.setKey_new_sp_b(b.getKey_new_sp());
        o.setKey_deny14_t_sp_b(b.getKey_deny14_t_sp());
        o.setAddress_new_qp_b(b.getAddress_new_qp());
        o.setKey_new_qp_b(b.getKey_new_qp());
        o.setKey_deny14_t_qp_b(b.getKey_deny14_t_qp());

        if (StringUtils.equals(flag, "stdaddr")) {
            o.setTag("标准地址一致");
        } else if (StringUtils.equals(flag, "key")) {
            o.setTag(b.getTag());
            o.setDistance_xy(b.getDistance_xy() + "");
            o.setDistance_aoi(b.getDistance_aoi() + "");
        }

        o.setInc_day(a.getInc_day());
        o.setCity_code(a.getCity_code());
        return o;
    }


    public String convertHanzi2Pinyin(String hanzi, boolean full) {
        /***
         * ^[\u2E80-\u9FFF]+$ 匹配所有东亚区的语言
         * ^[\u4E00-\u9FFF]+$ 匹配简体和繁体
         * ^[\u4E00-\u9FA5]+$ 匹配简体
         */
        String regExp = "^[\u4E00-\u9FFF]+$";
        StringBuffer sb = new StringBuffer();
        if (hanzi == null || "".equals(hanzi.trim())) {
            return "";
        }
        String pinyin = "";
        for (int i = 0; i < hanzi.length(); i++) {
            char unit = hanzi.charAt(i);
            if (match(String.valueOf(unit), regExp))//是汉字，则转拼音
            {
                pinyin = convertSingleHanzi2Pinyin(unit);
                if (full) {
                    sb.append(pinyin.toUpperCase());
                } else {
                    sb.append((pinyin.charAt(0) + "").toUpperCase());
                }
            } else {
                sb.append(unit);
            }
        }
        return sb.toString();
    }

    /***
     * 将单个汉字转成拼音
     * @param hanzi
     * @return
     */
    private String convertSingleHanzi2Pinyin(char hanzi) {
        HanyuPinyinOutputFormat outputFormat = new HanyuPinyinOutputFormat();
        outputFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        String[] res;
        StringBuffer sb = new StringBuffer();
        try {
            res = PinyinHelper.toHanyuPinyinStringArray(hanzi, outputFormat);
            sb.append(res[0]);//对于多音字，只用第一个拼音
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        return sb.toString();
    }

    /***
     * @param str 源字符串
     * @param regex 正则表达式
     * @return 是否匹配
     */
    public boolean match(String str, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    public String getMatch(String str, String regex) {
        StringBuilder sb = new StringBuilder();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            sb.append(matcher.group());
        }
        return sb.toString();
    }
}
