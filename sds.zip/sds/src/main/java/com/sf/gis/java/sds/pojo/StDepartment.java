package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class StDepartment implements Serializable {
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "depart_code")
    private String depart_code;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "is_fixed")
    private String is_fixed;
    @Column(name = "type_code")
    private String type_code;

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getDepart_code() {
        return depart_code;
    }

    public void setDepart_code(String depart_code) {
        this.depart_code = depart_code;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getIs_fixed() {
        return is_fixed;
    }

    public void setIs_fixed(String is_fixed) {
        this.is_fixed = is_fixed;
    }

    public String getType_code() {
        return type_code;
    }

    public void setType_code(String type_code) {
        this.type_code = type_code;
    }
}
