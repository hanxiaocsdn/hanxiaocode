package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.DruidManager;
import com.sf.gis.java.sds.db.GislgDbManager;
import com.sf.gis.java.sds.pojo.WrongDataDiff;
import com.sf.gis.java.sds.service.impl.IWrongDataDiffService;
import com.sf.gis.java.sds.utils.IDGenerator;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;

public class WrongDataDiffService extends BaseService implements IWrongDataDiffService {
    private static final Logger logger = LoggerFactory.getLogger(WrongDataDiffService.class);

    DruidManager druidManager;

    public WrongDataDiffService() {
        druidManager = GislgDbManager.getInstance().getDruidManager();
    }

    public final static String TABLE_NAME = "sss_gis_diff_origin_data_by_day";

    private final String[] columns = {"id", "unique_md5", "address", "sss_dept", "gis_dept", "origin_src", "data_time",
            "frequency", "type", "deptcode", "arssDeptCode", "city_code", "waybillNo", "is_done"};

    @Override
    public void insert(List<WrongDataDiff> list) throws Exception {
        druidManager.excuBatch(list, 5000, new com.sf.gis.java.sds.db.DruidManager.ExcuBatchListener() {
            @Override
            public String createSql() {
                StringBuilder sb = new StringBuilder();
                String insertSql = druidManager.crateIgnoreInsertSqlWithOutValue(columns, TABLE_NAME);
                sb.append(insertSql);
                return sb.toString();
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);
                for (int i = 0; i < columns.length; i++) {
                    if (columns[i].equals("id")) {
                        stmt.setString(i + 1, IDGenerator.getID());
                    } else {
                        stmt.setString(i + 1, (String) map.get(columns[i]));
                    }
                }
            }
        });
    }

    @Override
    public void createTable() {
        StringBuilder sb = new StringBuilder("create table IF NOT EXISTS " + TABLE_NAME + "(");
        for (String column : columns) {
            if (column.equals("address")) {
                sb.append(column + " text  ,");
            } else {
                sb.append(column + " VARCHAR(50)  ,");
            }
        }
        sb.append("CREATE_TIME  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,");
        sb.append("UPDATE_TIME  timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP ,");
        sb.append(" PRIMARY KEY ( id ) ");
        sb.append(")ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        logger.error(sb.toString());
        druidManager.update(sb.toString());
    }

    @Override
    public void deleteData(String date, String cityCodes) {
        String deleteSql = "delete from " + TABLE_NAME + " where data_time = '" + date + "' ";
        if (cityCodes != null) {
            deleteSql += " and city_code in " + cityCodes;
        }
        logger.error("delete today:" + deleteSql);
        druidManager.update(deleteSql);
    }

}