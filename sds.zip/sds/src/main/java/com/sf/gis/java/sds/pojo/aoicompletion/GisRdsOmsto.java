package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GisRdsOmsto implements Serializable {
    @Column(name = "req_orderno")
    private String req_orderno;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoiid")
    private String finalaoiid;

    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_addresseecontacts")
    private String req_addresseecontacts;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "req_addresseemobile")
    private String req_addresseemobile;
    @Column(name = "splitresult")
    private String splitresult;

    private String level45Word;
    private String l45_waybill;
    private double freq45_waybill;

    public String getL45_waybill() {
        return l45_waybill;
    }

    public void setL45_waybill(String l45_waybill) {
        this.l45_waybill = l45_waybill;
    }

    public double getFreq45_waybill() {
        return freq45_waybill;
    }

    public void setFreq45_waybill(double freq45_waybill) {
        this.freq45_waybill = freq45_waybill;
    }

    public String getLevel45Word() {
        return level45Word;
    }

    public void setLevel45Word(String level45Word) {
        this.level45Word = level45Word;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getReq_addresseecontacts() {
        return req_addresseecontacts;
    }

    public void setReq_addresseecontacts(String req_addresseecontacts) {
        this.req_addresseecontacts = req_addresseecontacts;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getReq_addresseemobile() {
        return req_addresseemobile;
    }

    public void setReq_addresseemobile(String req_addresseemobile) {
        this.req_addresseemobile = req_addresseemobile;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getReq_orderno() {
        return req_orderno;
    }

    public void setReq_orderno(String req_orderno) {
        this.req_orderno = req_orderno;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }
}
