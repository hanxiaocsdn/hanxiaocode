package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsIndexStat implements Serializable {
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "type")
    private String type;
    @Column(name = "total_num")
    private String total_num;
    @Column(name = "lock_num")
    private String lock_num;
    @Column(name = "ad1_num")
    private String ad1_num;
    @Column(name = "ad4_num")
    private String ad4_num;
    @Column(name = "ad5_num")
    private String ad5_num;
    @Column(name = "ad6_num")
    private String ad6_num;
    @Column(name = "ad7_num")
    private String ad7_num;
    @Column(name = "ad8_num")
    private String ad8_num;
    @Column(name = "ad9_num")
    private String ad9_num;
    @Column(name = "ad10_num")
    private String ad10_num;
    @Column(name = "ad11_num")
    private String ad11_num;
    @Column(name = "other_ad_num")
    private String other_ad_num;
    @Column(name = "addr_lock_num")
    private String addr_lock_num;
    @Column(name = "inc_day")
    private String inc_day;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTotal_num() {
        return total_num;
    }

    public void setTotal_num(String total_num) {
        this.total_num = total_num;
    }

    public String getLock_num() {
        return lock_num;
    }

    public void setLock_num(String lock_num) {
        this.lock_num = lock_num;
    }

    public String getAd1_num() {
        return ad1_num;
    }

    public void setAd1_num(String ad1_num) {
        this.ad1_num = ad1_num;
    }

    public String getAd4_num() {
        return ad4_num;
    }

    public void setAd4_num(String ad4_num) {
        this.ad4_num = ad4_num;
    }

    public String getAd5_num() {
        return ad5_num;
    }

    public void setAd5_num(String ad5_num) {
        this.ad5_num = ad5_num;
    }

    public String getAd6_num() {
        return ad6_num;
    }

    public void setAd6_num(String ad6_num) {
        this.ad6_num = ad6_num;
    }

    public String getAd7_num() {
        return ad7_num;
    }

    public void setAd7_num(String ad7_num) {
        this.ad7_num = ad7_num;
    }

    public String getAd8_num() {
        return ad8_num;
    }

    public void setAd8_num(String ad8_num) {
        this.ad8_num = ad8_num;
    }

    public String getAd9_num() {
        return ad9_num;
    }

    public void setAd9_num(String ad9_num) {
        this.ad9_num = ad9_num;
    }

    public String getAd10_num() {
        return ad10_num;
    }

    public void setAd10_num(String ad10_num) {
        this.ad10_num = ad10_num;
    }

    public String getAd11_num() {
        return ad11_num;
    }

    public void setAd11_num(String ad11_num) {
        this.ad11_num = ad11_num;
    }

    public String getOther_ad_num() {
        return other_ad_num;
    }

    public void setOther_ad_num(String other_ad_num) {
        this.other_ad_num = other_ad_num;
    }

    public String getAddr_lock_num() {
        return addr_lock_num;
    }

    public void setAddr_lock_num(String addr_lock_num) {
        this.addr_lock_num = addr_lock_num;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
