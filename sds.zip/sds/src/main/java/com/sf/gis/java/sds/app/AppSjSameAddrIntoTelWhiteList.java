package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SjSameAddrIntoTelWhiteListController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 需求：收件下柯缺失的重复地址入电话白名单库
 * 需求方：陈袁（01421176）
 * 研发：匡仁衡（01399581）
 * 开发日期：2023-06-15
 * 任务id:769766
 */
public class AppSjSameAddrIntoTelWhiteList {
    private static Logger logger = LoggerFactory.getLogger(AppSjSameAddrIntoTelWhiteList.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new SjSameAddrIntoTelWhiteListController().start(date);
        logger.error("run end");
    }
}
