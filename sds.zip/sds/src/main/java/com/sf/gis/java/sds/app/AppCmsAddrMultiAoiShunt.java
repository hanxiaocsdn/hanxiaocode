package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CmsAddrMultiAoiShunt;
import com.sf.gis.java.sds.pojo.PrescriptionQualifiedRate;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sf.gis.java.base.util.StringNumUtils.fixnulltoStr;


/**
 * 任务id:874599(CMS地址多aoi分流)
 * 业务方：01394694（郭本婕）
 * 研发：01399581（匡仁衡）
 * 时间：2023年10月23日17:53:41
 */
public class AppCmsAddrMultiAoiShunt {
    private static Logger logger = LoggerFactory.getLogger(AppCmsAddrMultiAoiShunt.class);
    private static String splitUrl = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=87106f6380af4df0845a693eee58843c";

    public static void main(String[] args) {
        String date = args[0];
        String city_codes = args[1];
        logger.error("date:{}", date);
        logger.error("city_codes:{}", city_codes);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSplitAoiNameCheckCleanAddr");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");
        JavaRDD<CmsAoiSch> cmsRdd = getcmsRdd(spark, sc);
        for (String city_code : city_codes.split(",")) {
            logger.error("city_code:{}", city_code);
            logger.error("获取数据");
            JavaRDD<CmsAddrMultiAoiShunt> rdd = getData(spark, cityDbPro, city_code, date, cmsRdd);
            logger.error("获取aoi_name分词,以及aoi_name_new");
            JavaRDD<CmsAddrMultiAoiShunt> splitAndNameRdd = getSplitAndAoiNameNew(rdd);
            logger.error("按照zno_code和aoi_name_new分组判断");
            JavaRDD<CmsAddrMultiAoiShunt> tagRdd = groupByZnoCodeAndAoiNameNew(splitAndNameRdd);
            logger.error("打标判断");
            JavaRDD<CmsAddrMultiAoiShunt> lastRdd = getTag(tagRdd);
            logger.error("结果数据存储");
            spark.sql(String.format("alter table dm_gis.cms_addr_multi_aoi_shunt drop if EXISTS partition(inc_day='%s',city_code='%s')", date, city_code));
            DataUtil.saveInto(spark, sc, "dm_gis.cms_addr_multi_aoi_shunt", CmsAddrMultiAoiShunt.class, lastRdd, "inc_day", "city_code");
            lastRdd.unpersist();
            logger.error("process city_code:{}, end...", city_code);
        }
        cmsRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static JavaRDD<CmsAoiSch> getcmsRdd(SparkSession spark, JavaSparkContext sc) {
        String aoi_name_sql = "select\n" +
                "  a.aoi_id aoi_id,\n" +
                "  a.aoi_name aoi_name,\n" +
                "  a.zno_code zno_code,\n" +
                "  b.p_fa_name fa_type\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      aoi_id,\n" +
                "      aoi_name,\n" +
                "      zno_code,\n" +
                "      fa_type\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_sch\n" +
                "    where\n" +
                "      city_code not in ('886', '853', '852')\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      fa_type,\n" +
                "      p_fa_name\n" +
                "    from\n" +
                "      dm_gis.aoi_fa_type_info\n" +
                "    where\n" +
                "      source = 'PRC'\n" +
                "  ) b on a.fa_type = b.fa_type\n" +
                "union all\n" +
                "select\n" +
                "  c.aoi_id aoi_id,\n" +
                "  c.aoi_name aoi_name,\n" +
                "  c.zno_code zno_code,\n" +
                "  d.p_fa_name fa_type\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      aoi_id,\n" +
                "      aoi_name,\n" +
                "      zno_code,\n" +
                "      fa_type\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_sch\n" +
                "    where\n" +
                "      city_code in ('886', '853', '852')\n" +
                "  ) c\n" +
                "  left join (\n" +
                "    select\n" +
                "      fa_type,\n" +
                "      p_fa_name\n" +
                "    from\n" +
                "      dm_gis.aoi_fa_type_info\n" +
                "    where\n" +
                "      source = 'HK'\n" +
                "  ) d on c.fa_type = d.fa_type";
        JavaRDD<CmsAoiSch> cmsRdd = DataUtil.loadData(spark, sc, aoi_name_sql, CmsAoiSch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());
        return cmsRdd;
    }

    public static JavaRDD<CmsAddrMultiAoiShunt> getTag(JavaRDD<CmsAddrMultiAoiShunt> tagRdd) {
        JavaPairRDD<String, Iterable<CmsAddrMultiAoiShunt>> pairRdd = tagRdd.mapToPair(o -> new Tuple2<>(o.getZno_code() + "_" + o.getAoi_name_new(), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("pairRdd cnt:{}", pairRdd.count());
        tagRdd.unpersist();

        logger.error("过滤出组内有无true的tag");
        JavaRDD<CmsAddrMultiAoiShunt> trueRdd = pairRdd.filter(tp -> Lists.newArrayList(tp._2).stream().anyMatch(o -> StringUtils.equals("true", o.getTag()))).flatMap(tp -> tp._2.iterator()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CmsAddrMultiAoiShunt> noTrueRdd = pairRdd.filter(tp -> Lists.newArrayList(tp._2).stream().noneMatch(o -> StringUtils.equals("true", o.getTag()))).flatMap(tp -> tp._2.iterator()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trueRdd cnt:{},noTrueRdd cnt:{}", trueRdd.count(), noTrueRdd.count());
        pairRdd.unpersist();

        JavaRDD<CmsAddrMultiAoiShunt> cntYesRdd = trueRdd.filter(AppCmsAddrMultiAoiShunt::judge).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CmsAddrMultiAoiShunt> cntNoRdd = trueRdd.filter(o -> !judge(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cntYesRdd cnt:{},cntNoRdd cnt:{}", cntYesRdd.count(), cntNoRdd.count());
        trueRdd.unpersist();

        logger.error("生成address_split");
        JavaRDD<CmsAddrMultiAoiShunt> splitContainRdd = cntYesRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getCity_code(), o)).groupByKey(5).flatMap(tp -> {
            List<CmsAddrMultiAoiShunt> list = Lists.newArrayList(tp._2);
            CmsAddrMultiAoiShunt o = list.get(0);
            String address = o.getAddress();
            String city_code = o.getCity_code();
            String address_split = "";
            String split_contain = "false";
            if (StringUtils.isNotEmpty(address)) {
                address_split = getSplit(address, city_code);
                List<String> levelList = getLevelList(address_split);
                if (levelList.size() > 0 && ((levelList.contains("9") && levelList.contains("11")) || (levelList.contains("14")))) {
                    split_contain = "true";
                }
            }
            String finalAddress_split = address_split;
            String finalSplit_contain = split_contain;
            return list.stream().peek(t -> {
                t.setAddress_split(finalAddress_split);
                t.setSplit_contain(finalSplit_contain);
            }).iterator();
        }).repartition(SysConstant.THREAD_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitContainRdd cnt:{}", splitContainRdd.count());
        cntYesRdd.unpersist();

        JavaRDD<CmsAddrMultiAoiShunt> splitContainTrueRdd = splitContainRdd.filter(o -> StringUtils.equals("true", o.getSplit_contain())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CmsAddrMultiAoiShunt> splitContainFalseRdd = splitContainRdd.filter(o -> StringUtils.equals("false", o.getSplit_contain())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitContainTrueRdd cnt:{}, splitContainFalseRdd cnt:{}", splitContainTrueRdd.count(), splitContainFalseRdd.count());
        splitContainRdd.unpersist();

        JavaRDD<CmsAddrMultiAoiShunt> addrMutiAoiRdd = splitContainFalseRdd.filter(o -> !o.getAoi_name().contains("加油站") && !o.getAoi_name().contains("中国石化")).map(o -> {
            o.setTag("地址多AOI_新增");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrMutiAoiRdd cnt:{}", addrMutiAoiRdd.count());
        splitContainFalseRdd.unpersist();

        JavaRDD<CmsAddrMultiAoiShunt> lastRdd = noTrueRdd.union(cntNoRdd).union(splitContainTrueRdd).map(o -> {
            String extend_attach2 = o.getExtend_attach2();
            if (StringUtils.equals(extend_attach2, "2")) {
                o.setTag("地址不详");
            } else if (StringUtils.equals(extend_attach2, "9")) {
                o.setTag("地址多AOI");
            }
            return o;
        }).union(addrMutiAoiRdd)
                .filter(o -> StringUtils.isNotEmpty(o.getTag()) && Arrays.asList("地址不详,地址多AOI,地址多AOI_新增".split(",")).contains(o.getTag()))
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        noTrueRdd.unpersist();
        cntNoRdd.unpersist();
        splitContainTrueRdd.unpersist();
        addrMutiAoiRdd.unpersist();
        return lastRdd;
    }

    public static List<String> getLevelList(String address_split) {
        ArrayList<String> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(address_split)) {
            String[] split = address_split.split("\\|");
            for (String s : split) {
                String[] split1 = s.split("\\^");
                if (split1.length >= 2) {
                    String name = split1[0];
                    String level = split1[1];
                    String before = level.substring(0, 1);
                    String after = level.substring(1, level.length());
                    list.add(after);
                }
            }
        }
        return list;
    }

    public static boolean judge(CmsAddrMultiAoiShunt o) {
        int type_cnt = StringUtils.isNotEmpty(o.getType_cnt()) ? Integer.parseInt(o.getType_cnt()) : 0;
        int aoi_cnt = StringUtils.isNotEmpty(o.getAoi_cnt()) ? Integer.parseInt(o.getAoi_cnt()) : 0;
        String tag = o.getTag();
        if ((type_cnt == 1 && StringUtils.equals(tag, "true")) || (type_cnt > 1 && aoi_cnt > 3 && StringUtils.equals(tag, "true"))) {
            return true;
        }
        return false;
    }

    public static JavaRDD<CmsAddrMultiAoiShunt> groupByZnoCodeAndAoiNameNew(JavaRDD<CmsAddrMultiAoiShunt> splitAndNameRdd) {
        JavaRDD<CmsAddrMultiAoiShunt> tagRdd = splitAndNameRdd.mapToPair(o -> new Tuple2<>(o.getZno_code() + "_" + o.getAoi_name_new(), o)).groupByKey().flatMap(tp -> {
            List<CmsAddrMultiAoiShunt> list = Lists.newArrayList(tp._2);
            int aoi_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_id()))
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAddrMultiAoiShunt::getAoi_id))), ArrayList::new))
                    .size();

            int type_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_type()))
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAddrMultiAoiShunt::getAoi_type))), ArrayList::new))
                    .size();

            List<CmsAddrMultiAoiShunt> tagList = list.stream().peek(o -> {
                String address = o.getAddress();
                String aoi_name_new = o.getAoi_name_new();
                String tag = "false";
                if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(aoi_name_new) && address.endsWith(aoi_name_new) && aoi_cnt > 1) {
                    tag = "true";
                }
                o.setTag(tag);
                o.setAoi_cnt(aoi_cnt + "");
                o.setType_cnt(type_cnt + "");
            }).collect(Collectors.toList());
            return tagList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:{}", tagRdd.count());
        splitAndNameRdd.unpersist();
        return tagRdd;
    }

    public static JavaRDD<CmsAddrMultiAoiShunt> getSplitAndAoiNameNew(JavaRDD<CmsAddrMultiAoiShunt> rdd) {
        JavaRDD<CmsAddrMultiAoiShunt> splitAndNameRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAoi_name() + "_" + o.getCity_code(), o)).groupByKey(5).flatMap(tp -> {
            List<CmsAddrMultiAoiShunt> list = Lists.newArrayList(tp._2);
            CmsAddrMultiAoiShunt o = list.get(0);
            String aoi_name = o.getAoi_name();
            String city_code = o.getCity_code();
            String aoi_name_split = "";
            if (StringUtils.isNotEmpty(aoi_name)) {
                aoi_name_split = getSplit(aoi_name, city_code);
            }
            String finalAoi_name_split = aoi_name_split;
            return list.stream().peek(t -> t.setAoi_name_split(finalAoi_name_split)).iterator();
        }).repartition(SysConstant.THREAD_COUNT).filter(o -> StringUtils.isNotEmpty(o.getAoi_name_split())).map(o -> {
            String aoi_name_split = o.getAoi_name_split();
            o.setAoi_name_new(getAoiNameNew(aoi_name_split));
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitAndNameRdd cnt:{}", splitAndNameRdd.count());
        rdd.unpersist();
        return splitAndNameRdd;
    }

    public static String getAoiNameNew(String aoi_name_split) {
        String[] split = aoi_name_split.split("\\|");
        String big_than_3 = "";
        for (int i = 0; i < split.length; i++) {
            String s = split[i];
            String[] split1 = s.split("\\^");
            if (split1.length >= 2) {
                String name = split1[0];
                String level = split1[1];
                String before = level.substring(0, 1);
                String after = level.substring(1, level.length());

                if (Arrays.asList("1,2,3,4".split(",")).contains(before) && StringUtils.equals("13", after)) {
                    if (name.matches(".住宅区|.工业区")) {
                        if (i != 0) {
                            return split[i - 1].split("\\^")[0];
                        } else {
                            return name;
                        }
                    } else {
                        return name;
                    }
                }

                if (StringUtils.isEmpty(big_than_3) && Integer.parseInt(after) > 3) {
                    big_than_3 = name;
                }
            }
        }
        return big_than_3;
    }

    public static boolean match(String str, String regex) {
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    public static String getSplit(String text, String city_code) {
        String split = "";
        try {
            String req = String.format(splitUrl, URLEncoder.encode(text, "UTF-8"), city_code);
            String res = HttpInvokeUtil.sendGet(req);
            split = getSplit(res);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return split;
    }

    public static String getSplit(String content) {
        ArrayList<String> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(content)) {
            try {
                JSONArray info = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("info");
                for (int i = 0; i < info.size(); i++) {
                    JSONObject jsonObject = info.getJSONObject(i);
                    String level = jsonObject.getString("level");
                    String name = jsonObject.getString("name");
                    String prop = jsonObject.getString("prop");
                    list.add(name + "^" + prop + level);
                }
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return list.size() > 0 ? String.join("|", list) : "";
    }

    public static JavaRDD<CmsAddrMultiAoiShunt> getData(SparkSession spark, Properties cityDbPro, String city_code, String date, JavaRDD<CmsAoiSch> cmsRdd) {
        String number = cityDbPro.getProperty(city_code);
        String table = "wchka.cms_address_" + number;
        logger.error("city:{},table:{}", city_code, table);
        String condition = String.format("city_code = '%s' and del_flag = 0", city_code);
        logger.error("condition:{}", condition);

        JavaRDD<CmsAddrMultiAoiShunt> rdd = spark.read().format("jdbc")
                .option("driver", "com.mysql.jdbc.Driver")
                .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                .option("dbtable", table)
                .option("user", "wchka_aoi")
                .option("password", "giscmsaoi123")
                .load()
                .where(condition)
                .select("city_code", "address", "address_id", "address_md5", "aoi_id", "type", "zno_code", "adcode", "extend_attach2")
                .toJavaRDD()
                .map(row -> {
                    CmsAddrMultiAoiShunt o = new CmsAddrMultiAoiShunt();

                    String city = "";
                    try {
                        city = row.getString(0);
                    } catch (Exception e) {
                    }

                    String address = "";
                    try {
                        address = row.getString(1);
                    } catch (Exception e) {
                    }

                    String address_id = "";
                    try {
                        address_id = row.getString(2);
                    } catch (Exception e) {
                    }

                    String address_md5 = "";
                    try {
                        address_md5 = row.getString(3);
                    } catch (Exception e) {
                    }

                    String aoi_id = "";
                    try {
                        aoi_id = row.getString(4);
                    } catch (Exception e) {
                    }

                    String type = "";
                    try {
                        type = row.getInt(5) + "";
                    } catch (Exception e) {
                    }

                    String zno_code = "";
                    try {
                        zno_code = row.getString(6);
                    } catch (Exception e) {
                    }

                    String adcode = "";
                    try {
                        adcode = row.getString(7);
                    } catch (Exception e) {
                    }

                    String extend_attach2 = "";
                    try {
                        extend_attach2 = row.getString(8);
                    } catch (Exception e) {
                    }
                    o.setCity_code(fixnulltoStr(city));
                    o.setAddress(fixnulltoStr(address));
                    o.setAddress_id(fixnulltoStr(address_id));
                    o.setAddress_md5(fixnulltoStr(address_md5));
                    o.setAoi_id(fixnulltoStr(aoi_id));
                    o.setType(fixnulltoStr(type));
                    o.setZno_code(fixnulltoStr(zno_code));
                    o.setAdcode(adcode);
                    o.setExtend_attach2(extend_attach2);
                    o.setInc_day(date);
                    return o;
                }).filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(cmsRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                    CmsAddrMultiAoiShunt o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setAoi_name(cmsAoiSch.getAoi_name());
                        o.setAoi_type(cmsAoiSch.getFa_type());
                    }
                    return o;
                }).filter(o -> StringUtils.isNotEmpty(o.getAoi_name())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        return rdd;
    }

}
