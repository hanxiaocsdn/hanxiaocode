package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class KySbClear implements Serializable {
    @Column(name = "citycode")
    private String city_code;
    private String aoi_id;
    @Column(name = "address")
    private String address;
    private String tc;

    private String tc_new;
    private String gd_x;
    private String gd_y;
    private String precision_gd;
    private String mapa_x;
    private String mapa_y;
    private String precision_mapa;
    private String tc1;
    private String tc2;
    private String tc3;
    private String aoi;

    @Column(name = "tag")
    private String tag;
    @Column(name = "zno_code")
    private String zno_code;

    private String tempFlag;
    @Column(name = "check_aoi_id")
    private String check_aoi_id;
    private String check_tc;

    public String getCheck_tc() {
        return check_tc;
    }

    public void setCheck_tc(String check_tc) {
        this.check_tc = check_tc;
    }

    public String getCheck_aoi_id() {
        return check_aoi_id;
    }

    public void setCheck_aoi_id(String check_aoi_id) {
        this.check_aoi_id = check_aoi_id;
    }

    public String getTempFlag() {
        return tempFlag;
    }

    public void setTempFlag(String tempFlag) {
        this.tempFlag = tempFlag;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getMapa_x() {
        return mapa_x;
    }

    public void setMapa_x(String mapa_x) {
        this.mapa_x = mapa_x;
    }

    public String getMapa_y() {
        return mapa_y;
    }

    public void setMapa_y(String mapa_y) {
        this.mapa_y = mapa_y;
    }

    public String getPrecision_mapa() {
        return precision_mapa;
    }

    public void setPrecision_mapa(String precision_mapa) {
        this.precision_mapa = precision_mapa;
    }

    public String getTc1() {
        return tc1;
    }

    public void setTc1(String tc1) {
        this.tc1 = tc1;
    }

    public String getTc2() {
        return tc2;
    }

    public void setTc2(String tc2) {
        this.tc2 = tc2;
    }

    public String getTc3() {
        return tc3;
    }

    public void setTc3(String tc3) {
        this.tc3 = tc3;
    }

    public String getGd_x() {
        return gd_x;
    }

    public void setGd_x(String gd_x) {
        this.gd_x = gd_x;
    }

    public String getGd_y() {
        return gd_y;
    }

    public void setGd_y(String gd_y) {
        this.gd_y = gd_y;
    }

    public String getPrecision_gd() {
        return precision_gd;
    }

    public void setPrecision_gd(String precision_gd) {
        this.precision_gd = precision_gd;
    }

    public String getTc_new() {
        return tc_new;
    }

    public void setTc_new(String tc_new) {
        this.tc_new = tc_new;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTc() {
        return tc;
    }

    public void setTc(String tc) {
        this.tc = tc;
    }
}
