package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class KuaiYunWaybillDetailDi implements Serializable {
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "reqWaybillNo")
    private String reqWaybillNo;
    @Column(name = "reqAddress")
    private String reqAddress;
    @Column(name = "reTeamCode")
    private String reTeamCode;

    private String key_word;
    @Column(name = "aoiid")
    private String aoiid;
    private String splitResult;
    private String key_tag;
    private int count;
    private String id;
    private String tag;
    @Column(name = "aoiname")
    private String aoiName;

    private String gd_x;
    private String gd_y;
    private String precision_gd;
    private String gd_tc;

    private String mapa_x;
    private String mapa_y;
    private String precision_mapa;
    private String mapa_tc;

    private String oper;
    private String oper_time;

    @Column(name = "md5")
    private String md5;
    @Column(name = "keyword")
    private String keyWord;
    @Column(name = "tc")
    private String tc;
    @Column(name = "status")
    private String status;
    @Column(name = "statdate")
    private String statDate;

    public String getOper() {
        return oper;
    }

    public void setOper(String oper) {
        this.oper = oper;
    }

    public String getOper_time() {
        return oper_time;
    }

    public void setOper_time(String oper_time) {
        this.oper_time = oper_time;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getTc() {
        return tc;
    }

    public void setTc(String tc) {
        this.tc = tc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatDate() {
        return statDate;
    }

    public void setStatDate(String statDate) {
        this.statDate = statDate;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getMapa_x() {
        return mapa_x;
    }

    public void setMapa_x(String mapa_x) {
        this.mapa_x = mapa_x;
    }

    public String getMapa_y() {
        return mapa_y;
    }

    public void setMapa_y(String mapa_y) {
        this.mapa_y = mapa_y;
    }

    public String getPrecision_mapa() {
        return precision_mapa;
    }

    public void setPrecision_mapa(String precision_mapa) {
        this.precision_mapa = precision_mapa;
    }

    public String getMapa_tc() {
        return mapa_tc;
    }

    public void setMapa_tc(String mapa_tc) {
        this.mapa_tc = mapa_tc;
    }

    public String getGd_tc() {
        return gd_tc;
    }

    public void setGd_tc(String gd_tc) {
        this.gd_tc = gd_tc;
    }

    public String getGd_x() {
        return gd_x;
    }

    public void setGd_x(String gd_x) {
        this.gd_x = gd_x;
    }

    public String getGd_y() {
        return gd_y;
    }

    public void setGd_y(String gd_y) {
        this.gd_y = gd_y;
    }

    public String getPrecision_gd() {
        return precision_gd;
    }

    public void setPrecision_gd(String precision_gd) {
        this.precision_gd = precision_gd;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getKey_tag() {
        return key_tag;
    }

    public void setKey_tag(String key_tag) {
        this.key_tag = key_tag;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getReqWaybillNo() {
        return reqWaybillNo;
    }

    public void setReqWaybillNo(String reqWaybillNo) {
        this.reqWaybillNo = reqWaybillNo;
    }

    public String getReqAddress() {
        return reqAddress;
    }

    public void setReqAddress(String reqAddress) {
        this.reqAddress = reqAddress;
    }

    public String getReTeamCode() {
        return reTeamCode;
    }

    public void setReTeamCode(String reTeamCode) {
        this.reTeamCode = reTeamCode;
    }
}
