package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class KyGdlPackWaybillnoMonitor implements Serializable {

    @Column(name = "pickup_tm")
    private String pickup_tm;
    @Column(name = "deliver_emp_code")
    private String deliver_emp_code;
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "dest_city_code")
    private String dest_city_code;
    @Column(name = "is_check")
    private String is_check;
    @Column(name = "review_status")
    private String review_status;
    @Column(name = "pass_status")
    private String pass_status;
    @Column(name = "bomb_box")
    private String bomb_box;
    @Column(name = "source")
    private String source;
    @Column(name = "inc_day")
    private String date;

    private String addr;
    private String groupId;
    private String aoiId;
    private String floor;
    private String stdAddr;
    private String splitResult;
    private String aoiType;
    private String is_elevator_flag;
    private String aoi_is_elevator;
    private String aoi_elevator_rate;
    private String aoi_no_elevator_rate;

    private String is_elevator;
    private String is_climb;

    private String data_src;
    private String group_id;
    private String aoi_id;

    private String ky_climb;
    private String check;
    private String city;

    private double cover_ele_rate;
    private double cover_climb_rate;
    private double rightRate;

    private String id;
    private String stat_type;
    private String stat_type_content;

    private int at_cnt;
    private int elevator_cnt;
    private int climb_cnt;

    //总量
    private int cnt ;
    //匹配量
    private int match_cnt ;
    //电梯识别量
    private int elevator_distinguish_cnt ;
    //有电梯
    private int has_elevator_cnt ;
    //无电梯
    private int no_has_elevator_cnt;
    //电梯无法判断
    private int elevator_no_judge_cnt;
    //爬楼识别量：is_climb=1或0
    private int climb_distinguish_cnt ;
    //爬楼识别准确量
    private int climb_distinguish_right_cnt;
    //需要爬楼
    private int need_climb_cnt ;
    //需要爬楼准确量
    private int need_climb_right_cnt ;
    //快运爬楼审批通过
    private int ky_climb_approve_pass_cnt ;
    //快运爬楼审批驳回
    private int ky_climb_approve_reject_cnt ;
    //快运爬楼未审批
    private int ky_climb_no_approve_cnt ;
    //快运未爬楼无需审批
    private int ky_climb_no_need_approve_cnt ;
    //不需要爬楼
    private int no_need_climb_cnt;
    //不需要爬楼准确量
    private int no_need_climb_right_cnt;
    //爬楼无法判断
    private int climb_no_judge_cnt;
    //楼层识别量
    private int floor_distinguish_cnt;

    //快运未爬楼审批通过
    private int no_ky_climb_approve_pass_cnt;
    //快运未爬楼审批驳回
    private int no_ky_climb_approve_reject_cnt;
    //快运未爬楼未审批
    private int no_ky_climb_no_approve_cnt;
    //快运未爬楼无需审批
    private int no_ky_climb_no_need_approve_cnt;

    private String province;
    private String region;

    private String tag;

    public String getDeliver_emp_code() {
        return deliver_emp_code;
    }

    public void setDeliver_emp_code(String deliver_emp_code) {
        this.deliver_emp_code = deliver_emp_code;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getData_src() {
        return data_src;
    }

    public void setData_src(String data_src) {
        this.data_src = data_src;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public int getNo_ky_climb_approve_pass_cnt() {
        return no_ky_climb_approve_pass_cnt;
    }

    public void setNo_ky_climb_approve_pass_cnt(int no_ky_climb_approve_pass_cnt) {
        this.no_ky_climb_approve_pass_cnt = no_ky_climb_approve_pass_cnt;
    }

    public int getNo_ky_climb_approve_reject_cnt() {
        return no_ky_climb_approve_reject_cnt;
    }

    public void setNo_ky_climb_approve_reject_cnt(int no_ky_climb_approve_reject_cnt) {
        this.no_ky_climb_approve_reject_cnt = no_ky_climb_approve_reject_cnt;
    }

    public int getNo_ky_climb_no_approve_cnt() {
        return no_ky_climb_no_approve_cnt;
    }

    public void setNo_ky_climb_no_approve_cnt(int no_ky_climb_no_approve_cnt) {
        this.no_ky_climb_no_approve_cnt = no_ky_climb_no_approve_cnt;
    }

    public int getNo_ky_climb_no_need_approve_cnt() {
        return no_ky_climb_no_need_approve_cnt;
    }

    public void setNo_ky_climb_no_need_approve_cnt(int no_ky_climb_no_need_approve_cnt) {
        this.no_ky_climb_no_need_approve_cnt = no_ky_climb_no_need_approve_cnt;
    }

    public int getMatch_cnt() {
        return match_cnt;
    }

    public void setMatch_cnt(int match_cnt) {
        this.match_cnt = match_cnt;
    }

    public int getElevator_distinguish_cnt() {
        return elevator_distinguish_cnt;
    }

    public void setElevator_distinguish_cnt(int elevator_distinguish_cnt) {
        this.elevator_distinguish_cnt = elevator_distinguish_cnt;
    }

    public int getHas_elevator_cnt() {
        return has_elevator_cnt;
    }

    public void setHas_elevator_cnt(int has_elevator_cnt) {
        this.has_elevator_cnt = has_elevator_cnt;
    }

    public int getNo_has_elevator_cnt() {
        return no_has_elevator_cnt;
    }

    public void setNo_has_elevator_cnt(int no_has_elevator_cnt) {
        this.no_has_elevator_cnt = no_has_elevator_cnt;
    }

    public int getElevator_no_judge_cnt() {
        return elevator_no_judge_cnt;
    }

    public void setElevator_no_judge_cnt(int elevator_no_judge_cnt) {
        this.elevator_no_judge_cnt = elevator_no_judge_cnt;
    }

    public int getClimb_distinguish_cnt() {
        return climb_distinguish_cnt;
    }

    public void setClimb_distinguish_cnt(int climb_distinguish_cnt) {
        this.climb_distinguish_cnt = climb_distinguish_cnt;
    }

    public int getClimb_distinguish_right_cnt() {
        return climb_distinguish_right_cnt;
    }

    public void setClimb_distinguish_right_cnt(int climb_distinguish_right_cnt) {
        this.climb_distinguish_right_cnt = climb_distinguish_right_cnt;
    }

    public int getNeed_climb_cnt() {
        return need_climb_cnt;
    }

    public void setNeed_climb_cnt(int need_climb_cnt) {
        this.need_climb_cnt = need_climb_cnt;
    }

    public int getNeed_climb_right_cnt() {
        return need_climb_right_cnt;
    }

    public void setNeed_climb_right_cnt(int need_climb_right_cnt) {
        this.need_climb_right_cnt = need_climb_right_cnt;
    }

    public int getKy_climb_approve_pass_cnt() {
        return ky_climb_approve_pass_cnt;
    }

    public void setKy_climb_approve_pass_cnt(int ky_climb_approve_pass_cnt) {
        this.ky_climb_approve_pass_cnt = ky_climb_approve_pass_cnt;
    }

    public int getKy_climb_approve_reject_cnt() {
        return ky_climb_approve_reject_cnt;
    }

    public void setKy_climb_approve_reject_cnt(int ky_climb_approve_reject_cnt) {
        this.ky_climb_approve_reject_cnt = ky_climb_approve_reject_cnt;
    }

    public int getKy_climb_no_approve_cnt() {
        return ky_climb_no_approve_cnt;
    }

    public void setKy_climb_no_approve_cnt(int ky_climb_no_approve_cnt) {
        this.ky_climb_no_approve_cnt = ky_climb_no_approve_cnt;
    }

    public int getKy_climb_no_need_approve_cnt() {
        return ky_climb_no_need_approve_cnt;
    }

    public void setKy_climb_no_need_approve_cnt(int ky_climb_no_need_approve_cnt) {
        this.ky_climb_no_need_approve_cnt = ky_climb_no_need_approve_cnt;
    }

    public int getNo_need_climb_cnt() {
        return no_need_climb_cnt;
    }

    public void setNo_need_climb_cnt(int no_need_climb_cnt) {
        this.no_need_climb_cnt = no_need_climb_cnt;
    }

    public int getNo_need_climb_right_cnt() {
        return no_need_climb_right_cnt;
    }

    public void setNo_need_climb_right_cnt(int no_need_climb_right_cnt) {
        this.no_need_climb_right_cnt = no_need_climb_right_cnt;
    }

    public int getClimb_no_judge_cnt() {
        return climb_no_judge_cnt;
    }

    public void setClimb_no_judge_cnt(int climb_no_judge_cnt) {
        this.climb_no_judge_cnt = climb_no_judge_cnt;
    }

    public int getFloor_distinguish_cnt() {
        return floor_distinguish_cnt;
    }

    public void setFloor_distinguish_cnt(int floor_distinguish_cnt) {
        this.floor_distinguish_cnt = floor_distinguish_cnt;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public int getAt_cnt() {
        return at_cnt;
    }

    public void setAt_cnt(int at_cnt) {
        this.at_cnt = at_cnt;
    }

    public int getElevator_cnt() {
        return elevator_cnt;
    }

    public void setElevator_cnt(int elevator_cnt) {
        this.elevator_cnt = elevator_cnt;
    }

    public int getClimb_cnt() {
        return climb_cnt;
    }

    public void setClimb_cnt(int climb_cnt) {
        this.climb_cnt = climb_cnt;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getCover_ele_rate() {
        return cover_ele_rate;
    }

    public void setCover_ele_rate(double cover_ele_rate) {
        this.cover_ele_rate = cover_ele_rate;
    }

    public double getCover_climb_rate() {
        return cover_climb_rate;
    }

    public void setCover_climb_rate(double cover_climb_rate) {
        this.cover_climb_rate = cover_climb_rate;
    }

    public double getRightRate() {
        return rightRate;
    }

    public void setRightRate(double rightRate) {
        this.rightRate = rightRate;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getKy_climb() {
        return ky_climb;
    }

    public void setKy_climb(String ky_climb) {
        this.ky_climb = ky_climb;
    }

    public String getCheck() {
        return check;
    }

    public void setCheck(String check) {
        this.check = check;
    }

    public String getIs_climb() {
        return is_climb;
    }

    public void setIs_climb(String is_climb) {
        this.is_climb = is_climb;
    }

    public String getIs_elevator() {
        return is_elevator;
    }

    public void setIs_elevator(String is_elevator) {
        this.is_elevator = is_elevator;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAoi_is_elevator() {
        return aoi_is_elevator;
    }

    public void setAoi_is_elevator(String aoi_is_elevator) {
        this.aoi_is_elevator = aoi_is_elevator;
    }

    public String getAoi_elevator_rate() {
        return aoi_elevator_rate;
    }

    public void setAoi_elevator_rate(String aoi_elevator_rate) {
        this.aoi_elevator_rate = aoi_elevator_rate;
    }

    public String getAoi_no_elevator_rate() {
        return aoi_no_elevator_rate;
    }

    public void setAoi_no_elevator_rate(String aoi_no_elevator_rate) {
        this.aoi_no_elevator_rate = aoi_no_elevator_rate;
    }

    public String getIs_elevator_flag() {
        return is_elevator_flag;
    }

    public void setIs_elevator_flag(String is_elevator_flag) {
        this.is_elevator_flag = is_elevator_flag;
    }

    public String getAoiType() {
        return aoiType;
    }

    public void setAoiType(String aoiType) {
        this.aoiType = aoiType;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getStdAddr() {
        return stdAddr;
    }

    public void setStdAddr(String stdAddr) {
        this.stdAddr = stdAddr;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPickup_tm() {
        return pickup_tm;
    }

    public void setPickup_tm(String pickup_tm) {
        this.pickup_tm = pickup_tm;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getDest_city_code() {
        return dest_city_code;
    }

    public void setDest_city_code(String dest_city_code) {
        this.dest_city_code = dest_city_code;
    }

    public String getIs_check() {
        return is_check;
    }

    public void setIs_check(String is_check) {
        this.is_check = is_check;
    }

    public String getReview_status() {
        return review_status;
    }

    public void setReview_status(String review_status) {
        this.review_status = review_status;
    }

    public String getPass_status() {
        return pass_status;
    }

    public void setPass_status(String pass_status) {
        this.pass_status = pass_status;
    }

    public String getBomb_box() {
        return bomb_box;
    }

    public void setBomb_box(String bomb_box) {
        this.bomb_box = bomb_box;
    }
}
