package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.GisRdsOmsfrom;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class GisRdsOmsfromController implements Serializable {
    private Logger logger = LoggerFactory.getLogger(GisRdsOmsfromController.class);

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> atdispatchUrlBc = sc.broadcast("http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=12797991c7e64fadb1272910d9d01aef&opt=zh");
        Broadcast<String> rdsksUrlBc = sc.broadcast("http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getTeam?ak=3eb300d2e06947f7945cd02530a32fd2&address=%s&city=%s&dept=%s");
        Broadcast<String> rgsbAddUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd");

        JavaRDD<GisRdsOmsfrom> gisRdsOmsfromRdd = loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisRdsOmsfromRdd cnt:{}", gisRdsOmsfromRdd.count());
        gisRdsOmsfromRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<GisRdsOmsfrom> deptCodeRdd = gisRdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getArssaoicode(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .map(o -> {
                    String arssaoicode = o.getArssaoicode();
                    if (StringUtils.isNotEmpty(arssaoicode)) {
                        String regex = "^\\d+[A-Z]+";
                        Pattern p = Pattern.compile(regex);
                        Matcher m = p.matcher(arssaoicode);
                        while (m.find()) {
                            o.setDeptcode(m.group(0));
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptCodeRdd cnt:{}", deptCodeRdd.count());
        deptCodeRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        gisRdsOmsfromRdd.unpersist();

        JavaRDD<GisRdsOmsfrom> splitResultRdd = deptCodeRdd.map(o -> {
            try {
                String address = o.getAddress();
                String citycode = o.getCitycode();
                if (StringUtils.isNotEmpty(address)) {
                    String content = runAtdispatch(atdispatchUrlBc.value(), address, citycode, acLimitCodeSetBc.value());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                JSONObject other = result.getJSONObject("other");
                                if (other != null) {
                                    JSONObject normresp = other.getJSONObject("normresp");
                                    if (normresp != null) {
                                        JSONObject result1 = normresp.getJSONObject("result");
                                        if (result1 != null) {
                                            String splitResult = result1.getString("splitResult");
                                            logger.error("splitResult:{}", splitResult);
                                            o.setSplitResult(splitResult);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitResultRdd cnt:{}", splitResultRdd.count());
        splitResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        deptCodeRdd.unpersist();

        JavaRDD<GisRdsOmsfrom> emptySplitRdd = splitResultRdd.filter(o -> StringUtils.isEmpty(o.getSplitResult())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("emptySplitRdd cnt:{}", emptySplitRdd.count());

        JavaRDD<GisRdsOmsfrom> addrLevelRdd = splitResultRdd.filter(o -> {
            boolean flag = false;
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                String level = splitResult.split(";")[1];
                int levelNum = StringUtils.isNotEmpty(level) ? Integer.valueOf(level) : 0;
                if (levelNum >= 11) {
                    flag = true;
                }
            }
            return flag;
        }).union(emptySplitRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrLevelRdd cnt:{}", addrLevelRdd.count());
        addrLevelRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        splitResultRdd.unpersist();
        emptySplitRdd.unpersist();

        JavaRDD<GisRdsOmsfrom> aoiRdd = addrLevelRdd.map(o -> {
            String address = o.getAddress();
            String citycode = o.getCitycode();
            String deptcode = o.getDeptcode();
            if (StringUtils.isNotEmpty(address)) {
                String content = runAoi(rdsksUrlBc.value(), address, citycode, deptcode, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                        JSONObject result = jsonObject.getJSONObject("result");
                        if (result != null) {
                            String aoi = result.getString("aoi");
                            String aoiCode = result.getString("aoiCode");
                            logger.error("aoi:{},aoiCode:{}", aoi, aoiCode);
                            o.setAoi(aoi);
                            o.setAoiCode(aoiCode);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:{}", aoiRdd.count());
        aoiRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        addrLevelRdd.unpersist();

        JavaRDD<GisRdsOmsfrom> filterRdd = aoiRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi()) && StringUtils.isNotEmpty(o.getAoiCode()) && StringUtils.equals(o.getAoiCode(), o.getArssaoicode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        aoiRdd.unpersist();

        JavaRDD<GisRdsOmsfrom> flagRdd = filterRdd.map(o -> {
            String citycode = o.getCitycode();
            String address = o.getAddress();
            String deptcode = o.getDeptcode();
            String aoi = o.getAoi();

            JSONObject param = new JSONObject();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("cityCode", citycode);
            jsonObject.put("address", address);
            jsonObject.put("znoCode", deptcode);
            jsonObject.put("aoiId", aoi);
            jsonObject.put("src", "0");

            param.put("ak", "3a191e7427e8470c86271a069411c66b");
            param.put("operSource", "ARSS_KS");
            param.put("operUserName", "01412995");
            param.put("addressSave", jsonObject);

            String content = runAddrUpdateAoi(rgsbAddUrlBc.value(), param.toJSONString());
            o.setContent(content);
            if (StringUtils.isNotEmpty(content)) {
                logger.error("content:{}", content);
                JSONObject result = JSON.parseObject(content);
                if (result != null) {
                    String flag = result.getString("success");
                    o.setFlag(flag);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("flagRdd cnt:{}", flagRdd.count());
        flagRdd.take(10).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("empty cnt:{}", flagRdd.filter(o -> StringUtils.isEmpty(o.getFlag())).count());
        logger.error("sucess cnt:{}", flagRdd.filter(o -> StringUtils.equals(o.getFlag(), "true")).count());
        logger.error("false cnt:{}", flagRdd.filter(o -> StringUtils.equals(o.getFlag(), "false")).count());

        spark.sql(String.format("alter table dm_gis.gis_rds_omsfrom_press_result drop if EXISTS partition( inc_day='%s' )", date));
        saveData(spark, flagRdd, date, "dm_gis.gis_rds_omsfrom_press_result");

        flagRdd.unpersist();

        spark.stop();
    }

    public void saveData(SparkSession spark, JavaRDD<GisRdsOmsfrom> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCitycode(), o.getArssaoicode(), o.getAddress(), o.getDeptcode(), o.getSplitResult(),
                    o.getAoi(), o.getAoiCode(), o.getFlag(), o.getContent()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "citycode", "arssaoicode", "address", "deptcode", "split_result",
                "aoi", "aoi_code", "flag", "content"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "gis_rds_omsfrom_press_result_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", table, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public String runAddrUpdateAoi(String url, String param) {
        String content = "";
        try {
            logger.error("addr update aoi url:{}", url);
            content = UrlUtil.sendPost(url, param);
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runAoi(String urlPattern, String address, String cityCode, String deptCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode, deptCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runAtdispatch(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }


    public JavaRDD<GisRdsOmsfrom> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("gis_rds_omsfrom.sql", date);
        logger.error("gis_rds_omsfrom sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, GisRdsOmsfrom.class);
    }

    public static void main(String[] args) {
        String regex1 = "^\\d+[A-Z]+";
        Pattern p = Pattern.compile(regex1);
        Matcher m = p.matcher("852UAB001667");
        while (m.find()) {
            System.out.println(m.group(0));
        }

    }
}
