package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.constant.SdsConstant;
import com.sf.gis.java.sds.controller.SfpAddrController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 画像（基于地址的小哥投递行为画像）
 * 缩写SFP，Portrait，肖像
 * @author 01370539 created on Aug.5 2021
 */
public class SfpAddrApp {
    private static final Logger logger = LoggerFactory.getLogger(SfpAddrApp.class);

    public static void main(String[] args) {
        logger.error("input parameter: {}", args);
        String processMode = null;
        String cityCode = null;
        if (args.length >= 2) {
            processMode = args[0];
            cityCode = args[1];
        }

        if (SdsConstant.SFP_ADDR_PROCESS_INIT.equalsIgnoreCase(processMode) || SdsConstant.SFP_ADDR_PROCESS_INIT_REGION.equalsIgnoreCase(processMode)) {
            String startDate = null;
            String endDate = null;
            if (args.length >= 4) {
                startDate = args[2];
                endDate = args[3];
            } else {
                logger.error("param not match, init param not match. startDate - {}, endDate - {}", startDate, endDate);
                System.exit(0);
            }
            if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
                logger.error("param not match, startDate - {}, endDate - {}", startDate, endDate);
                System.exit(0);
            }
            new SfpAddrController().process(processMode, cityCode, startDate, endDate);
        } else if (SdsConstant.SFP_ADDR_PROCESS_PUSH.equalsIgnoreCase(processMode) || SdsConstant.SFP_ADDR_PROCESS_PUSH_COORD.equalsIgnoreCase(processMode)) {
            String effectTypes = null;
            String xyAoiTypes = null;
            if (args.length >= 4) {
                effectTypes = args[2];
                xyAoiTypes = args[3];
            }
            new SfpAddrController().process(processMode, cityCode, effectTypes, xyAoiTypes);
        }  else if (SdsConstant.SFP_ADDR_PROCESS_VERIFY.equalsIgnoreCase(processMode)) {
            new SfpAddrController().processVerify();
        } else if (SdsConstant.SFP_ADDR_PROCESS_BUILDING.equalsIgnoreCase(processMode)) {
            String url = null;
            if (args.length >= 2) {
                url = args[1];
            }
            new SfpAddrController().processBuilding(url);
        } else {
            new SfpAddrController().process(processMode, cityCode);
        }
    }
}
