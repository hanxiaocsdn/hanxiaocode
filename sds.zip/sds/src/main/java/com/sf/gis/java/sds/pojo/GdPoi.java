package com.sf.gis.java.sds.pojo;

import java.io.Serializable;

public class GdPoi implements Serializable {
    private String location;
    private String gd_name;
    private String gd_address;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getGd_name() {
        return gd_name;
    }

    public void setGd_name(String gd_name) {
        this.gd_name = gd_name;
    }

    public String getGd_address() {
        return gd_address;
    }

    public void setGd_address(String gd_address) {
        this.gd_address = gd_address;
    }
}
