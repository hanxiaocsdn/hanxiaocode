package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class NewBusinessAreaModelsBuildingRecognitionStat implements Serializable {
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_id_num")
    private String aoi_id_num;
    @Column(name = "poi_num")
    private String poi_num;

    @Column(name = "inc_day")
    private String inc_day;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_id_num() {
        return aoi_id_num;
    }

    public void setAoi_id_num(String aoi_id_num) {
        this.aoi_id_num = aoi_id_num;
    }

    public String getPoi_num() {
        return poi_num;
    }

    public void setPoi_num(String poi_num) {
        this.poi_num = poi_num;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
