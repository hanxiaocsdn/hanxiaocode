package com.sf.gis.java.sds.bean;

import com.sf.gis.java.sds.enumtype.DeptBy;
import com.sf.gis.scala.base.util.StringUtils;

public class DeptData {
    private String gisDept;
    private String sssDept;
    private String sbAddress;
    private String sbDept;
    private String deptBy;
    private String req_billno;
    private String req_address;
    private String src;
    private String gisTeamCode;
    private String suc_day;
    private String cityCode;
    private String req_time;
    private String deptcode;

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getReq_time() {
        return req_time;
    }

    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public DeptData() {
    }


    public DeptData(String gisDept, String sssDept, String sbAddress, String sbDept, String deptBy,
                    String req_billno, String req_address,
                    String src, String gisTeamCode, String suc_day, String cityCode, String req_time,
                    String deptcode) {
        this.gisDept = gisDept;
        this.sssDept = sssDept;
        this.deptBy = deptBy;
        this.sbDept = sbDept;
        this.sbAddress = sbAddress;
        this.req_billno = req_billno;
        this.req_address = req_address;
        this.src = src;
        this.gisTeamCode = gisTeamCode;
        this.suc_day = suc_day;
        this.cityCode = cityCode;
        this.req_time = req_time;
        this.deptcode = deptcode;
    }

    public String getSuc_day() {
        return suc_day;
    }


    public void setSuc_day(String suc_day) {
        this.suc_day = suc_day;
    }


    public String getGisTeamCode() {
        return gisTeamCode;
    }

    public void setGisTeamCode(String gisTeamCode) {
        this.gisTeamCode = gisTeamCode;
    }

    public String getReq_address() {
        return req_address;
    }

    public void setReq_address(String req_address) {
        this.req_address = req_address;
    }


    public String getReq_billno() {
        return req_billno;
    }

    public void setReq_billno(String req_billno) {
        this.req_billno = req_billno;
    }

    public String getDeptBy() {
        return deptBy;
    }

    public void setDeptBy(String deptBy) {
        this.deptBy = deptBy;
    }

    public String getSbDept() {
        return sbDept;
    }

    public void setSbDept(String sbDept) {
        this.sbDept = sbDept;
    }

    public String getSbAddress() {
        return sbAddress;
    }

    public void setSbAddress(String sbAddress) {
        this.sbAddress = sbAddress;
    }

    public String getGisDept() {
        return gisDept;
    }

    public void setGisDept(String gisDept) {
        this.gisDept = gisDept;
    }

    public String getSssDept() {
        return sssDept;
    }

    public void setSssDept(String sssDept) {
        this.sssDept = sssDept;
    }

    public boolean isSb() {
        return !StringUtils.isBlank(sbAddress) || !StringUtils.isBlank(sbDept);
    }


    public boolean gisSssDeptCount() {
        return !StringUtils.isBlank(sssDept) || !StringUtils.isBlank(gisDept);
    }

    public boolean gisSssDeptAllCount() {
        return !StringUtils.isBlank(sssDept) || !StringUtils.isBlank(gisDept)
                || (!StringUtils.isBlank(sbDept) && !sbDept.equals("0") && !sbDept.equals("7"));
    }

    public boolean gisDeptCount() {
        return !StringUtils.isBlank(gisDept);
    }

    public boolean sssDeptCount() {
        return !StringUtils.isBlank(sssDept);
    }

    public boolean sbDeptCount() {
        return isSb();
    }

    public boolean gisSssNotSame() {
        return !StringUtils.isBlank(sssDept) && !StringUtils.isBlank(gisDept) && !sssDept.equals(gisDept);
    }

    public boolean isUseGis() {
        if (!StringUtils.isBlank(gisDept) && StringUtils.isBlank(sssDept)) {
            // gis有，sss无
            return true;
        } else if (!StringUtils.isBlank(gisDept) && gisDept.equals(sssDept)) {
            // gis有，gis和sss相同
            return true;
        } else if (!StringUtils.isBlank(gisDept) && !gisDept.equals(sssDept)
                && !isSb() && DeptBy.gis.name().equals(deptBy)) {
            // gis有，gis和sss不同，未请求审补
            return true;
        } else if (!StringUtils.isBlank(gisDept) && !gisDept.equals(sssDept)
                && isSb() && gisDept.equals(sbDept)) {
            // gis有，gis和sss不同，审补等于gis
            return true;
        }
        return false;
    }

    public boolean isUseSss() {
        if (!StringUtils.isBlank(sssDept) && StringUtils.isBlank(gisDept)) {
            // sss有，gis无
            return true;
        } else if (!StringUtils.isBlank(sssDept) && !sssDept.equals(gisDept) && isSb()
                && (StringUtils.isBlank(sbDept) || sbDept.equals("0") || sbDept.equals("7")
                || sssDept.equals(sbDept))) {
            return true;
        } else if (!StringUtils.isBlank(sssDept) && !sssDept.equals(gisDept) && !isSb() && !DeptBy.gis.name().equals(deptBy)) {
            return true;
        }
        return false;
    }

    public boolean isUseSb() {
        if (isSb() && !StringUtils.isBlank(sbDept)) {
            if (StringUtils.isBlank(gisDept) && StringUtils.isBlank(sssDept)
                    && !sbDept.equals("0") && !sbDept.equals("7")) {
                return true;
            } else if (!StringUtils.isBlank(sssDept)
                    && !sbDept.equals("0") && !sbDept.equals("7")
                    && !sbDept.equals(sssDept)
                    && !sbDept.equals(gisDept)) {
                return true;
            }
        }
        return false;
    }

    public boolean sb0_7() {
        return "0".equals(sbDept) || "7".equals(sbDept);
    }

    public boolean gisWrongSssNotSame() {
        return !StringUtils.isBlank(gisDept)
                && !StringUtils.isBlank(sssDept)
                && !gisDept.equals(sssDept)
                && !isSb()
                ;
    }
}