package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.OperationPlatformMisJudgment1Controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppOperationPlatformMisJudgment1 {
    private static Logger logger = LoggerFactory.getLogger(AppOperationPlatformMisJudgment1.class);

    public static void main(String[] args) {
        String today = args[0];
        logger.error("today:{}", today);
        logger.error("run start");
        new OperationPlatformMisJudgment1Controller().start(today);
        logger.error("run end");
    }
}
