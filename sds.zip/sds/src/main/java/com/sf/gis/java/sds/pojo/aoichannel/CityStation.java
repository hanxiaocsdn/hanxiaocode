package com.sf.gis.java.sds.pojo.aoichannel;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CityStation implements Serializable {

    @Column(name = "dist_code")
    private String dist_code;
    @Column(name = "cvs_code")
    private String cvs_code;
    @Column(name = "store_id")
    private String store_id;
    @Column(name = "cvs_name")
    private String cvs_name;
    @Column(name = "aoi_dist_code")
    private String aoi_dist_code;
    @Column(name = "store_address")
    private String store_address;
    @Column(name = "store_lng")
    private String store_lng;
    @Column(name = "store_lat")
    private String store_lat;

    private String req;
    private String resJson;
    private String aoi_id;
    private String aoi_code;
    private String aoi_name;

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getResJson() {
        return resJson;
    }

    public void setResJson(String resJson) {
        this.resJson = resJson;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getDist_code() {
        return dist_code;
    }

    public void setDist_code(String dist_code) {
        this.dist_code = dist_code;
    }

    public String getCvs_code() {
        return cvs_code;
    }

    public void setCvs_code(String cvs_code) {
        this.cvs_code = cvs_code;
    }

    public String getStore_id() {
        return store_id;
    }

    public void setStore_id(String store_id) {
        this.store_id = store_id;
    }

    public String getCvs_name() {
        return cvs_name;
    }

    public void setCvs_name(String cvs_name) {
        this.cvs_name = cvs_name;
    }

    public String getAoi_dist_code() {
        return aoi_dist_code;
    }

    public void setAoi_dist_code(String aoi_dist_code) {
        this.aoi_dist_code = aoi_dist_code;
    }

    public String getStore_address() {
        return store_address;
    }

    public void setStore_address(String store_address) {
        this.store_address = store_address;
    }

    public String getStore_lng() {
        return store_lng;
    }

    public void setStore_lng(String store_lng) {
        this.store_lng = store_lng;
    }

    public String getStore_lat() {
        return store_lat;
    }

    public void setStore_lat(String store_lat) {
        this.store_lat = store_lat;
    }
}
