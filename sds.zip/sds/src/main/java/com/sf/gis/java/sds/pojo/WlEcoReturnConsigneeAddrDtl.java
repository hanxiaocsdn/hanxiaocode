package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class WlEcoReturnConsigneeAddrDtl implements Serializable {
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;

    private String content;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }
}
