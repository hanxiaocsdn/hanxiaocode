package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.graph.aoi.common.util.KeyWordUtil;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.XzcVillage;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务id:827907(行政村数据预处理)
 * 业务方：01422529（刘桓）
 * 研发：01399581（匡仁衡）
 * 时间：2023年10月7日09:52:39AoiChannelIn
 */

public class AppAdsTransferSdsAoiReportPreProcess {
    private static Logger logger = LoggerFactory.getLogger(AppAdsTransferSdsAoiReportPreProcess.class);
    private static String hasOgcOverDistance_url = "http://sds-core-datarun.sf-express.com/datarun/aoiVillage/hasOgcOverDistance";

    public static void main(String[] args) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAdsTransferSdsAoiReportPreProcess");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String path_1 = "hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/xcd/xzc_zh_1.csv";
        String path_2 = "hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/xcd/xzc_zh_2.csv";
        JavaRDD<XzcVillage> rdd1 = get(sc, path_1);
        JavaRDD<XzcVillage> rdd2 = get(sc, path_2);

        JavaRDD<XzcVillage> rdd = rdd1.union(rdd2).mapToPair(o -> new Tuple2<>(o.getGuid_v() + "_" + o.getOgc_fid(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        rdd1.unpersist();
        rdd2.unpersist();

        JavaRDD<XzcVillage> lastRdd = rdd.mapToPair(o -> new Tuple2<>(o.getGuid_v(), o)).groupByKey().flatMap(tp -> {
            ArrayList<XzcVillage> all_list = new ArrayList<>();
            List<XzcVillage> list = Lists.newArrayList(tp._2);
            for (XzcVillage xzcVillage : list) {
                String ogc_fid = xzcVillage.getOgc_fid();
                String name = xzcVillage.getName();
                List<XzcVillage> filter_list = list.stream().filter(t -> !StringUtils.equals(t.getOgc_fid(), ogc_fid)).collect(Collectors.toList());
                for (XzcVillage village : filter_list) {
                    String neighbor_name = village.getName();
                    String neighbor_ogc_fid = village.getOgc_fid();
                    double sim_text = KeyWordUtil.similarity(name, neighbor_name);
                    XzcVillage o = new XzcVillage();
                    BeanUtils.copyProperties(o, xzcVillage);
                    o.setNeighbor_name(neighbor_name);
                    o.setNeighbor_ogc_fid(neighbor_ogc_fid);
                    o.setSim_text(sim_text);
                    all_list.add(o);
                }
            }

            Set<String> stay = new HashSet<>();
            Set<String> delete = new HashSet<>();
            Map<String, List<XzcVillage>> map = all_list.stream().collect(Collectors.groupingBy(XzcVillage::getOgc_fid));
            for (Map.Entry<String, List<XzcVillage>> stringListEntry : map.entrySet()) {
                String key = stringListEntry.getKey();
                List<XzcVillage> sim_list = stringListEntry.getValue();

                Set<String> lt_set = sim_list.stream().filter(t -> t.getSim_text() < 0.8).map(XzcVillage::getNeighbor_ogc_fid).collect(Collectors.toSet());
                if (lt_set.size() > 0) {
                    stay.addAll(lt_set);
                }
                stay.add(key);

                List<String> temp_lg_list = sim_list.stream().filter(t -> t.getSim_text() >= 0.8).map(XzcVillage::getNeighbor_ogc_fid).collect(Collectors.toList());
                if (temp_lg_list.size() >= 1) {
                    List<String> lg_list = new ArrayList<>();
                    lg_list.addAll(temp_lg_list);
                    for (String neighbor_ogc_fid : temp_lg_list) {
                        List<String> neighbor_list = all_list.stream().filter(t -> StringUtils.equals(neighbor_ogc_fid, t.getOgc_fid())).filter(t -> t.getSim_text() >= 0.8).map(XzcVillage::getNeighbor_ogc_fid).collect(Collectors.toList());
                        lg_list.addAll(neighbor_list);
                    }
                    lg_list.add(key);
                    List<String> last_list = lg_list.stream().distinct().collect(Collectors.toList());
                    JSONObject param = new JSONObject();
                    param.put("ogcFids", last_list);
                    param.put("distance", 2000);

                    String content = HttpInvokeUtil.sendPost(hasOgcOverDistance_url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
                    String isOver = "";
                    try {
                        isOver = JSON.parseObject(content).getJSONObject("data").getString("isOver");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    if (StringUtils.isEmpty(isOver) || StringUtils.equals(isOver, "0")) {
                        stay.addAll(new HashSet<>(last_list));
                    } else {
                        delete.addAll(new HashSet<>(last_list));
                    }
                }
            }

            for (String delete_ogc_fid : delete) {
                stay.remove(delete_ogc_fid);
            }

            return list.stream().filter(t -> stay.contains(t.getOgc_fid())).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        rdd.unpersist();

        spark.sql("truncate table dm_gis.xzc_filter");
        DataUtil.saveInto(spark, sc, "dm_gis.xzc_filter", XzcVillage.class, lastRdd);
        lastRdd.unpersist();
        sc.stop();
    }

    public static JavaRDD<XzcVillage> get(JavaSparkContext sc, String path) {
        JavaRDD<String> lineRdd = sc.textFile(path).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lineRdd cnt:{}", lineRdd.count());

        String header = lineRdd.first();
        logger.error("header:{}", header);

        JavaRDD<XzcVillage> rdd = lineRdd.filter(o -> !StringUtils.equals(o, header)).map(line -> {
            XzcVillage o = new XzcVillage();
            String[] split = line.split(",");
            String ogc_fid = split[0];
            String name = split[1];
            String guid_v = split[2];
            String name_v = split[3];

            o.setOgc_fid(ogc_fid);
            o.setName(name);
            o.setGuid_v(guid_v);
            o.setName_v(name_v);

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        lineRdd.unpersist();
        return rdd;
    }
}
