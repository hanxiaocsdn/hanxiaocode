package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.*;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class OperationPlatformMisJudgmentController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(OperationPlatformMisJudgmentController.class);

    public void start(String beforeDate, String date, String sdate, String edate) {
        //初始化spark
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Broadcast<String> precisionGdUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=c2ee00ecb0164098b58569b5bdffe60d&opt=gd2&address=%s&city=%s");
        Broadcast<String> aoiidurlBc = sc.broadcast("http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=dec044d089524419b371bc94555c539d");
        Broadcast<String> companyBc = sc.broadcast("公司|厰|厂|制品|制造|电子|科技|生物|环保|资源|精密|金属|车行|门窗|vivo|oppo|huawei|化工|针织|广告|刺绣|物流|集团|鞋业|能源|机电|电器|包装|银行|店|工作室|科技有限公司|有限责任公司|科技股份公司|股份有限公司|有限公司|科技公司|分公司|公司");
        Broadcast<String> misjudgeaoiUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh");
        Broadcast<String> aoiCheckTagUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck");
        Broadcast<String> hdfsClientDirBc = sc.broadcast("/user/01399581/upload/yunying_demand/data/");

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        String processDate = DateUtil.getDaysBefore(date, 1);
        logger.error("processDate:{}", processDate);
        JavaRDD<OperationPlatformMisJudgment> sourceRdd = loadSourceData(spark, sc, processDate, sdate, edate).map(o -> {
            String upload_date = o.getUpload_date();
            if (StringUtils.isNotEmpty(upload_date)) {
                String s = upload_date.split(" ")[0];
                String[] split = s.split("-");
                o.setMonth(split[0] + split[1]);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sourceRdd cnt:{}", sourceRdd.count());
        sourceRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

//        String hdfsClientDir = hdfsClientDirBc.value();
//        String filePath = hdfsClientDir.concat("20211202_new_test").concat(".csv");
//        JavaRDD<String> lines = sc.textFile(filePath).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        String header = lines.first();
//        logger.error("header:{}", header);
//        JavaRDD<OperationPlatformMisJudgment> sourceRdd = lines.filter(o -> !o.equals(header)).map(line -> {
//            String[] split = line.split(",");
//            OperationPlatformMisJudgment o = new OperationPlatformMisJudgment();
//            o.setOrigi_id(split[0]);
//            o.setFault_reason(split[1]);
//            o.setCity_code(split[2]);
//            o.setZno_code(split[3]);
//            o.setReceive_addr(split[4]);
//            o.setCompany_name(split[5]);
//            o.setGis_final_aoi(split[6]);
//            o.setFinal_aoi_name(split[7]);
//            o.setUpload_date(split[8].split(" ")[0].replace("-", ""));
//            o.setRemark_reason(split[9]);
//
//            String upload_date = o.getUpload_date();
//            if (StringUtils.isNotEmpty(upload_date) && upload_date.length() >= 6) {
//                String month = o.getUpload_date().substring(0, 6);
//                logger.error("month:{}", month);
//                o.setMonth(month);
//            }
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("sourceRdd cnt:{}", sourceRdd.count());
//        sourceRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

//        JavaRDD<AoiRealAccturyRateFinalData> gisGidRdd = loadGisgidData(spark, sc, "20211120", "20211222").persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("gisGidRdd cnt:{}", gisGidRdd.count());

//        JavaRDD<OperationPlatformMisJudgment> gisGidsourceRdd = sourceRdd.mapToPair(o -> new Tuple2<>(o.getOrigi_id(), o))
//                .leftOuterJoin(gisGidRdd.mapToPair(o -> new Tuple2<>(o.getId(), o)).reduceByKey((o1, o2) -> o1))
//                .map(tp -> {
//                    OperationPlatformMisJudgment o = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        AoiRealAccturyRateFinalData aoiRealAccturyRateFinalData = tp._2._2.get();
//
//                        o.setGis_src(aoiRealAccturyRateFinalData.getGisaoisrc());
//                        o.setNew_data_date(aoiRealAccturyRateFinalData.getInc_day());
//                        o.setGis_gid(aoiRealAccturyRateFinalData.getGis_to_sys_groupid());
//
//                    }
//                    return o;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("gisGidsourceRdd cnt:{}", gisGidsourceRdd.count());
//        sourceRdd.unpersist();
//        gisGidRdd.unpersist();

//        logger.error("have gis_gid cnt:{}", gisGidsourceRdd.filter(o -> StringUtils.isNotEmpty(o.getGis_gid())).count());
//        logger.error("no gis_gid cnt:{}", gisGidsourceRdd.filter(o -> StringUtils.isEmpty(o.getGis_gid())).count());


        JavaRDD<OperationPlatformMisJudgment> eqNormRdd = sourceRdd.filter(o -> StringUtils.equals(o.getGis_src(), "norm") || StringUtils.equals(o.getGis_src(), "chkn")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noEqNormRdd = sourceRdd.filter(o -> !(StringUtils.equals(o.getGis_src(), "norm") || StringUtils.equals(o.getGis_src(), "chkn"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqNormRdd cnt:{}", eqNormRdd.count());
        logger.error("noEqNormRdd cnt:{}", noEqNormRdd.count());
        sourceRdd.unpersist();

        JavaRDD<OperationBottomcorrected> operationBottomcorrectedRdd = loadAoiRealAccturyRateData(spark, sc, beforeDate, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("operationBottomcorrectedRdd cnt:{}", operationBottomcorrectedRdd.count());

        JavaRDD<OperationPlatformMisJudgment> bottomFinalaoiRdd = eqNormRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .leftOuterJoin(operationBottomcorrectedRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        OperationBottomcorrected operationBottomcorrected = tp._2._2.get();
                        o.setBottomcorrected(operationBottomcorrected.getBottomcorrected());
                        o.setFinalaoicode(operationBottomcorrected.getFinalaoicode());
                        o.setUnionTag1("ok");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("bottomFinalaoiRdd cnt:{}", bottomFinalaoiRdd.count());
        eqNormRdd.unpersist();
        operationBottomcorrectedRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpBottomRdd = bottomFinalaoiRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag1())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empBottomRdd = bottomFinalaoiRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag1())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpBottomRdd cnt:{}, empBottomRdd:{}", noEmpBottomRdd.count(), empBottomRdd.count());
        bottomFinalaoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> yesRdd = noEmpBottomRdd.filter(o -> StringUtils.equals(o.getBottomcorrected(), "yes") && StringUtils.isNotEmpty(o.getGis_final_aoi()) && StringUtils.isNotEmpty(o.getFinalaoicode()) && StringUtils.equals(o.getGis_final_aoi(), o.getFinalaoicode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noRdd = noEmpBottomRdd.filter(o -> !(StringUtils.equals(o.getBottomcorrected(), "yes") && StringUtils.isNotEmpty(o.getGis_final_aoi()) && StringUtils.isNotEmpty(o.getFinalaoicode()) && StringUtils.equals(o.getGis_final_aoi(), o.getFinalaoicode()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("yesRdd cnt:{}, noRdd cnt:{}", yesRdd.count(), noRdd.count());
        noEmpBottomRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_right_bottomTagRdd = yesRdd.map(o -> {
            o.setTag("area_right_bottom");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_right_bottomTagRdd cnt:{}", area_right_bottomTagRdd.count());
        yesRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> nextProcessRdd = noEqNormRdd.union(empBottomRdd).union(noRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("nextProcessRdd cnt:{}", nextProcessRdd.count());
        noEqNormRdd.unpersist();
        empBottomRdd.unpersist();
        noRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> weekStatRdd = loadAoiRealAccturyRateJudgeWrongOperationWeekStatData(spark, sc, beforeDate, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("weekStatRdd cnt:{}", weekStatRdd.count());

        JavaRDD<OperationPlatformMisJudgment> weekRdd = nextProcessRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid() + "_" + o.getNew_data_date(), o))
                .leftOuterJoin(weekStatRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid() + "_" + o.getInc_day(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiRealAccturyRateJudgeWrongOperation aoiRealAccturyRateJudgeWrongOperation = tp._2._2.get();
                        o.setRight_freq(aoiRealAccturyRateJudgeWrongOperation.getRight_freq());
                        o.setLabel(aoiRealAccturyRateJudgeWrongOperation.getLabel());
                        o.setWeek_finalaoicode(aoiRealAccturyRateJudgeWrongOperation.getFinalaoicode());
                        o.setUnionTag2("ok");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("weekRdd cnt:{}", weekRdd.count());
        nextProcessRdd.unpersist();
        weekStatRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpLabelRdd = weekRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag2())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empLabelRdd = weekRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag2())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpLabelRdd cnt:{}, empLabelRdd cnt:{}", noEmpLabelRdd.count(), empLabelRdd.count());
        weekRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> rightFreqRdd = noEmpLabelRdd.filter(o -> !StringUtils.equals(o.getRight_freq(), "0") && StringUtils.isNotEmpty(o.getGis_final_aoi()) && StringUtils.isNotEmpty(o.getWeek_finalaoicode()) && StringUtils.equals(o.getGis_final_aoi(), o.getWeek_finalaoicode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noRightFreqRdd = noEmpLabelRdd.filter(o -> !(!StringUtils.equals(o.getRight_freq(), "0") && StringUtils.isNotEmpty(o.getGis_final_aoi()) && StringUtils.isNotEmpty(o.getWeek_finalaoicode()) && StringUtils.equals(o.getGis_final_aoi(), o.getWeek_finalaoicode()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rightFreqRdd cnt:{},noRightFreqRdd cnt:{}", rightFreqRdd.count(), noRightFreqRdd.count());
        noEmpLabelRdd.unpersist();

//        JavaRDD<OperationPlatformMisJudgment> labelRdd = rightFreqRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
//                .groupByKey()
//                .flatMap(tp -> {
//                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
//                    List<OperationPlatformMisJudgment> otherList = list.stream().filter(o -> !StringUtils.equals(o.getLabel(), "right")).collect(Collectors.toList());
//                    List<OperationPlatformMisJudgment> rightList = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "right")).collect(Collectors.toList());
//
//                    int size = rightList.stream()
//                            .filter(o -> StringUtils.isNotEmpty(o.getWeek_finalaoicode()))
//                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OperationPlatformMisJudgment::getWeek_finalaoicode))), ArrayList::new))
//                            .size();
//                    if (size == 1) {
//                        rightList = rightList.stream().map(o -> {
//                            o.setUnionTag3("ok");
//                            return o;
//                        }).collect(Collectors.toList());
//                    }
//                    otherList.addAll(rightList);
//                    return otherList.iterator();
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("labelRdd cnt:{}", labelRdd.count());
//        rightFreqRdd.unpersist();

//        JavaRDD<OperationPlatformMisJudgment> noEmpTag3Rdd = labelRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag3())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<OperationPlatformMisJudgment> empTag3Rdd = labelRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag3())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("noEmpTag3Rdd:{}, empTag3Rdd:{}", noEmpTag3Rdd.count(), empTag3Rdd.count());
//        labelRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_rightTagRdd = rightFreqRdd.map(o -> {
            o.setTag("area_right");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_rightTagRdd cnt:{}", area_rightTagRdd.count());
        rightFreqRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> next2ProcessRdd = empLabelRdd.union(noRightFreqRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("next2ProcessRdd cnt:{}", next2ProcessRdd.count());
        empLabelRdd.unpersist();
        noRightFreqRdd.unpersist();
//        empTag3Rdd.unpersist();

        JavaRDD<CghsResultData> cghsRdd = loadCghsData(spark, sc, beforeDate, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cghsRdd cnt:{}", cghsRdd.count());

//        JavaRDD<CghsResultData> uniqueCghsRdd = cghsRdd.mapToPair(o -> new Tuple2<>(o.getGid(), o))
//                .groupByKey()
//                .filter(tp -> {
//                    boolean flag = false;
//                    List<CghsResultData> list = Lists.newArrayList(tp._2);
//                    int size = list.stream()
//                            .filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_code()))
//                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CghsResultData::getCheck_aoi_code))), ArrayList::new))
//                            .size();
//                    if (size == 1) {
//                        flag = true;
//                    }
//                    return flag;
//                }).flatMap(tp -> Lists.newArrayList(tp._2).iterator())
//                .persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("uniqueCghsRdd cnt:{}", uniqueCghsRdd.count());
//        cghsRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> check_aoi_codeRdd = next2ProcessRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .leftOuterJoin(cghsRdd.mapToPair(o -> new Tuple2<>(o.getGid(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CghsResultData cghsResultData = tp._2._2.get();
                        o.setCheck_aoi_code(cghsResultData.getCheck_aoi_code());
                        o.setUnionTag4("ok");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("check_aoi_codeRdd cnt:{}", check_aoi_codeRdd.count());
        next2ProcessRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpcheck_aoi_codeRdd = check_aoi_codeRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag4())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empcheck_aoi_codeRdd = check_aoi_codeRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag4())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpcheck_aoi_codeRdd cnt:{}, empcheck_aoi_codeRdd:{}", noEmpcheck_aoi_codeRdd.count(), empcheck_aoi_codeRdd.count());
        check_aoi_codeRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmptyCheckAoiCodeRdd = noEmpcheck_aoi_codeRdd.filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> emptyCheckAoiCodeRdd = noEmpcheck_aoi_codeRdd.filter(o -> StringUtils.isEmpty(o.getCheck_aoi_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmptyCheckAoiCodeRdd cnt:{}, emptyCheckAoiCodeRdd cnt:{}", noEmptyCheckAoiCodeRdd.count(), emptyCheckAoiCodeRdd.count());
        noEmpcheck_aoi_codeRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> eqGisAoiCheckAoi = noEmptyCheckAoiCodeRdd.filter(o -> StringUtils.equals(o.getGis_final_aoi(), o.getCheck_aoi_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noEqGisAoiCheckAoi = noEmptyCheckAoiCodeRdd.filter(o -> !StringUtils.equals(o.getGis_final_aoi(), o.getCheck_aoi_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqGisAoiCheckAoi cnt:{}, noEqGisAoiCheckAoi cnt:{}", eqGisAoiCheckAoi.count(), noEqGisAoiCheckAoi.count());
        noEmptyCheckAoiCodeRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> uniqueCheckAoiCodeRdd = eqGisAoiCheckAoi.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    int size = list.stream()
                            .filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_code()))
                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OperationPlatformMisJudgment::getCheck_aoi_code))), ArrayList::new))
                            .size();
                    if (size == 1) {
                        list = list.stream().map(o -> {
                            o.setUnionTag8("ok");
                            return o;
                        }).collect(Collectors.toList());
                    }
                    return list.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueCheckAoiCodeRdd cnt:{}", uniqueCheckAoiCodeRdd.count());
        eqGisAoiCheckAoi.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpUnionTagRdd = uniqueCheckAoiCodeRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag8())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empUnionTagRdd = uniqueCheckAoiCodeRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag8())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpUnionTagRdd cnt:{}, empUnionTagRdd cnt:{}", noEmpUnionTagRdd.count(), empUnionTagRdd.count());
        uniqueCheckAoiCodeRdd.unpersist();


        JavaRDD<OperationPlatformMisJudgment> area_right_cgTagRdd = noEmpUnionTagRdd.map(o -> {
            o.setTag("area_right_cg");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_right_cgTagRdd cnt:{}", area_right_cgTagRdd.count());
        noEmpUnionTagRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_wrong_cgTagRdd = noEqGisAoiCheckAoi.union(empUnionTagRdd).map(o -> {
            o.setTag("area_wrong_cg");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_wrong_cgTagRdd cnt:{}", area_wrong_cgTagRdd.count());
        noEqGisAoiCheckAoi.unpersist();
        empUnionTagRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> wrongOperationRdd = loadWrongOperationData(spark, sc, beforeDate, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("wrongOperationRdd cnt:{}", wrongOperationRdd.count());

        JavaRDD<OperationPlatformMisJudgment> gj_aoicodeRdd = empcheck_aoi_codeRdd.union(emptyCheckAoiCodeRdd).mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .leftOuterJoin(wrongOperationRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiRealAccturyRateJudgeWrongOperation aoiRealAccturyRateJudgeWrongOperation = tp._2._2.get();
                        o.setGj_aoicode_t(aoiRealAccturyRateJudgeWrongOperation.getGj_aoicode_t());
                        o.setAoi_80_code(aoiRealAccturyRateJudgeWrongOperation.getAoi_80_code());
                        o.setUnionTag5("ok");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gj_aoicodeRdd cnt:{}", gj_aoicodeRdd.count());
        empcheck_aoi_codeRdd.unpersist();
        emptyCheckAoiCodeRdd.unpersist();
        wrongOperationRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpGjAoiRdd = gj_aoicodeRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag5())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empGjAoiRdd = gj_aoicodeRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag5())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpGjAoiRdd cnt:{}, empGjAoiRdd cnt:{}", noEmpGjAoiRdd.count(), empGjAoiRdd.count());
        gj_aoicodeRdd.unpersist();

//        List<String> gj_aoi_list = noEmpGjAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getGj_aoicode_t())).mapToPair(o -> new Tuple2<>(o.getGj_aoicode_t(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._1).collect();
//        List<String> aoi_80_list = noEmpGjAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_80_code())).mapToPair(o -> new Tuple2<>(o.getAoi_80_code(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._1).collect();
//        Broadcast<List<String>> gj_aoi_listBc = sc.broadcast(gj_aoi_list);
//        Broadcast<List<String>> aoi_80_listBc = sc.broadcast(aoi_80_list);

        JavaRDD<OperationPlatformMisJudgment> listRdd = noEmpGjAoiRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    List<String> gj_aoi_list = list.stream().filter(o -> StringUtils.isNotEmpty(o.getGj_aoicode_t())).map(o -> o.getGj_aoicode_t()).distinct().collect(Collectors.toList());
                    List<String> aoi_80_list = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_80_code())).map(o -> o.getAoi_80_code()).distinct().collect(Collectors.toList());
                    return list.stream().map(o -> {
                        o.setGj_aoi_list(gj_aoi_list);
                        o.setAoi_80_list(aoi_80_list);
                        return o;
                    }).collect(Collectors.toList()).iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("listRdd cnt:{}", listRdd.count());
        noEmpGjAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> tagListRdd = listRdd.map(o -> {
            List<String> gj_aoi_list = o.getGj_aoi_list();
            List<String> aoi_80_list = o.getAoi_80_list();
            String gis_final_aoi = o.getGis_final_aoi();
            if (StringUtils.isNotEmpty(gis_final_aoi) && gj_aoi_list.size() > 0 && aoi_80_list.size() > 0 && (gj_aoi_list.contains(gis_final_aoi) || aoi_80_list.contains(gis_final_aoi))) {
                o.setUnionTag6("ok");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagListRdd cnt:{}", tagListRdd.count());
        listRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noEmpTag6Rdd = tagListRdd.filter(o -> StringUtils.isNotEmpty(o.getUnionTag6())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> empTag6Rdd = tagListRdd.filter(o -> StringUtils.isEmpty(o.getUnionTag6())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpTag6Rdd cnt:{}, empTag6Rdd cnt:{}", noEmpTag6Rdd.count(), empTag6Rdd.count());
        tagListRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_wrong_xgTagRdd = empTag6Rdd.map(o -> {
            o.setTag("area_wrong_xg");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_wrong_xgTagRdd cnt:{}", area_wrong_xgTagRdd.count());
        empTag6Rdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_right_gjTagRdd = noEmpTag6Rdd.map(o -> {
            o.setTag("area_right_gj");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_right_gjTagRdd cnt:{}", area_right_gjTagRdd.count());
        noEmpTag6Rdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> xyRdd = empGjAoiRdd.map(o -> {
            String addr = "";
            String receive_addr = o.getReceive_addr();
            String city_code = o.getCity_code();
            String company_name = o.getCompany_name();
            String company_prefix = companyBc.value();
            if (judgeCompany(company_prefix, company_name)) {
                addr = receive_addr + company_name;
            } else {
                addr = receive_addr;
            }
            if (StringUtils.isNotEmpty(addr)) {
                String content = runXy(precisionGdUrlBc.value(), addr, city_code, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                        JSONObject result = jsonObject.getJSONObject("result");
                        if (result != null && StringUtils.equals(result.getString("precision"), "2")) {
                            String xcoord = result.getString("xcoord");
                            String ycoord = result.getString("ycoord");
                            String precision = result.getString("precision");
                            logger.error("xcoord:{}", xcoord);
                            logger.error("ycoord:{}", ycoord);
                            o.setXcoord(xcoord);
                            o.setYcoord(ycoord);
                            o.setPrecision(precision);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xyRdd cnt:{}", xyRdd.count());
        empGjAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> gdAoiRdd = xyRdd.map(o -> {
            String xcoord = o.getXcoord();
            String ycoord = o.getYcoord();
            if (StringUtils.isNotEmpty(xcoord) && StringUtils.isNotEmpty(ycoord)) {
                String content = runAoi(aoiidurlBc.value(), xcoord, ycoord, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject1 = JSON.parseObject(content);
                    Integer status = jsonObject1.getInteger("status");
                    if (status == 0) {
                        JSONObject result = jsonObject1.getJSONObject("result");
                        JSONArray aoi_data = result.getJSONArray("aoi_data");
                        if (aoi_data.size() > 0) {
                            String gd_aoi = aoi_data.getJSONObject(0).getString("aoi_code");
                            logger.error("gd_aoi:{}", gd_aoi);
                            o.setGd_aoi(gd_aoi);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdAoiRdd cnt:{}", gdAoiRdd.count());
        xyRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> eqGdAoiRdd = gdAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getGd_aoi()) && StringUtils.equals(o.getGd_aoi(), o.getGis_final_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noEqGdAoiRdd = gdAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getGd_aoi()) && StringUtils.equals(o.getGd_aoi(), o.getGis_final_aoi()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqGdAoiRdd cnt:{}, noEqGdAoiRdd cnt:{}", eqGdAoiRdd.count(), noEqGdAoiRdd.count());
        gdAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> area_right_gdTagRdd = eqGdAoiRdd.map(o -> {
            o.setTag("area_right_gd");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("area_right_gdTagRdd cnt:{}", area_right_gdTagRdd.count());
        eqGdAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> noTagRdd = noEqGdAoiRdd.map(o -> {
            o.setTag("no");
            o.setGroup_tag("no");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noTagRdd cnt:{}", noTagRdd.count());
        noEqGdAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> sufixRdd = area_rightTagRdd.union(area_right_gjTagRdd).filter(o -> StringUtils.equals(o.getGis_src(), "norm") || StringUtils.equals(o.getGis_src(), "chkn")).filter(o -> {
            String end_words = "村|工业区|工业园|工业园区|产业园";
            String receive_addr = o.getReceive_addr();
            boolean flag = true;
            if (StringUtils.isNotEmpty(receive_addr)) {
                String[] split = end_words.split("\\|");
                for (String s : split) {
                    if (receive_addr.endsWith(s)) {
                        flag = false;
                    }
                }
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        area_rightTagRdd.unpersist();
        area_right_gjTagRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> uniqueFinalaoicodeRdd = sufixRdd.mapToPair(o -> new Tuple2<>(o.getGis_gid(), o))
                .groupByKey()
                .filter(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    int size = list.stream()
                            .filter(o -> StringUtils.isNotEmpty(o.getFinalaoicode()))
                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OperationPlatformMisJudgment::getFinalaoicode))), ArrayList::new))
                            .size();
                    boolean flag = false;
                    if (size == 1) {
                        flag = true;
                    }
                    return flag;
                }).flatMap(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    return list.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueFinalaoicodeRdd cnt:{}", uniqueFinalaoicodeRdd.count());
        sufixRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> proAoiRdd = uniqueFinalaoicodeRdd.map(o -> {
            String receive_addr = o.getReceive_addr();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(receive_addr)) {
                String content = run(misjudgeaoiUrlBc.value(), receive_addr, city_code, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        if (jsonObject.getInteger("status") == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                JSONArray tcs = result.getJSONArray("tcs");
                                if (tcs != null && tcs.size() > 0) {
                                    String aoiid = tcs.getJSONObject(0).getString("aoicode");
                                    logger.error("aoiid:{}", aoiid);
                                    o.setProAoi(aoiid);
                                }
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("proAoiRdd cnt:{}", proAoiRdd.count());
        uniqueFinalaoicodeRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> eqProAoiRdd = proAoiRdd.filter(o -> StringUtils.equals(o.getGis_final_aoi(), o.getProAoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<OperationPlatformMisJudgment> noEqProAoiRdd = proAoiRdd.filter(o -> !StringUtils.equals(o.getGis_final_aoi(), o.getProAoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqProAoiRdd cnt:{}", eqProAoiRdd.count());
        logger.error("noEqProAoiRdd cnt:{}", noEqProAoiRdd.count());
        proAoiRdd.unpersist();

//        JavaRDD<OperationPlatformMisJudgment> noTagEqProAoiRdd = noEqProAoiRdd.map(o -> {
//            o.setGroup_tag("no");
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("noTagEqProAoiRdd cnt:{}", noTagEqProAoiRdd.count());
//        noEqProAoiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> checkRdd = eqProAoiRdd.map(o -> {
            o.setGroup_tag("yes");
            String city_code = o.getCity_code();
            String gis_gid = o.getGis_gid();
            if (StringUtils.isNotEmpty(gis_gid)) {
                JSONArray list = new JSONArray();
                list.add(gis_gid);

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cityCode", city_code);
                jsonObject.put("aoiCheckTag", 1);
                jsonObject.put("addressIds", list);

                String content = runCheckTag(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                logger.error("result:{}", content);
//                if (StringUtils.isNotEmpty(content)) {
//                    JSONObject jsonObject1 = JSON.parseObject(content);
//                    if (jsonObject1 != null) {
//                        Boolean success = jsonObject1.getBoolean("success");
//                        o.setCheckFlag(success);
//                    }
//                }

            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd cnt:{}", checkRdd.count());
        eqProAoiRdd.unpersist();

//        JavaRDD<OperationPlatformMisJudgment> resultRdd2 = checkRdd.union(noTagEqProAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd2 cnt:{}", resultRdd2.count());
//        noTagEqProAoiRdd.unpersist();
//        checkRdd.unpersist();

        String executeSql1 = String.format("alter table dm_gis.aoi_real_acc_rate_report_group_tag drop if EXISTS partition(inc_day='%s')", date);
        logger.error("executeSql1 :{}", executeSql1);
        spark.sql(executeSql1);
        saveData(spark, checkRdd, date, "dm_gis.aoi_real_acc_rate_report_group_tag");
        checkRdd.unpersist();


        JavaRDD<OperationBottomcorrected> req_addresseeaddrRdd = loadAoiRealAccturyRateData1(spark, sc, beforeDate, date).filter(o ->
                StringUtils.equals(o.getTag1(), "wrong")
                        || (StringUtils.equals(o.getTag1(), "no") && (StringUtils.equals(o.getTag2(), "wrong_pc1") || StringUtils.equals(o.getTag2(), "wrong_pc2")))
                        || (StringUtils.equals(o.getTag1(), "no") && !StringUtils.equals(o.getTag2(), "wrong_pc1") && !StringUtils.equals(o.getTag2(), "wrong_pc2") && StringUtils.equals(o.getTag3(), "wrong_yw")))
                .map(o -> {
                    String month = o.getInc_day().substring(0, 6);
                    o.setMonth(month);
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("req_addresseeaddrRdd cnt:{}", req_addresseeaddrRdd.count());

        JavaRDD<OperationPlatformMisJudgment> unionRdd = area_right_bottomTagRdd.union(area_rightTagRdd).union(area_right_cgTagRdd).union(area_right_gjTagRdd).union(area_right_gdTagRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unionRdd cnt:{}", unionRdd.count());
        area_right_bottomTagRdd.unpersist();
        area_rightTagRdd.unpersist();
        area_right_cgTagRdd.unpersist();
        area_right_gjTagRdd.unpersist();
        area_right_gdTagRdd.unpersist();

        JavaRDD<OperationBottomcorrected> req_addresseeaddrRdd1 = req_addresseeaddrRdd.mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o))
                .leftOuterJoin(unionRdd.mapToPair(o -> new Tuple2<>(o.getReceive_addr(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("req_addresseeaddrRdd1 cnt:{}", req_addresseeaddrRdd1.count());
        req_addresseeaddrRdd.unpersist();

        JavaRDD<OperationBottomcorrected> address_countRdd = req_addresseeaddrRdd1.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getReq_addresseeaddr(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<OperationBottomcorrected> list = Lists.newArrayList(tp._2);
                    int address_count = list.size();
                    List<OperationBottomcorrected> resultList = list.stream().map(o -> {
                        o.setAddress_count(address_count + "");
                        return o;
                    }).collect(Collectors.toList());
                    return resultList.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("address_countRdd cnt:{}", address_countRdd.count());
        req_addresseeaddrRdd1.unpersist();

        JavaRDD<OperationBottomcorrected> address_count_monthlyRdd = address_countRdd.mapToPair(o -> new Tuple2<>(o.getMonth() + "_" + o.getReq_addresseeaddr(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<OperationBottomcorrected> list = Lists.newArrayList(tp._2);
                    int address_count_monthly = list.size();
                    List<OperationBottomcorrected> resultList = list.stream().map(o -> {
                        o.setAddress_count_monthly(address_count_monthly + "");
                        return o;
                    }).collect(Collectors.toList());
                    return resultList.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("address_count_monthlyRdd cnt:{}", address_count_monthlyRdd.count());
        address_countRdd.unpersist();

        JavaRDD<OperationBottomcorrected> address_count_zcRdd = address_count_monthlyRdd.mapToPair(o -> new Tuple2<>(o.getFinalzc(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<OperationBottomcorrected> list = Lists.newArrayList(tp._2);
                    int size = list.size();
                    return list.stream().map(o -> {
                        o.setAddress_count_zc(size + "");
                        return o;
                    }).collect(Collectors.toList()).iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("address_count_zcRdd cnt:{}", address_count_zcRdd.count());
        address_count_monthlyRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> addrCountRdd = unionRdd.mapToPair(o -> new Tuple2<>(o.getReceive_addr(), o))
                .leftOuterJoin(address_count_zcRdd.mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        OperationBottomcorrected operationBottomcorrected = tp._2._2.get();
                        o.setAddress_count(operationBottomcorrected.getAddress_count());
                        o.setAddress_count_monthly(operationBottomcorrected.getAddress_count_monthly());
                        o.setAddress_count_zc(operationBottomcorrected.getAddress_count_zc());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrCountRdd cnt:{}", addrCountRdd.count());
        unionRdd.unpersist();
        address_count_zcRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> resultRdd1 = addrCountRdd.union(area_wrong_cgTagRdd).union(area_wrong_xgTagRdd).union(noTagRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd1 cnt:{}", resultRdd1.count());
        addrCountRdd.unpersist();
        area_wrong_cgTagRdd.unpersist();
        area_wrong_xgTagRdd.unpersist();
        noTagRdd.unpersist();

        logger.error("数据入库");
        String executeSql = String.format("alter table dm_gis.aoi_real_acc_rate_report_addr_count_zc drop if EXISTS partition(inc_day='%s')", date);
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, resultRdd1, date, "dm_gis.aoi_real_acc_rate_report_addr_count_zc");
        resultRdd1.unpersist();

        spark.stop();
    }

    public void saveData(SparkSession spark, JavaRDD<OperationPlatformMisJudgment> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getOrigi_id(), o.getFault_reason(), o.getCity_code(), o.getZno_code(), o.getReceive_addr(),
                    o.getGis_gid(), o.getGis_src(), o.getCompany_name(), o.getFinal_aoi_name(), o.getGis_final_aoi(),
                    o.getNew_data_date(), o.getRemark_reason(), o.getUpload_date(), o.getTag(), o.getGroup_tag(), o.getBottomcorrected(), o.getRight_freq(), o.getFinalaoicode(),
                    o.getCheck_aoi_code(),
                    o.getAoi_80_list() != null && o.getAoi_80_list().size() > 0 ? o.getAoi_80_list().stream().collect(Collectors.joining(",")) : "",
                    o.getGj_aoi_list() != null && o.getGj_aoi_list().size() > 0 ? o.getGj_aoi_list().stream().collect(Collectors.joining(",")) : "",
                    o.getGd_aoi(), o.getAddress_count(), o.getAddress_count_monthly(), o.getAddress_count_zc()

            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"origin_id", "fault_reason", "city_code", "zno_code", "receive_addr",
                "gid", "gis_src", "company_name", "gis_final_aoi_name", "gis_final_aoi",
                "new_data_date", "remark_reason", "upload_date", "tag", "group_tag", "bottomcorrected", "right_freq", "finalaoicode",
                "cgcheck_aoi_code", "80_list", "gj_aoi_list", "gd_aoi", "address_count", "address_count_monthly", "address_count_zc"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "mis_judgment_group_correct_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", table, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public String runCheckTag(String url, String param) {
        String content = "";
        try {
            logger.error("check tag url:{}", url);
            content = UrlUtil.sendPost(url, param);
            logger.error("content:{}", content);
        } catch (Exception e) {
            logger.error("check tag error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean judgeCompany(String company_prefix, String company) {
        boolean flag = false;
        if (StringUtils.isNotEmpty(company)) {
            String[] companyList = company_prefix.split("\\|");
            for (String s : companyList) {
                if (company.contains(s)) {
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }


    public JavaRDD<AoiRealAccturyRateFinalData> loadGisgidData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select id,gis_to_sys_groupid,gisaoisrc,inc_day from dm_gis.aoi_real_acctury_rate_final_data where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateFinalData.class);
    }


    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadWrongOperationData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select gis_to_sys_groupid,gj_aoicode_t,80_aoi_code,finalaoicode from dm_gis.aoi_real_acctury_rate_judge_wrong_operation where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

    public JavaRDD<OperationPlatformMisJudgment> loadSourceData(SparkSession spark, JavaSparkContext sc, String date, String startDate, String endDate) {
        String sql = String.format("select gid origi_id,city_code,zno_code,company_name,final_aoi gis_final_aoi,data_date new_data_date,remark_reason,final_aoi_name,gis_src,address_id gis_gid,fault_reason,upload_date,receive_addr from dm_gis.fault_feedback where inc_day = '%s' and upload_date between '%s' and '%s'", date, startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, OperationPlatformMisJudgment.class);
    }


    public JavaRDD<OperationBottomcorrected> loadAoiRealAccturyRateData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select gis_to_sys_groupid,finalaoicode,bottomcorrected from dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected where inc_day between '%s' and '%s' and bottomcorrected = 'yes'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, OperationBottomcorrected.class);
    }

    public JavaRDD<OperationBottomcorrected> loadAoiRealAccturyRateData1(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select finalzc,req_addresseeaddr,gis_to_sys_groupid,finalaoicode,bottomcorrected,tag1,tag2,tag3,inc_day from dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, OperationBottomcorrected.class);
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadAoiRealAccturyRateJudgeWrongOperationWeekStatData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select gis_to_sys_groupid,right_freq,label,finalaoicode,inc_day from dm_gis.aoi_real_acctury_rate_judge_wrong_operation_week_stat where operate_date between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

    public JavaRDD<CghsResultData> loadCghsData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select check_aoi_code,gid from dm_gis.cghs_result_data where inc_day between '%s' and '%s' and source in ('chkn_WRONG_AOI_PN', 'norm_WRONG_AOI_PN', 'norm_WRONG_AOI_SAME') ", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CghsResultData.class);
    }

    public String run(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public String runAoi(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            logger.error("aoi url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request aoi error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runXy(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public static void main(String[] args) {
//        List<String> gj_aoi_list = new ArrayList<>();
//        gj_aoi_list.add("1");
//        gj_aoi_list.add("2");
//        gj_aoi_list.add("3");
//        System.out.println(gj_aoi_list.stream().collect(Collectors.joining(",")));

        System.out.println(URLEncoder.encode("福建省福州市鼓楼区鼓东街道井关外路8号4-402"));
    }

}
