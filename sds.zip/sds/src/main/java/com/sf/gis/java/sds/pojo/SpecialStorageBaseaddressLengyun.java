package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SpecialStorageBaseaddressLengyun implements Serializable {
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "county")
    private String county;
    @Column(name = "address")
    private String address;
    @Column(name = "norm_address")
    private String norm_address;
    @Column(name = "company")
    private String company;
    @Column(name = "termresult")
    private String termresult;
    @Column(name = "addresstype")
    private String addresstype;
    @Column(name = "warehousename")
    private String warehousename;
    @Column(name = "warehousetype")
    private String warehousetype;
    @Column(name = "warehouseid")
    private String warehouseid;
    @Column(name = "tag")
    private String tag;
    @Column(name = "exceptional")
    private String exceptional;
    @Column(name = "regex")
    private String regex;
    @Column(name = "create_user")
    private String create_user;
    @Column(name = "create_time")
    private String create_time;
    @Column(name = "update_user")
    private String update_user;
    @Column(name = "update_time")
    private String update_time;
    @Column(name = "del_flag")
    private String del_flag;
    @Column(name = "company_name")
    private String company_name;
    @Column(name = "tag_fuzzy")
    private String tag_fuzzy;
    @Column(name = "splitresult_zaiku")
    private String splitresult_zaiku;
    @Column(name = "company_zaiku")
    private String company_zaiku;
    @Column(name = "word911_zaiku")
    private String word911_zaiku;
    @Column(name = "word9list_zaiku")
    private String word9list_zaiku;
    @Column(name = "word13list_zaiku")
    private String word13list_zaiku;
    @Column(name = "maxlevel_zaiku")
    private String maxlevel_zaiku;
    @Column(name = "splitresult_zaiku_notype")
    private String splitresult_zaiku_notype;
    @Column(name = "splitresult_zaiku_norepeat")
    private String splitresult_zaiku_norepeat;
    @Column(name = "all14numletter_zaiku")
    private String all14numletter_zaiku;
    @Column(name = "all15numletter_zaiku")
    private String all15numletter_zaiku;
    @Column(name = "all16numletter_zaiku")
    private String all16numletter_zaiku;
    @Column(name = "all17numletter_zaiku")
    private String all17numletter_zaiku;
    @Column(name = "judge_subset1")
    private String judge_subset1;
    @Column(name = "judge_set2_911")
    private String judge_set2_911;
    @Column(name = "judge_set2_913")
    private String judge_set2_913;
    @Column(name = "judge_set3_911")
    private String judge_set3_911;
    @Column(name = "judge_set3_913")
    private String judge_set3_913;
    @Column(name = "judge_result")
    private String judge_result;

    @Column(name = "splitresult_zaiku_norepeat_no18")
    private String splitresult_zaiku_norepeat_no18;
    @Column(name = "xzqh")
    private String xzqh;
    @Column(name = "allsame13")
    private String allsame13;
    @Column(name = "firstsame13")
    private String firstsame13;
    @Column(name = "xzqh_undecided")
    private String xzqh_undecided;
    @Column(name = "word9101112_undecided")
    private String word9101112_undecided;
    @Column(name = "wordlargerthan12_undecided")
    private String wordlargerthan12_undecided;
    @Column(name = "reform_address")
    private String reform_address;

    @Column(name = "inc_day")
    private String inc_day;

    private String temp_tag;

    public String getSplitresult_zaiku_norepeat_no18() {
        return splitresult_zaiku_norepeat_no18;
    }

    public void setSplitresult_zaiku_norepeat_no18(String splitresult_zaiku_norepeat_no18) {
        this.splitresult_zaiku_norepeat_no18 = splitresult_zaiku_norepeat_no18;
    }

    public String getXzqh() {
        return xzqh;
    }

    public void setXzqh(String xzqh) {
        this.xzqh = xzqh;
    }

    public String getAllsame13() {
        return allsame13;
    }

    public void setAllsame13(String allsame13) {
        this.allsame13 = allsame13;
    }

    public String getFirstsame13() {
        return firstsame13;
    }

    public void setFirstsame13(String firstsame13) {
        this.firstsame13 = firstsame13;
    }

    public String getXzqh_undecided() {
        return xzqh_undecided;
    }

    public void setXzqh_undecided(String xzqh_undecided) {
        this.xzqh_undecided = xzqh_undecided;
    }

    public String getWord9101112_undecided() {
        return word9101112_undecided;
    }

    public void setWord9101112_undecided(String word9101112_undecided) {
        this.word9101112_undecided = word9101112_undecided;
    }

    public String getWordlargerthan12_undecided() {
        return wordlargerthan12_undecided;
    }

    public void setWordlargerthan12_undecided(String wordlargerthan12_undecided) {
        this.wordlargerthan12_undecided = wordlargerthan12_undecided;
    }

    public String getReform_address() {
        return reform_address;
    }

    public void setReform_address(String reform_address) {
        this.reform_address = reform_address;
    }

    public String getJudge_set3_911() {
        return judge_set3_911;
    }

    public void setJudge_set3_911(String judge_set3_911) {
        this.judge_set3_911 = judge_set3_911;
    }

    public String getJudge_set3_913() {
        return judge_set3_913;
    }

    public void setJudge_set3_913(String judge_set3_913) {
        this.judge_set3_913 = judge_set3_913;
    }

    public String getJudge_set2_911() {
        return judge_set2_911;
    }

    public void setJudge_set2_911(String judge_set2_911) {
        this.judge_set2_911 = judge_set2_911;
    }

    public String getJudge_set2_913() {
        return judge_set2_913;
    }

    public void setJudge_set2_913(String judge_set2_913) {
        this.judge_set2_913 = judge_set2_913;
    }

    public String getJudge_result() {
        return judge_result;
    }

    public void setJudge_result(String judge_result) {
        this.judge_result = judge_result;
    }

    public String getJudge_subset1() {
        return judge_subset1;
    }

    public void setJudge_subset1(String judge_subset1) {
        this.judge_subset1 = judge_subset1;
    }

    public String getTemp_tag() {
        return temp_tag;
    }

    public void setTemp_tag(String temp_tag) {
        this.temp_tag = temp_tag;
    }

    public String getAll15numletter_zaiku() {
        return all15numletter_zaiku;
    }

    public void setAll15numletter_zaiku(String all15numletter_zaiku) {
        this.all15numletter_zaiku = all15numletter_zaiku;
    }

    public String getAll16numletter_zaiku() {
        return all16numletter_zaiku;
    }

    public void setAll16numletter_zaiku(String all16numletter_zaiku) {
        this.all16numletter_zaiku = all16numletter_zaiku;
    }

    public String getAll17numletter_zaiku() {
        return all17numletter_zaiku;
    }

    public void setAll17numletter_zaiku(String all17numletter_zaiku) {
        this.all17numletter_zaiku = all17numletter_zaiku;
    }

    public String getAll14numletter_zaiku() {
        return all14numletter_zaiku;
    }

    public void setAll14numletter_zaiku(String all14numletter_zaiku) {
        this.all14numletter_zaiku = all14numletter_zaiku;
    }

    public String getSplitresult_zaiku_norepeat() {
        return splitresult_zaiku_norepeat;
    }

    public void setSplitresult_zaiku_norepeat(String splitresult_zaiku_norepeat) {
        this.splitresult_zaiku_norepeat = splitresult_zaiku_norepeat;
    }

    public String getSplitresult_zaiku_notype() {
        return splitresult_zaiku_notype;
    }

    public void setSplitresult_zaiku_notype(String splitresult_zaiku_notype) {
        this.splitresult_zaiku_notype = splitresult_zaiku_notype;
    }

    public String getMaxlevel_zaiku() {
        return maxlevel_zaiku;
    }

    public void setMaxlevel_zaiku(String maxlevel_zaiku) {
        this.maxlevel_zaiku = maxlevel_zaiku;
    }

    public String getWord9list_zaiku() {
        return word9list_zaiku;
    }

    public void setWord9list_zaiku(String word9list_zaiku) {
        this.word9list_zaiku = word9list_zaiku;
    }

    public String getWord13list_zaiku() {
        return word13list_zaiku;
    }

    public void setWord13list_zaiku(String word13list_zaiku) {
        this.word13list_zaiku = word13list_zaiku;
    }

    public String getWord911_zaiku() {
        return word911_zaiku;
    }

    public void setWord911_zaiku(String word911_zaiku) {
        this.word911_zaiku = word911_zaiku;
    }

    public String getCompany_zaiku() {
        return company_zaiku;
    }

    public void setCompany_zaiku(String company_zaiku) {
        this.company_zaiku = company_zaiku;
    }

    public String getSplitresult_zaiku() {
        return splitresult_zaiku;
    }

    public void setSplitresult_zaiku(String splitresult_zaiku) {
        this.splitresult_zaiku = splitresult_zaiku;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNorm_address() {
        return norm_address;
    }

    public void setNorm_address(String norm_address) {
        this.norm_address = norm_address;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getTermresult() {
        return termresult;
    }

    public void setTermresult(String termresult) {
        this.termresult = termresult;
    }

    public String getAddresstype() {
        return addresstype;
    }

    public void setAddresstype(String addresstype) {
        this.addresstype = addresstype;
    }

    public String getWarehousename() {
        return warehousename;
    }

    public void setWarehousename(String warehousename) {
        this.warehousename = warehousename;
    }

    public String getWarehousetype() {
        return warehousetype;
    }

    public void setWarehousetype(String warehousetype) {
        this.warehousetype = warehousetype;
    }

    public String getWarehouseid() {
        return warehouseid;
    }

    public void setWarehouseid(String warehouseid) {
        this.warehouseid = warehouseid;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getExceptional() {
        return exceptional;
    }

    public void setExceptional(String exceptional) {
        this.exceptional = exceptional;
    }

    public String getRegex() {
        return regex;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public String getCreate_user() {
        return create_user;
    }

    public void setCreate_user(String create_user) {
        this.create_user = create_user;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getUpdate_user() {
        return update_user;
    }

    public void setUpdate_user(String update_user) {
        this.update_user = update_user;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getDel_flag() {
        return del_flag;
    }

    public void setDel_flag(String del_flag) {
        this.del_flag = del_flag;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getTag_fuzzy() {
        return tag_fuzzy;
    }

    public void setTag_fuzzy(String tag_fuzzy) {
        this.tag_fuzzy = tag_fuzzy;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
