package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class TtAppointAddition implements Serializable {
    @Column(name = "appoint_internal_no")
    private String appoint_internal_no;
    @Column(name = "addition_key")
    private String addition_key;
    @Column(name = "addition_value")
    private String addition_value;

    public String getAppoint_internal_no() {
        return appoint_internal_no;
    }

    public void setAppoint_internal_no(String appoint_internal_no) {
        this.appoint_internal_no = appoint_internal_no;
    }

    public String getAddition_key() {
        return addition_key;
    }

    public void setAddition_key(String addition_key) {
        this.addition_key = addition_key;
    }

    public String getAddition_value() {
        return addition_value;
    }

    public void setAddition_value(String addition_value) {
        this.addition_value = addition_value;
    }
}
