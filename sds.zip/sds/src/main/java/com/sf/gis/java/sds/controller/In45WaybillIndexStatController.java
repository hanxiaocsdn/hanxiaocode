package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CgcsSgsAoiExp;
import com.sf.gis.java.sds.pojo.CityNameMap;
import com.sf.gis.java.sds.pojo.In45Waybill;
import com.sf.gis.java.sds.pojo.In45WaybillIndex;
import com.sf.gis.java.sds.service.StdBaseService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class In45WaybillIndexStatController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(In45WaybillIndexStatController.class);
    StdBaseService service = new StdBaseService();

    public void process(String date1, String date2) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        JavaRDD<In45Waybill> in45WaybillRdd = loadData(spark, sc, date1, date2).filter(o -> StringUtils.isNotEmpty(o.getDest_dist_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("in45WaybillRdd cnt:{}", in45WaybillRdd.count());

        List<CityNameMap> cityNameMapList = service.loadCityNameMap(spark, sc).collect();
        logger.error("cityNameMapList cnt:{}", cityNameMapList.size());
        Broadcast<List<CityNameMap>> cityNameMapListBc = sc.broadcast(cityNameMapList);

        JavaRDD<In45Waybill> cityNameRdd = in45WaybillRdd.map(o -> {
            List<CityNameMap> cityNameMapListTemp = cityNameMapListBc.value();
            String dest_dist_code = o.getDest_dist_code();
            List<CityNameMap> collect = cityNameMapListTemp.stream().filter(t -> StringUtils.equals(t.getCitycode(), dest_dist_code)).collect(Collectors.toList());
            if (collect.size() > 0) {
                o.setRegion(collect.get(0).getRegion());
                String city = ArrayUtil.joinArr(collect.stream().sorted((o1, o2) -> o1.getAdcode().compareTo(o2.getAdcode())).map(t -> t.getCity()).collect(Collectors.toList()), "/");
                o.setCity(city);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityNameRdd cnt:{}", cityNameRdd.count());
        in45WaybillRdd.unpersist();


        JavaRDD<In45Waybill> waybillRequesttypeUniqueRdd = cityNameRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no() + o.getRequesttype(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<In45Waybill> waybillUniqueRdd = cityNameRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("waybillRequesttypeUniqueRdd cnt:{}", waybillRequesttypeUniqueRdd.count());
        logger.error("waybillUniqueRdd cnt:{}", waybillUniqueRdd.count());
        cityNameRdd.unpersist();


        JavaRDD<In45WaybillIndex> allStatRdd = waybillRequesttypeUniqueRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getDest_dist_code() + "_" + o.getRequesttype(), o)).groupByKey().map(tp -> processStatNew(tp._1, "total", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("allStatRdd cnt:{}", allStatRdd.count());

        JavaRDD<In45Waybill> residenceRdd = waybillRequesttypeUniqueRdd.filter(o -> StringUtils.equals(o.getAoitypecode(), "120302") || StringUtils.equals(o.getAoitypecode(), "120301") || StringUtils.equals(o.getAoitypecode(), "120305") || StringUtils.equals(o.getAoitypecode(), "120203")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("residenceRdd cnt:{}", residenceRdd.count());
        waybillRequesttypeUniqueRdd.unpersist();

        JavaRDD<In45WaybillIndex> residenceStatRdd = residenceRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getDest_dist_code() + "_" + o.getRequesttype(), o)).groupByKey().map(tp -> processStatNew(tp._1, "residence", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("residenceStatRdd cnt:{}", residenceStatRdd.count());
        residenceRdd.unpersist();

        JavaRDD<In45WaybillIndex> lastRdd = allStatRdd.union(residenceStatRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        allStatRdd.unpersist();
        residenceStatRdd.unpersist();

        saveData(spark, lastRdd, "dm_gis.in45_waybill_stat_new");
        lastRdd.unpersist();


//        JavaRDD<In45WaybillIndex> dateRdd = waybillUniqueRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_", o)).groupByKey().map(tp -> processStat("ALL", tp._1, "total", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<In45WaybillIndex> regionRdd = waybillUniqueRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getRegion(), o)).groupByKey().map(tp -> processStat("REGION", tp._1, "total", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<In45WaybillIndex> cityRdd = waybillUniqueRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getDest_dist_code(), o)).groupByKey().map(tp -> processStat("CITY", tp._1, "total", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("dateRdd cnt:{}", dateRdd.count());
//        logger.error("regionRdd cnt:{}", regionRdd.count());
//        logger.error("cityRdd cnt:{}", cityRdd.count());
//
//
//        JavaRDD<In45Waybill> residenceOtherRdd = waybillUniqueRdd.filter(o -> StringUtils.equals(o.getAoitypecode(), "120302") || StringUtils.equals(o.getAoitypecode(), "120301") || StringUtils.equals(o.getAoitypecode(), "120305") || StringUtils.equals(o.getAoitypecode(), "120203")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("residenceOtherRdd cnt:{}", residenceOtherRdd.count());
//        waybillUniqueRdd.unpersist();
//
//
//        JavaRDD<In45WaybillIndex> residenceDateRdd = residenceOtherRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_", o)).groupByKey().map(tp -> processStat("ALL", tp._1, "residence", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<In45WaybillIndex> residenceRegionRdd = residenceOtherRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getRegion(), o)).groupByKey().map(tp -> processStat("REGION", tp._1, "residence", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<In45WaybillIndex> residenceCityRdd = residenceOtherRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getDest_dist_code(), o)).groupByKey().map(tp -> processStat("CITY", tp._1, "residence", Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("residenceDateRdd cnt:{}", residenceDateRdd.count());
//        logger.error("residenceRegionRdd cnt:{}", residenceRegionRdd.count());
//        logger.error("residenceCityRdd cnt:{}", residenceCityRdd.count());
//        residenceOtherRdd.unpersist();
//
//        JavaRDD<In45WaybillIndex> resultRdd = dateRdd.union(regionRdd).union(cityRdd).union(residenceDateRdd).union(residenceRegionRdd).union(residenceCityRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        dateRdd.unpersist();
//        regionRdd.unpersist();
//        cityRdd.unpersist();
//        residenceDateRdd.unpersist();
//        residenceRegionRdd.unpersist();
//        residenceCityRdd.unpersist();
//
//        DataUtil.saveOverwrite(spark, sc, "dm_gis.in45_waybill_stat", In45WaybillIndex.class, resultRdd, "inc_day");
//        resultRdd.unpersist();

    }


    public void saveData(SparkSession spark, JavaRDD<In45WaybillIndex> inRdd, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getId(), o.getStat_date(), o.getRegion(), o.getCityCode(), o.getCity(),
                    o.getRequesttype(), o.getTag(), o.getGis_cnt(), o.getDistinguish_cnt(), o.getFee_cnt(),
                    o.getClimb_cnt(), o.getClimb_fee_cnt(), o.getNo_elevator_cnt(), o.getNo_elevator_fee_cnt(), o.getNo_climb_cnt(),
                    o.getNo_climb_fee_cnt(), o.getNo_distinguish_cnt(), o.getNo_distinguish_fee_cnt(), o.getInc_day()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "id", "stat_date", "region", "citycode", "city",
                "requesttype", "tag", "gis_cnt", "distinguish_cnt", "fee_cnt",
                "climb_cnt", "climb_fee_cnt", "no_elevator_cnt", "no_elevator_fee_cnt", "no_climb_cnt",
                "no_climb_fee_cnt", "no_distinguish_cnt", "no_distinguish_fee_cnt", "inc_day"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "in45_waybill_stat_new_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert overwrite table %s partition(inc_day)" +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);
    }

    public static JavaRDD<In45Waybill> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select * from dm_gis.in45_waybill where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, In45Waybill.class);
    }

    public In45WaybillIndex processStatNew(String stat_type_content, String tag, List<In45Waybill> list) {
        long gis_cnt = list.size();
        long distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") || StringUtils.equals(o.getIsclimb(), "1") || StringUtils.equals(o.getIsclimb(), "2")).count();
        long fee_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getService_fee())).count();

        long climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1")).count();
        long climb_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2")).count();
        long no_elevator_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0")).count();
        long no_climb_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1")).count();
        long no_distinguish_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.isNotEmpty(o.getService_fee())).count();

        In45WaybillIndex o = new In45WaybillIndex();
        o.setGis_cnt(gis_cnt + "");
        o.setDistinguish_cnt(distinguish_cnt + "");
        o.setFee_cnt(fee_cnt + "");
        o.setClimb_cnt(climb_cnt + "");
        o.setClimb_fee_cnt(climb_fee_cnt + "");
        o.setNo_elevator_cnt(no_elevator_cnt + "");
        o.setNo_elevator_fee_cnt(no_elevator_fee_cnt + "");
        o.setNo_climb_cnt(no_climb_cnt + "");
        o.setNo_climb_fee_cnt(no_climb_fee_cnt + "");
        o.setNo_distinguish_cnt(no_distinguish_cnt + "");
        o.setNo_distinguish_fee_cnt(no_distinguish_fee_cnt + "");

        In45Waybill in45Waybill = list.get(0);
        String[] split = stat_type_content.split("_");

        String date = split[0];
        String citycode = split[1];
        String requesttype = split.length >= 3 ? split[2] : "";
        String city = in45Waybill.getCity();
        String region = in45Waybill.getRegion();

        o.setId(DigestUtils.md5Hex(date + stat_type_content + tag));
        o.setStat_date(date);
        o.setInc_day(date);
        o.setTag(tag);
        o.setRequesttype(requesttype);
        o.setRegion(region);
        o.setCityCode(citycode);
        o.setCity(city);

        return o;
    }

    public In45WaybillIndex processStat(String stat_type, String stat_type_content, String tag, List<In45Waybill> list) {
        long gis_cnt = list.size();
        long distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") || StringUtils.equals(o.getIsclimb(), "1") || StringUtils.equals(o.getIsclimb(), "2")).count();
        long fee_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getService_fee())).count();

        long climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1")).count();
        long climb_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2")).count();
        long no_elevator_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0")).count();
        long no_climb_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.isNotEmpty(o.getService_fee())).count();

        long no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1")).count();
        long no_distinguish_fee_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.isNotEmpty(o.getService_fee())).count();

        In45WaybillIndex o = new In45WaybillIndex();
        o.setGis_cnt(gis_cnt + "");
        o.setDistinguish_cnt(distinguish_cnt + "");
        o.setFee_cnt(fee_cnt + "");
        o.setClimb_cnt(climb_cnt + "");
        o.setClimb_fee_cnt(climb_fee_cnt + "");
        o.setNo_elevator_cnt(no_elevator_cnt + "");
        o.setNo_elevator_fee_cnt(no_elevator_fee_cnt + "");
        o.setNo_climb_cnt(no_climb_cnt + "");
        o.setNo_climb_fee_cnt(no_climb_fee_cnt + "");
        o.setNo_distinguish_cnt(no_distinguish_cnt + "");
        o.setNo_distinguish_fee_cnt(no_distinguish_fee_cnt + "");
        String date = stat_type_content.split("_")[0];
        o.setId(DigestUtils.md5Hex(date + stat_type + stat_type_content + tag));
        o.setStat_date(date);
        o.setInc_day(date);
        o.setTag(tag);
        o.setStat_type(stat_type);
        if (StringUtils.equals(stat_type, "ALL")) {
            o.setStat_type_content("ALL");
            o.setRegion("ALL");
            o.setCityCode("ALL");
            o.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "REGION")) {
            String region = stat_type_content.split("_")[1];
            o.setStat_type_content(region);
            o.setRegion(region);
            o.setCityCode("ALL");
            o.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "CITY")) {
            String citycode = stat_type_content.split("_")[1];
            In45Waybill in45Waybill = list.get(0);
            String region = in45Waybill.getRegion();
            String city = in45Waybill.getCity();

            o.setStat_type_content(city);
            o.setRegion(region);
            o.setCityCode(citycode);
            o.setCity(city);
        }
        return o;
    }
}
