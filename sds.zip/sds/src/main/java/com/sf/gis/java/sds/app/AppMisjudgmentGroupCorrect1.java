package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.MisjudgmentGroupCorrectController1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppMisjudgmentGroupCorrect1 {
    private static Logger logger = LoggerFactory.getLogger(AppMisjudgmentGroupCorrect1.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new MisjudgmentGroupCorrectController1().start(startDate, endDate);
        logger.error("run end");
    }
}
