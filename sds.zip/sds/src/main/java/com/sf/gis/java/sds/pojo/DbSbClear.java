package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DbSbClear implements Serializable {
    @Column(name = "reqTime")
    private String reqTime;
    @Column(name = "sn")
    private String sn;
    @Column(name = "address")
    private String address;
    @Column(name = "depponZc")
    private String depponZc;
    @Column(name = "src")
    private String src;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "zc")
    private String zc;
    @Column(name = "keyWord")
    private String keyWord;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "dataSrc")
    private String dataSrc;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "city")
    private String city;
    @Column(name = "his_num")
    private String his_num;
    @Column(name = "his_zc_diff_num")
    private String his_zc_diff_num;
    @Column(name = "sign_zc_invalid")
    private String sign_zc_invalid;
    @Column(name = "zc_new")
    private String zc_new;
    @Column(name = "source_new")
    private String source_new;
    @Column(name = "tc_new")
    private String tc_new;
    @Column(name = "keyword_new")
    private String keyword_new;
    @Column(name = "match_new")
    private String match_new;
    @Column(name = "adcode_new")
    private String adcode_new;
    @Column(name = "msg_new")
    private String msg_new;
    @Column(name = "is_modify")
    private String is_modify;
    @Column(name = "key_diff_zc_num")
    private String key_diff_zc_num;
    @Column(name = "deal_type")
    private String deal_type;
    @Column(name = "status_deal")
    private String status_deal;

    @Column(name = "adcode_normal")
    private String adcode_normal;
    @Column(name = "aoiid_at")
    private String aoiid_at;
    @Column(name = "level_at")
    private String level_at;
    @Column(name = "splitresult_at")
    private String splitresult_at;
    @Column(name = "splitinfo_at")
    private String splitinfo_at;
    @Column(name = "keyword_at")
    private String keyword_at;
    @Column(name = "type_aoi")
    private String type_aoi;
    @Column(name = "zc_aoi")
    private String zc_aoi;
    @Column(name = "zc_aoi_num")
    private String zc_aoi_num;
    @Column(name = "is_right")
    private String is_right;

    @Column(name = "period")
    private String period;
    @Column(name = "inc_day")
    private String inc_day;

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getIs_right() {
        return is_right;
    }

    public void setIs_right(String is_right) {
        this.is_right = is_right;
    }

    public String getAdcode_normal() {
        return adcode_normal;
    }

    public void setAdcode_normal(String adcode_normal) {
        this.adcode_normal = adcode_normal;
    }

    public String getAoiid_at() {
        return aoiid_at;
    }

    public void setAoiid_at(String aoiid_at) {
        this.aoiid_at = aoiid_at;
    }

    public String getLevel_at() {
        return level_at;
    }

    public void setLevel_at(String level_at) {
        this.level_at = level_at;
    }

    public String getSplitresult_at() {
        return splitresult_at;
    }

    public void setSplitresult_at(String splitresult_at) {
        this.splitresult_at = splitresult_at;
    }

    public String getSplitinfo_at() {
        return splitinfo_at;
    }

    public void setSplitinfo_at(String splitinfo_at) {
        this.splitinfo_at = splitinfo_at;
    }

    public String getKeyword_at() {
        return keyword_at;
    }

    public void setKeyword_at(String keyword_at) {
        this.keyword_at = keyword_at;
    }

    public String getType_aoi() {
        return type_aoi;
    }

    public void setType_aoi(String type_aoi) {
        this.type_aoi = type_aoi;
    }

    public String getZc_aoi() {
        return zc_aoi;
    }

    public void setZc_aoi(String zc_aoi) {
        this.zc_aoi = zc_aoi;
    }

    public String getZc_aoi_num() {
        return zc_aoi_num;
    }

    public void setZc_aoi_num(String zc_aoi_num) {
        this.zc_aoi_num = zc_aoi_num;
    }

    public String getStatus_deal() {
        return status_deal;
    }

    public void setStatus_deal(String status_deal) {
        this.status_deal = status_deal;
    }

    public String getDeal_type() {
        return deal_type;
    }

    public void setDeal_type(String deal_type) {
        this.deal_type = deal_type;
    }

    public String getKey_diff_zc_num() {
        return key_diff_zc_num;
    }

    public void setKey_diff_zc_num(String key_diff_zc_num) {
        this.key_diff_zc_num = key_diff_zc_num;
    }

    public String getIs_modify() {
        return is_modify;
    }

    public void setIs_modify(String is_modify) {
        this.is_modify = is_modify;
    }

    public String getSign_zc_invalid() {
        return sign_zc_invalid;
    }

    public void setSign_zc_invalid(String sign_zc_invalid) {
        this.sign_zc_invalid = sign_zc_invalid;
    }

    public String getReqTime() {
        return reqTime;
    }

    public void setReqTime(String reqTime) {
        this.reqTime = reqTime;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDepponZc() {
        return depponZc;
    }

    public void setDepponZc(String depponZc) {
        this.depponZc = depponZc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getDataSrc() {
        return dataSrc;
    }

    public void setDataSrc(String dataSrc) {
        this.dataSrc = dataSrc;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getHis_num() {
        return his_num;
    }

    public void setHis_num(String his_num) {
        this.his_num = his_num;
    }

    public String getHis_zc_diff_num() {
        return his_zc_diff_num;
    }

    public void setHis_zc_diff_num(String his_zc_diff_num) {
        this.his_zc_diff_num = his_zc_diff_num;
    }

    public String getZc_new() {
        return zc_new;
    }

    public void setZc_new(String zc_new) {
        this.zc_new = zc_new;
    }

    public String getSource_new() {
        return source_new;
    }

    public void setSource_new(String source_new) {
        this.source_new = source_new;
    }

    public String getTc_new() {
        return tc_new;
    }

    public void setTc_new(String tc_new) {
        this.tc_new = tc_new;
    }

    public String getKeyword_new() {
        return keyword_new;
    }

    public void setKeyword_new(String keyword_new) {
        this.keyword_new = keyword_new;
    }

    public String getMatch_new() {
        return match_new;
    }

    public void setMatch_new(String match_new) {
        this.match_new = match_new;
    }

    public String getAdcode_new() {
        return adcode_new;
    }

    public void setAdcode_new(String adcode_new) {
        this.adcode_new = adcode_new;
    }

    public String getMsg_new() {
        return msg_new;
    }

    public void setMsg_new(String msg_new) {
        this.msg_new = msg_new;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
