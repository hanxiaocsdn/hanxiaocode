package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.SrcData4RuralXyAoi;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 乡村驿站坐标转化为AOI服务类
 * @author 01370539 Created On: May.07 2021
 */
public class RuralXyAoiService {
    private final Logger logger = LoggerFactory.getLogger(RuralXyAoiService.class);

    /**
     * 加载数据
     * @param ss SparkSession
     * @param jsc JavaSparkContext
     * @param statDate 统计日期
     * @return 查询的数据
     */
    public JavaRDD<SrcData4RuralXyAoi> loadData(SparkSession ss, JavaSparkContext jsc, String statDate) {
        String sql = SqlUtil.getSqlStr("src_data_4_ruralxyaoi.sql", statDate);
        return DataUtil.loadData(ss, jsc, sql, SrcData4RuralXyAoi.class);
    }
}
