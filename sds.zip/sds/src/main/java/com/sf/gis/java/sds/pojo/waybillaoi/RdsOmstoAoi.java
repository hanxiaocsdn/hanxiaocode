package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class RdsOmstoAoi implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "addresseeaoicode")
    private String addresseeaoicode;
    @Column(name = "addresseedeptcode")
    private String addresseedeptcode;
    @Column(name = "orderno")
    private String orderno;

    private String addresseeaoiid;

    @Column(name = "receiverprovince")
    private String receiverprovince;
    @Column(name = "receivercity")
    private String receivercity;
    @Column(name = "addresseecitycode")
    private String addresseecitycode;
    @Column(name = "addresseeaddr")
    private String addresseeaddr;
    @Column(name = "receiverarea")
    private String receiverarea;

    @Column(name = "addresseecompname")
    private String addresseecompname;
    @Column(name = "addresseemobile")
    private String addresseemobile;
    @Column(name = "addresseephone")
    private String addresseephone;

    public String getAddresseecompname() {
        return addresseecompname;
    }

    public void setAddresseecompname(String addresseecompname) {
        this.addresseecompname = addresseecompname;
    }

    public String getAddresseemobile() {
        return addresseemobile;
    }

    public void setAddresseemobile(String addresseemobile) {
        this.addresseemobile = addresseemobile;
    }

    public String getAddresseephone() {
        return addresseephone;
    }

    public void setAddresseephone(String addresseephone) {
        this.addresseephone = addresseephone;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getReceiverprovince() {
        return receiverprovince;
    }

    public void setReceiverprovince(String receiverprovince) {
        this.receiverprovince = receiverprovince;
    }

    public String getReceivercity() {
        return receivercity;
    }

    public void setReceivercity(String receivercity) {
        this.receivercity = receivercity;
    }

    public String getAddresseecitycode() {
        return addresseecitycode;
    }

    public void setAddresseecitycode(String addresseecitycode) {
        this.addresseecitycode = addresseecitycode;
    }

    public String getAddresseeaddr() {
        return addresseeaddr;
    }

    public void setAddresseeaddr(String addresseeaddr) {
        this.addresseeaddr = addresseeaddr;
    }

    public String getReceiverarea() {
        return receiverarea;
    }

    public void setReceiverarea(String receiverarea) {
        this.receiverarea = receiverarea;
    }

    public String getAddresseeaoiid() {
        return addresseeaoiid;
    }

    public void setAddresseeaoiid(String addresseeaoiid) {
        this.addresseeaoiid = addresseeaoiid;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getAddresseeaoicode() {
        return addresseeaoicode;
    }

    public void setAddresseeaoicode(String addresseeaoicode) {
        this.addresseeaoicode = addresseeaoicode;
    }

    public String getAddresseedeptcode() {
        return addresseedeptcode;
    }

    public void setAddresseedeptcode(String addresseedeptcode) {
        this.addresseedeptcode = addresseedeptcode;
    }
}
