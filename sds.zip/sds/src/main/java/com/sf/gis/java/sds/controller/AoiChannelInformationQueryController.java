package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.aoichannel.*;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.service.AoiChannelInformationQueryService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.sf.gis.java.base.util.ConfigurationUtil.loadMap;

public class AoiChannelInformationQueryController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiChannelInformationQueryController.class);
    AoiChannelInformationQueryService service = new AoiChannelInformationQueryService();

    //    private static final String aoiUrl = "http://10.119.72.206:9000/data/aoiSdk/getCoorAoi";
//    private static final String aoiNewUrl = "http://10.119.72.206:9000/data/aoiSdk/getCircleAoiBase?x=%s&y=%s&radius=%s";
    private static final String aoiUrl = "http://sds-core-datarun.sf-express.com/datarun/track/getCoorAoi";
    private static final String aoiNewUrl = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=%s";

    public void start(String incDay) {
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取aoi及aoi区域");
        JavaRDD<AoiAreaAoi> aoiAreaAoidRdd = service.loadAoiAreaAoi(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaAoidRdd cnt:{}", aoiAreaAoidRdd.count());

        logger.error("获取丰巢数据");
        JavaRDD<FengChao> fengChaoRdd = service.loadFengChao(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fengChaoRdd cnt:{}", fengChaoRdd.count());

        logger.error("丰巢数据跑出aoi");
        JavaRDD<FengChao> aoiFengChaoRdd = fengChaoRdd.map(o -> {
            String x = o.getLongitude();
            String y = o.getLatitude();
            JSONArray jsonArr = new JSONArray();
            JSONObject json = new JSONObject();
            json.put("lng", x);
            json.put("lat", y);
            jsonArr.add(json);

            try {
                String content = HttpInvokeUtil.sendPost(aoiUrl, jsonArr.toString());
                o.setReq(jsonArr.toString());
                o.setResJson(content);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONArray data = jsonObject.getJSONArray("data");
                            if (data != null && data.size() > 0) {
                                JSONObject jsonObject1 = data.getJSONObject(0);
                                if (jsonObject1 != null) {
                                    if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") == 0) {
                                        o.setAoi_id(jsonObject1.getString("aoiId"));
                                        o.setAoi_code(jsonObject1.getString("aoiCode"));
                                        o.setAoi_name(jsonObject1.getString("aoiName"));

                                    } else if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") > 0) {
                                        String req = String.format(aoiNewUrl, x, y, 50);
                                        String result = HttpInvokeUtil.sendGet(req);
                                        o.setReq(req.replace(aoiUrl, ""));
                                        o.setResJson(result);
                                        JSONObject jsonObject2 = JSON.parseObject(result);
                                        String aoi_id = "";
                                        String aoi_code = "";
                                        String aoi_name = "";
                                        if (jsonObject2 != null) {
                                            Boolean success1 = jsonObject2.getBoolean("success");
                                            if (success1) {
                                                JSONArray data1 = jsonObject2.getJSONArray("data");
                                                for (int i = 0; i < data1.size(); i++) {
                                                    JSONObject jsonObject3 = data1.getJSONObject(i);
                                                    if (jsonObject3 != null) {
                                                        String id = jsonObject3.getString("id");
                                                        String aoiCode = jsonObject3.getString("aoiCode");
                                                        String name = jsonObject3.getString("name");

                                                        aoi_id = aoi_id.concat(id).concat("|");
                                                        aoi_code = aoi_code.concat(aoiCode).concat("|");
                                                        aoi_name = aoi_name.concat(name).concat("|");
                                                    }
                                                }
                                                o.setAoi_id(aoi_id.replaceAll("(\\|)$", ""));
                                                o.setAoi_code(aoi_code.replaceAll("(\\|)$", ""));
                                                o.setAoi_name(aoi_name.replaceAll("(\\|)$", ""));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        String req = String.format(aoiNewUrl, x, y, 50);
                        String result = HttpInvokeUtil.sendGet(req);
                        o.setReq(req.replace(aoiUrl, ""));
                        o.setResJson(result);
                        JSONObject jsonObject2 = JSON.parseObject(result);
                        String aoi_id = "";
                        String aoi_code = "";
                        String aoi_name = "";
                        if (jsonObject2 != null) {
                            Boolean success1 = jsonObject2.getBoolean("success");
                            if (success1) {
                                JSONArray data1 = jsonObject2.getJSONArray("data");
                                for (int i = 0; i < data1.size(); i++) {
                                    JSONObject jsonObject3 = data1.getJSONObject(i);
                                    if (jsonObject3 != null) {
                                        String id = jsonObject3.getString("id");
                                        String aoiCode = jsonObject3.getString("aoiCode");
                                        String name = jsonObject3.getString("name");

                                        aoi_id = aoi_id.concat(id).concat("|");
                                        aoi_code = aoi_code.concat(aoiCode).concat("|");
                                        aoi_name = aoi_name.concat(name).concat("|");
                                    }
                                }
                                o.setAoi_id(aoi_id.replaceAll("(\\|)$", ""));
                                o.setAoi_code(aoi_code.replaceAll("(\\|)$", ""));
                                o.setAoi_name(aoi_name.replaceAll("(\\|)$", ""));
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiFengChaoRdd cnt:{}", aoiFengChaoRdd.count());
        fengChaoRdd.unpersist();

        String dim_hive_cabinet_info_df_aoi_info_sql = String.format("alter table dm_gis.dim_hive_cabinet_info_df_aoi_info drop if EXISTS partition( inc_day='%s' )", incDay);
        logger.error("dim_hive_cabinet_info_df_aoi_info_sql :{}", dim_hive_cabinet_info_df_aoi_info_sql);
        spark.sql(dim_hive_cabinet_info_df_aoi_info_sql);
        logger.error("丰巢数据入库");
        service.saveFengChaoData(spark, aoiFengChaoRdd, incDay);
        aoiFengChaoRdd.unpersist();


        logger.error("获取便利店数据");
        JavaRDD<ConvenienceStore> convenienceStoreRdd = service.loadConvenienceStore(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("convenienceStoreRdd cnt:{}", convenienceStoreRdd.count());

        logger.error("便利店数据跑出aoi");
        Map<String, String> map = loadMap("city_dist_limit.csv", "citycode", "dist_limit");
        Broadcast<Map<String, String>> mapBc = sc.broadcast(map);

        JavaRDD<ConvenienceStore> aoiConvenienceStoreRdd = convenienceStoreRdd.map(o -> {
            String x = o.getLongitude();
            String y = o.getLatitude();
            String cityid = o.getCityid();
            String dist = "300";
            if (StringUtils.isNotEmpty(cityid)) {
                String dist_limit = mapBc.value().get(cityid);
                dist = StringUtils.isNotEmpty(dist_limit) ? dist_limit : "300";
            }
            try {
                if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                    JSONArray jsonArr = new JSONArray();
                    JSONObject json = new JSONObject();
                    json.put("lng", x);
                    json.put("lat", y);
                    jsonArr.add(json);

                    String content = HttpInvokeUtil.sendPost(aoiUrl, jsonArr.toString());
                    o.setReq(jsonArr.toString());
                    o.setResJson(content);
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONArray data = jsonObject.getJSONArray("data");
                            if (data != null && data.size() > 0) {
                                JSONObject jsonObject1 = data.getJSONObject(0);
                                if (jsonObject1 != null) {
                                    if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") <= Double.parseDouble(dist)) {
                                        String aoiId = jsonObject1.getString("aoiId");
                                        String aoiCode = jsonObject1.getString("aoiCode");
                                        logger.error("std_aoi:{}", aoiId);
                                        logger.error("std_aoi_code:{}", aoiCode);
                                        o.setStdAoi(aoiId);
                                        o.setStdAoiCode(aoiCode);
                                    }
                                }
                            }
                        }
                        if (StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode())) {
                            String req = String.format(aoiNewUrl, x, y, Integer.valueOf(dist));
                            String result = HttpInvokeUtil.sendGet(req);
                            logger.error("req:{}", req);
                            logger.error("result:{}", result);
                            o.setReq(req.replace(aoiUrl, ""));
                            o.setResJson(result);
                            JSONObject jsonObject2 = JSON.parseObject(result);
                            if (jsonObject2 != null) {
                                Boolean success1 = jsonObject2.getBoolean("success");
                                if (success1) {
                                    JSONArray data1 = jsonObject2.getJSONArray("data");
                                    for (int i = 0; i < data1.size(); i++) {
                                        JSONObject jsonObject3 = data1.getJSONObject(i);
                                        if (jsonObject3 != null) {
                                            String id = jsonObject3.getString("id");
                                            String aoiCode = jsonObject3.getString("aoiCode");
                                            String name = jsonObject3.getString("name");
//                                            ConvenienceStore cs = new ConvenienceStore();
//                                            BeanUtils.copyProperties(cs, o);

                                            o.setAoi_id(id);
                                            o.setAoi_code(aoiCode);
                                            o.setAoi_name(name);

//                                            cs.setAoi_id(id);
//                                            cs.setAoi_code(aoiCode);
//                                            cs.setAoi_name(name);
//                                            list.add(cs);
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        String req = String.format(aoiNewUrl, x, y, Integer.valueOf(dist));
                        String result = HttpInvokeUtil.sendGet(req);
                        logger.error("req:{}", req);
                        logger.error("result:{}", result);
                        o.setReq(req.replace(aoiUrl, ""));
                        o.setResJson(result);
                        JSONObject jsonObject2 = JSON.parseObject(result);
                        if (jsonObject2 != null) {
                            Boolean success1 = jsonObject2.getBoolean("success");
                            if (success1) {
                                JSONArray data1 = jsonObject2.getJSONArray("data");
                                for (int i = 0; i < data1.size(); i++) {
                                    JSONObject jsonObject3 = data1.getJSONObject(i);
                                    if (jsonObject3 != null) {
                                        String id = jsonObject3.getString("id");
                                        String aoiCode = jsonObject3.getString("aoiCode");
                                        String name = jsonObject3.getString("name");
//                                        ConvenienceStore cs = new ConvenienceStore();
//                                        BeanUtils.copyProperties(cs, o);
                                        o.setAoi_id(id);
                                        o.setAoi_code(aoiCode);
                                        o.setAoi_name(name);

//                                        cs.setAoi_id(id);
//                                        cs.setAoi_code(aoiCode);
//                                        cs.setAoi_name(name);
//                                        list.add(cs);
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiConvenienceStoreRdd cnt:{}", aoiConvenienceStoreRdd.count());
        convenienceStoreRdd.unpersist();

        JavaRDD<ConvenienceStore> aoiAreaCodeConvenienceStoreRdd = aoiConvenienceStoreRdd.filter(o -> StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode()))
                .mapToPair(o -> new Tuple2<>(o.getStdAoiCode(), o))
                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
                    ConvenienceStore convenienceStore = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
                        convenienceStore.setAoi_area_code(aoi_area_code);
                    }
                    return convenienceStore;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaCodeConvenienceStoreRdd cnt:{}", aoiAreaCodeConvenienceStoreRdd.count());
        aoiConvenienceStoreRdd.unpersist();

        JavaRDD<ConvenienceStore> origionAoiAreaCodeConvenienceStoreRdd = aoiAreaCodeConvenienceStoreRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
                    ConvenienceStore convenienceStore = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
                        convenienceStore.setOrigion_aoi_area_code(aoi_area_code);
                    }
                    return convenienceStore;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("origionAoiAreaCodeConvenienceStoreRdd cnt:{}", origionAoiAreaCodeConvenienceStoreRdd.count());
        aoiAreaCodeConvenienceStoreRdd.unpersist();

        JavaRDD<ConvenienceStore> convenienceStoreFinalRdd = origionAoiAreaCodeConvenienceStoreRdd.filter(o -> StringUtils.isNotEmpty(o.getOrigion_aoi_area_code()) && StringUtils.equals(o.getOrigion_aoi_area_code(), o.getAoi_area_code()))
                .mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getService_addr(), o.getProvince(), o.getCityid(), o.getLongitude(), o.getLatitude()}, "_"), o))
                .groupByKey()
                .map(tp -> {
                    List<ConvenienceStore> list = Lists.newArrayList(tp._2);
                    ConvenienceStore convenienceStore = list.get(0);
                    String aoi_id = "";
                    String aoi_code = "";
                    String aoi_name = "";
                    for (ConvenienceStore store : list) {
                        aoi_id = aoi_id.concat(store.getAoi_id()).concat("|");
                        aoi_code = aoi_code.concat(store.getAoi_code()).concat("|");
                        aoi_name = aoi_name.concat(store.getAoi_name()).concat("|");
                    }
                    convenienceStore.setAoi_id(aoi_id.replaceAll("(\\|)$", ""));
                    convenienceStore.setAoi_code(aoi_code.replaceAll("(\\|)$", ""));
                    convenienceStore.setAoi_name(aoi_name.replaceAll("(\\|)$", ""));

                    return convenienceStore;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("convenienceStoreFinalRdd cnt:{}", convenienceStoreFinalRdd.count());
        origionAoiAreaCodeConvenienceStoreRdd.unpersist();

        String cx_service_network_aoi_info_sql = String.format("alter table dm_gis.cx_service_network_aoi_info drop if EXISTS partition( inc_day='%s' )", incDay);
        logger.error("cx_service_network_aoi_info_sql :{}", cx_service_network_aoi_info_sql);
        spark.sql(cx_service_network_aoi_info_sql);
        logger.error("便利店数据入库");
        service.saveConvenienceStoreData(spark, convenienceStoreFinalRdd, incDay);
        convenienceStoreFinalRdd.unpersist();

        logger.error("获取菜鸟驿站数据");
        JavaRDD<Cnyz> cnyzRdd = service.loadCnyz(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cnyzRdd cnt:{}", cnyzRdd.count());

        logger.error("菜鸟驿站数据跑出aoi");
        JavaRDD<Cnyz> aoiCnyzRdd = cnyzRdd.flatMap(o -> {
            String x = o.getLongitude();
            String y = o.getLatitude();
            List<Cnyz> list = new ArrayList<>();

            JSONArray jsonArr = new JSONArray();
            JSONObject json = new JSONObject();
            json.put("lng", x);
            json.put("lat", y);
            jsonArr.add(json);
            try {
                String content = HttpInvokeUtil.sendPost(aoiUrl, jsonArr.toString());
                o.setReq(jsonArr.toString());
                o.setResJson(content);
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null) {
                    Boolean success = jsonObject.getBoolean("success");
                    if (success) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        if (data != null && data.size() > 0) {
                            JSONObject jsonObject1 = data.getJSONObject(0);
                            if (jsonObject1 != null) {
                                if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") <= 300) {
                                    o.setStdAoi(jsonObject1.getString("aoiId"));
                                    o.setStdAoiCode(jsonObject1.getString("aoiCode"));
                                }
                            }
                        }
                    }
                    logger.error("std_aoi:{}", o.getStdAoi());
                    logger.error("std_aoi_code:{}", o.getStdAoiCode());
                    if (StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode())) {
                        String req = String.format(aoiNewUrl, x, y, 300);
                        String result = HttpInvokeUtil.sendGet(req);
                        logger.error("req:{}", req);
                        logger.error("result:{}", result);
                        o.setReq(req.replace(aoiUrl, ""));
                        o.setResJson(result);
                        JSONObject jsonObject2 = JSON.parseObject(result);
                        if (jsonObject2 != null) {
                            Boolean success1 = jsonObject2.getBoolean("success");
                            if (success1) {
                                JSONArray data1 = jsonObject2.getJSONArray("data");
                                for (int i = 0; i < data1.size(); i++) {
                                    JSONObject jsonObject3 = data1.getJSONObject(i);
                                    if (jsonObject3 != null) {
                                        String id = jsonObject3.getString("id");
                                        String aoiCode = jsonObject3.getString("aoiCode");
                                        String name = jsonObject3.getString("name");
                                        Cnyz cnyz = new Cnyz();
                                        BeanUtils.copyProperties(cnyz, o);

                                        cnyz.setAoi_id(id);
                                        cnyz.setAoi_code(aoiCode);
                                        cnyz.setAoi_name(name);
                                        list.add(cnyz);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    String req = String.format(aoiNewUrl, x, y, 300);
                    String result = HttpInvokeUtil.sendGet(req);
                    logger.error("req:{}", req);
                    logger.error("result:{}", result);
                    o.setReq(req.replace(aoiUrl, ""));
                    o.setResJson(result);
                    JSONObject jsonObject2 = JSON.parseObject(result);
                    if (jsonObject2 != null) {
                        Boolean success1 = jsonObject2.getBoolean("success");
                        if (success1) {
                            JSONArray data1 = jsonObject2.getJSONArray("data");
                            for (int i = 0; i < data1.size(); i++) {
                                JSONObject jsonObject3 = data1.getJSONObject(i);
                                if (jsonObject3 != null) {
                                    String id = jsonObject3.getString("id");
                                    String aoiCode = jsonObject3.getString("aoiCode");
                                    String name = jsonObject3.getString("name");
                                    Cnyz cnyz = new Cnyz();
                                    BeanUtils.copyProperties(cnyz, o);

                                    cnyz.setAoi_id(id);
                                    cnyz.setAoi_code(aoiCode);
                                    cnyz.setAoi_name(name);
                                    list.add(cnyz);
                                }
                            }
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiCnyzRdd cnt:{}", aoiCnyzRdd.count());
        cnyzRdd.unpersist();

        JavaRDD<Cnyz> aoiAreaCodeCnyzRdd = aoiCnyzRdd.filter(o -> StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode()))
                .mapToPair(o -> new Tuple2<>(o.getStdAoiCode(), o))
                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
                    Cnyz cnyz = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
                        cnyz.setAoi_area_code(aoi_area_code);
                    }
                    return cnyz;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaCodeCnyzRdd cnt:{}", aoiAreaCodeCnyzRdd.count());
        aoiCnyzRdd.unpersist();

        JavaRDD<Cnyz> origionAoiAreaCodeCnyzRdd = aoiAreaCodeCnyzRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
                    Cnyz cnyz = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
                        cnyz.setOrigion_aoi_area_code(aoi_area_code);
                    }
                    return cnyz;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("origionAoiAreaCodeCnyzRdd cnt:{}", origionAoiAreaCodeCnyzRdd.count());
        aoiAreaCodeCnyzRdd.unpersist();

        JavaRDD<Cnyz> cnyzFinalRdd = origionAoiAreaCodeCnyzRdd.filter(o -> StringUtils.isNotEmpty(o.getOrigion_aoi_area_code()) && StringUtils.equals(o.getOrigion_aoi_area_code(), o.getAoi_area_code()))
                .mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getProvince(), o.getCity(), o.getCounty(), o.getTown(), o.getPointname(), o.getNettype(), o.getLongitude(), o.getLatitude(), o.getAddress(), o.getZno_code(), o.getRegion(), o.getCompany()}, "_"), o))
                .groupByKey()
                .map(tp -> {
                    List<Cnyz> list = Lists.newArrayList(tp._2);
                    Cnyz cnyz = list.get(0);
                    String aoi_id = "";
                    String aoi_code = "";
                    String aoi_name = "";
                    for (Cnyz cn : list) {
                        aoi_id = aoi_id.concat(cn.getAoi_id()).concat("|");
                        aoi_code = aoi_code.concat(cn.getAoi_code()).concat("|");
                        aoi_name = aoi_name.concat(cn.getAoi_name()).concat("|");
                    }
                    cnyz.setAoi_id(aoi_id.replaceAll("(\\|)$", ""));
                    cnyz.setAoi_code(aoi_code.replaceAll("(\\|)$", ""));
                    cnyz.setAoi_name(aoi_name.replaceAll("(\\|)$", ""));

                    return cnyz;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cnyzFinalRdd cnt:{}", cnyzFinalRdd.count());
        origionAoiAreaCodeCnyzRdd.unpersist();

        logger.error("菜鸟驿站数据入库");
        spark.sql("truncate table dm_gis.cnyz");
        service.saveCnyzData(spark, cnyzFinalRdd);
        cnyzFinalRdd.unpersist();

        logger.error("获取城市驿站数据");
        JavaRDD<CityStation> cityStationRdd = service.loadCityStation(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityStationRdd cnt:{}", cityStationRdd.count());

        JavaRDD<CityStation> aoiCityStationRdd = cityStationRdd.map(o -> {
            String x = o.getStore_lng();
            String y = o.getStore_lat();
            JSONArray jsonArr = new JSONArray();
            JSONObject json = new JSONObject();
            json.put("lng", x);
            json.put("lat", y);
            jsonArr.add(json);

            try {
                String content = HttpInvokeUtil.sendPost(aoiUrl, jsonArr.toString());
                o.setReq(jsonArr.toString());
                o.setResJson(content);
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null) {
                    Boolean success = jsonObject.getBoolean("success");
                    if (success) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        if (data != null && data.size() > 0) {
                            JSONObject jsonObject1 = data.getJSONObject(0);
                            if (jsonObject1 != null) {
                                if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") <= 100) {
                                    o.setAoi_id(jsonObject1.getString("aoiId"));
                                    o.setAoi_code(jsonObject1.getString("aoiCode"));
                                    o.setAoi_name(jsonObject1.getString("aoiName"));
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiCityStationRdd cnt:{}", aoiCityStationRdd.count());
        cityStationRdd.unpersist();

        String cvs_pickup_deliver_aoi_sum_di_sql = String.format("alter table dm_gis.cvs_pickup_deliver_aoi_sum_di drop if EXISTS partition( inc_day='%s' )", incDay);
        logger.error("cvs_pickup_deliver_aoi_sum_di_sql :{}", cvs_pickup_deliver_aoi_sum_di_sql);
        spark.sql(cvs_pickup_deliver_aoi_sum_di_sql);
        logger.error("城市驿站数据入库");
        service.saveCityStationData(spark, aoiCityStationRdd, incDay);
        aoiCityStationRdd.unpersist();

//        logger.error("获取乡村驿站数据");
//        JavaRDD<VillageStation> villageStationRdd = service.loadVillageStation(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("villageStationRdd cnt:{}", villageStationRdd.count());
//        villageStationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//
//        JavaRDD<VillageStation> aoiVillageStationRdd = villageStationRdd.flatMap(o -> {
//            String x = o.getLongitude();
//            String y = o.getLatitude();
//            List<VillageStation> list = new ArrayList<>();
//
//            JSONArray jsonArr = new JSONArray();
//            JSONObject json = new JSONObject();
//            json.put("lng", x);
//            json.put("lat", y);
//            jsonArr.add(json);
//            String content = service.runAoi(aoiUrlBc.value(), jsonArr.toString());
//            o.setReq(jsonArr.toString());
//            o.setResJson(content);
//            JSONObject jsonObject = JSON.parseObject(content);
//            if(jsonObject != null){
//                Boolean success = jsonObject.getBoolean("success");
//                if (success) {
//                    JSONArray data = jsonObject.getJSONArray("data");
//                    if (data != null && data.size() > 0) {
//                        JSONObject jsonObject1 = data.getJSONObject(0);
//                        if (jsonObject1 != null) {
//                            if (jsonObject1.containsKey("dist") && jsonObject1.getDouble("dist") <= 300) {
//                                o.setStdAoi(jsonObject1.getString("aoiId"));
//                                o.setStdAoiCode(jsonObject1.getString("aoiCode"));
//                            }
//                        }
//                    }
//                }
//                if (StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode())) {
//                    String req = String.format(aoiNewUrlBc.value(), x, y, 300);
//                    String result = Utils.retryGet(req);
//                    o.setReq(req);
//                    o.setResJson(result);
//                    JSONObject jsonObject2 = JSON.parseObject(result);
//                    if (jsonObject2 != null) {
//                        Boolean success1 = jsonObject2.getBoolean("success");
//                        if (success1) {
//                            JSONArray data1 = jsonObject2.getJSONArray("data");
//                            for (int i = 0; i < data1.size(); i++) {
//                                JSONObject jsonObject3 = data1.getJSONObject(i);
//                                if (jsonObject3 != null) {
//                                    String id = jsonObject3.getString("id");
//                                    String aoiCode = jsonObject3.getString("aoiCode");
//                                    String name = jsonObject3.getString("name");
//                                    VillageStation vs = new VillageStation();
//                                    BeanUtils.copyProperties(vs, o);
//
//                                    vs.setAoi_id(id);
//                                    vs.setAoi_code(aoiCode);
//                                    vs.setAoi_name(name);
//                                    list.add(vs);
//                                }
//                            }
//                        }
//                    }
//                }
//
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("aoiVillageStationRdd cnt:{}", aoiVillageStationRdd.count());
//        aoiVillageStationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        villageStationRdd.unpersist();
//
//        JavaRDD<VillageStation> aoiAreaCodeVillageStationStoreRdd = aoiVillageStationRdd.filter(o -> StringUtils.isNotEmpty(o.getStdAoi()) && StringUtils.isNotEmpty(o.getStdAoiCode()))
//                .mapToPair(o -> new Tuple2<>(o.getStdAoiCode(), o))
//                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
//                    VillageStation villageStation = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
//                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
//                        villageStation.setAoi_area_code(aoi_area_code);
//                    }
//                    return villageStation;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("aoiAreaCodeVillageStationStoreRdd cnt:{}", aoiAreaCodeVillageStationStoreRdd.count());
//        aoiAreaCodeVillageStationStoreRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        aoiVillageStationRdd.unpersist();
//
//        JavaRDD<VillageStation> origionAoiAreaCodeVillageStationRdd = aoiAreaCodeVillageStationStoreRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
//                .leftOuterJoin(aoiAreaAoidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
//                    VillageStation villageStation = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
//                        String aoi_area_code = aoiAreaAoi.getAoi_area_code();
//                        villageStation.setOrigion_aoi_area_code(aoi_area_code);
//                    }
//                    return villageStation;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("origionAoiAreaCodeVillageStationRdd cnt:{}", origionAoiAreaCodeVillageStationRdd.count());
//        origionAoiAreaCodeVillageStationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        aoiAreaCodeVillageStationStoreRdd.unpersist();
//
//        JavaRDD<VillageStation> villageStationFinalRdd = origionAoiAreaCodeVillageStationRdd.filter(o -> StringUtils.isNotEmpty(o.getOrigion_aoi_area_code()) && StringUtils.equals(o.getOrigion_aoi_area_code(), o.getAoi_area_code()))
//                .mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getNetwork_id(), o.getNetwork_name(), o.getCity_code(), o.getAddress(), o.getLongitude(), o.getLatitude()}, "_"), o))
//                .groupByKey()
//                .map(tp -> {
//                    List<VillageStation> list = Lists.newArrayList(tp._2);
//                    VillageStation villageStation = list.get(0);
//                    String aoi_id = "";
//                    String aoi_code = "";
//                    String aoi_name = "";
//                    for (VillageStation station : list) {
//                        aoi_id = aoi_id.concat(station.getAoi_id()).concat("|");
//                        aoi_code = aoi_code.concat(station.getAoi_code()).concat("|");
//                        aoi_name = aoi_name.concat(station.getAoi_name()).concat("|");
//                    }
//                    villageStation.setAoi_id(aoi_id.replaceAll("(\\|)$", ""));
//                    villageStation.setAoi_code(aoi_code.replaceAll("(\\|)$", ""));
//                    villageStation.setAoi_name(aoi_name.replaceAll("(\\|)$", ""));
//
//                    return villageStation;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("villageStationFinalRdd cnt:{}", villageStationFinalRdd.count());
//        villageStationFinalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        origionAoiAreaCodeVillageStationRdd.unpersist();
//        aoiAreaAoidRdd.unpersist();
//
//        //乡村驿站数据入库
//        service.saveVillageStationData(spark, villageStationFinalRdd, incDay);
//        villageStationFinalRdd.unpersist();

        //整合渠道数据
        String executeSql1 = String.format("alter table dm_gis.aoi_channel_stat drop if EXISTS partition( inc_day='%s' )", incDay);
        logger.error("executeSql1 :{}", executeSql1);
        spark.sql(executeSql1);

        JavaRDD<AoiChannelStat> aoiChannelStatRdd = service.getAoiChannelStat(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiChannelStatRdd cnt:{}", aoiChannelStatRdd.count());

        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<AoiChannelStat> aoiCityCodeStatRdd = aoiChannelStatRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))).map(tp -> {
            AoiChannelStat aoiChannelStat = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                aoiChannelStat.setCitycode(cmsAoiSch.getCity_code());
            }
            return aoiChannelStat;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiCityCodeStatRdd cnt:{}", aoiCityCodeStatRdd.count());
        aoiChannelStatRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        // 针对结果表dm_gis.aoi_channel_stat，新增AOI黑名单（存储aoiid）；若出现在AOI黑名单中的，则不输出至dm_gis.aoi_channel_stat表中，无论是否有丰巢柜/便利店资源
        String filePath = "/user/01399581/upload/yunying_demand/data/".concat("aoi_black.csv");
        logger.error("filePath:{}", filePath);
        JavaRDD<String> lines = sc.textFile(filePath).persist(StorageLevel.MEMORY_AND_DISK_SER());
        String header = lines.first();
        logger.error("header:{}", header);
        JavaPairRDD<String, AoiChannelStat> aoiRdd = lines.filter(o -> !o.equals(header)).map(line -> {
            String aoi = line.split(",")[0];
            AoiChannelStat o = new AoiChannelStat();
            o.setAoiid(aoi);
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:{}", aoiRdd.count());
        lines.unpersist();

//        JavaPairRDD<String, AoiChannelStat> codeAoiRdd = aoiCityCodeStatRdd.mapToPair(o -> new Tuple2<>(o.getCode(), o))
//                .leftOuterJoin(codeRdd)
//                .filter(tp -> {
//                    boolean flag = false;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        flag = true;
//                    }
//                    return flag;
//                }).map(tp -> tp._2._1).mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("codeAoiRdd cnt:{}", codeAoiRdd.count());
//        codeAoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        codeRdd.unpersist();

//        service.saveAoiData(spark, codeAoiRdd.map(tp -> tp._2), incDay);

        JavaRDD<AoiChannelStat> afterFilterRdd = aoiCityCodeStatRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o)).groupByKey().leftOuterJoin(aoiRdd).filter(tp -> {
            ArrayList<AoiChannelStat> list = Lists.newArrayList(tp._2._1);
            int fc = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "fc")).collect(Collectors.toList()).size();
            boolean flag = true;
            if (tp._2._2 != null && tp._2._2.isPresent() && fc == 0) {
                flag = false;
            }
            return flag;
        }).flatMap(tp -> {
            ArrayList<AoiChannelStat> list = Lists.newArrayList(tp._2._1);
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("afterFilterRdd cnt:{}", afterFilterRdd.count());
        aoiCityCodeStatRdd.unpersist();
        aoiRdd.unpersist();

        JavaRDD<AoiChannelStat> aoiChannelStatFinalRdd = afterFilterRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getCitycode(), o.getAoiid()}, "_"), o)).groupByKey().map(tp -> {
            List<AoiChannelStat> list = Lists.newArrayList(tp._2);
            AoiChannelStat aoiChannelStat = list.get(0);

            int fcCnt = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "fc")).collect(Collectors.toList()).size();
            int bldCnt = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "bld")).collect(Collectors.toList()).size();
            int csyzCnt = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "csyz")).collect(Collectors.toList()).size();
            int cnyzCnt = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "cnyz")).collect(Collectors.toList()).size();

            List<String> fc_code_list = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "fc")).map(o -> o.getCode()).collect(Collectors.toList());
            List<String> bld_code_list = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "bld")).map(o -> o.getCode()).collect(Collectors.toList());
            String fc_code_list_str = ArrayUtil.joinArr(fc_code_list, "|");
            String bld_code_list_str = ArrayUtil.joinArr(bld_code_list, "|");


//            int xcyzCnt = list.stream().filter(o -> StringUtils.equals(o.getFlag(), "xcyz")).collect(Collectors.toList()).size();
//            int bld = bldCnt + xcyzCnt;

            String aoi_channel = "{\"xgj\"" + ":" + 0 + ",\"csyz\"" + ":" + csyzCnt + ",\"bld\"" + ":" + bldCnt + ",\"fc\"" + ":" + fcCnt + ",\"yz\"" + ":" + cnyzCnt + "}";
            aoiChannelStat.setAoi_channel(aoi_channel);
            aoiChannelStat.setFc_code_list(fc_code_list_str);
            aoiChannelStat.setBld_code_list(bld_code_list_str);

            return aoiChannelStat;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiChannelStatFinalRdd cnt:{}", aoiChannelStatFinalRdd.count());
        afterFilterRdd.unpersist();

        //汇总结果入库
        service.saveStatData(spark, aoiChannelStatFinalRdd, incDay);
        aoiChannelStatFinalRdd.unpersist();

        String executeSql3 = String.format("select count(1) from dm_gis.aoi_channel_stat where inc_day='%s'", incDay);
        logger.error("executeSql3:{}", executeSql3);
        spark.sql(executeSql3).show();

        spark.stop();
    }
}
