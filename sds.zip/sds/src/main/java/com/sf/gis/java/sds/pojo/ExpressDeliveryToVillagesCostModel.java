package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ExpressDeliveryToVillagesCostModel implements Serializable {
    @Column(name = "dest_hq_code")
    private String dest_hq_code;
    @Column(name = "dest_area_code")
    private String dest_area_code;
    @Column(name = "area_name")
    private String area_name;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "dept_name")
    private String dept_name;
    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "min_distance")
    private String min_distance;
    @Column(name = "inc_day")
    private String inc_day;

    public String getDest_hq_code() {
        return dest_hq_code;
    }

    public void setDest_hq_code(String dest_hq_code) {
        this.dest_hq_code = dest_hq_code;
    }

    public String getDest_area_code() {
        return dest_area_code;
    }

    public void setDest_area_code(String dest_area_code) {
        this.dest_area_code = dest_area_code;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getMin_distance() {
        return min_distance;
    }

    public void setMin_distance(String min_distance) {
        this.min_distance = min_distance;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
