package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AppXiaoGeMoneyController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id：392448（丰源小哥计提）
 * 业务方：李嘉欣
 * 研发：01399581（匡仁衡）
 */
public class AppXiaoGeMoney {
    private static Logger logger = LoggerFactory.getLogger(AppXiaoGeMoney.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String today = args[2];
        logger.error("startDate:{}", startDate);
        logger.error("endDate:{}", endDate);
        logger.error("today:{}", today);
        new AppXiaoGeMoneyController().start(startDate, endDate, today);
    }
}
