package com.sf.gis.java.sds.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONArray;
import com.sf.gis.scala.base.util.HttpUtils;

//import org.apache.hadoop.yarn.webapp.hamlet.Hamlet;


public class AoiBuildingGuid {
    public static String getAoiGuid(String adr, String dst) {
        String service_url = "http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode";
        JSONObject request_param = new JSONObject();
        request_param.put("address", adr);
        request_param.put("cityCode", dst);
        request_param.put("addressType", 1);
        request_param.put("sysCode", "NLOC");
        request_param.put("ak", "dcac0ddb279f45dc861f6061676d7948");
        request_param.put("type" , 1);

        for (int index = 0; index < 5; ++index) {
            try {
                JSONObject jsonObject = HttpUtils.urlConnectionPostJson(service_url, request_param.toString(),5000);
                if (jsonObject.containsKey("retCode")) {
                    String sStatus = jsonObject.getString("retCode");
                    if (sStatus.equals("1")) {
                        if (jsonObject.containsKey("aoiId")) {
                            String aoiId = jsonObject.getString("aoiId");
                            return aoiId;
                        }
                    }
                }
                return "";
            } catch (Exception e) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException tmp) {
                }

                if (index == 4){
                    return "";
                }
            }
        }
        return "";
    }

    public static String[] getBuildingGuid(String adr) {
        String[] levelWord = new String[29];
        levelWord[0] = "success";

        String service_url = "http://gis-int.int.sfdc.com.cn:1080/building/address/identify?showserver=true&ak=7a04c8f420ec4a67a257d7dfc70135a2&cityCode=755&address="+adr;
        for (int index = 0; index < 5; ++index) {
            for (int i = 1; i < 29; ++i) {
                levelWord[i] = "";
            }

            try {
                JSONObject jsonObject= HttpUtils.urlConnectionGetJson(service_url,5000);
                String sStatus = jsonObject.getString("status");
                JSONObject json_result = jsonObject.getJSONObject("result");
                if (sStatus.equals("0") == true) {
                    String bld_id = "";
                    if (json_result.containsKey("aoiId")) {
                        levelWord[1] = json_result.getString("aoiId");
                    }
                    if (json_result.containsKey("buildingId")) {
                        bld_id = json_result.getString("buildingId");
                        //levelWord[2] = bld_id;
                    }

                    if (json_result.containsKey("others")) {
                        JSONObject others = json_result.getJSONObject("others");
                        if (others.containsKey("splitResult")){
                            String splitStr = others.getString("splitResult");
                            levelWord[21] = splitStr;
                        }

                        int[] index_level = new int[18];
                        for (int i = 0; i < 18; ++i)
                            index_level[i] = -1;
                        if (others.containsKey("addrSplitInfo")) {
                            JSONArray splitInfo = others.getJSONArray("addrSplitInfo");
                            for (int i = 0; i < splitInfo.size(); ++i) {
                                JSONObject splitInfo_item = splitInfo.getJSONObject(i);
                                String level = splitInfo_item.getString("level");
                                int int_level = Integer.parseInt(level);
                                String name = splitInfo_item.getString("name");
                                if (int_level < 18 && int_level >= 0) {
                                    if (levelWord[int_level + 3].equals(""))
                                        levelWord[int_level + 3] = name;
                                    else
                                        levelWord[int_level + 3] = levelWord[int_level + 3] + "|" + name;

                                    if (int_level <= 13) {
                                        if (levelWord[26].equals(""))
                                            levelWord[26] = name;
                                        else
                                            levelWord[26] = levelWord[26] + name;
                                    }

                                    if (int_level <= 14) {
                                        if (levelWord[27].equals(""))
                                            levelWord[27] = name;
                                        else
                                            levelWord[27] = levelWord[27] + name;
                                    }

                                    index_level[i] = int_level;
                                }
                            }
                        }

                        if (others.containsKey("geocoder")) {
                            JSONArray geocoder = others.getJSONArray("geocoder");
                            for (int i = 0; i < geocoder.size(); ++i) {
                                JSONObject geocoder_item = geocoder.getJSONObject(i);
                                if (geocoder_item.containsKey("cell1") && geocoder_item.containsKey("confidence")) {
                                    int confidence = Integer.parseInt(geocoder_item.getString("confidence"));
                                    String geocoder_key = geocoder_item.getString("key");
                                    String id = "";
                                    if (geocoder_item.containsKey("id")) {
                                        id = geocoder_item.getString("id");
                                    }
                                    String standardization = "";
                                    if (geocoder_item.containsKey("standardization")) {
                                        standardization = geocoder_item.getString("standardization");
                                    }
                                    String province = "";
                                    if (geocoder_item.containsKey("province")) {
                                        province = geocoder_item.getString("province");
                                    }
                                    String city = "";
                                    if (geocoder_item.containsKey("city")) {
                                        city = geocoder_item.getString("city");
                                    }
                                    String district = "";
                                    if (geocoder_item.containsKey("district")) {
                                        district = geocoder_item.getString("district");
                                    }
                                    String[] geocoder_key_list = geocoder_key.split("|");
                                    if (confidence > 0) {
                                        String bldid = geocoder_item.getString("cell1");
                                        bldid = bldid.substring(0, bldid.indexOf("|"));
                                        for (int j = 0; j < geocoder_key_list.length; ++j) {
                                            int geocoder_key_index = Integer.parseInt(geocoder_key_list[j]);
                                            if (index_level[geocoder_key_index] == 14 || (!id.equals("") && id.equals(bld_id))) {
                                                levelWord[2] = bldid;
                                                break;
                                            }
                                        }
                                    }

                                    levelWord[22] = standardization;
                                    levelWord[23] = province;
                                    levelWord[24] = city;
                                    levelWord[25] = district;
                                }
                            }
                        }
                    }
                }
                return levelWord;
            } catch (Exception e) {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException tmp) {
                }

                if (index == 4){
                    levelWord[0] = "fail";
                    return levelWord;
                }
            }
        }
        return levelWord;
    }

    public static String[] getAnalysisOthers(String other, String bld_id) {
        String[] levelWord = new String[7];
        levelWord[0] = "success";
        for (int i = 1; i < 7; ++i) {
            levelWord[i] = "";
        }

        try {
            JSONObject others = JSON.parseObject(other);

            int[] index_level = new int[18];
            for (int i = 0; i < 18; ++i)
                index_level[i] = -1;
            if (others.containsKey("addrSplitInfo")) {
                JSONArray splitInfo = others.getJSONArray("addrSplitInfo");
                for (int i = 0; i < splitInfo.size(); ++i) {
                    JSONObject splitInfo_item = splitInfo.getJSONObject(i);
                    String level = splitInfo_item.getString("level");
                    int int_level = Integer.parseInt(level);
                    String name = splitInfo_item.getString("name");
                    if (int_level < 18 && int_level >= 0) {
                        index_level[i] = int_level;
                    }
                }
            }

            if (others.containsKey("geocoder")) {
                JSONArray geocoder = others.getJSONArray("geocoder");
                for (int i = 0; i < geocoder.size(); ++i) {
                    JSONObject geocoder_item = geocoder.getJSONObject(i);
                    if (geocoder_item.containsKey("cell1") && geocoder_item.containsKey("confidence")) {
                        int confidence = Integer.parseInt(geocoder_item.getString("confidence"));
                        String geocoder_key = geocoder_item.getString("key");
                        String id = "";
                        if (geocoder_item.containsKey("id")) {
                            id = geocoder_item.getString("id");
                        }
                        String standardization = "";
                        if (geocoder_item.containsKey("standardization")) {
                            standardization = geocoder_item.getString("standardization");
                        }
                        String province = "";
                        if (geocoder_item.containsKey("province")) {
                            province = geocoder_item.getString("province");
                        }
                        String city = "";
                        if (geocoder_item.containsKey("city")) {
                            city = geocoder_item.getString("city");
                        }
                        String district = "";
                        if (geocoder_item.containsKey("district")) {
                            district = geocoder_item.getString("district");
                        }

                        String[] geocoder_key_list = geocoder_key.split("|");
                        if (confidence > 0) {
                            String bldid = geocoder_item.getString("cell1");
                            bldid = bldid.substring(0, bldid.indexOf("|"));
                            for (int j = 0; j < geocoder_key_list.length; ++j) {
                                int geocoder_key_index = Integer.parseInt(geocoder_key_list[j]);
                                if (index_level[geocoder_key_index] == 14 || (!id.equals("") && id.equals(bld_id))) {
                                    levelWord[2] = bldid;
                                    break;
                                }
                            }
                        }
                        levelWord[3] = standardization;
                        levelWord[4] = province;
                        levelWord[5] = city;
                        levelWord[6] = district;
                    }
                }
            }
        } catch (Exception e) {
            levelWord[0] = "fail";
        }

        return levelWord;
    }

    public static String[] getAoiBuildingGuid(String adr, String dst) {
        String[] levelWord = new String[29];
        levelWord[0] = "fail";
        for (int i = 1; i < 29; ++i) {
            levelWord[i] = "";
        }
        if (adr.equals("")) {
            return levelWord;
        }
        adr = adr.replace("\n", "").replace(" ", "").replace("#", "").replace("&", "")
                .replace(",", "").replace("|", "");
        String aoiId = getAoiGuid(adr, dst);
        if (!aoiId.equals("")) {
            String[] info = getBuildingGuid(adr);
            if (info[1].equals(aoiId)) {
                try {
                    String splitInfo = info[21];
                    splitInfo = new String(splitInfo.getBytes(), "utf-8");

                    AddressLevel addrLevel = new AddressLevel();
                    if (AddressLevelJNA.GetAddrLevel(false, "", splitInfo, addrLevel)) {
                        if (!addrLevel.aoi.equals("")) {
                            info[16] = addrLevel.aoi;
                        }
                        if (!addrLevel.subAoi.equals("")) {
                            info[16] = addrLevel.subAoi;
                        }
                        if (!addrLevel.building.equals("")) {
                            info[17] = addrLevel.building;
                        }
                        if (!addrLevel.unit.equals("")) {
                            info[18] = addrLevel.unit;
                        }
                        if (!addrLevel.floor.equals("")) {
                            info[19] = addrLevel.floor;
                        }
                        if (!addrLevel.room.equals("")) {
                            info[20] = addrLevel.room;
                        }
                    } else {
                        info[28] = "标准化失败";
                    }
                } catch (Exception e) {
                    System.out.println(e);
                }

                return info;
            }
        }
        return levelWord;
    }

    public static String[] getAnalysisBldid(String others, String bld_id) {
        // 索引18 存储subaoi
        String[] levelWord = new String[28];
        for (int i = 0; i < 28; ++i) {
            levelWord[i] = "";
        }

        String[] other_info = getAnalysisOthers(others, bld_id);
        if (other_info[0].equals("success")) {
            levelWord[21] = other_info[1];
            levelWord[22] = other_info[2];
            levelWord[23] = other_info[3];
            levelWord[24] = other_info[4];
            levelWord[25] = other_info[5];
            levelWord[26] = other_info[6];
        }
        return levelWord;
    }

    public static String[] getNormalizeSplitInfo(String others, String bld_id, String adcode){
        // 索引18 存储subaoi
        String[] levelWord = new String[28];
        for (int i = 0; i < 28; ++i) {
            levelWord[i] = "";
        }

        String[] other_info = getAnalysisOthers(others, bld_id);
        if (other_info[0].equals("success")) {
            levelWord[21] = other_info[1];
            levelWord[22] = other_info[2];
            levelWord[23] = other_info[3];
            levelWord[24] = other_info[4];
            levelWord[25] = other_info[5];
            levelWord[26] = other_info[6];
        }

        JSONObject jsonObject = JSON.parseObject(others);
        String level_14_str = "";
        if (jsonObject != null && jsonObject.containsKey("status")) {
            int sStatus = jsonObject.getInteger("status");
            if (sStatus == 0) {
                String extend_bld_info = "";
                if (jsonObject.containsKey("addrSplitInfo")) {
                    JSONArray splitInfo = jsonObject.getJSONArray("addrSplitInfo");
                    for (int i = 0; i < splitInfo.size(); ++i) {
                        JSONObject splitInfo_item = splitInfo.getJSONObject(i);
                        String level = splitInfo_item.getString("level");
                        int int_level = Integer.parseInt(level);
                        String name = splitInfo_item.getString("name");
                        if (int_level < 18 && int_level >= 0) {
                            if (int_level <= 13) {
                                if (levelWord[27].equals(""))
                                    levelWord[27] = name;
                                else
                                    levelWord[27] = levelWord[27] + name;
                            }

                            if (int_level <= 14) {
                                if (level_14_str.equals(""))
                                    level_14_str = name;
                                else
                                    level_14_str = level_14_str + name;
                            }

                            if (levelWord[int_level].equals(""))
                                levelWord[int_level] = name;
                            else if (!levelWord[int_level].equals(name))
                                levelWord[int_level] = levelWord[int_level] + "|" + name;

                            if (int_level > 14) {
                                extend_bld_info = extend_bld_info + name;
                            }
                        }
                    }
                }

                if (!levelWord[23].equals("")) {
                    levelWord[23] = levelWord[23] + extend_bld_info;
                    try {
                        AddressLevel addrLevel = new AddressLevel();
                        if (AddressLevelJNA.GetAddrLevel(false, adcode, levelWord[23], addrLevel)) {
                            if (!addrLevel.split_result.equals("")) {
                                levelWord[19] = addrLevel.split_result;
                            }
                            if (!addrLevel.province.equals("")) {
                                levelWord[1] = addrLevel.province;
                            }
                            if (!addrLevel.city.equals("")) {
                                levelWord[2] = addrLevel.city;
                            }
                            if (!addrLevel.county.equals("")) {
                                levelWord[3] = addrLevel.county;
                            }
                            if (!addrLevel.town.equals("")) {
                                levelWord[5] = addrLevel.town;
                            }
                            if (!addrLevel.village.equals("")) {
                                levelWord[6] = addrLevel.village;
                            }
                            if (!addrLevel.road.equals("")) {
                                levelWord[9] = addrLevel.road;
                            }
                            if (!addrLevel.branch_road.equals("")) {
                                levelWord[10] = addrLevel.branch_road;
                            }
                            if (!addrLevel.house_no.equals("")) {
                                levelWord[11] = addrLevel.house_no;
                            }
                            if (!addrLevel.branch_house_no.equals("")) {
                                levelWord[12] = addrLevel.branch_house_no;
                            }
                            if (!addrLevel.aoi.equals("")) {
                                levelWord[13] = addrLevel.aoi;
                            }
                            if (!addrLevel.subAoi.equals("")) {
                                levelWord[18] = addrLevel.subAoi;
                            }
                            if (!addrLevel.building.equals("")) {
                                levelWord[14] = addrLevel.building;
                            }
                            if (!addrLevel.unit.equals("")) {
                                levelWord[15] = addrLevel.unit;
                            }
                            if (!addrLevel.floor.equals("")) {
                                levelWord[16] = addrLevel.floor;
                            }
                            if (!addrLevel.room.equals("")) {
                                levelWord[17] = addrLevel.room;
                            }
                            if (!addrLevel.aoi_name.equals("")) {
                                levelWord[27] = addrLevel.aoi_name;
                            }
                        } else {
                            levelWord[20] = "标准化失败";
                        }
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            }
        }

        if (levelWord[23].equals("")) {
            levelWord[23] = level_14_str;
            levelWord[20] = "标准化楼栋地址获取失败， 标准化失败";
        }
        return levelWord;
    }


    public static String[] getNormalizeSplitInfoNew(String others, String bld_id, String adcode,String addr){
        // 索引18 存储subaoi
        String[] levelWord = new String[28];
        for (int i = 0; i < 28; ++i) {
            levelWord[i] = "";
        }

        if (addr!=null&&!addr.equals("")) {
            try {
                AddressLevel addrLevel = new AddressLevel();
                if (AddressLevelJNA.GetAddrLevel(false, adcode, addr, addrLevel)) {
                    if (!addrLevel.split_result.equals("")) {
                        levelWord[19] = addrLevel.split_result;
                    }
                    if (!addrLevel.province.equals("")) {
                        levelWord[1] = addrLevel.province;
                    }
                    if (!addrLevel.city.equals("")) {
                        levelWord[2] = addrLevel.city;
                    }
                    if (!addrLevel.county.equals("")) {
                        levelWord[3] = addrLevel.county;
                    }
                    if (!addrLevel.town.equals("")) {
                        levelWord[5] = addrLevel.town;
                    }
                    if (!addrLevel.village.equals("")) {
                        levelWord[6] = addrLevel.village;
                    }
                    if (!addrLevel.road.equals("")) {
                        levelWord[9] = addrLevel.road;
                    }
                    if (!addrLevel.branch_road.equals("")) {
                        levelWord[10] = addrLevel.branch_road;
                    }
                    if (!addrLevel.house_no.equals("")) {
                        levelWord[11] = addrLevel.house_no;
                    }
                    if (!addrLevel.branch_house_no.equals("")) {
                        levelWord[12] = addrLevel.branch_house_no;
                    }
                    if (!addrLevel.aoi.equals("")) {
                        levelWord[13] = addrLevel.aoi;
                    }
                    if (!addrLevel.subAoi.equals("")) {
                        levelWord[18] = addrLevel.subAoi;
                    }
                    if (!addrLevel.building.equals("")) {
                        levelWord[14] = addrLevel.building;
                    }
                    if (!addrLevel.unit.equals("")) {
                        levelWord[15] = addrLevel.unit;
                    }
                    if (!addrLevel.floor.equals("")) {
                        levelWord[16] = addrLevel.floor;
                    }
                    if (!addrLevel.room.equals("")) {
                        levelWord[17] = addrLevel.room;
                    }
                    if (!addrLevel.aoi_name.equals("")) {
                        levelWord[27] = addrLevel.aoi_name;
                    }
                } else {
                    levelWord[20] = "标准化失败";
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }

        if (levelWord[23].equals("")) {
//            levelWord[23] = level_14_str;
            levelWord[20] = "标准化楼栋地址获取失败， 标准化失败";
        }
        return levelWord;
    }
    public static void main(String args[])
    {
        if (!AddressLevelJNA.Init("./", "", "./config", "120000"))
        {
            System.out.println("call AddressLevelJNA.Init failure!");
            return;
        }

        String others = "{\"status\":0,\"count\":3,\"geocoder\":[{\"province\":\"天津市\",\"district\":\"河西区\",\"floor\":\"13\",\"adcode\":120103,\"filter\":1,\"group\":\"880509385C3911EABB6B3C15FB00027B\",\"name\":\"天津市河西区友谊大厦a座@13层1305室\",\"x\":117.211401,\"y\":39.0786036,\"standardization\":\"天津市河西区友谊路街道友谊路50号友谊大厦a座\",\"score\":1,\"level\":\"GL_POI\",\"mainid\":\"349598\",\"poi_typecode\":\"2\",\"id\":\"3D164E6C36F611EBB5880540C744320C\",\"sflag\":0,\"key\":\"3|4\",\"address\":\"友谊大厦a座\",\"confidence\":99,\"citycode\":\"022\",\"room\":\"1305\",\"mode\":1,\"x_road\":0.0,\"y_road\":0.0,\"distance\":66,\"dataSrc\":1,\"srcuuid\":\"525141\",\"area\":0,\"cell1\":\"92ED4B9ADF994F5FA2F5F2F53EA750E2|友谊大厦a座\",\"cell2\":\"$cf_split\"},{\"province\":\"天津市\",\"district\":\"河西区\",\"floor\":\"13\",\"adcode\":120103,\"filter\":1,\"group\":\"8815B3D25C3911EABB6B3C15FB00027B\",\"name\":\"天津市河西区大安大厦a座@13层1305室\",\"x\":117.210991,\"y\":39.080675,\"standardization\":\"天津市河西区友谊路街道友谊路41号大安大厦a座\",\"score\":1,\"level\":\"GL_POI\",\"mainid\":\"364413\",\"poi_typecode\":\"2\",\"id\":\"A0382FC6FA6311EA8864C97AA067ACDC\",\"sflag\":0,\"key\":\"3|4\",\"address\":\"大安大厦a座\",\"confidence\":99,\"citycode\":\"022\",\"room\":\"1305\",\"mode\":2,\"x_road\":0.0,\"y_road\":0.0,\"distance\":226,\"dataSrc\":1,\"srcuuid\":\"619129\",\"area\":0,\"cell2\":\"$cf_split\"},{\"province\":\"天津市\",\"district\":\"河西区\",\"floor\":\"13\",\"adcode\":120103,\"filter\":2,\"group\":\"DA60FD06BAA74B9E8A203E6576C5B4D5\",\"name\":\"天津市河西区友谊路41号a座@13层1305室\",\"x\":117.211266,\"y\":39.0804558,\"standardization\":\"天津市河西区友谊路街道友谊路41号a座\",\"score\":1,\"level\":\"GL_POI\",\"mainid\":\"327665\",\"poi_typecode\":\"2\",\"id\":\"029F3CAE71EC11EBADAB9F4BE5B68E20\",\"sflag\":0,\"key\":\"3|4\",\"address\":\"友谊路41号a座\",\"confidence\":92,\"citycode\":\"022\",\"room\":\"1305\",\"mode\":2,\"x_road\":0.0,\"y_road\":0.0,\"distance\":198,\"dataSrc\":1,\"srcuuid\":\"388742\",\"area\":0}],\"source\":\"tianjin\",\"splitResult\":\"天津市^11,河西区^13,友谊路^19,友谊大厦^113,a座^214,1305室^217;17\",\"splitType\":0,\"addrSplitInfo\":[{\"match\":\"1\",\"prop\":\"1\",\"level\":1,\"name\":\"天津市\"},{\"match\":\"1\",\"prop\":\"1\",\"level\":3,\"name\":\"河西区\"},{\"match\":\"1\",\"prop\":\"1\",\"level\":9,\"name\":\"友谊路\"},{\"match\":\"1\",\"prop\":\"1\",\"level\":13,\"name\":\"友谊大厦\"},{\"match\":\"1\",\"prop\":\"2\",\"level\":14,\"name\":\"a座\"},{\"match\":\"0\",\"prop\":\"2\",\"level\":17,\"name\":\"1305室\"}],\"guid\":\"284D4F6C-C01D-4727-8031-417C4E144493\"}";
        String bld_id = "3D164E6C36F611EBB5880540C744320C";
        String adcode = "120000";
        String[] assemble_info = getNormalizeSplitInfo(others, bld_id, adcode);
        String province = "";
        String city = "";
        String county = "";
        String town = "";
        String village = "";
        String road = "";
        String branch_road = "";
        String house_no = "";
        String branch_house_no = "";
        String aoi = "";
        String sub_aoi = "";
        String building = "";
        String unit = "";
        String floor = "";
        String room = "";
        String reserve1 = "";
        String reserve2 = assemble_info[23] + "&&" + assemble_info[27];
        String splitInfo = "";

        if (assemble_info[1].isEmpty()) {
            province = assemble_info[24];
        }
        else {
            province = assemble_info[1];
        }
        if (assemble_info[2].isEmpty()) {
            city = assemble_info[25];
        }
        else {
            city = assemble_info[2];
        }
        if (assemble_info[4].isEmpty()) {
            county = assemble_info[26];
        }
        else {
            county = assemble_info[4];
        }
        town = assemble_info[5];
        village = assemble_info[6];
        road = assemble_info[9];
        branch_road = assemble_info[10];
        house_no = assemble_info[11];
        branch_house_no = assemble_info[12];
        aoi = assemble_info[13];
        sub_aoi = assemble_info[18];
        building = assemble_info[14];
        unit = assemble_info[15];
        floor = assemble_info[16];
        room = assemble_info[17];
        splitInfo = assemble_info[19].replace(",", "#");
        reserve1 = assemble_info[20];

        System.out.println("split_result:" + splitInfo);
        System.out.println("province:" + province);
        System.out.println("city:" + city);
        System.out.println("county:" + county);
        System.out.println("town:" + town);
        System.out.println("village:" + village);
        System.out.println("road:" + road);
        System.out.println("branch_road:" + branch_road);
        System.out.println("house_no:" + house_no);
        System.out.println("branch_house_no:" + branch_house_no);
        System.out.println("aoi:" + aoi);
        System.out.println("sub_aoi:" + sub_aoi);
        System.out.println("building:" + building);
        System.out.println("unit:" + unit);
        System.out.println("floor:" + floor);
        System.out.println("room:" + room);
        System.out.println("reserve1:" + reserve1);
        System.out.println("reserve2:" + reserve2);
    }
}
