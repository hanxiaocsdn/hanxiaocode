package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.ProductIncUbasNextAppStat;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id：813526(【客体】事中不上门数据统计)
 * 业务方：01412980（潘宜鹏）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月15日11:00:29
 */
public class AppIncidentNotDeliveryHome {
    private static String url = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side";
    private static Logger logger = LoggerFactory.getLogger(AppIncidentNotDeliveryHome.class);

    private static String account = "01399581";
    private static String taskId = "813526";
    private static String taskName = "事中不上门数据统计";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppIncidentNotDeliveryHome");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String before1Date = DateUtil.getDaysBefore(date, 1);
        String product_inc_ubas_next_app_sql = String.format("select\n" +
                "  a.waybillno waybill_no,\n" +
                "  b.city city,\n" +
                "  b.employee_id employee_id,\n" +
                "  b.aoi_id aoi_id,\n" +
                "  b.address address,\n" +
                "  a.scene match_type,\n" +
                "  b.current_tm current_tm,\n" +
                "  a.properties_type properties_type,\n" +
                "  a.properties_content properties_content,\n" +
                "  a.time properties_time,\n" +
                "  b.tracks tracks,\n" +
                "  a.inc_day inc_day\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      waybillno,\n" +
                "      properties_type,\n" +
                "      properties_content,\n" +
                "      time,\n" +
                "      sf_user_id,\n" +
                "      properties ['scene'] as scene,\n" +
                "      inc_day\n" +
                "    from\n" +
                "      dm_sfxg.product_inc_ubas_next_app\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and event_id = '1320'\n" +
                "      and properties_type = '1'\n" +
                "      and properties ['scene'] = '1'\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      waybill_no,\n" +
                "      city,\n" +
                "      employee_id,\n" +
                "      aoi_id,\n" +
                "      address,\n" +
                "      current_tm,\n" +
                "      tracks\n" +
                "    from\n" +
                "      (\n" +
                "        select\n" +
                "          waybill_no,\n" +
                "          city,\n" +
                "          employee_id,\n" +
                "          aoi_id,\n" +
                "          address,\n" +
                "          current_tm,\n" +
                "          tracks,\n" +
                "          row_number() over (\n" +
                "            partition by waybill_no\n" +
                "            order by\n" +
                "              current_tm desc\n" +
                "          ) rank\n" +
                "        from\n" +
                "          dm_gis.lbs_log_pnsaoi\n" +
                "        where\n" +
                "          inc_day between '%s'\n" +
                "          and '%s'\n" +
                "      ) t\n" +
                "    where\n" +
                "      t.rank = 1\n" +
                "  ) b on a.waybillno = b.waybill_no", date, before1Date, date);

        JavaRDD<ProductIncUbasNextAppStat> rdd = DataUtil.loadData(spark, sc, product_inc_ubas_next_app_sql, ProductIncUbasNextAppStat.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, url, "", rdd.count(), 20);
        JavaRDD<ProductIncUbasNextAppStat> resultRdd = rdd.map(o -> {
            String aoi_id = o.getAoi_id();
            String tracks = o.getTracks();
            int cnt_1 = 0, cnt_1_5 = 0, cnt_5_10 = 0, cnt_10_20 = 0, cnt_20_50 = 0, cnt_50_75 = 0, cnt_75_100 = 0, cnt_100 = 0;
            if (StringUtils.isNotEmpty(aoi_id) && StringUtils.isNotEmpty(tracks)) {
                JSONArray jsonArray = JSONObject.parseArray(tracks);
                for (int i = 0; i < jsonArray.size(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    if (jsonObject != null) {
                        Double ac = jsonObject.getDouble("ac");
                        if (ac <= 100) {
                            String x = jsonObject.getString("x");
                            String y = jsonObject.getString("y");
                            String req = String.format(url, x, y, aoi_id);
                            String result = HttpInvokeUtil.sendGet(req);
                            try {
                                double data = JSON.parseObject(result).getDouble("data");
                                if (data < 1) {
                                    ++cnt_1;
                                } else if (data >= 1 && data < 5) {
                                    ++cnt_1_5;
                                } else if (data >= 5 && data < 10) {
                                    ++cnt_5_10;
                                } else if (data >= 10 && data < 20) {
                                    ++cnt_10_20;
                                } else if (data >= 20 && data < 50) {
                                    ++cnt_20_50;
                                } else if (data >= 50 && data < 75) {
                                    ++cnt_50_75;
                                } else if (data >= 75 && data < 100) {
                                    ++cnt_75_100;
                                } else {
                                    ++cnt_100;
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            o.setCnt_1(cnt_1 + "");
            o.setCnt_1_5(cnt_1_5 + "");
            o.setCnt_5_10(cnt_5_10 + "");
            o.setCnt_10_20(cnt_10_20 + "");
            o.setCnt_20_50(cnt_20_50 + "");
            o.setCnt_50_75(cnt_50_75 + "");
            o.setCnt_75_100(cnt_75_100 + "");
            o.setCnt_100(cnt_100 + "");

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        spark.sql(String.format("alter table dm_gis.incident_not_delivery_home drop if EXISTS partition( inc_day='%s' )", date));
        DataUtil.saveOverwrite(spark, sc, "dm_gis.incident_not_delivery_home", ProductIncUbasNextAppStat.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();


    }
}
