package com.sf.gis.java.sds.enumtype;

public enum HookCalDimen {
    date,//日期
    region,//大区
    cityCode,//城市
    zc//网点
}
