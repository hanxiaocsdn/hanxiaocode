package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.ProductIncUbasNextApp;
import com.sf.gis.java.sds.pojo.StAreaCityRelation;
import com.sf.gis.java.sds.service.AoiAndPoiErrorStatService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class AoiAndPoiErrorStatController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiAndPoiErrorStatController.class);
    AoiAndPoiErrorStatService service = new AoiAndPoiErrorStatService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dates) {
            logger.error("date:{}", date);
            JavaRDD<ProductIncUbasNextApp> productIncUbasNextAppRdd = service.loadProductIncUbasNextApp(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("productIncUbasNextAppRdd cnt:{}", productIncUbasNextAppRdd.count());
            productIncUbasNextAppRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            //生成明细
            JavaRDD<ProductIncUbasNextApp> detailRdd = productIncUbasNextAppRdd.map(o -> {

                String cityCode = StringUtils.isNotEmpty(o.getZonecode()) ? service.getCityCode(o.getZonecode()) : "";
                String msg = o.getMsg();
                String type = o.getType();
                String error_type = "";
                if (StringUtils.isNotEmpty(msg)) {
                    error_type = "AOI区域内报错";
                } else if (StringUtils.isEmpty(msg) && StringUtils.equals(type, "2")) {
                    error_type = "AOI区域间报错";
                } else if (StringUtils.isEmpty(msg) && !StringUtils.equals(type, "2")) {
                    error_type = "异常地址报错";
                }

                String location = o.getX() + "," + o.getY();
                String source = "";
                if (StringUtils.equals(o.getEvent_id(), "1127")) {
                    source = "派件历史";
                } else if (StringUtils.equals(o.getEvent_id(), "10068")) {
                    source = "路径规划任务列表";
                }
                o.setLocation(location);
                o.setCityCode(cityCode);
                o.setCorrect_aoi_name(msg);
                o.setError_type(error_type);
                o.setSource(source);

                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("detailRdd cnt:{}", detailRdd.count());
            detailRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            productIncUbasNextAppRdd.unpersist();

            JavaRDD<StAreaCityRelation> areaCityRdd = service.loadAreaCityRelation(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("areaCityRdd cnt:{}", areaCityRdd.count());
            areaCityRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            detailRdd = detailRdd.mapToPair(o -> new Tuple2<>(o.getCityCode(), o)).leftOuterJoin(areaCityRdd.mapToPair(o -> new Tuple2<>(o.getCity_code(), o))).map(tp -> {
                ProductIncUbasNextApp productIncUbasNextApp = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    StAreaCityRelation stAreaCityRelation = tp._2._2.get();
                    productIncUbasNextApp.setArea(stAreaCityRelation.getArea_code());
                }
                return productIncUbasNextApp;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("detailRdd cnt:{}", detailRdd.count());
            detailRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            areaCityRdd.unpersist();

            //插入明细数据
            service.saveDetailData(spark, detailRdd, date);

            //生成统计
            JavaRDD<ProductIncUbasNextApp> statRdd = detailRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getArea(), o.getCityCode(), o.getUserid(), o.getZonecode(), o.getSource()}, "_"), o))
                    .groupByKey()
                    .map(tp -> {
                        List<ProductIncUbasNextApp> list = Lists.newArrayList(tp._2);
                        ProductIncUbasNextApp productIncUbasNextApp = list.get(0);

                        int aoi_internal_cnt = list.stream().filter(o -> StringUtils.equals(o.getError_type(), "AOI区域内报错")).collect(Collectors.toList()).size();
                        int aoi_between_cnt = list.stream().filter(o -> StringUtils.equals(o.getError_type(), "AOI区域间报错")).collect(Collectors.toList()).size();
                        int exception_addr_cnt = list.stream().filter(o -> StringUtils.equals(o.getError_type(), "异常地址报错")).collect(Collectors.toList()).size();
                        productIncUbasNextApp.setAoi_internal_cnt(aoi_internal_cnt);
                        productIncUbasNextApp.setAoi_between_cnt(aoi_between_cnt);
                        productIncUbasNextApp.setException_addr_cnt(exception_addr_cnt);

                        return productIncUbasNextApp;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statRdd cnt:{}", statRdd.count());
            statRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            detailRdd.unpersist();

            //插入统计数据
            service.saveStatlData(spark, statRdd, date);
            statRdd.unpersist();
        }
        spark.stop();
    }
}
