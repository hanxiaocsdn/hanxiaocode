package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.BtAnalysisController;
import com.sf.gis.java.sds.controller.CpAnalysisController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 摆摊数据挖掘
 * @author 01370539 Created On: Mar.07 2022
 */
public class BtAnalysisApp {
    private static final Logger logger = LoggerFactory.getLogger(BtAnalysisApp.class);

    public static void main(String[] args) {
        String startDate;
        String endDate;
        String isFromOrig;
        String cityCode = null;
        if (args != null && args.length >= 4) {
            cityCode = args[0];
            startDate = args[1];
            endDate = args[2];
            isFromOrig = args[3];
        } else {
            if (args.length == 1) {
                cityCode = args[0];
            }
            startDate = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 3);
            endDate = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 3);
            isFromOrig = "true";
        }

        if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
            logger.error("param not match, startDate - {}, endDate - {}", startDate, endDate);
            System.exit(0);
        }
        new BtAnalysisController().process(cityCode, startDate, endDate, isFromOrig);
    }
}
