package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAddressDuplicate implements Serializable {
    @Column(name = "address_id_a")
    private String address_id_a;
    @Column(name = "address_md5_a")
    private String address_md5_a;
    @Column(name = "address_a")
    private String address_a;
    @Column(name = "keyword_a")
    private String keyword_a;
    @Column(name = "zno_code_a")
    private String zno_code_a;
    @Column(name = "receipt_zno_code_a")
    private String receipt_zno_code_a;
    @Column(name = "x_a")
    private String x_a;
    @Column(name = "y_a")
    private String y_a;
    @Column(name = "type_a")
    private String type_a;
    @Column(name = "delivery_type_a")
    private String delivery_type_a;
    @Column(name = "status_a")
    private String status_a;
    @Column(name = "aoi_id_a")
    private String aoi_id_a;
    @Column(name = "src_a")
    private String src_a;

    @Column(name = "aoi_code_a")
    private String aoi_code_a;
    @Column(name = "aoi_name_a")
    private String aoi_name_a;
    @Column(name = "fa_type_a")
    private String fa_type_a;
    @Column(name = "aoi_area_code_a")
    private String aoi_area_code_a;

    @Column(name = "group_alias_a")
    private String group_alias_a;
    @Column(name = "group_type_a")
    private String group_type_a;
    @Column(name = "group_name_a")
    private String group_name_a;
    @Column(name = "group_adcode_a")
    private String group_adcode_a;

    @Column(name = "address_split_info_a")
    private String address_split_info_a;
    @Column(name = "key_split_info_a")
    private String key_split_info_a;

    @Column(name = "max_split_addr_a")
    private String max_split_addr_a;
    @Column(name = "max_split_key_a")
    private String max_split_key_a;

    @Column(name = "key_14_a")
    private String key_14_a;
    @Column(name = "key_cnt13_a")
    private String key_cnt13_a;
    @Column(name = "key_deny14_a")
    private String key_deny14_a;
    @Column(name = "key_deny14_t_a")
    private String key_deny14_t_a;

    @Column(name = "address_new_a")
    private String address_new_a;
    @Column(name = "key_new_a")
    private String key_new_a;

    @Column(name = "address_new_sp_a")
    private String address_new_sp_a;
    @Column(name = "key_new_sp_a")
    private String key_new_sp_a;
    @Column(name = "key_deny14_t_sp_a")
    private String key_deny14_t_sp_a;

    @Column(name = "address_new_qp_a")
    private String address_new_qp_a;
    @Column(name = "key_new_qp_a")
    private String key_new_qp_a;
    @Column(name = "key_deny14_t_qp_a")
    private String key_deny14_t_qp_a;

    @Column(name = "address_id_b")
    private String address_id_b;
    @Column(name = "address_md5_b")
    private String address_md5_b;
    @Column(name = "address_b")
    private String address_b;
    @Column(name = "keyword_b")
    private String keyword_b;
    @Column(name = "zno_code_b")
    private String zno_code_b;
    @Column(name = "receipt_zno_code_b")
    private String receipt_zno_code_b;
    @Column(name = "x_b")
    private String x_b;
    @Column(name = "y_b")
    private String y_b;
    @Column(name = "type_b")
    private String type_b;
    @Column(name = "delivery_type_b")
    private String delivery_type_b;
    @Column(name = "status_b")
    private String status_b;
    @Column(name = "aoi_id_b")
    private String aoi_id_b;
    @Column(name = "src_b")
    private String src_b;

    @Column(name = "aoi_code_b")
    private String aoi_code_b;
    @Column(name = "aoi_name_b")
    private String aoi_name_b;
    @Column(name = "fa_type_b")
    private String fa_type_b;
    @Column(name = "aoi_area_code_b")
    private String aoi_area_code_b;

    @Column(name = "group_alias_b")
    private String group_alias_b;
    @Column(name = "group_type_b")
    private String group_type_b;
    @Column(name = "group_name_b")
    private String group_name_b;
    @Column(name = "group_adcode_b")
    private String group_adcode_b;

    @Column(name = "address_split_info_b")
    private String address_split_info_b;
    @Column(name = "key_split_info_b")
    private String key_split_info_b;

    @Column(name = "max_split_addr_b")
    private String max_split_addr_b;
    @Column(name = "max_split_key_b")
    private String max_split_key_b;

    @Column(name = "key_14_b")
    private String key_14_b;
    @Column(name = "key_cnt13_b")
    private String key_cnt13_b;
    @Column(name = "key_deny14_b")
    private String key_deny14_b;
    @Column(name = "key_deny14_t_b")
    private String key_deny14_t_b;

    @Column(name = "address_new_b")
    private String address_new_b;
    @Column(name = "key_new_b")
    private String key_new_b;

    @Column(name = "address_new_sp_b")
    private String address_new_sp_b;
    @Column(name = "key_new_sp_b")
    private String key_new_sp_b;
    @Column(name = "key_deny14_t_sp_b")
    private String key_deny14_t_sp_b;

    @Column(name = "address_new_qp_b")
    private String address_new_qp_b;
    @Column(name = "key_new_qp_b")
    private String key_new_qp_b;
    @Column(name = "key_deny14_t_qp_b")
    private String key_deny14_t_qp_b;


    @Column(name = "tag")
    private String tag;
    @Column(name = "distance_xy")
    private String distance_xy;
    @Column(name = "distance_aoi")
    private String distance_aoi;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String city_code;

    public String getDistance_xy() {
        return distance_xy;
    }

    public void setDistance_xy(String distance_xy) {
        this.distance_xy = distance_xy;
    }

    public String getDistance_aoi() {
        return distance_aoi;
    }

    public void setDistance_aoi(String distance_aoi) {
        this.distance_aoi = distance_aoi;
    }

    public String getAddress_new_qp_a() {
        return address_new_qp_a;
    }

    public void setAddress_new_qp_a(String address_new_qp_a) {
        this.address_new_qp_a = address_new_qp_a;
    }

    public String getKey_new_qp_a() {
        return key_new_qp_a;
    }

    public void setKey_new_qp_a(String key_new_qp_a) {
        this.key_new_qp_a = key_new_qp_a;
    }

    public String getKey_deny14_t_qp_a() {
        return key_deny14_t_qp_a;
    }

    public void setKey_deny14_t_qp_a(String key_deny14_t_qp_a) {
        this.key_deny14_t_qp_a = key_deny14_t_qp_a;
    }

    public String getAddress_new_qp_b() {
        return address_new_qp_b;
    }

    public void setAddress_new_qp_b(String address_new_qp_b) {
        this.address_new_qp_b = address_new_qp_b;
    }

    public String getKey_new_qp_b() {
        return key_new_qp_b;
    }

    public void setKey_new_qp_b(String key_new_qp_b) {
        this.key_new_qp_b = key_new_qp_b;
    }

    public String getKey_deny14_t_qp_b() {
        return key_deny14_t_qp_b;
    }

    public void setKey_deny14_t_qp_b(String key_deny14_t_qp_b) {
        this.key_deny14_t_qp_b = key_deny14_t_qp_b;
    }

    public String getAddress_id_a() {
        return address_id_a;
    }

    public void setAddress_id_a(String address_id_a) {
        this.address_id_a = address_id_a;
    }

    public String getAddress_md5_a() {
        return address_md5_a;
    }

    public void setAddress_md5_a(String address_md5_a) {
        this.address_md5_a = address_md5_a;
    }

    public String getAddress_a() {
        return address_a;
    }

    public void setAddress_a(String address_a) {
        this.address_a = address_a;
    }

    public String getKeyword_a() {
        return keyword_a;
    }

    public void setKeyword_a(String keyword_a) {
        this.keyword_a = keyword_a;
    }

    public String getZno_code_a() {
        return zno_code_a;
    }

    public void setZno_code_a(String zno_code_a) {
        this.zno_code_a = zno_code_a;
    }

    public String getReceipt_zno_code_a() {
        return receipt_zno_code_a;
    }

    public void setReceipt_zno_code_a(String receipt_zno_code_a) {
        this.receipt_zno_code_a = receipt_zno_code_a;
    }

    public String getX_a() {
        return x_a;
    }

    public void setX_a(String x_a) {
        this.x_a = x_a;
    }

    public String getY_a() {
        return y_a;
    }

    public void setY_a(String y_a) {
        this.y_a = y_a;
    }

    public String getType_a() {
        return type_a;
    }

    public void setType_a(String type_a) {
        this.type_a = type_a;
    }

    public String getDelivery_type_a() {
        return delivery_type_a;
    }

    public void setDelivery_type_a(String delivery_type_a) {
        this.delivery_type_a = delivery_type_a;
    }

    public String getStatus_a() {
        return status_a;
    }

    public void setStatus_a(String status_a) {
        this.status_a = status_a;
    }

    public String getAoi_id_a() {
        return aoi_id_a;
    }

    public void setAoi_id_a(String aoi_id_a) {
        this.aoi_id_a = aoi_id_a;
    }

    public String getSrc_a() {
        return src_a;
    }

    public void setSrc_a(String src_a) {
        this.src_a = src_a;
    }

    public String getAoi_code_a() {
        return aoi_code_a;
    }

    public void setAoi_code_a(String aoi_code_a) {
        this.aoi_code_a = aoi_code_a;
    }

    public String getAoi_name_a() {
        return aoi_name_a;
    }

    public void setAoi_name_a(String aoi_name_a) {
        this.aoi_name_a = aoi_name_a;
    }

    public String getFa_type_a() {
        return fa_type_a;
    }

    public void setFa_type_a(String fa_type_a) {
        this.fa_type_a = fa_type_a;
    }

    public String getAoi_area_code_a() {
        return aoi_area_code_a;
    }

    public void setAoi_area_code_a(String aoi_area_code_a) {
        this.aoi_area_code_a = aoi_area_code_a;
    }

    public String getGroup_alias_a() {
        return group_alias_a;
    }

    public void setGroup_alias_a(String group_alias_a) {
        this.group_alias_a = group_alias_a;
    }

    public String getGroup_type_a() {
        return group_type_a;
    }

    public void setGroup_type_a(String group_type_a) {
        this.group_type_a = group_type_a;
    }

    public String getGroup_name_a() {
        return group_name_a;
    }

    public void setGroup_name_a(String group_name_a) {
        this.group_name_a = group_name_a;
    }

    public String getGroup_adcode_a() {
        return group_adcode_a;
    }

    public void setGroup_adcode_a(String group_adcode_a) {
        this.group_adcode_a = group_adcode_a;
    }

    public String getAddress_split_info_a() {
        return address_split_info_a;
    }

    public void setAddress_split_info_a(String address_split_info_a) {
        this.address_split_info_a = address_split_info_a;
    }

    public String getKey_split_info_a() {
        return key_split_info_a;
    }

    public void setKey_split_info_a(String key_split_info_a) {
        this.key_split_info_a = key_split_info_a;
    }

    public String getMax_split_addr_a() {
        return max_split_addr_a;
    }

    public void setMax_split_addr_a(String max_split_addr_a) {
        this.max_split_addr_a = max_split_addr_a;
    }

    public String getMax_split_key_a() {
        return max_split_key_a;
    }

    public void setMax_split_key_a(String max_split_key_a) {
        this.max_split_key_a = max_split_key_a;
    }

    public String getKey_14_a() {
        return key_14_a;
    }

    public void setKey_14_a(String key_14_a) {
        this.key_14_a = key_14_a;
    }

    public String getKey_cnt13_a() {
        return key_cnt13_a;
    }

    public void setKey_cnt13_a(String key_cnt13_a) {
        this.key_cnt13_a = key_cnt13_a;
    }

    public String getKey_deny14_a() {
        return key_deny14_a;
    }

    public void setKey_deny14_a(String key_deny14_a) {
        this.key_deny14_a = key_deny14_a;
    }

    public String getKey_deny14_t_a() {
        return key_deny14_t_a;
    }

    public void setKey_deny14_t_a(String key_deny14_t_a) {
        this.key_deny14_t_a = key_deny14_t_a;
    }

    public String getAddress_new_a() {
        return address_new_a;
    }

    public void setAddress_new_a(String address_new_a) {
        this.address_new_a = address_new_a;
    }

    public String getKey_new_a() {
        return key_new_a;
    }

    public void setKey_new_a(String key_new_a) {
        this.key_new_a = key_new_a;
    }

    public String getAddress_new_sp_a() {
        return address_new_sp_a;
    }

    public void setAddress_new_sp_a(String address_new_sp_a) {
        this.address_new_sp_a = address_new_sp_a;
    }

    public String getKey_new_sp_a() {
        return key_new_sp_a;
    }

    public void setKey_new_sp_a(String key_new_sp_a) {
        this.key_new_sp_a = key_new_sp_a;
    }

    public String getKey_deny14_t_sp_a() {
        return key_deny14_t_sp_a;
    }

    public void setKey_deny14_t_sp_a(String key_deny14_t_sp_a) {
        this.key_deny14_t_sp_a = key_deny14_t_sp_a;
    }

    public String getAddress_id_b() {
        return address_id_b;
    }

    public void setAddress_id_b(String address_id_b) {
        this.address_id_b = address_id_b;
    }

    public String getAddress_md5_b() {
        return address_md5_b;
    }

    public void setAddress_md5_b(String address_md5_b) {
        this.address_md5_b = address_md5_b;
    }

    public String getAddress_b() {
        return address_b;
    }

    public void setAddress_b(String address_b) {
        this.address_b = address_b;
    }

    public String getKeyword_b() {
        return keyword_b;
    }

    public void setKeyword_b(String keyword_b) {
        this.keyword_b = keyword_b;
    }

    public String getZno_code_b() {
        return zno_code_b;
    }

    public void setZno_code_b(String zno_code_b) {
        this.zno_code_b = zno_code_b;
    }

    public String getReceipt_zno_code_b() {
        return receipt_zno_code_b;
    }

    public void setReceipt_zno_code_b(String receipt_zno_code_b) {
        this.receipt_zno_code_b = receipt_zno_code_b;
    }

    public String getX_b() {
        return x_b;
    }

    public void setX_b(String x_b) {
        this.x_b = x_b;
    }

    public String getY_b() {
        return y_b;
    }

    public void setY_b(String y_b) {
        this.y_b = y_b;
    }

    public String getType_b() {
        return type_b;
    }

    public void setType_b(String type_b) {
        this.type_b = type_b;
    }

    public String getDelivery_type_b() {
        return delivery_type_b;
    }

    public void setDelivery_type_b(String delivery_type_b) {
        this.delivery_type_b = delivery_type_b;
    }

    public String getStatus_b() {
        return status_b;
    }

    public void setStatus_b(String status_b) {
        this.status_b = status_b;
    }

    public String getAoi_id_b() {
        return aoi_id_b;
    }

    public void setAoi_id_b(String aoi_id_b) {
        this.aoi_id_b = aoi_id_b;
    }

    public String getSrc_b() {
        return src_b;
    }

    public void setSrc_b(String src_b) {
        this.src_b = src_b;
    }

    public String getAoi_code_b() {
        return aoi_code_b;
    }

    public void setAoi_code_b(String aoi_code_b) {
        this.aoi_code_b = aoi_code_b;
    }

    public String getAoi_name_b() {
        return aoi_name_b;
    }

    public void setAoi_name_b(String aoi_name_b) {
        this.aoi_name_b = aoi_name_b;
    }

    public String getFa_type_b() {
        return fa_type_b;
    }

    public void setFa_type_b(String fa_type_b) {
        this.fa_type_b = fa_type_b;
    }

    public String getAoi_area_code_b() {
        return aoi_area_code_b;
    }

    public void setAoi_area_code_b(String aoi_area_code_b) {
        this.aoi_area_code_b = aoi_area_code_b;
    }

    public String getGroup_alias_b() {
        return group_alias_b;
    }

    public void setGroup_alias_b(String group_alias_b) {
        this.group_alias_b = group_alias_b;
    }

    public String getGroup_type_b() {
        return group_type_b;
    }

    public void setGroup_type_b(String group_type_b) {
        this.group_type_b = group_type_b;
    }

    public String getGroup_name_b() {
        return group_name_b;
    }

    public void setGroup_name_b(String group_name_b) {
        this.group_name_b = group_name_b;
    }

    public String getGroup_adcode_b() {
        return group_adcode_b;
    }

    public void setGroup_adcode_b(String group_adcode_b) {
        this.group_adcode_b = group_adcode_b;
    }

    public String getAddress_split_info_b() {
        return address_split_info_b;
    }

    public void setAddress_split_info_b(String address_split_info_b) {
        this.address_split_info_b = address_split_info_b;
    }

    public String getKey_split_info_b() {
        return key_split_info_b;
    }

    public void setKey_split_info_b(String key_split_info_b) {
        this.key_split_info_b = key_split_info_b;
    }

    public String getMax_split_addr_b() {
        return max_split_addr_b;
    }

    public void setMax_split_addr_b(String max_split_addr_b) {
        this.max_split_addr_b = max_split_addr_b;
    }

    public String getMax_split_key_b() {
        return max_split_key_b;
    }

    public void setMax_split_key_b(String max_split_key_b) {
        this.max_split_key_b = max_split_key_b;
    }

    public String getKey_14_b() {
        return key_14_b;
    }

    public void setKey_14_b(String key_14_b) {
        this.key_14_b = key_14_b;
    }

    public String getKey_cnt13_b() {
        return key_cnt13_b;
    }

    public void setKey_cnt13_b(String key_cnt13_b) {
        this.key_cnt13_b = key_cnt13_b;
    }

    public String getKey_deny14_b() {
        return key_deny14_b;
    }

    public void setKey_deny14_b(String key_deny14_b) {
        this.key_deny14_b = key_deny14_b;
    }

    public String getKey_deny14_t_b() {
        return key_deny14_t_b;
    }

    public void setKey_deny14_t_b(String key_deny14_t_b) {
        this.key_deny14_t_b = key_deny14_t_b;
    }

    public String getAddress_new_b() {
        return address_new_b;
    }

    public void setAddress_new_b(String address_new_b) {
        this.address_new_b = address_new_b;
    }

    public String getKey_new_b() {
        return key_new_b;
    }

    public void setKey_new_b(String key_new_b) {
        this.key_new_b = key_new_b;
    }

    public String getAddress_new_sp_b() {
        return address_new_sp_b;
    }

    public void setAddress_new_sp_b(String address_new_sp_b) {
        this.address_new_sp_b = address_new_sp_b;
    }

    public String getKey_new_sp_b() {
        return key_new_sp_b;
    }

    public void setKey_new_sp_b(String key_new_sp_b) {
        this.key_new_sp_b = key_new_sp_b;
    }

    public String getKey_deny14_t_sp_b() {
        return key_deny14_t_sp_b;
    }

    public void setKey_deny14_t_sp_b(String key_deny14_t_sp_b) {
        this.key_deny14_t_sp_b = key_deny14_t_sp_b;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
