package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ApplicationNocallPickCrossRegional implements Serializable {
    @Column(name = "time")
    private String time;
    @Column(name = "src_order_no")
    private String src_order_no;
    @Column(name = "inner_order_no")
    private String inner_order_no;
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "zonecode")
    private String zonecode;
    @Column(name = "order_time")
    private String order_time;
    @Column(name = "act_loginid")
    private String act_loginid;
    @Column(name = "act_time")
    private String act_time;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "city_name")
    private String city_name;
    @Column(name = "aoi_group")
    private String aoi_group;
    @Column(name = "eventlng")
    private String eventlng;
    @Column(name = "eventlat")
    private String eventlat;

    private String coor_aoi;
    private String coor_aoi_code;
    private String coor_zno_code;
    private String coor_aoi_group;
    private String coor_area_dist;
    private String coor_zno_dist;
    private String aoi_code;
    private String aoi_id;
    private String aoi_id_group;
    private String aoi_area_code_list;

    private String flag;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getSrc_order_no() {
        return src_order_no;
    }

    public void setSrc_order_no(String src_order_no) {
        this.src_order_no = src_order_no;
    }

    public String getInner_order_no() {
        return inner_order_no;
    }

    public void setInner_order_no(String inner_order_no) {
        this.inner_order_no = inner_order_no;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public String getAct_loginid() {
        return act_loginid;
    }

    public void setAct_loginid(String act_loginid) {
        this.act_loginid = act_loginid;
    }

    public String getAct_time() {
        return act_time;
    }

    public void setAct_time(String act_time) {
        this.act_time = act_time;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getAoi_area_code_list() {
        return aoi_area_code_list;
    }

    public void setAoi_area_code_list(String aoi_area_code_list) {
        this.aoi_area_code_list = aoi_area_code_list;
    }

    public String getAoi_id_group() {
        return aoi_id_group;
    }

    public void setAoi_id_group(String aoi_id_group) {
        this.aoi_id_group = aoi_id_group;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getCoor_zno_dist() {
        return coor_zno_dist;
    }

    public void setCoor_zno_dist(String coor_zno_dist) {
        this.coor_zno_dist = coor_zno_dist;
    }

    public String getCoor_aoi_code() {
        return coor_aoi_code;
    }

    public void setCoor_aoi_code(String coor_aoi_code) {
        this.coor_aoi_code = coor_aoi_code;
    }

    public String getCoor_zno_code() {
        return coor_zno_code;
    }

    public void setCoor_zno_code(String coor_zno_code) {
        this.coor_zno_code = coor_zno_code;
    }

    public String getCoor_area_dist() {
        return coor_area_dist;
    }

    public void setCoor_area_dist(String coor_area_dist) {
        this.coor_area_dist = coor_area_dist;
    }

    public String getCoor_aoi_group() {
        return coor_aoi_group;
    }

    public void setCoor_aoi_group(String coor_aoi_group) {
        this.coor_aoi_group = coor_aoi_group;
    }

    public String getCoor_aoi() {
        return coor_aoi;
    }

    public void setCoor_aoi(String coor_aoi) {
        this.coor_aoi = coor_aoi;
    }

    public String getEventlng() {
        return eventlng;
    }

    public void setEventlng(String eventlng) {
        this.eventlng = eventlng;
    }

    public String getEventlat() {
        return eventlat;
    }

    public void setEventlat(String eventlat) {
        this.eventlat = eventlat;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getAoi_group() {
        return aoi_group;
    }

    public void setAoi_group(String aoi_group) {
        this.aoi_group = aoi_group;
    }
}
