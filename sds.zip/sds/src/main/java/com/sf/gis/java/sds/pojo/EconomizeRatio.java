package com.sf.gis.java.sds.pojo;



import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class EconomizeRatio implements Serializable {
    @Column(name="task_id")
    private String taskId;
    @Column(name="len_new")
    private String lenNew;
    @Column(name = "time_new")
    private String timeNew;
    @Column(name="inc_month")
    private String incMonth;
    @Column(name="day")
    private String day;
    @Column(name = "status")
    private String status;
    @Column(name = "conduct_type")
    private String conductType;
    @Column(name = "inc_day")
    private String incDay;
    @Column(name = "toll_charge")
    private String tollCharge;
    @Column(name = "etc_toll_charge")
    private String etcTollCharge;
    @Column(name = "is_navi")
    private String isNavi;
    @Column(name = "is_navi_noyaw")
    private String isNaviNoyaw;
    @Column(name="task_area_code")
    private String taskAreaCode;
    @Column(name="src_province")
    private String srcProvince;
    @Column(name="dest_province")
    private String destProvince;
    @Column(name="src_city_name")
    private String srcCityName;
    @Column(name="dest_city_name")
    private String destCityName;
    @Column(name = "biz_type")
    private int bizType;
    @Column(name = "main_driver_account")
    private String mainDriverAccount;
    @Column(name = "driver_name")
    private String driverName;
    @Column(name = "actual_run_time")
    private long actualRunTime;
    @Column(name = "app_time_actual_distance")
    private double appTimeActualDistance;
    @Column(name = "plan_run_time")
    private long planRunTime;
    @Column(name = "carrier_type")
    private int carrierType;
    @Column(name = "plf_flag")
    private int plfFlag;
    @Column(name = "is_zy")
    private int isZy;
    @Column(name = "is_db")
    private int isDb;
    @Column(name = "nodb_delay_min")
    private long nodbDelayMin;
    @Column(name = "line_code")
    private String lineCode;
    @Column(name = "is_push_line")
    private String isPushLine;
    @Column(name = "base_line_mile")
    private String baseLineMile;
    @Column(name = "base_line_time")
    private String baseLineTime;
    @Column(name = "base_line_etctoll")
    private String baseLineEtctoll;
    @Column(name = "base_line_toll")
    private String baseLineToll;
    @Column(name = "line_area")
    private String line_area;

    @Column(name = "error_type")
    private String error_type;

    private double zy_sumBaseLineEtctoll;
    private int zy_taskNumber;
    private double zy_sumEtcTollCharge;
    private int no_zy_taskNumber;
    private double no_zy_sumEtcTollCharge;

    public String getError_type() {
        return error_type;
    }

    public void setError_type(String error_type) {
        this.error_type = error_type;
    }

    public String getLine_area() {
        return line_area;
    }

    public void setLine_area(String line_area) {
        this.line_area = line_area;
    }

    public String getBaseLineToll() {
        return baseLineToll;
    }

    public void setBaseLineToll(String baseLineToll) {
        this.baseLineToll = baseLineToll;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getLenNew() {
        return lenNew;
    }

    public void setLenNew(String lenNew) {
        this.lenNew = lenNew;
    }

    public String getTimeNew() {
        return timeNew;
    }

    public void setTimeNew(String timeNew) {
        this.timeNew = timeNew;
    }

    public String getIncMonth() {
        return incMonth;
    }

    public void setIncMonth(String incMonth) {
        this.incMonth = incMonth;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getConductType() {
        return conductType;
    }

    public void setConductType(String conductType) {
        this.conductType = conductType;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getTollCharge() {
        return tollCharge;
    }

    public void setTollCharge(String tollCharge) {
        this.tollCharge = tollCharge;
    }

    public String getEtcTollCharge() {
        return etcTollCharge;
    }

    public void setEtcTollCharge(String etcTollCharge) {
        this.etcTollCharge = etcTollCharge;
    }

    public String getIsNavi() {
        return isNavi;
    }

    public void setIsNavi(String isNavi) {
        this.isNavi = isNavi;
    }

    public String getIsNaviNoyaw() {
        return isNaviNoyaw;
    }

    public void setIsNaviNoyaw(String isNaviNoyaw) {
        this.isNaviNoyaw = isNaviNoyaw;
    }

    public String getTaskAreaCode() {
        return taskAreaCode;
    }

    public void setTaskAreaCode(String taskAreaCode) {
        this.taskAreaCode = taskAreaCode;
    }

    public String getSrcProvince() {
        return srcProvince;
    }

    public void setSrcProvince(String srcProvince) {
        this.srcProvince = srcProvince;
    }

    public String getDestProvince() {
        return destProvince;
    }

    public void setDestProvince(String destProvince) {
        this.destProvince = destProvince;
    }

    public String getSrcCityName() {
        return srcCityName;
    }

    public void setSrcCityName(String srcCityName) {
        this.srcCityName = srcCityName;
    }

    public String getDestCityName() {
        return destCityName;
    }

    public void setDestCityName(String destCityName) {
        this.destCityName = destCityName;
    }

    public int getBizType() {
        return bizType;
    }

    public void setBizType(int bizType) {
        this.bizType = bizType;
    }

    public String getMainDriverAccount() {
        return mainDriverAccount;
    }

    public void setMainDriverAccount(String mainDriverAccount) {
        this.mainDriverAccount = mainDriverAccount;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public long getActualRunTime() {
        return actualRunTime;
    }

    public void setActualRunTime(long actualRunTime) {
        this.actualRunTime = actualRunTime;
    }

    public double getAppTimeActualDistance() {
        return appTimeActualDistance;
    }

    public void setAppTimeActualDistance(double appTimeActualDistance) {
        this.appTimeActualDistance = appTimeActualDistance;
    }

    public long getPlanRunTime() {
        return planRunTime;
    }

    public void setPlanRunTime(long planRunTime) {
        this.planRunTime = planRunTime;
    }

    public int getCarrierType() {
        return carrierType;
    }

    public void setCarrierType(int carrierType) {
        this.carrierType = carrierType;
    }

    public int getPlfFlag() {
        return plfFlag;
    }

    public void setPlfFlag(int plfFlag) {
        this.plfFlag = plfFlag;
    }

    public int getIsZy() {
        return isZy;
    }

    public void setIsZy(int isZy) {
        this.isZy = isZy;
    }

    public int getIsDb() {
        return isDb;
    }

    public void setIsDb(int isDb) {
        this.isDb = isDb;
    }

    public long getNodbDelayMin() {
        return nodbDelayMin;
    }

    public void setNodbDelayMin(long nodbDelayMin) {
        this.nodbDelayMin = nodbDelayMin;
    }

    public String getLineCode() {
        return lineCode;
    }

    public void setLineCode(String lineCode) {
        this.lineCode = lineCode;
    }

    public String getIsPushLine() {
        return isPushLine;
    }

    public void setIsPushLine(String isPushLine) {
        this.isPushLine = isPushLine;
    }

    public String getBaseLineMile() {
        return baseLineMile;
    }

    public void setBaseLineMile(String baseLineMile) {
        this.baseLineMile = baseLineMile;
    }

    public String getBaseLineTime() {
        return baseLineTime;
    }

    public void setBaseLineTime(String baseLineTime) {
        this.baseLineTime = baseLineTime;
    }

    public String getBaseLineEtctoll() {
        return baseLineEtctoll;
    }

    public void setBaseLineEtctoll(String baseLineEtctoll) {
        this.baseLineEtctoll = baseLineEtctoll;
    }

    public double getZy_sumBaseLineEtctoll() {
        return zy_sumBaseLineEtctoll;
    }

    public void setZy_sumBaseLineEtctoll(double zy_sumBaseLineEtctoll) {
        this.zy_sumBaseLineEtctoll = zy_sumBaseLineEtctoll;
    }

    public int getZy_taskNumber() {
        return zy_taskNumber;
    }

    public void setZy_taskNumber(int zy_taskNumber) {
        this.zy_taskNumber = zy_taskNumber;
    }

    public double getZy_sumEtcTollCharge() {
        return zy_sumEtcTollCharge;
    }

    public void setZy_sumEtcTollCharge(double zy_sumEtcTollCharge) {
        this.zy_sumEtcTollCharge = zy_sumEtcTollCharge;
    }

    public int getNo_zy_taskNumber() {
        return no_zy_taskNumber;
    }

    public void setNo_zy_taskNumber(int no_zy_taskNumber) {
        this.no_zy_taskNumber = no_zy_taskNumber;
    }

    public double getNo_zy_sumEtcTollCharge() {
        return no_zy_sumEtcTollCharge;
    }

    public void setNo_zy_sumEtcTollCharge(double no_zy_sumEtcTollCharge) {
        this.no_zy_sumEtcTollCharge = no_zy_sumEtcTollCharge;
    }
}
