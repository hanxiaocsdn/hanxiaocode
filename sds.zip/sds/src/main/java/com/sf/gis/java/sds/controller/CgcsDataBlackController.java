package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CghsResultData;
import com.sf.gis.java.sds.service.CgcsDataIssueService;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class CgcsDataBlackController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(CgcsDataBlackController.class);
    CgcsDataIssueService service = new CgcsDataIssueService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dates) {
            logger.error("date:{}", date);
            logger.error("查询所有仓管核实的结果");
            JavaRDD<CghsResultData> cghsResultDataRdd = service.loadCghsResultData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cghsResultDataRdd cnt:{}", cghsResultDataRdd.count());
            cghsResultDataRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            if (cghsResultDataRdd.count() > 0) {
                logger.error("计算频率，统计出黑名单数据");
                JavaRDD<CghsResultData> freqRdd = cghsResultDataRdd.repartition(800).mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getAddress(), o.getCheck_by()}, "_"), o))
                        .groupByKey()
                        .flatMap(tp -> {
                            List<CghsResultData> list = Lists.newArrayList(tp._2);
                            int size = list.size();
                            list = list.stream().map(o -> {
                                o.setFreq(size);
                                return o;
                            }).collect(Collectors.toList());
                            return list.iterator();
                        }).filter(o -> o.getFreq() >= 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("freqRdd cnt:{}", freqRdd.count());
                freqRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
                cghsResultDataRdd.unpersist();

                logger.error("黑名单数据存储");
                service.saveBlackData(spark, freqRdd, "dm_gis.cgcss_misclassification_data_shunt_black");
                freqRdd.unpersist();
            } else {
                logger.error("date:{}，无符合条件数据",date);
            }

        }

    }
}
