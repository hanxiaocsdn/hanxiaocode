package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GisRdsOmsfrom implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "syncreqdatetime")
    private String syncreqdatetime;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "emp_code")
    private String emp_code;
    @Column(name = "reqtimetm")
    private String reqtimetm;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "inc_day")
    private String inc_day;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getReqtimetm() {
        return reqtimetm;
    }

    public void setReqtimetm(String reqtimetm) {
        this.reqtimetm = reqtimetm;
    }

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getSyncreqdatetime() {
        return syncreqdatetime;
    }

    public void setSyncreqdatetime(String syncreqdatetime) {
        this.syncreqdatetime = syncreqdatetime;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }
}
