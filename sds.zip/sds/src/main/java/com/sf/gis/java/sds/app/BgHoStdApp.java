package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.sds.controller.BgHoStdController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 标杆库分流地址库
 * @author 01370539 Created On: May.27 2021
 */
public class BgHoStdApp {
    private static final Logger logger = LoggerFactory.getLogger(BgHoStdApp.class);

    public static void main(String[] args) {
        String statDate = "";
        String[] citys = new String[0];
        if (args != null && args.length >= 2) {
            statDate = args[0];
            citys = args[1].split(",");
        }

        if (!statDate.matches("20\\d{6}") || citys.length == 0) {
            logger.error("param not match, statDate - {}, citys - {}", statDate, citys);
            System.exit(0);
        }
        new BgHoStdController().process(statDate, citys);
    }
}
