package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.WaybillFairsAoiInfoDi;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 需求：特殊入仓展会增值服务场景数据跑数
 * 业务方：潘宜鹏（01412980）
 * 研发：匡仁衡（01399581）
 * 任务id：778880
 */

public class AppWaybillFairsAoiInfoDi {
    private static Logger logger = LoggerFactory.getLogger(AppWaybillFairsAoiInfoDi.class);
    private static String url = "http://gis-int.int.sfdc.com.cn:1080/diff/api/vas?address=%s&citycode=%s&opt=exh&ak=9c1d529c40f54877a9a6372e686fee47&show=1&consignaddress=%s&consigncitycode=%s";
    private static int limitMin = 2000 / 10;
    private static String account = "01399581";
    private static String taskId = "778880";
    private static String taskName = "特殊入仓展会增值服务场景数据跑数";

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppWaybillFairsAoiInfoDi");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select\n" +
                "  waybill_no,\n" +
                "  consigned_dt,\n" +
                "  consigned_tm,\n" +
                "  src_aoi_name,\n" +
                "  src_city_code,\n" +
                "  src_city_name,\n" +
                "  dest_aoi_name,\n" +
                "  dest_city_code,\n" +
                "  dest_city_name,\n" +
                "  fairs_type,\n" +
                "  service_prod_code,\n" +
                "  add_serve_name,\n" +
                "  add_serve_fee,\n" +
                "  consignor_mobile,\n" +
                "  consignee_addr,\n" +
                "  bdp_decrypt(waybill_no,consignee_addr,false) consignee_addr_udf,\n" +
                "  consignor_addr,\n" +
                "  bdp_decrypt(waybill_no,consignor_addr,false) consignor_addr_udf\n" +
                "from\n" +
                "  ky.dm_heavy_cargo.waybill_fairs_aoi_info_di\n" +
                "where\n" +
                "  inc_day between '%s' and '%s'\n" +
                "  and add_serve_fee != 0.0\n" +
                "  and add_serve_fee is not null", startDate, endDate);

        spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01399581/sfdencrpt.ini");
        spark.sql("add jar hdfs://sfbdp1/tmp/udf/01377105/131623/1002/decrypt-2.0.jar");
        spark.sql("create temporary function bdp_decrypt as 'com.sf.udf.decrypt_v2.Decrypt'");
        JavaRDD<WaybillFairsAoiInfoDi> rdd = DataUtil.loadData(spark, sc, sql, WaybillFairsAoiInfoDi.class).map(o -> {
            o.setInc_day(endDate);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());


        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, url, "9c1d529c40f54877a9a6372e686fee47", rdd.count(), 10);
        JavaRDD<WaybillFairsAoiInfoDi> resultRdd = rdd.mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<WaybillFairsAoiInfoDi> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                WaybillFairsAoiInfoDi o = itr.next();
                String consignee_addr_udf = o.getConsignee_addr_udf();
                String dest_city_code = o.getDest_city_code();
                if (StringUtils.isNotEmpty(consignee_addr_udf)) {
                    String consignor_addr_udf = o.getConsignor_addr_udf();
                    String src_city_code = o.getSrc_city_code();

                    String req = String.format(url, URLEncoder.encode(consignee_addr_udf, "UTF-8"), dest_city_code, URLEncoder.encode(consignor_addr_udf, "UTF-8"), src_city_code);
                    String resp = HttpInvokeUtil.sendGet(req);
                    o.setResp(resp);
                    try {
                        String matchtype = JSON.parseObject(resp).getJSONObject("result").getJSONObject("hData").getString("matchtype");
                        String exhibitionid = JSON.parseObject(resp).getJSONObject("result").getJSONObject("hData").getString("exhibitionid");
                        o.setHdata_matchtype(matchtype);
                        o.setHdata_exhibitionid(exhibitionid);

                    } catch (Exception e) {
//                        e.printStackTrace();
                    }

                    try {
                        String hdata_matchtype = JSON.parseObject(resp).getJSONObject("result").getJSONObject("chdata").getString("matchtype");
                        String hdata_exhibitionid = JSON.parseObject(resp).getJSONObject("result").getJSONObject("chdata").getString("exhibitionid");
                        o.setChdata_matchtype(hdata_matchtype);
                        o.setChdata_exhibitionid(hdata_exhibitionid);
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }

                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        spark.sql(String.format("alter table dm_gis.waybill_fairs_aoi_info_di drop if EXISTS partition(inc_day='%s')", endDate));
        DataUtil.saveInto(spark, sc, "dm_gis.waybill_fairs_aoi_info_di", WaybillFairsAoiInfoDi.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
        logger.error("run end");
    }
}
