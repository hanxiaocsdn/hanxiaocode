package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.ExpressDeliveryToVillagesCostModel;
import com.sf.gis.java.sds.pojo.ExpressDeliveryToVillagesCostModelStat;
import com.sf.gis.java.sds.pojo.PathFix;
import com.sf.gis.java.sds.pojo.SaTrajectoryAoi;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;
import scala.Tuple3;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 任务id：925512（【偏远乡村派件上门】代理派件成本测算模型）
 * 业务：01425243（敖少良）
 * 研发：01399581（匡仁衡）
 */
public class AppExpressDeliveryToVillagesCostModel {
    private static String getTrackAoisUrl = "http://sds-core-datarun.sf-express.com/datarun/track/getTrackAois?showAoiCode=1";
    private static String getAoiTspUrl = "http://gis-apis.int.sfcloud.local:1080/rpmp/aoiTsp";
    private static String ak = "9a0daa124a724ee5a8d85ec60500895b";
    private static Logger logger = LoggerFactory.getLogger(AppExpressDeliveryToVillagesCostModel.class);
    private static String account = "01399581";
    private static String taskId = "925512";
    private static String taskName = "代理派件成本测算模型";
    private static double Z = 0.14; //单位时间成本为Z=0.14元/分钟
    private static double X = 0.75; //单位油耗成本为X=0.75元/公里

    public static void main(String[] args) {
        String date = args[0];
        String startDate = args[1];
        String endDate = args[2];
        logger.error("date:{}", date);
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppExpressDeliveryToVillagesCostModel");
        double avg_deliver_tm = 0;
        if (args.length == 3) {
            logger.error("获取纠偏后轨迹数据");
            JavaRDD<SaTrajectoryAoi> aoiSumIntervalTmRdd = getPathFix(sparkInfo, date);
            logger.error("获取每个aoi下的总件量");
            JavaPairRDD<String, Long> aoi_cnt_rdd = getAoiCnt(sparkInfo, date);
            logger.error("AOI内派件时间平均间隔测算：分钟/件");
            avg_deliver_tm = avg(aoi_cnt_rdd, aoiSumIntervalTmRdd);
        } else if (args.length == 4) {
            avg_deliver_tm = Double.parseDouble(args[3]);
        }
        logger.error("avg_deliver_tm:{}", avg_deliver_tm);
        logger.error("获取一个月乡村派件数据");
        JavaRDD<ExpressDeliveryToVillagesCostModel> sourceRdd = getSource(sparkInfo, startDate, endDate);
        logger.error("件量明细存储");
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.express_delivery_to_villages_cost_model_detail", ExpressDeliveryToVillagesCostModel.class, sourceRdd, "inc_day");
        logger.error("按网点维度统计");
        JavaRDD<ExpressDeliveryToVillagesCostModelStat> statRdd = deptStat(sparkInfo, sourceRdd, avg_deliver_tm);
        logger.error("统计数据存储");
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.express_delivery_to_villages_cost_model_rs", ExpressDeliveryToVillagesCostModelStat.class, statRdd, "inc_day");
        sparkInfo.getContext().stop();
        logger.error("end...");
    }

    public static JavaRDD<ExpressDeliveryToVillagesCostModelStat> deptStat(SparkInfo sparkInfo, JavaRDD<ExpressDeliveryToVillagesCostModel> deliveryCntRdd, double avg_deliver_tm) {
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", getAoiTspUrl, ak, deliveryCntRdd.count(), 10);
        JavaRDD<ExpressDeliveryToVillagesCostModelStat> statRdd = deliveryCntRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + o.getDest_zone_code(), o)).groupByKey().map(tp -> {
            List<ExpressDeliveryToVillagesCostModel> list = Lists.newArrayList(tp._2);
            ExpressDeliveryToVillagesCostModel o = list.get(0);
            String x = o.getLongitude();
            String y = o.getLatitude();

            String dest_hq_code = o.getDest_hq_code();
            String dest_area_code = o.getDest_area_code();
            String area_name = o.getArea_name();
            String dest_dist_code = o.getDest_dist_code();
            String dest_zone_code = o.getDest_zone_code();
            String dept_name = o.getDept_name();

            //0-3km件量
            List<ExpressDeliveryToVillagesCostModel> list_0_3 = list.stream().filter(t -> judge(t.getMin_distance(), 0, 3, "")).collect(Collectors.toList());
            int count_0_3 = list_0_3.size();
            //3-5km件量
            List<ExpressDeliveryToVillagesCostModel> list_3_5 = list.stream().filter(t -> judge(t.getMin_distance(), 3, 5, "")).collect(Collectors.toList());
            int count_3_5 = list_3_5.size();
            //5-10km件量
            List<ExpressDeliveryToVillagesCostModel> list_5_10 = list.stream().filter(t -> judge(t.getMin_distance(), 5, 10, "")).collect(Collectors.toList());
            int count_5_10 = list_5_10.size();
            //10-30km件量
            List<ExpressDeliveryToVillagesCostModel> list_10_30 = list.stream().filter(t -> judge(t.getMin_distance(), 10, 30, "")).collect(Collectors.toList());
            int count_10_30 = list_10_30.size();
            //30km以上件量
            List<ExpressDeliveryToVillagesCostModel> list_30 = list.stream().filter(t -> judge(t.getMin_distance(), 30, 100, "large")).collect(Collectors.toList());
            int count_30 = list_30.size();

            //0-3km派件成本
            String aoiIds_0_3 = getAoiIds(list_0_3);
            Tuple3<String, String, String> tp_0_3 = getGetAoiTspUrl(x, y, aoiIds_0_3);
            String resp_0_3 = tp_0_3._1();
            String dist_0_3 = tp_0_3._2();
            String time_0_3 = tp_0_3._3();
            double cb_0_3 = caculate(dist_0_3, time_0_3, count_0_3, avg_deliver_tm);

            //0-5km派件成本
            String aoiIds_0_5 = getAoiIds(list.stream().filter(t -> judge(t.getMin_distance(), 0, 5, "")).collect(Collectors.toList()));
            Tuple3<String, String, String> tp_0_5 = getGetAoiTspUrl(x, y, aoiIds_0_5);
            String resp_0_5 = tp_0_5._1();
            String dist_0_5 = tp_0_5._2();
            String time_0_5 = tp_0_5._3();
            double cb_0_5 = caculate(dist_0_5, time_0_5, count_0_3 + count_3_5, avg_deliver_tm);

            //0-10km派件成本
            String aoiIds_0_10 = getAoiIds(list.stream().filter(t -> judge(t.getMin_distance(), 0, 10, "")).collect(Collectors.toList()));
            Tuple3<String, String, String> tp_0_10 = getGetAoiTspUrl(x, y, aoiIds_0_10);
            String resp_0_10 = tp_0_10._1();
            String dist_0_10 = tp_0_10._2();
            String time_0_10 = tp_0_10._3();
            double cb_0_10 = caculate(dist_0_10, time_0_10, count_0_3 + count_3_5 + count_5_10, avg_deliver_tm);

            //0-30km派件成本
            String aoiIds_0_30 = getAoiIds(list.stream().filter(t -> judge(t.getMin_distance(), 0, 30, "")).collect(Collectors.toList()));
            Tuple3<String, String, String> tp_0_30 = getGetAoiTspUrl(x, y, aoiIds_0_30);
            String resp_0_30 = tp_0_30._1();
            String dist_0_30 = tp_0_30._2();
            String time_0_30 = tp_0_30._3();
            double cb_0_30 = caculate(dist_0_30, time_0_30, count_0_3 + count_3_5 + count_5_10 + count_10_30, avg_deliver_tm);

            //全部派件成本
            String aoiIds_all = getAoiIds(list);
            Tuple3<String, String, String> tp_all = getGetAoiTspUrl(x, y, aoiIds_all);
            String resp_all = tp_all._1();
            String dist_all = tp_all._2();
            String time_all = tp_all._3();
            double cb_all = caculate(dist_all, time_all, count_0_3 + count_3_5 + count_5_10 + count_10_30 + count_30, avg_deliver_tm);

            //0-3km票均派件成本
            double avg_0_3 = count_0_3 != 0 ? cb_0_3 / (double) count_0_3 : 0;

            //3-5km票均派件成本
            double avg_3_5 = count_3_5 != 0 ? (cb_0_5 - cb_0_3) / (double) count_3_5 : 0;

            //5-10km票均派件成本
            double avg_5_10 = count_5_10 != 0 ? (cb_0_10 - cb_0_5) / (double) count_5_10 : 0;

            //10-30km票均派件成本
            double avg_10_30 = count_10_30 != 0 ? (cb_0_30 - cb_0_10) / (double) count_10_30 : 0;

            //30km以上票均派件成本
            double avg_30 = count_30 != 0 ? (cb_all - cb_0_30) / (double) count_30 : 0;
            String inc_day = o.getInc_day();

            return new ExpressDeliveryToVillagesCostModelStat(dest_hq_code, dest_area_code, area_name, dest_dist_code, dest_zone_code, dept_name,
                    count_0_3 + "", count_3_5 + "", count_5_10 + "", count_10_30 + "", count_30 + "",
                    dist_0_3, time_0_3, cb_0_3 + "",
                    dist_0_5, time_0_5, cb_0_5 + "",
                    dist_0_10, time_0_10, cb_0_10 + "",
                    dist_0_30, time_0_30, cb_0_30 + "",
                    dist_all, time_all, cb_all + "",
                    avg_0_3 + "", avg_3_5 + "", avg_5_10 + "", avg_10_30 + "", avg_30 + "",
                    aoiIds_0_3, aoiIds_0_5, aoiIds_0_10, aoiIds_0_30, aoiIds_all,
                    x, y,
                    resp_0_3, resp_0_5, resp_0_10, resp_0_30, resp_all,
                    inc_day
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:{}", statRdd.count());
        deliveryCntRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        return statRdd;
    }

    public static String getAoiIds(List<ExpressDeliveryToVillagesCostModel> list) {
        List<String> list_aoi = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_id())).map(ExpressDeliveryToVillagesCostModel::getAoi_id).distinct().collect(Collectors.toList());
        return list_aoi.size() > 0 ? String.join("|", list_aoi) : "";
    }

    public static double caculate(String dist, String time, int cnt, double avg_deliver_tm) {
        double new_dist = StringUtils.isNotEmpty(dist) ? Double.parseDouble(dist) / (double) 1000 : 0;
        double new_time = StringUtils.isNotEmpty(time) ? Double.parseDouble(time) / (double) 60 : 0;
        return new_dist * X + (cnt * avg_deliver_tm + new_time) * Z;
    }


    public static Tuple3<String, String, String> getGetAoiTspUrl(String x, String y, String aoiIds) {
        String last_content = "";
        String last_dist = "";
        String last_time = "";
        if (StringUtils.isNotEmpty(aoiIds)) {
            JSONObject param = new JSONObject();
            param.put("strategy", 2);
            param.put("stype", 2);
            param.put("starts", x + "," + y);
            param.put("ends", x + "," + y);
            param.put("ak", ak);
            param.put("aoiIds", aoiIds);
            param.put("opt", "sf2");

            //因为服务不太稳定，所以调三次，取三次中dist最小的值作为结果
            for (int i = 0; i < 3; i++) {
                String content = HttpInvokeUtil.sendPost(getAoiTspUrl, param.toJSONString());
                String dist = "";
                String time = "";
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        dist = JSON.parseObject(content).getJSONObject("result").getString("dist");
                        time = JSON.parseObject(content).getJSONObject("result").getString("time");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }
                logger.error("dist:{},time:{}", dist, time);
                if (StringUtils.isEmpty(last_content)) {
                    last_content = content;
                    last_dist = dist;
                    last_time = time;
                } else {
                    if (StringUtils.isNotEmpty(dist) && StringUtils.isNotEmpty(last_dist) && Double.parseDouble(dist) < Double.parseDouble(last_dist)) {
                        last_content = content;
                        last_dist = dist;
                        last_time = time;
                    }
                }
            }
        }
        return new Tuple3<String, String, String>(last_content, last_dist, last_time);
    }

    public static Tuple2<String, String> parseResp(String content) {
        String dist = "";
        String time = "";
        if (StringUtils.isNotEmpty(content)) {
            try {
                dist = JSON.parseObject(content).getJSONObject("result").getString("dist");
                time = JSON.parseObject(content).getJSONObject("result").getString("time");
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        logger.error("dist:{},time:{}", dist, time);
        return new Tuple2<>(dist, time);
    }

    public static boolean judge(String min_distance, double start, double end, String tag) {
        double distance = 0;
        if (StringUtils.isNotEmpty(min_distance)) {
            distance = Double.parseDouble(min_distance);
        }
        if (StringUtils.isEmpty(tag)) {
            return distance >= start && distance < end;
        } else {
            return distance >= start;
        }
    }

    public static JavaRDD<ExpressDeliveryToVillagesCostModel> getSource(SparkInfo sparkInfo, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("express_delivery_to_villages_cost_model.sql", startDate, endDate);
        JavaRDD<ExpressDeliveryToVillagesCostModel> sourceRdd = DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, ExpressDeliveryToVillagesCostModel.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sourceRdd cnt:{}", sourceRdd.count());
        return sourceRdd;
    }

    public static double avg(JavaPairRDD<String, Long> aoi_cnt_rdd, JavaRDD<SaTrajectoryAoi> aoiSumIntervalTmRdd) {
        JavaPairRDD<String, Long> tm_cnt_rdd = aoi_cnt_rdd.leftOuterJoin(aoiSumIntervalTmRdd.mapToPair(o -> new Tuple2<>(o.getAoiCode(), o.getAoi_interval_tm()))).filter(tp -> {
            String aoi_code = tp._1;
            long cnt = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                String interval_tm = tp._2._2.get();
                double avg = (Double.parseDouble(interval_tm) / (double) 60) / cnt;
                return avg > 0 && avg <= 15;
            }
            return false;
        }).mapToPair(tp -> new Tuple2<>(tp._2._2.get(), tp._2._1)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tm_cnt_rdd cnt:{}", tm_cnt_rdd.count());
        aoi_cnt_rdd.unpersist();
        aoiSumIntervalTmRdd.unpersist();

        //总时长
        Double totalIntervalTm = tm_cnt_rdd.map(tp -> Double.parseDouble(tp._1)).reduce(Double::sum);
        //总件量
        long totalCnt = tm_cnt_rdd.map(tp -> tp._2).reduce(Long::sum);
        tm_cnt_rdd.unpersist();
        return (totalIntervalTm / (double) 60) / totalCnt;
    }

    public static JavaPairRDD<String, Long> getAoiCnt(SparkInfo sparkInfo, String date) {
        String sql = String.format("select aoi_code,count(*) cnt from dm_gis.village_dest_kdsm_res where inc_day = '%s' and class_code in ('210','220') and wd_type = '代理' and (aoi_code is not null and aoi_code <>'') group by aoi_code", date);
        JavaPairRDD<String, Long> aoi_cnt_rdd = sparkInfo.getSession().sql(sql).toJavaRDD().mapToPair(row -> new Tuple2<>(row.getString(0), row.getLong(1))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoi_cnt_rdd cnt:{}", aoi_cnt_rdd.count());
        return aoi_cnt_rdd;
    }

    public static JavaRDD<SaTrajectoryAoi> getPathFix(SparkInfo sparkInfo, String date) {
        String path_fix_sql = String.format("select\n" +
                "  a.*\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      un,\n" +
                "      bn,\n" +
                "      rsp\n" +
                "    from\n" +
                "      dm_gis.path_fix\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and tp = 'bike'\n" +
                "      and (\n" +
                "        rsp is not null\n" +
                "        and rsp <> ''\n" +
                "      )\n" +
                "  ) a\n" +
                "  join (\n" +
                "    select\n" +
                "      deliver_emp_code\n" +
                "    from\n" +
                "      dm_gis.village_dest_kdsm_res\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and class_code in ('210', '220')\n" +
                "      and wd_type = '代理'\n" +
                "      and (\n" +
                "        deliver_emp_code is not null\n" +
                "        and deliver_emp_code <> ''\n" +
                "      )\n" +
                "    group by\n" +
                "      deliver_emp_code\n" +
                "  ) b on a.un = b.deliver_emp_code", date, date);
        JavaRDD<PathFix> pathFixRdd = DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), path_fix_sql, PathFix.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("pathFixRdd:{}", pathFixRdd.count());

        //解析纠偏后的数据
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", getTrackAoisUrl, "", pathFixRdd.count(), 10);
        JavaRDD<SaTrajectoryAoi> pathAoiRdd = pathFixRdd.flatMap(o -> {
            ArrayList<SaTrajectoryAoi> evaList = new ArrayList<>();
            String rsp = o.getRsp();
            if (StringUtils.isNotEmpty(rsp)) {
                List<SaTrajectoryAoi> list = new ArrayList<>();
                JSONArray tracks = JSON.parseObject(rsp).getJSONArray("tracks");
                if (tracks != null && tracks.size() > 0) {
                    for (int i = 0; i < tracks.size(); i++) {
                        JSONObject jsonObject = tracks.getJSONObject(i);
                        String x = jsonObject.getString("x");
                        String y = jsonObject.getString("y");
                        String tm = jsonObject.getString("tm");
                        SaTrajectoryAoi saTrajectoryAoi = new SaTrajectoryAoi();
                        saTrajectoryAoi.setZx(x);
                        saTrajectoryAoi.setZy(y);
                        saTrajectoryAoi.setTm(tm);
                        list.add(saTrajectoryAoi);
                    }
                }

                if (list.size() > 0) {
                    //获取轨迹对应aoi信息
                    List<JSONObject> param = list.stream().filter(t -> StringUtils.isNotEmpty(t.getZx()) && StringUtils.isNotEmpty(t.getZy())).map(t -> {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("lng", t.getZx());
                        jsonObject.put("lat", t.getZy());
                        return jsonObject;
                    }).distinct().collect(Collectors.toList());

                    String content = HttpInvokeUtil.sendPost(getTrackAoisUrl, param.toString());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            JSONArray data = jsonObject.getJSONArray("data");
                            if (data != null && data.size() > 0) {
                                for (int i = 0; i < data.size(); i++) {
                                    JSONObject jsonObject1 = data.getJSONObject(i);
                                    if (jsonObject1 != null) {
                                        String aoiId = jsonObject1.getString("aoiId");
                                        String aoiCode = jsonObject1.getString("aoiCode");
                                        String lng = jsonObject1.getJSONArray("coors").getJSONObject(0).getString("lng");
                                        String lat = jsonObject1.getJSONArray("coors").getJSONObject(0).getString("lat");
                                        list = list.stream().map(t -> {
                                            if (StringUtils.equals(t.getZx(), lng) && StringUtils.equals(t.getZy(), lat)) {
                                                t.setAoi(aoiId);
                                                t.setAoiCode(aoiCode);
                                            }
                                            return t;
                                        }).collect(Collectors.toList());
                                    }
                                }
                            }
                        }
                    }
                }

                List<SaTrajectoryAoi> sortTmList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoiCode())).sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).collect(Collectors.toList());
                long starTm = 0;
                long endTm;
                long diffTm;
                for (int i = 0; i < sortTmList.size(); i++) {
                    SaTrajectoryAoi t = sortTmList.get(i);
                    String aoiCode = t.getAoiCode();
                    String tm = t.getTm();
                    if (starTm == 0 && i == 0) {
                        starTm = Long.parseLong(tm);
                    } else if (starTm == 0) {
                        starTm = (Long.parseLong(sortTmList.get(i - 1).getTm()) + Long.parseLong(tm)) / 2;
                    }

                    if (i < sortTmList.size() - 1 && !StringUtils.equals(aoiCode, sortTmList.get(i + 1).getAoiCode())) {
                        endTm = (Long.parseLong(sortTmList.get(i + 1).getTm()) + Long.parseLong(tm)) / 2;
                        diffTm = endTm - starTm;
                        t.setAoi_interval_tm(diffTm + "");
                        evaList.add(t);
                        starTm = 0;
                    } else if (i == sortTmList.size() - 1) {
                        endTm = Long.parseLong(tm);
                        diffTm = endTm - starTm;
                        t.setAoi_interval_tm(diffTm + "");
                        evaList.add(t);
                    }
                }
            }
            return evaList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("pathAoiRdd cnt:{}", pathAoiRdd.count());
        pathFixRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        //每个aoi对应的总间隔时长
        JavaRDD<SaTrajectoryAoi> sumIntervalTmRdd = pathAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoiCode(), o)).groupByKey().map(tp -> {
            List<SaTrajectoryAoi> list = Lists.newArrayList(tp._2);
            SaTrajectoryAoi t = list.get(0);
            Long sumIntervalTm = list.stream().map(o -> StringUtils.isNotEmpty(o.getAoi_interval_tm()) ? Long.parseLong(o.getAoi_interval_tm()) : 0).reduce(Long::sum).get();
            t.setAoi_interval_tm(sumIntervalTm + "");
            return t;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sumIntervalTmRdd cnt:{}", sumIntervalTmRdd.count());
        pathAoiRdd.unpersist();

        return sumIntervalTmRdd;
    }
}
