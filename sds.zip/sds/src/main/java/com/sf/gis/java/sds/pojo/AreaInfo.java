package com.sf.gis.java.sds.pojo;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class AreaInfo implements Serializable {
    /**
     *
     */
    private static final long serialVersionUID = 6403897719935230187L;
    @Column(name = "PROVINCE")
    private String province;
    @Column(name = "REGION")
    private String region;
    @Column(name = "CITY")
    private String city;
    @Column(name = "CITYCODE")
    private String citycode;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public AreaInfo(String province, String region, String city, String citycode) {
        this.province = province;
        this.region = region;
        this.city = city;
        this.citycode = citycode;
    }

    public AreaInfo() {
    }
}