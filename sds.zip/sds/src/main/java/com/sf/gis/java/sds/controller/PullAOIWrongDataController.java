package com.sf.gis.java.sds.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sf.gis.java.sds.service.PullOmsService;

import java.util.Map;

public class PullAOIWrongDataController {
    private static final Logger logger = LoggerFactory.getLogger(PullAOIWrongDataController.class);

    private PullOmsService pullOmsService;
    private Map<String, String> configMap;

    public PullAOIWrongDataController(Map<String, String> configMap) {
        pullOmsService = new PullOmsService();
        this.configMap = configMap;

    }

    public void start(int argDays) throws Exception {

        pullOmsService.pullAoiWrongData(argDays, configMap);

    }

}