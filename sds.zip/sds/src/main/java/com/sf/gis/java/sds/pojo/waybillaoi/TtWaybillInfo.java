package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class TtWaybillInfo implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "order_no")
    private String order_no;
    @Column(name = "consignee_emp_code")
    private String consignee_emp_code;
    @Column(name = "deliver_emp_code")
    private String deliver_emp_code;


    @Column(name = "source_waybill_no")
    private String source_waybill_no;

    @Column(name = "src_city_code")
    private String src_city_code;
    @Column(name = "src_county")
    private String src_county;
    @Column(name = "src_dist_code")
    private String src_dist_code;
    @Column(name = "consignor_addr")
    private String consignor_addr;
    @Column(name = "consignor_mobile")
    private String consignor_mobile;
    @Column(name = "consignor_phone")
    private String consignor_phone;
    @Column(name = "consignor_comp_name")
    private String consignor_comp_name;
    @Column(name = "freight_monthly_acct_code")
    private String freight_monthly_acct_code;

    @Column(name = "dest_city_code")
    private String dest_city_code;
    @Column(name = "dest_county")
    private String dest_county;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "consignee_mobile")
    private String consignee_mobile;
    @Column(name = "consignee_phone")
    private String consignee_phone;
    @Column(name = "consignee_comp_name")
    private String consignee_comp_name;

    public String getDest_city_code() {
        return dest_city_code;
    }

    public void setDest_city_code(String dest_city_code) {
        this.dest_city_code = dest_city_code;
    }

    public String getDest_county() {
        return dest_county;
    }

    public void setDest_county(String dest_county) {
        this.dest_county = dest_county;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getConsignee_mobile() {
        return consignee_mobile;
    }

    public void setConsignee_mobile(String consignee_mobile) {
        this.consignee_mobile = consignee_mobile;
    }

    public String getConsignee_phone() {
        return consignee_phone;
    }

    public void setConsignee_phone(String consignee_phone) {
        this.consignee_phone = consignee_phone;
    }

    public String getConsignee_comp_name() {
        return consignee_comp_name;
    }

    public void setConsignee_comp_name(String consignee_comp_name) {
        this.consignee_comp_name = consignee_comp_name;
    }

    public String getSrc_city_code() {
        return src_city_code;
    }

    public void setSrc_city_code(String src_city_code) {
        this.src_city_code = src_city_code;
    }

    public String getSrc_county() {
        return src_county;
    }

    public void setSrc_county(String src_county) {
        this.src_county = src_county;
    }

    public String getSrc_dist_code() {
        return src_dist_code;
    }

    public void setSrc_dist_code(String src_dist_code) {
        this.src_dist_code = src_dist_code;
    }

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getConsignor_mobile() {
        return consignor_mobile;
    }

    public void setConsignor_mobile(String consignor_mobile) {
        this.consignor_mobile = consignor_mobile;
    }

    public String getConsignor_phone() {
        return consignor_phone;
    }

    public void setConsignor_phone(String consignor_phone) {
        this.consignor_phone = consignor_phone;
    }

    public String getConsignor_comp_name() {
        return consignor_comp_name;
    }

    public void setConsignor_comp_name(String consignor_comp_name) {
        this.consignor_comp_name = consignor_comp_name;
    }

    public String getFreight_monthly_acct_code() {
        return freight_monthly_acct_code;
    }

    public void setFreight_monthly_acct_code(String freight_monthly_acct_code) {
        this.freight_monthly_acct_code = freight_monthly_acct_code;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getConsignee_emp_code() {
        return consignee_emp_code;
    }

    public void setConsignee_emp_code(String consignee_emp_code) {
        this.consignee_emp_code = consignee_emp_code;
    }

    public String getDeliver_emp_code() {
        return deliver_emp_code;
    }

    public void setDeliver_emp_code(String deliver_emp_code) {
        this.deliver_emp_code = deliver_emp_code;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getSource_waybill_no() {
        return source_waybill_no;
    }

    public void setSource_waybill_no(String source_waybill_no) {
        this.source_waybill_no = source_waybill_no;
    }
}
