package com.sf.gis.java.sds.pojo;

public class GisRssPnsRedirectLog {
    private String dateTime;
    private String type;
    private String sn;
    private String ak;
    private String geometryCode;
    private String address1;
    private String address2;
    private String orderNo;
    private String time;
    private String status;
    private String err;
    private String msg;
    private String q_address1;
    private String q_address2;
    private String q_province1;
    private String city1;
    private String county1;
    private String adcode1;
    private String geometryCode1;
    private String specialLevel1;
    private String province2;
    private String city2;
    private String county2;
    private String adcode2;
    private String identical;
    private String driving_distance;
    private String driving_time;
    private String walking_distance;
    private String walking_time;

    public String getDriving_distance() {
        return driving_distance;
    }

    public void setDriving_distance(String driving_distance) {
        this.driving_distance = driving_distance;
    }

    public String getDriving_time() {
        return driving_time;
    }

    public void setDriving_time(String driving_time) {
        this.driving_time = driving_time;
    }

    public String getWalking_distance() {
        return walking_distance;
    }

    public void setWalking_distance(String walking_distance) {
        this.walking_distance = walking_distance;
    }

    public String getWalking_time() {
        return walking_time;
    }

    public void setWalking_time(String walking_time) {
        this.walking_time = walking_time;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getGeometryCode() {
        return geometryCode;
    }

    public void setGeometryCode(String geometryCode) {
        this.geometryCode = geometryCode;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getQ_address1() {
        return q_address1;
    }

    public void setQ_address1(String q_address1) {
        this.q_address1 = q_address1;
    }

    public String getQ_address2() {
        return q_address2;
    }

    public void setQ_address2(String q_address2) {
        this.q_address2 = q_address2;
    }

    public String getQ_province1() {
        return q_province1;
    }

    public void setQ_province1(String q_province1) {
        this.q_province1 = q_province1;
    }

    public String getCity1() {
        return city1;
    }

    public void setCity1(String city1) {
        this.city1 = city1;
    }

    public String getCounty1() {
        return county1;
    }

    public void setCounty1(String county1) {
        this.county1 = county1;
    }

    public String getAdcode1() {
        return adcode1;
    }

    public void setAdcode1(String adcode1) {
        this.adcode1 = adcode1;
    }

    public String getGeometryCode1() {
        return geometryCode1;
    }

    public void setGeometryCode1(String geometryCode1) {
        this.geometryCode1 = geometryCode1;
    }

    public String getSpecialLevel1() {
        return specialLevel1;
    }

    public void setSpecialLevel1(String specialLevel1) {
        this.specialLevel1 = specialLevel1;
    }

    public String getProvince2() {
        return province2;
    }

    public void setProvince2(String province2) {
        this.province2 = province2;
    }

    public String getCity2() {
        return city2;
    }

    public void setCity2(String city2) {
        this.city2 = city2;
    }

    public String getCounty2() {
        return county2;
    }

    public void setCounty2(String county2) {
        this.county2 = county2;
    }

    public String getAdcode2() {
        return adcode2;
    }

    public void setAdcode2(String adcode2) {
        this.adcode2 = adcode2;
    }

    public String getIdentical() {
        return identical;
    }

    public void setIdentical(String identical) {
        this.identical = identical;
    }
}
