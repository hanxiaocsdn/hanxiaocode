package com.sf.gis.java.sds.pojo;

import com.github.davidmoten.geo.LatLong;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class CpaStat implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "deliver_address")
    private String deliverAddress;
    @Column(name = "lat")
    private String lat;
    @Column(name = "lng")
    private String lng;
    @Column(name = "count")
    private String count;
    @Column(name = "start_date")
    private String startDate;
    @Column(name = "end_date")
    private String endDate;
    @Column(name = "dest_dist_code")
    private String destDistCode;
    private List<LatLong> llList;
    private List<CpaSrc> subList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeliverAddress() {
        return deliverAddress;
    }

    public void setDeliverAddress(String deliverAddress) {
        this.deliverAddress = deliverAddress;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getDestDistCode() {
        return destDistCode;
    }

    public void setDestDistCode(String destDistCode) {
        this.destDistCode = destDistCode;
    }

    public List<LatLong> getLlList() {
        return llList;
    }

    public void setLlList(List<LatLong> llList) {
        this.llList = llList;
    }

    public List<CpaSrc> getSubList() {
        return subList;
    }

    public void setSubList(List<CpaSrc> subList) {
        this.subList = subList;
    }

    @Override
    public String toString() {
        return "CpaStat{" +
                "id='" + id + '\'' +
                ", deliverAddress='" + deliverAddress + '\'' +
                ", lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                ", count='" + count + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", destDistCode='" + destDistCode + '\'' +
                ", llList.size='" + llList.size() + '\'' +
                ", subList.size='" + subList.size() + '\'' +
                '}';
    }
}
