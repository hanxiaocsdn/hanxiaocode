package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.FvpCoreFactRouteOverRangeZj;
import com.sf.gis.java.sds.pojo.FvpCoreFactRouteOverRangeZjStat;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务：788536（超范围转寄指标监控报表）
 * 业务方：01324490（金姣）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月15日11:26:55
 */
public class AppAddrReachableOverRangeZj {
    private static Logger logger = LoggerFactory.getLogger(AppAddrReachableOverRangeZj.class);
    private static String url = "http://sisp-int-apis.int.sfcloud.local:8000/userQuery/waybillQueryService/queryWaybillInfo";
    private static String account = "01399581";
    private static String taskId = "788536";
    private static String taskName = "超范围转寄指标监控报表";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAddrReachableOverRangeZj");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String before1Date = DateUtil.getDaysBefore(date, 1);
        String before6Date = DateUtil.getDaysBefore(date, 6);
        String before30Date = DateUtil.getDaysBefore(date, 30);

        String sql = SqlUtil.getSqlStr("fvp_core_fact_route.sql", before1Date, before30Date, before1Date, before1Date);
        JavaRDD<FvpCoreFactRouteOverRangeZj> rdd = DataUtil.loadData(spark, sc, sql, FvpCoreFactRouteOverRangeZj.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, url, "", rdd.count(), 2);
        JavaRDD<FvpCoreFactRouteOverRangeZj> queryWaybillInfoRdd = rdd.repartition(2).map(o -> {
            String mainwaybillno = o.getMainwaybillno();
            if (StringUtils.isNotEmpty(mainwaybillno)) {
                JSONObject param = new JSONObject();
                JSONObject jsonObject = new JSONObject();
                JSONArray waybillNos = new JSONArray();
                waybillNos.add(mainwaybillno);
                jsonObject.put("waybillNos", waybillNos);
                jsonObject.put("sysCode", "GIS-ASS-OMS");
                jsonObject.put("contextOrder", "00001");
                param.put("obj", jsonObject);

                String content = HttpInvokeUtil.sendPostHeader(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "sysCode", "GIS-ASS-OMS", "UTF-8", "UTF-8");
                Thread.sleep(500);
                String src_sys_name = "";
                String freight_monthly_acct_code = "";
                String if_ziqu = "0";
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        src_sys_name = JSON.parseObject(content).getJSONObject("obj").getJSONObject("waybillAddition").getString("orderSysSource");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }

                    try {
                        freight_monthly_acct_code = JSON.parseObject(content).getJSONObject("obj").getJSONArray("waybillFees").getJSONObject(0).getString("customerAcctCode");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }

                    try {
                        JSONArray jsonArray = JSON.parseObject(content).getJSONObject("obj").getJSONArray("waybillAdditionOrigins");
                        for (int i = 0; i < jsonArray.size(); i++) {
                            JSONObject json = jsonArray.getJSONObject(i);
                            String additionalKey = json.getString("additionalKey");
                            String additionalValues = json.getString("additionalValues");
                            if (StringUtils.equals("LIST_ONESELF_PICK_UP_FLG", additionalKey)) {
                                if (StringUtils.equals("1", additionalValues)) {
                                    if_ziqu = additionalValues;
                                    break;
                                }
                            }
                        }
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }
                o.setSrc_sys_name(src_sys_name);
                o.setFreight_monthly_acct_code(freight_monthly_acct_code);
                o.setIf_ziqu(if_ziqu);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("queryWaybillInfoRdd cnt:{}", queryWaybillInfoRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        String contract_sql = String.format("select\n" +
                "  m.customer_code freight_monthly_acct_code\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      protocol_code\n" +
                "    from\n" +
                "      ods_cmdm.cmdm_protocol\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and protocol_type = 'A_ZZFWTK_CFWZJ'\n" +
                "      and protocol_state in ('40', '50')\n" +
                "    group by\n" +
                "      protocol_code\n" +
                "  ) t\n" +
                "  inner join (\n" +
                "    select\n" +
                "      contract_code,\n" +
                "      customer_code\n" +
                "    from\n" +
                "      ods_cmdm.cmdm_acc_relation\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "  ) r on r.contract_code = t.protocol_code\n" +
                "  inner join (\n" +
                "    select\n" +
                "      customer_code\n" +
                "    from\n" +
                "      dim.dim_customer_info_df\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and billing_status = '已生效'\n" +
                "    group by\n" +
                "      customer_code\n" +
                "  ) m on r.customer_code = m.customer_code\n" +
                "group by\n" +
                "  m.customer_code", before1Date, before1Date, before1Date);
        JavaRDD<FvpCoreFactRouteOverRangeZj> contractRdd = DataUtil.loadData(spark, sc, contract_sql, FvpCoreFactRouteOverRangeZj.class).filter(o -> StringUtils.isNotEmpty(o.getFreight_monthly_acct_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("contractRdd cnt:{}", contractRdd.count());

        JavaRDD<FvpCoreFactRouteOverRangeZj> resultRdd = queryWaybillInfoRdd.repartition(40).mapToPair(o -> new Tuple2<>(o.getFreight_monthly_acct_code(), o)).leftOuterJoin(contractRdd.mapToPair(o -> new Tuple2<>(o.getFreight_monthly_acct_code(), o))).map(tp -> {
            FvpCoreFactRouteOverRangeZj o = tp._2._1;
            String if_contract = "0";
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                if_contract = "1";
            }
            o.setIf_contract(if_contract);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        queryWaybillInfoRdd.unpersist();
        contractRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.cfwzj", FvpCoreFactRouteOverRangeZj.class, resultRdd, "inc_day");

//        String temp_sql = String.format("select * from dm_gis.cfwzj where inc_day = '%s'", "20230816");
//        JavaRDD<FvpCoreFactRouteOverRangeZj> resultRdd = DataUtil.loadData(spark, sc, temp_sql, FvpCoreFactRouteOverRangeZj.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());

        String sql_80 = String.format("select\n" +
                "  a.mainwaybillno mainwaybillno,\n" +
                "  a.zonecode zonecode,\n" +
                "  a.inc_day inc_day,\n" +
                "  b.provinct_name provinct_name,\n" +
                "  b.city_name city_name,\n" +
                "  b.city_code city_code\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      mainwaybillno,\n" +
                "      zonecode,\n" +
                "      inc_day\n" +
                "    from\n" +
                "      ods_kafka_fvp.fvp_core_fact_route\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and opcode = '80'\n" +
                "      and (\n" +
                "        mainwaybillno is not null\n" +
                "        and mainwaybillno <> ''\n" +
                "      )\n" +
                "    group by\n" +
                "      mainwaybillno,\n" +
                "      zonecode,\n" +
                "      inc_day\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      dept_code,\n" +
                "      provinct_name,\n" +
                "      city_name,\n" +
                "      dist_code city_code\n" +
                "    from\n" +
                "      dim.dim_dept_info_df\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "    group by\n" +
                "      dept_code,\n" +
                "      provinct_name,\n" +
                "      city_name,\n" +
                "      dist_code\n" +
                "  ) b on a.zonecode = b.dept_code", before1Date, before1Date);
        JavaRDD<FvpCoreFactRouteOverRangeZj> opcode_80_Rdd = DataUtil.loadData(spark, sc, sql_80, FvpCoreFactRouteOverRangeZj.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("opcode_80_Rdd cnt:{}", opcode_80_Rdd.count());

        long qg_cnt = opcode_80_Rdd.filter(o -> StringUtils.isNotEmpty(o.getMainwaybillno())).mapToPair(o -> new Tuple2<>(o.getMainwaybillno(), o)).reduceByKey((o1, o2) -> o1).count();
        logger.error("qg_cnt:{}", qg_cnt);

        JavaPairRDD<String, Integer> cntPairRdd = opcode_80_Rdd.mapToPair(o -> new Tuple2<>(o.getProvinct_name() + "_" + o.getCity_name(), o)).groupByKey().mapToPair(tp -> {
            String key = tp._1;
            List<FvpCoreFactRouteOverRangeZj> list = Lists.newArrayList(tp._2);
            int cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getMainwaybillno())).collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(FvpCoreFactRouteOverRangeZj::getMainwaybillno))), ArrayList::new)).size();
            return new Tuple2<>(key, cnt);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cntPairRdd cnt:{}", cntPairRdd.count());
        opcode_80_Rdd.unpersist();

        JavaRDD<FvpCoreFactRouteOverRangeZjStat> statRdd = resultRdd.mapToPair(o -> new Tuple2<>(o.getProvinct_name() + "_" + o.getCity_name(), o)).groupByKey().map(tp -> {
            List<FvpCoreFactRouteOverRangeZj> list = Lists.newArrayList(tp._2);
            FvpCoreFactRouteOverRangeZj o = list.get(0);

            String province_name = o.getProvinct_name();
            String city_name = o.getCity_name();
            String city_code = o.getCity_code();
            String inc_day = o.getInc_day();
            String stat_type = "CITY";
            String stat_type_content = city_name;
            String stat_date = inc_day;

            long bsp_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "BSP")).count();
            long cx_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "CCSP")).count();
            long other_cnt = list.stream().filter(t -> !StringUtils.equals(t.getSrc_sys_name(), "BSP") && !StringUtils.equals(t.getSrc_sys_name(), "CCSP")).count();


            long contract_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "BSP") && StringUtils.equals(t.getIf_contract(), "1")).count();
            long no_contract_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "BSP") && StringUtils.equals(t.getIf_contract(), "0")).count();
            long ziqu_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "CCSP") && StringUtils.equals(t.getIf_ziqu(), "1")).count();
            long no_ziqu_cnt = list.stream().filter(t -> StringUtils.equals(t.getSrc_sys_name(), "CCSP") && StringUtils.equals(t.getIf_ziqu(), "0")).count();

            FvpCoreFactRouteOverRangeZjStat last = new FvpCoreFactRouteOverRangeZjStat();
            last.setId(DigestUtils.md5Hex(stat_date + stat_type + stat_type_content));
            last.setProvince_name(province_name);
            last.setCity_name(city_name);
            last.setCity_code(city_code);
            last.setStat_type(stat_type);
            last.setStat_type_content(stat_type_content);
            last.setStat_date(stat_date);

            last.setBsp_cnt(bsp_cnt + "");
            last.setCx_cnt(cx_cnt + "");
            last.setOther_cnt(other_cnt + "");
            last.setContract_cnt(contract_cnt + "");
            last.setNo_contract_cnt(no_contract_cnt + "");
            last.setZiqu_cnt(ziqu_cnt + "");
            last.setNo_ziqu_cnt(no_ziqu_cnt + "");
            last.setInc_day(inc_day);

            return last;
        }).mapToPair(o -> new Tuple2<>(o.getProvince_name() + "_" + o.getCity_name(), o)).leftOuterJoin(cntPairRdd).map(tp -> {
            FvpCoreFactRouteOverRangeZjStat o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                int cnt = tp._2._2.get();
                o.setCnt(cnt + "");
            }
            o.setQg_cnt(qg_cnt + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:{}", statRdd.count());
        resultRdd.unpersist();
        cntPairRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.cfwzj_stat", FvpCoreFactRouteOverRangeZjStat.class, statRdd, "inc_day");
        statRdd.unpersist();

    }
}
