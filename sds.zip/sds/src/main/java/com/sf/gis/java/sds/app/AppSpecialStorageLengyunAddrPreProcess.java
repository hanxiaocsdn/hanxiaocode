package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.SpecialStorageBaseaddressLengyun;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 任务id：913554（冷运基础入仓地址数据聚合工艺_在库地址预先处理）
 * 业务方：01425216（谭雨祯）
 * 研发：01399581（匡仁衡）
 */
public class AppSpecialStorageLengyunAddrPreProcess {
    private static Logger logger = LoggerFactory.getLogger(AppSpecialStorageLengyunAddrPreProcess.class);
    private static String url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=e6a874c441cc41eda1b443d420f6632d&opt=norm";
    private static String account = "01399581";
    private static String taskId = "913554";
    private static String taskName = "冷运基础入仓地址数据聚合工艺_在库地址预先处理";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        String beforeDate = DateUtil.getDaysBefore(date, 1);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSpecialStorageLengyunAddrPreProcess");

        //1.获取源数据
        JavaRDD<SpecialStorageBaseaddressLengyun> allRdd = getData(sparkInfo, date);
        //2.过滤出存在t-2的address_id
        JavaRDD<SpecialStorageBaseaddressLengyun> filterRdd = filterData(sparkInfo, beforeDate, allRdd);
        JavaRDD<SpecialStorageBaseaddressLengyun> rdd = filterRdd.filter(o -> StringUtils.isEmpty(o.getTemp_tag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SpecialStorageBaseaddressLengyun> otherRdd = filterRdd.filter(o -> StringUtils.isNotEmpty(o.getTemp_tag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd:{},otherRdd:{}", rdd.count(), otherRdd.count());
        filterRdd.unpersist();
        //3.获取切词
        String id = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", url, "e6a874c441cc41eda1b443d420f6632d", rdd.count(), 2);
        JavaRDD<SpecialStorageBaseaddressLengyun> splitRdd = getSplit(rdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id);
        //4.切词提取
        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd = processSplit(splitRdd);
        //5.入库
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.specialstorage_baseaddress_lengyun_inprogress", SpecialStorageBaseaddressLengyun.class, resultRdd.union(otherRdd), "inc_day");
        resultRdd.unpersist();
        otherRdd.unpersist();

        sparkInfo.getContext().stop();
        logger.error("end...");
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> filterData(SparkInfo sparkInfo, String date, JavaRDD<SpecialStorageBaseaddressLengyun> allRdd) {
        String sql = String.format("select address_id from dm_gis.specialstorage_baseaddress_lengyun_inprogress where inc_day = '%s' group by address_id", date);
        JavaRDD<SpecialStorageBaseaddressLengyun> beforeRdd = DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SpecialStorageBaseaddressLengyun.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("beforeRdd cnt:{}", beforeRdd.count());

        JavaRDD<SpecialStorageBaseaddressLengyun> tempTagRdd = allRdd.mapToPair(o -> new Tuple2<>(o.getAddress_id(), o)).leftOuterJoin(beforeRdd.mapToPair(o -> new Tuple2<>(o.getAddress_id(), o))).map(tp -> {
            SpecialStorageBaseaddressLengyun o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setTemp_tag("1");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tempTagRdd cnt:{}", tempTagRdd.count());
        allRdd.unpersist();
        beforeRdd.unpersist();
        return tempTagRdd;
    }


    public static JavaRDD<SpecialStorageBaseaddressLengyun> processSplit(JavaRDD<SpecialStorageBaseaddressLengyun> splitRdd) {
        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd = splitRdd.map(AppSpecialStorageLengyunAddrPreProcess::processSplit).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        splitRdd.unpersist();
        return resultRdd;
    }


    public static SpecialStorageBaseaddressLengyun processSplit(SpecialStorageBaseaddressLengyun o) {
        //广东省^11,深圳市^12,南山区^13,软件产业基地^213,1a栋^214,21楼^216
        String splitresult_zaiku = o.getSplitresult_zaiku();

        //1.提取最后的13级(不含613)及之后的文本拼接
        StringBuilder company_zaiku = new StringBuilder();

        //2.splitresult_zaiku中是否有相连的9级和11级
        List<String> list_level = new ArrayList<>();
        String word_9_level = "";
        String word_11_level = "";
        int word_9_11_level_flag = 0;

        //3.splitresult_zaiku中是否同时有9级和13级
        List<String> word9list = new ArrayList<>();
        List<String> word13list = new ArrayList<>();

        //4.记录splitresult_zaiku中除18级以外最大的词级为maxlevel_zaiku(613不算13级)
        String maxlevel_zaiku = "0";

        //5.去掉splitresult_zaiku各词级的属性词为splitresult_zaiku_notype（属性为6的13级保存词级数为613）
        List<String> splitresult_zaiku_notype = new ArrayList<>();

        //6.去掉splitresult_zaiku_notype中重复的词级(重复词级保留位置更前的)为splitresult_zaiku_norepeat
        List<String> splitresult_zaiku_norepeat = new ArrayList<>();

        //7.取出splitresult_zaiku_norepeat中所有14级的数字和字母为all14numletter_zaiku
        List<String> all14numletter_zaiku = new ArrayList<>();

        //8.取出splitresult_zaiku_norepeat中所有15级的数字和字母为all15numletter_zaiku
        List<String> all15numletter_zaiku = new ArrayList<>();

        //9.取出splitresult_zaiku_norepeat中所有16级的数字和字母为all16numletter_zaiku
        List<String> all16numletter_zaiku = new ArrayList<>();

        //10.取出splitresult_zaiku_norepeat中所有17级的数字和字母为all17numletter_zaiku
        List<String> all17numletter_zaiku = new ArrayList<>();

        if (StringUtils.isNotEmpty(splitresult_zaiku)) {
            List<String> split = Arrays.asList(splitresult_zaiku.split(","));
            String last_13_name = "";
            String prop_level = "";

            for (int i = 0; i < split.size(); i++) {
                String s = split.get(i);
                String[] split1 = s.split("\\^");
                if (split1.length >= 2) {
                    String name = split1[0];
                    String s1 = split1[1];
                    String prop = s1.substring(0, 1);
                    String level = s1.substring(1, s1.length());

                    if (!StringUtils.equals("613", s1)) {
                        list_level.add(level);
                    }

                    if ("613".equals(prop + level)) {
                        splitresult_zaiku_notype.add(name + "^" + prop + level);
                    } else {
                        splitresult_zaiku_notype.add(name + "^" + level);
                    }

                    String temp_level = level;
                    if ("613".equals(prop + level)) {
                        temp_level = prop + level;
                    }
                    if (StringUtils.isNotEmpty(level) && !"18".equals(level) && Integer.parseInt(temp_level) >= Integer.parseInt(maxlevel_zaiku)) {
                        if ("613".equals(prop + level)) {
                            maxlevel_zaiku = prop + level;
                        } else {
                            maxlevel_zaiku = level;
                        }
                    }

                    if ("9".equals(level)) {
                        word9list.add(name);
                        if (word_9_11_level_flag == 0 && i != split.size() - 1) {
                            String s2 = split.get(i + 1);
                            String[] split2 = s2.split("\\^");
                            String name_11 = split2[0];
                            String s3 = split2[1];
                            String level_11 = s3.substring(1, s3.length());
                            if ("11".equals(level_11)) {
                                word_9_level = name;
                                word_11_level = name_11;
                                word_9_11_level_flag = 1;
                            }
                        }
                    }


                    if (!"6".equals(prop) && "13".equals(level)) {
                        word13list.add(name);
                        last_13_name = name;
                        prop_level = prop + level;
                    }
                }
            }


            if (StringUtils.isNotEmpty(last_13_name)) {
                int index = split.lastIndexOf(last_13_name + "^" + prop_level);
                for (int i = index; i < split.size(); i++) {
                    String s = split.get(i);
                    String[] split1 = s.split("\\^");
                    if (split1.length >= 2) {
                        String name = split1[0];
                        company_zaiku.append(name);
                    }
                }
            }


        }
        //提取最后的13级(不含613)及之后的文本拼接
        o.setCompany_zaiku(company_zaiku.toString());

        //取出splitresult_zaiku中第一个9+11的文本命名为word911_zaiku(9和11相接，11级只取出字母和数字)
        String sb_level = list_level.size() > 0 ? String.join("#", list_level) : "";
        if (StringUtils.isNotEmpty(sb_level) && sb_level.contains("9#11")) {
            //o.setWord911_zaiku(word_9_level + AddrUtil.getMatch(word_11_level, "[a-z0-9A-Z]+"));
        } else {
            if (StringUtils.isNotEmpty(sb_level) && sb_level.contains("9") && sb_level.contains("13")) {
                //取出splitresult_zaiku中所有9级的文本命名为word9list_zaiku；取出splitresult_zaiku中所有13级的文本命名为word13list_zaiku
                o.setWord9list_zaiku(word9list.size() > 0 ? String.join("|", word9list) : "");
                o.setWord13list_zaiku(word13list.size() > 0 ? String.join("|", word13list) : "");
            }
        }

        //记录splitresult_zaiku中除18级以外最大的词级为maxlevel_zaiku(613不算13级)
        o.setMaxlevel_zaiku(maxlevel_zaiku);

        if (splitresult_zaiku_notype.size() > 0) {
            //splitresult_zaiku各词级的属性词为splitresult_zaiku_notype（属性为6的13级保存词级数为613）
            o.setSplitresult_zaiku_notype(String.join(",", splitresult_zaiku_notype));
            for (String s : splitresult_zaiku_notype) {
                if (!splitresult_zaiku_norepeat.contains(s)) {
                    splitresult_zaiku_norepeat.add(s);
                }
            }
            if (splitresult_zaiku_norepeat.size() > 0) {
                //去掉splitresult_zaiku_notype中重复的词级(重复词级保留位置更前的)为splitresult_zaiku_norepeat
                o.setSplitresult_zaiku_norepeat(String.join(",", splitresult_zaiku_norepeat));
                //取出splitresult_zaiku_norepeat中所有14级的数字和字母为all14numletter_zaiku
                for (String s : splitresult_zaiku_norepeat) {
                    String[] split = s.split("\\^");
                    String name = split[0];
                    String level = split[1];

                    if ("14".equals(level)) {
                        all14numletter_zaiku.add(AddrUtil.getMatch(name, "[a-z0-9A-Z]+"));
                    }

                    if ("15".equals(level)) {
                        all15numletter_zaiku.add(AddrUtil.getMatch(name, "[a-z0-9A-Z]+"));
                    }

                    if ("16".equals(level)) {
                        all16numletter_zaiku.add(AddrUtil.getMatch(name, "[a-z0-9A-Z]+"));
                    }

                    if ("17".equals(level)) {
                        all17numletter_zaiku.add(AddrUtil.getMatch(name, "[a-z0-9A-Z]+"));
                    }
                }

                o.setAll14numletter_zaiku(all14numletter_zaiku.size() > 0 ? String.join("|", all14numletter_zaiku) : "");
                o.setAll15numletter_zaiku(all15numletter_zaiku.size() > 0 ? String.join("|", all15numletter_zaiku) : "");
                o.setAll16numletter_zaiku(all16numletter_zaiku.size() > 0 ? String.join("|", all16numletter_zaiku) : "");
                o.setAll17numletter_zaiku(all17numletter_zaiku.size() > 0 ? String.join("|", all17numletter_zaiku) : "");

            }
        }

        return o;
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> getSplit(JavaRDD<SpecialStorageBaseaddressLengyun> rdd) {
        JavaRDD<SpecialStorageBaseaddressLengyun> splitRdd = rdd.map(o -> {
            String norm_address = o.getNorm_address();
            if (StringUtils.isEmpty(norm_address)) {
                norm_address = o.getAddress();
            }
            if (StringUtils.isNotEmpty(norm_address)) {
                String citycode = o.getCitycode();
                String req = String.format(url, URLEncoder.encode(norm_address, "UTF-8"), citycode);
                String content = HttpInvokeUtil.sendGet(req);
                String splitresult_zaiku = "";
                try {
                    String splitResult = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                    splitresult_zaiku = splitResult.split(";")[0];
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setSplitresult_zaiku(splitresult_zaiku);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitRdd cnt:{}", splitRdd.count());
        rdd.unpersist();
        return splitRdd;
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> getData(SparkInfo sparkInfo, String date) {
        String sql = String.format("select\n" +
                "  address_id,\n" +
                "  adcode,\n" +
                "  area_code,\n" +
                "  province,\n" +
                "  city,\n" +
                "  citycode,\n" +
                "  county,\n" +
                "  address,\n" +
                "  norm_address,\n" +
                "  company,\n" +
                "  termresult,\n" +
                "  cast(addresstype as string) addresstype,\n" +
                "  warehousename,\n" +
                "  warehousetype,\n" +
                "  warehouseid,\n" +
                "  tag,\n" +
                "  exceptional,\n" +
                "  regex,\n" +
                "  create_user,\n" +
                "  create_time,\n" +
                "  update_user,\n" +
                "  update_time,\n" +
                "  cast(del_flag as string) del_flag,\n" +
                "  company_name,\n" +
                "  tag_fuzzy,\n" +
                "  inc_day\n" +
                "from\n" +
                "  dm_gis.specialstorage_baseaddress_lengyun\n" +
                "where inc_day = '%s' and del_flag = 0", date);
        JavaRDD<SpecialStorageBaseaddressLengyun> allRdd = DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SpecialStorageBaseaddressLengyun.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("allRdd cnt:{}", allRdd.count());
        return allRdd;
    }
}
