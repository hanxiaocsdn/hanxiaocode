package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class RdsOmsfromAoi implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "address")
    private String address;
    @Column(name = "county")
    private String county;

    @Column(name = "orderno")
    private String orderno;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "aoicode")
    private String aoicode;

    @Column(name = "customeraccount")
    private String customeraccount;
    @Column(name = "mobile")
    private String mobile;
    @Column(name = "phone")
    private String phone;
    @Column(name = "company")
    private String company;
    @Column(name = "isnotundercall")
    private String isnotundercall;

    private String aoiid;

    public String getCustomeraccount() {
        return customeraccount;
    }

    public void setCustomeraccount(String customeraccount) {
        this.customeraccount = customeraccount;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getIsnotundercall() {
        return isnotundercall;
    }

    public void setIsnotundercall(String isnotundercall) {
        this.isnotundercall = isnotundercall;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getAoicode() {
        return aoicode;
    }

    public void setAoicode(String aoicode) {
        this.aoicode = aoicode;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }
}
