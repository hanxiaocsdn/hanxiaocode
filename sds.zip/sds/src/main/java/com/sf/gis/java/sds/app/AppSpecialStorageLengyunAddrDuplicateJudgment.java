package com.sf.gis.java.sds.app;

import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.SpecialStorageBaseaddressLengyun;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务id：914400（冷运基础入仓地址数据聚合工艺_（地址重复判断） &&（地址聚合））
 * 业务方：01425216（谭雨祯）
 * 研发：01399581(匡仁衡)
 */
public class AppSpecialStorageLengyunAddrDuplicateJudgment {
    private static Logger logger = LoggerFactory.getLogger(AppSpecialStorageLengyunAddrDuplicateJudgment.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSpecialStorageLengyunAddrDuplicateJudgment");

        //1.获取预处理数据
        JavaRDD<SpecialStorageBaseaddressLengyun> rdd = getPreProcessData(sparkInfo, date);
        //2.打标签,地址重复判断
        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd1 = groupStat(rdd);
        //3.入库
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.specialstorage_baseaddress_lengyun_judge_repeat", SpecialStorageBaseaddressLengyun.class, resultRdd1, "inc_day");
        resultRdd1.unpersist();
        //4.地址聚合
        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd2 = addrGroup(sparkInfo, resultRdd1);
        //5.入库
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.specialstorage_baseaddress_lengyun_reform", SpecialStorageBaseaddressLengyun.class, resultRdd2, "inc_day");
        resultRdd2.unpersist();

        sparkInfo.getContext().stop();
        logger.error("end...");
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> addrGroup(SparkInfo sparkInfo, JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd1) {
        JavaRDD<SpecialStorageBaseaddressLengyun> empRdd = resultRdd1.filter(o -> StringUtils.isEmpty(o.getSplitresult_zaiku_norepeat())).map(o -> {
            o.setReform_address(o.getNorm_address());
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SpecialStorageBaseaddressLengyun> noEmpRdd = resultRdd1.filter(o -> StringUtils.isNotEmpty(o.getSplitresult_zaiku_norepeat())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpRdd cnt:{}, empRdd cnt:{}", noEmpRdd.count(), empRdd.count());
        resultRdd1.unpersist();
        Map<String, String> temp_map = noEmpRdd.mapToPair(o -> new Tuple2<>(o.getAddress_id(), o.getSplitresult_zaiku_norepeat())).collectAsMap();
        HashMap<String, String> map = new HashMap<>(temp_map);
        logger.error("map size:{}", map.size());
        Broadcast<Map<String, String>> mapBc = sparkInfo.getContext().broadcast(map);

        //生成 splitresult_zaiku_norepeat_no18
        JavaRDD<SpecialStorageBaseaddressLengyun> splitresultZaikuNorepeatNo18Rdd = noEmpRdd.map(o -> {
            String splitresult_zaiku_norepeat = o.getSplitresult_zaiku_norepeat();
            String splitresultZaikuNorepeatNo18 = getSplitresultZaikuNorepeatNo18(splitresult_zaiku_norepeat);
            o.setSplitresult_zaiku_norepeat_no18(splitresultZaikuNorepeatNo18);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitresultZaikuNorepeatNo18Rdd cnt:{}", splitresultZaikuNorepeatNo18Rdd.count());
        noEmpRdd.unpersist();

        JavaRDD<SpecialStorageBaseaddressLengyun> eqUndecidedRdd = splitresultZaikuNorepeatNo18Rdd.filter(o -> StringUtils.equals(o.getJudge_result(), "undecided"));
        JavaRDD<SpecialStorageBaseaddressLengyun> noEqUndecidedRdd = splitresultZaikuNorepeatNo18Rdd.filter(o -> !StringUtils.equals(o.getJudge_result(), "undecided"));
        logger.error("eqUndecidedRdd cnt:{}, noEqUndecidedRdd cnt:{}", eqUndecidedRdd.count(), noEqUndecidedRdd.count());
        splitresultZaikuNorepeatNo18Rdd.unpersist();

        JavaRDD<SpecialStorageBaseaddressLengyun> eqUndecidedResult = processEqUndecidedRdd(eqUndecidedRdd);
        JavaRDD<SpecialStorageBaseaddressLengyun> noEqUndecidedResultRdd = processNoEqUndecidedRdd(noEqUndecidedRdd, mapBc);

        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd2 = empRdd.union(eqUndecidedResult).union(noEqUndecidedResultRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd2 cnt:{}", resultRdd2.count());
        empRdd.unpersist();
        eqUndecidedResult.unpersist();
        noEqUndecidedResultRdd.unpersist();
        return resultRdd2;
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> processNoEqUndecidedRdd(JavaRDD<SpecialStorageBaseaddressLengyun> noEqUndecidedRdd, Broadcast<Map<String, String>> mapBc) {
        JavaRDD<SpecialStorageBaseaddressLengyun> noEqUndecidedResultRdd = noEqUndecidedRdd.map(o -> {
            //得到judget_set3_911/judge_set3_913中所有address_id各自对应的splitresult_zaiku_norepeat里最高频的1-3级，将文本进行按1,2,3级的顺序拼接后得到xzqh
            Map<String, String> map = mapBc.value();
            String judget_set3 = "";
            if (StringUtils.isNotEmpty(o.getJudge_set3_911())) {
                judget_set3 = o.getJudge_set3_911();
            } else {
                judget_set3 = o.getJudge_set3_913();
            }
            String[] split = judget_set3.split("\\|");
            List<String> level_1_name = new ArrayList<>();
            List<String> level_2_name = new ArrayList<>();
            List<String> level_3_name = new ArrayList<>();

            List<String> splitresult_zaiku_norepeat_list = new ArrayList<>();
            LinkedHashSet<String> level_13_name_level_set = new LinkedHashSet<>();
            for (String address_id : split) {
                String splitresult_zaiku_norepeat = map.get(address_id);
                //辽宁省^1,沈阳市^2,沈北新区^3,蒲河路^9,169^11,海吉星物流园^13,2期^613,京东冷链库房^13,进院右拐^18,京东^18
                if (StringUtils.isNotEmpty(splitresult_zaiku_norepeat)) {
                    splitresult_zaiku_norepeat_list.add(splitresult_zaiku_norepeat);
                    String[] split1 = splitresult_zaiku_norepeat.split(",");
                    for (String s : split1) {
                        String[] split2 = s.split("\\^");
                        String name = split2[0];
                        String level = split2[1];
                        if ("1".equals(level)) {
                            level_1_name.add(name);
                        }
                        if ("2".equals(level)) {
                            level_2_name.add(name);
                        }
                        if ("3".equals(level)) {
                            level_3_name.add(name);
                        }
                        if ("13".equals(level)) {
                            level_13_name_level_set.add(name + "^" + level);
                        }
                    }
                }
            }
            String max_1_name = "";
            String max_2_name = "";
            String max_3_name = "";
            if (level_1_name.size() > 0) {
                max_1_name = getMaxName(level_1_name).get(0);
            }
            if (level_2_name.size() > 0) {
                max_2_name = getMaxName(level_2_name).get(0);
            }
            if (level_3_name.size() > 0) {
                max_3_name = getMaxName(level_3_name).get(0);
            }
            String xzqh = max_1_name + max_2_name + max_3_name;
            o.setXzqh(xzqh);

            //得到judget_set3_911/judge_set3_913中所有address_id各自对应的splitresult_zaiku_norepeat里所有一致的13级文本按顺序拼接，命名为allsame13；第一个一致的13级文本命名为firstsame13
            StringBuilder allsame13_sb = new StringBuilder();
            String firstsame13 = "";
            int firstsame13_flag = 0;
            int total_size = splitresult_zaiku_norepeat_list.size();
            for (String name_level : level_13_name_level_set) {
                int contains_13_size = (int) splitresult_zaiku_norepeat_list.stream().filter(t -> t.contains(name_level)).count();
                if (total_size == contains_13_size) {
                    String name = name_level.split("\\^")[0];
                    allsame13_sb.append(name);
                    if (firstsame13_flag == 0) {
                        firstsame13 = name;
                        firstsame13_flag = 1;
                    }
                }
            }
            o.setAllsame13(allsame13_sb.toString());
            o.setFirstsame13(firstsame13);

            String judge_result = o.getJudge_result();
            if (StringUtils.equals("repeat_913", judge_result)) {
                //得到reform_address：拼接xzqh+splitresult_zaiku_norepeat_no18中非1-3级的所有词级文本
                StringBuilder sb = new StringBuilder();
                String splitresult_zaiku_norepeat_no18 = o.getSplitresult_zaiku_norepeat_no18();
                String[] split1 = splitresult_zaiku_norepeat_no18.split(",");
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    String name = split2[0];
                    String level = split2[1];
                    if (!"1".equals(level) && !"2".equals(level) && !"3".equals(level)) {
                        sb.append(name);
                    }
                }
                o.setReform_address(xzqh + sb.toString());
            } else {
                String splitresult_zaiku_norepeat = o.getSplitresult_zaiku_norepeat();
                if (splitresult_zaiku_norepeat.contains("^14") || splitresult_zaiku_norepeat.contains("^15") || splitresult_zaiku_norepeat.contains("^16") || splitresult_zaiku_norepeat.contains("^17")) {
                    //得到reform_address：拼接xzqh+word911_zaiku+ '号'+firstsame13+相应的14-17级词级文本+company_name
                    String[] split1 = splitresult_zaiku_norepeat.split(",");
                    StringBuilder sb = new StringBuilder();
                    for (String s : split1) {
                        String[] split2 = s.split("\\^");
                        String name = split2[0];
                        String level = split2[1];
                        if ("14".equals(level) || "15".equals(level) || "16".equals(level) || "17".equals(level)) {
                            sb.append(name);
                        }
                    }
                    o.setReform_address(xzqh + o.getWord911_zaiku() + "号" + firstsame13 + sb.toString() + o.getCompany_name());
                } else {
                    if (StringUtils.isEmpty(allsame13_sb.toString())) {
                        //得到reform_address：拼接xzqh+word911_zaiku+ '号'+company_name
                        o.setReform_address(xzqh + o.getWord911_zaiku() + "号" + o.getCompany_name());
                    } else {
                        //得到reform_address：拼接xzqh+word911_zaiku+ '号'+allsame13
                        o.setReform_address(xzqh + o.getWord911_zaiku() + "号" + allsame13_sb.toString());
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEqUndecidedResultRdd cnt:{}", noEqUndecidedResultRdd.count());
        noEqUndecidedRdd.unpersist();
        return noEqUndecidedResultRdd;
    }

    public static List<String> getMaxName(List<String> collect) {
        Map<String, Integer> map = new HashMap<>();
        for (String name : collect) {
            map.put(name, map.getOrDefault(name, 0) + 1);
        }
        List<Integer> frequency = new ArrayList<>();
        map.forEach((k, v) -> {
            frequency.add(v);
        });
        Collections.sort(frequency);
        int maxFrequency = frequency.get(frequency.size() - 1);
        List<String> result = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == maxFrequency) {
                result.add(entry.getKey());
            }
        }
        return result;
    }


    public static JavaRDD<SpecialStorageBaseaddressLengyun> processEqUndecidedRdd(JavaRDD<SpecialStorageBaseaddressLengyun> eqUndecidedRdd) {
        JavaRDD<SpecialStorageBaseaddressLengyun> eqUndecidedResult = eqUndecidedRdd.map(o -> {
            //辽宁省^1,沈阳市^2,沈北新区^3,蒲河路^9,169^11,海吉星物流园^13,2期^613,京东冷链库房^13,进院右拐^18,京东^18
            //1.取出splitresult_zaiku_norepeat中第一个1级、2级、3级的文本依次拼接得到xzqh_undecided
            String splitresult_zaiku_norepeat = o.getSplitresult_zaiku_norepeat();
            String[] split = splitresult_zaiku_norepeat.split(",");
            String name_1 = "";
            int flag_1 = 0;
            String name_2 = "";
            int flag_2 = 0;
            String name_3 = "";
            int flag_3 = 0;
            for (String s : split) {
                String[] split1 = s.split("\\^");
                String name = split1[0];
                String level = split1[1];
                if ("1".equals(level) && flag_1 == 0) {
                    name_1 = name;
                    flag_1 = 1;
                }

                if ("2".equals(level) && flag_2 == 0) {
                    name_2 = name;
                    flag_2 = 1;
                }

                if ("3".equals(level) && flag_3 == 0) {
                    name_3 = name;
                    flag_3 = 1;
                }
            }
            String xzqh_undecided = name_1 + name_2 + name_3;
            o.setXzqh_undecided(xzqh_undecided);

            //2.splitresult_zaiku_norepeat_no18含有9+10+11+12/9+10+11/9+11+12/9+11?(各词级相接)
            //辽宁省^1,沈阳市^2,沈北新区^3,蒲河路^9,169^11,海吉星物流园^13,2期^613,京东冷链库房^13,进院右拐^18,京东^18
            String splitresult_zaiku_norepeat_no18 = o.getSplitresult_zaiku_norepeat_no18();
            String[] no18_split = splitresult_zaiku_norepeat_no18.split(",");
            StringBuilder sb = new StringBuilder();
            StringBuilder largerthan12_name = new StringBuilder();
            List<String> level_list = new ArrayList<>();

            for (String s : no18_split) {
                String[] split1 = s.split("\\^");
                String name = split1[0];
                String level = split1[1];
                level_list.add(level);
                if (!"1".equals(level) && !"2".equals(level) && !"3".equals(level)) {
                    sb.append(name);
                }

                if (Integer.parseInt(level) > 12) {
                    largerthan12_name.append(name);
                }
            }

            String all_level = level_list.size() > 0 ? String.join("#", level_list) : "";
            if (all_level.contains("9#10#11#12") || all_level.contains("9#10#11") || all_level.contains("9#11#12") || all_level.contains("9#11")) {
                //取出splitresult_zaiku_norepeat_no18中第一个9+10+11+12/9+10+11/9+11+12/9+11的文本依次拼接得到word9101112_undecided
                if (all_level.contains("9#10#11#12")) {
                    for (int i = 0; i < no18_split.length; i++) {
                        String[] split9 = no18_split[i].split("\\^");
                        String name9 = split9[0];
                        String level9 = split9[1];
                        if ("9".equals(level9)) {
                            String[] split10 = no18_split[i + 1].split("\\^");
                            String name10 = split10[0];
                            String level10 = split10[1];
                            String[] split11 = no18_split[i + 2].split("\\^");
                            String name11 = split11[0];
                            String level11 = split11[1];
                            String[] split12 = no18_split[i + 3].split("\\^");
                            String name12 = split12[0];
                            String level12 = split12[1];
                            if ("10".equals(level10) && "11".equals(level11) && "12".equals(level12)) {
                                o.setWord9101112_undecided(name9 + name10 + name11 + name12);
                                break;
                            }
                        }
                    }
                } else if (all_level.contains("9#10#11")) {
                    for (int i = 0; i < no18_split.length; i++) {
                        String[] split9 = no18_split[i].split("\\^");
                        String name9 = split9[0];
                        String level9 = split9[1];
                        if ("9".equals(level9)) {
                            String[] split10 = no18_split[i + 1].split("\\^");
                            String name10 = split10[0];
                            String level10 = split10[1];
                            String[] split11 = no18_split[i + 2].split("\\^");
                            String name11 = split11[0];
                            String level11 = split11[1];
                            if ("10".equals(level10) && "11".equals(level11)) {
                                o.setWord9101112_undecided(name9 + name10 + name11);
                                break;
                            }
                        }
                    }
                } else if (all_level.contains("9#11#12")) {
                    for (int i = 0; i < no18_split.length; i++) {
                        String[] split9 = no18_split[i].split("\\^");
                        String name9 = split9[0];
                        String level9 = split9[1];
                        if ("9".equals(level9)) {
                            String[] split11 = no18_split[i + 1].split("\\^");
                            String name11 = split11[0];
                            String level11 = split11[1];
                            String[] split12 = no18_split[i + 2].split("\\^");
                            String name12 = split12[0];
                            String level12 = split12[1];
                            if ("11".equals(level11) && "12".equals(level12)) {
                                o.setWord9101112_undecided(name9 + name11 + name12);
                                break;
                            }
                        }
                    }
                } else if (all_level.contains("9#11")) {
                    for (int i = 0; i < no18_split.length; i++) {
                        String[] split9 = no18_split[i].split("\\^");
                        String name9 = split9[0];
                        String level9 = split9[1];
                        if ("9".equals(level9)) {
                            String[] split11 = no18_split[i + 1].split("\\^");
                            String name11 = split11[0];
                            String level11 = split11[1];
                            if ("11".equals(level11)) {
                                o.setWord9101112_undecided(name9 + name11);
                                break;
                            }

                        }
                    }
                }

                //取出splitresult_zaiku_norepeat_no18中所有大于12级的词级文本依次拼接得到wordlargerthan12_undecided
//                if (level_list.contains("13") && level_list.contains("613")) {
//                    List<String> largerthan12_level_list = new ArrayList<>();
//                    List<String> largerthan12_name_list = new ArrayList<>();
//                    List<String> name_613_list = new ArrayList<>();
//                    for (String s : no18_split) {
//                        String[] split1 = s.split("\\^");
//                        String name = split1[0];
//                        String level = split1[1];
//
//                        if (Integer.parseInt(level) > 12 && !"613".equals(level)) {
//                            largerthan12_level_list.add(level);
//                            largerthan12_name_list.add(name);
//                        }
//
//                        if ("613".equals(level)) {
//                            name_613_list.add(name);
//                        }
//                    }
//                    int index = largerthan12_level_list.lastIndexOf("13");
//                    largerthan12_name_list.addAll(index, name_613_list);
//
//                    o.setWordlargerthan12_undecided(String.join("", largerthan12_name_list));
//                } else {
//                    o.setWordlargerthan12_undecided(largerthan12_name.toString());
//                }
                o.setWordlargerthan12_undecided(largerthan12_name.toString());
                //得到reform_address：拼接xzqh_undecided+word9101112_undecided+wordlargerthan12_undecided
                o.setReform_address(xzqh_undecided + o.getWord9101112_undecided() + o.getWordlargerthan12_undecided());
            } else {
                o.setReform_address(xzqh_undecided + sb.toString());
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqUndecidedResult cnt:{}", eqUndecidedResult.count());
        eqUndecidedRdd.unpersist();
        return eqUndecidedResult;
    }

    public static String getSplitresultZaikuNorepeatNo18(String splitresult_zaiku_norepeat) {
        //辽宁省^1,沈阳市^2,沈北新区^3,蒲河路^9,169^11,海吉星物流园^13,2期^613,京东冷链库房^13,进院右拐^18,京东^18
        //删去splitresult_zaiku_norepeat中满足左侧条件1或条件2的18级，得到splitresult_zaiku_norepeat_no18
        //条件1：18级连续出现(即前面或后面接着另一个18级)且18级文本不含任一大客户渠道来源/'交叉'/'交汇'
        //条件2：18级的文本长度>2且18级文本不含任一大客户渠道来源/'交叉'/'交汇'
        List<String> list = new ArrayList<>();
        String[] split = splitresult_zaiku_norepeat.split(",");
        for (int i = 0; i < split.length; i++) {
            String s = split[i];
            String[] split1 = s.split("\\^");
            String name = split1[0];
            String level = split1[1];
            if ("18".equals(level)) {
                boolean flag1 = false;
                boolean flag2 = false;

                if (i != 0) {
                    String[] split2 = split[i - 1].split("\\^");
                    String before_level = split2[1];
                    if ("18".equals(before_level)) {
                        flag1 = true;
                    }
                }

                if (i != split.length - 1) {
                    String[] split2 = split[i + 1].split("\\^");
                    String after_level = split2[1];
                    if ("18".equals(after_level)) {
                        flag2 = true;
                    }
                }

                if (flag1 || flag2) {
                    //18级连续出现 盒马,京东,山姆,沃尔玛,美团,叮咚,朴朴,交叉,交汇
                    if (name.contains("盒马") || name.contains("京东") || name.contains("山姆") || name.contains("沃尔玛") || name.contains("美团") || name.contains("叮咚") || name.contains("朴朴") || name.contains("交叉") || name.contains("交汇")) {
                        list.add(name + "^" + level);
                    }
                } else {
                    //不是连续出现18级
                    if (name.length() > 2 && (!name.contains("盒马") && !name.contains("京东") && !name.contains("山姆") && !name.contains("沃尔玛") && !name.contains("美团") && !name.contains("叮咚") && !name.contains("朴朴") && !name.contains("交叉") && !name.contains("交汇"))) {

                    } else {
                        list.add(name + "^" + level);
                    }
                }

            } else {
                list.add(name + "^" + level);
            }

        }
        return list.size() > 0 ? String.join(",", list) : "";
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> groupStat(JavaRDD<SpecialStorageBaseaddressLengyun> rdd) {
        JavaRDD<SpecialStorageBaseaddressLengyun> resultRdd1 = rdd.mapToPair(o -> new Tuple2<>(o.getCitycode() + "_" + o.getCompany_zaiku() + "_" + o.getMaxlevel_zaiku(), o)).groupByKey().flatMap(tp -> {
            ArrayList<SpecialStorageBaseaddressLengyun> list = Lists.newArrayList(tp._2);
            List<String> address_id_list = list.stream().map(SpecialStorageBaseaddressLengyun::getAddress_id).distinct().collect(Collectors.toList());
            String judge_subset1 = address_id_list.size() > 0 ? String.join("|", address_id_list) : "";
            List<SpecialStorageBaseaddressLengyun> judge_subset_list = list.stream().peek(o -> o.setJudge_subset1(judge_subset1)).collect(Collectors.toList());
            //judge_subset1是否长度小于2
            if (address_id_list.size() < 2) {
                //打标签 undecided
                return judge_subset_list.stream().peek(o -> o.setJudge_result("undecided")).iterator();
            }

            //judge_set1一致的数据中，是否有word911_zaiku一致的数据
            List<SpecialStorageBaseaddressLengyun> noEmpWord911ZaikuList = judge_subset_list.stream().filter(o -> StringUtils.isNotEmpty(o.getWord911_zaiku())).collect(Collectors.toList());
            int noEmpWord911ZaiKuSize = noEmpWord911ZaikuList.size();
            int distinctSize = (int) noEmpWord911ZaikuList.stream().map(SpecialStorageBaseaddressLengyun::getWord911_zaiku).distinct().count();
            //judge_set1一致的数据中，没有word911_zaiku一致的数据(word911_zaiku不为空)
            boolean flag = false;
            if (distinctSize == noEmpWord911ZaiKuSize) {
                for (SpecialStorageBaseaddressLengyun o : judge_subset_list) {
                    Set<String> judge_set2_913_set = new HashSet<>();
                    String address_id1 = o.getAddress_id();
                    String word9list_zaiku1 = o.getWord9list_zaiku();
                    String word13list_zaiku1 = o.getWord13list_zaiku();
                    List<SpecialStorageBaseaddressLengyun> otherList = judge_subset_list.stream().filter(t -> !StringUtils.equals(t.getAddress_id(), address_id1)).collect(Collectors.toList());
                    if (otherList.size() > 0) {
                        for (SpecialStorageBaseaddressLengyun o1 : otherList) {
                            String address_id2 = o1.getAddress_id();
                            String word9list_zaiku2 = o1.getWord9list_zaiku();
                            String word13list_zaiku2 = o1.getWord13list_zaiku();
                            //同组内，如果有word9list_zaiku中任一9级文本一致且word13list_zaiku中任一13级文本一致的数据
                            if (judgeList(word9list_zaiku1, word9list_zaiku2, "") && judgeList(word13list_zaiku1, word13list_zaiku2, "")) {
                                flag = true;
                                judge_set2_913_set.add(address_id1);
                                judge_set2_913_set.add(address_id2);
                            }
                        }
                    }
                    if (judge_set2_913_set.size() > 0) {
                        //同组数据中，将word9list_zaiku中任一9级文本一致且word13list_zaiku中任一13级文本一致的数据address_id集合存为为judge_set2_913(没有的，字段为空)
                        o.setJudge_set2_913(String.join("|", judge_set2_913_set.stream().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList())));
                    }
                }
                //同组内，flag仍为false的话，说明没有word9list_zaiku中任一9级文本一致且word13list_zaiku中任一13级文本一致的数据
                if (!flag) {
                    return judge_subset_list.stream().peek(o -> o.setJudge_result("undecided")).iterator();
                }
            }

            if (distinctSize < noEmpWord911ZaiKuSize) {
                //同组数据中，将word911_zaiku一致数据的address_id集合存为为judge_set2_911(没有的，字段为空)
                judge_subset_list = judge_subset_list.stream().peek(o -> {
                    String address_id = o.getAddress_id();
                    String word911_zaiku = o.getWord911_zaiku();
                    List<String> other_eq_word911_zaiku_list = noEmpWord911ZaikuList.stream().filter(t -> !StringUtils.equals(t.getAddress_id(), address_id) && StringUtils.equals(t.getWord911_zaiku(), word911_zaiku)).map(SpecialStorageBaseaddressLengyun::getAddress_id).collect(Collectors.toList());
                    if (other_eq_word911_zaiku_list.size() > 0) {
                        List<String> judge_set2_911_list = new ArrayList<>();
                        judge_set2_911_list.add(address_id);
                        judge_set2_911_list.addAll(other_eq_word911_zaiku_list);
                        o.setJudge_set2_911(String.join("|", judge_set2_911_list.stream().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList())));
                    }
                }).collect(Collectors.toList());
            }

            //judge_set2_911为空且judge_set2_913为空
            List<SpecialStorageBaseaddressLengyun> empList = judge_subset_list.stream().filter(o -> StringUtils.isEmpty(o.getJudge_set2_911()) && StringUtils.isEmpty(o.getJudge_set2_913())).collect(Collectors.toList());
            List<SpecialStorageBaseaddressLengyun> noEmpList = judge_subset_list.stream().filter(o -> !(StringUtils.isEmpty(o.getJudge_set2_911()) && StringUtils.isEmpty(o.getJudge_set2_913()))).collect(Collectors.toList());
            empList = empList.stream().peek(t -> t.setJudge_result("undecided")).collect(Collectors.toList());

            long judge_set2_911_cnt = noEmpList.stream().filter(o -> StringUtils.isNotEmpty(o.getJudge_set2_911())).count();
            long judge_set2_913_cnt = noEmpList.stream().filter(o -> StringUtils.isNotEmpty(o.getJudge_set2_913())).count();

            if (judge_set2_911_cnt > 0) {
                noEmpList = judgeSet3(noEmpList, "911");
            }

            if (judge_set2_913_cnt > 0) {
                noEmpList = judgeSet3(noEmpList, "913");
            }
            List<SpecialStorageBaseaddressLengyun> result_list = new ArrayList<>();
            result_list.addAll(empList);
            result_list.addAll(noEmpList);

            return result_list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd1 cnt:{}", resultRdd1.count());
        rdd.unpersist();
        return resultRdd1;
    }

    public static List<SpecialStorageBaseaddressLengyun> judgeSet3(List<SpecialStorageBaseaddressLengyun> judge_subset_list, String tag) {
        boolean flag = false;
        for (SpecialStorageBaseaddressLengyun o1 : judge_subset_list) {
            Set<String> judge_set3_set = new HashSet<>();
            String address_id1 = o1.getAddress_id();
            String compare_field1 = "";
            if ("911".equals(tag)) {
                compare_field1 = o1.getJudge_set2_911();
            } else if ("913".equals(tag)) {
                compare_field1 = o1.getJudge_set2_913();
            }
            String all14numletter_zaiku1 = o1.getAll14numletter_zaiku();
            String all15numletter_zaiku1 = o1.getAll15numletter_zaiku();
            String all16numletter_zaiku1 = o1.getAll16numletter_zaiku();
            String all17numletter_zaiku1 = o1.getAll17numletter_zaiku();
            String finalCompare_field = compare_field1;
            List<SpecialStorageBaseaddressLengyun> otherList = judge_subset_list.stream().filter(t -> {
                boolean flag1 = !StringUtils.equals(t.getAddress_id(), address_id1);
                String compare_field2 = "";
                if ("911".equals(tag)) {
                    compare_field2 = t.getJudge_set2_911();
                } else if ("913".equals(tag)) {
                    compare_field2 = t.getJudge_set2_913();
                }
                boolean flag2 = StringUtils.equals(finalCompare_field, compare_field2);
                return flag1 && flag2;
            }).collect(Collectors.toList());
            if (otherList.size() > 0) {
                for (SpecialStorageBaseaddressLengyun o2 : otherList) {
                    String address_id2 = o2.getAddress_id();
                    String all14numletter_zaiku2 = o2.getAll14numletter_zaiku();
                    String all15numletter_zaiku2 = o2.getAll15numletter_zaiku();
                    String all16numletter_zaiku2 = o2.getAll16numletter_zaiku();
                    String all17numletter_zaiku2 = o2.getAll17numletter_zaiku();
                    if (judgeList(all14numletter_zaiku1, all14numletter_zaiku2, "0") && judgeList(all15numletter_zaiku1, all15numletter_zaiku2, "0")
                            && judgeList(all16numletter_zaiku1, all16numletter_zaiku2, "0") && judgeList(all17numletter_zaiku1, all17numletter_zaiku2, "0")) {
                        flag = true;
                        judge_set3_set.add(address_id1);
                        judge_set3_set.add(address_id2);
                    }
                }
            }
            String company_name = o1.getCompany_name();
            String company_zaiku = o1.getCompany_zaiku();
            if (judge_set3_set.size() > 0) {
                if ("911".equals(tag)) {
                    o1.setJudge_set3_911(String.join("|", judge_set3_set));
                    o1.setJudge_result("repeat_911");
                    if (StringUtils.isEmpty(company_name) && StringUtils.isEmpty(company_zaiku)) {
                        o1.setJudge_result("undecided");
                    }

                } else if ("913".equals(tag)) {
                    o1.setJudge_set3_913(String.join("|", judge_set3_set));
                    o1.setJudge_result("repeat_913");
                    if (StringUtils.isEmpty(company_name) && StringUtils.isEmpty(company_zaiku)) {
                        o1.setJudge_result("undecided");
                    }
                }
            } else {
                o1.setJudge_result("undecided");
            }
        }

        if (!flag) {
            return judge_subset_list.stream().peek(t -> t.setJudge_result("undecided")).collect(Collectors.toList());
        }
        return judge_subset_list;
    }

    public static boolean judgeList(String text1, String text2, String tag) {
        if (StringUtils.isEmpty(tag)) {
            if (StringUtils.isNotEmpty(text1) && StringUtils.isNotEmpty(text2)) {
                String[] split1 = text1.split("\\|");
                String[] split2 = text2.split("\\|");
                for (String s1 : split1) {
                    for (String s2 : split2) {
                        if (StringUtils.isNotEmpty(s1) && StringUtils.equals(s1, s2)) {
                            return true;
                        }
                    }
                }
            }
        } else {
            return StringUtils.equals(text1, text2);
        }
        return false;
    }

    public static JavaRDD<SpecialStorageBaseaddressLengyun> getPreProcessData(SparkInfo sparkInfo, String date) {
        String sql = String.format("select * from dm_gis.specialstorage_baseaddress_lengyun_inprogress where inc_day = '%s'", date);
        JavaRDD<SpecialStorageBaseaddressLengyun> rdd = DataUtil.loadData(sparkInfo.getSession(), sparkInfo.getContext(), sql, SpecialStorageBaseaddressLengyun.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        return rdd;
    }
}
