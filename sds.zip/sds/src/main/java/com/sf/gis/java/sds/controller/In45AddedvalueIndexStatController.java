package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CityNameMap;
import com.sf.gis.java.sds.pojo.In45Addedvalue;
import com.sf.gis.java.sds.pojo.In45AddedvalueIndex;
import com.sf.gis.java.sds.service.StdBaseService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

public class In45AddedvalueIndexStatController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(In45AddedvalueIndexStatController.class);
    StdBaseService service = new StdBaseService();

    public void process(String date1, String date2) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        StdBaseService service = new StdBaseService();

        JavaRDD<In45Addedvalue> rdd = loadData(spark, sc, date1, date2).mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        List<CityNameMap> cityNameMapList = service.loadCityNameMap(spark, sc).collect();
        logger.error("cityNameMapList cnt:{}", cityNameMapList.size());
        Broadcast<List<CityNameMap>> cityNameMapListBc = sc.broadcast(cityNameMapList);

        JavaRDD<In45Addedvalue> cityNameRdd = rdd.map(o -> {
            List<CityNameMap> cityNameMapListTemp = cityNameMapListBc.value();
            String dest_dist_code = o.getDest_dist_code();
            List<CityNameMap> collect = cityNameMapListTemp.stream().filter(t -> StringUtils.equals(t.getCitycode(), dest_dist_code)).collect(Collectors.toList());
            if (collect.size() > 0) {
                o.setRegion(collect.get(0).getRegion());
                String city = ArrayUtil.joinArr(collect.stream().sorted((o1, o2) -> o1.getAdcode().compareTo(o2.getAdcode())).map(t -> t.getCity()).collect(Collectors.toList()), "/");
                o.setCity(city);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityNameRdd cnt:{}", cityNameRdd.count());
        rdd.unpersist();

        JavaRDD<In45AddedvalueIndex> dateRdd = cityNameRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_", o)).groupByKey().map(tp -> processStat("ALL", tp._1, Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<In45AddedvalueIndex> regionRdd = cityNameRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getRegion(), o)).groupByKey().map(tp -> processStat("REGION", tp._1, Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<In45AddedvalueIndex> cityRdd = cityNameRdd.mapToPair(o -> new Tuple2<>(o.getInc_day() + "_" + o.getDest_dist_code(), o)).groupByKey().map(tp -> processStat("CITY", tp._1, Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("dateRdd cnt:{}", dateRdd.count());
        logger.error("regionRdd cnt:{}", regionRdd.count());
        logger.error("cityRdd cnt:{}", cityRdd.count());
        cityNameRdd.unpersist();

        JavaRDD<In45AddedvalueIndex> resultRdd = dateRdd.union(regionRdd).union(cityRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        dateRdd.unpersist();
        regionRdd.unpersist();
        cityRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.in45_addedvalue_stat", In45AddedvalueIndex.class, resultRdd, "inc_day");
        resultRdd.unpersist();
    }

    public static JavaRDD<In45Addedvalue> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select * from dm_gis.in45_addedvalue where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, In45Addedvalue.class);
    }

    public In45AddedvalueIndex processStat(String stat_type, String stat_type_content, List<In45Addedvalue> list) {

        In45AddedvalueIndex in45AddedvalueIndex = new In45AddedvalueIndex();
        long cnt = list.size();
        in45AddedvalueIndex.setCnt(cnt + "");
        double sum_fee = list.stream().map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSum_fee(sum_fee + "");

        long gis_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIsclimb())).count();
        in45AddedvalueIndex.setGis_cnt(gis_cnt + "");
        double gis_sum_fee = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIsclimb())).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setGis_sum_fee(gis_sum_fee + "");

        long climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1")).count();
        double climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        long no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2")).count();
        double no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        long no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0")).count();
        double no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        long no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1")).count();
        double no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);

        in45AddedvalueIndex.setClimb_cnt(climb_cnt + "");
        in45AddedvalueIndex.setClimb_sum_fee(climb_sum_fee + "");

        in45AddedvalueIndex.setNo_elevator_cnt(no_elevator_cnt + "");
        in45AddedvalueIndex.setNo_elevator_sum_fee(no_elevator_sum_fee + "");

        in45AddedvalueIndex.setNo_climb_cnt(no_climb_cnt + "");
        in45AddedvalueIndex.setNo_climb_sum_fee(no_climb_sum_fee + "");

        in45AddedvalueIndex.setNo_distinguish_cnt(no_distinguish_cnt + "");
        in45AddedvalueIndex.setNo_distinguish_sum_fee(no_distinguish_sum_fee + "");


        long residence_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && judgeAoiType(o.getAoitypecode())).count();
        in45AddedvalueIndex.setResidence_climb_cnt(residence_climb_cnt + "");

        double residence_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && judgeAoiType(o.getAoitypecode())).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setResidence_climb_sum_fee(residence_climb_sum_fee + "");

        long residence_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && judgeAoiType(o.getAoitypecode())).count();
        in45AddedvalueIndex.setResidence_no_elevator_cnt(residence_no_elevator_cnt + "");

        double residence_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && judgeAoiType(o.getAoitypecode())).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setResidence_no_elevator_sum_fee(residence_no_elevator_sum_fee + "");

        long residence_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && judgeAoiType(o.getAoitypecode())).count();
        in45AddedvalueIndex.setResidence_no_climb_cnt(residence_no_climb_cnt + "");

        double residence_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && judgeAoiType(o.getAoitypecode())).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setResidence_no_climb_sum_fee(residence_no_climb_sum_fee + "");

        long residence_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && judgeAoiType(o.getAoitypecode())).count();
        in45AddedvalueIndex.setResidence_no_distinguish_cnt(residence_no_distinguish_cnt + "");

        double residence_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && judgeAoiType(o.getAoitypecode())).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setResidence_no_distinguish_sum_fee(residence_no_distinguish_sum_fee + "");

        long other_residence_climb_cnt = climb_cnt - residence_climb_cnt;
        in45AddedvalueIndex.setOther_residence_climb_cnt(other_residence_climb_cnt + "");

        double other_residence_climb_sum_fee = climb_sum_fee - residence_climb_sum_fee;
        in45AddedvalueIndex.setOther_residence_climb_sum_fee(other_residence_climb_sum_fee + "");

        long other_residence_no_elevator_cnt = no_elevator_cnt - residence_no_elevator_cnt;
        in45AddedvalueIndex.setOther_residence_no_elevator_cnt(other_residence_no_elevator_cnt + "");

        double other_residence_no_elevator_sum_fee = no_elevator_sum_fee - residence_no_elevator_sum_fee;
        in45AddedvalueIndex.setOther_residence_no_elevator_sum_fee(other_residence_no_elevator_sum_fee + "");

        long other_residence_no_climb_cnt = no_climb_cnt - residence_no_climb_cnt;
        in45AddedvalueIndex.setOther_residence_no_climb_cnt(other_residence_no_climb_cnt + "");


        double other_residence_no_climb_sum_fee = no_climb_sum_fee - residence_no_climb_sum_fee;
        in45AddedvalueIndex.setOther_residence_no_climb_sum_fee(other_residence_no_climb_sum_fee + "");


        long other_residence_no_distinguish_cnt = no_distinguish_cnt - residence_no_distinguish_cnt;
        in45AddedvalueIndex.setOther_residence_no_distinguish_cnt(other_residence_no_distinguish_cnt + "");


        double other_residence_no_distinguish_sum_fee = no_distinguish_sum_fee - residence_no_distinguish_sum_fee;
        in45AddedvalueIndex.setOther_residence_no_distinguish_sum_fee(other_residence_no_distinguish_sum_fee + "");


        long opcode_50_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getOpcode(), "50")).count();
        in45AddedvalueIndex.setOpcode_50_climb_cnt(opcode_50_climb_cnt + "");

        double opcode_50_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getOpcode(), "50")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setOpcode_50_climb_sum_fee(opcode_50_climb_sum_fee + "");


        long opcode_50_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getOpcode(), "50")).count();
        in45AddedvalueIndex.setOpcode_50_no_elevator_cnt(opcode_50_no_elevator_cnt + "");

        double opcode_50_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getOpcode(), "50")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setOpcode_50_no_elevator_sum_fee(opcode_50_no_elevator_sum_fee + "");

        long opcode_50_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getOpcode(), "50")).count();
        in45AddedvalueIndex.setOpcode_50_no_climb_cnt(opcode_50_no_climb_cnt + "");

        double opcode_50_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getOpcode(), "50")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setOpcode_50_no_climb_sum_fee(opcode_50_no_climb_sum_fee + "");

        long opcode_50_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getOpcode(), "50")).count();
        in45AddedvalueIndex.setOpcode_50_no_distinguish_cnt(opcode_50_no_distinguish_cnt + "");

        double opcode_50_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getOpcode(), "50")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setOpcode_50_no_distinguish_sum_fee(opcode_50_no_distinguish_sum_fee + "");

        long other_opcode_50_climb_cnt = climb_cnt - opcode_50_climb_cnt;
        in45AddedvalueIndex.setOther_opcode_50_climb_cnt(other_opcode_50_climb_cnt + "");

        double other_opcode_50_climb_sum_fee = climb_sum_fee - opcode_50_climb_sum_fee;
        in45AddedvalueIndex.setOther_opcode_50_climb_sum_fee(other_opcode_50_climb_sum_fee + "");

        long other_opcode_50_no_elevator_cnt = no_elevator_cnt - opcode_50_no_elevator_cnt;
        in45AddedvalueIndex.setOther_opcode_50_no_elevator_cnt(other_opcode_50_no_elevator_cnt + "");

        double other_opcode_50_no_elevator_sum_fee = no_elevator_sum_fee - opcode_50_no_elevator_sum_fee;
        in45AddedvalueIndex.setOther_opcode_50_no_elevator_sum_fee(other_opcode_50_no_elevator_sum_fee + "");

        long other_opcode_50_no_climb_cnt = no_climb_cnt - opcode_50_no_climb_cnt;
        in45AddedvalueIndex.setOther_opcode_50_no_climb_cnt(other_opcode_50_no_climb_cnt + "");

        double other_opcode_50_no_climb_sum_fee = no_climb_sum_fee - opcode_50_no_climb_sum_fee;
        in45AddedvalueIndex.setOther_opcode_50_no_climb_sum_fee(other_opcode_50_no_climb_sum_fee + "");

        long other_opcode_50_no_distinguish_cnt = no_distinguish_cnt - opcode_50_no_distinguish_cnt;
        in45AddedvalueIndex.setOther_opcode_50_no_distinguish_cnt(other_opcode_50_no_distinguish_cnt + "");

        double other_opcode_50_no_distinguish_sum_fee = no_distinguish_sum_fee - opcode_50_no_distinguish_sum_fee;
        in45AddedvalueIndex.setOther_opcode_50_no_distinguish_sum_fee(other_opcode_50_no_distinguish_sum_fee + "");

        long sfkh_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).count();
        in45AddedvalueIndex.setSfkh_climb_cnt(sfkh_climb_cnt + "");

        double sfkh_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfkh_climb_sum_fee(sfkh_climb_sum_fee + "");

        long sfkh_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).count();
        in45AddedvalueIndex.setSfkh_no_elevator_cnt(sfkh_no_elevator_cnt + "");

        double sfkh_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfkh_no_elevator_sum_fee(sfkh_no_elevator_sum_fee + "");

        long sfkh_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).count();
        in45AddedvalueIndex.setSfkh_no_climb_cnt(sfkh_no_climb_cnt + "");

        double sfkh_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfkh_no_climb_sum_fee(sfkh_no_climb_sum_fee + "");

        long sfkh_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).count();
        in45AddedvalueIndex.setSfkh_no_distinguish_cnt(sfkh_no_distinguish_cnt + "");

        double sfkh_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "顺丰卡航")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfkh_no_distinguish_sum_fee(sfkh_no_distinguish_sum_fee + "");

        long bzld_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "标准零担")).count();
        in45AddedvalueIndex.setBzld_climb_cnt(bzld_climb_cnt + "");

        double bzld_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "标准零担")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setBzld_climb_sum_fee(bzld_climb_sum_fee + "");

        long bzld_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "标准零担")).count();
        in45AddedvalueIndex.setBzld_no_elevator_cnt(bzld_no_elevator_cnt + "");

        double bzld_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "标准零担")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setBzld_no_elevator_sum_fee(bzld_no_elevator_sum_fee + "");

        long bzld_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "标准零担")).count();
        in45AddedvalueIndex.setBzld_no_climb_cnt(bzld_no_climb_cnt + "");

        double bzld_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "标准零担")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setBzld_no_climb_sum_fee(bzld_no_climb_sum_fee + "");

        long bzld_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "标准零担")).count();
        in45AddedvalueIndex.setBzld_no_distinguish_cnt(bzld_no_distinguish_cnt + "");

        double bzld_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "标准零担")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setBzld_no_distinguish_sum_fee(bzld_no_distinguish_sum_fee + "");

        long sfgp_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).count();
        in45AddedvalueIndex.setSfgp_climb_cnt(sfgp_climb_cnt + "");

        double sfgp_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfgp_climb_sum_fee(sfgp_climb_sum_fee + "");

        long sfgp_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).count();
        in45AddedvalueIndex.setSfgp_no_elevator_cnt(sfgp_no_elevator_cnt + "");

        double sfgp_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfgp_no_elevator_sum_fee(sfgp_no_elevator_sum_fee + "");

        long sfgp_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).count();
        in45AddedvalueIndex.setSfgp_no_climb_cnt(sfgp_no_climb_cnt + "");

        double sfgp_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfgp_no_climb_sum_fee(sfgp_no_climb_sum_fee + "");

        long sfgp_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).count();
        in45AddedvalueIndex.setSfgp_no_distinguish_cnt(sfgp_no_distinguish_cnt + "");

        double sfgp_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "顺丰干配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSfgp_no_distinguish_sum_fee(sfgp_no_distinguish_sum_fee + "");

        long cztp_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).count();
        in45AddedvalueIndex.setCztp_climb_cnt(cztp_climb_cnt + "");

        double cztp_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setCztp_climb_sum_fee(cztp_climb_sum_fee + "");

        long cztp_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).count();
        in45AddedvalueIndex.setCztp_no_elevator_cnt(cztp_no_elevator_cnt + "");

        double cztp_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setCztp_no_elevator_sum_fee(cztp_no_elevator_sum_fee + "");

        long cztp_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).count();
        in45AddedvalueIndex.setCztp_no_climb_cnt(cztp_no_climb_cnt + "");

        double cztp_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setCztp_no_climb_sum_fee(cztp_no_climb_sum_fee + "");

        long cztp_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).count();
        in45AddedvalueIndex.setCztp_no_distinguish_cnt(cztp_no_distinguish_cnt + "");

        double cztp_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getService_prod_name(), "纯重特配")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setCztp_no_distinguish_sum_fee(cztp_no_distinguish_sum_fee + "");

        long other_prod_name_type_climb_cnt = climb_cnt - sfkh_climb_cnt - bzld_climb_cnt - sfgp_climb_cnt - cztp_climb_cnt;
        in45AddedvalueIndex.setOther_prod_name_type_climb_cnt(other_prod_name_type_climb_cnt + "");

        double other_prod_name_type_climb_sum_fee = climb_sum_fee - sfkh_climb_sum_fee - bzld_climb_sum_fee - sfgp_climb_sum_fee - cztp_climb_sum_fee;
        in45AddedvalueIndex.setOther_prod_name_type_climb_sum_fee(other_prod_name_type_climb_sum_fee + "");

        long other_prod_name_type_no_elevator_cnt = no_elevator_cnt - sfkh_no_elevator_cnt - bzld_no_elevator_cnt - sfgp_no_elevator_cnt - cztp_no_elevator_cnt;
        in45AddedvalueIndex.setOther_prod_name_type_no_elevator_cnt(other_prod_name_type_no_elevator_cnt + "");

        double other_prod_name_type_no_elevator_sum_fee = no_elevator_sum_fee - sfkh_no_elevator_sum_fee - bzld_no_elevator_sum_fee - sfgp_no_elevator_sum_fee - cztp_no_elevator_sum_fee;
        in45AddedvalueIndex.setOther_prod_name_type_no_elevator_sum_fee(other_prod_name_type_no_elevator_sum_fee + "");

        long other_prod_name_type_no_climb_cnt = no_climb_cnt - sfkh_no_climb_cnt - bzld_no_climb_cnt - sfgp_no_climb_cnt - cztp_no_climb_cnt;
        in45AddedvalueIndex.setOther_prod_name_type_no_climb_cnt(other_prod_name_type_no_climb_cnt + "");

        double other_prod_name_type_no_climb_sum_fee = no_climb_sum_fee - sfkh_no_climb_sum_fee - bzld_no_climb_sum_fee - sfgp_no_climb_sum_fee - cztp_no_climb_sum_fee;
        in45AddedvalueIndex.setOther_prod_name_type_no_climb_sum_fee(other_prod_name_type_no_climb_sum_fee + "");

        long other_prod_name_type_no_distinguish_cnt = no_distinguish_cnt - sfkh_no_distinguish_cnt - bzld_no_distinguish_cnt - sfgp_no_distinguish_cnt - cztp_no_distinguish_cnt;
        in45AddedvalueIndex.setOther_prod_name_type_no_distinguish_cnt(other_prod_name_type_no_distinguish_cnt + "");

        double other_prod_name_type_no_distinguish_sum_fee = no_distinguish_sum_fee - sfkh_no_distinguish_sum_fee - bzld_no_distinguish_sum_fee - sfgp_no_distinguish_sum_fee - cztp_no_distinguish_sum_fee;
        in45AddedvalueIndex.setOther_prod_name_type_no_distinguish_sum_fee(other_prod_name_type_no_distinguish_sum_fee + "");

        long yj_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "月结")).count();
        in45AddedvalueIndex.setYj_climb_cnt(yj_climb_cnt + "");

        double yj_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "月结")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setYj_climb_sum_fee(yj_climb_sum_fee + "");

        long yj_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "月结")).count();
        in45AddedvalueIndex.setYj_no_elevator_cnt(yj_no_elevator_cnt + "");

        double yj_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "月结")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setYj_no_elevator_sum_fee(yj_no_elevator_sum_fee + "");

        long yj_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "月结")).count();
        in45AddedvalueIndex.setYj_no_climb_cnt(yj_no_climb_cnt + "");

        double yj_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "月结")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setYj_no_climb_sum_fee(yj_no_climb_sum_fee + "");

        long yj_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "月结")).count();
        in45AddedvalueIndex.setYj_no_distinguish_cnt(yj_no_distinguish_cnt + "");

        double yj_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "月结")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setYj_no_distinguish_sum_fee(yj_no_distinguish_sum_fee + "");

        long hy_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "会员")).count();
        in45AddedvalueIndex.setHy_climb_cnt(hy_climb_cnt + "");

        double hy_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "会员")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setHy_climb_sum_fee(hy_climb_sum_fee + "");

        long hy_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "会员")).count();
        in45AddedvalueIndex.setHy_no_elevator_cnt(hy_no_elevator_cnt + "");

        double hy_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "会员")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setHy_no_elevator_sum_fee(hy_no_elevator_sum_fee + "");

        long hy_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "会员")).count();
        in45AddedvalueIndex.setHy_no_climb_cnt(hy_no_climb_cnt + "");

        double hy_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "会员")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setHy_no_climb_sum_fee(hy_no_climb_sum_fee + "");

        long hy_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "会员")).count();
        in45AddedvalueIndex.setHy_no_distinguish_cnt(hy_no_distinguish_cnt + "");

        double hy_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "会员")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setHy_no_distinguish_sum_fee(hy_no_distinguish_sum_fee + "");

        long sk_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "散客")).count();
        in45AddedvalueIndex.setSk_climb_cnt(sk_climb_cnt + "");

        double sk_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPay_cust_type(), "散客")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSk_climb_sum_fee(sk_climb_sum_fee + "");

        long sk_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "散客")).count();
        in45AddedvalueIndex.setSk_no_elevator_cnt(sk_no_elevator_cnt + "");

        double sk_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPay_cust_type(), "散客")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSk_no_elevator_sum_fee(sk_no_elevator_sum_fee + "");

        long sk_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "散客")).count();
        in45AddedvalueIndex.setSk_no_climb_cnt(sk_no_climb_cnt + "");

        double sk_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPay_cust_type(), "散客")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSk_no_climb_sum_fee(sk_no_climb_sum_fee + "");

        long sk_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "散客")).count();
        in45AddedvalueIndex.setSk_no_distinguish_cnt(sk_no_distinguish_cnt + "");

        double sk_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPay_cust_type(), "散客")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSk_no_distinguish_sum_fee(sk_no_distinguish_sum_fee + "");

        long other_pay_cust_type_climb_cnt = climb_cnt - yj_climb_cnt - hy_climb_cnt - sk_climb_cnt;
        in45AddedvalueIndex.setOther_pay_cust_type_climb_cnt(other_pay_cust_type_climb_cnt + "");

        double other_pay_cust_type_climb_sum_fee = climb_sum_fee - yj_climb_sum_fee - hy_climb_sum_fee - sk_climb_sum_fee;
        in45AddedvalueIndex.setOther_pay_cust_type_climb_sum_fee(other_pay_cust_type_climb_sum_fee + "");

        long other_pay_cust_type_no_elevator_cnt = no_elevator_cnt - yj_no_elevator_cnt - hy_no_elevator_cnt - sk_no_elevator_cnt;
        in45AddedvalueIndex.setOther_pay_cust_type_no_elevator_cnt(other_pay_cust_type_no_elevator_cnt + "");

        double other_pay_cust_type_no_elevator_sum_fee = no_elevator_sum_fee - yj_no_elevator_sum_fee - hy_no_elevator_sum_fee - sk_no_elevator_sum_fee;
        in45AddedvalueIndex.setOther_pay_cust_type_no_elevator_sum_fee(other_pay_cust_type_no_elevator_sum_fee + "");

        long other_pay_cust_type_no_climb_cnt = no_climb_cnt - yj_no_climb_cnt - hy_no_climb_cnt - sk_no_climb_cnt;
        in45AddedvalueIndex.setOther_pay_cust_type_no_climb_cnt(other_pay_cust_type_no_climb_cnt + "");

        double other_pay_cust_type_no_climb_sum_fee = no_climb_sum_fee - yj_no_climb_sum_fee - hy_no_climb_sum_fee - sk_no_climb_sum_fee;
        in45AddedvalueIndex.setOther_pay_cust_type_no_climb_sum_fee(other_pay_cust_type_no_climb_sum_fee + "");

        long other_pay_cust_type_no_distinguish_cnt = no_distinguish_cnt - yj_no_distinguish_cnt - hy_no_distinguish_cnt - sk_no_distinguish_cnt;
        in45AddedvalueIndex.setOther_pay_cust_type_no_distinguish_cnt(other_pay_cust_type_no_distinguish_cnt + "");

        double other_pay_cust_type_no_distinguish_sum_fee = no_distinguish_sum_fee - yj_no_distinguish_sum_fee - hy_no_distinguish_sum_fee - sk_no_distinguish_sum_fee;
        in45AddedvalueIndex.setOther_pay_cust_type_no_distinguish_sum_fee(other_pay_cust_type_no_distinguish_sum_fee + "");

        long sgs_core_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).count();
        in45AddedvalueIndex.setSgs_core_climb_cnt(sgs_core_climb_cnt + "");

        double sgs_core_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSgs_core_climb_sum_fee(sgs_core_climb_sum_fee + "");

        long sgs_core_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).count();
        in45AddedvalueIndex.setSgs_core_no_elevator_cnt(sgs_core_no_elevator_cnt + "");

        double sgs_core_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSgs_core_no_elevator_sum_fee(sgs_core_no_elevator_sum_fee + "");

        long sgs_core_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).count();
        in45AddedvalueIndex.setSgs_core_no_climb_cnt(sgs_core_no_climb_cnt + "");

        double sgs_core_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSgs_core_no_climb_sum_fee(sgs_core_no_climb_sum_fee + "");
        long sgs_core_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).count();
        in45AddedvalueIndex.setSgs_core_no_distinguish_cnt(sgs_core_no_distinguish_cnt + "");
        double sgs_core_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPickup_barsn(), "sgs-core")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setSgs_core_no_distinguish_sum_fee(sgs_core_no_distinguish_sum_fee + "");

        long fop_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).count();
        in45AddedvalueIndex.setFop_climb_cnt(fop_climb_cnt + "");

        double fop_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "1") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setFop_climb_sum_fee(fop_climb_sum_fee + "");

        long fop_no_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).count();
        in45AddedvalueIndex.setFop_no_elevator_cnt(fop_no_elevator_cnt + "");

        double fop_no_elevator_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "2") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setFop_no_elevator_sum_fee(fop_no_elevator_sum_fee + "");

        long fop_no_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).count();
        in45AddedvalueIndex.setFop_no_climb_cnt(fop_no_climb_cnt + "");

        double fop_no_climb_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "0") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setFop_no_climb_sum_fee(fop_no_climb_sum_fee + "");

        long fop_no_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).count();
        in45AddedvalueIndex.setFop_no_distinguish_cnt(fop_no_distinguish_cnt + "");

        double fop_no_distinguish_sum_fee = list.stream().filter(o -> StringUtils.equals(o.getIsclimb(), "-1") && StringUtils.equals(o.getPickup_barsn(), "FOP-OPSS-CORE_FOP-APP-FCA")).map(o -> StringUtils.isNotEmpty(o.getService_fee()) ? Double.parseDouble(o.getService_fee()) : 0).reduce(Double::sum).orElse(0.0);
        in45AddedvalueIndex.setFop_no_distinguish_sum_fee(fop_no_distinguish_sum_fee + "");

        long other_pickup_barsn_climb_cnt = climb_cnt - sgs_core_climb_cnt - fop_climb_cnt;
        in45AddedvalueIndex.setOther_pickup_barsn_climb_cnt(other_pickup_barsn_climb_cnt + "");

        double other_pickup_barsn_climb_sum_fee = climb_sum_fee - sgs_core_climb_sum_fee - fop_climb_sum_fee;
        in45AddedvalueIndex.setOther_pickup_barsn_climb_sum_fee(other_pickup_barsn_climb_sum_fee + "");

        long other_pickup_barsn_no_elevator_cnt = no_elevator_cnt - sgs_core_no_elevator_cnt - fop_no_elevator_cnt;
        in45AddedvalueIndex.setOther_pickup_barsn_no_elevator_cnt(other_pickup_barsn_no_elevator_cnt + "");

        double other_pickup_barsn_no_elevator_sum_fee = no_elevator_sum_fee - sgs_core_no_elevator_sum_fee - fop_no_elevator_sum_fee;
        in45AddedvalueIndex.setOther_pickup_barsn_no_elevator_sum_fee(other_pickup_barsn_no_elevator_sum_fee + "");

        long other_pickup_barsn_no_climb_cnt = no_climb_cnt - sgs_core_no_climb_cnt - fop_no_climb_cnt;
        in45AddedvalueIndex.setOther_pickup_barsn_no_climb_cnt(other_pickup_barsn_no_climb_cnt + "");

        double other_pickup_barsn_no_climb_sum_fee = no_climb_sum_fee - sgs_core_no_climb_sum_fee - fop_no_climb_sum_fee;
        in45AddedvalueIndex.setOther_pickup_barsn_no_climb_sum_fee(other_pickup_barsn_no_climb_sum_fee + "");

        long other_pickup_barsn_no_distinguish_cnt = no_distinguish_cnt - sgs_core_no_distinguish_cnt - fop_no_distinguish_cnt;
        in45AddedvalueIndex.setOther_pickup_barsn_no_distinguish_cnt(other_pickup_barsn_no_distinguish_cnt + "");

        double other_pickup_barsn_no_distinguish_sum_fee = no_distinguish_sum_fee - sgs_core_no_distinguish_sum_fee - fop_no_distinguish_sum_fee;
        in45AddedvalueIndex.setOther_pickup_barsn_no_distinguish_sum_fee(other_pickup_barsn_no_distinguish_sum_fee + "");

        String date = stat_type_content.split("_")[0];
        in45AddedvalueIndex.setId(DigestUtils.md5Hex(date + stat_type + stat_type_content));
        in45AddedvalueIndex.setStat_date(date);
        in45AddedvalueIndex.setInc_day(date);
        in45AddedvalueIndex.setStat_type(stat_type);
        if (StringUtils.equals(stat_type, "ALL")) {
            in45AddedvalueIndex.setStat_type_content("ALL");
            in45AddedvalueIndex.setRegion("ALL");
            in45AddedvalueIndex.setCityCode("ALL");
            in45AddedvalueIndex.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "REGION")) {
            String region = stat_type_content.split("_")[1];
            in45AddedvalueIndex.setStat_type_content(region);
            in45AddedvalueIndex.setRegion(region);
            in45AddedvalueIndex.setCityCode("ALL");
            in45AddedvalueIndex.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "CITY")) {
            String citycode = stat_type_content.split("_")[1];
            In45Addedvalue in45Addedvalue = list.get(0);
            String region = in45Addedvalue.getRegion();
            String city = in45Addedvalue.getCity();

            in45AddedvalueIndex.setStat_type_content(city);
            in45AddedvalueIndex.setRegion(region);
            in45AddedvalueIndex.setCityCode(citycode);
            in45AddedvalueIndex.setCity(city);
        }

        return in45AddedvalueIndex;
    }

    public boolean judgeAoiType(String aoiTypeCode) {
        return StringUtils.equals(aoiTypeCode, "120301") || StringUtils.equals(aoiTypeCode, "120302") || StringUtils.equals(aoiTypeCode, "120203") || StringUtils.equals(aoiTypeCode, "120305");
    }
}
