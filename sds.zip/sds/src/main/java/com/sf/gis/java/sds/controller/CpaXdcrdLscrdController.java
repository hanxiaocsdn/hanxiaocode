package com.sf.gis.java.sds.controller;

import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.dto.AoiInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.XdLsCrd;
import com.sf.gis.java.sds.service.CpaXdcrdLscrdService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 客户下单位置信息和揽收位置信息分析
 * @author 01370539
 * Created on Jun.15 2022
 * 需求人员：赵瑜婷
 */
public class CpaXdcrdLscrdController {
    private static final Logger logger = LoggerFactory.getLogger(CpaXdcrdLscrdController.class);

    private static final CpaXdcrdLscrdService  cpaXdCrdLsCrdSvc = new CpaXdcrdLscrdService();

    public void process(String startDate, String endDate, String cityCode) {
        SparkInfo si = SparkUtil.getSpark(CpaXdcrdLscrdController.class.getName());

        JavaRDD<XdLsCrd> rddSrc = cpaXdCrdLsCrdSvc.loadSrcData(si, startDate, endDate, cityCode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("获取到的数据数量为： {}", rddSrc.count());
        rddSrc.take(3).forEach(o -> logger.error("o------->>> {}", o.toString()));

        JavaRDD<XdLsCrd> rddRs = rddSrc.map(o -> {
            if (StringUtils.isNotEmpty(o.getLsLng()) && StringUtils.isNotEmpty(o.getLsLat())) {
                AoiInfo lsAoi = AoiApi.byxy("7f8938c656044f9ca9bcc40f4407f351", "aoi2", o.getLsLng(), o.getLsLat());
                o.setLsAoiId(lsAoi.getAoiId());
                o.setLsAoiCode(lsAoi.getAoiCode());
                o.setLsAoiArea(lsAoi.getAoiAreaCode());
                o.setLsXyZc(lsAoi.getAoiZc());
            }
            if (StringUtils.isNotEmpty(o.getXdLng()) && StringUtils.isNotEmpty(o.getXdLat())) {
                AoiInfo xdAoi = AoiApi.byxy("7f8938c656044f9ca9bcc40f4407f351", "aoi2", o.getXdLng(), o.getXdLat());
                o.setXdAoiId(xdAoi.getAoiId());
                o.setXdAoiCode(xdAoi.getAoiCode());
                o.setXdAoiArea(xdAoi.getAoiAreaCode());
                o.setXdXyZc(xdAoi.getAoiZc());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("结果数据数量为： {}", rddRs.count());
        rddRs.take(3).forEach(o -> logger.error("o------->>> {}", o.toString()));
        rddSrc.unpersist();

        DataUtil.saveOverwrite(si, "xdcrd_lscrd_cpa", XdLsCrd.class, rddRs, "inc_day");
    }
}
