package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.*;
import com.sf.gis.java.base.pojo.ZcInfo;
import com.sf.gis.java.base.svc.CoordService;
import com.sf.gis.java.base.svc.ZcService;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.constant.SdsConstant;
import com.sf.gis.java.sds.pojo.*;
import com.sf.gis.java.sds.service.SfpAddrService;
import jodd.util.StringUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisSentinelPool;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 地址画像控制器
 * @author 01370539 created on Aug.6 2021
 */
public class SfpAddrController {
    private static final Logger logger = LoggerFactory.getLogger(SfpAddrController.class);

    private final SfpAddrService sfpAddrService = new SfpAddrService();
    private final CoordService coordService = new CoordService();
    private final ZcService zcService = new ZcService();

    private SparkInfo sparkInfo;

    public void process(String processMode, String cityCodes, String... args) {
        logger.error("process init start. processMode - {}, cityCodes - {}, args - {}", processMode, cityCodes, args);
        sparkInfo = SparkUtil.getSpark(SfpAddrController.class.getName());
        String[] cityCodeArr = cityCodes.split(",");
        Properties rcProp = ConfigUtil.loadPropertiesConfiguration("region_city.properties");

        for (String cityCode : cityCodeArr) {
            if (SdsConstant.SFP_ADDR_PROCESS_INIT.equalsIgnoreCase(processMode)) {
                processInit(rcProp.getProperty(cityCode), cityCode, args[0], args[1]);
            } else if (SdsConstant.SFP_ADDR_PROCESS_INIT_REGION.equalsIgnoreCase(processMode)) {
                processInit(cityCode, args[0], args[1]);
            } else if (SdsConstant.SFP_ADDR_PROCESS_SPLIT.equalsIgnoreCase(processMode)) {
                processSplit(cityCode);
            } else if (SdsConstant.SFP_ADDR_PROCESS_COORD.equalsIgnoreCase(processMode)) {
                processCoord(cityCode);
            } else if (SdsConstant.SFP_ADDR_PROCESS_NORM.equalsIgnoreCase(processMode)) {
                processNorm(cityCode);
            } else if (SdsConstant.SFP_ADDR_PROCESS_PUSH.equalsIgnoreCase(processMode) || SdsConstant.SFP_ADDR_PROCESS_PUSH_COORD.equalsIgnoreCase(processMode)) {
                processPush(cityCode, args[0], args[1], processMode);
            } else if (SdsConstant.SFP_ADDR_PROCESS_ALL.equalsIgnoreCase(processMode)) {
                processInit(rcProp.getProperty(cityCode), cityCode, args[0], args[1]);
                processSplit(cityCode);
                processCoord(cityCode);
            }
            sparkInfo.getSession().catalog().clearCache();
        }
    }

    /**
     * 获取运单寄件相关数据，并形成初始化数据
     * @param region // 大区
     * @param cityCode // 城市编码
     * @param startDate // 开始时间
     * @param endDate // 结束时间
     */
    private void processInit(String region, String cityCode, String startDate, String endDate) {
        logger.error("process init start. regioin - {}, cityCode - {}, startDate - {}, endDate - {}", region, cityCode, startDate, endDate);
        String curEndDate = startDate;
        while (curEndDate.compareToIgnoreCase(endDate) < 0) {
            curEndDate = DateUtil.getDayAfter(startDate, FixedConstant.DATE_FORMATE_INCDAY, 30);
            if (curEndDate.compareToIgnoreCase(endDate) > 0) {
                curEndDate = endDate;
            }
            logger.error("init. curRegion - {}, cityCode - {}, startDate - {}, endDate - {}", region, cityCode, startDate, curEndDate);
            // 获取初始化数据
            JavaRDD<SfpAddrInit> rddInit = sfpAddrService.load4Init(sparkInfo, region, cityCode, startDate, curEndDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("address init data count: {}", rddInit.count());

            DataUtil.saveInto(sparkInfo, "dm_gis.sfp_addr_init", SfpAddrInit.class, rddInit, "city_code");
            rddInit.unpersist();
            startDate = DateUtil.getDayAfter(curEndDate, FixedConstant.DATE_FORMATE_INCDAY, 1);
        }
        logger.error("process init end. ");
    }

    /**
     * 获取运单寄件相关数据，并形成初始化数据
     * @param region // 大区
     * @param startDate // 开始时间
     * @param endDate // 结束时间
     */
    private void processInit(String region, String startDate, String endDate) {
        logger.error("process init start. regioin - {}, startDate - {}, endDate - {}", region, startDate, endDate);
        String curEndDate = startDate;
        while (curEndDate.compareToIgnoreCase(endDate) < 0) {
            curEndDate = DateUtil.getDayAfter(startDate, FixedConstant.DATE_FORMATE_INCDAY, 30);
            if (curEndDate.compareToIgnoreCase(endDate) > 0) {
                curEndDate = endDate;
            }
            logger.error("init. curRegion - {}, startDate - {}, endDate - {}", region, startDate, curEndDate);
            // 获取初始化数据
            JavaRDD<SfpAddrInit> rddInit = sfpAddrService.load4Init(sparkInfo, region, startDate, curEndDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("address init data count: {}", rddInit.count());

            DataUtil.saveInto(sparkInfo, "dm_gis.sfp_addr_init", SfpAddrInit.class, rddInit, "city_code");
            rddInit.unpersist();
            startDate = DateUtil.getDayAfter(curEndDate, FixedConstant.DATE_FORMATE_INCDAY, 1);
        }
        logger.error("process init end. ");
    }

    private void processSplit(String cityCode) {
        logger.error("process split start. cityCode - {}", cityCode);

        JavaRDD<SfpAddrInit> rddInit = sfpAddrService.load4Split(sparkInfo, cityCode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("need split data count: {}", rddInit.count());

        // 拆分初始化数据分词，并根据分词生成主键id
        JavaRDD<SfpAddrInit> rddAi4s = sfpAddrService.split(rddInit).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddAi4s.take(1).forEach(temp -> logger.error("rddAi4s data format: {}", temp.toString()));
        rddInit.unpersist();

        DataUtil.saveOverwrite(sparkInfo, "dm_gis.sfp_addr_split", SfpAddrInit.class, rddAi4s, "city_code");
        rddAi4s.unpersist();

        logger.error("process split end. ");
    }

    private void processCoord(String cityCode) {
        logger.error("process coord start. cityCode - {}", cityCode);

        JavaRDD<SfpAddrInit> rddInit = sfpAddrService.load4Coord(sparkInfo, cityCode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("coord data count: {}", rddInit.count());

        JavaRDD<CoordInfo> rddCoord1 = rddInit.map(temp -> {
            CoordInfo ci = new CoordInfo();
            ci.setUuid(temp.getUuid());
            ci.setKey(temp.getKeyId() + "#" + temp.getHashLatLngBq());
            ci.setLat(temp.getLatBq());
            ci.setLng(temp.getLngBq());
            return ci;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the first time need converge count: {}", rddCoord1.count());
        rddCoord1.take(1).forEach(temp -> logger.error("rddCoord: {}", temp.toString()));

        JavaRDD<CoordInfo> rddCoord2 = coordService.converge(rddCoord1, SdsConstant.COORD_CONVERGE_DIS_50).map(temp -> {
            CoordInfo ci = new CoordInfo();
            ci.setUuid(temp.getUuid());
            ci.setKey(temp.getKey().split("#")[0]);
            ci.setLat(temp.getLat());
            ci.setLng(temp.getLng());
            ci.setLlList(temp.getLlList());
            ci.setSubMap(temp.getSubMap());
            return ci;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the second time need converge count: {}", rddCoord2.count());
        rddCoord2.take(1).forEach(temp -> logger.error("rddCoord: {}", temp.toString()));
        rddCoord1.unpersist();

        JavaRDD<CoordInfo> rddCoord3 = coordService.converge(rddCoord2, SdsConstant.COORD_CONVERGE_DIS_50).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("after the second time converge count: {}", rddCoord3.count());
        rddCoord3.take(1).forEach(temp -> logger.error("rddCoord: {}", temp.toString()));
        rddCoord2.unpersist();

        JavaPairRDD<String, LatLong> rddCenter = coordService.getCenter(rddCoord3).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddCenter count: {}", rddCenter.count());
        rddCoord3.unpersist();

        JavaRDD<SfpAddrInit> rddFinal = rddInit.mapToPair(temp -> new Tuple2<>(temp.getUuid(), temp)).join(rddCenter).map(tp -> {
            tp._2._1.setLat(String.valueOf(tp._2._2.getLat()));
            tp._2._1.setLng(String.valueOf(tp._2._2.getLon()));
            return tp._2._1;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddFinal count: {}", rddFinal.count());
        rddFinal.take(1).forEach(temp -> logger.error("rddFinal format: {}", temp.toString()));
        rddInit.unpersist();
        rddCenter.unpersist();

        DataUtil.saveOverwrite(sparkInfo, "dm_gis.sfp_addr_coord", SfpAddrInit.class, rddFinal, "city_code");
        rddFinal.unpersist();

        logger.error("process coord end.");
    }

    private void processNorm(String cityCode) {
        logger.error("process norm start. cityCode - {}", cityCode);

        JavaRDD<SfpAddrInit> rddCoord = sfpAddrService.load4Norm(sparkInfo, cityCode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddCoord data count: {}", rddCoord.count());
        JavaRDD<SfpAddrNorm> rddConverge = rddCoord.mapToPair(temp -> new Tuple2<>(temp.getKeyId() + "#" + temp.getLat() + "#" + temp.getLng(), temp)).groupByKey().map(tp -> {
            SfpAddrNorm san = new SfpAddrNorm();
            List<SfpAddrInit> aisList = Lists.newArrayList(tp._2);
            SfpAddrInit sai = null;
            for (SfpAddrInit ais : aisList) {
                if (StringUtils.isNotEmpty(ais.getZc()) || StringUtils.isNotEmpty(ais.getAoi())) {
                    sai = ais;
                    break;
                }
            }
            if (sai == null) {
                sai = aisList.get(0);
            }
            san.setProvince(sai.getProvince());
            san.setCity(sai.getCity());
            san.setDistrict(sai.getDistrict());
            san.setAddr(sai.getAddr());
            san.setSplit(sai.getSplit());
            san.setSplitKey(sai.getSplitKey());
            san.setSplitKeyLevel(sai.getSplitKeyLevel());
            san.setKeyId(sai.getKeyId());
            san.setPoi(sai.getPoi());
            san.setBuilding(sai.getBuilding());
            san.setLngGeo(sai.getLngGeo());
            san.setLatGeo(sai.getLatGeo());
            san.setPrecisionGeo(sai.getPrecisionGeo());
            san.setLngKh(sai.getLngKh());
            san.setLatKh(sai.getLatKh());
            san.setLngBq(sai.getLngBq());
            san.setLatBq(sai.getLatBq());
            san.setPrecisionBq(sai.getPrecisionBq());
            san.setLng(sai.getLng());
            san.setLat(sai.getLat());
            san.setFreq(String.valueOf(aisList.size()));
            san.setCityCode(sai.getCityCode());
            return san;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddConverge count: {}", rddConverge.count());
        rddCoord.unpersist();

        JavaRDD<SfpAddrNorm> rddNorm = rddConverge.map(temp -> {
            AtdispatchApiIn param = new AtdispatchApiIn();
            param.setAk("332129eb218a469dbc9e88b35ed43886");
            param.setOpt("zh");
            param.setCity(temp.getCityCode());
            param.setAddress(URLEncoder.encode(StrUtils.processInvalidCharacter(temp.getAddr()), FixedConstant.CHARSET_UTF));
            AddrInfo addrInfo = AddrApi.atdispatchApi(param);
            AoiInfo aoiInfo = AoiApi.byxy("332129eb218a469dbc9e88b35ed43886", temp.getLng(), temp.getLat());
            temp.setZc(addrInfo.getZc());
            temp.setAoiAddr(addrInfo.getAoiId());
            temp.setAoiXy(aoiInfo.getAoiId());
            temp.setAoiXyType(aoiInfo.getAoiType());
            temp.setAoiXyTypeName(aoiInfo.getAoiTypeName());
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddNorm count: {}", rddNorm.count());
        rddNorm.take(1).forEach(temp -> logger.error("rddNorm data format: {}", temp.toString()));
        rddConverge.unpersist();

        JavaPairRDD<String, ZcInfo> rddTpZc = zcService.getZcPoint(sparkInfo, cityCode).mapToPair(temp -> new Tuple2<>(temp.getZc(), temp)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddTpZc count: {}", rddTpZc.count());
        logger.error("755FG count: {}", rddTpZc.filter(tp -> "755FG".equalsIgnoreCase(tp._1)).count());

        JavaRDD<SfpAddrNorm> rddFinalPre = rddNorm.mapToPair(temp -> new Tuple2<>(temp.getZc(), temp)).groupByKey().leftOuterJoin(rddTpZc.groupByKey()).flatMap(tp -> {
            List<SfpAddrNorm> result = Lists.newArrayList(tp._2._1);
            if (tp._2._2.isPresent()) {
                List<ZcInfo> zcList = Lists.newArrayList(tp._2._2.get());
                ZcInfo zcInfo = zcList.get(0);
                for (SfpAddrNorm sfpAddrNorm : result) {
                    sfpAddrNorm.setLatZc(zcInfo.getLat());
                    sfpAddrNorm.setLngZc(zcInfo.getLng());
                }
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddFinalPre count: {}", rddFinalPre.count());
        rddFinalPre.take(1).forEach(temp -> logger.error("rddFinalPre data format: {}", temp.toString()));

        JavaRDD<SfpAddrNorm> rddFinal = rddFinalPre.map(temp -> {
            Double disZc = StringUtils.isNotEmpty(temp.getLatZc()) && StringUtils.isNotEmpty(temp.getLngZc()) ? GeometryUtil.getDistance(GeometryUtil.createPoint(temp.getLngZc(), temp.getLatZc()), GeometryUtil.createPoint(temp.getLng(), temp.getLat())) : null;
            Double disGeo = StringUtils.isNotEmpty(temp.getLatGeo()) && StringUtils.isNotEmpty(temp.getLngGeo()) ? GeometryUtil.getDistance(GeometryUtil.createPoint(temp.getLngGeo(), temp.getLatGeo()), GeometryUtil.createPoint(temp.getLng(), temp.getLat())) : null;
            Double disKh = StringUtils.isNotEmpty(temp.getLatKh()) && StringUtils.isNotEmpty(temp.getLngKh()) ? GeometryUtil.getDistance(GeometryUtil.createPoint(temp.getLngKh(), temp.getLatKh()), GeometryUtil.createPoint(temp.getLng(), temp.getLat())) : null;
            Boolean isInAoi = StringUtil.isNotEmpty(temp.getAoiAddr()) && StringUtils.isNotEmpty(temp.getAoiXy()) ? temp.getAoiAddr().equalsIgnoreCase(temp.getAoiXy()) : null;

            if (disZc != null && disZc <= SdsConstant.COORD_CONVERGE_DIS_50) {
                temp.setIsEffect(SdsConstant.IS_EFFECT_0);
                temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_ZC);
            }
            if (StringUtils.isEmpty(temp.getIsEffect())) {
                if (isInAoi != null && isInAoi) {
                    temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                    temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_AOI);
                    if (disGeo != null && disGeo <= SdsConstant.COORD_CONVERGE_DIS_50 && disKh != null && disKh <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_AOIGEOKH);
                    } else if (disKh != null && disKh <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_AOIKH);
                    } else if (disGeo != null && disGeo <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_AOIGEO);
                    }
                } else {
                    if (isInAoi != null && !isInAoi) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_0);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_UNMATCH_AOI);
                    } else {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_2);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_DEFAULT);
                    }
                    if (disGeo != null && disGeo <= SdsConstant.COORD_CONVERGE_DIS_50 && disKh != null && disKh <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_GEOKH);
                    } else if (disKh != null && disKh <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_KH);
                    } else if (disGeo != null && disGeo <= SdsConstant.COORD_CONVERGE_DIS_50) {
                        temp.setIsEffect(SdsConstant.IS_EFFECT_1);
                        temp.setEffectType(SdsConstant.EFFECT_TYPE_MATCH_GEO);
                    }
                }
            }
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddFinal count: {}", rddFinal.count());
        rddFinal.take(1).forEach(temp -> logger.error("rddFinal data format: {}", temp.toString()));
        rddNorm.unpersist();

        DataUtil.saveOverwrite(sparkInfo, "dm_gis.sfp_addr_norm", SfpAddrNorm.class, rddFinal, "city_code");
        rddFinal.unpersist();

        logger.error("process converge end.");
    }

    private void processPush(String cityCode, String effectTypes, String xyAoiTypes, String processMode) {
        logger.error("process {} start. cityCode - {}, effectTypes - {}, xyAoiTypes - {}", processMode, cityCode, effectTypes, xyAoiTypes);

        String etStr = "'" + effectTypes.replaceAll(",", "','") + "'";
        String xyAoiTypeStr = "'" + xyAoiTypes.replaceAll(",", "','") + "'";
        JavaRDD<SfpAddrNorm> rddNorm = null;
        if (SdsConstant.SFP_ADDR_PROCESS_PUSH.equalsIgnoreCase(processMode)) {
            rddNorm = sfpAddrService.load4Push(sparkInfo, cityCode, etStr, xyAoiTypeStr).persist(StorageLevel.MEMORY_AND_DISK_SER());
        } else if (SdsConstant.SFP_ADDR_PROCESS_PUSH_COORD.equalsIgnoreCase(processMode)) {
            rddNorm = sfpAddrService.load4PushCoord(sparkInfo, cityCode, etStr, xyAoiTypeStr).persist(StorageLevel.MEMORY_AND_DISK_SER());
        }        
        logger.error("rddNorm data count: {}", rddNorm.count());

        JavaRDD<SfpAddrPush> rddRule = sfpAddrService.extractSkRule(rddNorm, processMode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddRule data count: {}", rddNorm.count());
        rddNorm.unpersist();

        JavaRDD<SfpAddrPush> rddPush = rddRule.filter(temp -> {
            boolean result = false;
            String[] sklArr = temp.getSplitKeyLevel().split("\\|");
            for (String skl : sklArr) {
                if (skl.startsWith("14")) {
                    result = true;
                    break;
                }
            }
            return result;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddPush count: {}", rddPush.count());
        rddPush.take(1).forEach(temp -> logger.error("push data format - {}", temp.toString()));
        rddNorm.unpersist();

        DataUtil.saveInto(sparkInfo, "dm_gis.sfp_addr_push", SfpAddrPush.class, rddPush, "inc_day");

        JavaRDD<Map<String, String>> rddMap = rddPush.repartition(SysConstant.PARALLELISM_REDIS).mapPartitions(pt -> {
            SfpAddrPush sfpAddrPush;
            JedisSentinelPool pool = RedisUtil.initJedisPool("redis.properties");
            Jedis jedis = pool.getResource();
            String key;
            long setRs;
            List<Map<String, String>> resultList = new ArrayList<>();
            while (pt.hasNext()) {
                sfpAddrPush = pt.next();
                Map<String, String> valueMap = new HashMap<>();
                try {
                    valueMap.put("keyId", sfpAddrPush.getKeyId());
                    valueMap.put("lat", sfpAddrPush.getLat());
                    valueMap.put("lng", sfpAddrPush.getLng());
                    key = DigestUtils.md5Hex(sfpAddrPush.getSplitKey().replaceAll("\\|", ""));
                    setRs = jedis.hset(sfpAddrPush.getAoiXy(), key, JSON.toJSONString(valueMap));
                    valueMap.put("setRs", String.valueOf(setRs));
                } catch(Exception e) {
                    valueMap.put("setRs", "-1");
                    logger.error("push error. value : {}", valueMap);
                }
                resultList.add(valueMap);
            }
            pool.close();
            return resultList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("push complete. push count: {}", rddMap.count());
        logger.error("push failure count: {}， push success count: {}", rddMap.filter(mp -> "-1".equalsIgnoreCase(mp.get("setRs"))).count(), rddMap.filter(mp -> "1".equalsIgnoreCase(mp.get("setRs"))).count());
        rddPush.unpersist();
        rddMap.unpersist();
        logger.error("process {} end. ", processMode);
    }

    public void processBuilding(String url) {
        logger.error("process process building start, url - {}", url);
        try {
            sparkInfo = SparkUtil.getSpark(SfpAddrController.class.getName());
            Properties prop = ConfigUtil.loadPropertiesConfiguration("ch_building_city_adcode.properties");
            Connection conn = JdbcUtil.getClickHouseConnection("jdbc:clickhouse://" + url + "/zymysql", "gis-ass-acts-ch2", "BDP@clickhouse");

            JavaRDD<Building> rddBuilding = sfpAddrService.load4Building(sparkInfo, conn);
            logger.error("rddBuilding count: {}", rddBuilding.count());
            rddBuilding.take(1).forEach(temp -> logger.error("building format: {}", temp.toString()));

            JavaRDD<Building> rddFinal = rddBuilding.map(temp -> {
                AoiInfo aoiInfo = AoiApi.byxy("332129eb218a469dbc9e88b35ed43886", temp.getLng(), temp.getLat());
                temp.setAoi(aoiInfo.getAoiId());
                temp.setCityCode(prop.getProperty(temp.getAdcode()));
                return temp;
            });
            rddFinal.take(1).forEach(temp -> logger.error("building format: {}", temp.toString()));
            rddBuilding.unpersist();
            if (rddFinal.count() > 0) {
                DataUtil.saveOverwrite(sparkInfo, "dm_gis.sfp_addr_building", Building.class, rddFinal, "city_code");
            }
            rddFinal.unpersist();
        } catch (Exception e) {
            logger.error("");
        }
        logger.error("process process building end. ");
    }

    public void processVerify() {
        logger.error("process verify start");

        sparkInfo = SparkUtil.getSpark(SfpAddrController.class.getName());

        JavaRDD<SfpAddrNorm> rddVerify = sfpAddrService.load4Verify(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("need verify data count: {}", rddVerify.count());

        JavaPairRDD<String, Iterable<SfpAddrNorm>> rddTpVerify = rddVerify.mapToPair(temp -> new Tuple2<>(temp.getAoiXy(), temp)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("need verify aoi count: {}", rddTpVerify.count());
        rddVerify.unpersist();

        JavaRDD<Building> rddBuilding = sfpAddrService.loadBuilding(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("building data count: {}", rddBuilding.count());

        JavaPairRDD<String, Iterable<Building>> rddTpBuilding = rddBuilding.mapToPair(temp -> new Tuple2<>(temp.getAoi(), temp)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("building aoi count: {}", rddTpBuilding.count());
        rddBuilding.unpersist();

        JavaRDD<SfpAddrNorm> rddFinal = rddTpVerify.join(rddTpBuilding).flatMap(tp -> {
            List<Building> buildingList = Lists.newArrayList(tp._2._2);
            Map<String, List<Building>> buildingMap = new HashMap<>();
            List<Building> ruleList = null;
            Pattern pNumber = Pattern.compile("(.*[0-9].*)");
            Matcher mNumber = null;
            String rule;
            for (Building building : buildingList) {
                mNumber = pNumber.matcher(building.getName());
                if (mNumber.find()) {
                    rule = mNumber.group(0);
                    if (StringUtils.isNotEmpty(rule)) {
                        ruleList = buildingMap.get(rule);
                        if (ruleList == null) {
                            ruleList = new ArrayList<>();
                            buildingMap.put(rule, ruleList);
                        }
                        ruleList.add(building);
                    }
                }
            }

            List<SfpAddrNorm> normList = Lists.newArrayList(tp._2._1);
            String[] klArr;
            Integer index;
            for(SfpAddrNorm norm : normList) {
                index = null;
                klArr = norm.getSplitKeyLevel().split("\\|");
                for (int i = klArr.length - 1; i >= 0; i--) {
                    if (klArr[i].startsWith("14^")) {
                        index = i;
                        break;
                    }
                }
                if (index != null) {
                    klArr = norm.getSplitKey().split("\\|");
                    mNumber = pNumber.matcher(klArr[index]);
                    if (mNumber.find()) {
                        rule = mNumber.group(0);
                        buildingList = buildingMap.get(rule);
                        if (buildingList != null) {
                            norm.setStatusBuilding("match_name");
                            for (Building building : buildingList) {
                                norm.setBuildingId(building.getId());
                                norm.setBuildingName(building.getName());
                                norm.setLatBuilding(building.getLat());
                                norm.setLngBuilding(building.getLng());
                                if (GeometryUtil.getDistance(GeometryUtil.createPoint(building.getLng(), building.getLat()), GeometryUtil.createPoint(norm.getLng(), norm.getLat())) <= 50) {
                                    norm.setStatusBuilding("match_coord");
                                    break;
                                }
                            }
                        } else {
                            norm.setStatusBuilding("unmatch");
                        }
                    }
                }
            }
            return normList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("can match building count: {}", rddFinal.count());
        rddTpVerify.unpersist();
        rddTpBuilding.unpersist();

        DataUtil.saveOverwrite(sparkInfo, "dm_gis.sfp_addr_verify", SfpAddrNorm.class, rddFinal, "city_code");
        rddFinal.unpersist();

        logger.error("process verify end. ");
    }
}
