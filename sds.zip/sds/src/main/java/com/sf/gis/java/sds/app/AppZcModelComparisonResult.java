package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.DimDeptInfoDf;
import com.sf.gis.java.sds.pojo.ZcModelComparisonResult;
import com.sf.gis.java.sds.pojo.ZcModelComparisonResultStat;
import com.sf.gis.java.sds.pojo.ZnocodeDepartcodeMapping;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务id：833268（【壹竿项目-SD】ZC模型更新后指标效果对比）
 * 业务方：01421176,01436983（陈袁,王艳）
 * 研发：01399581（匡仁衡）
 * 时间：2023年10月7日09:44:39
 */

public class AppZcModelComparisonResult {
    private static Logger logger = LoggerFactory.getLogger(AppZcModelComparisonResult.class);
    private static String url = "http://gis-gw.int.sfdc.com.cn:9080/atip/zc?cuted=0&citycode=%s&address=%s";
    private static String atp = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=d4c3a0f6ed0044df8c1e4f0cc1dbfe6f";
    private static String old_ak = "6efbc190f2f24091afc3fb993234652f";
    private static String new_ak = "e66c43a17c7342bf847cd3e670a51148";

    private static String account = "01399581";
    private static String taskId = "833268";
    private static String taskName = "ZC模型更新后指标效果对比";

    private static int limitMin = 1000 / 10;

    public static void main(String[] args) {
        String date = args[0];
        String citycodes = args[1];
        logger.error("date:{}", date);
        logger.error("citycodes:{}", citycodes);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppZcModelComparisonResult");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String before4Date = DateUtil.getDaysBefore(date, 4);
        String before1Date = DateUtil.getDaysBefore(date, 1);

        //获取网点和上级网点映射
        Broadcast<Map<String, DimDeptInfoDf>> zoneMapBc = sc.broadcast(getZoneMap(spark, sc, before1Date));
        //获取重量网点映射
        Broadcast<Map<String, String>> weightMapBc = sc.broadcast(getWeightMap(spark, before1Date));
        //获取变更网点映射
        JavaRDD<String> strRdd = sc.textFile("/user/01399581/upload/yunying_demand/data/zc_change.csv").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("strRdd cnt:{}", strRdd.count());
        strRdd.take(10).forEach(o -> logger.error(JSON.toJSONString(o)));
        String header = strRdd.first();
        logger.error("header:{}", header);
        Map<String, String> zcChangeMap = new HashMap<>(strRdd.filter(o -> !StringUtils.equals(o, header)).mapToPair(line -> {
            String[] split = line.split(",");
            if (split.length >= 2) {
                return new Tuple2<>(split[0], split[1]);
            }
            return new Tuple2<>("", "");
        }).filter(tp -> StringUtils.isNotEmpty(tp._1) && StringUtils.isNotEmpty(tp._2)).collectAsMap());
        logger.error("zcChangeMap size:{}", zcChangeMap.size());
        Broadcast<Map<String, String>> zcChangeMapBc = sc.broadcast(zcChangeMap);

        spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01399581/sfdencrpt.ini");
        spark.sql("add jar hdfs://sfbdp1/tmp/udf/01377105/131623/1002/decrypt-2.0.jar");
        spark.sql("create temporary function bdp_decrypt as 'com.sf.udf.decrypt_v2.Decrypt'");

        String no_vip_sql = String.format("select waybill_no,bdp_decrypt(current_timestamp(), consignee_addr, false) consignee_addr,dest_dist_code dest_city_code,dest_city_name,dest_zone_code,addressee_dept_code,consignee_aoi_code_dept_code,'0' vip_tag from dwd.dwd_waybill_info_dtl_di where inc_day between '%s' and '%s' and ackbill_type_code = '1' and dest_dist_code in (%s) order by rand() limit 200000", before4Date, before1Date, mkString(citycodes.split(",")));
        JavaRDD<ZcModelComparisonResult> noVipRdd = DataUtil.loadData(spark, sc, no_vip_sql, ZcModelComparisonResult.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noVipRdd cnt:{}", noVipRdd.count());

        String vip_last_date = spark.sql("show partitions dm_gis.zc_model_offline").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("vip_last_date:{}", vip_last_date);
        String vip_sql = String.format("select consignee_addr,dest_city_code,'1' vip_tag from dm_gis.zc_model_offline where inc_day = '%s'", vip_last_date);
        JavaRDD<ZcModelComparisonResult> vipRdd = DataUtil.loadData(spark, sc, vip_sql, ZcModelComparisonResult.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("vipRdd cnt:{}", vipRdd.count());

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atp, "d4c3a0f6ed0044df8c1e4f0cc1dbfe6f", vipRdd.count(), 1);
        JavaRDD<ZcModelComparisonResult> vipZoneRdd = vipRdd.repartition(1).map(o -> {
            String consignee_addr = o.getConsignee_addr();
            String dest_city_code = o.getDest_city_code();
            if (StringUtils.isNotEmpty(consignee_addr)) {
                String req = String.format(atp, URLEncoder.encode(consignee_addr, "UTF-8"), dest_city_code);
                String content = HttpInvokeUtil.sendGet(req);
                String dept = "";
                try {
                    dept = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setDest_zone_code(dept);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("vipZoneRdd cnt:{}", vipZoneRdd.count());
        vipRdd.unpersist();
        vipZoneRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        JavaRDD<ZcModelComparisonResult> rdd = noVipRdd.union(vipZoneRdd).map(o -> {
            o.setInc_day(date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());
        noVipRdd.unpersist();
        vipZoneRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, old_ak, rdd.count(), 1);
        JavaRDD<ZcModelComparisonResult> oldRdd = getResp(rdd, "ak", old_ak, "old").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("oldRdd cnt:{}", oldRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, new_ak, oldRdd.count(), 1);
        JavaRDD<ZcModelComparisonResult> newRdd = getResp(oldRdd, "ak", new_ak, "new").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newRdd cnt:{}", newRdd.count());
        oldRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        logger.error("获取网点数据");

        //获取各字段上级网点以及重量映射
        JavaRDD<ZcModelComparisonResult> tagRdd = newRdd.map(o -> {
            Map<String, DimDeptInfoDf> zoneMap = zoneMapBc.value();
            Map<String, String> weightMap = weightMapBc.value();
            Map<String, String> zcChange = zcChangeMapBc.value();

            //运单妥投的网点代码
            String dest_zone_code = o.getDest_zone_code();
//            String dest_zone_code_up = zoneMap.getOrDefault(dest_zone_code, ""); //运单妥投的网点代码的上级网点
            String dest_zone_code_up = zoneMap.get(dest_zone_code) != null ? zoneMap.get(dest_zone_code).getParent_dept_code() : ""; //运单妥投的网点代码的上级网点
            o.setDest_zone_code_up(dest_zone_code_up);

            //旧网点代码
            String old_dept = o.getOld_dept();
//            String old_dept_up = zoneMap.getOrDefault(old_dept, ""); //旧返回网点上级网点
            String old_dept_up = zoneMap.get(old_dept) != null ? zoneMap.get(old_dept).getParent_dept_code() : ""; //旧返回网点上级网点
            String old_dept_weight = weightMap.getOrDefault(old_dept, ""); //旧返回网点映射的重量网点
            String old_dept_up_weight = weightMap.getOrDefault(old_dept_up, ""); //旧返回网点上级网点映射的重量网点
            o.setOld_dept_up(old_dept_up);
            o.setOld_dept_weight(old_dept_weight);
            o.setOld_dept_up_weight(old_dept_up_weight);

            //新网点代码
            String new_dept = o.getNew_dept();
//            String new_dept_up = zoneMap.getOrDefault(new_dept, ""); //新返回网点上级网点
            String new_dept_up = zoneMap.get(new_dept) != null ? zoneMap.get(new_dept).getParent_dept_code() : ""; //新返回网点上级网点
            String new_dept_weight = weightMap.getOrDefault(new_dept, ""); //新返回网点映射的重量网点
            String new_dept_up_weight = weightMap.getOrDefault(new_dept_up, ""); //新返回网点上级网点映射的重量网点
            o.setNew_dept_up(new_dept_up);
            o.setNew_dept_weight(new_dept_weight);
            o.setNew_dept_up_weight(new_dept_up_weight);

            String old_tag = "";
            String new_tag = "";
            if (StringUtils.isEmpty(dest_zone_code) || zcChange.containsKey(dest_zone_code) || zcChange.containsKey(dest_zone_code_up)) {
                old_tag = "2";
                new_tag = "2";
            }

            if (StringUtils.isEmpty(old_dept) || zcChange.containsKey(old_dept) || zcChange.containsKey(old_dept_up) || zcChange.containsKey(old_dept_weight) || zcChange.containsKey(old_dept_up_weight)) {
                old_tag = "2";
            }

            if (StringUtils.isEmpty(new_dept) || zcChange.containsKey(new_dept) || zcChange.containsKey(new_dept_up) || zcChange.containsKey(new_dept_weight) || zcChange.containsKey(new_dept_up_weight)) {
                new_tag = "2";
            }

            //dest_zone_code关联dim.dim_dept_info_df表dept_code，获取网点类型和网点名称dept_type_code，dept_type_name
            DimDeptInfoDf dimDeptInfoDf = zoneMap.get(dest_zone_code);
            String dept_type_code = "";
            String dept_type_name = "";
            if (dimDeptInfoDf != null) {
                dept_type_code = dimDeptInfoDf.getDept_type_code();
                dept_type_name = dimDeptInfoDf.getDept_type_name();
            }

            //特殊网点剔除  网点类型dept_type_code为DB05-XMDB/FB04-WXJ/FB04-XMFB/FB05-CCPSCK/FB04-GLX/DB05-JPZ/FB04-KYFB/ZZC04-ERJ/ZZC05-KYJS/QB03-KYGS 或者 （网点类型dept_type_code为DB05-SFZ且网点名称dept_type_name包含临时网点/服务中心  的运单）
            List<String> type_code_list = Arrays.asList("DB05-XMDB,FB04-WXJ,FB04-XMFB,FB05-CCPSCK,FB04-GLX,DB05-JPZ,FB04-KYFB,ZZC04-ERJ,ZZC05-KYJS,QB03-KYGS,DB05-HKJPZ,DB05-DJJPZ,ZZC04-YJ,ZZC05-SJ".split(","));
            if (type_code_list.contains(dept_type_code) || ("DB05-SFZ".equals(dept_type_code) && StringUtils.isNotEmpty(dept_type_name) && (dept_type_name.contains("临时网点") || dept_type_name.contains("服务中心")))) {
                old_tag = "2";
                new_tag = "2";
            }

            //同城件剔除 dest_zone_code是否是数字+TC+两位字母
            if (StringUtils.isNotEmpty(dest_zone_code) && dest_zone_code.matches("\\d+TC[A-Za-z]{2}")) {
                old_tag = "2";
                new_tag = "2";
            }

            //跨城市剔除 dest_zone_code截取城市编码 citycode citycode !=dest_city_code
            String citycode = getCityCode(dest_zone_code);
            String dest_city_code = o.getDest_city_code();
            if (StringUtils.isNotEmpty(dest_city_code) && !StringUtils.equals(citycode, dest_city_code)) {
                old_tag = "2";
                new_tag = "2";
            }

            //校验旧返回网点和新返回网点数据准确性
            if (StringUtils.isEmpty(old_tag)) {
                if (compareZc(old_dept, dest_zone_code, dest_zone_code_up) || compareZc(old_dept_up, dest_zone_code, dest_zone_code_up) ||
                        compareZc(old_dept_weight, dest_zone_code, dest_zone_code_up) || compareZc(old_dept_up_weight, dest_zone_code, dest_zone_code_up)) {
                    old_tag = "1";
                } else {
                    old_tag = "0";
                }
            }

            if (StringUtils.isEmpty(new_tag)) {
                if (compareZc(new_dept, dest_zone_code, dest_zone_code_up) || compareZc(new_dept_up, dest_zone_code, dest_zone_code_up) ||
                        compareZc(new_dept_weight, dest_zone_code, dest_zone_code_up) || compareZc(new_dept_up_weight, dest_zone_code, dest_zone_code_up)) {
                    new_tag = "1";
                } else {
                    new_tag = "0";
                }
            }


            o.setOld_tag(old_tag);
            o.setNew_tag(new_tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:{}", tagRdd.count());
        newRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.zc_model_comparison_result", ZcModelComparisonResult.class, tagRdd, "inc_day");

        //统计指标
        ZcModelComparisonResultStat stat = stat(tagRdd, date);
        tagRdd.unpersist();
        ArrayList<ZcModelComparisonResultStat> list = new ArrayList<>();
        list.add(stat);

        JavaRDD<ZcModelComparisonResultStat> statRdd = sc.parallelize(list).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:{}", statRdd.count());

        DataUtil.saveOverwrite(spark, sc, "dm_gis.zc_model_comparison_total", ZcModelComparisonResultStat.class, statRdd, "inc_day");
        statRdd.unpersist();
        sc.stop();
    }

    public static String getCityCode(String zonecode) {
        StringBuilder sb = new StringBuilder();
        if (StringUtils.isNotEmpty(zonecode)) {
            zonecode = zonecode.trim();
            for (int i = 0; i < zonecode.length(); i++) {
                char c = zonecode.charAt(i);
                if (Character.isLowerCase(c) || Character.isUpperCase(c)) {
                    break;
                }
                if (c >= 48 && c <= 57) {
                    sb.append(c);
                }
            }

        }
        return sb.toString();
    }


    public static ZcModelComparisonResultStat stat(JavaRDD<ZcModelComparisonResult> tagRdd, String date) {
        //总量
        long waybill_total = tagRdd.count();
        long old_dept_sbl_total = tagRdd.filter(o -> StringUtils.isNotEmpty(o.getOld_dept())).count();
        long new_dept_sbl_total = tagRdd.filter(o -> StringUtils.isNotEmpty(o.getNew_dept())).count();
        double old_dept_sbl = (double) old_dept_sbl_total / (double) waybill_total;
        double new_dept_sbl = (double) new_dept_sbl_total / (double) waybill_total;
        long old_dept_zql_total = tagRdd.filter(o -> StringUtils.equals("1", o.getOld_tag())).count();
        long new_dept_zql_total = tagRdd.filter(o -> StringUtils.equals("1", o.getNew_tag())).count();
        long old_dept_0_total = tagRdd.filter(o -> StringUtils.equals("0", o.getOld_tag())).count();
        long new_dept_0_total = tagRdd.filter(o -> StringUtils.equals("0", o.getNew_tag())).count();
        double old_dept_zql = (double) old_dept_zql_total / (double) (old_dept_zql_total + old_dept_0_total);
        double new_dept_zql = (double) new_dept_zql_total / (double) (new_dept_zql_total + new_dept_0_total);


        //大客户
        long waybill_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1")).count();
        long old_dept_sbl_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.isNotEmpty(o.getOld_dept())).count();
        long new_dept_sbl_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.isNotEmpty(o.getNew_dept())).count();
        double old_dept_sbl_ka = (double) old_dept_sbl_total_ka / (double) waybill_total_ka;
        double new_dept_sbl_ka = (double) new_dept_sbl_total_ka / (double) waybill_total_ka;
        long old_dept_zql_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.equals("1", o.getOld_tag())).count();
        long new_dept_zql_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.equals("1", o.getNew_tag())).count();
        long old_dept_0_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.equals("0", o.getOld_tag())).count();
        long new_dept_0_total_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "1") && StringUtils.equals("0", o.getNew_tag())).count();
        double old_dept_zql_ka = (double) old_dept_zql_total_ka / (double) (old_dept_zql_total_ka + old_dept_0_total_ka);
        double new_dept_zql_ka = (double) new_dept_zql_total_ka / (double) (new_dept_zql_total_ka + new_dept_0_total_ka);

        //非大客户
        long waybill_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0")).count();
        long old_dept_sbl_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.isNotEmpty(o.getOld_dept())).count();
        long new_dept_sbl_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.isNotEmpty(o.getNew_dept())).count();
        double old_dept_sbl_no_ka = (double) old_dept_sbl_total_no_ka / (double) waybill_total_no_ka;
        double new_dept_sbl_no_ka = (double) new_dept_sbl_total_no_ka / (double) waybill_total_no_ka;
        long old_dept_zql_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.equals("1", o.getOld_tag())).count();
        long new_dept_zql_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.equals("1", o.getNew_tag())).count();
        long old_dept_0_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.equals("0", o.getOld_tag())).count();
        long new_dept_0_total_no_ka = tagRdd.filter(o -> StringUtils.equals(o.getVip_tag(), "0") && StringUtils.equals("0", o.getNew_tag())).count();
        double old_dept_zql_no_ka = (double) old_dept_zql_total_no_ka / (double) (old_dept_zql_total_no_ka + old_dept_0_total_no_ka);
        double new_dept_zql_no_ka = (double) new_dept_zql_total_no_ka / (double) (new_dept_zql_total_no_ka + new_dept_0_total_no_ka);

        return new ZcModelComparisonResultStat(waybill_total + "", old_dept_sbl_total + "", new_dept_sbl_total + "", old_dept_sbl + "", new_dept_sbl + "", old_dept_zql_total + "", new_dept_zql_total + "", old_dept_zql + "", new_dept_zql + "",
                waybill_total_ka + "", old_dept_sbl_total_ka + "", new_dept_sbl_total_ka + "", old_dept_sbl_ka + "", new_dept_sbl_ka + "", old_dept_zql_total_ka + "", new_dept_zql_total_ka + "", old_dept_zql_ka + "", new_dept_zql_ka + "",
                waybill_total_no_ka + "", old_dept_sbl_total_no_ka + "", new_dept_sbl_total_no_ka + "", old_dept_sbl_no_ka + "", new_dept_sbl_no_ka + "", old_dept_zql_total_no_ka + "", new_dept_zql_total_no_ka + "", old_dept_zql_no_ka + "", new_dept_zql_no_ka + "",
                date
        );

    }

    public static boolean compareZc(String zc, String dest_zone_code, String dest_zone_code_up) {
        return StringUtils.isNotEmpty(zc) && (StringUtils.equals(zc, dest_zone_code) || StringUtils.equals(zc, dest_zone_code_up));
    }


    public static Map<String, DimDeptInfoDf> getZoneMap(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select dept_code,parent_dept_code,dept_type_code,dept_type_name from dim.dim_dept_info_df where inc_day = '%s' and delete_flg = '0' and (dept_code is not null and dept_code <>'')", date);
        return DataUtil.loadData(spark, sc, sql, DimDeptInfoDf.class).collect().stream().collect(Collectors.toMap(DimDeptInfoDf::getDept_code, t -> t, (key1, key2) -> key2));
    }

    public static Map<String, String> getWeightMap(SparkSession spark, String date) {
        String sql = String.format("select dept_code_last,dept_code_mapping from (\n" +
                "select\n" +
                "  dept_code_last,\n" +
                "  dept_code_mapping\n" +
                "from\n" +
                "  dm_sssnew.dm_weight_mapping_dtl_df lateral view explode(split(dept_code,',')) tmp_tbl as dept_code_last\n" +
                "where\n" +
                "  inc_day = '%s'\n" +
                "  and deleted = 'N'\n" +
                "  and dept_code_mapping is not null and dept_code_mapping <>''\n" +
                ") t where t.dept_code_last is not null and t.dept_code_last <>''", date);
        logger.error("weight_mapping_sql:{}", sql);
        Map<String, String> map = spark.sql(sql).toJavaRDD().mapToPair(row -> new Tuple2<>(row.getString(0), row.getString(1))).collectAsMap();
        logger.error("WeightMap size:{}", map.size());
        return new HashMap<>(map);
    }


    public static JavaRDD<ZcModelComparisonResult> getResp(JavaRDD<ZcModelComparisonResult> rdd, String key, String value, String tag) {
        return rdd.repartition(10).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<ZcModelComparisonResult> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                ZcModelComparisonResult o = itr.next();
                String addr = o.getConsignee_addr();
                String dest_city_code = o.getDest_city_code();
                if (StringUtils.isNotEmpty(addr)) {
                    String req = String.format(url, dest_city_code, URLEncoder.encode(addr, "UTF-8"));
                    String content = HttpInvokeUtil.sendGet(req, key, value);
                    String dept = "";
                    try {
                        dept = JSON.parseObject(content).getJSONObject("result").getString("zc_code");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    if (StringUtils.equals(tag, "old")) {
                        o.setOld_resp(content);
                        o.setOld_dept(dept);
                    } else if (StringUtils.equals(tag, "new")) {
                        o.setNew_resp(content);
                        o.setNew_dept(dept);
                    }
                }
                list.add(o);
            }
            return list.iterator();
        });
    }

    public static String mkString(String[] arr) {
        return "\'" + String.join("\',\'", arr) + "\'";
    }
}
