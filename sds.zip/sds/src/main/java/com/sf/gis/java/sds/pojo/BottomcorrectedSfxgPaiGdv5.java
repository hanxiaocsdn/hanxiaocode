package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Map;

@Table
public class BottomcorrectedSfxgPaiGdv5 implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "gis_aoi_name")
    private String gis_aoi_name;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "tag3")
    private String tag3;
    @Column(name = "bottomcorrected")
    private String bottomcorrected;
    @Column(name = "r_aoi")
    private String r_aoi;
    @Column(name = "key_word")
    private String key_word;
    @Column(name = "key_tag")
    private String key_tag;
    @Column(name = "80_aoi_code")
    private String aoi_code_80;
    @Column(name = "80_aoi_name")
    private String aoi_name_80;
    @Column(name = "mapa_aoicode")
    private String mapa_aoicode;
    @Column(name = "gd_aoicode")
    private String gd_aoicode;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "gj_aoicode_t")
    private String gj_aoicode_t;
    @Column(name = "errortype")
    private String errortype;
    @Column(name = "finalresult")
    private String finalresult;
    @Column(name = "phone")
    private String phone;

    @Column(name = "distinct_id")
    private String distinct_id;
    @Column(name = "lib")
    private String lib;
    @Column(name = "type")
    private String type;
    @Column(name = "event")
    private String event;
    @Column(name = "time")
    private String time;
    @Column(name = "user_id")
    private String user_id;
    @Column(name = "zone_code")
    private String zone_code;
    @Column(name = "event_id")
    private String event_id;
    @Column(name = "properties")
    private String properties;
    @Column(name = "city")
    private String city;
    @Column(name = "province")
    private String province;

    @Column(name = "std_address")
    private String std_address;
    @Column(name = "gdaoi")
    private String gdaoi;
    @Column(name = "inc_day")
    private String inc_day;

    private boolean flag;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getGis_aoi_name() {
        return gis_aoi_name;
    }

    public void setGis_aoi_name(String gis_aoi_name) {
        this.gis_aoi_name = gis_aoi_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getBottomcorrected() {
        return bottomcorrected;
    }

    public void setBottomcorrected(String bottomcorrected) {
        this.bottomcorrected = bottomcorrected;
    }

    public String getR_aoi() {
        return r_aoi;
    }

    public void setR_aoi(String r_aoi) {
        this.r_aoi = r_aoi;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getKey_tag() {
        return key_tag;
    }

    public void setKey_tag(String key_tag) {
        this.key_tag = key_tag;
    }

    public String getAoi_code_80() {
        return aoi_code_80;
    }

    public void setAoi_code_80(String aoi_code_80) {
        this.aoi_code_80 = aoi_code_80;
    }

    public String getAoi_name_80() {
        return aoi_name_80;
    }

    public void setAoi_name_80(String aoi_name_80) {
        this.aoi_name_80 = aoi_name_80;
    }

    public String getMapa_aoicode() {
        return mapa_aoicode;
    }

    public void setMapa_aoicode(String mapa_aoicode) {
        this.mapa_aoicode = mapa_aoicode;
    }

    public String getGd_aoicode() {
        return gd_aoicode;
    }

    public void setGd_aoicode(String gd_aoicode) {
        this.gd_aoicode = gd_aoicode;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getErrortype() {
        return errortype;
    }

    public void setErrortype(String errortype) {
        this.errortype = errortype;
    }

    public String getFinalresult() {
        return finalresult;
    }

    public void setFinalresult(String finalresult) {
        this.finalresult = finalresult;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDistinct_id() {
        return distinct_id;
    }

    public void setDistinct_id(String distinct_id) {
        this.distinct_id = distinct_id;
    }

    public String getLib() {
        return lib;
    }

    public void setLib(String lib) {
        this.lib = lib;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getZone_code() {
        return zone_code;
    }

    public void setZone_code(String zone_code) {
        this.zone_code = zone_code;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getProperties() {
        return properties;
    }

    public void setProperties(String properties) {
        this.properties = properties;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getStd_address() {
        return std_address;
    }

    public void setStd_address(String std_address) {
        this.std_address = std_address;
    }

    public String getGdaoi() {
        return gdaoi;
    }

    public void setGdaoi(String gdaoi) {
        this.gdaoi = gdaoi;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
