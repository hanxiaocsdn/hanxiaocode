package com.sf.gis.java.sds.service;

import com.sf.gis.java.sds.enumtype.MapType;
import com.sf.gis.java.sds.enumtype.ProjectType;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class SyncWaybillAoiDataToProjectService {
    private static final Logger logger = LoggerFactory.getLogger(SyncWaybillAoiDataToProjectService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    // 目标订单表的字段
    private final static List<String> order_info_columns = Arrays.asList(new String[]{"waybill_id", "waybill_no",
            "source_zone_code", "src_dist_code", "src_city_code", "src_county", "src_division_code", "src_area_code",
            "src_hq_code", "src_type_code", "src_lgt", "src_lat", "meterage_weight_qty", "real_weight_qty",
            "consignee_emp_code", "consigned_tm", "cargo_type_code", "limit_type_code", "express_type_code",
            "ackbill_type_code", "waybill_type", "order_no", "contacts_id", "consignor_comp_name", "consignor_addr",
            "consignor_phone", "consignor_cont_name", "consignor_mobile", "consignor_addr_native",
            "freight_monthly_acct_code", "freight_payment_type_code", "freight_payment_dept_code",
            "cod_monthly_acct_code", "all_fee", "all_fee_rmb", "freight", "freight_rmb", "consignor_post_code",
            "service_prod_code", "is_value_insured", "cons_name", "cvs_code", "signed_back_waybill_no",
            "source_waybill_no", "goods_deal_type", "inner_parcel_flag", "self_send_flag", "self_pickup_flag",
            "transfer_parcel_flag", "order_id", "order_type", "order_tm", "source_unit_code", "recv_bar_tm",
            "consign_lgt", "consign_lat", "load_tm", "pay_cust_type", "consignor_cust_type", "recv_bar_dept_code",
            "waybill_source_type", "real_monthly_acct_code", "real_product_code", "real_all_fee", "real_cod_fee_rmb",
            "cons_category", "src_province", "aoi_id", "aoi_name", "aoi_alias", "aoi_address", "aoi_x", "aoi_y",
            "aoi_code", "hook_src", "aoi_type_code", "aoi_type_name", "aoi_zc", "order_type_code", "call_needflg",
            "src_sys_type", "is_sch_order", "call_needflg_gis", "aoi_parent", "inc_day"});
    // 目标运单表的字段
    private final static List<String> waybill_info_columns = Arrays.asList(new String[]{"waybill_id", "waybill_no",
            "dest_zone_code", "dest_dist_code", "dest_city_code", "dest_county", "dest_division_code", "dest_area_code",
            "dest_hq_code", "dest_type_code", "dest_lgt", "dest_lat", "meterage_weight_qty", "real_weight_qty",
            "deliver_emp_code", "signer_name", "signin_tm", "cargo_type_code", "limit_type_code", "express_type_code",
            "ackbill_type_code", "waybill_type", "order_no", "consignee_comp_name", "consignee_addr", "consignee_phone",
            "consignee_cont_name", "consignee_mobile", "consignee_addr_native", "freight_monthly_acct_code",
            "freight_payment_type_code", "freight_payment_dept_code", "cod_monthly_acct_code", "all_fee", "all_fee_rmb",
            "freight", "freight_rmb", "consignee_post_code", "service_prod_code", "is_value_insured", "cons_name",
            "receipt_cvs_code", "signed_back_waybill_no", "source_waybill_no", "goods_deal_type", "inner_parcel_flag",
            "self_send_flag", "self_pickup_flag", "transfer_parcel_flag", "order_id", "dest_unit_code",
            "change_addr_flag", "delivery_lgt", "delivery_lat", "waybill_status", "load_tm", "pay_cust_type",
            "send_bar_dept_code", "first_loading_dept_code", "last_unloading_dept_code", "waybill_source_type",
            "real_monthly_acct_code", "real_product_code", "real_all_fee", "real_cod_fee_rmb", "cons_category",
            "dest_province", "aoi_id", "aoi_name", "aoi_alias", "aoi_address", "aoi_x", "aoi_y", "hook_src",
            "aoi_type_code", "aoi_type_name", "aoi_code", "aoi_zc", "aoi_parent", "inc_day"});

    public SyncWaybillAoiDataToProjectService() {
//        sparkSession = SparkManager.getInstance("BDP_ProcessingSyncProject").getSparkSession();
        sparkSession = Spark.getSparkSession(SyncWaybillAoiDataToProjectService.class.getSimpleName(),null,false,2);
    }

    public String createSql(String targetTable, String dataTime, String dataType,
                            String city_str) {

        List<String> columns = waybill_info_columns;
        String deptStr = "dest_dist_code";
        String srcTable = "tt_waybill_hook";
        if (dataType.equals(MapType.shou.name())) {
            columns = order_info_columns;
            deptStr = "src_dist_code";
            srcTable = "tt_order_hook";
        }
        StringBuilder sb = new StringBuilder();
        for (String column : columns) {
            if (column.equals("consignee_addr") || column.equals("consignor_addr")
            || column.equals("consignor_cont_name") || column.equals("consignee_cont_name")
            || column.equals("consignee_mobile") || column.equals("consignee_phone")
            ) {
                sb.append("'' as " + column).append(",");
            }else if(column.equals("cons_name") && dataType.equals(MapType.shou.name())){
                sb.append("NULL as " + column).append(",");
            }
            else {
                sb.append(column).append(",");
            }
        }
        sb.deleteCharAt(sb.length() - 1);
        String sql = "insert into table  " + targetTable + " partition(" + "inc_day) select "
                + sb.toString()
                + " from dm_gis." + srcTable + " where  inc_day='" + dataTime + "'";
        if (!city_str.isEmpty()) {
            sql = sql + " and " + deptStr + " in ('" + city_str + "')";
        }
        return sql;
    }

    /**
     * 同步数据到项目表
     *
     * @param project
     * @param dataType
     * @param dataTime
     * @param syncCityList
     */
    public void syncWaybillAoiToProject(String project, String dataType, String dataTime, Set<String> syncCityList) {
        String targetTable = fetchTableName(project, dataType);
        logger.error("删除分区");
        sparkSession.sql("ALTER TABLE " + targetTable + " DROP IF EXISTS PARTITION (inc_day='" + dataTime + "')");
        logger.error("新建分区");
        sparkSession.sql("ALTER TABLE " + targetTable + " add if not exists partition(inc_day='" + dataTime + "')");
        String city_str = syncCityList.stream().collect(Collectors.joining("','"));

        String sql = createSql(targetTable, dataTime, dataType,
                city_str);
//		LogUtil.e(sql);
        sparkSession.sql(sql);
    }

    public void syncWaybillAoiToProjectDuomi(String dataType, String dataTime, Set<String> syncCityList) {
        String targetTable = "dm_gis.tt_waybill_aoi_info_dmxq";
        String insertSql = "insert  overwrite table " + targetTable + " partition(inc_day='" + dataTime + "')"
                + " select signin_tm,waybill_no,dest_dist_code,dest_zone_code,aoi_code,aoi_id from "
                + " dm_gis.tt_waybill_hook  ";
        ;
        if (dataType.equals(MapType.shou.name())) {
            targetTable = "dm_gis.tt_order_aoi_info_dmxq";
            insertSql = "insert  overwrite table " + targetTable + " partition(inc_day='" + dataTime + "')"
                    + " select consigned_tm,waybill_no,src_dist_code,source_zone_code,aoi_code,aoi_id from "
                    + " dm_gis.tt_order_hook ";
        }
        insertSql = insertSql + " where inc_day='" + dataTime + "'";
        logger.error("删除分区");
        sparkSession.sql("ALTER TABLE " + targetTable + " DROP IF EXISTS PARTITION (inc_day='" + dataTime + "')");
        logger.error("新建分区");
        sparkSession.sql("ALTER TABLE " + targetTable + " add if not exists partition(inc_day='" + dataTime + "')");
        logger.error("插入sql" + insertSql);
        sparkSession.sql(insertSql);
    }

    /**
     * 获取表名
     *
     * @param project
     * @param dataType
     * @return
     */
    private String fetchTableName(String project, String dataType) {
        if (dataType.equals(MapType.shou.name())) {
            if (project.equals(ProjectType.zhiyu.name())) {
                return "dm_gis.tt_order_aoi_info";
            } else if (project.equals(ProjectType.duomi.name())) {
                return "dm_gis.tt_order_aoi_info_duomi";
            }
        } else if (dataType.equals(MapType.pai.name())) {
            if (project.equals(ProjectType.zhiyu.name())) {
                return "dm_gis.tt_waybill_aoi_info";
            } else if (project.equals(ProjectType.duomi.name())) {
                return "dm_gis.tt_waybill_aoi_info_duomi";
            }
        }
        return null;
    }

    /**
     * 计算治愈项目的新增数据
     *
     * @param configMap
     * @param date
     * @param zhiyuTargetCity
     * @param zhiyuChangeCity
     * @param zhiyuChangedDept
     * @param date
     * @return
     */
    public Long calAddDataCount(Set<String> targetCity, String date, String dataType) {
        String sql = null;
        String dataTimeSql = " inc_day = '" + date + "' ";
        String city = targetCity.stream().collect(Collectors.joining("','"));
        if (dataType.equals(MapType.pai.name())) {
            sql = "select  count(1) from " + UploadWaybillAoiDataToHiveService.TT_WAYBILL_AOI_INFO + " where "
                    + dataTimeSql;
            if (!city.isEmpty()) {
                sql = sql + " and  dest_dist_code in ('" + city + "') ";
            }
        } else if (dataType.equals(MapType.shou.name())) {
            sql = "select  count(1) from " + UploadWaybillAoiDataToHiveService.TT_ORDER_AOI_INFO + " where "
                    + dataTimeSql;
            if (!city.isEmpty()) {
                sql = sql + " and src_dist_code in ('" + city + "') ";
            }
        }

//		LogUtil.e(sql);
        Long count = sparkSession.sql(sql).javaRDD().map(x -> x.getLong(0)).collect().get(0);
        logger.error("count:" + count);
        return count;
    }

    public boolean checkDataExist(String argDate, String dataType) {
        String table = UploadWaybillAoiDataToHiveService.aoi_hook_state_table + dataType;
        String sql = "select * from " + table + " where inc_day='" + argDate + "' "
                + " and state = '1' ";
        long count = sparkSession.sql(sql).javaRDD().count();
        return count > 0;
    }
}
