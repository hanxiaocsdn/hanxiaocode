package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;

@Table
public class Building {
    @Column(name = "id")
    private String id;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "name")
    private String name;
    @Column(name = "alias")
    private String alias;
    @Column(name = "lat")
    private String lat;
    @Column(name = "lng")
    private String lng;
    @Column(name = "city_code")
    private String cityCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @Override
    public String toString() {
        return "Building{" +
                "id='" + id + '\'' +
                ", adcode='" + adcode + '\'' +
                ", aoi='" + aoi + '\'' +
                ", name='" + name + '\'' +
                ", alias='" + alias + '\'' +
                ", lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                ", cityCode='" + cityCode + '\'' +
                '}';
    }
}
