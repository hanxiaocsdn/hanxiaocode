package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.ExecutionRate;
import com.sf.gis.java.sds.service.ExecutionRateService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class ExecutionRateController implements Serializable {
    private Logger logger = LoggerFactory.getLogger(ExecutionRateController.class);
    ExecutionRateService service = new ExecutionRateService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<ExecutionRate> executionRateRdd = service.loadData(spark, sc, date).filter(o -> (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.equals(o.getIsPushLine(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("executionRateRdd cnt:{}", executionRateRdd.count());
            executionRateRdd.take(3).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<ExecutionRate> executionRateResultRdd = executionRateRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<ExecutionRate> list = Lists.newArrayList(tp._2);
                ExecutionRate executionRate = list.get(0);

                //班次数
                int shuttleNumber = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getLineCode()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getLineCode))), ArrayList::new))
                        .size();

                //任务量
                int taskNumber = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //执行量
                int executionNumber = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //自营任务量
                int selfSupportTaskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //自营执行量
                int selfSupportExecutionNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //非自营任务量
                int noSelfSupportTaskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //非自营执行量
                int noSelfSupportExecutionNumber = list.stream()
                        .filter(o -> o.getIsZy() == 0 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                //自营其他执行任务量
                int selfSupportOtherExecutionNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ExecutionRate::getTaskId))), ArrayList::new))
                        .size();

                executionRate.setShuttleNumber(shuttleNumber);
                executionRate.setTaskNumber(taskNumber);
                executionRate.setExecutionNumber(executionNumber);
                executionRate.setSelfSupportTaskNumber(selfSupportTaskNumber);
                executionRate.setSelfSupportExecutionNumber(selfSupportExecutionNumber);
                executionRate.setNoSelfSupportTaskNumber(noSelfSupportTaskNumber);
                executionRate.setNoSelfSupportExecutionNumber(noSelfSupportExecutionNumber);
                executionRate.setSelfSupportOtherExecutionNumber(selfSupportOtherExecutionNumber);

                return executionRate;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("executionRateResultRdd cnt:{}", executionRateResultRdd.count());
            executionRateResultRdd.take(3).forEach(o -> logger.error(JSON.toJSONString(o)));
            executionRateRdd.unpersist();
            if (executionRateResultRdd.count() > 0) {
                if(flag != size){
                    //删除数据
                    spark.sql(String.format("insert overwrite table dm_gis.ETA_EXECUTE_RATE_STAT select * from dm_gis.ETA_EXECUTE_RATE_STAT where stat_date != '%s'",date));
                    service.delete(date);
                }
                service.saveData(spark, executionRateResultRdd);
                service.saveToMysql(sc, executionRateResultRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            executionRateResultRdd.unpersist();
        }
        spark.stop();
    }
}
