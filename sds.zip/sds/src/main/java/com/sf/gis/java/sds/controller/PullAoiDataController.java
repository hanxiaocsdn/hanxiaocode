package com.sf.gis.java.sds.controller;


import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.service.AoiDbService;
import com.sf.gis.java.sds.service.PullAoiDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class PullAoiDataController {
    private static final Logger logger = LoggerFactory.getLogger(PullAoiDataController.class);
    private PullAoiDataService pullAoiService;
    private Map<String, String> configMap;

    public PullAoiDataController(Map<String, String> configMap) {
        pullAoiService = new PullAoiDataService();
        this.configMap = configMap;
    }

    public void start() throws Exception {
        String[] date = findDaysOneByOne(configMap);
        pullAoiService.pullDataByDay(configMap, date);
        clearExpireData();
    }

    /**
     * 清除过期数据
     *
     * @throws Exception
     */
    private void clearExpireData() throws Exception {
        logger.error("删除过期数据，90天前");
        List<String> clear_date = findClearDate(configMap);
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        AoiDbService aoiDbService = new AoiDbService();
        aoiDbService.delete_by_day(clear_date, openCityList);
    }

    /**
     * 获取要清除的最大天数
     *
     * @param configMap
     * @return
     * @throws Exception
     */
    private List<String> findClearDate(Map<String, String> configMap) throws Exception {
        List<String> ret = new ArrayList<>();
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        if (beginDays < 0) {
            throw new Exception("开始天数错误：" + beginDays);
        }
        int clearDays = Integer.valueOf(configMap.get(ConfigKey.clear_expire_data_days.name()));
        for (int i = 0; i < clearDays; i++) {
            ret.add(DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + 90 + i));
        }
        return ret;
    }

    /**
     * 获取天数，列出所有天数
     *
     * @param configMap
     * @return
     */
    private String[] findDaysOneByOne(Map<String, String> configMap) {

        int days = Integer.valueOf(configMap.get(ConfigKey.days.name()));
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        List<String> date = new ArrayList<>();
        for (int i = 0; i < days; i++) {
            date.add(DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + i));
        }
        logger.error(JSON.toJSONString(date));
        return date.toArray(new String[date.size()]);
    }

    /**
     * 获取天数，第一天和最后一天
     *
     * @param configMap
     * @return
     */
    @SuppressWarnings("unused")
    private String[] findDays(Map<String, String> configMap) {

        int days = Integer.valueOf(configMap.get(ConfigKey.days.name()));
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        String[] date = new String[]{DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + days - 1),
                DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays)};
        return date;
    }

}