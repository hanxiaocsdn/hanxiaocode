package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ProductIncUbasNextApp implements Serializable {
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "zonecode")
    private String zonecode;
    @Column(name = "msg")
    private String msg;
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "userid")
    private String userid;
    @Column(name = "type")
    private String type;

    @Column(name = "event_id")
    private String event_id;
    @Column(name = "dt")
    private String dt;


    private String location;
    private String cityCode;
    private String area;
    private String correct_aoi_id;
    private String correct_aoi_name;
    private String error_type;
    private String source;

    private int aoi_internal_cnt;
    private int aoi_between_cnt;
    private int exception_addr_cnt;

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEvent_id() {
        return event_id;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCorrect_aoi_id() {
        return correct_aoi_id;
    }

    public void setCorrect_aoi_id(String correct_aoi_id) {
        this.correct_aoi_id = correct_aoi_id;
    }

    public String getCorrect_aoi_name() {
        return correct_aoi_name;
    }

    public void setCorrect_aoi_name(String correct_aoi_name) {
        this.correct_aoi_name = correct_aoi_name;
    }

    public String getError_type() {
        return error_type;
    }

    public void setError_type(String error_type) {
        this.error_type = error_type;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getAoi_internal_cnt() {
        return aoi_internal_cnt;
    }

    public void setAoi_internal_cnt(int aoi_internal_cnt) {
        this.aoi_internal_cnt = aoi_internal_cnt;
    }

    public int getAoi_between_cnt() {
        return aoi_between_cnt;
    }

    public void setAoi_between_cnt(int aoi_between_cnt) {
        this.aoi_between_cnt = aoi_between_cnt;
    }

    public int getException_addr_cnt() {
        return exception_addr_cnt;
    }

    public void setException_addr_cnt(int exception_addr_cnt) {
        this.exception_addr_cnt = exception_addr_cnt;
    }
}
