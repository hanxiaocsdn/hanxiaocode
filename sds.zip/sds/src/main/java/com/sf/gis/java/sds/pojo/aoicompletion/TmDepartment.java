package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TmDepartment implements Serializable {
    @Column(name = "dept_id")
    private String dept_id;
    @Column(name = "division_code")
    private String division_code;
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "hq_code")
    private String hq_code;
    @Column(name = "type_code")
    private String type_code;
    @Column(name = "dept_name")
    private String dept_name;
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "dept_desc")
    private String dept_desc;
    @Column(name = "created_emp_code")
    private String created_emp_code;
    @Column(name = "created_tm")
    private String created_tm;
    @Column(name = "modified_emp_code")
    private String modified_emp_code;
    @Column(name = "modified_tm")
    private String modified_tm;
    @Column(name = "valid_dt")
    private String valid_dt;
    @Column(name = "dist_code")
    private String dist_code;
    @Column(name = "parent_dept_code")
    private String parent_dept_code;
    @Column(name = "type_level")
    private String type_level;
    @Column(name = "outside_name")
    private String outside_name;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "dept_addr")
    private String dept_addr;
    @Column(name = "postal_code")
    private String postal_code;
    @Column(name = "outside_name_en")
    private String outside_name_en;
    @Column(name = "email_addr")
    private String email_addr;
    @Column(name = "belong_county")
    private String belong_county;
    @Column(name = "belong_village")
    private String belong_village;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "pick_wage_aoi_id")
    private String pick_wage_aoi_id;
    @Column(name = "send_wage_aoi_id")
    private String send_wage_aoi_id;
    @Column(name = "dept_aoi_id")
    private String dept_aoi_id;

    @Column(name = "tag")
    private String tag;

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getDept_aoi_id() {
        return dept_aoi_id;
    }

    public void setDept_aoi_id(String dept_aoi_id) {
        this.dept_aoi_id = dept_aoi_id;
    }

    public String getPick_wage_aoi_id() {
        return pick_wage_aoi_id;
    }

    public void setPick_wage_aoi_id(String pick_wage_aoi_id) {
        this.pick_wage_aoi_id = pick_wage_aoi_id;
    }

    public String getSend_wage_aoi_id() {
        return send_wage_aoi_id;
    }

    public void setSend_wage_aoi_id(String send_wage_aoi_id) {
        this.send_wage_aoi_id = send_wage_aoi_id;
    }

    public String getDept_id() {
        return dept_id;
    }

    public void setDept_id(String dept_id) {
        this.dept_id = dept_id;
    }

    public String getDivision_code() {
        return division_code;
    }

    public void setDivision_code(String division_code) {
        this.division_code = division_code;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getHq_code() {
        return hq_code;
    }

    public void setHq_code(String hq_code) {
        this.hq_code = hq_code;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public String getDept_desc() {
        return dept_desc;
    }

    public void setDept_desc(String dept_desc) {
        this.dept_desc = dept_desc;
    }

    public String getCreated_emp_code() {
        return created_emp_code;
    }

    public void setCreated_emp_code(String created_emp_code) {
        this.created_emp_code = created_emp_code;
    }

    public String getCreated_tm() {
        return created_tm;
    }

    public void setCreated_tm(String created_tm) {
        this.created_tm = created_tm;
    }

    public String getModified_emp_code() {
        return modified_emp_code;
    }

    public void setModified_emp_code(String modified_emp_code) {
        this.modified_emp_code = modified_emp_code;
    }

    public String getModified_tm() {
        return modified_tm;
    }

    public void setModified_tm(String modified_tm) {
        this.modified_tm = modified_tm;
    }

    public String getValid_dt() {
        return valid_dt;
    }

    public void setValid_dt(String valid_dt) {
        this.valid_dt = valid_dt;
    }

    public String getDist_code() {
        return dist_code;
    }

    public void setDist_code(String dist_code) {
        this.dist_code = dist_code;
    }

    public String getParent_dept_code() {
        return parent_dept_code;
    }

    public void setParent_dept_code(String parent_dept_code) {
        this.parent_dept_code = parent_dept_code;
    }

    public String getType_level() {
        return type_level;
    }

    public void setType_level(String type_level) {
        this.type_level = type_level;
    }

    public String getOutside_name() {
        return outside_name;
    }

    public void setOutside_name(String outside_name) {
        this.outside_name = outside_name;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getDept_addr() {
        return dept_addr;
    }

    public void setDept_addr(String dept_addr) {
        this.dept_addr = dept_addr;
    }

    public String getPostal_code() {
        return postal_code;
    }

    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code;
    }

    public String getOutside_name_en() {
        return outside_name_en;
    }

    public void setOutside_name_en(String outside_name_en) {
        this.outside_name_en = outside_name_en;
    }

    public String getEmail_addr() {
        return email_addr;
    }

    public void setEmail_addr(String email_addr) {
        this.email_addr = email_addr;
    }

    public String getBelong_county() {
        return belong_county;
    }

    public void setBelong_county(String belong_county) {
        this.belong_county = belong_county;
    }

    public String getBelong_village() {
        return belong_village;
    }

    public void setBelong_village(String belong_village) {
        this.belong_village = belong_village;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getType_code() {
        return type_code;
    }

    public void setType_code(String type_code) {
        this.type_code = type_code;
    }
}
