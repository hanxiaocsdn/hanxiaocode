package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AoiMaxIndexByGroupW;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 任务id:330285
 * 任务id:335401
 */

public class GroupAoiToCmsService implements Serializable {
    private Logger logger = LoggerFactory.getLogger(GroupAoiToCmsService.class);

    public JavaRDD<AoiMaxIndexByGroupW> loadData(SparkSession spark, JavaSparkContext sc, String incDay) {
        String sql = SqlUtil.getSqlStr("aoi_max_index_by_group_w.sql", incDay, incDay);
        logger.error("aoi_max_index_by_group_w sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiMaxIndexByGroupW.class);
    }

    public JavaRDD<AoiMaxIndexByGroupW> loadUpdateData(SparkSession spark, JavaSparkContext sc, String incDay) {
        String sql = String.format("select * from dm_gis.aoi_max_index_by_group_w_stat where inc_day = '%s'",incDay);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiMaxIndexByGroupW.class);
    }

    public boolean judge(AoiMaxIndexByGroupW o) {
        boolean flag = false;
        String max_r_aoi = o.getMax_r_aoi();
        String max_r_aoi_freq = o.getMax_r_aoi_freq();
        String ts_aoi_code = o.getTs_aoi_code();

        String max_80_aoi = o.getMax_80_aoi();
        String max_80_aoi_freq = o.getMax_80_aoi_freq();

        if (StringUtils.isNotEmpty(max_r_aoi) && StringUtils.isNotEmpty(max_r_aoi_freq) && Double.valueOf(max_r_aoi_freq) > 0.5 && StringUtils.equals(max_r_aoi, ts_aoi_code)
                && !(StringUtils.isNotEmpty(max_80_aoi) && StringUtils.isNotEmpty(max_80_aoi_freq) && Double.valueOf(max_80_aoi_freq) > 0.5 && !StringUtils.equals(max_r_aoi, max_80_aoi))) {
            flag = true;
        }
        return flag;
    }

    public void saveData(SparkSession spark, JavaRDD<AoiMaxIndexByGroupW> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getReq_destcitycode(), o.getGis_to_sys_groupid(), o.getMax_r_aoi(), o.getTs_aoi_id(), o.getAoi_80_code(), o.getStd_addr(),
                    o.getMax_r_aoi_freq(), o.getMax_80_aoi_freq()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"req_destcitycode", "gis_to_sys_groupid", "max_r_aoi", "ts_aoi_id", "80_aoi_code",
                "std_addr", "max_r_aoi_freq", "max_80_aoi_freq"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_max_index_by_group_w_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_max_index_by_group_w_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveCheckData(SparkSession spark, JavaRDD<AoiMaxIndexByGroupW> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getReq_destcitycode(), o.getGis_to_sys_groupid(), o.getMax_r_aoi(), o.getTs_aoi_id(), o.getAoi_80_code(), o.getStd_addr(),
                    o.getMax_r_aoi_freq(), o.getMax_80_aoi_freq(), o.getCmsAoi(), o.getCmsAdcode(), o.getCmsZnoCode()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"req_destcitycode", "gis_to_sys_groupid", "max_r_aoi", "ts_aoi_id", "80_aoi_code",
                "std_addr", "max_r_aoi_freq", "max_80_aoi_freq", "cms_aoi_id", "cms_adcode", "cms_znocode"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_max_index_by_group_w_stat_check_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_max_index_by_group_w_stat_check";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public String runAddrUpdateAoi(String url, String param) {
        String content = "";
        try {
            logger.error("addr update aoi url:{}", url);
            content = UrlUtil.sendPost(url, param);
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runGetCmsAoi(String urlPattern, String cityCode, String addressId) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, cityCode, addressId);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public String runCheckTag(String url, String param) {
        String content = "";
        try {
            logger.error("check tag url:{}", url);
            content = UrlUtil.sendPost(url, param);
            logger.error("content:{}", content);
        } catch (Exception e) {
            logger.error("check tag error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

}
