package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TcAoiRelationship implements Serializable {
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "tccode")
    private String tccode;
    @Column(name = "code")
    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTccode() {
        return tccode;
    }

    public void setTccode(String tccode) {
        this.tccode = tccode;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }
}
