package com.sf.gis.java.sds.pojo;

import scala.Serializable;

import java.util.List;

public class ClusterWifiData implements Serializable {
    //聚类中心点经度
    private String lng;
    //聚类中心点纬度度
    private String lat;
    //聚类中心点指纹数量
    private Long clusterNum;
    //聚类中心点指纹列表
    private List<String> fingerList;
    //聚类中心点指纹坐标列表
    private List<String> points;

    //是否为异常wifi
    private Boolean isErrorWifi=false;

    public Boolean getErrorWifi() {
        return isErrorWifi;
    }

    public void setErrorWifi(Boolean errorWifi) {
        isErrorWifi = errorWifi;
    }



    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public Long getClusterNum() {
        return clusterNum;
    }

    public void setClusterNum(Long clusterNum) {
        this.clusterNum = clusterNum;
    }

    public List<String> getFingerList() {
        return fingerList;
    }

    public void setFingerList(List<String> fingerList) {
        this.fingerList = fingerList;
    }

    public List<String> getPoints() {
        return points;
    }

    public void setPoints(List<String> points) {
        this.points = points;
    }
}
