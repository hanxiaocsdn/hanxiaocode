package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class NewBusinessAreaModelsBuildingRecognitionDetail implements Serializable {
    @Column(name = "temp_aoi")
    private String temp_aoi;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "addr")
    private String addr;
    @Column(name = "resp")
    private String resp;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "building_id")
    private String building_id;
    @Column(name = "inc_day")
    private String inc_day;


    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getBuilding_id() {
        return building_id;
    }

    public void setBuilding_id(String building_id) {
        this.building_id = building_id;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTemp_aoi() {
        return temp_aoi;
    }

    public void setTemp_aoi(String temp_aoi) {
        this.temp_aoi = temp_aoi;
    }
}
