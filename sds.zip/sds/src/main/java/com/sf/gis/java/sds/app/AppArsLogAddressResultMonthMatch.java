package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.ArsLogAddressResultMonthMatch;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.List;

/**
 * 任务id：858162（【地址筛单】可达10月更新筛单数据不一致及新增行政区划命中日志真实地址情况_shell）
 * 业务方：01425247（段嫦慧）
 * 研发：01399581（匡仁衡）
 */
public class AppArsLogAddressResultMonthMatch {
    private static Logger logger = LoggerFactory.getLogger(AppArsLogAddressResultMonthMatch.class);

    public static void main(String[] args) {
        String date = args[0];
        String date1 = args[1];
        String date2 = args[2];
        logger.error("date:{}, date1:{}, date2:{}", date, date1, date2);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppArsLogAddressResultMonthMatch");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql2 = "select citycode pre_city_code,province pre_province,city pre_city,county pre_county,town pre_town,village pre_village,new_tag,pre_tag from dm_gis.inconsistent_and_administrative_division_data";
        JavaPairRDD<String, ArsLogAddressResultMonthMatch> rdd2 = DataUtil.loadData(spark, sc, sql2, ArsLogAddressResultMonthMatch.class).mapToPair(o -> new Tuple2<>(o.getPre_city_code() + o.getPre_province() + o.getPre_city() + o.getPre_county() + o.getPre_town() + o.getPre_village(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd2 cnt:{}", rdd2.count());

        List<String> dates = DateUtil.getDateList(date1, date2, "yyyyMMdd");
        for (String s : dates) {
            logger.error("process date:{}", s);
            String sql1 = String.format("select\n" +
                    "  get_json_object(get_json_object(log,'$.message'),'$.sn') sn,\n" +
                    "  get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.ak') ak,\n" +
                    "  get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'), '$.province') province,\n" +
                    "  get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.city') city,\n" +
                    "  get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'), '$.district') district,\n" +
                    "  get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'), '$.address') address,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'), '$.result' ),'$.city_code' ) pre_city_code,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.province') pre_province,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.city') pre_city,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.county') pre_county,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.town') pre_town,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.village') pre_village,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.district'),'$.detailinfo') pre_detailinfo,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'),'$.source') pre_source,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result'), '$.src') pre_src,\n" +
                    "  get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'), '$.data'),'$.result' ),'$.result') pre_result,\n" +
                    "  inc_day\n" +
                    "from\n" +
                    "  dm_gis.bee_logs_gis_ar_collect\n" +
                    "where\n" +
                    "  inc_day between '%s'\n" +
                    "  and '%s'\n" +
                    "  and log like '%%url_e%%'", s, s);

            JavaRDD<ArsLogAddressResultMonthMatch> rdd1 = DataUtil.loadData(spark, sc, sql1, ArsLogAddressResultMonthMatch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd1 cnt:{}", rdd1.count());

            JavaRDD<ArsLogAddressResultMonthMatch> uniqueRdd = rdd1.map(o -> {
                o.setFreq("1");
                return o;
            }).mapToPair(o -> new Tuple2<>(o.getProvince() + o.getCity() + o.getDistrict() + o.getAddress() + o.getPre_province() + o.getPre_city() + o.getPre_county() + o.getPre_town() + o.getPre_village() + o.getPre_result() + o.getPre_src() + o.getPre_source(), o))
                    .reduceByKey((o1, o2) -> {
                        o1.setFreq((Integer.parseInt(o1.getFreq()) + Integer.parseInt(o2.getFreq())) + "");
                        return o1;
                    }).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("uniqueRdd cnt:{}", uniqueRdd.count());
            rdd1.unpersist();

//            JavaRDD<ArsLogAddressResultMonthMatch> lastRdd = uniqueRdd.mapToPair(o -> new Tuple2<>(o.getPre_city_code() + o.getPre_province() + o.getPre_city() + o.getPre_county() + o.getPre_town() + o.getPre_village(), o))
//                    .leftOuterJoin(rdd2).filter(tp -> {
//                        return tp._2._2 != null && tp._2._2.isPresent();
//                    }).map(tp -> {
//                        ArsLogAddressResultMonthMatch o = tp._2._1;
//                        ArsLogAddressResultMonthMatch o1 = tp._2._2.get();
//
//                        o.setNew_tag(o1.getNew_tag());
//                        o.setPre_tag(o1.getPre_tag());
//                        o.setOper_date(date);
//                        return o;
//                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("lastRdd cnt:{}", lastRdd.count());
//            uniqueRdd.unpersist();

            DataUtil.saveInto(spark, sc, "dm_gis.ars_log_address_result_month_match", ArsLogAddressResultMonthMatch.class, uniqueRdd, "oper_date");
            uniqueRdd.unpersist();
        }
        rdd2.unpersist();

//        String sql = String.format("select * from dm_gis.ars_log_address_result_month_match where oper_date = '%s'", date);
//        JavaRDD<ArsLogAddressResultMonthMatch> tempRdd = DataUtil.loadData(spark, sc, sql, ArsLogAddressResultMonthMatch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("tempRdd cnt:{}", tempRdd.count());
//
//        JavaRDD<ArsLogAddressResultMonthMatch> resultRdd = tempRdd.mapToPair(o -> new Tuple2<>(o.getProvince() + o.getCity() + o.getDistrict() + o.getAddress() + o.getPre_province() + o.getPre_city() + o.getPre_county() + o.getPre_town() + o.getPre_village() + o.getPre_result(), o))
//                .reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        tempRdd.unpersist();
//
//        DataUtil.saveOverwrite(spark, sc, "dm_gis.ars_log_address_result_month_match_last", ArsLogAddressResultMonthMatch.class, resultRdd, "oper_date");
//        resultRdd.unpersist();

        sc.stop();
    }
}
