package com.sf.gis.java.sds.kafka;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OmsLogToHive {
    public static Logger logger = LoggerFactory.getLogger(OmsLogToHive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("omskafka2hive.properties", OmsLogToHive.class.getName());
    }
}
