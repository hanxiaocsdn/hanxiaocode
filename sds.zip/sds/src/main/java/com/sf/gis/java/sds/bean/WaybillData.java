package com.sf.gis.java.sds.bean;


public class WaybillData {
    private String waybill_no;
    private String citycode;
    private String zno_code;
    private String address;
    private String inc_day;
    private String dataType;
    private String company;
    private String phone;
    private String mobile;
    private String province;
    private String country;
    private String contName;
    private String aoiId;
    private String aoiName;
    private String aoiAlias;
    private String aoiAddress;
    private String aoiX;
    private String aoiY;
    private String aoiCode;
    private String groupId;
    private String teamCode;
    public WaybillData() {
    }

    public WaybillData(String waybill_no, String citycode, String zno_code, String address, String inc_day,
                       String dataType, String company, String phone, String mobile, String province, String country,
                       String contName) {
        this.waybill_no = waybill_no;
        this.citycode = citycode;
        this.zno_code = zno_code;
        this.address = address;
        this.inc_day = inc_day;
        this.dataType = dataType;
        this.company = company;
        this.phone = phone;
        this.mobile = mobile;
        this.province = province;
        this.country = country;
        this.contName = contName;
    }

    public WaybillData(String waybill_no, String citycode, String zno_code, String inc_day, String dataType,
                       String phone, String mobile, String contName, String aoiId, String aoiName, String aoiAlias,
                       String aoiAddress, String aoiX, String aoiY) {
        this.waybill_no = waybill_no;
        this.citycode = citycode;
        this.zno_code = zno_code;
        this.inc_day = inc_day;
        this.dataType = dataType;
        this.phone = phone;
        this.mobile = mobile;
        this.contName = contName;
        this.aoiId = aoiId;
        this.aoiName = aoiName;
        this.aoiAlias = aoiAlias;
        this.aoiAddress = aoiAddress;
        this.aoiX = aoiX;
        this.aoiY = aoiY;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getContName() {
        return contName;
    }

    public void setContName(String contName) {
        this.contName = contName;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getAoiAlias() {
        return aoiAlias;
    }

    public void setAoiAlias(String aoiAlias) {
        this.aoiAlias = aoiAlias;
    }

    public String getAoiAddress() {
        return aoiAddress;
    }

    public void setAoiAddress(String aoiAddress) {
        this.aoiAddress = aoiAddress;
    }

    public String getAoiX() {
        return aoiX;
    }

    public void setAoiX(String aoiX) {
        this.aoiX = aoiX;
    }

    public String getAoiY() {
        return aoiY;
    }

    public void setAoiY(String aoiY) {
        this.aoiY = aoiY;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

}
