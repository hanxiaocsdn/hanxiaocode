package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CgcsSgsAoiExp;
import com.sf.gis.java.sds.pojo.TaskAoiid;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Serializable;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AppXiaoGeMoneyController1 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AppXiaoGeMoneyController1.class);

    public void start(String startDate, String endDate, String loadDate, String today) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> precisionGdUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=c2ee00ecb0164098b58569b5bdffe60d&opt=gd2&address=%s&city=%s");
        Broadcast<String> aoiidurlBc = sc.broadcast("http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=dec044d089524419b371bc94555c539d");
        Broadcast<String> rgsbAddUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd");
        Broadcast<String> aoiCheckTagUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck");
        Broadcast<String> updateAddressIdUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId");

        JavaRDD<CgcsSgsAoiExp> operTagRdd = loadXiaoge_moneyexp(spark, sc, loadDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("operTagRdd cnt:{}", operTagRdd.count());

        JavaRDD<CgcsSgsAoiExp> operTag40Rdd = operTagRdd.filter(o -> StringUtils.equals(o.getTag(), "40")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> operTag31Or41Rdd = operTagRdd.filter(o -> StringUtils.equals(o.getTag(), "31") || StringUtils.equals(o.getTag(), "41")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("operTag40Rdd cnt:{}, operTag31Or41Rdd cnt:{}", operTag40Rdd.count(), operTag31Or41Rdd.count());
        operTagRdd.unpersist();

        JavaRDD<TaskAoiid> taskAoiidRdd = getTaskAoiid(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("taskAoiidRdd cnt:{}", taskAoiidRdd.count());

        JavaRDD<CgcsSgsAoiExp> xyRdd = operTag40Rdd.map(o -> {
            String std_addr = o.getStd_addr();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(std_addr)) {
                String content = runXy(precisionGdUrlBc.value(), std_addr, city_code, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                        JSONObject resultJson = jsonObject.getJSONObject("result");
                        if (resultJson != null) {
                            String xcoord = resultJson.getString("xcoord");
                            String ycoord = resultJson.getString("ycoord");
                            logger.error("xcoord:{}", xcoord);
                            logger.error("ycoord:{}", ycoord);
                            o.setGd_x(xcoord);
                            o.setGd_y(ycoord);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xyRdd cnt:{}", xyRdd.count());
        operTag40Rdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> gdAoiRdd = xyRdd.map(o -> {
            String gd_x = o.getGd_x();
            String gd_y = o.getGd_y();
            if (StringUtils.isNotEmpty(gd_x) && StringUtils.isNotEmpty(gd_y)) {
                String content = runAoi(aoiidurlBc.value(), gd_x, gd_y, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    if (org.apache.commons.lang.StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject1 = JSON.parseObject(content);
                        Integer status = jsonObject1.getInteger("status");
                        if (status == 0) {
                            JSONObject result = jsonObject1.getJSONObject("result");
                            JSONArray aoi_data = result.getJSONArray("aoi_data");
                            if (aoi_data.size() > 0) {
                                String gdaoi_id = aoi_data.getJSONObject(0).getString("aoi_id");
                                logger.error("gdaoi_id:{}", gdaoi_id);
                                o.setGd_aoiid(gdaoi_id);
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdAoiRdd cnt:{}", gdAoiRdd.count());
        xyRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> stdTaskAoiidRdd = gdAoiRdd.mapToPair(o -> new Tuple2<>(o.getStd_addr(), o))
                .leftOuterJoin(taskAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    CgcsSgsAoiExp o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TaskAoiid taskAoiid = tp._2._2.get();
                        o.setStd_task_aoiid(taskAoiid.getCheck_aoi_id());
                        o.setCheck_dept_code(taskAoiid.getCheck_dept_code());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdTaskAoiidRdd cnt:{}", stdTaskAoiidRdd.count());
        gdAoiRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> eqAoiIdRdd = stdTaskAoiidRdd.filter(o -> StringUtils.equals(o.getStd_aoiid(), o.getGd_aoiid()) || StringUtils.equals(o.getStd_aoiid(), o.getStd_task_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> noEqAoiIdRdd = stdTaskAoiidRdd.filter(o -> !(StringUtils.equals(o.getStd_aoiid(), o.getGd_aoiid()) || StringUtils.equals(o.getStd_aoiid(), o.getStd_task_aoiid()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqAoiIdRdd cnt:{}", eqAoiIdRdd.count());
        logger.error("noEqAoiIdRdd cnt:{}", noEqAoiIdRdd.count());
        stdTaskAoiidRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag40_5Rdd = eqAoiIdRdd.map(o -> {
            String tag = "";
            if (StringUtils.equals(o.getGd_aoiid(), o.getStd_task_aoiid())) {
                tag = "40_51";
            } else {
                tag = "40_50";
            }
            o.setTag(tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag40_5Rdd cnt:{}", tag40_5Rdd.count());
        eqAoiIdRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> finalEqRdd = noEqAoiIdRdd.filter(o -> (StringUtils.isNotEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getGd_aoiid(), o.getXg_aoiid())) || (StringUtils.isNotEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getGd_aoiid(), o.getStd_task_aoiid())) || (StringUtils.isEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getStd_task_aoiid(), o.getXg_aoiid()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> finalNoEqRdd = noEqAoiIdRdd.filter(o -> !((StringUtils.isNotEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getGd_aoiid(), o.getXg_aoiid())) || (StringUtils.isNotEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getGd_aoiid(), o.getStd_task_aoiid())) || (StringUtils.isEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getStd_task_aoiid(), o.getXg_aoiid())))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalEqRdd cnt:{}", finalEqRdd.count());
        logger.error("finalNoEqRdd cnt:{}", finalNoEqRdd.count());
        noEqAoiIdRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag40_61Rdd = finalEqRdd.map(o -> {
            o.setTag("40_61");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag40_61Rdd cnt:{}", tag40_61Rdd.count());
        finalEqRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag40_60Rdd = finalNoEqRdd.map(o -> {
            o.setTag("40_60");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag40_60Rdd cnt:{}", tag40_60Rdd.count());
        finalNoEqRdd.unpersist();

        //oper=31 or oper=41 && 40_60
        JavaRDD<CgcsSgsAoiExp> flagRdd = operTag31Or41Rdd.mapToPair(o -> new Tuple2<>(o.getConsignee_addr(), o))
                .leftOuterJoin(taskAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    CgcsSgsAoiExp cgcsSgsAoiExp = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TaskAoiid o = tp._2._2.get();
                        cgcsSgsAoiExp.setCons_task_aoiid(o.getCheck_aoi_id());
                        cgcsSgsAoiExp.setCheck_dept_code(o.getCheck_dept_code());
                    }
                    return cgcsSgsAoiExp;
                }).filter(o -> StringUtils.isNotEmpty(o.getXg_aoiid()) && StringUtils.equals(o.getCons_task_aoiid(), o.getXg_aoiid()))
                .union(tag40_60Rdd.filter(o -> StringUtils.isNotEmpty(o.getXg_aoiid()) && StringUtils.equals(o.getStd_task_aoiid(), o.getXg_aoiid())))
                .map(o -> {
                    String city_code = o.getCity_code();
                    String consignee_addr = o.getConsignee_addr();
                    String check_dept_code = o.getCheck_dept_code();
                    String aoi = o.getXg_aoiid();

                    JSONObject param = new JSONObject();
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("cityCode", city_code);
                    jsonObject.put("address", consignee_addr);
                    jsonObject.put("znoCode", check_dept_code);
                    jsonObject.put("aoiId", aoi);
                    jsonObject.put("aoiSource", "S99");
                    param.put("ak", "3a191e7427e8470c86271a069411c66b");
//                    jsonObject.put("src", "0");
                    param.put("operSource", "xiaoge_moneyexp");
                    param.put("operUserName", "01412989");
                    param.put("addressSave", jsonObject);

                    String content = run(rgsbAddUrlBc.value(), param.toJSONString());
                    logger.error("content:{}", content);
                    o.setRgsbAddContent(content);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject result = JSON.parseObject(content);
                        if (result != null) {
                            String flag = result.getString("success");
                            o.setFlag(flag);
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("flagRdd cnt:{}", flagRdd.count());
        logger.error("empty cnt:{}", flagRdd.filter(o -> StringUtils.isEmpty(o.getFlag())).count());
        logger.error("sucess cnt:{}", flagRdd.filter(o -> StringUtils.equals(o.getFlag(), "true")).count());
        logger.error("false cnt:{}", flagRdd.filter(o -> StringUtils.equals(o.getFlag(), "false")).count());
        operTag31Or41Rdd.unpersist();
        tag40_60Rdd.unpersist();

        //oper=40_51
        JavaRDD<CgcsSgsAoiExp> checkRdd = tag40_5Rdd.filter(o -> StringUtils.equals(o.getTag(), "40_51"))
                .mapToPair(o -> new Tuple2<>(o.getStd_addr(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .map(o -> {
                    String city_code = o.getCity_code();
                    String gis_to_sys_groupid = o.getGroupid();
                    if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                        JSONArray list = new JSONArray();
                        list.add(gis_to_sys_groupid);

                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("cityCode", city_code);
                        jsonObject.put("aoiCheckTag", 1);
                        jsonObject.put("addressIds", list);

                        String content = run(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                        logger.error("content:{}", content);
                        o.setAoiCheckTagContent(content);
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject1 = JSON.parseObject(content);
                            if (jsonObject != null) {
                                String success = jsonObject1.getString("success");
                                o.setFlag(success);
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd cnt:{}", checkRdd.count());
        checkRdd.map(o -> o.getAoiCheckTagContent()).filter(o -> StringUtils.isNotEmpty(o)).take(10).forEach(o -> logger.error(o));
        logger.error("empty cnt:{}", checkRdd.filter(o -> StringUtils.isEmpty(o.getFlag())).count());
        logger.error("sucess cnt:{}", checkRdd.filter(o -> StringUtils.equals(o.getFlag(), "true")).count());
        logger.error("false cnt:{}", checkRdd.filter(o -> StringUtils.equals(o.getFlag(), "false")).count());

        tag40_5Rdd.unpersist();

        //oper=40_61
        JavaRDD<CgcsSgsAoiExp> updateAddrRdd = tag40_61Rdd.map(o -> {
            String city_code = o.getCity_code();
            String addressId = o.getGroupid();
            String aoi = "";

            if (StringUtils.equals(o.getGd_aoiid(), o.getXg_aoiid())) {
                aoi = o.getGd_aoiid();
            } else if (StringUtils.equals(o.getGd_aoiid(), o.getStd_task_aoiid())) {
                aoi = o.getGd_aoiid();
            } else if (StringUtils.isEmpty(o.getGd_aoiid()) && StringUtils.equals(o.getStd_task_aoiid(), o.getXg_aoiid())) {
                aoi = o.getStd_task_aoiid();
            }

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("cityCode", city_code);
            jsonObject.put("addressId", addressId);
            jsonObject.put("aoiId", aoi);
            jsonObject.put("checkZnoCode", "1");
            jsonObject.put("operSource", "xiaoge_moneyexp");
            jsonObject.put("operUserName", "01412989");
            String content = run(updateAddressIdUrlBc.value(), jsonObject.toJSONString());
            logger.error("content:{}", content);
            o.setUpdateAddressIdContent(content);
            if (StringUtils.isNotEmpty(content)) {
                JSONObject result = JSON.parseObject(content);
                if (result != null) {
                    String success = result.getString("success");
                    o.setFlag(success);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("updateAddrRdd cnt:{}", updateAddrRdd.count());
        updateAddrRdd.map(o -> o.getUpdateAddressIdContent()).filter(o -> StringUtils.isNotEmpty(o)).take(10).forEach(o -> logger.error(o));
        logger.error("empty cnt:{}", updateAddrRdd.filter(o -> StringUtils.isEmpty(o.getFlag())).count());
        logger.error("sucess cnt:{}", updateAddrRdd.filter(o -> StringUtils.equals(o.getFlag(), "true")).count());
        logger.error("false cnt:{}", updateAddrRdd.filter(o -> StringUtils.equals(o.getFlag(), "false")).count());
        tag40_61Rdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> resultRdd = checkRdd.union(updateAddrRdd).union(flagRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        checkRdd.unpersist();
        updateAddrRdd.unpersist();
        flagRdd.unpersist();

        String executeSql = String.format("alter table dm_gis.xiaoge_moneyexp_2 drop if EXISTS partition(inc_day='%s')", today);
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, resultRdd, "dm_gis.xiaoge_moneyexp_2", today);

        spark.stop();
    }

    public JavaRDD<CgcsSgsAoiExp> loadXiaoge_moneyexp(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select city_code,std_addr,consignee_addr,std_aoiid,xg_aoiid,oper tag,groupid from dm_gis.xiaoge_moneyexp where inc_day = '%s' and oper in ('40', '31', '41')", date);
        logger.error("xiaoge_moneyexp sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
    }

    public JavaRDD<TaskAoiid> getTaskAoiid(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select address,check_aoi_id,check_dept_code from dm_gis.dm_cgcs_check_info_df where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TaskAoiid.class);
    }

    public String runXy(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runAoi(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            logger.error("aoi url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request aoi error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public void saveData(SparkSession spark, JavaRDD<CgcsSgsAoiExp> inRdd, String targetTable, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getCity_code(), o.getConsignee_addr(), o.getXg_aoiid(), o.getAddressee_aoi_type(), o.getFinalaoiid(), o.getFinalzc(), o.getVague_tag(),
                    o.getMark(), o.getStd_addr(), o.getGroupid(), o.getStd_aoiid(), o.getGd_x(), o.getGd_y(), o.getGd_aoiid(), o.getStd_task_aoiid(), o.getCons_task_aoiid(), o.getTag(), o.getStd_dept()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "waybill_no", "city_code", "consignee_addr", "xg_aoiid", "aoi_type", "finalaoiid", "finalzc", "vague_tag",
                "mark", "std_addr", "groupid", "std_aoiid", "gd_x", "gd_y", "gd_aoiid", "std_task_aoiid", "cons_task_aoiid", "oper", "std_dept"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "xiaoge_moneyexp_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);
    }

    public String run(String url, String param) {
        String content = "";
        try {
            logger.error("url:{}", url);
            content = UrlUtil.sendPost(url, param);
        } catch (Exception e) {
            logger.error("error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }
}
