package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class PjMisjudgmentMultiSourceCorrectionAoi implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "delivery_lgt")
    private String delivery_lgt;
    @Column(name = "delivery_lat")
    private String delivery_lat;
    @Column(name = "inc_day_gd")
    private String inc_day_gd;
    @Column(name = "req_waybillno")
    private String req_waybillno;
    @Column(name = "req_destcitycode")
    private String req_destcitycode;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "req_time")
    private String req_time;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "80_aoi_code")
    private String aoi_code_80;
    @Column(name = "80_aoi_name")
    private String aoi_name_80;
    @Column(name = "aoi80")
    private String aoi80;
    @Column(name = "znocode80")
    private String znocode80;
    @Column(name = "fa_type80")
    private String fa_type80;

    @Column(name = "at_aoiid")
    private String at_aoiid;
    @Column(name = "at_aoicode")
    private String at_aoicode;
    @Column(name = "at_aoisrc")
    private String at_aoisrc;
    @Column(name = "at_deptcode")
    private String at_deptcode;
    @Column(name = "at_groupid")
    private String at_groupid;

    @Column(name = "std_address")
    private String std_address;
    @Column(name = "cms_adcode")
    private String cms_adcode;
    @Column(name = "cms_aoi")
    private String cms_aoi;
    @Column(name = "cms_znocode")
    private String cms_znocode;

    @Column(name = "xcoord")
    private String xcoord;
    @Column(name = "ycoord")
    private String ycoord;
    @Column(name = "geo_aoiid")
    private String geo_aoiid;
    @Column(name = "gdaoi")
    private String gdaoi;
    @Column(name = "freq")
    private String freq;
    @Column(name = "update_result")
    private String update_result;
    @Column(name = "cms_fa_type")
    private String cms_fa_type;
    @Column(name = "updatetag_result")
    private String updatetag_result;
    @Column(name = "inc_day")
    private String inc_day;

    public String getUpdatetag_result() {
        return updatetag_result;
    }

    public void setUpdatetag_result(String updatetag_result) {
        this.updatetag_result = updatetag_result;
    }

    public String getCms_fa_type() {
        return cms_fa_type;
    }

    public void setCms_fa_type(String cms_fa_type) {
        this.cms_fa_type = cms_fa_type;
    }

    public String getUpdate_result() {
        return update_result;
    }

    public void setUpdate_result(String update_result) {
        this.update_result = update_result;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getGdaoi() {
        return gdaoi;
    }

    public void setGdaoi(String gdaoi) {
        this.gdaoi = gdaoi;
    }

    public String getGeo_aoiid() {
        return geo_aoiid;
    }

    public void setGeo_aoiid(String geo_aoiid) {
        this.geo_aoiid = geo_aoiid;
    }

    public String getXcoord() {
        return xcoord;
    }

    public void setXcoord(String xcoord) {
        this.xcoord = xcoord;
    }

    public String getYcoord() {
        return ycoord;
    }

    public void setYcoord(String ycoord) {
        this.ycoord = ycoord;
    }

    public String getStd_address() {
        return std_address;
    }

    public void setStd_address(String std_address) {
        this.std_address = std_address;
    }

    public String getCms_adcode() {
        return cms_adcode;
    }

    public void setCms_adcode(String cms_adcode) {
        this.cms_adcode = cms_adcode;
    }

    public String getCms_aoi() {
        return cms_aoi;
    }

    public void setCms_aoi(String cms_aoi) {
        this.cms_aoi = cms_aoi;
    }

    public String getCms_znocode() {
        return cms_znocode;
    }

    public void setCms_znocode(String cms_znocode) {
        this.cms_znocode = cms_znocode;
    }

    public String getAt_aoiid() {
        return at_aoiid;
    }

    public void setAt_aoiid(String at_aoiid) {
        this.at_aoiid = at_aoiid;
    }

    public String getAt_aoicode() {
        return at_aoicode;
    }

    public void setAt_aoicode(String at_aoicode) {
        this.at_aoicode = at_aoicode;
    }

    public String getAt_aoisrc() {
        return at_aoisrc;
    }

    public void setAt_aoisrc(String at_aoisrc) {
        this.at_aoisrc = at_aoisrc;
    }

    public String getAt_deptcode() {
        return at_deptcode;
    }

    public void setAt_deptcode(String at_deptcode) {
        this.at_deptcode = at_deptcode;
    }

    public String getAt_groupid() {
        return at_groupid;
    }

    public void setAt_groupid(String at_groupid) {
        this.at_groupid = at_groupid;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getDelivery_lgt() {
        return delivery_lgt;
    }

    public void setDelivery_lgt(String delivery_lgt) {
        this.delivery_lgt = delivery_lgt;
    }

    public String getDelivery_lat() {
        return delivery_lat;
    }

    public void setDelivery_lat(String delivery_lat) {
        this.delivery_lat = delivery_lat;
    }

    public String getInc_day_gd() {
        return inc_day_gd;
    }

    public void setInc_day_gd(String inc_day_gd) {
        this.inc_day_gd = inc_day_gd;
    }

    public String getReq_waybillno() {
        return req_waybillno;
    }

    public void setReq_waybillno(String req_waybillno) {
        this.req_waybillno = req_waybillno;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getReq_time() {
        return req_time;
    }

    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getAoi_code_80() {
        return aoi_code_80;
    }

    public void setAoi_code_80(String aoi_code_80) {
        this.aoi_code_80 = aoi_code_80;
    }

    public String getAoi_name_80() {
        return aoi_name_80;
    }

    public void setAoi_name_80(String aoi_name_80) {
        this.aoi_name_80 = aoi_name_80;
    }

    public String getAoi80() {
        return aoi80;
    }

    public void setAoi80(String aoi80) {
        this.aoi80 = aoi80;
    }

    public String getZnocode80() {
        return znocode80;
    }

    public void setZnocode80(String znocode80) {
        this.znocode80 = znocode80;
    }

    public String getFa_type80() {
        return fa_type80;
    }

    public void setFa_type80(String fa_type80) {
        this.fa_type80 = fa_type80;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
