package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.GisRdsOmsfromController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppGisRdsOmsfrom {
    private static Logger logger = LoggerFactory.getLogger(AppGisRdsOmsfrom.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new GisRdsOmsfromController().start(date);
        logger.error("run end");
    }
}
