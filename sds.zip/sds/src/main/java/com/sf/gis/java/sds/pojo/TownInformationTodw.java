package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TownInformationTodw implements Serializable {
    @Column(name = "agent_code")
    private String agent_code;
    @Column(name = "town")
    private String town;
    @Column(name = "biz_type")
    private String biz_type;
    @Column(name = "district_code")
    private String district_code;
    @Column(name = "village_name")
    private String village_name;
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "area_name")
    private String area_name;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "parent_dept_code")
    private String parent_dept_code;
    @Column(name = "parent_longitude")
    private String parent_longitude;
    @Column(name = "parent_latitude")
    private String parent_latitude;
    @Column(name = "dept_to_parent_dept_dist")
    private String dept_to_parent_dept_dist;
    @Column(name = "area_sum")
    private String area_sum;
    @Column(name = "rk_sum")
    private String rk_sum;
    @Column(name = "town_cnt")
    private String town_cnt;
    @Column(name = "village_cnt")
    private String village_cnt;
    @Column(name = "resp")
    private String resp;
    @Column(name = "agent_dist")
    private String agent_dist;
    @Column(name = "agent_time")
    private String agent_time;
    @Column(name = "ftkj_resp")
    private String ftkj_resp;
    @Column(name = "inc_day")
    private String inc_day;

    private String centerx;
    private String centery;
    private String center_xy_str;
    private int area;
    private int rk;

    public String getFtkj_resp() {
        return ftkj_resp;
    }

    public void setFtkj_resp(String ftkj_resp) {
        this.ftkj_resp = ftkj_resp;
    }

    public String getAgent_dist() {
        return agent_dist;
    }

    public void setAgent_dist(String agent_dist) {
        this.agent_dist = agent_dist;
    }

    public String getAgent_time() {
        return agent_time;
    }

    public void setAgent_time(String agent_time) {
        this.agent_time = agent_time;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getTown_cnt() {
        return town_cnt;
    }

    public void setTown_cnt(String town_cnt) {
        this.town_cnt = town_cnt;
    }

    public String getVillage_cnt() {
        return village_cnt;
    }

    public void setVillage_cnt(String village_cnt) {
        this.village_cnt = village_cnt;
    }

    public String getVillage_name() {
        return village_name;
    }

    public void setVillage_name(String village_name) {
        this.village_name = village_name;
    }

    public String getArea_sum() {
        return area_sum;
    }

    public void setArea_sum(String area_sum) {
        this.area_sum = area_sum;
    }

    public String getRk_sum() {
        return rk_sum;
    }

    public void setRk_sum(String rk_sum) {
        this.rk_sum = rk_sum;
    }

    public int getArea() {
        return area;
    }

    public void setArea(int area) {
        this.area = area;
    }

    public int getRk() {
        return rk;
    }

    public void setRk(int rk) {
        this.rk = rk;
    }

    public String getDept_to_parent_dept_dist() {
        return dept_to_parent_dept_dist;
    }

    public void setDept_to_parent_dept_dist(String dept_to_parent_dept_dist) {
        this.dept_to_parent_dept_dist = dept_to_parent_dept_dist;
    }

    public String getCenter_xy_str() {
        return center_xy_str;
    }

    public void setCenter_xy_str(String center_xy_str) {
        this.center_xy_str = center_xy_str;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getParent_dept_code() {
        return parent_dept_code;
    }

    public void setParent_dept_code(String parent_dept_code) {
        this.parent_dept_code = parent_dept_code;
    }

    public String getParent_longitude() {
        return parent_longitude;
    }

    public void setParent_longitude(String parent_longitude) {
        this.parent_longitude = parent_longitude;
    }

    public String getParent_latitude() {
        return parent_latitude;
    }

    public void setParent_latitude(String parent_latitude) {
        this.parent_latitude = parent_latitude;
    }

    public String getCenterx() {
        return centerx;
    }

    public void setCenterx(String centerx) {
        this.centerx = centerx;
    }

    public String getCentery() {
        return centery;
    }

    public void setCentery(String centery) {
        this.centery = centery;
    }

    public String getAgent_code() {
        return agent_code;
    }

    public void setAgent_code(String agent_code) {
        this.agent_code = agent_code;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getBiz_type() {
        return biz_type;
    }

    public void setBiz_type(String biz_type) {
        this.biz_type = biz_type;
    }

    public String getDistrict_code() {
        return district_code;
    }

    public void setDistrict_code(String district_code) {
        this.district_code = district_code;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
