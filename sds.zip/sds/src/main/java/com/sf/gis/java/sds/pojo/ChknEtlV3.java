package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ChknEtlV3 implements Serializable {
    @Column(name = "is_vague_addr")
    private String is_vague_addr;
    @Column(name = "norm_is_identify")
    private String norm_is_identify;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "chknid")
    private String chknid;
    @Column(name = "address")
    private String address;
    @Column(name = "dept_chkn")
    private String dept_chkn;
    @Column(name = "dept_norm")
    private String dept_norm;
    @Column(name = "dept_equal1")
    private String dept_equal1;
    @Column(name = "aoiid_norm")
    private String aoiid_norm;
    @Column(name = "aoiname_norm")
    private String aoiname_norm;
    @Column(name = "aoiid_chkn")
    private String aoiid_chkn;
    @Column(name = "aoiname_chkn")
    private String aoiname_chkn;
    @Column(name = "group_id")
    private String group_id;
    @Column(name = "standard")
    private String standard;
    @Column(name = "splitinfo_chkn")
    private String splitinfo_chkn;
    @Column(name = "norm_rsp")
    private String norm_rsp;

    @Column(name = "xcoord_chkn")
    private String xcoord_chkn;
    @Column(name = "ycoord_chkn")
    private String ycoord_chkn;
    @Column(name = "xcoord_norm")
    private String xcoord_norm;
    @Column(name = "ycoord_norm")
    private String ycoord_norm;
    @Column(name = "distance")
    private String distance;

    @Column(name = "label")
    private String label;
    @Column(name = "score")
    private String score;
    @Column(name = "aoiid_chkn_ks16")
    private String aoiid_chkn_ks16;
    @Column(name = "splitinfo_norm")
    private String splitinfo_norm;
    @Column(name = "keyword_chkn")
    private String keyword_chkn;
    @Column(name = "address_nokeyword")
    private String address_nokeyword;
    @Column(name = "afterdept_nokeyword")
    private String afterdept_nokeyword;

    @Column(name = "result_mgeo_aoidistance")
    private String result_mgeo_aoidistance;
    @Column(name = "result_mgeo_ks16chknaoi")
    private String result_mgeo_ks16chknaoi;
    @Column(name = "result_nokeyword_dept")
    private String result_nokeyword_dept;
    @Column(name = "unmatch_result_combine")
    private String unmatch_result_combine;
    @Column(name = "match_resp")
    private String match_resp;
    @Column(name = "inc_day")
    private String inc_day;

    public String getMatch_resp() {
        return match_resp;
    }

    public void setMatch_resp(String match_resp) {
        this.match_resp = match_resp;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getUnmatch_result_combine() {
        return unmatch_result_combine;
    }

    public void setUnmatch_result_combine(String unmatch_result_combine) {
        this.unmatch_result_combine = unmatch_result_combine;
    }

    public String getResult_mgeo_aoidistance() {
        return result_mgeo_aoidistance;
    }

    public void setResult_mgeo_aoidistance(String result_mgeo_aoidistance) {
        this.result_mgeo_aoidistance = result_mgeo_aoidistance;
    }

    public String getResult_mgeo_ks16chknaoi() {
        return result_mgeo_ks16chknaoi;
    }

    public void setResult_mgeo_ks16chknaoi(String result_mgeo_ks16chknaoi) {
        this.result_mgeo_ks16chknaoi = result_mgeo_ks16chknaoi;
    }

    public String getResult_nokeyword_dept() {
        return result_nokeyword_dept;
    }

    public void setResult_nokeyword_dept(String result_nokeyword_dept) {
        this.result_nokeyword_dept = result_nokeyword_dept;
    }

    public String getAfterdept_nokeyword() {
        return afterdept_nokeyword;
    }

    public void setAfterdept_nokeyword(String afterdept_nokeyword) {
        this.afterdept_nokeyword = afterdept_nokeyword;
    }

    public String getAddress_nokeyword() {
        return address_nokeyword;
    }

    public void setAddress_nokeyword(String address_nokeyword) {
        this.address_nokeyword = address_nokeyword;
    }

    public String getKeyword_chkn() {
        return keyword_chkn;
    }

    public void setKeyword_chkn(String keyword_chkn) {
        this.keyword_chkn = keyword_chkn;
    }

    public String getSplitinfo_norm() {
        return splitinfo_norm;
    }

    public void setSplitinfo_norm(String splitinfo_norm) {
        this.splitinfo_norm = splitinfo_norm;
    }

    public String getAoiid_chkn_ks16() {
        return aoiid_chkn_ks16;
    }

    public void setAoiid_chkn_ks16(String aoiid_chkn_ks16) {
        this.aoiid_chkn_ks16 = aoiid_chkn_ks16;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getXcoord_chkn() {
        return xcoord_chkn;
    }

    public void setXcoord_chkn(String xcoord_chkn) {
        this.xcoord_chkn = xcoord_chkn;
    }

    public String getYcoord_chkn() {
        return ycoord_chkn;
    }

    public void setYcoord_chkn(String ycoord_chkn) {
        this.ycoord_chkn = ycoord_chkn;
    }

    public String getXcoord_norm() {
        return xcoord_norm;
    }

    public void setXcoord_norm(String xcoord_norm) {
        this.xcoord_norm = xcoord_norm;
    }

    public String getYcoord_norm() {
        return ycoord_norm;
    }

    public void setYcoord_norm(String ycoord_norm) {
        this.ycoord_norm = ycoord_norm;
    }

    public String getIs_vague_addr() {
        return is_vague_addr;
    }

    public void setIs_vague_addr(String is_vague_addr) {
        this.is_vague_addr = is_vague_addr;
    }

    public String getNorm_is_identify() {
        return norm_is_identify;
    }

    public void setNorm_is_identify(String norm_is_identify) {
        this.norm_is_identify = norm_is_identify;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getChknid() {
        return chknid;
    }

    public void setChknid(String chknid) {
        this.chknid = chknid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDept_chkn() {
        return dept_chkn;
    }

    public void setDept_chkn(String dept_chkn) {
        this.dept_chkn = dept_chkn;
    }

    public String getDept_norm() {
        return dept_norm;
    }

    public void setDept_norm(String dept_norm) {
        this.dept_norm = dept_norm;
    }

    public String getDept_equal1() {
        return dept_equal1;
    }

    public void setDept_equal1(String dept_equal1) {
        this.dept_equal1 = dept_equal1;
    }

    public String getAoiid_norm() {
        return aoiid_norm;
    }

    public void setAoiid_norm(String aoiid_norm) {
        this.aoiid_norm = aoiid_norm;
    }

    public String getAoiname_norm() {
        return aoiname_norm;
    }

    public void setAoiname_norm(String aoiname_norm) {
        this.aoiname_norm = aoiname_norm;
    }

    public String getAoiid_chkn() {
        return aoiid_chkn;
    }

    public void setAoiid_chkn(String aoiid_chkn) {
        this.aoiid_chkn = aoiid_chkn;
    }

    public String getAoiname_chkn() {
        return aoiname_chkn;
    }

    public void setAoiname_chkn(String aoiname_chkn) {
        this.aoiname_chkn = aoiname_chkn;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getSplitinfo_chkn() {
        return splitinfo_chkn;
    }

    public void setSplitinfo_chkn(String splitinfo_chkn) {
        this.splitinfo_chkn = splitinfo_chkn;
    }

    public String getNorm_rsp() {
        return norm_rsp;
    }

    public void setNorm_rsp(String norm_rsp) {
        this.norm_rsp = norm_rsp;
    }
}
