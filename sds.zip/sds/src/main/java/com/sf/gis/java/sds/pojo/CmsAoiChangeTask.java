package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAoiChangeTask implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "consignor_addr")
    private String consignor_addr;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "aoi_id")
    private String aoi_id;

    @Column(name = "pj_aoi")
    private String pj_aoi;
    @Column(name = "sj_aoi")
    private String sj_aoi;

    public String getPj_aoi() {
        return pj_aoi;
    }

    public void setPj_aoi(String pj_aoi) {
        this.pj_aoi = pj_aoi;
    }

    public String getSj_aoi() {
        return sj_aoi;
    }

    public void setSj_aoi(String sj_aoi) {
        this.sj_aoi = sj_aoi;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }
}
