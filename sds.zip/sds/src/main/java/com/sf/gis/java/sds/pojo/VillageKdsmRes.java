package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class VillageKdsmRes implements Serializable {
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "zone_code")
    private String zone_code;
    @Column(name = "vil_code")
    private String vil_code;
    @Column(name = "is_jcpj")
    private String is_jcpj;
    @Column(name = "type")
    private String type;

    private double rate;
    private double cover_rate;
    private int xzc_cnt;
    private int valid_cnt;

    public double getCover_rate() {
        return cover_rate;
    }

    public void setCover_rate(double cover_rate) {
        this.cover_rate = cover_rate;
    }

    public int getValid_cnt() {
        return valid_cnt;
    }

    public void setValid_cnt(int valid_cnt) {
        this.valid_cnt = valid_cnt;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public int getXzc_cnt() {
        return xzc_cnt;
    }

    public void setXzc_cnt(int xzc_cnt) {
        this.xzc_cnt = xzc_cnt;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getZone_code() {
        return zone_code;
    }

    public void setZone_code(String zone_code) {
        this.zone_code = zone_code;
    }

    public String getVil_code() {
        return vil_code;
    }

    public void setVil_code(String vil_code) {
        this.vil_code = vil_code;
    }

    public String getIs_jcpj() {
        return is_jcpj;
    }

    public void setIs_jcpj(String is_jcpj) {
        this.is_jcpj = is_jcpj;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
