package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.DistanceAndConsumeTimeChange;
import com.sf.gis.java.sds.service.DistanceAndConsumeTimeChangeService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class DistanceAndConsumeTimeChangeController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DistanceAndConsumeTimeChangeController.class);
    DistanceAndConsumeTimeChangeService service = new DistanceAndConsumeTimeChangeService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<DistanceAndConsumeTimeChange> distanceAndConsumeTimeChangeRdd = service.loadData(spark, sc, date).filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.equals(o.getIsPushLine(), "1")).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("distanceAndConsumeTimeChangeRdd cnt:{}", distanceAndConsumeTimeChangeRdd.count());
            distanceAndConsumeTimeChangeRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<DistanceAndConsumeTimeChange> distanceAndConsumeTimeChangeResultRdd = distanceAndConsumeTimeChangeRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<DistanceAndConsumeTimeChange> list = Lists.newArrayList(tp._2);
                DistanceAndConsumeTimeChange distanceAndConsumeTimeChange = list.get(0);

                //任务量
                int taskCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(DistanceAndConsumeTimeChange::getTaskId))), ArrayList::new))
                        .size();

                //基准总里程
                double baseSumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineMile()))
                        .map(o -> Double.valueOf(o.getBaseLineMile()) / (double) 1000)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总里程
                double sumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //基准总耗时
                double baseSumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineTime()))
                        .map(o -> Double.valueOf(o.getBaseLineTime()) / (double) 60)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总耗时
                long sumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                distanceAndConsumeTimeChange.setTaskCount(taskCount);
                distanceAndConsumeTimeChange.setBaseSumDistance(baseSumDistance);
                distanceAndConsumeTimeChange.setSumDistance(sumDistance);
                distanceAndConsumeTimeChange.setBaseSumConsumeTime(baseSumConsumeTime);
                distanceAndConsumeTimeChange.setSumConsumeTime(sumConsumeTime);

                return distanceAndConsumeTimeChange;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("distanceAndConsumeTimeChangeResultRdd cnt:{}", distanceAndConsumeTimeChangeResultRdd.count());
            distanceAndConsumeTimeChangeResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            distanceAndConsumeTimeChangeRdd.unpersist();

            //插入数据库
            if (distanceAndConsumeTimeChangeResultRdd.count() > 0) {
                if (flag != size) {
                    //删除数据
                    spark.sql(String.format("insert overwrite table dm_gis.ETA_DISTANCE_TIME_RATIO_STAT select * from dm_gis.ETA_DISTANCE_TIME_RATIO_STAT where stat_date != '%s'", date));
                    service.delete(date);
                }
                service.saveData(spark, distanceAndConsumeTimeChangeResultRdd);
                service.saveToMysql(sc, distanceAndConsumeTimeChangeResultRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            distanceAndConsumeTimeChangeResultRdd.unpersist();
        }
        spark.stop();
    }
}
