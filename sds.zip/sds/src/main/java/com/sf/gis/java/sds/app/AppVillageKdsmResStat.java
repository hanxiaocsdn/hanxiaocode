package com.sf.gis.java.sds.app;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.VillageKdsmRes;
import com.sf.gis.java.sds.pojo.VillageKdsmResStat;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * 任务id：686527,677150（【偏远乡村派件上门】行政村有效覆盖率统计）
 * 业务方：01425243（敖少良）
 * 研发：01399581（匡仁衡）
 */
public class AppVillageKdsmResStat {
    private static Logger logger = LoggerFactory.getLogger(AppVillageKdsmResStat.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String tag = args[2];
        logger.error("startDate:{},endDate:{}, tag:{}", startDate, endDate, tag);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppVillageKdsmResStat");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        JavaRDD<VillageKdsmRes> rdd = loadData(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<VillageKdsmRes> xzcRdd = rdd.mapToPair(o -> new Tuple2<>(o.getZone_code(), o)).groupByKey().flatMap(tp -> {
            List<VillageKdsmRes> list = Lists.newArrayList(tp._2);
            int xzc_cnt = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(VillageKdsmRes::getVil_code))), ArrayList::new)).size();
            return list.stream().map(o -> {
                o.setXzc_cnt(xzc_cnt);
                return o;
            }).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xzcRdd cnt:{}", xzcRdd.count());
        rdd.unpersist();

        JavaRDD<VillageKdsmResStat> lastRdd = xzcRdd.mapToPair(o -> new Tuple2<>(o.getZone_code() + "_" + o.getVil_code(), o)).groupByKey().flatMap(tp -> {
            List<VillageKdsmRes> list = Lists.newArrayList(tp._2);
            int xzc_sp_cnt = list.size();
            int xzc_sp_jc_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_jcpj(), "1")).collect(Collectors.toList()).size();
            double rate = (double) Math.round((Double.parseDouble(xzc_sp_jc_cnt + "") / Double.parseDouble(xzc_sp_cnt + "")) * 100) / 100;
            return list.stream().map(o -> {
                o.setRate(rate);
                return o;
            }).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getZone_code(), o)).groupByKey().flatMap(tp -> {
            List<VillageKdsmRes> list = Lists.newArrayList(tp._2);
            int valid_cnt = list.stream()
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(VillageKdsmRes::getVil_code))), ArrayList::new))
                    .stream().filter(o -> o.getRate() >= 0.80).collect(Collectors.toList()).size();
            return list.stream().map(o -> {
                o.setValid_cnt(valid_cnt);
                return o;
            }).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getZone_code(), o)).reduceByKey((o1, o2) -> o1).map(tp -> {
            VillageKdsmRes o = tp._2;
            int xzc_cnt = o.getXzc_cnt();
            int valid_cnt = o.getValid_cnt();
            double cover_rate = (double) Math.round((Double.parseDouble(valid_cnt + "") / Double.parseDouble(xzc_cnt + "")) * 100) / 100;
            o.setCover_rate(cover_rate);
            return o;
        }).map(o -> {
            VillageKdsmResStat r = new VillageKdsmResStat();
            r.setArea_code(o.getArea_code());
            r.setCitycode(o.getCitycode());
            r.setZone_code(o.getZone_code());
            r.setXzc_cnt(o.getXzc_cnt() + "");
            r.setValid_cnt(o.getValid_cnt() + "");
            r.setCover_rate(o.getCover_rate() + "");
            r.setInc_day(endDate);
            return r;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        xzcRdd.unpersist();

        if (StringUtils.equals(tag, "day")) {
            DataUtil.saveOverwrite(spark, sc, "dm_gis.village_dest_src_kdsm_res_stat", VillageKdsmResStat.class, lastRdd, "inc_day");
        } else if (StringUtils.equals(tag, "month")) {
            DataUtil.saveOverwrite(spark, sc, "dm_gis.village_dest_src_kdsm_res_stat_month", VillageKdsmResStat.class, lastRdd, "inc_day");
        }
        lastRdd.unpersist();
        sc.stop();
        logger.error("end...");

    }

    public static JavaRDD<VillageKdsmRes> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select\n" +
                "  dest_area_code area_code,\n" +
                "  dest_dist_code citycode,\n" +
                "  dest_zone_code zone_code,\n" +
                "  vil_code,\n" +
                "  is_jcpj,\n" +
                "  'pj' type\n" +
                "from\n" +
                "  dm_gis.village_dest_kdsm_res\n" +
                "where\n" +
                "  inc_day between '%s' and '%s'\n" +
                "  and class_code = '220'\n" +
                "union\n" +
                "select\n" +
                "  src_area_code,\n" +
                "  src_dist_code citycode,\n" +
                "  source_zone_code zone_code,\n" +
                "  vil_code,\n" +
                "  is_jcpj,\n" +
                "  'sj' type\n" +
                "from\n" +
                "  dm_gis.village_src_kdsm_res\n" +
                "where\n" +
                "  inc_day between '%s' and '%s'\n" +
                "  and class_code = '220'", startDate, endDate, startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, VillageKdsmRes.class);
    }
}
