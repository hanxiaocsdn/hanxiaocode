package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TransLogInfo implements Serializable {
    @Column(name = "log")
    private String log;

    private String dateTime;
    private String sn;
    private String reqId;
    private String employeeId;
    private String cityCode;
    private String lng;
    private String lat;
    private String vehicleType;
    private String aoiCount;
    private String waybillCount;
    private String poiWaybillCount;
    private String time;
    private String employeeAoiId;
    private String poiCount;
    private String poiBuildingCount;
    private String poiEntranceCount;
    private String aoiMatrixCount;
    private String aoiMatrix0Count;
    private String aoiMatrix1Count;
    private String aoiMatrix2Count;
    private String aoiMatrix3Count;
    private String poiMatrixCount;
    private String poiMatrix0Count;
    private String poiMatrix1Count;
    private String poiMatrix2Count;
    private String poiMatrix3Count;
    private String missAoiCount;
    private String missPoiCount;

    public String getMissPoiCount() {
        return missPoiCount;
    }

    public void setMissPoiCount(String missPoiCount) {
        this.missPoiCount = missPoiCount;
    }

    public String getMissAoiCount() {
        return missAoiCount;
    }

    public void setMissAoiCount(String missAoiCount) {
        this.missAoiCount = missAoiCount;
    }

    public String getPoiMatrixCount() {
        return poiMatrixCount;
    }

    public void setPoiMatrixCount(String poiMatrixCount) {
        this.poiMatrixCount = poiMatrixCount;
    }

    public String getPoiMatrix0Count() {
        return poiMatrix0Count;
    }

    public void setPoiMatrix0Count(String poiMatrix0Count) {
        this.poiMatrix0Count = poiMatrix0Count;
    }

    public String getPoiMatrix1Count() {
        return poiMatrix1Count;
    }

    public void setPoiMatrix1Count(String poiMatrix1Count) {
        this.poiMatrix1Count = poiMatrix1Count;
    }

    public String getPoiMatrix2Count() {
        return poiMatrix2Count;
    }

    public void setPoiMatrix2Count(String poiMatrix2Count) {
        this.poiMatrix2Count = poiMatrix2Count;
    }

    public String getPoiMatrix3Count() {
        return poiMatrix3Count;
    }

    public void setPoiMatrix3Count(String poiMatrix3Count) {
        this.poiMatrix3Count = poiMatrix3Count;
    }

    public String getAoiMatrixCount() {
        return aoiMatrixCount;
    }

    public void setAoiMatrixCount(String aoiMatrixCount) {
        this.aoiMatrixCount = aoiMatrixCount;
    }

    public String getAoiMatrix0Count() {
        return aoiMatrix0Count;
    }

    public void setAoiMatrix0Count(String aoiMatrix0Count) {
        this.aoiMatrix0Count = aoiMatrix0Count;
    }

    public String getAoiMatrix1Count() {
        return aoiMatrix1Count;
    }

    public void setAoiMatrix1Count(String aoiMatrix1Count) {
        this.aoiMatrix1Count = aoiMatrix1Count;
    }

    public String getAoiMatrix2Count() {
        return aoiMatrix2Count;
    }

    public void setAoiMatrix2Count(String aoiMatrix2Count) {
        this.aoiMatrix2Count = aoiMatrix2Count;
    }

    public String getAoiMatrix3Count() {
        return aoiMatrix3Count;
    }

    public void setAoiMatrix3Count(String aoiMatrix3Count) {
        this.aoiMatrix3Count = aoiMatrix3Count;
    }

    public String getPoiCount() {
        return poiCount;
    }

    public void setPoiCount(String poiCount) {
        this.poiCount = poiCount;
    }

    public String getPoiBuildingCount() {
        return poiBuildingCount;
    }

    public void setPoiBuildingCount(String poiBuildingCount) {
        this.poiBuildingCount = poiBuildingCount;
    }

    public String getPoiEntranceCount() {
        return poiEntranceCount;
    }

    public void setPoiEntranceCount(String poiEntranceCount) {
        this.poiEntranceCount = poiEntranceCount;
    }

    public String getEmployeeAoiId() {
        return employeeAoiId;
    }

    public void setEmployeeAoiId(String employeeAoiId) {
        this.employeeAoiId = employeeAoiId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getReqId() {
        return reqId;
    }

    public void setReqId(String reqId) {
        this.reqId = reqId;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getAoiCount() {
        return aoiCount;
    }

    public void setAoiCount(String aoiCount) {
        this.aoiCount = aoiCount;
    }

    public String getWaybillCount() {
        return waybillCount;
    }

    public void setWaybillCount(String waybillCount) {
        this.waybillCount = waybillCount;
    }

    public String getPoiWaybillCount() {
        return poiWaybillCount;
    }

    public void setPoiWaybillCount(String poiWaybillCount) {
        this.poiWaybillCount = poiWaybillCount;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }
}
