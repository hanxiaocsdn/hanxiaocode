package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.StdAddrCoincideJudgeController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 研发：匡仁衡
 * 需求：【B库质量提升】标准地址重合判断_规范化地址关键词一致
 * 需求方：赵媛
 */
public class AppStdAddrCoincideJudge {
    private static Logger logger = LoggerFactory.getLogger(AppStdAddrCoincideJudge.class);

    public static void main(String[] args) {
        String statDate = args[0];
        logger.error("statDate:{}", statDate);
        logger.error("run start");
        new StdAddrCoincideJudgeController().start(statDate);
        logger.error("run end");
    }
}
