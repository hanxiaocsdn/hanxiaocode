package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class XzqFindZcDiff implements Serializable {
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "address")
    private String address;
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "type")
    private String type;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "name")
    private String name;
    @Column(name = "result")
    private String result;
    @Column(name = "name_d")
    private String name_d;

    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String city_code;

    public String getName_d() {
        return name_d;
    }

    public void setName_d(String name_d) {
        this.name_d = name_d;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
