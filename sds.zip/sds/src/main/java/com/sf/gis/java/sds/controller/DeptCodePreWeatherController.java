package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.DeptCodePreWeather;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class DeptCodePreWeatherController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DeptCodePreWeatherController.class);
    private static String url = "http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/queryWeatherForecast";
    private static String ak = "e81a07b0227d4a7fa25508d15f6f8301";
    private static String account = "01399581";
    private static String taskId = "774520";
    private static String taskName = "异常天气数据统计";
    private static int limitMin = 2000 / 10;


    public void start(String date, String hour) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String hour_partition = hour.split(" ")[1].split(":")[0];
        logger.error("hour_partition:{}", hour_partition);

        String sql = String.format("select area_code,area_name,dist_code,city_name,dept_type_code,dept_code,dept_name,longitude dept_longitude,latitude dept_latitude,inc_day from dim.dim_dept_info_df where inc_day = '%s' and delete_flg <> '1'", date);
        JavaRDD<DeptCodePreWeather> rdd = DataUtil.loadData(spark, sc, sql, DeptCodePreWeather.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<DeptCodePreWeather> xyRdd = rdd.filter(o -> StringUtils.isNotEmpty(o.getLongitude()) && StringUtils.isNotEmpty(o.getLatitude())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DeptCodePreWeather> empXyRdd = rdd.filter(o -> !(StringUtils.isNotEmpty(o.getLongitude()) && StringUtils.isNotEmpty(o.getLatitude()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xyRdd cnt:{}", xyRdd.count());
        logger.error("empXyRdd cnt:{}", empXyRdd.count());
        rdd.unpersist();


        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, "e81a07b0227d4a7fa25508d15f6f8301", xyRdd.count(), 10);
        JavaRDD<DeptCodePreWeather> lastRdd = xyRdd.flatMap(o -> {
            ArrayList<DeptCodePreWeather> list = new ArrayList<>();
            String longitude = o.getLongitude();
            String latitude = o.getLatitude();
            JSONObject param = new JSONObject();
            param.put("ak", ak);
            param.put("time", hour);
            param.put("time_range", 72);

            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("coor", longitude + "," + latitude);
            jsonArray.add(jsonObject);
            param.put("data", jsonArray);

            String response = HttpInvokeUtil.sendPost(url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
            o.setResp(response);
            o.setObserved_time(hour);
            o.setHour(hour_partition);
            try {
                JSONArray weather_list = JSON.parseObject(response).getJSONArray("DATA").getJSONObject(0).getJSONArray("weather");
                for (int i = 0; i < weather_list.size(); i++) {
                    JSONObject result = weather_list.getJSONObject(i);
                    DeptCodePreWeather newO = new DeptCodePreWeather();
                    BeanUtils.copyProperties(newO, o);

                    String weather_start_time = result.getString("weather_start_time");
                    String weather_end_time = result.getString("weather_end_time");
                    String type = result.getString("type");
                    String description = result.getString("description");
                    String level = result.getString("level");
                    String value = result.getString("value");

                    newO.setWeather_start_time(weather_start_time);
                    newO.setWeather_end_time(weather_end_time);
                    newO.setType(type);
                    newO.setDescription(description);
                    if (StringUtils.equals(type, "5") && (StringUtils.equals(value, "0.0") || StringUtils.isEmpty(value))) {
                        value = "35";
                    }
                    newO.setLevel(level);
                    newO.setValue(value);

                    list.add(newO);
                }
            } catch (Exception e) {
                list.add(o);
            }
            return list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(t -> t.getWeather_start_time() + "_" + t.getWeather_end_time() + "_" + t.getType()))), ArrayList::new)).iterator();
        }).union(empXyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        xyRdd.unpersist();
        empXyRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        spark.sql(String.format("alter table dm_gis.dept_code_pre_weather drop if EXISTS partition(inc_day='%s',hour='%s')", date, hour_partition));
        DataUtil.saveInto(spark, sc, "dm_gis.dept_code_pre_weather", DeptCodePreWeather.class, lastRdd, "inc_day", "hour");
        lastRdd.unpersist();
        sc.stop();
    }
}
