package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class Addr4Ho implements Serializable {

    @Column(name = "id")
    private String id;  // address id
    @Column(name = "address")
    private String address;
    @Column(name = "keyword")
    private String keyword;
    @Column(name = "zc")
    private String zc;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "kw_addr")
    private String kwAddr;
    @Column(name = "key_tag")
    private String keyTag;
    @Column(name = "last13")
    private String last13;
    @Column(name = "last613")
    private String last613;
    @Column(name = "last14")
    private String last14;
    @Column(name = "kt_bg")
    private String ktBg;
    @Column(name = "aoi_id_bg")
    private String aoiIdBg;
    @Column(name = "aoi_name_bg")
    private String aoiNameBg;
    @Column(name = "aoi_code_bg")
    private String aoiCodeBg;
    @Column(name = "lng_ts")
    private String lngTs;
    @Column(name = "lat_ts")
    private String latTs;
    @Column(name = "precision_ts")
    private String precisionTs;
    @Column(name = "aoi_id_ts")
    private String aoiIdTs;
    @Column(name = "aoi_name_ts")
    private String aoiNameTs;
    @Column(name = "aoi_code_ts")
    private String aoiCodeTs;
    @Column(name = "type")
    private String type;  // match:和标杆库一致; unmatch:和标杆库不一致
    @Column(name = "split_std")
    private String splitStd;  // match:和标杆库一致; unmatch:和标杆库不一致
    @Column(name = "city_code")
    private String cityCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getKwAddr() {
        return kwAddr;
    }

    public void setKwAddr(String kwAddr) {
        this.kwAddr = kwAddr;
    }

    public String getKeyTag() {
        return keyTag;
    }

    public void setKeyTag(String keyTag) {
        this.keyTag = keyTag;
    }

    public String getLast13() {
        return last13;
    }

    public void setLast13(String last13) {
        this.last13 = last13;
    }

    public String getLast613() {
        return last613;
    }

    public void setLast613(String last613) {
        this.last613 = last613;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getKtBg() {
        return ktBg;
    }

    public void setKtBg(String ktBg) {
        this.ktBg = ktBg;
    }

    public String getAoiIdBg() {
        return aoiIdBg;
    }

    public void setAoiIdBg(String aoiIdBg) {
        this.aoiIdBg = aoiIdBg;
    }

    public String getAoiNameBg() {
        return aoiNameBg;
    }

    public void setAoiNameBg(String aoiNameBg) {
        this.aoiNameBg = aoiNameBg;
    }

    public String getAoiCodeBg() {
        return aoiCodeBg;
    }

    public void setAoiCodeBg(String aoiCodeBg) {
        this.aoiCodeBg = aoiCodeBg;
    }

    public String getLngTs() {
        return lngTs;
    }

    public void setLngTs(String lngTs) {
        this.lngTs = lngTs;
    }

    public String getLatTs() {
        return latTs;
    }

    public void setLatTs(String latTs) {
        this.latTs = latTs;
    }

    public String getPrecisionTs() {
        return precisionTs;
    }

    public void setPrecisionTs(String precisionTs) {
        this.precisionTs = precisionTs;
    }

    public String getAoiIdTs() {
        return aoiIdTs;
    }

    public void setAoiIdTs(String aoiIdTs) {
        this.aoiIdTs = aoiIdTs;
    }

    public String getAoiNameTs() {
        return aoiNameTs;
    }

    public void setAoiNameTs(String aoiNameTs) {
        this.aoiNameTs = aoiNameTs;
    }

    public String getAoiCodeTs() {
        return aoiCodeTs;
    }

    public void setAoiCodeTs(String aoiCodeTs) {
        this.aoiCodeTs = aoiCodeTs;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSplitStd() {
        return splitStd;
    }

    public void setSplitStd(String splitStd) {
        this.splitStd = splitStd;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @Override
    public String toString() {
        return "Addr4Ho{" +
                "id='" + id + '\'' +
                ", address='" + address + '\'' +
                ", keyword='" + keyword + '\'' +
                ", zc='" + zc + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", kwAddr='" + kwAddr + '\'' +
                ", keyTag='" + keyTag + '\'' +
                ", last13='" + last13 + '\'' +
                ", last613='" + last613 + '\'' +
                ", last14='" + last14 + '\'' +
                ", ktBg='" + ktBg + '\'' +
                ", aoiIdBg='" + aoiIdBg + '\'' +
                ", aoiNameBg='" + aoiNameBg + '\'' +
                ", aoiCodeBg='" + aoiCodeBg + '\'' +
                ", lngTs='" + lngTs + '\'' +
                ", latTs='" + latTs + '\'' +
                ", precisionTs='" + precisionTs + '\'' +
                ", aoiIdTs='" + aoiIdTs + '\'' +
                ", aoiNameTs='" + aoiNameTs + '\'' +
                ", aoiCodeTs='" + aoiCodeTs + '\'' +
                ", type='" + type + '\'' +
                ", splitStd='" + splitStd + '\'' +
                ", cityCode='" + cityCode + '\'' +
                '}';
    }
}
