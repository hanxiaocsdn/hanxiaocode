package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.CpaXdcrdLscrdController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 客户下单位置信息和揽收位置信息分析
 * @author 01370539
 * Created on Jun.15 2022
 * 需求人员：赵瑜婷
 */
public class CpaXdcrdLscrdApp {
    private static final Logger logger = LoggerFactory.getLogger(CpaXdcrdLscrdApp.class);

    public static void main(String[] args) {
        String startDate;
        String endDate;
        String cityCode;
        if (args != null && args.length >=2) {
            startDate = args[0];
            endDate = args[1];
            cityCode = args[2];
        } else {
            startDate = DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY);
            endDate = startDate;
            cityCode = "755";
        }
        if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
            logger.error("date format must be yyyyMMdd, startDate - {}, endDate - {}", startDate, endDate);
            System.exit(0);
        }
        new CpaXdcrdLscrdController().process(startDate, endDate, cityCode);
    }
}
