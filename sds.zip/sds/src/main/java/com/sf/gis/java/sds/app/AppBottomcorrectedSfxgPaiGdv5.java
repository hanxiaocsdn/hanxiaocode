package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.BottomcorrectedPaiGdv5;
import com.sf.gis.java.sds.pojo.BottomcorrectedSfxgPaiGdv5;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 任务id：880364（不上门弹窗关联派件一期筛选_高德ps结果存表）
 * 业务方：01434066（宋雨莲）
 * 研发：01399581（匡仁衡）
 */

public class AppBottomcorrectedSfxgPaiGdv5 {
    private static final Logger logger = LoggerFactory.getLogger(AppBottomcorrectedSfxgPaiGdv5.class);
    private static final String gd = "http://gis-gaode.int.sfcloud.local:1080/optimalMatching?address=%s";
    private static final String account = "01399581";
    private static final String taskId = "880364";
    private static final String taskName = "不上门弹窗关联派件一期筛选_高德ps结果存表";

    private static final int limitMin1 = 2000 / 10;
    private static final int limitMin2 = 4000 / 10;

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppBottomcorrectedSfxgPaiGdv5");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");
        Broadcast<Properties> cityDbProBc = sc.broadcast(cityDbPro);


        spark.sql("add jar hdfs://sfbdp1//tmp/udf/01424213/136447/1000/hiveUdf-1.0-SNAPSHOT.jar");
        spark.sql("create temporary function Map_To_Json_XP as 'com.sf.hive.udf.MapToString'");
        String sql = SqlUtil.getSqlStr("bottomcorrected_join_product_inc_ubas_next_app.sql", date, date);
        JavaRDD<BottomcorrectedSfxgPaiGdv5> rdd = DataUtil.loadData(spark, sc, sql, BottomcorrectedSfxgPaiGdv5.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<BottomcorrectedSfxgPaiGdv5> normRdd = rdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<BottomcorrectedSfxgPaiGdv5> noEqNormRdd = rdd.filter(o -> !StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:{}", normRdd.count());
        logger.error("noEqNormRdd cnt:{}", noEqNormRdd.count());
        rdd.unpersist();

        String group_sql = "select\n" +
                "  address_id as gis_to_sys_groupid\n" +
                "from\n" +
                "  dm_gis.split_aoi_address_cleansing_c\n" +
                "where\n" +
                "  inc_day = '20231114'\n" +
                "  and (\n" +
                "    address_id is not null\n" +
                "    and address_id <> ''\n" +
                "  )\n" +
                "  group by address_id";
        JavaPairRDD<String, BottomcorrectedSfxgPaiGdv5> gisToSysGroupidRdd = DataUtil.loadData(spark, sc, group_sql, BottomcorrectedSfxgPaiGdv5.class).mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisToSysGroupidRdd cnt:{}", gisToSysGroupidRdd.count());

        JavaRDD<BottomcorrectedSfxgPaiGdv5> normFlagRdd = normRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).leftOuterJoin(gisToSysGroupidRdd).map(tp -> {
            BottomcorrectedSfxgPaiGdv5 o = tp._2._1;
            boolean flag = true;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                flag = false;
            }
            o.setFlag(flag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normFlagRdd cnt:{}", normFlagRdd.count());
        normRdd.unpersist();
        gisToSysGroupidRdd.unpersist();

        JavaRDD<BottomcorrectedSfxgPaiGdv5> trueRdd = normFlagRdd.filter(BottomcorrectedSfxgPaiGdv5::isFlag).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<BottomcorrectedSfxgPaiGdv5> falseRdd = normFlagRdd.filter(o -> !o.isFlag()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trueRdd cnt:{}, falseRdd:{}", trueRdd.count(), falseRdd.count());
        normFlagRdd.unpersist();


        JavaRDD<BottomcorrectedSfxgPaiGdv5> normStdAddrRdd = trueRdd.mapPartitions(itr -> {
            Properties cityMap = cityDbProBc.value();
            Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
            Statement stmt = conn.createStatement();
            List<BottomcorrectedSfxgPaiGdv5> list = new ArrayList<>();
            try {
                while (itr.hasNext()) {
                    BottomcorrectedSfxgPaiGdv5 o = itr.next();
                    String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                    String city_code = o.getCity_code();
                    if (StringUtils.isNotEmpty(gis_to_sys_groupid) && org.apache.commons.lang.StringUtils.isNotEmpty(city_code)) {
                        String cms_sql = String.format("select address from cms_address_%s where city_code='%s' and address_id = '%s'", cityMap.getProperty(city_code), city_code, gis_to_sys_groupid);
                        logger.info("cms_sql:" + cms_sql);
                        if (StringUtils.isNotEmpty(cms_sql)) {
                            ResultSet rs = stmt.executeQuery(cms_sql);
                            while (rs.next()) {
                                String address = rs.getString("address");
                                o.setStd_address(StringNumUtils.fixnulltoStr(address));
                            }
                        }
                    }
                    list.add(o);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                stmt.close();
                conn.close();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normStdAddrRdd cnt:{}", normStdAddrRdd.count());
        trueRdd.unpersist();

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", normStdAddrRdd.count(), 10);
        JavaRDD<BottomcorrectedSfxgPaiGdv5> gdRdd = normStdAddrRdd.repartition(10).mapPartitions(itr -> {
            ArrayList<BottomcorrectedSfxgPaiGdv5> list = new ArrayList<>();
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin2) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin2, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                BottomcorrectedSfxgPaiGdv5 o = itr.next();
                String std_address = o.getStd_address();
                String gd_aoi = "";
                if (StringUtils.isNotEmpty(std_address)) {
                    String req = String.format(gd, URLEncoder.encode(std_address, "UTF-8"));
                    String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                    try {
                        gd_aoi = JSON.parseObject(content).getJSONObject("message").getJSONArray("result").getJSONObject(0).getString("aoiid");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }
                o.setGdaoi(gd_aoi);
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:{}", gdRdd.count());
        normStdAddrRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        JavaRDD<BottomcorrectedSfxgPaiGdv5> resultRdd = noEqNormRdd.union(gdRdd).union(falseRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        noEqNormRdd.unpersist();
        gdRdd.unpersist();
        falseRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.sfxg_event_pai_gdv5 drop if EXISTS partition(inc_day='%s')", date));
        DataUtil.saveInto(spark, sc, "dm_gis.sfxg_event_pai_gdv5", BottomcorrectedSfxgPaiGdv5.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();

    }
}
