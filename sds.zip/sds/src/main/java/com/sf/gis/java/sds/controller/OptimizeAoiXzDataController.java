package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.CmsAddress;
import com.sf.gis.java.sds.pojo.OptimizeAoiXzData;
import com.sf.gis.java.sds.pojo.aoicompletion.GisRdsOmsto;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class OptimizeAoiXzDataController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(OptimizeAoiXzDataController.class);
    private static String getAoiTownInterInfo = "http://sds-core-datarun.sf-express.com/datarun/aoi/getAoiTownInterInfo?aoiId=%s";

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String cms_sql = "select aoi_id from dm_gis.cms_aoi_sch where city_code not in ('886', '852', '853')";
//        String cms_sql = "select aoi_id from dm_gis.cms_aoi_sch where city_code = '010'";
        JavaRDD<OptimizeAoiXzData> rdd = DataUtil.loadData(spark, sc, cms_sql, OptimizeAoiXzData.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<OptimizeAoiXzData> aoitowninterinfoRdd = rdd.map(o -> {
            String aoi_id = o.getAoi_id();
            if (StringUtils.isNotEmpty(aoi_id)) {
                String req = String.format(getAoiTownInterInfo, aoi_id);
                String content = HttpInvokeUtil.sendGet(req);
                o.setAoitowninterinfo_resp(content);

                boolean success = false;
                try {
                    success = JSON.parseObject(content).getBoolean("success");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setSuccess(success);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoitowninterinfoRdd cnt:{}", aoitowninterinfoRdd.count());
        rdd.unpersist();

        JavaRDD<OptimizeAoiXzData> successRdd = aoitowninterinfoRdd.filter(OptimizeAoiXzData::isSuccess).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("successRdd cnt:{}", successRdd.count());
        aoitowninterinfoRdd.unpersist();

        JavaRDD<OptimizeAoiXzData> ratioRdd = successRdd.map(o -> {
            String aoitowninterinfo_resp = o.getAoitowninterinfo_resp();
            JSONObject resp = JSON.parseObject(aoitowninterinfo_resp);
            String name_rs = "";
            double ratio_rs = 0;
            double dist_rs = 0;

            String province = "";
            String city = "";
            String county = "";
            JSONArray data = resp.getJSONArray("data");
            if (data != null && data.size() > 0) {
                for (int i = 0; i < data.size(); i++) {
                    JSONObject jsonObject = data.getJSONObject(i);
                    double ratio = jsonObject.getDouble("ratio");

                    if (ratio > ratio_rs) {
                        ratio_rs = ratio;
                        String name = jsonObject.getString("name");
                        double dist = jsonObject.getDouble("dist");
                        name_rs = name;
                        dist_rs = dist;

                        String nameP = jsonObject.getString("nameP");
                        String nameC = jsonObject.getString("nameC");
                        String nameD = jsonObject.getString("nameD");
                        province = nameP;
                        city = nameC;
                        county = nameD;
                    }
                }
            }

            o.setArea_max(ratio_rs + "");
            o.setTown(name_rs);
            o.setShortest_dist(dist_rs + "");

            o.setProvince(province);
            o.setCity(city);
            o.setCounty(county);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ratioRdd cnt:{}", ratioRdd.count());
        successRdd.unpersist();

        JavaRDD<OptimizeAoiXzData> geotypeRdd = ratioRdd.map(o -> {
            double area_max = StringUtils.isNotEmpty(o.getArea_max()) ? Double.parseDouble(o.getArea_max()) : 0.0;
            String geotype = "";

            if (area_max <= 0.9) {
                geotype = "KUA";
            } else {
                if (area_max < 1) {
                    geotype = "B";
                } else {
                    double shortest_dist = StringUtils.isNotEmpty(o.getShortest_dist()) ? Double.parseDouble(o.getShortest_dist()) : 0.0;
                    if (shortest_dist <= 120) {
                        geotype = "B";
                    } else {
                        geotype = "I";
                    }
                }
            }
            o.setGeotype(geotype);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("geotypeRdd cnt:{}", geotypeRdd.count());
        ratioRdd.unpersist();

        String before5Date = DateUtil.getDaysBefore(date, 5);
        String before1Date = DateUtil.getDaysBefore(date, 1);

        String omsto_sql = String.format("select\n" +
                "  finalaoiid,\n" +
                "  regexp_replace(req_addresseeaddr, '[\\\\r\\\\n\\\\s,]+', '') as req_addresseeaddr,\n" +
                "  regexp_replace(req_addresseecontacts, '[\\\\r\\\\n\\\\s,]+', '') as req_addresseecontacts,\n" +
                "  regexp_replace(req_comp_name, '[\\\\r\\\\n\\\\s,]+', '') as req_comp_name,\n" +
                "  req_addresseemobile,\n" +
                "  splitresult\n" +
                "FROM\n" +
                "  dm_gis.gis_rds_omsto\n" +
                "where\n" +
                "  inc_day between '%s'\n" +
                "  and '%s'\n" +
                "  and (finalaoiid is not null and finalaoiid <>'')" +
                "  and (splitresult is not null and splitresult <>'')", before5Date, before1Date);

        JavaRDD<GisRdsOmsto> omstoRdd = DataUtil.loadData(spark, sc, omsto_sql, GisRdsOmsto.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("omstoRdd cnt:{}", omstoRdd.count());

        JavaRDD<GisRdsOmsto> level45WordRdd = omstoRdd.map(o -> {
            String level45 = getLevel45(o.getSplitresult());
            o.setLevel45Word(level45);
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getLevel45Word()))
                .mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr() + o.getReq_addresseecontacts() + o.getReq_comp_name() + o.getReq_addresseemobile(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("level45WordRdd cnt:{}", level45WordRdd.count());
        omstoRdd.unpersist();

        JavaRDD<GisRdsOmsto> waybillRdd = level45WordRdd.mapToPair(o -> new Tuple2<>(o.getFinalaoiid(), o)).groupByKey().map(tp -> {
            List<GisRdsOmsto> list = Lists.newArrayList(tp._2);
            GisRdsOmsto gisRdsOmsto = list.get(0);

            ArrayList<String> word45_list = new ArrayList<>();
            List<GisRdsOmsto> collect = list.stream().peek(o -> word45_list.addAll(Arrays.asList(o.getLevel45Word().split(",")))).collect(Collectors.toList());

            int cnt = word45_list.size();

            List<String> after_process_sufix_list = word45_list.stream().map(o -> {
                String str = o.replaceAll("(街道|地区|街道镇|街道乡|镇|乡)$", "");
                if (str.length() >= 2) {
                    return str;
                } else {
                    return o;
                }
            }).collect(Collectors.toList());

            List<String> max_list = after_process_sufix_list.stream()
                    .collect(Collectors.groupingBy(o -> o))
                    .values()
                    .stream()
                    .max(Comparator.comparing(l -> l.size()))
                    .get();
            String max_word = max_list.get(0);
            int max_cnt = max_list.size();

            double freq45_waybill = (double) max_cnt / (double) cnt;
            gisRdsOmsto.setFreq45_waybill(freq45_waybill);

            String final_word = word45_list.stream().filter(o -> o.contains(max_word))
                    .collect(Collectors.groupingBy(o -> o))
                    .values()
                    .stream()
                    .max(Comparator.comparing(l -> l.size()))
                    .get().get(0);
            gisRdsOmsto.setL45_waybill(final_word);
            return gisRdsOmsto;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("waybillRdd cnt:{}", waybillRdd.count());
        level45WordRdd.unpersist();

        JavaRDD<OptimizeAoiXzData> geotypeWaybillRdd = geotypeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(waybillRdd.mapToPair(o -> new Tuple2<>(o.getFinalaoiid(), o)))
                .map(tp -> {
                    OptimizeAoiXzData o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        GisRdsOmsto gisRdsOmsto = tp._2._2.get();

                        o.setL45_waybill(gisRdsOmsto.getL45_waybill());
                        o.setFreq45_waybill(gisRdsOmsto.getFreq45_waybill() + "");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("geotypeWaybillRdd cnt:{}", geotypeWaybillRdd.count());
        geotypeRdd.unpersist();
        waybillRdd.unpersist();

        String cms_address_std_aoi_prepare_sql = String.format("select * from dm_gis.cms_address_std_aoi_prepare where inc_day = '%s'", date);
        JavaRDD<CmsAddress> stdPrepareRdd = DataUtil.loadData(spark, sc, cms_address_std_aoi_prepare_sql, CmsAddress.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdPrepareRdd cnt:{}", stdPrepareRdd.count());

        JavaRDD<OptimizeAoiXzData> geotypeStdRdd = geotypeWaybillRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(stdPrepareRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    OptimizeAoiXzData o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAddress cmsAddress = tp._2._2.get();
                        o.setFinalprovince(cmsAddress.getFinalprovince());
                        o.setFinalcity(cmsAddress.getFinalcity());
                        o.setFinalcounty(cmsAddress.getFinalcounty());
                        o.setL5_norm(cmsAddress.getL5_norm());
                        o.setFreq5_norm(cmsAddress.getFreq5_norm());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("geotypeStdRdd cnt:{}", geotypeStdRdd.count());
        geotypeWaybillRdd.unpersist();
        stdPrepareRdd.unpersist();

        JavaRDD<OptimizeAoiXzData> resultRdd = geotypeStdRdd.map(o -> {
            String finaltown = "";
            String tag = "";
            String l45_waybill = o.getL45_waybill();
            double freq45_waybill = StringUtils.isNotEmpty(o.getFreq45_waybill()) ? Double.parseDouble(o.getFreq45_waybill()) : 0;

            String l5_norm = o.getL5_norm();
            double freq5_norm = StringUtils.isNotEmpty(o.getFreq5_norm()) ? Double.parseDouble(o.getFreq5_norm()) : 0;

            if ((StringUtils.equals(l45_waybill, "北京经济技术开发区") || StringUtils.equals(l45_waybill, "中关村国家自主创新示范区大兴生物医药产业基地")) && freq45_waybill >= 0.6) {
                o.setGeotype("");
                finaltown = l45_waybill;
                tag = "defined";
            } else {
                String geotype = o.getGeotype();
                String town = o.getTown();
                if (StringUtils.equals(geotype, "I")) {
                    finaltown = town;
                    tag = "defined";
                } else {
                    if (StringUtils.equals(geotype, "B")) {
                        if (StringUtils.isEmpty(l45_waybill) && StringUtils.equals(town, l5_norm) && freq5_norm >= 0.8) {
                            finaltown = town;
                            tag = "defined";
                        } else {
                            if (StringUtils.isNotEmpty(l45_waybill) && StringUtils.equals(town, l45_waybill) && freq45_waybill >= 0.55 && !StringUtils.equals(town, l5_norm)) {
                                finaltown = town;
                                tag = "defined";
                            } else {
                                if (StringUtils.isNotEmpty(l45_waybill) && StringUtils.equals(town, l45_waybill) && freq45_waybill >= 0.55 && StringUtils.equals(town, l5_norm) && (freq5_norm - freq45_waybill) <= 0.25) {
                                    finaltown = town;
                                    tag = "defined";
                                } else {
                                    if (StringUtils.isEmpty(l45_waybill) && freq5_norm >= 0.6) {
                                        finaltown = l5_norm;
                                        tag = "recommended";
                                    } else {
                                        if (StringUtils.isNotEmpty(l45_waybill) && StringUtils.equals(l45_waybill, l5_norm) && freq45_waybill >= 0.6 && freq5_norm >= 0.6) {
                                            finaltown = l5_norm;
                                            tag = "recommended";
                                        } else {
                                            finaltown = town;
                                            tag = "recommended";
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        double area_max = StringUtils.isNotEmpty(o.getArea_max()) ? Double.parseDouble(o.getArea_max()) : 0;
                        if (area_max >= 0.6) {
                            if (StringUtils.isNotEmpty(town) && StringUtils.equals(town, l5_norm) && freq5_norm >= 0.8) {
                                finaltown = town;
                                tag = "defined";
                            } else {
                                if (StringUtils.isNotEmpty(town) && StringUtils.equals(town, l45_waybill) && freq45_waybill >= 0.6) {
                                    finaltown = town;
                                    tag = "defined";
                                } else {
                                    if (StringUtils.isNotEmpty(l5_norm) && StringUtils.equals(l45_waybill, l5_norm)) {
                                        finaltown = l5_norm;
                                        tag = "recommended";
                                    } else {
                                        if (StringUtils.isNotEmpty(town) && StringUtils.equals(l45_waybill, town)) {
                                            finaltown = town;
                                            tag = "recommended";
                                        } else {
                                            if (StringUtils.isNotEmpty(town) && StringUtils.equals(town, l5_norm)) {
                                                finaltown = town;
                                                tag = "recommended";
                                            } else {
                                                if (!StringUtils.equals(l45_waybill, l5_norm) && !StringUtils.equals(l45_waybill, town) && !StringUtils.equals(town, l5_norm) && freq5_norm >= freq45_waybill && freq5_norm >= 0.5) {
                                                    finaltown = l5_norm;
                                                    tag = "recommended";
                                                } else {
                                                    if (!StringUtils.equals(l45_waybill, l5_norm) && !StringUtils.equals(l45_waybill, town) && !StringUtils.equals(town, l5_norm) && freq5_norm < freq45_waybill && freq45_waybill >= 0.5) {
                                                        finaltown = l45_waybill;
                                                        tag = "recommended";
                                                    } else {
                                                        finaltown = town;
                                                        tag = "recommended";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (StringUtils.isEmpty(l45_waybill) && freq5_norm >= 0.9) {
                                finaltown = l5_norm;
                                tag = "defined";
                            } else {
                                if (StringUtils.isNotEmpty(l5_norm) && StringUtils.equals(l5_norm, l45_waybill) && freq5_norm >= 0.8 && freq45_waybill >= 0.6) {
                                    finaltown = l5_norm;
                                    tag = "defined";
                                } else {
                                    if (StringUtils.isNotEmpty(l5_norm) && StringUtils.equals(l45_waybill, l5_norm)) {
                                        finaltown = l5_norm;
                                        tag = "recommended";
                                    } else {
                                        if (StringUtils.isNotEmpty(town) && StringUtils.equals(l45_waybill, town)) {
                                            finaltown = town;
                                            tag = "recommended";
                                        } else {
                                            if (StringUtils.isNotEmpty(town) && StringUtils.equals(town, l5_norm)) {
                                                finaltown = town;
                                                tag = "recommended";
                                            } else {
                                                if (!StringUtils.equals(l45_waybill, l5_norm) && !StringUtils.equals(l45_waybill, town) && !StringUtils.equals(town, l5_norm) && freq5_norm >= freq45_waybill && freq5_norm >= 0.5) {
                                                    finaltown = l5_norm;
                                                    tag = "recommended";
                                                } else {
                                                    if (!StringUtils.equals(l45_waybill, l5_norm) && !StringUtils.equals(l45_waybill, town) && !StringUtils.equals(town, l5_norm) && freq5_norm < freq45_waybill && freq45_waybill >= 0.5) {
                                                        finaltown = l45_waybill;
                                                        tag = "recommended";
                                                    } else {
                                                        finaltown = town;
                                                        tag = "recommended";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            o.setFinaltown(finaltown);
            o.setTag(tag);
            o.setInc_day(date);

            String finalprovince = o.getFinalprovince();
            String finalcity = o.getFinalcity();
            String finalcounty = o.getFinalcounty();

            if (StringUtils.isEmpty(finalprovince)) {
                o.setFinalprovince(o.getProvince());
            }
            if (StringUtils.isEmpty(finalcity)) {
                o.setFinalcity(o.getCity());
            }
            if (StringUtils.isEmpty(finalcounty)) {
                o.setFinalcounty(o.getCounty());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        geotypeStdRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.optimize_aoi_xz_area_divide_data drop if EXISTS partition(inc_day='%s')", date));
        DataUtil.saveOverwrite(spark, sc, "dm_gis.optimize_aoi_xz_area_divide_data", OptimizeAoiXzData.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();


    }


    public String getLevel45(String splitresult) {
        ArrayList<String> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(splitresult)) {
            String before = splitresult.split(";")[0];
            String[] split = before.split("\\|");
            for (String s : split) {
                String[] split1 = s.split("\\^");
                if (split1.length >= 2) {
                    String word = split1[0];
                    String level = split1[1];
                    if (Arrays.asList("14,24,15,25".split(",")).contains(level)) {
                        if (StringUtils.isNotEmpty(word)) {
                            list.add(StringNumUtils.toChinese(word));
                        }
                    }
                }
            }
        }
        return list.size() > 0 ? String.join(",", list) : "";
    }


}
