package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.sds.pojo.BtDetail;
import com.sf.gis.java.sds.pojo.BtStat;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 竞品分析服务类
 * @author 01370539 created on Jun.22 2021
 */
public class BtAnalysisService {
    private static final Logger logger = LoggerFactory.getLogger(BtAnalysisService.class);

    public JavaRDD<BtDetail> loadGjData(SparkInfo si, String cityCode, String startDate, String endDate){
        String sql = "select un emp_no, bn zc, zx x, zy y, from_unixtime(cast(tm as int),'yyyyMMddHHmmss') op_time, inc_day from dm_gis.esg_gis_loc_trajectory where inc_day between '" + startDate + "' and '" + endDate + "' and ak = 1 and length(bn) >= 3 and zx is not null and zx != '' ";
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += " and bn like '" + cityCode + "%'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtDetail> loadGjAoiData(SparkInfo si, String startDate, String endDate){
        String sql = "select lng x, lat y, aoi_id aoi, inc_day from dm_gis.dwb_track_aoi_di where inc_day between '" + startDate + "' and '" + endDate + "' and lng is not null and lng != '' ";
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtDetail> loadBtEmpData(SparkInfo si, String cityCode, String startDate, String endDate){
        String sql = "select * from dm_gis.bt_gj where inc_day between '" + startDate + "' and '" + endDate + "' ";
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += " and city_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtDetail> loadBqData(SparkInfo si, String cityCode, String startDate, String endDate){
        String sql = "select from_unixtime(cast(barscantm/1000 as int),'yyyyMMddHHmmss') as op_time, zonecode zc, baroprcode emp_no, opcode, opname, mainwaybillno waybill_no, inc_day from ods_kafka_fvp.fvp_core_fact_route where inc_day between '" + startDate + "' and '" + endDate + "' and opcode = '80' and baroprcode != '' and baroprcode is not null and barscantm is not null and barscantm != '' and length(zonecode) >= 3";
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += "  and zonecode like '" + cityCode + "%'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtDetail> loadEmpData(SparkInfo si, String cityCode, String startDate, String endDate){
        String sql = "select waybill_no, consignee_mobile emp_no, dest_dist_code city_code, inc_day from dm_gis.tt_waybill_hook where inc_day between '" + startDate + "' and '" + endDate + "' ";
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += "  and dest_dist_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtDetail> loadAoiData(SparkInfo si, String cityCode){
        String sql = "select aoi_id aoi, fa_type aoi_type, city_code from dm_gis.cms_aoi_sch where source = 'sz' ";
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += "  and city_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtDetail.class);
    }

    public JavaRDD<BtStat> loadAoiCount(SparkInfo si, String cityCode, String startDate, String endDate){
        String sql = "select city_code, zno_code zc, aoi_id aoi, count_pick aoi_pu_cnt, count_deliver aoi_dlv_cnt, inc_day from dm_gis.aoi_count_stat where  inc_day between '" + startDate + "' and '" + endDate + "' " ;
        if (StringUtils.isNotEmpty(cityCode) && !"ALL".equalsIgnoreCase(cityCode)) {
            sql += " and city_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si.getSession(), si.getContext(), sql, BtStat.class);
    }
}
