package com.sf.gis.java.sds.pojo;


import com.sf.gis.java.base.util.MD5Util;
import com.sf.gis.java.sds.bean.DeptData;
import com.sf.gis.java.sds.utils.ObjectUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import java.util.Map;

@Entity
public class WrongDataDeptEmpty {
    @Column(name = "id")
    private String id;

    @Column(name = "address_md5")
    private String address_md5;
    @Column(name = "address")
    private String address;
    @Column(name = "data_time")
    private String dataTime;
    @Column(name = "frequency")
    private Integer frequency;
    @Column(name = "updateTime")
    private String updateTime;
    @Column(name = "waybillNo")
    private String waybillNo;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "req_time")
    private String req_time;

    @Column(name = "city_code")
    private String city_code;
    @Column(name = "is_done")
    private Integer is_done;


    public WrongDataDeptEmpty() {

    }


    public WrongDataDeptEmpty(DeptData x, String dataTime) {
        address = x.getReq_address();
//		if(x.isUseSb()){
//			deptcode = x.getSbDept();
//		}else{
//			deptcode = "";
//		}
        deptcode = x.getDeptcode() == null ? "" : x.getDeptcode();
        waybillNo = x.getReq_billno();
        this.dataTime = dataTime;
        req_time = x.getReq_time();
        city_code = x.getCityCode();
        address_md5 = MD5Util.getMD5(address);
        frequency = 1;
        is_done = 0;
    }


    public Integer getIs_done() {
        return is_done;
    }


    public void setIs_done(Integer is_done) {
        this.is_done = is_done;
    }


    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public Integer getFrequency() {
        return frequency;
    }

    public void setFrequency(Integer frequency) {
        this.frequency = frequency;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDataTime() {
        return dataTime;
    }

    public void setDataTime(String dataTime) {
        this.dataTime = dataTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getAddress_md5() {
        return address_md5;
    }


    public void setAddress_md5(String address_md5) {
        this.address_md5 = address_md5;
    }


    public String getReq_time() {
        return req_time;
    }


    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }


    public String[] toColumnArray(String[] columns) throws IllegalArgumentException, IllegalAccessException {
        Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(this);
        String[] ret = new String[columns.length];
        for (int i = 0; i < columns.length; i++) {
            ret[i] = map.get(columns[i]) == null ? "" : String.valueOf(map.get(columns[i]));
        }
        return ret;
    }
}
