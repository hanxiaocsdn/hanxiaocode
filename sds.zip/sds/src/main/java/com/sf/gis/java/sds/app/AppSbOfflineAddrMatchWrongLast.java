package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.sds.pojo.ChknEtlV3;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;


/**
 * 需求：【B库质量提升】审补下线地址匹配错误工艺_last
 * 需求方：谭雨祯（01425216）
 * 研发：匡仁衡（01399581）
 * 任务id：873（新平台）
 */
public class AppSbOfflineAddrMatchWrongLast {
    private static Logger logger = LoggerFactory.getLogger(AppSbOfflineAddrMatchWrongLast.class);
    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");

        //初始化spark
        SparkSession spark = Spark.getSparkSession("AppSbOfflineAddrMatchWrongLast", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        String match_wrong_sql = String.format("select * from dm_gis.chkn_etl_v3_sb_offline_addr_match_wrong where inc_day = '%s'", date);
        JavaRDD<ChknEtlV3> match_wrongRdd = DataUtil.loadData(spark, sc, match_wrong_sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("match_wrongRdd cnt:{}", match_wrongRdd.count());

        String match_sql = String.format("select * from dm_gis.chkn_etl_v3_sb_offline_addr_match where inc_day = '%s'", date);
        JavaRDD<ChknEtlV3> matchRdd = DataUtil.loadData(spark, sc, match_sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("matchRdd cnt:{}", matchRdd.count());

        JavaRDD<ChknEtlV3> afterDeptRdd = match_wrongRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getStandard(), o)).leftOuterJoin(matchRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getStandard(), o))).map(tp -> {
            ChknEtlV3 o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                ChknEtlV3 chknEtlV3 = tp._2._2.get();

                o.setLabel(chknEtlV3.getLabel());
                o.setScore(chknEtlV3.getScore());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("afterDeptRdd cnt:{}", afterDeptRdd.count());
        match_wrongRdd.unpersist();
        matchRdd.unpersist();

        JavaRDD<ChknEtlV3> resultRdd = afterDeptRdd.map(o -> {
            String label = o.getLabel();
            String score = o.getScore();
            String distance = o.getDistance();
            String result_mgeo_aoidistance = "";
            if (StringUtils.equals(label, "not_match") && StringUtils.isNotEmpty(score) && Double.parseDouble(score) > 0.95 && StringUtils.isNotEmpty(distance) && Double.parseDouble(distance) >= 800) {
                result_mgeo_aoidistance = "匹配错误";
            }

            String aoiid_chkn = o.getAoiid_chkn();
            String aoiid_norm = o.getAoiid_norm();
            String aoiid_chkn_ks16 = o.getAoiid_chkn_ks16();
            String result_mgeo_ks16chknaoi = "";
            if (StringUtils.equals(label, "not_match") && !StringUtils.equals(aoiid_chkn, aoiid_norm) && StringUtils.isNotEmpty(aoiid_chkn_ks16) && StringUtils.equals(aoiid_chkn_ks16, aoiid_chkn)) {
                result_mgeo_ks16chknaoi = "匹配错误";
            }

            String dept_equal1 = o.getDept_equal1();
            String dept_chkn = o.getDept_chkn();
            String afterdept_nokeyword = o.getAfterdept_nokeyword();
            String splitinfo_chkn = o.getSplitinfo_chkn();
            String splitinfo_norm = o.getSplitinfo_norm();
            String result_nokeyword_dept = "";
            if (StringUtils.equals(dept_equal1, "false") && StringUtils.isNotEmpty(dept_chkn) && StringUtils.equals(dept_chkn, afterdept_nokeyword) && !judge(splitinfo_chkn, splitinfo_norm)) {
                result_nokeyword_dept = "匹配错误";
            }
            o.setResult_mgeo_aoidistance(result_mgeo_aoidistance);
            o.setResult_mgeo_ks16chknaoi(result_mgeo_ks16chknaoi);
            o.setResult_nokeyword_dept(result_nokeyword_dept);

            String unmatch_result_combine = "";
            if (StringUtils.isNotEmpty(result_mgeo_aoidistance) || StringUtils.isNotEmpty(result_mgeo_ks16chknaoi) || StringUtils.isNotEmpty(result_nokeyword_dept)) {
                unmatch_result_combine = "y";
            }

            o.setUnmatch_result_combine(unmatch_result_combine);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        afterDeptRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.chkn_etl_v3_sb_offline_addr_match_wrong", ChknEtlV3.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static boolean judge(String split_chkn, String split_norm) {
        if (StringUtils.isNotEmpty(split_chkn) && StringUtils.isNotEmpty(split_norm)) {
            try {
                String[] chkn = split_chkn.split(",");
                String[] norm = split_norm.split(",");

                String[] last_chkn = chkn[chkn.length - 1].split("\\^");
                String[] last_norm = norm[norm.length - 1].split("\\^");

                if (last_chkn.length >= 2 && last_norm.length >= 2) {
                    String chkn_word = last_chkn[0];
                    String chkn_level = last_chkn[1];
                    String chkn_after = chkn_level.substring(1, chkn_level.length());

                    String norm_word = last_norm[0];
                    String norm_level = last_norm[1];
                    String norm_after = norm_level.substring(1, norm_level.length());

                    if (StringUtils.equals(chkn_after, "13") && StringUtils.equals(chkn_after, norm_after) && StringUtils.equals(chkn_word, norm_word)) {
                        return true;
                    }
                }
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return false;
    }
}
