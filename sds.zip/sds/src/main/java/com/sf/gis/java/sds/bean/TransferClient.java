package com.sf.gis.java.sds.bean;


import java.util.Date;


public abstract class TransferClient {
    protected String host, userName, pwd;
    public TransferClient(String host, String userName, String pwd) {
        this.host = host;
        this.userName = userName;
        this.pwd = pwd;
    }
    public abstract  Date getFileLastModifiedTime(String path,int zoneTimeDiff) throws Exception ;
    public abstract void close() throws Exception;
    public abstract boolean uploadFile(String localPath, String ftpPath) throws Exception ;
    public abstract boolean downloadFile(String ftpPath, String localPath, String fileName) throws Exception ;

}