package com.sf.gis.java.sds.enumtype;

/**
 * 收派类型
 */
public enum MapType {
    shou,pai
}
