package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ZnocodeDepartcodeMapping implements Serializable {
    @Column(name = "znocode")
    private String znocode;
    @Column(name = "departcode")
    private String departcode;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "typecode")
    private String typecode;

    public String getTypecode() {
        return typecode;
    }

    public void setTypecode(String typecode) {
        this.typecode = typecode;
    }

    public String getDepartcode() {
        return departcode;
    }

    public void setDepartcode(String departcode) {
        this.departcode = departcode;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getZnocode() {
        return znocode;
    }

    public void setZnocode(String znocode) {
        this.znocode = znocode;
    }
}
