package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.List;

@Table
public class TtEdcsWaybillContentSws implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "original_zone_code")
    private String original_zone_code;
    @Column(name = "takeover_member_no")
    private String takeover_member_no;
    @Column(name = "takeover_tm")
    private String takeover_tm;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "destination_zone_code")
    private String destination_zone_code;

    private boolean signReceipt;
    private String source_waybill_no;

    private String addresseeaoicode;
    private String addresseeaoiid;
    private String addresseedeptcode;

    private String lastAoiid;
    private String tag;

    private String province;
    private String city;
    private String citycode;
    private String address;
    private String county;

    private String customeraccount;
    private String mobile;
    private String phone;
    private String company;
    private String isnotundercall;

    private String receiverprovince;
    private String receivercity;
    private String addresseecitycode;
    private String addresseeaddr;
    private String receiverarea;
    private String addresseecompname;
    private String addresseemobile;
    private String addresseephone;

    private List<CmsAoiSch> list;
    private int aoi_size;
    private String aoiid;
    private String dept_code;

    private String before10min;
    private String after10min;
    private String barscantmstd;

    private String eventlng;
    private String eventlat;

    private String src_lgt;
    private String src_lat;

    private String order_no;

    private String aoi_code;
    private String fa_type;
    private String aoi_area_code;

    private String waybill_type;
    private String similarity;

    private String event_aoiid;
    private String aoi_name;

    public String getAddresseecompname() {
        return addresseecompname;
    }

    public void setAddresseecompname(String addresseecompname) {
        this.addresseecompname = addresseecompname;
    }

    public String getAddresseemobile() {
        return addresseemobile;
    }

    public void setAddresseemobile(String addresseemobile) {
        this.addresseemobile = addresseemobile;
    }

    public String getAddresseephone() {
        return addresseephone;
    }

    public void setAddresseephone(String addresseephone) {
        this.addresseephone = addresseephone;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getEvent_aoiid() {
        return event_aoiid;
    }

    public void setEvent_aoiid(String event_aoiid) {
        this.event_aoiid = event_aoiid;
    }

    public String getCustomeraccount() {
        return customeraccount;
    }

    public void setCustomeraccount(String customeraccount) {
        this.customeraccount = customeraccount;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getIsnotundercall() {
        return isnotundercall;
    }

    public void setIsnotundercall(String isnotundercall) {
        this.isnotundercall = isnotundercall;
    }

    public String getDestination_zone_code() {
        return destination_zone_code;
    }

    public void setDestination_zone_code(String destination_zone_code) {
        this.destination_zone_code = destination_zone_code;
    }

    public String getSimilarity() {
        return similarity;
    }

    public void setSimilarity(String similarity) {
        this.similarity = similarity;
    }

    public String getWaybill_type() {
        return waybill_type;
    }

    public void setWaybill_type(String waybill_type) {
        this.waybill_type = waybill_type;
    }

    public String getReceiverprovince() {
        return receiverprovince;
    }

    public void setReceiverprovince(String receiverprovince) {
        this.receiverprovince = receiverprovince;
    }

    public String getReceivercity() {
        return receivercity;
    }

    public void setReceivercity(String receivercity) {
        this.receivercity = receivercity;
    }

    public String getAddresseecitycode() {
        return addresseecitycode;
    }

    public void setAddresseecitycode(String addresseecitycode) {
        this.addresseecitycode = addresseecitycode;
    }

    public String getAddresseeaddr() {
        return addresseeaddr;
    }

    public void setAddresseeaddr(String addresseeaddr) {
        this.addresseeaddr = addresseeaddr;
    }

    public String getReceiverarea() {
        return receiverarea;
    }

    public void setReceiverarea(String receiverarea) {
        this.receiverarea = receiverarea;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getSrc_lgt() {
        return src_lgt;
    }

    public void setSrc_lgt(String src_lgt) {
        this.src_lgt = src_lgt;
    }

    public String getSrc_lat() {
        return src_lat;
    }

    public void setSrc_lat(String src_lat) {
        this.src_lat = src_lat;
    }

    public String getEventlng() {
        return eventlng;
    }

    public void setEventlng(String eventlng) {
        this.eventlng = eventlng;
    }

    public String getEventlat() {
        return eventlat;
    }

    public void setEventlat(String eventlat) {
        this.eventlat = eventlat;
    }

    public String getBarscantmstd() {
        return barscantmstd;
    }

    public void setBarscantmstd(String barscantmstd) {
        this.barscantmstd = barscantmstd;
    }

    public String getBefore10min() {
        return before10min;
    }

    public void setBefore10min(String before10min) {
        this.before10min = before10min;
    }

    public String getAfter10min() {
        return after10min;
    }

    public void setAfter10min(String after10min) {
        this.after10min = after10min;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public int getAoi_size() {
        return aoi_size;
    }

    public void setAoi_size(int aoi_size) {
        this.aoi_size = aoi_size;
    }

    public List<CmsAoiSch> getList() {
        return list;
    }

    public void setList(List<CmsAoiSch> list) {
        this.list = list;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getLastAoiid() {
        return lastAoiid;
    }

    public void setLastAoiid(String lastAoiid) {
        this.lastAoiid = lastAoiid;
    }

    public String getAddresseeaoiid() {
        return addresseeaoiid;
    }

    public void setAddresseeaoiid(String addresseeaoiid) {
        this.addresseeaoiid = addresseeaoiid;
    }

    public String getAddresseeaoicode() {
        return addresseeaoicode;
    }

    public void setAddresseeaoicode(String addresseeaoicode) {
        this.addresseeaoicode = addresseeaoicode;
    }

    public String getAddresseedeptcode() {
        return addresseedeptcode;
    }

    public void setAddresseedeptcode(String addresseedeptcode) {
        this.addresseedeptcode = addresseedeptcode;
    }

    public String getSource_waybill_no() {
        return source_waybill_no;
    }

    public void setSource_waybill_no(String source_waybill_no) {
        this.source_waybill_no = source_waybill_no;
    }

    public boolean isSignReceipt() {
        return signReceipt;
    }

    public void setSignReceipt(boolean signReceipt) {
        this.signReceipt = signReceipt;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getOriginal_zone_code() {
        return original_zone_code;
    }

    public void setOriginal_zone_code(String original_zone_code) {
        this.original_zone_code = original_zone_code;
    }

    public String getTakeover_member_no() {
        return takeover_member_no;
    }

    public void setTakeover_member_no(String takeover_member_no) {
        this.takeover_member_no = takeover_member_no;
    }

    public String getTakeover_tm() {
        return takeover_tm;
    }

    public void setTakeover_tm(String takeover_tm) {
        this.takeover_tm = takeover_tm;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
