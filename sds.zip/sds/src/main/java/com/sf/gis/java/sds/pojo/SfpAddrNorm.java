package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 地址详细信息
 * @author 01370539 created on Aug.12 2021
 */
@Table
public class SfpAddrNorm implements Serializable {
    @Column(name = "province")
    private String province;    // 省
    @Column(name = "city")
    private String city;    // 市
    @Column(name = "district")
    private String district;    // 区
    @Column(name = "zc")
    private String zc;    // 地址网点，来自派件
    @Column(name = "aoi_addr")
    private String aoiAddr;    // 地址AOI，来自atdispatch
    @Column(name = "aoi_xy")
    private String aoiXy;    // 坐标AOI，来自dept2
    @Column(name = "aoi_xy_type")
    private String aoiXyType;    // 坐标AOI类型
    @Column(name = "aoi_xy_type_name")
    private String aoiXyTypeName;    // 坐标AOI类型名称
    @Column(name = "addr")
    private String addr;    // 地址
    @Column(name = "split")
    private String split;    // 切词
    @Column(name = "split_key")
    private String splitKey;    // 通过切词获取的主体
    @Column(name = "split_key_level")
    private String splitKeyLevel;    // 切词主体的级别
    @Column(name = "key_id")
    private String keyId;    // 同一地址标识
    @Column(name = "poi")
    private String poi;    // poi
    @Column(name = "building")
    private String building;    // 楼栋
    @Column(name = "lng_zc")
    private String lngZc;    // 地址的经度（来自地理编码服务）
    @Column(name = "lat_zc")
    private String latZc;    // 地址的纬度（来自地理编码服务）
    @Column(name = "lng_geo")
    private String lngGeo;    // 地址的经度（来自地理编码服务）
    @Column(name = "lat_geo")
    private String latGeo;    // 地址的纬度（来自地理编码服务）
    @Column(name = "precision_geo")
    private String precisionGeo;    // 坐标精度（来自地理编码服务）
    @Column(name = "lng_kh")
    private String lngKh;    // 经度（来自巴枪）
    @Column(name = "lat_kh")
    private String latKh;    // 纬度（来自巴枪）
    @Column(name = "lng_bq")
    private String lngBq;    // 经度（来自巴枪）
    @Column(name = "lat_bq")
    private String latBq;    // 纬度（来自巴枪）
    @Column(name = "precision_bq")
    private String precisionBq;    // 坐标精度（来自地理编码服务）
    @Column(name = "lng")
    private String lng;    // 坐标聚合中间点经度
    @Column(name = "lat")
    private String lat;    // 坐标聚合中间点纬度
    @Column(name = "freq")
    private String freq;    // 频次
    @Column(name = "is_effect")
    private String isEffect;    // 是否有效: 0：无效；1：有效；2：没有经过任何第三方坐标校验
    @Column(name = "effect_type")
    private String effectType;    // 有效类型: 0：无效；1……n：有效，数值越大，有效度越高；
    @Column(name = "building_id")
    private String buildingId;    // 楼栋ID
    @Column(name = "building_name")
    private String buildingName;    // 楼栋名称
    @Column(name = "lng_building")
    private String lngBuilding;    // 楼栋经度
    @Column(name = "lat_building")
    private String latBuilding;    // 楼栋纬度
    @Column(name = "status_building")
    private String statusBuilding;    // 楼栋匹配状态
    @Column(name = "city_code")
    private String cityCode;    // 城市编码

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoiAddr() {
        return aoiAddr;
    }

    public void setAoiAddr(String aoiAddr) {
        this.aoiAddr = aoiAddr;
    }

    public String getAoiXy() {
        return aoiXy;
    }

    public void setAoiXy(String aoiXy) {
        this.aoiXy = aoiXy;
    }

    public String getAoiXyType() {
        return aoiXyType;
    }

    public void setAoiXyType(String aoiXyType) {
        this.aoiXyType = aoiXyType;
    }

    public String getAoiXyTypeName() {
        return aoiXyTypeName;
    }

    public void setAoiXyTypeName(String aoiXyTypeName) {
        this.aoiXyTypeName = aoiXyTypeName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getSplitKey() {
        return splitKey;
    }

    public void setSplitKey(String splitKey) {
        this.splitKey = splitKey;
    }

    public String getSplitKeyLevel() {
        return splitKeyLevel;
    }

    public void setSplitKeyLevel(String splitKeyLevel) {
        this.splitKeyLevel = splitKeyLevel;
    }

    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    public String getPoi() {
        return poi;
    }

    public void setPoi(String poi) {
        this.poi = poi;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getLngZc() {
        return lngZc;
    }

    public void setLngZc(String lngZc) {
        this.lngZc = lngZc;
    }

    public String getLatZc() {
        return latZc;
    }

    public void setLatZc(String latZc) {
        this.latZc = latZc;
    }

    public String getLngGeo() {
        return lngGeo;
    }

    public void setLngGeo(String lngGeo) {
        this.lngGeo = lngGeo;
    }

    public String getLatGeo() {
        return latGeo;
    }

    public void setLatGeo(String latGeo) {
        this.latGeo = latGeo;
    }

    public String getPrecisionGeo() {
        return precisionGeo;
    }

    public void setPrecisionGeo(String precisionGeo) {
        this.precisionGeo = precisionGeo;
    }

    public String getLngKh() {
        return lngKh;
    }

    public void setLngKh(String lngKh) {
        this.lngKh = lngKh;
    }

    public String getLatKh() {
        return latKh;
    }

    public void setLatKh(String latKh) {
        this.latKh = latKh;
    }

    public String getLngBq() {
        return lngBq;
    }

    public void setLngBq(String lngBq) {
        this.lngBq = lngBq;
    }

    public String getLatBq() {
        return latBq;
    }

    public void setLatBq(String latBq) {
        this.latBq = latBq;
    }

    public String getPrecisionBq() {
        return precisionBq;
    }

    public void setPrecisionBq(String precisionBq) {
        this.precisionBq = precisionBq;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getIsEffect() {
        return isEffect;
    }

    public void setIsEffect(String isEffect) {
        this.isEffect = isEffect;
    }

    public String getEffectType() {
        return effectType;
    }

    public void setEffectType(String effectType) {
        this.effectType = effectType;
    }

    public String getBuildingId() {
        return buildingId;
    }

    public void setBuildingId(String buildingId) {
        this.buildingId = buildingId;
    }

    public String getBuildingName() {
        return buildingName;
    }

    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }

    public String getLngBuilding() {
        return lngBuilding;
    }

    public void setLngBuilding(String lngBuilding) {
        this.lngBuilding = lngBuilding;
    }

    public String getLatBuilding() {
        return latBuilding;
    }

    public void setLatBuilding(String latBuilding) {
        this.latBuilding = latBuilding;
    }

    public String getStatusBuilding() {
        return statusBuilding;
    }

    public void setStatusBuilding(String statusBuilding) {
        this.statusBuilding = statusBuilding;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @Override
    public String toString() {
        return "SfpAddrNorm{" +
                "province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", district='" + district + '\'' +
                ", zc='" + zc + '\'' +
                ", aoiAddr='" + aoiAddr + '\'' +
                ", aoiXy='" + aoiXy + '\'' +
                ", aoiXyType='" + aoiXyType + '\'' +
                ", aoiXyTypeName='" + aoiXyTypeName + '\'' +
                ", addr='" + addr + '\'' +
                ", split='" + split + '\'' +
                ", splitKey='" + splitKey + '\'' +
                ", splitKeyLevel='" + splitKeyLevel + '\'' +
                ", keyId='" + keyId + '\'' +
                ", poi='" + poi + '\'' +
                ", building='" + building + '\'' +
                ", lngZc='" + lngZc + '\'' +
                ", latZc='" + latZc + '\'' +
                ", lngGeo='" + lngGeo + '\'' +
                ", latGeo='" + latGeo + '\'' +
                ", precisionGeo='" + precisionGeo + '\'' +
                ", lngKh='" + lngKh + '\'' +
                ", latKh='" + latKh + '\'' +
                ", lngBq='" + lngBq + '\'' +
                ", latBq='" + latBq + '\'' +
                ", precisionBq='" + precisionBq + '\'' +
                ", lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", freq='" + freq + '\'' +
                ", isEffect='" + isEffect + '\'' +
                ", effectType='" + effectType + '\'' +
                ", buildingId='" + buildingId + '\'' +
                ", buildingName='" + buildingName + '\'' +
                ", lngBuilding='" + lngBuilding + '\'' +
                ", latBuilding='" + latBuilding + '\'' +
                ", status_building='" + statusBuilding + '\'' +
                ", cityCode='" + cityCode + '\'' +
                '}';
    }
}
