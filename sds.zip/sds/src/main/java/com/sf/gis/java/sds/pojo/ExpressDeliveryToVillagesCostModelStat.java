package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ExpressDeliveryToVillagesCostModelStat implements Serializable {
    @Column(name = "dest_hq_code")
    private String dest_hq_code;
    @Column(name = "dest_area_code")
    private String dest_area_code;
    @Column(name = "area_name")
    private String area_name;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "dept_name")
    private String dept_name;
    @Column(name = "count_0_3")
    private String count_0_3;
    @Column(name = "count_3_5")
    private String count_3_5;
    @Column(name = "count_5_10")
    private String count_5_10;
    @Column(name = "count_10_30")
    private String count_10_30;
    @Column(name = "count_30")
    private String count_30;
    @Column(name = "dist_0_3")
    private String dist_0_3;
    @Column(name = "time_0_3")
    private String time_0_3;
    @Column(name = "cb_0_3")
    private String cb_0_3;
    @Column(name = "dist_0_5")
    private String dist_0_5;
    @Column(name = "time_0_5")
    private String time_0_5;
    @Column(name = "cb_0_5")
    private String cb_0_5;
    @Column(name = "dist_0_10")
    private String dist_0_10;
    @Column(name = "time_0_10")
    private String time_0_10;
    @Column(name = "cb_0_10")
    private String cb_0_10;
    @Column(name = "dist_0_30")
    private String dist_0_30;
    @Column(name = "time_0_30")
    private String time_0_30;
    @Column(name = "cb_0_30")
    private String cb_0_30;
    @Column(name = "dist_all")
    private String dist_all;
    @Column(name = "time_all")
    private String time_all;
    @Column(name = "cb_all")
    private String cb_all;
    @Column(name = "avg_0_3")
    private String avg_0_3;
    @Column(name = "avg_3_5")
    private String avg_3_5;
    @Column(name = "avg_5_10")
    private String avg_5_10;
    @Column(name = "avg_10_30")
    private String avg_10_30;
    @Column(name = "avg_30")
    private String avg_30;

    @Column(name = "aoi_0_3")
    private String aoi_0_3;
    @Column(name = "aoi_0_5")
    private String aoi_0_5;
    @Column(name = "aoi_0_10")
    private String aoi_0_10;
    @Column(name = "aoi_0_30")
    private String aoi_0_30;
    @Column(name = "aoi_all")
    private String aoi_all;

    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "aoi_0_3_resp")
    private String aoi_0_3_resp;
    @Column(name = "aoi_0_5_resp")
    private String aoi_0_5_resp;
    @Column(name = "aoi_0_10_resp")
    private String aoi_0_10_resp;
    @Column(name = "aoi_0_30_resp")
    private String aoi_0_30_resp;
    @Column(name = "aoi_all_resp")
    private String aoi_all_resp;

    @Column(name = "inc_day")
    private String inc_day;

    public ExpressDeliveryToVillagesCostModelStat() {
    }

    public ExpressDeliveryToVillagesCostModelStat(String dest_hq_code, String dest_area_code, String area_name, String dest_dist_code, String dest_zone_code, String dept_name, String count_0_3, String count_3_5, String count_5_10, String count_10_30, String count_30, String dist_0_3, String time_0_3, String cb_0_3, String dist_0_5, String time_0_5, String cb_0_5, String dist_0_10, String time_0_10, String cb_0_10, String dist_0_30, String time_0_30, String cb_0_30, String dist_all, String time_all, String cb_all, String avg_0_3, String avg_3_5, String avg_5_10, String avg_10_30, String avg_30, String aoi_0_3, String aoi_0_5, String aoi_0_10, String aoi_0_30, String aoi_all, String x, String y, String aoi_0_3_resp, String aoi_0_5_resp, String aoi_0_10_resp, String aoi_0_30_resp, String aoi_all_resp, String inc_day) {
        this.dest_hq_code = dest_hq_code;
        this.dest_area_code = dest_area_code;
        this.area_name = area_name;
        this.dest_dist_code = dest_dist_code;
        this.dest_zone_code = dest_zone_code;
        this.dept_name = dept_name;
        this.count_0_3 = count_0_3;
        this.count_3_5 = count_3_5;
        this.count_5_10 = count_5_10;
        this.count_10_30 = count_10_30;
        this.count_30 = count_30;
        this.dist_0_3 = dist_0_3;
        this.time_0_3 = time_0_3;
        this.cb_0_3 = cb_0_3;
        this.dist_0_5 = dist_0_5;
        this.time_0_5 = time_0_5;
        this.cb_0_5 = cb_0_5;
        this.dist_0_10 = dist_0_10;
        this.time_0_10 = time_0_10;
        this.cb_0_10 = cb_0_10;
        this.dist_0_30 = dist_0_30;
        this.time_0_30 = time_0_30;
        this.cb_0_30 = cb_0_30;
        this.dist_all = dist_all;
        this.time_all = time_all;
        this.cb_all = cb_all;
        this.avg_0_3 = avg_0_3;
        this.avg_3_5 = avg_3_5;
        this.avg_5_10 = avg_5_10;
        this.avg_10_30 = avg_10_30;
        this.avg_30 = avg_30;
        this.aoi_0_3 = aoi_0_3;
        this.aoi_0_5 = aoi_0_5;
        this.aoi_0_10 = aoi_0_10;
        this.aoi_0_30 = aoi_0_30;
        this.aoi_all = aoi_all;
        this.x = x;
        this.y = y;
        this.aoi_0_3_resp = aoi_0_3_resp;
        this.aoi_0_5_resp = aoi_0_5_resp;
        this.aoi_0_10_resp = aoi_0_10_resp;
        this.aoi_0_30_resp = aoi_0_30_resp;
        this.aoi_all_resp = aoi_all_resp;
        this.inc_day = inc_day;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getAoi_0_3_resp() {
        return aoi_0_3_resp;
    }

    public void setAoi_0_3_resp(String aoi_0_3_resp) {
        this.aoi_0_3_resp = aoi_0_3_resp;
    }

    public String getAoi_0_5_resp() {
        return aoi_0_5_resp;
    }

    public void setAoi_0_5_resp(String aoi_0_5_resp) {
        this.aoi_0_5_resp = aoi_0_5_resp;
    }

    public String getAoi_0_10_resp() {
        return aoi_0_10_resp;
    }

    public void setAoi_0_10_resp(String aoi_0_10_resp) {
        this.aoi_0_10_resp = aoi_0_10_resp;
    }

    public String getAoi_0_30_resp() {
        return aoi_0_30_resp;
    }

    public void setAoi_0_30_resp(String aoi_0_30_resp) {
        this.aoi_0_30_resp = aoi_0_30_resp;
    }

    public String getAoi_all_resp() {
        return aoi_all_resp;
    }

    public void setAoi_all_resp(String aoi_all_resp) {
        this.aoi_all_resp = aoi_all_resp;
    }

    public String getAoi_0_3() {
        return aoi_0_3;
    }

    public void setAoi_0_3(String aoi_0_3) {
        this.aoi_0_3 = aoi_0_3;
    }

    public String getAoi_0_5() {
        return aoi_0_5;
    }

    public void setAoi_0_5(String aoi_0_5) {
        this.aoi_0_5 = aoi_0_5;
    }

    public String getAoi_0_10() {
        return aoi_0_10;
    }

    public void setAoi_0_10(String aoi_0_10) {
        this.aoi_0_10 = aoi_0_10;
    }

    public String getAoi_0_30() {
        return aoi_0_30;
    }

    public void setAoi_0_30(String aoi_0_30) {
        this.aoi_0_30 = aoi_0_30;
    }

    public String getAoi_all() {
        return aoi_all;
    }

    public void setAoi_all(String aoi_all) {
        this.aoi_all = aoi_all;
    }

    public String getDest_hq_code() {
        return dest_hq_code;
    }

    public void setDest_hq_code(String dest_hq_code) {
        this.dest_hq_code = dest_hq_code;
    }

    public String getDest_area_code() {
        return dest_area_code;
    }

    public void setDest_area_code(String dest_area_code) {
        this.dest_area_code = dest_area_code;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getCount_0_3() {
        return count_0_3;
    }

    public void setCount_0_3(String count_0_3) {
        this.count_0_3 = count_0_3;
    }

    public String getCount_3_5() {
        return count_3_5;
    }

    public void setCount_3_5(String count_3_5) {
        this.count_3_5 = count_3_5;
    }

    public String getCount_5_10() {
        return count_5_10;
    }

    public void setCount_5_10(String count_5_10) {
        this.count_5_10 = count_5_10;
    }

    public String getCount_10_30() {
        return count_10_30;
    }

    public void setCount_10_30(String count_10_30) {
        this.count_10_30 = count_10_30;
    }

    public String getCount_30() {
        return count_30;
    }

    public void setCount_30(String count_30) {
        this.count_30 = count_30;
    }

    public String getDist_0_3() {
        return dist_0_3;
    }

    public void setDist_0_3(String dist_0_3) {
        this.dist_0_3 = dist_0_3;
    }

    public String getTime_0_3() {
        return time_0_3;
    }

    public void setTime_0_3(String time_0_3) {
        this.time_0_3 = time_0_3;
    }

    public String getCb_0_3() {
        return cb_0_3;
    }

    public void setCb_0_3(String cb_0_3) {
        this.cb_0_3 = cb_0_3;
    }

    public String getDist_0_5() {
        return dist_0_5;
    }

    public void setDist_0_5(String dist_0_5) {
        this.dist_0_5 = dist_0_5;
    }

    public String getTime_0_5() {
        return time_0_5;
    }

    public void setTime_0_5(String time_0_5) {
        this.time_0_5 = time_0_5;
    }

    public String getCb_0_5() {
        return cb_0_5;
    }

    public void setCb_0_5(String cb_0_5) {
        this.cb_0_5 = cb_0_5;
    }

    public String getDist_0_10() {
        return dist_0_10;
    }

    public void setDist_0_10(String dist_0_10) {
        this.dist_0_10 = dist_0_10;
    }

    public String getTime_0_10() {
        return time_0_10;
    }

    public void setTime_0_10(String time_0_10) {
        this.time_0_10 = time_0_10;
    }

    public String getCb_0_10() {
        return cb_0_10;
    }

    public void setCb_0_10(String cb_0_10) {
        this.cb_0_10 = cb_0_10;
    }

    public String getDist_0_30() {
        return dist_0_30;
    }

    public void setDist_0_30(String dist_0_30) {
        this.dist_0_30 = dist_0_30;
    }

    public String getTime_0_30() {
        return time_0_30;
    }

    public void setTime_0_30(String time_0_30) {
        this.time_0_30 = time_0_30;
    }

    public String getCb_0_30() {
        return cb_0_30;
    }

    public void setCb_0_30(String cb_0_30) {
        this.cb_0_30 = cb_0_30;
    }

    public String getDist_all() {
        return dist_all;
    }

    public void setDist_all(String dist_all) {
        this.dist_all = dist_all;
    }

    public String getTime_all() {
        return time_all;
    }

    public void setTime_all(String time_all) {
        this.time_all = time_all;
    }

    public String getCb_all() {
        return cb_all;
    }

    public void setCb_all(String cb_all) {
        this.cb_all = cb_all;
    }

    public String getAvg_0_3() {
        return avg_0_3;
    }

    public void setAvg_0_3(String avg_0_3) {
        this.avg_0_3 = avg_0_3;
    }

    public String getAvg_3_5() {
        return avg_3_5;
    }

    public void setAvg_3_5(String avg_3_5) {
        this.avg_3_5 = avg_3_5;
    }

    public String getAvg_5_10() {
        return avg_5_10;
    }

    public void setAvg_5_10(String avg_5_10) {
        this.avg_5_10 = avg_5_10;
    }

    public String getAvg_10_30() {
        return avg_10_30;
    }

    public void setAvg_10_30(String avg_10_30) {
        this.avg_10_30 = avg_10_30;
    }

    public String getAvg_30() {
        return avg_30;
    }

    public void setAvg_30(String avg_30) {
        this.avg_30 = avg_30;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
