package com.sf.gis.java.sds.controller;


import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.service.PullProxyDeptDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PullProxyDeptDataController {
    private static final Logger logger = LoggerFactory.getLogger(PullProxyDeptDataController.class);

    private PullProxyDeptDataService pullProxyDeptService;
    private Map<String, String> configMap;

    public PullProxyDeptDataController(Map<String, String> configMap) {
        pullProxyDeptService = new PullProxyDeptDataService();
        this.configMap = configMap;
    }

    public void start() {
        String[] date = findDaysOneByOne(configMap);
        pullProxyDeptService.pullDataByDay(date);
    }

    /**
     * 获取天数，列出所有天数
     *
     * @param configMap
     * @return
     */
    private String[] findDaysOneByOne(Map<String, String> configMap) {

        int days = Integer.valueOf(configMap.get(ConfigKey.days.name()));
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        List<String> date = new ArrayList<>();
        for (int i = 0; i < days; i++) {
            date.add(DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + i));
        }
        logger.error(JSON.toJSONString(date));
        return date.toArray(new String[date.size()]);
    }

    /**
     * 获取天数，第一天和最后一天
     *
     * @param configMap
     * @return
     */
    @SuppressWarnings("unused")
    private String[] findDays(Map<String, String> configMap) {

        int days = Integer.valueOf(configMap.get(ConfigKey.days.name()));
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        String[] date = new String[]{DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + days - 1),
                DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays)};
        return date;
    }

}
