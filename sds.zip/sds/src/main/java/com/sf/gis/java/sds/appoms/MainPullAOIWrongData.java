package com.sf.gis.java.sds.appoms;


import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import com.sf.gis.java.sds.controller.PullAOIWrongDataController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

public class MainPullAOIWrongData {
    private static final Logger logger = LoggerFactory.getLogger(MainPullAOIWrongData.class);

    public static void main(String[] args) throws IOException {
        // logger.error("begin Main");
        // logger.error("高峰不让跑");
        // System.exit(0);
        long begin = System.currentTimeMillis();
        try {
            start(args);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
            logger.error("over:" + (System.currentTimeMillis() - begin));
            System.exit(-1);
        }
        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
        Map<String, String> configMap = ConfigUtil
                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");
        PullAOIWrongDataController sssWrongDistribute = new PullAOIWrongDataController(configMap);
        int daysAgo = 1;
        if (args.length == 1) {
            daysAgo = Integer.valueOf(args[0]);
        }
        sssWrongDistribute.start(daysAgo);

    }

}
