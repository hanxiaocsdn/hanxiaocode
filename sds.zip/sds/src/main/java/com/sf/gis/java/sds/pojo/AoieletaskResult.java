package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoieletaskResult implements Serializable {
    @Column(name = "batch_no")
    private String batch_no;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "address")
    private String address;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "addr_ele")
    private String addr_ele;
    @Column(name = "ele")
    private String ele;
    @Column(name = "climb")
    private String climb;
    @Column(name = "group_id")
    private String group_id;
    @Column(name = "now_ele")
    private String now_ele;
    @Column(name = "now_src")
    private String now_src;
    @Column(name = "is_elevator")
    private String is_elevator;
    @Column(name = "data_src")
    private String data_src;
    @Column(name = "cms_address")
    private String cms_address;
    @Column(name = "cms_aoi_id")
    private String cms_aoi_id;
    @Column(name = "inc_day")
    private String inc_day;

    private String insertSource100Resp;
    private String insertSource99Resp;
    private String deleteResp;

    public String getDeleteResp() {
        return deleteResp;
    }

    public void setDeleteResp(String deleteResp) {
        this.deleteResp = deleteResp;
    }

    public String getInsertSource100Resp() {
        return insertSource100Resp;
    }

    public void setInsertSource100Resp(String insertSource100Resp) {
        this.insertSource100Resp = insertSource100Resp;
    }

    public String getInsertSource99Resp() {
        return insertSource99Resp;
    }

    public void setInsertSource99Resp(String insertSource99Resp) {
        this.insertSource99Resp = insertSource99Resp;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCms_address() {
        return cms_address;
    }

    public void setCms_address(String cms_address) {
        this.cms_address = cms_address;
    }

    public String getCms_aoi_id() {
        return cms_aoi_id;
    }

    public void setCms_aoi_id(String cms_aoi_id) {
        this.cms_aoi_id = cms_aoi_id;
    }

    public String getIs_elevator() {
        return is_elevator;
    }

    public void setIs_elevator(String is_elevator) {
        this.is_elevator = is_elevator;
    }

    public String getData_src() {
        return data_src;
    }

    public void setData_src(String data_src) {
        this.data_src = data_src;
    }

    public String getNow_ele() {
        return now_ele;
    }

    public void setNow_ele(String now_ele) {
        this.now_ele = now_ele;
    }

    public String getNow_src() {
        return now_src;
    }

    public void setNow_src(String now_src) {
        this.now_src = now_src;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getEle() {
        return ele;
    }

    public void setEle(String ele) {
        this.ele = ele;
    }

    public String getClimb() {
        return climb;
    }

    public void setClimb(String climb) {
        this.climb = climb;
    }

    public String getBatch_no() {
        return batch_no;
    }

    public void setBatch_no(String batch_no) {
        this.batch_no = batch_no;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAddr_ele() {
        return addr_ele;
    }

    public void setAddr_ele(String addr_ele) {
        this.addr_ele = addr_ele;
    }
}
