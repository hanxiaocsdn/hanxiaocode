package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 地址详细信息
 * @author 01370539 created on Aug.12 2021
 */
@Table
public class SfpAddrPush implements Serializable {
    @Column(name = "province")
    private String province;    // 省
    @Column(name = "city")
    private String city;    // 市
    @Column(name = "city_code")
    private String cityCode;    // 城市编码
    @Column(name = "district")
    private String district;    // 区
    @Column(name = "aoi_xy")
    private String aoiXy;    // 坐标AOI，来自dept2
    @Column(name = "aoi_xy_type")
    private String aoiXyType;    // 坐标AOI类型
    @Column(name = "aoi_xy_type_name")
    private String aoiXyTypeName;    // 坐标AOI类型名称
    @Column(name = "addr")
    private String addr;    // 地址
    @Column(name = "split")
    private String split;    // 切词
    @Column(name = "split_key")
    private String splitKey;    // 坐标精度（来自地理编码服务）
    @Column(name = "split_key_level")
    private String splitKeyLevel;    // 切词主体的级别
    @Column(name = "key_id")
    private String keyId;    // 同一地址标识
    @Column(name = "poi")
    private String poi;    // poi
    @Column(name = "building")
    private String building;    // 楼栋
    @Column(name = "sk_poi")
    private String skPoi;    // poi,来自split_key
    @Column(name = "sk_rule")
    private String skRule;    // 提取出来的规则,来自split_key
    @Column(name = "sk_rule_use")
    private String skRuleUse;    // 最终使用的规则,来自split_key
    @Column(name = "lng")
    private String lng;    // 坐标聚合中间点经度
    @Column(name = "lat")
    private String lat;    // 坐标聚合中间点纬度
    @Column(name = "freq")
    private String freq;    // 频次
    @Column(name = "is_effect")
    private String isEffect;    // 是否有效: 0：无效；1：有效；2：没有经过任何第三方坐标校验
    @Column(name = "effect_type")
    private String effectType;    // 有效类型: 0：无效；1……n：有效，数值越大，有效度越高；
    @Column(name = "source")
    private String source;    // 有效类型: 0：无效；1……n：有效，数值越大，有效度越高；
    @Column(name = "push_time")
    private String pushTime;    // 有效类型: 0：无效；1……n：有效，数值越大，有效度越高；
    @Column(name = "inc_day")
    private String incDay;    // 推送日期

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getAoiXy() {
        return aoiXy;
    }

    public void setAoiXy(String aoiXy) {
        this.aoiXy = aoiXy;
    }

    public String getAoiXyType() {
        return aoiXyType;
    }

    public void setAoiXyType(String aoiXyType) {
        this.aoiXyType = aoiXyType;
    }

    public String getAoiXyTypeName() {
        return aoiXyTypeName;
    }

    public void setAoiXyTypeName(String aoiXyTypeName) {
        this.aoiXyTypeName = aoiXyTypeName;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getSplitKey() {
        return splitKey;
    }

    public void setSplitKey(String splitKey) {
        this.splitKey = splitKey;
    }

    public String getSplitKeyLevel() {
        return splitKeyLevel;
    }

    public void setSplitKeyLevel(String splitKeyLevel) {
        this.splitKeyLevel = splitKeyLevel;
    }

    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    public String getPoi() {
        return poi;
    }

    public void setPoi(String poi) {
        this.poi = poi;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getSkPoi() {
        return skPoi;
    }

    public void setSkPoi(String skPoi) {
        this.skPoi = skPoi;
    }

    public String getSkRule() {
        return skRule;
    }

    public void setSkRule(String skRule) {
        this.skRule = skRule;
    }

    public String getSkRuleUse() {
        return skRuleUse;
    }

    public void setSkRuleUse(String skRuleUse) {
        this.skRuleUse = skRuleUse;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getIsEffect() {
        return isEffect;
    }

    public void setIsEffect(String isEffect) {
        this.isEffect = isEffect;
    }

    public String getEffectType() {
        return effectType;
    }

    public void setEffectType(String effectType) {
        this.effectType = effectType;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getPushTime() {
        return pushTime;
    }

    public void setPushTime(String pushTime) {
        this.pushTime = pushTime;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "SfpAddrPush{" +
                "province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", district='" + district + '\'' +
                ", aoiXy='" + aoiXy + '\'' +
                ", aoiXyType='" + aoiXyType + '\'' +
                ", aoiXyTypeName='" + aoiXyTypeName + '\'' +
                ", addr='" + addr + '\'' +
                ", split='" + split + '\'' +
                ", splitKey='" + splitKey + '\'' +
                ", splitKeyLevel='" + splitKeyLevel + '\'' +
                ", keyId='" + keyId + '\'' +
                ", poi='" + poi + '\'' +
                ", building='" + building + '\'' +
                ", skPoi='" + skPoi + '\'' +
                ", skRule='" + skRule + '\'' +
                ", skRuleUse='" + skRuleUse + '\'' +
                ", lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", freq='" + freq + '\'' +
                ", isEffect='" + isEffect + '\'' +
                ", effectType='" + effectType + '\'' +
                ", source='" + source + '\'' +
                ", pushTime='" + pushTime + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
