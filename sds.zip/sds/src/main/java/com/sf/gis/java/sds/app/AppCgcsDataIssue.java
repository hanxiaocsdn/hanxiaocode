package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.CgcsDataIssueController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppCgcsDataIssue {
    private static Logger logger = LoggerFactory.getLogger(AppCgcsDataIssue.class);

    public static void main(String[] args) {
        String today = args[0];
        String startDate = args[1];
        String endDate = args[2];
        logger.error("today:{},startDate:{},endDate:{} ", today, startDate, endDate);
        logger.error("run start");
        new CgcsDataIssueController().start(today, startDate, endDate);
        logger.error("run end");
    }
}
