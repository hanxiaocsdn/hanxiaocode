package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SpecialInboundIdentificationReportController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id：730577(【特殊入仓】自动化每周定时聚合大网未识别地址)
 * 业务方：01427169（邓蔼娟）
 * 研发：01399581（匡仁衡）
 */
public class AppSpecialInboundIdentificationReport {
    private static Logger logger = LoggerFactory.getLogger(AppSpecialInboundIdentificationReport.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new SpecialInboundIdentificationReportController().start(date);
        logger.error("run end");
    }
}
