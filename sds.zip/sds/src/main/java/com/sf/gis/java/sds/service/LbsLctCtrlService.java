package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.pojo.LbsLctCtrl;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;

import java.util.List;

/**
 * lbs定位管控重构（需求：刘雨婷）
 * @author 01370539
 * 2022年7月20日
 */
public class LbsLctCtrlService {

    public JavaRDD<LbsLctCtrl> loadWbHook(SparkInfo si, String incDay) {
        String sql = "select waybill_no, dest_hq_code, dest_zone_code, aoi_id, aoi_type_name, aoi_type_code, aoi_x aoi_lng,aoi_y aoi_lat, delivery_lgt dlv_lng, delivery_lat dlv_lat, deliver_emp_code couriercode, consignee_phone, concat_ws(',',service_prod_code) as service_prod_code, inc_day from dm_gis.tt_waybill_hook where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadFvpRout(SparkInfo si, String incDay) {
        String startDate = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2);
        String sql = "select waybill_no, couriercode, barscantm, opcode, inc_day from (select waybillno waybill_no, couriercode, barscantm, opcode, inc_day, row_number() over(partition by waybillno,opcode order by barscantm) rn from ods_kafka_fvp.fvp_core_fact_route where inc_day between '" + startDate + "' and '" + incDay + "' and opcode in ('80','130','125','83','72','67','82', '99')) tmp where tmp.rn = 1";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadLocTrack(SparkInfo si, String incDay, String ak, JavaRDD<String> rddCouriercode) {
        List<String> empList = rddCouriercode.collect();
        String empStr = "";
        for (String emp : empList) {
            empStr += ",'" + emp + "'";
        }
        String sql = "select un couriercode, zx track_lng, zy track_lat, tm track_tm, tp track_tp, ad track_ad, ak track_ak, inc_day from dm_gis.esg_gis_loc_trajectory where inc_day = '" + incDay + "' and ak = '" + ak + "' and dx <> '-1.0' and tp in ('1','5','6','8') and un in (" + empStr.substring(1) + ")";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadLocTrack(SparkInfo si, String incDay) {
        String sql = "select un couriercode, zx track_lng, zy track_lat, tm track_tm, tp track_tp, ad track_ad, ak track_ak, inc_day from dm_gis.esg_gis_loc_trajectory where inc_day = '" + incDay + "' and ak = '1' and dx <> '-1.0' and tp in ('1','5','6','8')";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadEvent(SparkInfo si, String incDay) {
        String sql = "select distinct sf_user_id couriercode, properties_waybillno waybill_no, event_id from dm_sfxg.product_inc_ubas_next_app where inc_day = '" + incDay + "' and (event_id = '21506' or event_id = '21510')";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadDb05Dld(SparkInfo si) {
        String sql = "select zno_code dest_zone_code from dm_gis.st_department where type_code='DB05-DLD'";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadToBox(SparkInfo si, String incDay) {
        String sql = "select waybill_no from dm_terminal.cvs_deliver_dtl_di where inc_day = '" + incDay + "' and is_cvs_deliver = '是' and (waybill_no <> '' or waybill_no is not null)";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadToShop(SparkInfo si, String incDay) {
        String sql = "select waybill_no from dm_terminal.yufff_fengchao_shoupai_detail_pj where inc_day = '" + incDay + "' and (waybill_no <> '' or waybill_no is not null)";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadComplaint(SparkInfo si, String incDay) {
        String sql = "select waybill_no, new_dir1 complaint1, new_dir2 complaint2, new_dir3 complaint3 from dwd.dwd_qc_cos_check_mul_duty_dtl_di where inc_day = '" + incDay + "' and is_area_check_new = '是'";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }

    public JavaRDD<LbsLctCtrl> loadRs(SparkInfo si, String incDay) {
        String sql = "select * from dm_gis.lbs_lctctrl_dpp where inc_day = '" + incDay + "'";
        return DataUtil.loadData(si, sql, LbsLctCtrl.class);
    }



}
