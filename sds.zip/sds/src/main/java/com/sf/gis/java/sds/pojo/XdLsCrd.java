package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 客户下单位置信息和揽收位置信息分析
 * @author 01370539
 * Created on Jun.15 2022
 * 需求人员：赵瑜婷
 */
@Table(name="")
public class XdLsCrd implements Serializable {
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "addr_aoi_id")
    private String addrAoiId;
    @Column(name = "addr_aoi_code")
    private String addrAoiCode;
    @Column(name = "addr_aoi_area")
    private String addrAoiArea;
    @Column(name = "addr_zc")
    private String addrZc;
    @Column(name = "ls_xg_zc")
    private String lsXgZc;
    @Column(name = "ls_lng")
    private String lsLng;
    @Column(name = "ls_lat")
    private String lsLat;
    @Column(name = "ls_aoi_id")
    private String lsAoiId;
    @Column(name = "ls_aoi_code")
    private String lsAoiCode;
    @Column(name = "ls_aoi_area")
    private String lsAoiArea;
    @Column(name = "ls_xy_zc")
    private String lsXyZc;
    @Column(name = "xd_lng")
    private String xdLng;
    @Column(name = "xd_lat")
    private String xdLat;
    @Column(name = "xd_aoi_id")
    private String xdAoiId;
    @Column(name = "xd_aoi_code")
    private String xdAoiCode;
    @Column(name = "xd_aoi_area")
    private String xdAoiArea;
    @Column(name = "xd_xy_zc")
    private String xdXyZc;
    @Column(name = "inc_day")
    private String incDay;

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getAddrAoiId() {
        return addrAoiId;
    }

    public void setAddrAoiId(String addrAoiId) {
        this.addrAoiId = addrAoiId;
    }

    public String getAddrAoiCode() {
        return addrAoiCode;
    }

    public void setAddrAoiCode(String addrAoiCode) {
        this.addrAoiCode = addrAoiCode;
    }

    public String getAddrAoiArea() {
        return addrAoiArea;
    }

    public void setAddrAoiArea(String addrAoiArea) {
        this.addrAoiArea = addrAoiArea;
    }

    public String getAddrZc() {
        return addrZc;
    }

    public void setAddrZc(String addrZc) {
        this.addrZc = addrZc;
    }

    public String getLsXgZc() {
        return lsXgZc;
    }

    public void setLsXgZc(String lsXgZc) {
        this.lsXgZc = lsXgZc;
    }

    public String getLsLng() {
        return lsLng;
    }

    public void setLsLng(String lsLng) {
        this.lsLng = lsLng;
    }

    public String getLsLat() {
        return lsLat;
    }

    public void setLsLat(String lsLat) {
        this.lsLat = lsLat;
    }

    public String getLsAoiId() {
        return lsAoiId;
    }

    public void setLsAoiId(String lsAoiId) {
        this.lsAoiId = lsAoiId;
    }

    public String getLsAoiCode() {
        return lsAoiCode;
    }

    public void setLsAoiCode(String lsAoiCode) {
        this.lsAoiCode = lsAoiCode;
    }

    public String getLsAoiArea() {
        return lsAoiArea;
    }

    public void setLsAoiArea(String lsAoiArea) {
        this.lsAoiArea = lsAoiArea;
    }

    public String getLsXyZc() {
        return lsXyZc;
    }

    public void setLsXyZc(String lsXyZc) {
        this.lsXyZc = lsXyZc;
    }

    public String getXdLng() {
        return xdLng;
    }

    public void setXdLng(String xdLng) {
        this.xdLng = xdLng;
    }

    public String getXdLat() {
        return xdLat;
    }

    public void setXdLat(String xdLat) {
        this.xdLat = xdLat;
    }

    public String getXdAoiId() {
        return xdAoiId;
    }

    public void setXdAoiId(String xdAoiId) {
        this.xdAoiId = xdAoiId;
    }

    public String getXdAoiCode() {
        return xdAoiCode;
    }

    public void setXdAoiCode(String xdAoiCode) {
        this.xdAoiCode = xdAoiCode;
    }

    public String getXdAoiArea() {
        return xdAoiArea;
    }

    public void setXdAoiArea(String xdAoiArea) {
        this.xdAoiArea = xdAoiArea;
    }

    public String getXdXyZc() {
        return xdXyZc;
    }

    public void setXdXyZc(String xdXyZc) {
        this.xdXyZc = xdXyZc;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "XdLsCrd{" +
                "waybillNo='" + waybillNo + '\'' +
                ", addrAoiId='" + addrAoiId + '\'' +
                ", addrAoiCode='" + addrAoiCode + '\'' +
                ", addrAoiArea='" + addrAoiArea + '\'' +
                ", addrZc='" + addrZc + '\'' +
                ", lsXgZc='" + lsXgZc + '\'' +
                ", lsLng='" + lsLng + '\'' +
                ", lsLat='" + lsLat + '\'' +
                ", lsAoiId='" + lsAoiId + '\'' +
                ", lsAoiCode='" + lsAoiCode + '\'' +
                ", lsAoiArea='" + lsAoiArea + '\'' +
                ", lsXyZc='" + lsXyZc + '\'' +
                ", xdLng='" + xdLng + '\'' +
                ", xdLat='" + xdLat + '\'' +
                ", xdAoiId='" + xdAoiId + '\'' +
                ", xdAoiCode='" + xdAoiCode + '\'' +
                ", xdAoiArea='" + xdAoiArea + '\'' +
                ", xdXyZc='" + xdXyZc + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
