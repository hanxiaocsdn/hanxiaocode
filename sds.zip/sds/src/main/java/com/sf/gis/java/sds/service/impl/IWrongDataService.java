package com.sf.gis.java.sds.service.impl;


import com.sf.gis.java.sds.bean.DeptData;

import java.util.List;

public interface IWrongDataService {

    List<DeptData> getWrongDataDiff(String date);

    List<DeptData> getWrongDataDeptEmpty(String date, String cityCode);

    void createDiffData(String date);

    void createDeptEmptyData(String date, String gisEmptyCity);
}