package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.NlocServicePopFeedbackData;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 任务id:1015154(网络定位服务80管控应用弹窗反馈数据运营闭环)
 * 研发：01399581（匡仁衡）
 * 业务：01407317（成谷胜）
 */
public class AppNlocServicePopFeedbackDataOperationLoop {
    private static final Logger logger = Logger.getLogger(AppNlocServicePopFeedbackDataOperationLoop.class);
    private static final String gd = "http://gis-gaode.int.sfcloud.local:1080/optimalMatching?address=%s";
    private static final String getCircleAoiBase = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=%s";

    private static final String account = "01399581";
    private static final String taskId = "1015154";
    private static final String taskName = "网络定位服务80管控应用弹窗反馈数据运营闭环";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppNlocServicePopFeedbackDataOperationLoop");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取数据源");
        JavaRDD<NlocServicePopFeedbackData> rdd = getData(spark, sc, date);
        logger.error("获取高德经纬度");
        JavaRDD<NlocServicePopFeedbackData> gdRdd = getGdCoords(rdd, spark);
        logger.error("获取高德aoi和妥投aoi");
        JavaRDD<NlocServicePopFeedbackData> aoiRdd = getAoi(gdRdd, spark);
        logger.error("打标签");
        JavaRDD<NlocServicePopFeedbackData> tagRdd = getTag(aoiRdd);
        logger.error("结果存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_ubas_next_app_pop_feedback_operation_loop_di", NlocServicePopFeedbackData.class, tagRdd, "inc_day");
        tagRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static JavaRDD<NlocServicePopFeedbackData> getTag(JavaRDD<NlocServicePopFeedbackData> aoiRdd) {
        JavaRDD<NlocServicePopFeedbackData> tagRdd = aoiRdd.map(o -> {
            String wifi_aoi = o.getWifi_aoi();
            String aoi_id = o.getAoi_id();
            String gdaoi = o.getGdaoi();
            List<String> aois80 = o.getList();
            String tag = "";
            if (StringUtils.isNotEmpty(wifi_aoi) && StringUtils.equals(wifi_aoi, aoi_id)) {

            } else {
                if (StringUtils.isNotEmpty(wifi_aoi) && aois80 != null && aois80.size() > 0 && aois80.contains(wifi_aoi)) {
                    if (StringUtils.equals(wifi_aoi, gdaoi)) {
                        tag = "GIS_WRONG";
                    } else {
                        if (StringUtils.isNotEmpty(aoi_id) && StringUtils.equals(aoi_id, gdaoi)) {
                            tag = "NOT_TODOOR";
                        }
                    }
                } else {
                    if (StringUtils.isNotEmpty(aoi_id) && aois80 != null && aois80.size() > 0 && aois80.contains(aoi_id)) {
                        tag = "WIFI_WRONG";
                    }
                }
            }

            o.setTag(tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:" + tagRdd.count());
        aoiRdd.unpersist();
        return tagRdd;
    }

    public static JavaRDD<NlocServicePopFeedbackData> getAoi(JavaRDD<NlocServicePopFeedbackData> gdRdd, SparkSession spark) {
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", gdRdd.count() * 2, 4);
        JavaRDD<NlocServicePopFeedbackData> aoiRdd = gdRdd.repartition(4).map(o -> {
            String coords_gd = o.getCoords_gd();
            if (StringUtils.isNotEmpty(coords_gd)) {
                String[] split = coords_gd.split(",");
                if (split.length >= 2) {
                    String x = split[0];
                    String y = split[1];
                    String req = String.format(getCircleAoiBase, x, y, 1);
                    String gd_xy_res = HttpInvokeUtil.sendGet(req);
                    o.setGd_xy_res(gd_xy_res);
                    String gd_aoi = "";
                    try {
                        gd_aoi = JSON.parseObject(gd_xy_res).getJSONArray("data").getJSONObject(0).getString("id");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    o.setGdaoi(gd_aoi);
                }
            }

            String delivery_lgt = o.getDelivery_lgt();
            String delivery_lat = o.getDelivery_lat();
            if (StringUtils.isNotEmpty(delivery_lgt) && StringUtils.isNotEmpty(delivery_lat)) {
                String req = String.format(getCircleAoiBase, delivery_lgt, delivery_lat, 50);
                String delivery_xy_res = HttpInvokeUtil.sendGet(req);
                o.setDelivery_xy_res(delivery_xy_res);
                ArrayList<String> list = new ArrayList<>();
                try {
                    JSONArray data = JSON.parseObject(delivery_xy_res).getJSONArray("data");
                    for (int i = 0; i < data.size(); i++) {
                        JSONObject jsonObject = data.getJSONObject(i);
                        String id = jsonObject.getString("id");
                        list.add(id);
                    }
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setList(list);
                o.setAois80(list.size() > 0 ? String.join(",", list) : "");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:" + aoiRdd.count());
        gdRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        return aoiRdd;
    }

    public static JavaRDD<NlocServicePopFeedbackData> getGdCoords(JavaRDD<NlocServicePopFeedbackData> rdd, SparkSession spark) {
        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", rdd.count(), 4);
        JavaRDD<NlocServicePopFeedbackData> gdRdd = rdd.repartition(4).map(o -> {
            String address = o.getAddress();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(gd, URLEncoder.encode(address, "UTF-8"));
                String gd_res = HttpInvokeUtil.sendGet(req);
                o.setGd_res(gd_res);
                String coords_gd = "";
                try {
                    coords_gd = JSON.parseObject(gd_res).getJSONArray("gdResult").getJSONObject(0).getString("location");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                //111.002419,21.636007
                o.setCoords_gd(coords_gd);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:" + gdRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);
        return gdRdd;
    }

    public static JavaRDD<NlocServicePopFeedbackData> getData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select " +
                "  t1.sf_user_id sf_user_id, " +
                "  t1.opera_time opera_time, " +
                "  t1.zone_code zone_code, " +
                "  t1.waybillno waybillno, " +
                "  t1.properties_type properties_type, " +
                "  t1.properties_content properties_content, " +
                "  t1.city city, " +
                "  t1.inc_day inc_day, " +
                "  t2.signin_time signin_time, " +
                "  t2.delivery_lgt delivery_lgt, " +
                "  t2.delivery_lat delivery_lat, " +
                "  t2.aoi_id aoi_id, " +
                "  t3.address address, " +
                "  t3.match_type match_type, " +
                "  t3.current_tm current_tm, " +
                "  t3.wifilist wifilist, " +
                "  t3.wifimatchaddresslist wifimatchaddresslist, " +
                "  t3.wifimatchtype wifimatchtype," +
                "  t3.wifi_aoi wifi_aoi " +
                "from " +
                "  ( " +
                "    select " +
                "      sf_user_id, " +
                "      opera_time, " +
                "      zone_code, " +
                "      waybillno, " +
                "      properties_type, " +
                "      properties_content, " +
                "      city, " +
                "      inc_day " +
                "    from " +
                "      dm_sfxg.product_inc_ubas_next_app " +
                "    where " +
                "      inc_day = '%s' " +
                "      and event_id = '1320' " +
                "      and ( " +
                "        zone_code like '022%%' " +
                "        or zone_code like '755%%' " +
                "        or zone_code like '510%%' " +
                "      ) " +
                "  ) t1 " +
                "  left join ( " +
                "    select " +
                "      waybill_no, " +
                "      dest_dist_code, " +
                "      signin_tm signin_time, " +
                "      delivery_lgt, " +
                "      delivery_lat, " +
                "      aoi_id " +
                "    from " +
                "      dm_gis.tt_waybill_hook " +
                "    where " +
                "      inc_day = '%s' " +
                "      and dest_dist_code in ('755', '022', '510') " +
                "  ) t2 " +
                "  on t1.waybillno = t2.waybill_no " +
                "  join ( " +
                "    select " +
                "      * " +
                "    from " +
                "      ( " +
                "        select " +
                "          waybill_no, " +
                "          address, " +
                "          match_type, " +
                "          current_tm, " +
                "          wifilist, " +
                "          wifimatchaddresslist, " +
                "          wifimatchtype, " +
                "          '' wifi_aoi, " +
                "          row_number() over( " +
                "            partition by waybill_no " +
                "            order by " +
                "              current_tm desc " +
                "          ) as rn " +
                "        from " +
                "          dm_gis.lbs_log_pnsaoi " +
                "        where " +
                "          inc_day = '%s' " +
                "          and city in ('755', '022', '510') " +
                "          and waybill_no is not null " +
                "          and waybill_no <> '' " +
                "          and wifimatchtype = 'NOT_MATCH' " +
                "      ) t " +
                "    where " +
                "      t.rn = 1 " +
                "  ) t3 " +
                "  on t1.waybillno = t3.waybill_no", date, date, date);
        JavaRDD<NlocServicePopFeedbackData> rdd = DataUtil.loadData(spark, sc, sql, NlocServicePopFeedbackData.class).map(o -> {
            String wifimatchaddresslist = o.getWifimatchaddresslist();
            String wifi_aoi = "";
            try {
                wifi_aoi = JSON.parseArray(wifimatchaddresslist).getJSONObject(0).getString("aoiId");
            } catch (Exception e) {
//                e.printStackTrace();
            }
            o.setWifi_aoi(wifi_aoi);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        return rdd;
    }
}
