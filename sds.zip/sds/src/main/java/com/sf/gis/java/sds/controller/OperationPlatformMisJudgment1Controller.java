package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.AoiRealAccRateReport;
import com.sf.gis.java.sds.pojo.OperationPlatformMisJudgment;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OperationPlatformMisJudgment1Controller implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(OperationPlatformMisJudgment1Controller.class);

    public void start(String today) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();


        //取数时间上个月 月初-月尾
        String firstDayOfLastMonth = DateUtil.getFirstDayOfMonth(DateUtil.getMouthBefore(today, 1));
        String lastDayOfLastMonth = DateUtil.getLastDayOfMonth(DateUtil.getMouthBefore(today, 1));
        logger.error("firstDayOfLastMonth:{}, lastDayOfLastMonth:{}", firstDayOfLastMonth, lastDayOfLastMonth);
        JavaRDD<AoiRealAccRateReport> aoiRealAccRateReportRdd = loadSourceData(spark, sc, firstDayOfLastMonth, lastDayOfLastMonth).filter(o -> {
            boolean flag = true;
            if (StringUtils.isEmpty(o.getRw_search_w_amount()) && StringUtils.isEmpty(o.getAoi_name_chk_w_amount()) && StringUtils.isEmpty(o.getSuspected_wrong_amount()) &&
                    StringUtils.isEmpty(o.getBusiness_wrong_amount()) && StringUtils.isEmpty(o.getXg_track_seq_amount()) && StringUtils.isEmpty(o.getRw_search_c_amount()) &&
                    StringUtils.isEmpty(o.getAoi_name_chk_c_amount()) && StringUtils.isEmpty(o.getSpecial_business_amount()) && StringUtils.isEmpty(o.getBusiness_correct_amount())) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRealAccRateReportRdd cnt:{}", aoiRealAccRateReportRdd.count());

        JavaRDD<AoiRealAccRateReport> zcRdd = aoiRealAccRateReportRdd.filter(o -> StringUtils.equals(o.getStat_type(), "ZC")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AoiRealAccRateReport> cityRdd = aoiRealAccRateReportRdd.filter(o -> StringUtils.equals(o.getStat_type(), "CITY")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AoiRealAccRateReport> regionRdd = aoiRealAccRateReportRdd.filter(o -> StringUtils.equals(o.getStat_type(), "REGION")).map(o -> {
            String region = o.getRegion();
            if (StringUtils.equals(region, "潮汕区") || StringUtils.equals(region, "惠州区")) {
                region = "粤东区";
            }
            if (StringUtils.equals(region, "香港区") || StringUtils.equals(region, "澳门区")) {
                region = "香港区";
            }
            o.setRegion(region);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcRdd cnt:{}", zcRdd.count());
        logger.error("cityRdd cnt:{}", cityRdd.count());
        logger.error("regionRdd cnt:{}", regionRdd.count());
        aoiRealAccRateReportRdd.unpersist();

        //TODO 取数时间 上个月月初-当天  new_data_date：上个月月初-月尾
        JavaRDD<OperationPlatformMisJudgment> addrCntRdd = loadAddrCntData(spark, sc, firstDayOfLastMonth, today, lastDayOfLastMonth).filter(o -> StringUtils.isNotEmpty(o.getAddress_count_zc())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrCntRdd cnt:{}", addrCntRdd.count());

        JavaRDD<AddressInfoMapDi> addressInfoMapDiRdd = loadAddressInfoMap(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addressInfoMapDiRdd cnt:{}", addressInfoMapDiRdd.count());

        JavaRDD<OperationPlatformMisJudgment> addrCntZcRdd = addrCntRdd.mapToPair(o -> new Tuple2<>(o.getCity_code(), o))
                .leftOuterJoin(addressInfoMapDiRdd.mapToPair(o -> new Tuple2<>(o.getCitycode(), o)))
                .map(tp -> {
                    OperationPlatformMisJudgment o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AddressInfoMapDi addressInfoMapDi = tp._2._2.get();
                        String region = addressInfoMapDi.getRegion();
                        if (StringUtils.equals(region, "潮汕区") || StringUtils.equals(region, "惠州区")) {
                            region = "粤东区";
                        }
                        if (StringUtils.equals(region, "香港区") || StringUtils.equals(region, "澳门区")) {
                            region = "香港区";
                        }
                        o.setRegion(region);
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getZno_code() + "_" + o.getInc_day(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .mapToPair(o -> new Tuple2<>(o.getZno_code(), o))
                .groupByKey()
                .map(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    OperationPlatformMisJudgment operationPlatformMisJudgment = list.get(0);
                    int addressCountZc = list.stream().map(o -> Integer.parseInt(o.getAddress_count_zc())).reduce((o1, o2) -> o1 + o2).get();
                    operationPlatformMisJudgment.setAddress_count_zc(addressCountZc + "");

                    return operationPlatformMisJudgment;
                })


                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrCntZcRdd cnt:{}", addrCntZcRdd.count());
        addrCntRdd.unpersist();
        addressInfoMapDiRdd.unpersist();

        JavaRDD<OperationPlatformMisJudgment> addrCntCityRdd = addrCntZcRdd.mapToPair(o -> new Tuple2<>(o.getCity_code(), o))
                .groupByKey()
                .map(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    OperationPlatformMisJudgment operationPlatformMisJudgment = list.get(0);
                    int address_count_zc = list.stream().map(o -> StringUtils.isNotEmpty(o.getAddress_count_zc()) ? Integer.parseInt(o.getAddress_count_zc()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    operationPlatformMisJudgment.setAddress_count_zc(address_count_zc + "");
                    return operationPlatformMisJudgment;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrCntCityRdd cnt:{}", addrCntCityRdd.count());

        JavaRDD<OperationPlatformMisJudgment> addrCntRegionRdd = addrCntZcRdd
                .mapToPair(o -> new Tuple2<>(o.getRegion(), o))
                .groupByKey()
                .map(tp -> {
                    List<OperationPlatformMisJudgment> list = Lists.newArrayList(tp._2);
                    OperationPlatformMisJudgment operationPlatformMisJudgment = list.get(0);
                    int address_count_zc = list.stream().map(o -> StringUtils.isNotEmpty(o.getAddress_count_zc()) ? Integer.parseInt(o.getAddress_count_zc()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    operationPlatformMisJudgment.setAddress_count_zc(address_count_zc + "");
                    return operationPlatformMisJudgment;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrCntRegionRdd cnt:{}", addrCntRegionRdd.count());


        logger.error("开始统计:网点维度");
        JavaRDD<AoiRealAccRateReport> zcAoiRealAddrCntRdd = zcRdd.mapToPair(o -> new Tuple2<>(o.getZonecode(), o))
                .leftOuterJoin(addrCntZcRdd.mapToPair(o -> new Tuple2<>(o.getZno_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    AoiRealAccRateReport o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        OperationPlatformMisJudgment operationPlatformMisJudgment = tp._2._2.get();
                        String address_count_zc = operationPlatformMisJudgment.getAddress_count_zc();
                        o.setAddress_count_zc(address_count_zc);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAoiRealAddrCntRdd cnt:{}", zcAoiRealAddrCntRdd.count());
        zcRdd.unpersist();
        addrCntZcRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> zcWrong_rightRdd = zcAoiRealAddrCntRdd.map(o -> {
            int rw_search_w_amount = StringUtils.isNotEmpty(o.getRw_search_w_amount()) ? Integer.parseInt(o.getRw_search_w_amount()) : 0;
            int aoi_name_chk_w_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_w_amount()) ? Integer.parseInt(o.getAoi_name_chk_w_amount()) : 0;
            int suspected_wrong_amount = StringUtils.isNotEmpty(o.getSuspected_wrong_amount()) ? Integer.parseInt(o.getSuspected_wrong_amount()) : 0;
            int business_wrong_amount = StringUtils.isNotEmpty(o.getBusiness_wrong_amount()) ? Integer.parseInt(o.getBusiness_wrong_amount()) : 0;
            int wrong_amount = rw_search_w_amount + aoi_name_chk_w_amount + suspected_wrong_amount + business_wrong_amount;

            int xg_track_seq_amount = StringUtils.isNotEmpty(o.getXg_track_seq_amount()) ? Integer.parseInt(o.getXg_track_seq_amount()) : 0;
            int rw_search_c_amount = StringUtils.isNotEmpty(o.getRw_search_c_amount()) ? Integer.parseInt(o.getRw_search_c_amount()) : 0;
            int aoi_name_chk_c_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_c_amount()) ? Integer.parseInt(o.getAoi_name_chk_c_amount()) : 0;
            int special_business_amount = StringUtils.isNotEmpty(o.getSpecial_business_amount()) ? Integer.parseInt(o.getSpecial_business_amount()) : 0;
            int business_correct_amount = StringUtils.isNotEmpty(o.getBusiness_correct_amount()) ? Integer.parseInt(o.getBusiness_correct_amount()) : 0;
            int right_amount = xg_track_seq_amount + rw_search_c_amount + aoi_name_chk_c_amount + special_business_amount + business_correct_amount;

            o.setWrong_amount(wrong_amount + "");
            o.setRight_amount(right_amount + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcWrong_rightRdd cnt:{}", zcWrong_rightRdd.count());
        zcAoiRealAddrCntRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> zcStatRdd = zcWrong_rightRdd.mapToPair(o -> new Tuple2<>(o.getZonecode(), o))
                .groupByKey()
                .map(tp -> {
                    List<AoiRealAccRateReport> list = Lists.newArrayList(tp._2);
                    AoiRealAccRateReport aoiRealAccRateReport = list.get(0);

                    int totalWrongAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getWrong_amount()) ? Integer.parseInt(o.getWrong_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalRightAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getRight_amount()) ? Integer.parseInt(o.getRight_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalAddrZcAmount = StringUtils.isNotEmpty(aoiRealAccRateReport.getAddress_count_zc()) ? Integer.parseInt(aoiRealAccRateReport.getAddress_count_zc()) : 0;
                    if (totalAddrZcAmount > totalWrongAmount) {
                        totalAddrZcAmount = totalWrongAmount;
                    }

                    double right_rate = Double.valueOf(totalRightAmount + totalAddrZcAmount) / Double.valueOf(totalWrongAmount + totalRightAmount);

                    aoiRealAccRateReport.setTotalWrongAmount(totalWrongAmount + "");
                    aoiRealAccRateReport.setTotalRightAmount(totalRightAmount + "");
                    aoiRealAccRateReport.setTotalAddrZcAmount(totalAddrZcAmount + "");
                    aoiRealAccRateReport.setRight_rate(right_rate + "");

                    aoiRealAccRateReport.setStat_type("ZC");
                    aoiRealAccRateReport.setStat_type_content(aoiRealAccRateReport.getZonecode());
                    return aoiRealAccRateReport;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcStatRdd cnt:{}", zcStatRdd.count());
        zcWrong_rightRdd.unpersist();

        logger.error("开始统计:城市维度");
        JavaRDD<AoiRealAccRateReport> cityAoiRealAddrCntRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getCity_code(), o))
                .leftOuterJoin(addrCntCityRdd.mapToPair(o -> new Tuple2<>(o.getCity_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    AoiRealAccRateReport o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        OperationPlatformMisJudgment operationPlatformMisJudgment = tp._2._2.get();
                        String address_count_zc = operationPlatformMisJudgment.getAddress_count_zc();
                        o.setAddress_count_zc(address_count_zc);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityAoiRealAddrCntRdd cnt:{}", cityAoiRealAddrCntRdd.count());
        cityRdd.unpersist();
        addrCntCityRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> cityWrong_rightRdd = cityAoiRealAddrCntRdd.map(o -> {
            int rw_search_w_amount = StringUtils.isNotEmpty(o.getRw_search_w_amount()) ? Integer.parseInt(o.getRw_search_w_amount()) : 0;
            int aoi_name_chk_w_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_w_amount()) ? Integer.parseInt(o.getAoi_name_chk_w_amount()) : 0;
            int suspected_wrong_amount = StringUtils.isNotEmpty(o.getSuspected_wrong_amount()) ? Integer.parseInt(o.getSuspected_wrong_amount()) : 0;
            int business_wrong_amount = StringUtils.isNotEmpty(o.getBusiness_wrong_amount()) ? Integer.parseInt(o.getBusiness_wrong_amount()) : 0;
            int wrong_amount = rw_search_w_amount + aoi_name_chk_w_amount + suspected_wrong_amount + business_wrong_amount;

            int xg_track_seq_amount = StringUtils.isNotEmpty(o.getXg_track_seq_amount()) ? Integer.parseInt(o.getXg_track_seq_amount()) : 0;
            int rw_search_c_amount = StringUtils.isNotEmpty(o.getRw_search_c_amount()) ? Integer.parseInt(o.getRw_search_c_amount()) : 0;
            int aoi_name_chk_c_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_c_amount()) ? Integer.parseInt(o.getAoi_name_chk_c_amount()) : 0;
            int special_business_amount = StringUtils.isNotEmpty(o.getSpecial_business_amount()) ? Integer.parseInt(o.getSpecial_business_amount()) : 0;
            int business_correct_amount = StringUtils.isNotEmpty(o.getBusiness_correct_amount()) ? Integer.parseInt(o.getBusiness_correct_amount()) : 0;
            int right_amount = xg_track_seq_amount + rw_search_c_amount + aoi_name_chk_c_amount + special_business_amount + business_correct_amount;

            o.setWrong_amount(wrong_amount + "");
            o.setRight_amount(right_amount + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityWrong_rightRdd cnt:{}", cityWrong_rightRdd.count());
        cityAoiRealAddrCntRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> cityStatRdd = cityWrong_rightRdd.mapToPair(o -> new Tuple2<>(o.getCity(), o))
                .groupByKey()
                .map(tp -> {
                    List<AoiRealAccRateReport> list = Lists.newArrayList(tp._2);
                    AoiRealAccRateReport aoiRealAccRateReport = list.get(0);

                    int totalWrongAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getWrong_amount()) ? Integer.parseInt(o.getWrong_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalRightAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getRight_amount()) ? Integer.parseInt(o.getRight_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalAddrZcAmount = StringUtils.isNotEmpty(aoiRealAccRateReport.getAddress_count_zc()) ? Integer.parseInt(aoiRealAccRateReport.getAddress_count_zc()) : 0;
                    if (totalAddrZcAmount > totalWrongAmount) {
                        totalAddrZcAmount = totalWrongAmount;
                    }

                    double right_rate = Double.valueOf(totalRightAmount + totalAddrZcAmount) / Double.valueOf(totalWrongAmount + totalRightAmount);

                    aoiRealAccRateReport.setTotalWrongAmount(totalWrongAmount + "");
                    aoiRealAccRateReport.setTotalRightAmount(totalRightAmount + "");
                    aoiRealAccRateReport.setTotalAddrZcAmount(totalAddrZcAmount + "");
                    aoiRealAccRateReport.setRight_rate(right_rate + "");

                    aoiRealAccRateReport.setStat_type("CITY");
                    aoiRealAccRateReport.setStat_type_content(aoiRealAccRateReport.getCity());
                    aoiRealAccRateReport.setZonecode("ALL");
                    return aoiRealAccRateReport;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityStatRdd cnt:{}", cityStatRdd.count());
        cityWrong_rightRdd.unpersist();

        logger.error("开始统计:大区维度");
        JavaRDD<AoiRealAccRateReport> regionAoiRealAddrCntRdd = regionRdd.mapToPair(o -> new Tuple2<>(o.getRegion(), o))
                .leftOuterJoin(addrCntRegionRdd.mapToPair(o -> new Tuple2<>(o.getRegion(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    AoiRealAccRateReport o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        OperationPlatformMisJudgment operationPlatformMisJudgment = tp._2._2.get();
                        String address_count_zc = operationPlatformMisJudgment.getAddress_count_zc();
                        o.setAddress_count_zc(address_count_zc);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("regionAoiRealAddrCntRdd cnt:{}", regionAoiRealAddrCntRdd.count());
        regionRdd.unpersist();
        addrCntRegionRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> regionWrong_rightRdd = regionAoiRealAddrCntRdd.map(o -> {
            int rw_search_w_amount = StringUtils.isNotEmpty(o.getRw_search_w_amount()) ? Integer.parseInt(o.getRw_search_w_amount()) : 0;
            int aoi_name_chk_w_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_w_amount()) ? Integer.parseInt(o.getAoi_name_chk_w_amount()) : 0;
            int suspected_wrong_amount = StringUtils.isNotEmpty(o.getSuspected_wrong_amount()) ? Integer.parseInt(o.getSuspected_wrong_amount()) : 0;
            int business_wrong_amount = StringUtils.isNotEmpty(o.getBusiness_wrong_amount()) ? Integer.parseInt(o.getBusiness_wrong_amount()) : 0;
            int wrong_amount = rw_search_w_amount + aoi_name_chk_w_amount + suspected_wrong_amount + business_wrong_amount;

            int xg_track_seq_amount = StringUtils.isNotEmpty(o.getXg_track_seq_amount()) ? Integer.parseInt(o.getXg_track_seq_amount()) : 0;
            int rw_search_c_amount = StringUtils.isNotEmpty(o.getRw_search_c_amount()) ? Integer.parseInt(o.getRw_search_c_amount()) : 0;
            int aoi_name_chk_c_amount = StringUtils.isNotEmpty(o.getAoi_name_chk_c_amount()) ? Integer.parseInt(o.getAoi_name_chk_c_amount()) : 0;
            int special_business_amount = StringUtils.isNotEmpty(o.getSpecial_business_amount()) ? Integer.parseInt(o.getSpecial_business_amount()) : 0;
            int business_correct_amount = StringUtils.isNotEmpty(o.getBusiness_correct_amount()) ? Integer.parseInt(o.getBusiness_correct_amount()) : 0;
            int right_amount = xg_track_seq_amount + rw_search_c_amount + aoi_name_chk_c_amount + special_business_amount + business_correct_amount;

            o.setWrong_amount(wrong_amount + "");
            o.setRight_amount(right_amount + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("regionWrong_rightRdd cnt:{}", regionWrong_rightRdd.count());
        regionAoiRealAddrCntRdd.unpersist();

        JavaRDD<AoiRealAccRateReport> regionStatRdd = regionWrong_rightRdd.mapToPair(o -> new Tuple2<>(o.getRegion(), o))
                .groupByKey()
                .map(tp -> {
                    List<AoiRealAccRateReport> list = Lists.newArrayList(tp._2);
                    AoiRealAccRateReport aoiRealAccRateReport = list.get(0);

                    int totalWrongAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getWrong_amount()) ? Integer.parseInt(o.getWrong_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalRightAmount = list.stream().map(o -> StringUtils.isNotEmpty(o.getRight_amount()) ? Integer.parseInt(o.getRight_amount()) : 0).reduce((o1, o2) -> o1 + o2).get();
                    int totalAddrZcAmount = StringUtils.isNotEmpty(aoiRealAccRateReport.getAddress_count_zc()) ? Integer.parseInt(aoiRealAccRateReport.getAddress_count_zc()) : 0;
                    if (totalAddrZcAmount > totalWrongAmount) {
                        totalAddrZcAmount = totalWrongAmount;
                    }

                    double right_rate = Double.valueOf(totalRightAmount + totalAddrZcAmount) / Double.valueOf(totalWrongAmount + totalRightAmount);

                    aoiRealAccRateReport.setTotalWrongAmount(totalWrongAmount + "");
                    aoiRealAccRateReport.setTotalRightAmount(totalRightAmount + "");
                    aoiRealAccRateReport.setTotalAddrZcAmount(totalAddrZcAmount + "");
                    aoiRealAccRateReport.setRight_rate(right_rate + "");

                    aoiRealAccRateReport.setStat_type("REGION");
                    aoiRealAccRateReport.setStat_type_content(aoiRealAccRateReport.getRegion());
                    aoiRealAccRateReport.setCity("ALL");
                    aoiRealAccRateReport.setCity_code("ALL");
                    return aoiRealAccRateReport;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("regionStatRdd cnt:{}", regionStatRdd.count());
        regionWrong_rightRdd.unpersist();


        JavaRDD<AoiRealAccRateReport> resultRdd = zcStatRdd.union(cityStatRdd).union(regionStatRdd).filter(o -> {
            boolean flag = true;
            int rightAount = StringUtils.isNotEmpty(o.getTotalRightAmount()) ? Integer.parseInt(o.getTotalRightAmount()) : 0;
            int wrongAount = StringUtils.isNotEmpty(o.getTotalWrongAmount()) ? Integer.parseInt(o.getTotalWrongAmount()) : 0;
            if (rightAount + wrongAount <= 2) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        zcStatRdd.unpersist();
        cityStatRdd.unpersist();
        regionStatRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.aoi_real_acc_rate_report_month_stat drop if EXISTS partition(inc_day='%s')", today));
        saveData(spark, resultRdd, today);
        spark.stop();
    }

    public void saveData(SparkSession spark, JavaRDD<AoiRealAccRateReport> inRdd, String date) {

        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getStat_type(), o.getStat_type_content(), o.getRegion(), o.getCity_code(), o.getCity(), o.getZonecode(), o.getTotalRightAmount(), o.getTotalWrongAmount(), o.getTotalAddrZcAmount(), o.getRight_rate()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"stat_type", "stat_type_content", "region", "city_code", "city", "zonecode", "total_right", "total_wrong", "total_address_count", "accuracy"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_real_acc_rate_report_month_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_real_acc_rate_report_month_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public JavaRDD<AoiRealAccRateReport> loadSourceData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("aoi_real_acc_rate_report.sql", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccRateReport.class);
    }

    public JavaRDD<OperationPlatformMisJudgment> loadAddrCntData(SparkSession spark, JavaSparkContext sc, String firstDayOfLastMonth, String today, String lastDayOfLastMonth) {
        String sql = String.format("select city_code,zno_code,address_count_zc,inc_day from dm_gis.aoi_real_acc_rate_report_addr_count_zc where inc_day between '%s' and '%s' and new_data_date between '%s' and '%s'", firstDayOfLastMonth, today, firstDayOfLastMonth, lastDayOfLastMonth);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, OperationPlatformMisJudgment.class);
    }

//    select citycode,region from dm_gis.address_info_map_di

    public JavaRDD<AddressInfoMapDi> loadAddressInfoMap(SparkSession spark, JavaSparkContext sc) {
        String sql = "select citycode,region from dm_gis.address_info_map_di";
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AddressInfoMapDi.class);
    }

    public static void main(String[] args) throws Exception {
//        OperationPlatformMisJudgment o = new OperationPlatformMisJudgment();
//        for (Field f : o.getClass().getDeclaredFields()) {
//            f.setAccessible(true);
//            System.out.println(f.getType().toString());
//            if (StringUtils.equals(f.getType().toString(),"class java.lang.String") && f.get(o) == null) { //若字段为空，给该属性赋为空字符串
//                f.set(o, "");
//            }
//        }
//        System.out.println(JSON.toJSONString(o));

        List<String> dates = DateUtil.getDateList("2021-12-31", "2022-01-06", "yyyy-MM-dd");
        for (String date : dates) {
            System.out.println(date);
        }
    }
}
