package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class GisRssSegCloudLogCollectStd implements Serializable {
    @Column(name = "addresstext")
    private String addresstext;
    @Column(name = "syscode")
    private String syscode;
    @Column(name = "ak")
    private String ak;
    @Column(name = "personname")
    private String personname;
    @Column(name = "phonenumber")
    private String phonenumber;
    @Column(name = "address")
    private String address;
    @Column(name = "resp")
    private String resp;
    @Column(name = "personname_sit")
    private String personname_sit;
    @Column(name = "phonenumber_sit")
    private String phonenumber_sit;
    @Column(name = "address_sit")
    private String address_sit;
    @Column(name = "flag")
    private String flag;
    @Column(name = "inc_day")
    private String inc_day;

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getPersonname_sit() {
        return personname_sit;
    }

    public void setPersonname_sit(String personname_sit) {
        this.personname_sit = personname_sit;
    }

    public String getPhonenumber_sit() {
        return phonenumber_sit;
    }

    public void setPhonenumber_sit(String phonenumber_sit) {
        this.phonenumber_sit = phonenumber_sit;
    }

    public String getAddress_sit() {
        return address_sit;
    }

    public void setAddress_sit(String address_sit) {
        this.address_sit = address_sit;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getAddresstext() {
        return addresstext;
    }

    public void setAddresstext(String addresstext) {
        this.addresstext = addresstext;
    }

    public String getSyscode() {
        return syscode;
    }

    public void setSyscode(String syscode) {
        this.syscode = syscode;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getPersonname() {
        return personname;
    }

    public void setPersonname(String personname) {
        this.personname = personname;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
