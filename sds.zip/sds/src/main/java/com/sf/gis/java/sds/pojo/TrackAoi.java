package com.sf.gis.java.sds.pojo;

import java.io.Serializable;


public class TrackAoi implements Serializable, Comparable<TrackAoi> {
    private String aoiId;
    private String aoiName;
    private String lng;
    private String lat;
    private String tm;

    private String aoistart;
    private String aoiend;
    private String aoiduration;
    private String stay_time_duration;

    private long sum_stay_time;

    public String getStay_time_duration() {
        return stay_time_duration;
    }

    public void setStay_time_duration(String stay_time_duration) {
        this.stay_time_duration = stay_time_duration;
    }

    public long getSum_stay_time() {
        return sum_stay_time;
    }

    public void setSum_stay_time(long sum_stay_time) {
        this.sum_stay_time = sum_stay_time;
    }

    public String getAoistart() {
        return aoistart;
    }

    public void setAoistart(String aoistart) {
        this.aoistart = aoistart;
    }

    public String getAoiend() {
        return aoiend;
    }

    public void setAoiend(String aoiend) {
        this.aoiend = aoiend;
    }

    public String getAoiduration() {
        return aoiduration;
    }

    public void setAoiduration(String aoiduration) {
        this.aoiduration = aoiduration;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    @Override
    public int compareTo(TrackAoi o) {
        long sum_stay_time = this.getSum_stay_time();
        long sum_stay_time1 = o.getSum_stay_time();
        if (sum_stay_time > sum_stay_time1) {
            return 1;
        } else if (sum_stay_time < sum_stay_time1) {
            return -1;
        }
        return 0;
    }


}
