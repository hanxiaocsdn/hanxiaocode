package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 地址详细信息
 * @author 01370539 created on Aug.5 2021
 */
@Table
public class SfpAddrInit implements Serializable {
    @Column(name = "uuid")
    private String uuid;    // ID
    @Column(name = "province")
    private String province;    // 省
    @Column(name = "city")
    private String city;    // 市
    @Column(name = "district")
    private String district;    // 区
    @Column(name = "zc")
    private String zc;    // 网点
    @Column(name = "aoi")
    private String aoi;    // 网点
    @Column(name = "addr")
    private String addr;    // 地址
    @Column(name = "split")
    private String split;    // 切词
    @Column(name = "split_key")
    private String splitKey;    // 通过切词获取的主体
    @Column(name = "split_key_level")
    private String splitKeyLevel;    // 切词主体的级别
    @Column(name = "poi")
    private String poi;    // poi
    @Column(name = "poi_level")
    private String poiLevel;    // poi级别
    @Column(name = "building")
    private String building;    // 楼栋
    @Column(name = "building_level")
    private String buildingLevel;    // 楼栋
    @Column(name = "key_id")
    private String keyId;    // key的MD5值
    @Column(name = "group_geo")
    private String groupGeo;    // 坐标精度（来自地理编码服务）
    @Column(name = "action")
    private String action;    // 收寄行为：收件；寄件
    @Column(name = "action_date")
    private String actionDate;    // 收寄行为：收件；寄件
    @Column(name = "waybill_no")
    private String waybillNo;    // 运单号
    @Column(name = "order_no_wb")
    private String orderNoWb;    // 订单号(来自宽表)
    @Column(name = "sys_order_no")
    private String sysOrderNo;    // 系统订单号
    @Column(name = "order_no_oms")
    private String orderNoOms;    // 订单号(来自omsfrom)
    @Column(name = "under_call")
    private String underCall;    // 下call标志
    @Column(name = "lng_zc")
    private String lngZc;    // 地址的经度（来自地理编码服务）
    @Column(name = "lat_zc")
    private String latZc;    // 地址的纬度（来自地理编码服务）
    @Column(name = "lng_geo")
    private String lngGeo;    // 地址的经度（来自地理编码服务）
    @Column(name = "lat_geo")
    private String latGeo;    // 地址的纬度（来自地理编码服务）
    @Column(name = "precision_geo")
    private String precisionGeo;    // 坐标精度（来自地理编码服务）
    @Column(name = "lng_kh")
    private String lngKh;    // 经度（来自巴枪）
    @Column(name = "lat_kh")
    private String latKh;    // 纬度（来自巴枪）
    @Column(name = "lng_bq")
    private String lngBq;    // 经度（来自巴枪）
    @Column(name = "lat_bq")
    private String latBq;    // 纬度（来自巴枪）
    @Column(name = "precision_bq")
    private String precisionBq;    // 坐标精度（来自地理编码服务）
    @Column(name = "hash_latlng_bq")
    private String hashLatLngBq;    // 坐标hash值（来自巴枪）
    @Column(name = "lng")
    private String lng;    // 坐标聚合中间点经度
    @Column(name = "lat")
    private String lat;    // 坐标聚合中间点纬度
    @Column(name = "inc_day")
    private String incDay;    // 数据所属日期
    @Column(name = "city_code")
    private String cityCode;    // 城市编码

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getSplitKey() {
        return splitKey;
    }

    public void setSplitKey(String splitKey) {
        this.splitKey = splitKey;
    }

    public String getSplitKeyLevel() {
        return splitKeyLevel;
    }

    public void setSplitKeyLevel(String splitKeyLevel) {
        this.splitKeyLevel = splitKeyLevel;
    }

    public String getPoi() {
        return poi;
    }

    public void setPoi(String poi) {
        this.poi = poi;
    }

    public String getPoiLevel() {
        return poiLevel;
    }

    public void setPoiLevel(String poiLevel) {
        this.poiLevel = poiLevel;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getBuildingLevel() {
        return buildingLevel;
    }

    public void setBuildingLevel(String buildingLevel) {
        this.buildingLevel = buildingLevel;
    }

    public String getKeyId() {
        return keyId;
    }

    public void setKeyId(String keyId) {
        this.keyId = keyId;
    }

    public String getGroupGeo() {
        return groupGeo;
    }

    public void setGroupGeo(String groupGeo) {
        this.groupGeo = groupGeo;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getActionDate() {
        return actionDate;
    }

    public void setActionDate(String actionDate) {
        this.actionDate = actionDate;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getOrderNoWb() {
        return orderNoWb;
    }

    public void setOrderNoWb(String orderNoWb) {
        this.orderNoWb = orderNoWb;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getOrderNoOms() {
        return orderNoOms;
    }

    public void setOrderNoOms(String orderNoOms) {
        this.orderNoOms = orderNoOms;
    }

    public String getUnderCall() {
        return underCall;
    }

    public void setUnderCall(String underCall) {
        this.underCall = underCall;
    }

    public String getLngZc() {
        return lngZc;
    }

    public void setLngZc(String lngZc) {
        this.lngZc = lngZc;
    }

    public String getLatZc() {
        return latZc;
    }

    public void setLatZc(String latZc) {
        this.latZc = latZc;
    }

    public String getLngGeo() {
        return lngGeo;
    }

    public void setLngGeo(String lngGeo) {
        this.lngGeo = lngGeo;
    }

    public String getLatGeo() {
        return latGeo;
    }

    public void setLatGeo(String latGeo) {
        this.latGeo = latGeo;
    }

    public String getPrecisionGeo() {
        return precisionGeo;
    }

    public void setPrecisionGeo(String precisionGeo) {
        this.precisionGeo = precisionGeo;
    }

    public String getLngKh() {
        return lngKh;
    }

    public void setLngKh(String lngKh) {
        this.lngKh = lngKh;
    }

    public String getLatKh() {
        return latKh;
    }

    public void setLatKh(String latKh) {
        this.latKh = latKh;
    }

    public String getLngBq() {
        return lngBq;
    }

    public void setLngBq(String lngBq) {
        this.lngBq = lngBq;
    }

    public String getLatBq() {
        return latBq;
    }

    public void setLatBq(String latBq) {
        this.latBq = latBq;
    }

    public String getPrecisionBq() {
        return precisionBq;
    }

    public void setPrecisionBq(String precisionBq) {
        this.precisionBq = precisionBq;
    }

    public String getHashLatLngBq() {
        return hashLatLngBq;
    }

    public void setHashLatLngBq(String hashLatLngBq) {
        this.hashLatLngBq = hashLatLngBq;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @Override
    public String toString() {
        return "SfpAddrInit{" +
                "uuid='" + uuid + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", district='" + district + '\'' +
                ", zc='" + zc + '\'' +
                ", aoi='" + aoi + '\'' +
                ", addr='" + addr + '\'' +
                ", split='" + split + '\'' +
                ", splitKey='" + splitKey + '\'' +
                ", splitKeyLevel='" + splitKeyLevel + '\'' +
                ", poi='" + poi + '\'' +
                ", poiLevel='" + poiLevel + '\'' +
                ", building='" + building + '\'' +
                ", buildingLevel='" + buildingLevel + '\'' +
                ", keyId='" + keyId + '\'' +
                ", groupGeo='" + groupGeo + '\'' +
                ", action='" + action + '\'' +
                ", actionDate='" + actionDate + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", orderNoWb='" + orderNoWb + '\'' +
                ", sysOrderNo='" + sysOrderNo + '\'' +
                ", orderNoOms='" + orderNoOms + '\'' +
                ", underCall='" + underCall + '\'' +
                ", lngZc='" + lngZc + '\'' +
                ", latZc='" + latZc + '\'' +
                ", lngGeo='" + lngGeo + '\'' +
                ", latGeo='" + latGeo + '\'' +
                ", precisionGeo='" + precisionGeo + '\'' +
                ", lngKh='" + lngKh + '\'' +
                ", latKh='" + latKh + '\'' +
                ", lngBq='" + lngBq + '\'' +
                ", latBq='" + latBq + '\'' +
                ", precisionBq='" + precisionBq + '\'' +
                ", hashLatLngBq='" + hashLatLngBq + '\'' +
                ", lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", incDay='" + incDay + '\'' +
                ", cityCode='" + cityCode + '\'' +
                '}';
    }
}
