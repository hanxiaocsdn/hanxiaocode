package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.DbSbAutoClearController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:1147（德邦错分审补自动清洗工艺）
 * 业务方：01427169（邓蔼娟）
 * 研发：01399581（匡仁衡）
 */
public class AppDbSbAutoClear {
    private static Logger logger = LoggerFactory.getLogger(AppDbSbAutoClear.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String period = args[2];
        logger.error("startDate:{},endDate:{},period:{}", startDate, endDate, period);
        logger.error("run start");
        new DbSbAutoClearController().start(startDate, endDate, period);
        logger.error("run end");
    }
}
