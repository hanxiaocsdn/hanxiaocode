package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class NlocServicePopFeedbackData implements Serializable {
    @Column(name = "sf_user_id")
    private String sf_user_id;
    @Column(name = "opera_time")
    private String opera_time;
    @Column(name = "zone_code")
    private String zone_code;
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "properties_type")
    private String properties_type;
    @Column(name = "properties_content")
    private String properties_content;
    @Column(name = "city")
    private String city;
    @Column(name = "signin_time")
    private String signin_time;
    @Column(name = "delivery_lgt")
    private String delivery_lgt;
    @Column(name = "delivery_lat")
    private String delivery_lat;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "address")
    private String address;
    @Column(name = "match_type")
    private String match_type;
    @Column(name = "current_tm")
    private String current_tm;
    @Column(name = "wifilist")
    private String wifilist;
    @Column(name = "wifimatchaddresslist")
    private String wifimatchaddresslist;
    @Column(name = "wifimatchtype")
    private String wifimatchtype;
    @Column(name = "wifi_aoi")
    private String wifi_aoi;
    @Column(name = "gd_res")
    private String gd_res;
    @Column(name = "coords_gd")
    private String coords_gd;
    @Column(name = "gd_xy_res")
    private String gd_xy_res;
    @Column(name = "gdaoi")
    private String gdaoi;
    @Column(name = "delivery_xy_res")
    private String delivery_xy_res;
    @Column(name = "80aois")
    private String aois80;
    @Column(name = "tag")
    private String tag;
    @Column(name = "inc_day")
    private String inc_day;

    private List<String> list;

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getDelivery_xy_res() {
        return delivery_xy_res;
    }

    public void setDelivery_xy_res(String delivery_xy_res) {
        this.delivery_xy_res = delivery_xy_res;
    }

    public String getGd_xy_res() {
        return gd_xy_res;
    }

    public void setGd_xy_res(String gd_xy_res) {
        this.gd_xy_res = gd_xy_res;
    }

    public String getAois80() {
        return aois80;
    }

    public void setAois80(String aois80) {
        this.aois80 = aois80;
    }

    public String getGdaoi() {
        return gdaoi;
    }

    public void setGdaoi(String gdaoi) {
        this.gdaoi = gdaoi;
    }

    public String getCoords_gd() {
        return coords_gd;
    }

    public void setCoords_gd(String coords_gd) {
        this.coords_gd = coords_gd;
    }

    public String getGd_res() {
        return gd_res;
    }

    public void setGd_res(String gd_res) {
        this.gd_res = gd_res;
    }

    public String getWifi_aoi() {
        return wifi_aoi;
    }

    public void setWifi_aoi(String wifi_aoi) {
        this.wifi_aoi = wifi_aoi;
    }

    public String getSf_user_id() {
        return sf_user_id;
    }

    public void setSf_user_id(String sf_user_id) {
        this.sf_user_id = sf_user_id;
    }

    public String getOpera_time() {
        return opera_time;
    }

    public void setOpera_time(String opera_time) {
        this.opera_time = opera_time;
    }

    public String getZone_code() {
        return zone_code;
    }

    public void setZone_code(String zone_code) {
        this.zone_code = zone_code;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getProperties_type() {
        return properties_type;
    }

    public void setProperties_type(String properties_type) {
        this.properties_type = properties_type;
    }

    public String getProperties_content() {
        return properties_content;
    }

    public void setProperties_content(String properties_content) {
        this.properties_content = properties_content;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getSignin_time() {
        return signin_time;
    }

    public void setSignin_time(String signin_time) {
        this.signin_time = signin_time;
    }

    public String getDelivery_lgt() {
        return delivery_lgt;
    }

    public void setDelivery_lgt(String delivery_lgt) {
        this.delivery_lgt = delivery_lgt;
    }

    public String getDelivery_lat() {
        return delivery_lat;
    }

    public void setDelivery_lat(String delivery_lat) {
        this.delivery_lat = delivery_lat;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMatch_type() {
        return match_type;
    }

    public void setMatch_type(String match_type) {
        this.match_type = match_type;
    }

    public String getCurrent_tm() {
        return current_tm;
    }

    public void setCurrent_tm(String current_tm) {
        this.current_tm = current_tm;
    }

    public String getWifilist() {
        return wifilist;
    }

    public void setWifilist(String wifilist) {
        this.wifilist = wifilist;
    }

    public String getWifimatchaddresslist() {
        return wifimatchaddresslist;
    }

    public void setWifimatchaddresslist(String wifimatchaddresslist) {
        this.wifimatchaddresslist = wifimatchaddresslist;
    }

    public String getWifimatchtype() {
        return wifimatchtype;
    }

    public void setWifimatchtype(String wifimatchtype) {
        this.wifimatchtype = wifimatchtype;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
