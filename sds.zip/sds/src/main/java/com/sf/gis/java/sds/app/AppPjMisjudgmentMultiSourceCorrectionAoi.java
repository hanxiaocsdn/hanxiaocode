package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.PjMisjudgmentMultiSourceCorrectionAoi;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * 任务：964444(【壹竿-SD】派件判错数据多源修正AOI)
 * 业务：01434066（宋雨莲）
 * 研发：01399581（匡仁衡）
 */
public class AppPjMisjudgmentMultiSourceCorrectionAoi {
    private static final Logger logger = Logger.getLogger(AppPjMisjudgmentMultiSourceCorrectionAoi.class);
    private static final String atp = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=&company=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh";
    private static final String geo = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=gd2&address=%s&city=%s";
    private static final String byxy = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=3eb300d2e06947f7945cd02530a32fd2&x=%s&y=%s&opt=aoi&geom=0";
    private static final String gd = "http://gis-gaode.int.sfcloud.local:1080/optimalMatching?address=%s";

    private static final String updateAddrAoiId = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiId";
    private static final String rgsbAdd = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd";
    private static final String updateAddrAoiCheck = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck";
    private static final String updateAddrMd5AoiCheck = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck";

    private static final String taskId = "964444";
    private static final String taskName = "【壹竿-SD】派件判错数据多源修正AOI";
    private static final String account = "01399581";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppPjMisjudgmentMultiSourceCorrectionAoi");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取源数据");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> rdd = getData(spark, sc, date);
        logger.error("过滤数据");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterAoiAndAddrRdd = filterData(rdd);
        logger.error("重跑at派获取生产结果");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> atpRdd = atp(filterAoiAndAddrRdd, spark);
        logger.error("近三个月历史数据过滤");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterHisRdd = filterHis(spark, sc, atpRdd, date);
        logger.error("针对at_aoisrc不同来源,走各自的处理流程");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> lastRdd = processAoiSrc(filterHisRdd, sc, spark, date);
        logger.error("结果数据存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_aoi_real_acctury_rate_judge_bottomcorrected_misjudgment_correction_aoi_di", PjMisjudgmentMultiSourceCorrectionAoi.class, lastRdd, "inc_day");
        lastRdd.unpersist();

        sc.stop();
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> processAoiSrc(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterHisRdd, JavaSparkContext sc, SparkSession spark, String date) {
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normAndChknRdd = filterHisRdd.filter(o -> Arrays.asList("norm,chkn".split(",")).contains(o.getAt_aoisrc())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> otherRdd = filterHisRdd.filter(o -> !Arrays.asList("norm,chkn".split(",")).contains(o.getAt_aoisrc())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normAndChknRdd cnt:" + normAndChknRdd.count());
        logger.error("otherRdd cnt:" + otherRdd.count());
        filterHisRdd.unpersist();

        logger.error("norm,chkn数据处理");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normAndChknLastRdd = processNormAndChkn(normAndChknRdd, sc, spark);

        logger.error("other数据处理");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> otherLastRdd = processOther(otherRdd, spark, sc, date);

        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> unionRdd = normAndChknLastRdd.union(otherLastRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unionRdd cnt:" + unionRdd.count());
        normAndChknLastRdd.unpersist();
        otherLastRdd.unpersist();
        return unionRdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> processOther(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> otherRdd, SparkSession spark, JavaSparkContext sc, String date) {
        logger.error("增加其他数据源融入进来");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterAddRdd = getAddData(spark, sc, date);

        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> uniqueOtherRdd = otherRdd.filter(o -> !StringUtils.equals(o.getAoi80(), o.getAt_aoiid()) && StringUtils.equals(o.getZnocode80(), o.getAt_deptcode()))
                .union(filterAddRdd)
                .mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueOtherRdd cnt:" + uniqueOtherRdd.count());
        otherRdd.unpersist();
        filterAddRdd.unpersist();

        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", uniqueOtherRdd.count(), 5);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> otherLastRdd = getGdAoi(uniqueOtherRdd, "other").map(o -> {
            String city_code = o.getCity_code();
            String at_deptcode = o.getAt_deptcode();
            String req_addresseeaddr = o.getReq_addresseeaddr();
            String gdaoi = o.getGdaoi();
            String operSource = "wrong_80_gdps";
            String operUserName = "01434066";

            JSONObject param1 = new JSONObject();
            param1.put("ak", "7577390e76cc40b6ad6542640edd9d84");
            param1.put("operSource", operSource);
            param1.put("operUserName", operUserName);
            JSONObject addressSave = new JSONObject();
            addressSave.put("cityCode", city_code);
            addressSave.put("address", req_addresseeaddr);
            addressSave.put("znoCode", at_deptcode);
            addressSave.put("aoiId", gdaoi);
            addressSave.put("src", "1");
            param1.put("addressSave", addressSave);
            String rgsbAddRs = HttpInvokeUtil.sendPost(rgsbAdd, param1.toJSONString());
            boolean update_result = false;
            try {
                update_result = JSON.parseObject(rgsbAddRs).getBoolean("success");
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (update_result) {
                o.setUpdate_result(update_result + "");

                String addressMd5 = JSON.parseObject(rgsbAddRs).getJSONObject("data").getString("addressMd5");
                JSONObject param2 = new JSONObject();
                String aoiCheckTag = "8";
                param2.put("cityCode", city_code);
                param2.put("aoiCheckTag", aoiCheckTag);
                JSONArray list = new JSONArray();
                list.add(addressMd5);
                param2.put("addressMd5s", list);
                String aoiCheckRs = HttpInvokeUtil.sendPost(updateAddrMd5AoiCheck, param2.toJSONString());
                boolean updatetag_result = false;
                try {
                    updatetag_result = JSON.parseObject(aoiCheckRs).getBoolean("success");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (updatetag_result) {
                    o.setUpdatetag_result(updatetag_result + "");
                } else {
                    o.setUpdatetag_result(aoiCheckRs);
                }
            } else {
                o.setUpdate_result(rgsbAddRs);
            }
            return o;
        });
        BdpTaskRecordUtil.endNetworkInterface(account, id5);
        return otherLastRdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> processNormAndChkn(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normAndChknRdd, JavaSparkContext sc, SparkSession spark) {
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");
        Broadcast<Properties> cityDbProBc = sc.broadcast(cityDbPro);
        logger.error("at_aoisrc 为norm,chkn处理逻辑");
        logger.error("根据at_groupid,由从库中获取std_address,adcode记做cms_adcode,aoiId记做cms_aoi,znoCode记做cms_znocode");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normAndChknCmsRdd = normAndChknRdd.filter(o -> StringUtils.isNotEmpty(o.getAt_groupid()))
                .mapToPair(o -> new Tuple2<>(o.getAt_groupid(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2)
                .mapPartitions(itr -> {
                    Properties cityMap = cityDbProBc.value();
                    Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
                    Statement stmt = conn.createStatement();
                    List<PjMisjudgmentMultiSourceCorrectionAoi> list = new ArrayList<>();
                    try {
                        while (itr.hasNext()) {
                            PjMisjudgmentMultiSourceCorrectionAoi o = itr.next();
                            String at_groupid = o.getAt_groupid();
                            String city_code = o.getCity_code();
                            String at_aoisrc = o.getAt_aoisrc();
                            if (StringUtils.isNotEmpty(at_groupid) && StringUtils.isNotEmpty(city_code)) {
                                String sql = "";
                                if ("norm".equals(at_aoisrc)) {
                                    sql = String.format("select address,adcode,aoi_id,zno_code from cms_address_%s where city_code='%s' and address_id = '%s' and del_flag = 0", cityMap.getProperty(city_code), city_code, at_groupid);
                                } else {
                                    sql = String.format("select address,adcode,aoi_id,zno_code from cms_address_%s where city_code='%s' and address_md5 = '%s' and del_flag = 0", cityMap.getProperty(city_code), city_code, at_groupid);
                                }
                                logger.info("sql:" + sql);
                                if (StringUtils.isNotEmpty(sql)) {
                                    ResultSet rs = stmt.executeQuery(sql);
                                    while (rs.next()) {
                                        String address = rs.getString("address");
                                        String adcode = rs.getString("adcode");
                                        String aoi_id = rs.getString("aoi_id");
                                        String zno_code = rs.getString("zno_code");

                                        o.setStd_address(StringNumUtils.fixnulltoStr(address));
                                        o.setCms_adcode(StringNumUtils.fixnulltoStr(adcode));
                                        o.setCms_aoi(StringNumUtils.fixnulltoStr(aoi_id));
                                        o.setCms_znocode(StringNumUtils.fixnulltoStr(zno_code));
                                    }
                                }
                            }
                            list.add(o);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    } finally {
                        stmt.close();
                        conn.close();
                    }
                    return list.iterator();
                })
                .filter(o -> addr_filter(o.getStd_address()))
                .filter(o -> !StringUtils.equals(o.getAoi80(), o.getCms_aoi()) && StringUtils.equals(o.getZnocode80(), o.getCms_znocode()))
                .filter(o -> !Arrays.asList("4,5,6,7,8".split(",")).contains(o.getCms_adcode()))
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normAndChknCmsRdd cnt:" + normAndChknCmsRdd.count());
        normAndChknRdd.unpersist();

        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normRdd = normAndChknCmsRdd.filter(o -> "norm".equals(o.getAt_aoisrc())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> chknRdd = normAndChknCmsRdd.filter(o -> "chkn".equals(o.getAt_aoisrc())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:" + normRdd.count());
        logger.error("chknRdd cnt:" + chknRdd.count());
        normAndChknCmsRdd.unpersist();

        logger.error("norm数据处理");
        logger.error("调geo获取aoi");
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", geo, "87106f6380af4df0845a693eee58843c", normRdd.count(), 5);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", byxy, "3eb300d2e06947f7945cd02530a32fd2", normRdd.count(), 5);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> geoRdd = normRdd.mapToPair(o -> new Tuple2<>(o.getStd_address() + "_" + o.getCity_code(), o)).groupByKey().flatMap(tp -> {
            List<PjMisjudgmentMultiSourceCorrectionAoi> list = Lists.newArrayList(tp._2);
            PjMisjudgmentMultiSourceCorrectionAoi o = list.get(0);
            String std_address = o.getStd_address();
            String city_code = o.getCity_code();
            String xcoord = "";
            String ycoord = "";
            String geo_aoiid = "";
            if (StringUtils.isNotEmpty(std_address)) {
                String req = String.format(geo, URLEncoder.encode(std_address, "UTF-8"), city_code);
                String content = HttpInvokeUtil.sendGet(req);
                try {
                    xcoord = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
                    ycoord = JSON.parseObject(content).getJSONObject("result").getString("ycoord");

                } catch (Exception e) {
//                        e.printStackTrace();
                }
                if (StringUtils.isNotEmpty(xcoord) && StringUtils.isNotEmpty(ycoord)) {
                    String aoi_req = String.format(byxy, xcoord, ycoord);
                    String xy_content = HttpInvokeUtil.sendGet(aoi_req);
                    try {
                        geo_aoiid = JSON.parseObject(xy_content).getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id");
                        logger.error("geo_aoiid:" + geo_aoiid);
                    } catch (Exception e) {
//                            e.printStackTrace();
                    }
                }
            }
            String finalXcoord = xcoord;
            String finalYcoord = ycoord;
            String finalGeo_aoiid = geo_aoiid;
            return list.stream().peek(t -> {
                t.setXcoord(finalXcoord);
                t.setYcoord(finalYcoord);
                t.setGeo_aoiid(finalGeo_aoiid);
            }).iterator();
        }).filter(o -> StringUtils.isNotEmpty(o.getGeo_aoiid()) && StringUtils.equals(o.getGeo_aoiid(), o.getAoi80())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("geoRdd cnt:" + geoRdd.count());
        normRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        logger.error("调高德获取aoi");
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", geoRdd.count(), 5);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> gdRdd = getGdAoi(geoRdd, "norm_chkn");
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        String lastest_date = spark.sql("show partitions dm_gis.gis_pai_addr_freq_stat_freq").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("lastest_date:" + lastest_date);
        String sql = String.format("select address_id,freq from dm_gis.gis_pai_addr_freq_stat_freq where inc_day = '%s'", lastest_date);
        JavaPairRDD<String, String> address_id_freqRdd = spark.sql(sql).toJavaRDD().mapToPair(row -> new Tuple2<>(row.getString(0), row.getString(1))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("address_id_freqRdd cnt:" + address_id_freqRdd.count());

        String cms_sch_aoi_sql = "select aoi_id,fa_type from dm_gis.cms_aoi_sch";
        JavaPairRDD<String, String> aoiFaTypeRdd = spark.sql(cms_sch_aoi_sql).toJavaRDD().mapToPair(row -> new Tuple2<>(row.getString(0), row.getString(1))).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiFaTypeRdd cnt:" + aoiFaTypeRdd.count());


        logger.error("获取freq和cms_aoi对应的fa_type");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normLastRdd = gdRdd.mapToPair(o -> new Tuple2<>(o.getAt_groupid(), o)).leftOuterJoin(address_id_freqRdd).map(tp -> {
            PjMisjudgmentMultiSourceCorrectionAoi o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setFreq(tp._2._2.get());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getCms_aoi(), o)).leftOuterJoin(aoiFaTypeRdd).map(tp -> {
            PjMisjudgmentMultiSourceCorrectionAoi o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setCms_fa_type(tp._2._2.get());
            }
            return o;
        })
                .filter(o -> !Arrays.asList("120301,120302,120305".split(",")).contains(o.getCms_fa_type()) || (Arrays.asList("120301,120302,120305".split(",")).contains(o.getCms_fa_type()) && Integer.parseInt(StringUtils.isNotEmpty(o.getFreq()) ? o.getFreq() : "0") < 300))
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normLastRdd cnt:" + normLastRdd.count());
        gdRdd.unpersist();
        address_id_freqRdd.unpersist();
        aoiFaTypeRdd.unpersist();

        logger.error("chkn数据处理");
        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", chknRdd.count(), 5);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> chknLastRdd = getGdAoi(chknRdd, "norm_chkn");
        BdpTaskRecordUtil.endNetworkInterface(account, id4);

        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> normAndChknLastRdd = normLastRdd.union(chknLastRdd).map(o -> {
            String at_aoisrc = o.getAt_aoisrc();
            String city_code = o.getCity_code();
            String at_groupid = o.getAt_groupid();
            String gdaoi = o.getGdaoi();
            String operSource = "wrong_80_gdps";
            String operUserName = "01434066";
            String aoiSource = "S99";
            JSONObject param1 = new JSONObject();
            param1.put("cityCode", city_code);
            param1.put("aoiId", gdaoi);
            param1.put("operSource", operSource);
            param1.put("operUserName", operUserName);
            param1.put("aoiSource", aoiSource);
            param1.put("norm".equals(at_aoisrc) ? "addressId" : "addressMd5", at_groupid);
            String updateAddrAoiIdRs = HttpInvokeUtil.sendPost(updateAddrAoiId, param1.toJSONString());
            boolean update_result = false;
            try {
                update_result = JSON.parseObject(updateAddrAoiIdRs).getBoolean("success");
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (update_result) {
                //如果调用更新地址aoi接口返回为true,再调用更新标签接口
                o.setUpdate_result(update_result + "");
                JSONObject param2 = new JSONObject();
                String aoiCheckTag = "8";
                param2.put("cityCode", city_code);
                param2.put("aoiCheckTag", aoiCheckTag);
                JSONArray list = new JSONArray();
                list.add(at_groupid);
                param2.put("norm".equals(at_aoisrc) ? "addressIds" : "addressMd5s", list);
                String url = "norm".equals(at_aoisrc) ? updateAddrAoiCheck : updateAddrMd5AoiCheck;
                String aoiCheckRs = HttpInvokeUtil.sendPost(url, param2.toJSONString());
                boolean updatetag_result = false;
                try {
                    updatetag_result = JSON.parseObject(aoiCheckRs).getBoolean("success");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (updatetag_result) {
                    o.setUpdatetag_result(updatetag_result + "");
                } else {
                    o.setUpdatetag_result(aoiCheckRs);
                }
            } else {
                o.setUpdate_result(updateAddrAoiIdRs);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normAndChknLastRdd cnt:" + normAndChknLastRdd.count());
        normLastRdd.unpersist();
        chknLastRdd.unpersist();
        return normAndChknLastRdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> getGdAoi(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> rdd, String tag) {
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> gdRdd = rdd.mapToPair(o -> new Tuple2<>("norm_chkn".equals(tag) ? o.getStd_address() : o.getReq_addresseeaddr(), o)).groupByKey().flatMap(tp -> {
            List<PjMisjudgmentMultiSourceCorrectionAoi> list = Lists.newArrayList(tp._2);
            PjMisjudgmentMultiSourceCorrectionAoi o = list.get(0);
            String address = "norm_chkn".equals(tag) ? o.getStd_address() : o.getReq_addresseeaddr();
            String gd_aoi = "";
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(gd, URLEncoder.encode(address, "UTF-8"));
                String content = HttpInvokeUtil.sendGet(req);
                try {
                    gd_aoi = JSON.parseObject(content).getJSONObject("message").getJSONArray("result").getJSONObject(0).getString("aoiid");
                } catch (Exception e) {
//                        e.printStackTrace();
                }
            }
            String finalGd_aoi = gd_aoi;
            return list.stream().peek(t -> t.setGdaoi(finalGd_aoi)).iterator();
        }).filter(o -> StringUtils.isNotEmpty(o.getGdaoi()) && StringUtils.equals(o.getGdaoi(), o.getAoi80())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:" + gdRdd.count());
        rdd.unpersist();
        return gdRdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterHis(SparkSession spark, JavaSparkContext sc, JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> atpRdd, String date) {
        String sql = String.format("select req_addresseeaddr,at_groupid,at_aoisrc from dm_gis.dwd_aoi_real_acctury_rate_judge_bottomcorrected_misjudgment_correction_aoi_di where inc_day between '%s' and '%s' and update_result = 'true'", DateUtil.getDaysBefore(date, 90), date);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> hisRdd = DataUtil.loadData(spark, sc, sql, PjMisjudgmentMultiSourceCorrectionAoi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("hisRdd cnt:" + hisRdd.count());

        logger.error("at_aoisrc not in(norm,chkn)的用req_addresseeaddr关联,at_aoisrc in(norm,chkn）的用at_groupid关联,关联上的就结束");
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterHisRdd = atpRdd.mapToPair(o -> new Tuple2<>(Arrays.asList("norm,chkn".split(",")).contains(o.getAt_aoisrc()) ? o.getAt_groupid() : o.getReq_addresseeaddr(), o))
                .leftOuterJoin(hisRdd.mapToPair(o -> new Tuple2<>(Arrays.asList("norm,chkn".split(",")).contains(o.getAt_aoisrc()) ? o.getAt_groupid() : o.getReq_addresseeaddr(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> tp._2._2 == null || !tp._2._2.isPresent())
                .map(tp -> tp._2._1)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterHisRdd cnt:" + filterHisRdd.count());
        atpRdd.unpersist();
        hisRdd.unpersist();
        return filterHisRdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> atp(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterAoiAndAddrRdd, SparkSession spark) {
        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atp, "3eb300d2e06947f7945cd02530a32fd2", filterAoiAndAddrRdd.count(), 5);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> atpRdd = filterAoiAndAddrRdd.map(o -> {
            String req_addresseeaddr = o.getReq_addresseeaddr();
            String city_code = o.getCity_code();
            String req_comp_name = o.getReq_comp_name();
            if (StringUtils.isNotEmpty(req_addresseeaddr)) {
                String req = String.format(atp, URLEncoder.encode(req_addresseeaddr, "UTF-8"), city_code, URLEncoder.encode(StringUtils.isNotEmpty(req_comp_name) ? req_comp_name : "", "UTF-8"));
                String content = HttpInvokeUtil.sendGet(req);
                setProp(o, content);
            }
            return o;
        })
                .filter(o -> StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), o.getAt_aoiid()))
                .filter(o -> !Arrays.asList("normhp,normcompany".split(",")).contains(o.getAt_aoisrc()))
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atpRdd cnt:" + atpRdd.count());
        filterAoiAndAddrRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);
        return atpRdd;
    }

    public static void setProp(PjMisjudgmentMultiSourceCorrectionAoi o, String content) {
        String aoiid = "";
        String aoicode = "";
        String atAoiSrc = "";
        String dept = "";
        String groupid = "";
        try {
            JSONObject jsonObject = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0);
            aoiid = jsonObject.getString("aoiid");
            aoicode = jsonObject.getString("aoicode");
            atAoiSrc = jsonObject.getString("atAoiSrc");
            dept = jsonObject.getString("dept");
            groupid = jsonObject.getString("groupid");
        } catch (Exception e) {
//            e.printStackTrace();
        }

        String chknId = "";
        try {
            chknId = JSON.parseObject(content).getJSONObject("result").getJSONObject("id_list").getString("chknId");
        } catch (Exception e) {
//                e.printStackTrace();
        }

        o.setAt_aoiid(aoiid);
        o.setAt_aoicode(aoicode);
        o.setAt_aoisrc(atAoiSrc);
        o.setAt_deptcode(dept);

        if ("chkn".equals(atAoiSrc)) {
            o.setAt_groupid(chknId);
        } else if ("norm".equals(atAoiSrc)) {
            o.setAt_groupid(groupid);
        }
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterData(JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> rdd) {
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterAoiAndAddrRdd = rdd.filter(o -> StringUtils.isNotEmpty(o.getAoi80())).filter(o -> addr_filter(o.getReq_addresseeaddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterAoiAndAddrRdd cnt:" + filterAoiAndAddrRdd.count());
        rdd.unpersist();
        return filterAoiAndAddrRdd;
    }

    public static boolean addr_filter(String addr) {
        if (StringUtils.isNotEmpty(addr)) {
            String[] split = "工业园,工业区,工业园区,工业城,街,段,驻地,经济开发区,产业园,产业园区,商贸城,直发基地,基地".split(",");
            for (String word : split) {
                if (addr.endsWith(word)) {
                    return false;
                }
            }
        }
        return true;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> getData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select" +
                "  a.*," +
                "  b.aoi80 aoi80," +
                "  b.znocode80 znocode80," +
                "  b.fa_type80 fa_type80 " +
                "from" +
                "  (" +
                "    SELECT" +
                "      waybillno," +
                "      city_code," +
                "      org_code," +
                "      delivery_lgt," +
                "      delivery_lat," +
                "      inc_day_gd," +
                "      req_waybillno," +
                "      req_destcitycode," +
                "      req_addresseeaddr," +
                "      req_comp_name," +
                "      finalzc," +
                "      finalaoicode," +
                "      finalaoiid," +
                "      req_time," +
                "      gis_to_sys_groupid," +
                "      gisaoisrc," +
                "      tag1," +
                "      tag2," +
                "      80_aoi_code," +
                "      80_aoi_name," +
                "      inc_day " +
                "    FROM" +
                "      dm_gis.dm_aoi_real_acctury_rate_judge_bottomcorrected_2024_di" +
                "    where" +
                "      inc_day = '%s'" +
                "      and length(city_code) < 50" +
                "      and (" +
                "        finalaoicode is not null" +
                "        and finalaoicode <> ''" +
                "      )" +
                "      and (" +
                "        80_aoi_code is not null" +
                "        and 80_aoi_code <> ''" +
                "      )" +
                "      and city_code not in ('852', '853', '886')" +
                "      and tag1 in ('wrong', 'no')" +
                "  ) as a" +
                "  left join (" +
                "    select" +
                "      aoi_id as aoi80," +
                "      zno_code as znocode80," +
                "      aoi_code as 80code," +
                "      fa_type as fa_type80" +
                "    from" +
                "      dm_gis.cms_aoi_sch" +
                "  ) as b on a.80_aoi_code = b.80code" +
                "  left join (" +
                "    select" +
                "      req_addresseeaddr," +
                "      updateaoiid_result" +
                "    from" +
                "      dm_gis.aoi_accuracy_address_clean_pai" +
                "    where" +
                "      inc_day = '%s'" +
                "      and updateaoiid_result = 'True'" +
                "  ) as c on a.req_addresseeaddr = c.req_addresseeaddr" +
                "  where c.updateaoiid_result is null or c.updateaoiid_result = ''", date, date);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> rdd = DataUtil.loadData(spark, sc, sql, PjMisjudgmentMultiSourceCorrectionAoi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        return rdd;
    }

    public static JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> getAddData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select " +
                "  a.*, " +
                "  b.aoi80 aoi80, " +
                "  b.znocode80 znocode80 " +
                "from " +
                "  ( " +
                "    SELECT " +
                "      waybillno, " +
                "      city_code, " +
                "      org_code, " +
                "      delivery_lgt, " +
                "      delivery_lat, " +
                "      inc_day_gd, " +
                "      req_addresseeaddr, " +
                "      req_comp_name, " +
                "      finalzc, " +
                "      finalaoicode, " +
                "      finalaoiid, " +
                "      req_time, " +
                "      gis_to_sys_groupid, " +
                "      gisaoisrc, " +
                "      tag1, " +
                "      tag2, " +
                "      80_aoi_code, " +
                "      80_aoi_name, " +
                "      inc_day " +
                "    FROM " +
                "      dm_gis.dm_pai_norm_match_result_di " +
                "    where " +
                "      inc_day = '%s' " +
                "      and fin_tag = 'false' " +
                "      and tag1 = 'no' " +
                "      and gisaoisrc not in('normhp', 'normcompany') " +
                "  ) as a " +
                "  left join ( " +
                "    select " +
                "      aoi_id as aoi80, " +
                "      zno_code as znocode80, " +
                "      aoi_code as 80code " +
                "    from " +
                "      dm_gis.cms_aoi_sch " +
                "  ) as b on a.80_aoi_code = b.80code", date);
        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> addRdd = DataUtil.loadData(spark, sc, sql, PjMisjudgmentMultiSourceCorrectionAoi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addRdd cnt:" + addRdd.count());

        JavaRDD<PjMisjudgmentMultiSourceCorrectionAoi> filterAddRdd = addRdd.filter(o -> !StringUtils.equals(o.getAoi80(), o.getFinalaoiid()) && StringUtils.equals(o.getZnocode80(), o.getFinalzc()))
                .filter(o -> addr_filter(o.getReq_addresseeaddr()))
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterAddRdd cnt:" + filterAddRdd.count());
        addRdd.unpersist();
        return filterAddRdd;
    }


}


