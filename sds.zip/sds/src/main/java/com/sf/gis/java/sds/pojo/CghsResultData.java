package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CghsResultData implements Serializable {
    @Column(name = "region")
    private String region;
    @Column(name = "city")
    private String city;
    @Column(name = "check_date_day")
    private String check_date_day;
    @Column(name = "check_date_week")
    private String check_date_week;
    @Column(name = "check_date_month")
    private String check_date_month;
    @Column(name = "check_date_quarter")
    private String check_date_quarter;
    @Column(name = "check_date_year")
    private String check_date_year;
    @Column(name = "id")
    private long id;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "sch_code")
    private String sch_code;
    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "sys_code")
    private String sys_code;
    @Column(name = "address")
    private String address;
    @Column(name = "address_md5")
    private String address_md5;
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "create_date")
    private String create_date;
    @Column(name = "state")
    private int state;
    @Column(name = "gid")
    private String gid;
    @Column(name = "check_x")
    private double check_x;
    @Column(name = "check_y")
    private double check_y;
    @Column(name = "check_dept_code")
    private String check_dept_code;
    @Column(name = "check_sch_code")
    private String check_sch_code;
    @Column(name = "check_aoi_code")
    private String check_aoi_code;
    @Column(name = "check_aoi_name")
    private String check_aoi_name;
    @Column(name = "check_aoi_id")
    private String check_aoi_id;
    @Column(name = "check_data_type")
    private String check_data_type;
    @Column(name = "check_date")
    private String check_date;
    @Column(name = "check_by")
    private String check_by;
    @Column(name = "del_flag")
    private int del_flag;
    @Column(name = "del_date")
    private String del_date;
    @Column(name = "dept_type")
    private String dept_type;
    @Column(name = "is_encrypt")
    private int is_encrypt;
    @Column(name = "province")
    private String province;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "city_origin")
    private String city_origin;
    @Column(name = "county")
    private String county;
    @Column(name = "source")
    private String source;
    @Column(name = "cms_check_state")
    private int cms_check_state;
    @Column(name = "done_state")
    private int done_state;
    @Column(name = "data_time")
    private String data_time;
    @Column(name = "emp_id")
    private String emp_id;
    @Column(name = "gis_sch_code")
    private String gis_sch_code;
    @Column(name = "gis_aoi_code")
    private String gis_aoi_code;
    @Column(name = "batch_no")
    private String batch_no;
    @Column(name = "origin_id")
    private String origin_id;
    @Column(name = "old_team_id")
    private String old_team_id;
    @Column(name = "new_team_id")
    private String new_team_id;
    @Column(name = "flag")
    private String flag;
    @Column(name = "task_source")
    private String task_source;
    @Column(name = "inc_day")
    private String inc_day;

    private int freq;

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCheck_date_day() {
        return check_date_day;
    }

    public void setCheck_date_day(String check_date_day) {
        this.check_date_day = check_date_day;
    }

    public String getCheck_date_week() {
        return check_date_week;
    }

    public void setCheck_date_week(String check_date_week) {
        this.check_date_week = check_date_week;
    }

    public String getCheck_date_month() {
        return check_date_month;
    }

    public void setCheck_date_month(String check_date_month) {
        this.check_date_month = check_date_month;
    }

    public String getCheck_date_quarter() {
        return check_date_quarter;
    }

    public void setCheck_date_quarter(String check_date_quarter) {
        this.check_date_quarter = check_date_quarter;
    }

    public String getCheck_date_year() {
        return check_date_year;
    }

    public void setCheck_date_year(String check_date_year) {
        this.check_date_year = check_date_year;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getSch_code() {
        return sch_code;
    }

    public void setSch_code(String sch_code) {
        this.sch_code = sch_code;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getSys_code() {
        return sys_code;
    }

    public void setSys_code(String sys_code) {
        this.sys_code = sys_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress_md5() {
        return address_md5;
    }

    public void setAddress_md5(String address_md5) {
        this.address_md5 = address_md5;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getCreate_date() {
        return create_date;
    }

    public void setCreate_date(String create_date) {
        this.create_date = create_date;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public double getCheck_x() {
        return check_x;
    }

    public void setCheck_x(double check_x) {
        this.check_x = check_x;
    }

    public double getCheck_y() {
        return check_y;
    }

    public void setCheck_y(double check_y) {
        this.check_y = check_y;
    }

    public String getCheck_dept_code() {
        return check_dept_code;
    }

    public void setCheck_dept_code(String check_dept_code) {
        this.check_dept_code = check_dept_code;
    }

    public String getCheck_sch_code() {
        return check_sch_code;
    }

    public void setCheck_sch_code(String check_sch_code) {
        this.check_sch_code = check_sch_code;
    }

    public String getCheck_aoi_code() {
        return check_aoi_code;
    }

    public void setCheck_aoi_code(String check_aoi_code) {
        this.check_aoi_code = check_aoi_code;
    }

    public String getCheck_aoi_name() {
        return check_aoi_name;
    }

    public void setCheck_aoi_name(String check_aoi_name) {
        this.check_aoi_name = check_aoi_name;
    }

    public String getCheck_aoi_id() {
        return check_aoi_id;
    }

    public void setCheck_aoi_id(String check_aoi_id) {
        this.check_aoi_id = check_aoi_id;
    }

    public String getCheck_data_type() {
        return check_data_type;
    }

    public void setCheck_data_type(String check_data_type) {
        this.check_data_type = check_data_type;
    }

    public String getCheck_date() {
        return check_date;
    }

    public void setCheck_date(String check_date) {
        this.check_date = check_date;
    }

    public String getCheck_by() {
        return check_by;
    }

    public void setCheck_by(String check_by) {
        this.check_by = check_by;
    }

    public int getDel_flag() {
        return del_flag;
    }

    public void setDel_flag(int del_flag) {
        this.del_flag = del_flag;
    }

    public String getDel_date() {
        return del_date;
    }

    public void setDel_date(String del_date) {
        this.del_date = del_date;
    }

    public String getDept_type() {
        return dept_type;
    }

    public void setDept_type(String dept_type) {
        this.dept_type = dept_type;
    }

    public int getIs_encrypt() {
        return is_encrypt;
    }

    public void setIs_encrypt(int is_encrypt) {
        this.is_encrypt = is_encrypt;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getCity_origin() {
        return city_origin;
    }

    public void setCity_origin(String city_origin) {
        this.city_origin = city_origin;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getCms_check_state() {
        return cms_check_state;
    }

    public void setCms_check_state(int cms_check_state) {
        this.cms_check_state = cms_check_state;
    }

    public int getDone_state() {
        return done_state;
    }

    public void setDone_state(int done_state) {
        this.done_state = done_state;
    }

    public String getData_time() {
        return data_time;
    }

    public void setData_time(String data_time) {
        this.data_time = data_time;
    }

    public String getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(String emp_id) {
        this.emp_id = emp_id;
    }

    public String getGis_sch_code() {
        return gis_sch_code;
    }

    public void setGis_sch_code(String gis_sch_code) {
        this.gis_sch_code = gis_sch_code;
    }

    public String getGis_aoi_code() {
        return gis_aoi_code;
    }

    public void setGis_aoi_code(String gis_aoi_code) {
        this.gis_aoi_code = gis_aoi_code;
    }

    public String getBatch_no() {
        return batch_no;
    }

    public void setBatch_no(String batch_no) {
        this.batch_no = batch_no;
    }

    public String getOrigin_id() {
        return origin_id;
    }

    public void setOrigin_id(String origin_id) {
        this.origin_id = origin_id;
    }

    public String getOld_team_id() {
        return old_team_id;
    }

    public void setOld_team_id(String old_team_id) {
        this.old_team_id = old_team_id;
    }

    public String getNew_team_id() {
        return new_team_id;
    }

    public void setNew_team_id(String new_team_id) {
        this.new_team_id = new_team_id;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getTask_source() {
        return task_source;
    }

    public void setTask_source(String task_source) {
        this.task_source = task_source;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public int getFreq() {
        return freq;
    }

    public void setFreq(int freq) {
        this.freq = freq;
    }
}
