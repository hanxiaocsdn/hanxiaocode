package com.sf.gis.java.sds.enumtype;

public enum WrongDataConfigKey {
    dayAgo,gisEmptyCity,totalCity
}
