package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ShellExcutor;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.List;

public class TalsPushDataFtpService {
    private Logger logger = LoggerFactory.getLogger(TalsPushDataFtpService.class);
    public void push(JavaRDD<Row> rdd, List<String> columnList, String hdfsDir, String ftpDir, String ftpFile) {
        FtpManager ftpManager = FtpManager.getInstance(
                "10.116.49.190",
                21,
                "bdftp",
                "BrYsj20.23*fTkjbd"
        );
        if (!ftpManager.success) {
            logger.error("conn ftp error");
            System.exit(0);
        }

        try {
            new File(ftpFile).delete();
            ShellExcutor.exeCmd(String.format("hdfs dfs -rm -r -f %s", hdfsDir));
            rdd.map(o -> {
                int length = o.length();
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < length; i++) {
                    String value = o.getString(i);
                    if (value == null) {
                        value = "";
                    }
                    if (i != length - 1) {
                        builder.append(value).append("\t\t\t");
                    } else {
                        builder.append(value);
                    }
                }
                return builder.toString();
            }).repartition(1).saveAsTextFile(hdfsDir);
            ShellExcutor.exeCmd(String.format("hdfs dfs -get %s/part-00000 ./%s", hdfsDir, ftpFile));

            String fileHeaders = columnList.stream().reduce((h1, h2) -> h1.concat("\t\t\t").concat(h2)).orElse("");
            logger.error(fileHeaders);
            ShellExcutor.exeCmd(String.format("sed -i '1i\\%s' %s", fileHeaders, ftpFile));
            ftpManager.uploadFile(
                    ftpFile,
                    new String(ftpDir.getBytes("UTF-8"), "iso-8859-1"),
                    new String(ftpFile.getBytes("UTF-8"), "iso-8859-1")
            );
            logger.error("upload {} success", ftpFile);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            new File(ftpFile).delete();
            try {
                ShellExcutor.exeCmd(String.format("hdfs dfs -rm -r -f %s", hdfsDir));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void push_1(JavaRDD<Row> rdd, List<String> columnList, String hdfsDir, String ftpDir, String ftpFile) {
        FtpManager ftpManager = FtpManager.getInstance(
                "10.116.49.190",
                21,
                "bdftp",
                "Brysj2023@ftkjbd"
        );
        if (!ftpManager.success) {
            logger.error("conn ftp error");
            System.exit(0);
        }

        try {
            new File(ftpFile).delete();
            ShellExcutor.exeCmd(String.format("hdfs dfs -rm -r -f %s", hdfsDir));
            rdd.map(o -> {
                int length = o.length();
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < length; i++) {
                    String value = o.getString(i);
                    if (value == null) {
                        value = "";
                    }
                    if (i != length - 1) {
                        builder.append(value).append(",");
                    } else {
                        builder.append(value);
                    }
                }
                return builder.toString();
            }).repartition(1).saveAsTextFile(hdfsDir);
            ShellExcutor.exeCmd(String.format("hdfs dfs -get %s/part-00000 ./%s", hdfsDir, ftpFile));

            String fileHeaders = columnList.stream().reduce((h1, h2) -> h1.concat(",").concat(h2)).orElse("");
            logger.error(fileHeaders);
            ShellExcutor.exeCmd(String.format("sed -i '1i\\%s' %s", fileHeaders, ftpFile));
            ftpManager.uploadFile(
                    ftpFile,
                    new String(ftpDir.getBytes("UTF-8"), "iso-8859-1"),
                    new String(ftpFile.getBytes("UTF-8"), "iso-8859-1")
            );
            logger.error("upload {} success", ftpFile);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            new File(ftpFile).delete();
            try {
                ShellExcutor.exeCmd(String.format("hdfs dfs -rm -r -f %s", hdfsDir));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
