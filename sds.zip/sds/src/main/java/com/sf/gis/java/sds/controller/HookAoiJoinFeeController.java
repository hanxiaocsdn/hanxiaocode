package com.sf.gis.java.sds.controller;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.MapType;
import com.sf.gis.java.sds.service.UploadWaybillAoiDataToHiveService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

public class HookAoiJoinFeeController {
    private Map<String, String> configMap;
    private static final Logger logger = LoggerFactory.getLogger(HookAoiJoinFeeController.class);

    public HookAoiJoinFeeController(Map<String, String> configMap) {
        this.configMap = configMap;
    }

    public void start(String arg) throws Exception {
        addColumn();
    }

    private void addColumn() throws ParseException {
        UploadWaybillAoiDataToHiveService service = new UploadWaybillAoiDataToHiveService();
        int daysAgo = 728;
        Integer[] days = getLastMonthDays();
        for (int i = 0; i <= daysAgo; i++) {
            String dataTime = DateUtil.getCurrentDateBefore("yyyyMMdd", daysAgo - i);
            if (Integer.valueOf(dataTime) < days[0] || Integer.valueOf(dataTime) > days[1]) {
                // 测试使用
                continue;
            }

            service.saveToResultTable(new String[]{dataTime, MapType.shou.name()});
            service.saveToResultTable(new String[]{dataTime, MapType.pai.name()});
        }
    }

    /**
     * 获取上个月的开头和结尾两天
     *
     * @return
     */
    private Integer[] getLastMonthDays() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, -1);
        int endDay = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        int beginDay = calendar.getActualMinimum(Calendar.DAY_OF_MONTH);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        calendar.set(Calendar.DAY_OF_MONTH, beginDay);
        int beginDate = Integer.valueOf(sdf.format(calendar.getTime()));
        calendar.set(Calendar.DAY_OF_MONTH, endDay);
        int endDate = Integer.valueOf(sdf.format(calendar.getTime()));
        logger.error("" + beginDate + "," + endDate);
        return new Integer[]{beginDate, endDate};
    }
}