package com.sf.gis.java.sds.service;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.ShellExcutor;
import com.sf.gis.java.sds.bean.FtpClient;
import com.sf.gis.java.sds.bean.WaybillData;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.utils.ZipCompress;
import com.sf.gis.scala.base.spark.Spark;
import com.sf.gis.scala.base.util.HttpClientUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.File;
import java.io.Serializable;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;
public class PullWaybillDataService implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(PullWaybillDataService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    public static String TT_WAYBILL_INFO = "dm_gis.dwd_waybill_info_dtl_di";
    // public String HOOK_AOI_RSLT_TABLE = "dm_gis.aoi_hook_waybill_rslt_";
    public static String OMS_TO = "dm_gis.gis_rds_omsto";
    public static String OMS_FROM = "dm_gis.gis_rds_omsfrom";
    public static String AOI_FROM = "dm_gis.rds_omsfrom_aoi";
    public static String TT_WAYBILL_AOI_INFO = "dm_gis.tt_waybill_hook";
    public static String TT_ORDER_AOI_INFO = "dm_gis.tt_order_hook";

    public PullWaybillDataService() {
        sparkSession = Spark.getSparkSession(PullWaybillDataService.class.getSimpleName(), null, false, 2);
    }

    /**
     * 获取数据
     *
     * @param configMap
     * @param date
     * @throws Exception
     */
    public void pullDataByDay(Map<String, String> configMap, String[] date) throws Exception {
        logger.error("数据日期:" + date[0] + "," + date[1]);
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        FtpClient ftpClient = creattFtpClient(configMap, date[1]);
        String cities = openCityList.stream().collect(Collectors.joining("','"));
        String city_codes = openCityList.stream().collect(Collectors.joining(","));
        String dataType = configMap.get(ConfigKey.data_type.name());
        String deptHook = configMap.get(ConfigKey.dept_hook.name());
        List<String> deptHookList = (deptHook == null || deptHook.isEmpty()) ? null
                : Arrays.asList(deptHook.split(","));
        parserCity(cities, dataType, date[0], date[1], ftpClient, configMap, city_codes, deptHookList);

        ftpClient.close();
    }


    /**
     * 创建ftp客户端
     *
     * @param configMap
     * @param inc_day
     * @return
     */
    private FtpClient creattFtpClient(Map<String, String> configMap, String inc_day) {
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        ftpClient.setFtpFilePath(ftpPath);
        ftpClient.setFtpFileName(ftpFileName);
        return ftpClient;
    }

    private void parserCity(String city, String dataType, String beginDate, String endDate, FtpClient ftpClient,
                            Map<String, String> configMap, String city_codes, List<String> deptHookList) throws Exception {
        boolean useCache = "0".equals(configMap.get(ConfigKey.use_cache.name())) ? false : true;
        logger.error("useCache:" + useCache);
        String sql = null;
        if (dataType.equals("B")) {
            String inc_day_begin = DateUtil.getDayBefore(beginDate, "yyyyMMdd", 14);
            String inc_day_end = endDate;
            String logBeginDate = DateUtil.getDayBefore(beginDate, "yyyyMMdd", 5);
            String signin_tm = DateUtil.getDayBefore(endDate, 0, "yyyyMMdd", "yyyy-MM-dd");
            sql = "SELECT waybill_no,dest_dist_code as citycode ,dest_zone_code as zno_code,"
                    + " regexp_replace(consignee_addr_decrypt, '[\\r\\n\\0, \\,, \\.,\"]+', '') address,"
                    + " inc_day,regexp_replace(consignee_comp_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') comp_name,"
                    + " regexp_replace(consignee_phone, '[\\,]+', '') phone,"
                    + " regexp_replace(consignee_mobile, '[\\,]+', '') mobile, "
                    + " regexp_replace(dest_province, '[\\r\\n\\0, \\,, \\.,\"]+', '') province,"
                    + " regexp_replace(dest_county, '[\\r\\n\\0, \\,, \\.,\"]+', '') county,"
                    + " regexp_replace(consignee_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name FROM "
                    + TT_WAYBILL_INFO + " where (inc_day between '" + inc_day_begin + "' and '" + inc_day_end + "') "
                    + " and dest_dist_code in ('" + city + "') and signin_tm like '" + signin_tm + "%' ";
            if (deptHookList != null) {
                sql += " and dest_zone_code in ('" + deptHookList.stream().collect(Collectors.joining("','")) + "')";
            }

            String logSql = "select * from ( select req_waybillno, finalaoicode gisaoicode,finalzc gisDept,gis_to_sys_groupid groupId,"
                    + "finaltc teamcode,'' as log_address,row_number() over(partition BY req_waybillno order by req_time desc ) as rank "
                    + " from  " + OMS_TO + " where " + " inc_day between '" + logBeginDate + "' and '" + endDate
                    + "' and req_waybillno <> '' )a where a.rank=1 ";
            sql = "select b.waybill_no,b.citycode,b.zno_code,b.address,b.inc_day,b.comp_name,b.phone,b.mobile,b.province,"
                    + "b.county,b.cont_name,c.gisaoicode,c.gisDept,c.groupId,c.teamcode,c.log_address from (" + sql
                    + ") b left join (" + logSql + ") c" + " on b.waybill_no=c.req_waybillno ";
        } else {
            sql = "SELECT waybill_no,src_dist_code as citycode ,source_zone_code as zno_code,"
                    + " regexp_replace(consignor_addr_decrypt, '[\\r\\n\\0, \\,, \\.,\"]+', '') address,"
                    + " inc_day, regexp_replace(consignor_comp_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') comp_name,"
                    + " regexp_replace(consignor_phone, '[\\,]+', '') phone, "
                    + " regexp_replace(consignor_mobile, '[\\,]+', '') mobile,"
                    + " regexp_replace(src_province, '[\\r\\n\\0, \\,, \\.,\"]+', '') province,"
                    + " regexp_replace(src_county, '[\\r\\n\\0, \\,, \\.,\"]+', '') county,"
                    + " regexp_replace(consignor_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name,"
                    + " order_no FROM " + TT_WAYBILL_INFO + " where (inc_day between '" + beginDate + "' and '"
                    + endDate + "') " + " and src_dist_code in ('" + city + "') ";
            if (deptHookList != null) {
                sql += " and source_zone_code in ('" + deptHookList.stream().collect(Collectors.joining("','")) + "')";
            }
            String logBeginDate = DateUtil.getDayBefore(beginDate, "yyyyMMdd", 2);
            String logSql = "select * from ( select orderno,deptcode,'' as groupid,aoicode,teamcode," +
                    "regexp_replace(address, '[\\r\\n\\0, \\,, \\.,\"]+', '') log_address,"
                    + "row_number() over(partition BY orderno order by reqtime desc ) as rank " + " from  " + AOI_FROM
                    + " where " + " inc_day between '" + logBeginDate + "' and '" + endDate
                    + "' and orderno <> '' )a where a.rank=1 ";
            sql = "select b.waybill_no,b.citycode,b.zno_code,b.address,b.inc_day,b.comp_name,b.phone,b.mobile,b.province,"
                    + "b.county,b.cont_name,c.aoicode," + "c.deptcode,c.groupid,c.teamcode,c.log_address " + " from (" + sql
                    + ") b left join (" + logSql + ") c" + " on b.order_no=c.orderno ";
        }

        logger.error(sql);
        JavaRDD<WaybillData> dataRdd = sparkSession.sql(sql).javaRDD().persist(StorageLevel.MEMORY_AND_DISK_SER())
                .mapToPair(x -> {
                    return parserRow(x, endDate, dataType, useCache);
                }).reduceByKey((o1, o2) -> {
                    return o1;
                }).values();
        if (useCache && dataRdd.count() < 100000) {
            throw new Exception("数量过少，少于100000");
        }
        parserAllData(dataRdd, ftpClient, configMap, endDate, dataType, city_codes);
    }


    private Tuple2<String, WaybillData> parserRow(Row x, String endDate, String dataType, boolean useCache) {
        WaybillData ret = new WaybillData(x.getString(0), x.getString(1), x.getString(2), x.getString(3), endDate,
                dataType, x.getString(5), x.getString(6), x.getString(7), x.getString(8), x.getString(9),
                x.getString(10));
        String gisAoi = x.getString(11);
        String gisDept = x.getString(12);
        if (gisDept != null && gisDept.contains(",")) {
            gisDept = gisDept.split(",")[0];
        }
        String groupId = x.getString(13);
        String teamCode = x.getString(14);
        String logAddress = x.getString(15);
        if (teamCode != null && teamCode.contains(",")) {
            teamCode = teamCode.split(",")[0];
        }
        String cityCode = ret.getCitycode();
        ret.setAoiCode("");
        ret.setGroupId("");
        ret.setAoiId("");
        ret.setTeamCode("");
        if (useCache && gisAoi != null && !gisAoi.isEmpty() && !gisAoi.contains(",") && gisDept != null
                && !gisDept.isEmpty()
                && (cityCode == null || cityCode.isEmpty() || gisDept.startsWith(cityCode))
                && (logAddress==null || logAddress.isEmpty() || ret.getAddress()==null || logAddress.contains(ret.getAddress()) || ret.getAddress().contains(logAddress))
        ) {
            ret.setZno_code(gisDept);
            ret.setAoiCode(gisAoi);
            if (teamCode != null) {
                ret.setTeamCode(teamCode);
            }
            try {
                Set<String> groupIdSet = new HashSet<>(Arrays.asList(groupId.split("$")));
                groupIdSet.remove("");
                if (groupIdSet.size() == 1) {
                    ret.setGroupId(groupId);
                }
            } catch (Exception e) {

            }
        }
        return new Tuple2<String, WaybillData>(ret.getCitycode() + "_" + ret.getWaybill_no(), ret);

    }

    private void parserAllData(JavaRDD<WaybillData> dataRdd, FtpClient ftpClient, Map<String, String> configMap,
                               String inc_day, String dataType, String city_codes) throws Exception {
        // 加上分区得到唯一id
        JavaRDD<String> ret = null;
        ret = dataRdd.map(x -> x.getWaybill_no() + "," + x.getCitycode() + "," + x.getAddress() + "," + x.getZno_code()
                + "," + x.getInc_day() + "," + x.getDataType() + "," + x.getCompany() + "," + x.getPhone() + ","
                + x.getMobile() + "," + x.getProvince() + "," + x.getCountry() + "," + x.getContName() + ","
                + x.getAoiCode() + "," + x.getAoiId() + "," + x.getGroupId() + "," + x.getTeamCode());

        String srcName = ftpClient.getFtpFileName() + "_" + inc_day + "_" + dataType;
        try {
            String hdfsFile = "/user/01374443/upload/tmp/aoi_waybill/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            logger.error("增加文件头~");
            ShellExcutor
                    .exeCmd("sed -i '1i\\waybillno,city_code,address,zno_code,inc_day,data_type,company,phone,mobile,province,country,"
                            + "cont_name,aoiCode,aoi_id,group_group,team' " + srcName + ".csv");

            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient);
            delete_file(srcName);
            String moveUrl = configMap.get(ConfigKey.move_data_url.name());

            HttpClientUtil.getStrByGet(String.format(moveUrl, ftpClient.getFtpFilePath(), srcName + ".zip", inc_day,
                    dataType, inc_day, dataType, city_codes),"UTF-8");

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private void delete_file(String srcName) {
        File file = new File(srcName + ".zip");
        if (file.exists()) {
            file.delete();
        }
        file = new File(srcName + ".csv");
        if (file.exists()) {
            file.delete();
        }
    }

    private boolean checkFile(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return false;
        } else if (file.length() == 0) {
            file.delete();
            return false;
        }
        return true;
    }

    private void uploadFile(String fileName, FtpClient ftpClient) {
        try {
            logger.error(fileName + "," + ftpClient.getFtpFilePath());
            ftpClient.uploadFile(fileName, ftpClient.getFtpFilePath());
        } catch (Exception e) {
            logger.error("ftp error:" + e.getMessage());
        }
    }

    /**
     * 获取指定网点的数据
     *
     * @param configMap
     * @param strings
     * @param changedDept
     * @throws Exception
     */
    public void pullChangeDataByDay(Map<String, String> configMap, String[] date, Set<String> changedDept,
                                    Set<String> cityList) throws Exception {
        logger.error("数据日期:" + date[0] + "," + date[1]);
        logger.error("open city:" + cityList);
        FtpClient ftpClient = creattFtpClient(configMap, date[1]);
        String cities = cityList.stream().collect(Collectors.joining("','"));
        String city_codes = cityList.stream().collect(Collectors.joining(","));
        String changeDeptStr = changedDept.stream().collect(Collectors.joining("','"));
        logger.error("变更网点:" + changeDeptStr);
        String dataType = configMap.get(ConfigKey.data_type.name());
        parserCityChangeNew(cities, dataType, date[0], date[1], ftpClient, configMap, city_codes, changeDeptStr);

        ftpClient.close();
    }


    /**
     * 解析变更城市
     *
     * @param city
     * @param dataType
     * @param beginDate
     * @param endDate
     * @param ftpClient
     * @param configMap
     * @param city_codes
     * @throws Exception
     */
    private void parserCityChangeNew(String city, String dataType, String beginDate, String endDate,
                                     FtpClient ftpClient, Map<String, String> configMap, String city_codes, String changeDeptStr)
            throws Exception {
        String sql = null;

        if (dataType.equals("B")) {
            String inc_day_begin = beginDate;
            String inc_day_end = endDate;
            String dataTimeSql = "(inc_day between '" + inc_day_begin + "' and '" + inc_day_end + "') ";
            // String signin_tm = DateUtils.getDaysAgo(endDate, 0, "yyyyMMdd",
            // "yyyy-MM-dd");
            sql = "select waybill_no, dest_dist_code, aoi_zc, regexp_replace(consignee_addr, '[\\r\\n\\0, \\,, \\.,\"]+', '') address,"
                    + " inc_day,regexp_replace(consignee_comp_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') comp_name,"
                    + "regexp_replace(consignee_phone, '[\\,]+', '') phone,regexp_replace(consignee_mobile, '[\\,]+', '') mobile,"
                    + "regexp_replace(dest_province, '[\\r\\n\\0, \\,, \\.,\"]+', '') province,regexp_replace(dest_county, '[\\r\\n\\0, \\,, \\.,\"]+', '') county ,"
                    + "regexp_replace(consignee_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name from "
                    + TT_WAYBILL_AOI_INFO + " where " + dataTimeSql + " and dest_dist_code in ('" + city
                    + "') and aoi_zc in ('" + changeDeptStr + "') ";
        } else {
            String dataTimeSql = "(inc_day between '" + beginDate + "' and '" + endDate + "') ";
            sql = "select waybill_no, src_dist_code, aoi_zc, regexp_replace(consignor_addr, '[\\r\\n\\0, \\,, \\.,\"]+', '') address,"
                    + " inc_day,regexp_replace(consignor_comp_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') comp_name,"
                    + "regexp_replace(consignor_phone, '[\\,]+', '') phone,regexp_replace(consignor_mobile, '[\\,]+', '')  mobile,"
                    + "regexp_replace(src_province, '[\\r\\n\\0, \\,, \\.,\"]+', '') province,"
                    + "regexp_replace(src_county, '[\\r\\n\\0, \\,, \\.,\"]+', '') county,"
                    + "regexp_replace(consignor_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name from  "
                    + TT_ORDER_AOI_INFO + " where " + dataTimeSql + " and src_dist_code in ('" + city + "') "
                    + "and aoi_zc in ('" + changeDeptStr + "') ";
        }

        logger.error(sql);
        JavaRDD<WaybillData> dataRdd = sparkSession.sql(sql).javaRDD().persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> {
                    WaybillData ret = new WaybillData(x.getString(0), x.getString(1), x.getString(2), x.getString(3),
                            x.getString(4), dataType, x.getString(5), x.getString(6), x.getString(7), x.getString(8),
                            x.getString(9), x.getString(10));
                    ret.setAoiCode("");
                    ret.setGroupId("");
                    ret.setAoiId("");
                    return ret;
                });
        parserAllData(dataRdd, ftpClient, configMap, endDate, dataType, city_codes);
    }

    /**
     * 获取电话相关数据， 用于电话挂接
     *
     * @param configMap
     * @param phoneHookDate
     * @throws ParseException
     */
    public void pullPhoneData(Map<String, String> configMap, List<String> phoneHookDate) throws ParseException {

        logger.error("phone hook city:" + configMap.get(ConfigKey.phone_hook_city.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.phone_hook_city.name()).split(","));
        String beginDate = phoneHookDate.get(phoneHookDate.size() - 1);
        String endDate = phoneHookDate.get(0);
        FtpClient ftpClient = creattFtpClient(configMap, endDate);
        String cities = openCityList.stream().collect(Collectors.joining("','"));
        String dataType = configMap.get(ConfigKey.data_type.name());
        // 从hive中得到rdd
        JavaRDD<WaybillData> dataRdd = pullPhoneDataFromHive(beginDate, endDate, dataType, cities);
        uploadPhoneDataToFtp(dataRdd, ftpClient, endDate, dataType);
        ftpClient.close();
    }

    /**
     * 上传phone数据文件
     *
     * @param dataRdd
     * @param ftpClient
     * @param dataType
     * @param inc_day
     */
    private void uploadPhoneDataToFtp(JavaRDD<WaybillData> dataRdd, FtpClient ftpClient, String inc_day,
                                      String dataType) {
        // 加上分区得到唯一id
        JavaRDD<String> ret = null;
        ret = dataRdd.map(x -> x.getWaybill_no() + "," + x.getCitycode() + "," + x.getZno_code() + "," + x.getInc_day()
                + "," + x.getDataType() + "," + x.getPhone() + "," + x.getMobile() + "," + x.getContName() + ","
                + x.getAoiId() + "," + x.getAoiName() + "," + x.getAoiAlias() + "," + x.getAoiAddress() + ","
                + x.getAoiX() + "," + x.getAoiY());
        String srcName = "aoi-waybill_auto" + "_" + inc_day + "_" + dataType + "_" + "phone";
        try {
            String hdfsFile = "/user/01374443/upload/tmp/aoi_waybill/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            logger.error("增加文件头~");
            ShellExcutor
                    .exeCmd("sed -i '1i\\waybillno,city_code,zno_code,inc_day,data_type,phone,mobile,cont_name,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y' "
                            + srcName + ".csv");

            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient);
            delete_file(srcName);

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    /**
     * 从hive中获取数据rdd
     *
     * @param beginDate
     * @param endDate
     * @param dataType
     * @param cities
     * @return
     * @throws ParseException
     */
    private JavaRDD<WaybillData> pullPhoneDataFromHive(String beginDate, String endDate, String dataType, String cities)
            throws ParseException {
        String sql = null;
        String dataTimeSql = "(inc_day between '" + beginDate + "' and '" + endDate + "') ";
        if (dataType.equals("B")) {
            String inc_day_begin = beginDate;
            String inc_day_end = endDate;
            String dataTimeSqlOrigin = "(inc_day between '" + inc_day_begin + "' and '" + inc_day_end + "') ";
            // String signin_tm = DateUtils.getDaysAgo(endDate, 0, "yyyyMMdd",
            // "yyyy-MM-dd");
            sql = "select waybill_no, dest_dist_code, aoi_zc, inc_day,regexp_replace(consignee_phone, '[\\,]+', '') phone,"
                    + "regexp_replace(consignee_mobile, '[\\,]+', '') mobile,regexp_replace(consignee_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name,"
                    + " aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y from " + TT_WAYBILL_AOI_INFO + " where "
                    + dataTimeSqlOrigin + " and dest_dist_code in ('" + cities
                    + "') and (consignee_phone <> '' or consignee_mobile <> '') " + " and aoi_id <> '' ";
        } else {
            sql = "select waybill_no, src_dist_code, aoi_zc, inc_day,regexp_replace(consignor_phone, '[\\,]+', '') phone,"
                    + "regexp_replace(consignor_mobile, '[\\,]+', '') mobile,"
                    + "regexp_replace(consignor_cont_name, '[\\r\\n\\0, \\,, \\.,\"]+', '') cont_name,"
                    + " aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y from " + TT_ORDER_AOI_INFO + " where "
                    + dataTimeSql + " and src_dist_code in ('" + cities
                    + "') and (consignor_phone <> '' or consignor_mobile <> '') and aoi_id <> '' ";
        }

        logger.error(sql);
        JavaRDD<WaybillData> dataRdd = sparkSession.sql(sql).javaRDD().persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> new WaybillData(x.getString(0), x.getString(1), x.getString(2), x.getString(3), dataType,
                        x.getString(4), x.getString(5), x.getString(6), x.getString(7), x.getString(8), x.getString(9),
                        x.getString(10), x.getString(11), x.getString(12)));
        return dataRdd;
    }

    /**
     * 计算治愈项目的变更数据
     *
     * @param zhiyuChangeCity
     * @param zhiyuChangedDept
     * @param date
     * @return
     */
    public Long calChangeDataCount(Set<String> changeCity, Set<String> changedDept, List<String> date,
                                   Map<String, String> configMap) {

        String sql = null;
        String dataTimeSql = "(inc_day between '" + date.get(0) + "' and '" + date.get(date.size() - 1) + "') ";
        String dataType = configMap.get(ConfigKey.data_type.name());
        String changeDeptStr = changedDept.stream().collect(Collectors.joining("','"));
        String city = changeCity.stream().collect(Collectors.joining("','"));
        if (dataType.equals("B")) {
            sql = "select  count(1) from " + TT_WAYBILL_AOI_INFO + " where " + dataTimeSql + " and aoi_zc in ('"
                    + changeDeptStr + "') and dest_dist_code in ('" + city + "') ";
        } else {
            sql = "select  count(1) from " + TT_ORDER_AOI_INFO + " where " + dataTimeSql + " and aoi_zc in ('"
                    + changeDeptStr + "') and src_dist_code in ('" + city + "') ";
        }

        logger.error(sql);
        Long count = sparkSession.sql(sql).javaRDD().map(x -> x.getLong(0)).collect().get(0);
        logger.error("count:" + count);
        return count;
    }

}
