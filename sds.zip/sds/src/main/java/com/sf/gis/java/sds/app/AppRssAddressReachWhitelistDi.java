package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.FvpCoreFactRouteOverRangeZjStat;
import com.sf.gis.java.sds.pojo.RssAddressReachWhitelistDi;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * 任务id:788970(GIS-RSS-ARS:【超范围转寄白名单结果表过滤已识别正确数据需求】) 该需求经产品确认，无需上线
 * 业务方：01425247（段嫦慧）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月15日11:43:57
 */
public class AppRssAddressReachWhitelistDi {
    private static Logger logger = LoggerFactory.getLogger(AppRssAddressReachWhitelistDi.class);
    private static String url = "http://gis-int.int.sfdc.com.cn:1080/ar/api?address=%s&ak=6eff21e6ecc3410bb79c6717ccc62e80";
    private static int limitMin = 2000 / 10;

    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        logger.error("date1:{}, date2:{}", date1, date2);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppRssAddressReachWhitelistDi");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select * from dm_gis.rss_address_reach_whitelist_di where inc_day between '%s' and '%s'", date1, date2);
        JavaRDD<RssAddressReachWhitelistDi> rdd = DataUtil.loadData(spark, sc, sql, RssAddressReachWhitelistDi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<RssAddressReachWhitelistDi> arRdd = rdd.repartition(20).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            ArrayList<RssAddressReachWhitelistDi> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                RssAddressReachWhitelistDi o = itr.next();
                String consignee_addr = o.getConsignee_addr();
                int temp_result = 0;
                String temp_src = "";
                if (StringUtils.isNotEmpty(consignee_addr)) {
                    String req = String.format(url, URLEncoder.encode(consignee_addr, "UTF-8"));
                    String content = HttpInvokeUtil.sendGet(req);

                    try {
                        temp_result = JSON.parseObject(content).getInteger("result");
                        temp_src = JSON.parseObject(content).getString("src");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }
                o.setTemp_result(temp_result);
                o.setTemp_src(temp_src);
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("arRdd cnt:{}", arRdd.count());
        rdd.unpersist();

        JavaRDD<RssAddressReachWhitelistDi> deleteRdd = arRdd.filter(o -> o.getTemp_result() == 2 && !StringUtils.equals(o.getTemp_src(), "AR-REDIS")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<RssAddressReachWhitelistDi> stayRdd = arRdd.filter(o -> !(o.getTemp_result() == 2 && !StringUtils.equals(o.getTemp_src(), "AR-REDIS"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deleteRdd cnt:{}", deleteRdd.count());
        logger.error("stayRdd cnt:{}", stayRdd.count());
        arRdd.unpersist();
        deleteRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.rss_address_reach_whitelist_di", RssAddressReachWhitelistDi.class, stayRdd, "inc_day");
        stayRdd.unpersist();
        sc.stop();
    }
}
