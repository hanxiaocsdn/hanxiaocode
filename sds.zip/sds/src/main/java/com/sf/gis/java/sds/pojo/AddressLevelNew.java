package com.sf.gis.java.sds.pojo;

import scala.Serializable;

public class AddressLevelNew implements Serializable {

    public String aoi;
    public String subAoi;
    public String building;
    public String unit;
    public String floor;
    public String room;

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getSubAoi() {
        return subAoi;
    }

    public void setSubAoi(String subAoi) {
        this.subAoi = subAoi;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }
}
