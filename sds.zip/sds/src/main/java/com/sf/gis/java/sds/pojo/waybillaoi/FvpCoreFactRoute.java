package com.sf.gis.java.sds.pojo.waybillaoi;

import com.sf.gis.java.sds.pojo.TrackAoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class FvpCoreFactRoute implements Serializable, Comparable<FvpCoreFactRoute> {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "opcode")
    private String opcode;
    @Column(name = "barscantmstd")
    private String barscantmstd;

    @Column(name = "baroprcode")
    private String baroprcode;
    @Column(name = "hour")
    private String hour;
    @Column(name = "ordinal")
    private String ordinal;

    private long ordinal_cnt;

    public long getOrdinal_cnt() {
        return ordinal_cnt;
    }

    public void setOrdinal_cnt(long ordinal_cnt) {
        this.ordinal_cnt = ordinal_cnt;
    }

    public String getBaroprcode() {
        return baroprcode;
    }

    public void setBaroprcode(String baroprcode) {
        this.baroprcode = baroprcode;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getOrdinal() {
        return ordinal;
    }

    public void setOrdinal(String ordinal) {
        this.ordinal = ordinal;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    public String getBarscantmstd() {
        return barscantmstd;
    }

    public void setBarscantmstd(String barscantmstd) {
        this.barscantmstd = barscantmstd;
    }

    @Override
    public int compareTo(FvpCoreFactRoute o) {
        long sum_stay_time = this.getOrdinal_cnt();
        long sum_stay_time1 = o.getOrdinal_cnt();
        if (sum_stay_time > sum_stay_time1) {
            return 1;
        } else if (sum_stay_time < sum_stay_time1) {
            return -1;
        }
        return 0;
    }
}
