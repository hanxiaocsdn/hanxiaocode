package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.ClassExecutionCondition;
import com.sf.gis.java.sds.service.ClassExecutionConditionService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class ClassExecutionConditionController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(ClassExecutionConditionController.class);
    ClassExecutionConditionService service = new ClassExecutionConditionService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<ClassExecutionCondition> classExecutionConditionRdd = service.loadData(spark, sc, date).filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.equals(o.getIsPushLine(), "1")).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("classExecutionConditionRdd cnt:{}", classExecutionConditionRdd.count());
            classExecutionConditionRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));


            //按大区分组
            JavaRDD<ClassExecutionCondition> classExecutionConditionTaskAreaCodeGroupRdd = classExecutionConditionRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<ClassExecutionCondition> list = Lists.newArrayList(tp._2);
                ClassExecutionCondition classExecutionCondition = list.get(0);

                String stat_type = "AREA";
                String stat_type_content = classExecutionCondition.getTaskAreaCode();

                //任务量
                int taskCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行量
                int executionCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行量
                int no_executionCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //达成量
                int reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未达成量
                int no_reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行_达成量
                int executeReachCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行_达成量
                int noExecuteReachCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //基准总etc
                double baseSumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总etc
                double sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总etc
                double execution_sumEtc = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总etc
                double no_execution_sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总超时时长
                long sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总超时时长
                long execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")))
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总超时时长
                long no_execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));


                classExecutionCondition.setStat_type(stat_type);
                classExecutionCondition.setStat_type_content(stat_type_content);
                classExecutionCondition.setLine_area("ALL");
                classExecutionCondition.setLineCode("ALL");
                classExecutionCondition.setTaskCount(taskCount);
                classExecutionCondition.setExecutionCount(executionCount);
                classExecutionCondition.setNo_executionCount(no_executionCount);
                classExecutionCondition.setReachCount(reachCount);
                classExecutionCondition.setNo_reachCount(no_reachCount);
                classExecutionCondition.setExecuteReachCount(executeReachCount);
                classExecutionCondition.setNoExecuteReachCount(noExecuteReachCount);
                classExecutionCondition.setBaseSumEtc(baseSumEtc);
                classExecutionCondition.setSumEtc(sumEtc);
                classExecutionCondition.setExecution_sumEtc(execution_sumEtc);
                classExecutionCondition.setNo_execution_sumEtc(no_execution_sumEtc);
                classExecutionCondition.setSumTimeOut(sumTimeOut);
                classExecutionCondition.setExecution_sumTimeOut(execution_sumTimeOut);
                classExecutionCondition.setNo_execution_sumTimeOut(no_execution_sumTimeOut);

                return classExecutionCondition;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("classExecutionConditionTaskAreaCodeGroupRdd cnt:{}", classExecutionConditionTaskAreaCodeGroupRdd.count());
            classExecutionConditionTaskAreaCodeGroupRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            //按大区，片区分组
            JavaRDD<ClassExecutionCondition> classExecutionConditionLineAreaGroupRdd = classExecutionConditionRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getLine_area(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<ClassExecutionCondition> list = Lists.newArrayList(tp._2);
                ClassExecutionCondition classExecutionCondition = list.get(0);

                String stat_type = "LINEAREA";
                String stat_type_content = classExecutionCondition.getLine_area();

                //任务量
                int taskCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行量
                int executionCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行量
                int no_executionCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //达成量
                int reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未达成量
                int no_reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行_达成量
                int executeReachCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行_达成量
                int noExecuteReachCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //基准总etc
                double baseSumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总etc
                double sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总etc
                double execution_sumEtc = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总etc
                double no_execution_sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总超时时长
                long sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总超时时长
                long execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")))
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总超时时长
                long no_execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));


                classExecutionCondition.setStat_type(stat_type);
                classExecutionCondition.setStat_type_content(stat_type_content);
                classExecutionCondition.setLineCode("ALL");
                classExecutionCondition.setTaskCount(taskCount);
                classExecutionCondition.setExecutionCount(executionCount);
                classExecutionCondition.setNo_executionCount(no_executionCount);
                classExecutionCondition.setReachCount(reachCount);
                classExecutionCondition.setNo_reachCount(no_reachCount);
                classExecutionCondition.setExecuteReachCount(executeReachCount);
                classExecutionCondition.setNoExecuteReachCount(noExecuteReachCount);
                classExecutionCondition.setBaseSumEtc(baseSumEtc);
                classExecutionCondition.setSumEtc(sumEtc);
                classExecutionCondition.setExecution_sumEtc(execution_sumEtc);
                classExecutionCondition.setNo_execution_sumEtc(no_execution_sumEtc);
                classExecutionCondition.setSumTimeOut(sumTimeOut);
                classExecutionCondition.setExecution_sumTimeOut(execution_sumTimeOut);
                classExecutionCondition.setNo_execution_sumTimeOut(no_execution_sumTimeOut);

                return classExecutionCondition;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("classExecutionConditionLineAreaGroupRdd cnt:{}", classExecutionConditionLineAreaGroupRdd.count());
            classExecutionConditionLineAreaGroupRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            //按大区，片区，班次分组
            JavaRDD<ClassExecutionCondition> classExecutionConditionLineCodeGroupRdd = classExecutionConditionRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getLine_area(), o.getLineCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<ClassExecutionCondition> list = Lists.newArrayList(tp._2);
                ClassExecutionCondition classExecutionCondition = list.get(0);

                String stat_type = "CLASSID";
                String stat_type_content = classExecutionCondition.getLineCode();

                //任务量
                int taskCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行量
                int executionCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行量
                int no_executionCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //达成量
                int reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未达成量
                int no_reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行_达成量
                int executeReachCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行_达成量
                int noExecuteReachCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //基准总etc
                double baseSumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总etc
                double sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总etc
                double execution_sumEtc = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总etc
                double no_execution_sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总里程
                double sumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总里程
                double execution_sumDistance = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总里程
                double no_execution_sumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总耗时
                long sumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总耗时
                long execution_sumConsumeTime = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总耗时
                long no_execution_sumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //总超时时长
                long sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总超时时长
                long execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")))
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总超时时长
                long no_execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_超时任务量
                int executeNoReachCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行_超时任务量
                int noExecuteNoReachCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                classExecutionCondition.setExecute_no_reach_count(executeNoReachCount);
                classExecutionCondition.setNo_execute_no_reach_count(noExecuteNoReachCount);
                classExecutionCondition.setStat_type(stat_type);
                classExecutionCondition.setStat_type_content(stat_type_content);
                classExecutionCondition.setTaskCount(taskCount);
                classExecutionCondition.setExecutionCount(executionCount);
                classExecutionCondition.setNo_executionCount(no_executionCount);
                classExecutionCondition.setReachCount(reachCount);
                classExecutionCondition.setNo_reachCount(no_reachCount);
                classExecutionCondition.setExecuteReachCount(executeReachCount);
                classExecutionCondition.setNoExecuteReachCount(noExecuteReachCount);
                classExecutionCondition.setBaseSumEtc(baseSumEtc);
                classExecutionCondition.setSumEtc(sumEtc);
                classExecutionCondition.setExecution_sumEtc(execution_sumEtc);
                classExecutionCondition.setNo_execution_sumEtc(no_execution_sumEtc);
                classExecutionCondition.setSumDistance(sumDistance);
                classExecutionCondition.setExecution_sumDistance(execution_sumDistance);
                classExecutionCondition.setNo_execution_sumDistance(no_execution_sumDistance);
                classExecutionCondition.setSumConsumeTime(sumConsumeTime);
                classExecutionCondition.setExecution_sumConsumeTime(execution_sumConsumeTime);
                classExecutionCondition.setNo_execution_sumConsumeTime(no_execution_sumConsumeTime);
                classExecutionCondition.setSumTimeOut(sumTimeOut);
                classExecutionCondition.setExecution_sumTimeOut(execution_sumTimeOut);
                classExecutionCondition.setNo_execution_sumTimeOut(no_execution_sumTimeOut);

                return classExecutionCondition;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("classExecutionConditionLineCodeGroupRdd cnt:{}", classExecutionConditionLineCodeGroupRdd.count());
            classExecutionConditionLineCodeGroupRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));


            //插入bdp平台
            if (classExecutionConditionLineCodeGroupRdd.count() > 0) {
                String sql = String.format("alter table dm_gis.eta_class_execute_stat drop if EXISTS partition(inc_day='%s')", date);
                logger.error("sql:{}", sql);
                spark.sql(sql);
                service.saveData(spark, classExecutionConditionLineCodeGroupRdd, date);
            } else {
                logger.error("按班次分组查无数据");
            }

            //不按维度分组
            JavaRDD<ClassExecutionCondition> classExecutionConditionNoGroupRdd = classExecutionConditionRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<ClassExecutionCondition> list = Lists.newArrayList(tp._2);
                ClassExecutionCondition classExecutionCondition = list.get(0);

                String stat_type = "ALL";
                String stat_type_content = "ALL";
                String taskAreaCode = "ALL";
                String lineArea = "ALL";
                String lineCode = "ALL";

                //任务量
                int taskCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行量
                int executionCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行量
                int no_executionCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //达成量
                int reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未达成量
                int no_reachCount = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //执行_达成量
                int executeReachCount = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //未执行_达成量
                int noExecuteReachCount = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ClassExecutionCondition::getTaskId))), ArrayList::new))
                        .size();

                //基准总etc
                double baseSumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总etc
                double sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总etc
                double execution_sumEtc = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总etc
                double no_execution_sumEtc = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总里程
                double sumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //执行_总里程
                double execution_sumDistance = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //未执行_总里程
                double no_execution_sumDistance = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getLenNew()))
                        .map(o -> (double) Math.round((Double.valueOf(o.getLenNew()) / 1000.0) * 10) / 10)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //总耗时
                long sumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总耗时
                long execution_sumConsumeTime = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总耗时
                long no_execution_sumConsumeTime = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(String.valueOf(o.getActualRunTime())))
                        .map(o -> o.getActualRunTime())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //总超时时长
                long sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //执行_总超时时长
                long execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")))
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //未执行_总超时时长
                long no_execution_sumTimeOut = list.stream()
                        .filter(o -> o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2)
                        .map(o -> String.valueOf(o.getNodbDelayMin()) != null ? o.getNodbDelayMin() : 0)
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));


                classExecutionCondition.setStat_type(stat_type);
                classExecutionCondition.setStat_type_content(stat_type_content);
                classExecutionCondition.setTaskAreaCode(taskAreaCode);
                classExecutionCondition.setLine_area(lineArea);
                classExecutionCondition.setLineCode(lineCode);
                classExecutionCondition.setTaskCount(taskCount);
                classExecutionCondition.setExecutionCount(executionCount);
                classExecutionCondition.setNo_executionCount(no_executionCount);
                classExecutionCondition.setReachCount(reachCount);
                classExecutionCondition.setNo_reachCount(no_reachCount);
                classExecutionCondition.setExecuteReachCount(executeReachCount);
                classExecutionCondition.setNoExecuteReachCount(noExecuteReachCount);
                classExecutionCondition.setBaseSumEtc(baseSumEtc);
                classExecutionCondition.setSumEtc(sumEtc);
                classExecutionCondition.setExecution_sumEtc(execution_sumEtc);
                classExecutionCondition.setNo_execution_sumEtc(no_execution_sumEtc);
                classExecutionCondition.setSumDistance(sumDistance);
                classExecutionCondition.setExecution_sumDistance(execution_sumDistance);
                classExecutionCondition.setNo_execution_sumDistance(no_execution_sumDistance);
                classExecutionCondition.setSumConsumeTime(sumConsumeTime);
                classExecutionCondition.setExecution_sumConsumeTime(execution_sumConsumeTime);
                classExecutionCondition.setNo_execution_sumConsumeTime(no_execution_sumConsumeTime);
                classExecutionCondition.setSumTimeOut(sumTimeOut);
                classExecutionCondition.setExecution_sumTimeOut(execution_sumTimeOut);
                classExecutionCondition.setNo_execution_sumTimeOut(no_execution_sumTimeOut);

                return classExecutionCondition;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("classExecutionConditionNoGroupRdd cnt:{}", classExecutionConditionNoGroupRdd.count());
            classExecutionConditionNoGroupRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));


            JavaRDD<ClassExecutionCondition> finalRdd = classExecutionConditionTaskAreaCodeGroupRdd.union(classExecutionConditionLineAreaGroupRdd).union(classExecutionConditionLineCodeGroupRdd).union(classExecutionConditionNoGroupRdd).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            finalRdd.take(1).forEach(o -> JSON.toJSONString(o));

            classExecutionConditionNoGroupRdd.unpersist();
            classExecutionConditionLineCodeGroupRdd.unpersist();
            classExecutionConditionLineAreaGroupRdd.unpersist();
            classExecutionConditionTaskAreaCodeGroupRdd.unpersist();
            classExecutionConditionRdd.unpersist();


            //插入数据库
            if (finalRdd.count() > 0) {
                if (flag != size) {
                    //删除数据
                    service.delete(date);
                }
                service.saveToMysql(sc, finalRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            finalRdd.unpersist();
        }
        spark.stop();
    }
}
