package com.sf.gis.java.sds.service.impl;


import com.sf.gis.java.sds.pojo.WrongDataDeptEmpty;

import java.util.List;

public interface IWrongDataDeptEmptyService {

    void insert(List<WrongDataDeptEmpty> list) throws Exception;

    void createTable();

    void deleteData(String date, String cityCode);

}