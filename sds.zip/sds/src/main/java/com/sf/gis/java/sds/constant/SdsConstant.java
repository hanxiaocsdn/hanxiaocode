package com.sf.gis.java.sds.constant;

/**
 * 常量类
 * @author 01370539 Created On: May.07 2021
 */
public class SdsConstant {
    public static final String GET_AOI_DISTANCE = "50";

    public static final int COORD_CONVERGE_DIS_50 = 50;
    public static final String IS_EFFECT_0 = "0"; // 无效；
    public static final String IS_EFFECT_1 = "1"; // 有效；
    public static final String IS_EFFECT_2 = "2"; // 没有经过任何校验；
    public static final String EFFECT_TYPE_MATCH_ZC = "MATCH_ZC"; // 无效:聚合坐标和网点坐标相同；
    public static final String EFFECT_TYPE_UNMATCH_AOI = "UNMATCH_AOI"; // 无效:聚合坐标不在AOI内；
    public static final String EFFECT_TYPE_MATCH_AOI = "MATCH_AOI"; // 有效:聚合坐标在AOI内
    public static final String EFFECT_TYPE_MATCH_KH = "MATCH_KH"; // 有效:聚合坐标和客户下单坐标相同
    public static final String EFFECT_TYPE_MATCH_GEO = "MATCH_GEO"; // 有效:聚合坐标和地理编码坐标相同
    public static final String EFFECT_TYPE_MATCH_AOIKH = "MATCH_AOI-KH"; // 有效：聚合坐标在AOI内，并且和客户下单时的坐标相同
    public static final String EFFECT_TYPE_MATCH_AOIGEO = "MATCH_AOI-GEO"; // 有效：聚合坐标在AOI内，并且和地理编码坐标相同
    public static final String EFFECT_TYPE_MATCH_GEOKH = "MATCH_GEO-KH"; // 有效：聚合坐标和地理编码以及客户下单时的坐标相同
    public static final String EFFECT_TYPE_MATCH_AOIGEOKH = "MATCH_AOI-GEO-KH"; // 有效：聚合坐标在AOI内，并且和地理编码以及客户下单时的坐标相同
    public static final String EFFECT_TYPE_DEFAULT = "DEFAULT"; // 无法判断

    public static final String SFP_ADDR_PROCESS_INIT = "INIT";
    public static final String SFP_ADDR_PROCESS_INIT_REGION = "INIT_REGION";
    public static final String SFP_ADDR_PROCESS_SPLIT = "SPLIT";
    public static final String SFP_ADDR_PROCESS_COORD = "COORD";
    public static final String SFP_ADDR_PROCESS_NORM = "NORM";
    public static final String SFP_ADDR_PROCESS_PUSH = "PUSH";
    public static final String SFP_ADDR_PROCESS_PUSH_COORD = "PUSH_COORD";
    public static final String SFP_ADDR_PROCESS_BUILDING = "BUILDING";
    public static final String SFP_ADDR_PROCESS_VERIFY = "VERIFY";
    public static final String SFP_ADDR_PROCESS_ALL = "ALL";
}
