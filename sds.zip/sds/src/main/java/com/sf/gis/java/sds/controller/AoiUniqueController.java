package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class AoiUniqueController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiUniqueController.class);

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> normUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?addressId=%s&cityCode=%s");
        Broadcast<String> chknUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?addressMd5=%s&cityCode=%s");
        Broadcast<String> aoiCheckTagUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck");

        logger.error("获取源数据");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> judgeWrongOperationRdd = loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("judgeWrongOperationRdd cnt:{}", judgeWrongOperationRdd.count());
        judgeWrongOperationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("gis_to_sys_groupid下finalaoiid唯一");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> uniqueFinalaoiidRdd = judgeWrongOperationRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o))
                .groupByKey().filter(tp -> {
                    boolean flag = true;
                    List<AoiRealAccturyRateJudgeWrongOperation> list = Lists.newArrayList(tp._2);
                    int size = list.stream()
                            .filter(o -> StringUtils.isNotEmpty(o.getFinalaoiid()))
                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(AoiRealAccturyRateJudgeWrongOperation::getFinalaoiid))), ArrayList::new))
                            .size();
                    if (size > 1) {
                        flag = false;
                    }
                    return flag;
                }).flatMap(tp -> Lists.newArrayList(tp._2).iterator()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueFinalaoiidRdd cnt:{}", uniqueFinalaoiidRdd.count());
        uniqueFinalaoiidRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        judgeWrongOperationRdd.unpersist();

        logger.error("按照gis_to_sys_groupid排重");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> uniqueGistosysgroupidRdd = uniqueFinalaoiidRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueGistosysgroupidRdd cnt:{}", uniqueGistosysgroupidRdd.count());
        uniqueGistosysgroupidRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        uniqueFinalaoiidRdd.unpersist();

        logger.error("调取cms查询库中当前库中aoiId");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> normRdd = uniqueGistosysgroupidRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> chknRdd = uniqueGistosysgroupidRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "chkn")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:{}", normRdd.count());
        logger.error("chknRdd cnt:{}", chknRdd.count());

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> normAoiRdd = normRdd.map(o -> {
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                String content = runGetCmsAoi(normUrlBc.value(), city_code, gis_to_sys_groupid);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if (data != null) {
                                String aoiId = data.getString("aoiId");
                                String adcode = data.getString("adcode");
                                o.setAdcode(adcode);
                                o.setOld_cms_aoiid(aoiId);
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normAoiRdd cnt:{}", normAoiRdd.count());
        normAoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        normRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> chknAoiRdd = chknRdd.map(o -> {
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                String content = runGetCmsAoi(chknUrlBc.value(), city_code, gis_to_sys_groupid);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject.getBoolean("success");
                        if (success) {
                            JSONObject data = jsonObject.getJSONObject("data");
                            if (data != null) {
                                String aoiId = data.getString("aoiId");
                                String adcode = data.getString("adcode");
                                o.setAdcode(adcode);
                                o.setOld_cms_aoiid(aoiId);
                            }

                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("chknAoiRdd cnt:{}", chknAoiRdd.count());
        chknAoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        chknRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> unionRdd = normAoiRdd.union(chknRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unionRdd cnt:{}", unionRdd.count());
        unionRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        normAoiRdd.unpersist();
        chknRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> updateRdd = unionRdd.filter(o -> !StringUtils.equals(o.getAdcode(), "1") && StringUtils.equals(o.getFinalaoiid(), o.getOld_cms_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("updateRdd cnt:{}", updateRdd.count());
        updateRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        unionRdd.unpersist();

        logger.error("数据入库");
        String executeSql = String.format("alter table dm_gis.aoi_real_acctury_rate_judge_wrong_operation_week_stat_cms drop if EXISTS partition(type='%s')", "cms");
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, updateRdd, "cms", "dm_gis.aoi_real_acctury_rate_judge_wrong_operation_week_stat_cms");

        logger.error("将gis_to_sys_groupid在cms地址库中标记正确");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> checkRdd = updateRdd.repartition(200).map(o -> {
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                JSONArray list = new JSONArray();
                list.add(gis_to_sys_groupid);

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cityCode", city_code);
                jsonObject.put("aoiCheckTag", 1);
                jsonObject.put("addressIds", list);

                String content = runCheckTag(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject1 = JSON.parseObject(content);
                    if (jsonObject != null) {
                        Boolean success = jsonObject1.getBoolean("success");
                        o.setCheckFlag(success);
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd sucess cnt:{}", checkRdd.filter(o -> o.isCheckFlag()).count());
        logger.error("checkRdd fail cnt:{}", checkRdd.filter(o -> !o.isCheckFlag()).count());
        updateRdd.unpersist();
        checkRdd.unpersist();
        spark.stop();

    }

    public void saveData(SparkSession spark, JavaRDD<AoiRealAccturyRateJudgeWrongOperation> inRdd, String type, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCity_code(), o.getReq_addresseeaddr(), o.getGisaoisrc(), o.getGis_to_sys_groupid(), o.getFinalaoiid(), o.getLabel(), o.getOperate_date(), o.getOld_cms_aoiid()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "city_code", "req_addresseeaddr", "gisaoisrc", "gis_to_sys_groupid", "finalaoiid", "label", "operate_date", "aoiid"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_real_acctury_rate_judge_wrong_operation_week_stat_cms_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(type = '%s')" +
                "select * from %s", targetTable, type, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public String runCheckTag(String url, String param) {
        String content = "";
        try {
            logger.error("check tag url:{}", url);
            content = UrlUtil.sendPost(url, param);
            logger.error("content:{}", content);
        } catch (Exception e) {
            logger.error("check tag error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runGetCmsAoi(String urlPattern, String cityCode, String addressId) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, addressId, cityCode);
            logger.error("url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request cms error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("judge_wrong_operation_week_stat.sql", date);
        logger.error("judge_wrong_operation_week_stat sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

}
