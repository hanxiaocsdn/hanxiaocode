package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class Fcg implements Serializable {

    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "city_name")
    private String cityName;
    @Column(name = "dept_code")
    private String deptCode;
    @Column(name = "dept_center_x")
    private String deptCenterX;
    @Column(name = "dept_center_y")
    private String deptCenterY;
    @Column(name = "aoi_area_code")
    private String aoiAreaCode;
    @Column(name = "aoi_area_near")
    private String aoiAreaNear;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_center_x")
    private String aoiCenterX;
    @Column(name = "aoi_center_y")
    private String aoiCenterY;
    @Column(name = "wb_count")
    private String wbCount;
    @Column(name = "m_count")
    private String mCount;
    @Column(name = "fwsj_count")
    private String fwsjCount;
    @Column(name = "total_count")
    private String totalCount;
    @Column(name = "tag")
    private String tag;
    @Column(name = "key")
    private String key;
    @Column(name = "fcg_cnt")
    private String fcgCnt;
    @Column(name = "inc_day")
    private String incDay;

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptCenterX() {
        return deptCenterX;
    }

    public void setDeptCenterX(String deptCenterX) {
        this.deptCenterX = deptCenterX;
    }

    public String getDeptCenterY() {
        return deptCenterY;
    }

    public void setDeptCenterY(String deptCenterY) {
        this.deptCenterY = deptCenterY;
    }

    public String getAoiAreaCode() {
        return aoiAreaCode;
    }

    public void setAoiAreaCode(String aoiAreaCode) {
        this.aoiAreaCode = aoiAreaCode;
    }

    public String getAoiAreaNear() {
        return aoiAreaNear;
    }

    public void setAoiAreaNear(String aoiAreaNear) {
        this.aoiAreaNear = aoiAreaNear;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiCenterX() {
        return aoiCenterX;
    }

    public void setAoiCenterX(String aoiCenterX) {
        this.aoiCenterX = aoiCenterX;
    }

    public String getAoiCenterY() {
        return aoiCenterY;
    }

    public void setAoiCenterY(String aoiCenterY) {
        this.aoiCenterY = aoiCenterY;
    }

    public String getWbCount() {
        return wbCount;
    }

    public void setWbCount(String wbCount) {
        this.wbCount = wbCount;
    }

    public String getmCount() {
        return mCount;
    }

    public void setmCount(String mCount) {
        this.mCount = mCount;
    }

    public String getFwsjCount() {
        return fwsjCount;
    }

    public void setFwsjCount(String fwsjCount) {
        this.fwsjCount = fwsjCount;
    }

    public String getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(String totalCount) {
        this.totalCount = totalCount;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getFcgCnt() {
        return fcgCnt;
    }

    public void setFcgCnt(String fcgCnt) {
        this.fcgCnt = fcgCnt;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }
    @Override
    public String toString() {
        return "Fcg{" +
                "cityCode='" + cityCode + '\'' +
                ", cityName='" + cityName + '\'' +
                ", deptCode='" + deptCode + '\'' +
                ", deptCenterX='" + deptCenterX + '\'' +
                ", deptCenterY='" + deptCenterY + '\'' +
                ", aoiAreaCode='" + aoiAreaCode + '\'' +
                ", aoiAreaNear='" + aoiAreaNear + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiCenterX='" + aoiCenterX + '\'' +
                ", aoiCenterY='" + aoiCenterY + '\'' +
                ", wbCount='" + wbCount + '\'' +
                ", mCount='" + mCount + '\'' +
                ", fwsjCount='" + fwsjCount + '\'' +
                ", totalCount='" + totalCount + '\'' +
                ", tag='" + tag + '\'' +
                ", key='" + key + '\'' +
                ", fcgCnt='" + fcgCnt + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
