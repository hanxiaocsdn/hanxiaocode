package com.sf.gis.java.sds.pojo;


import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.MD5Util;

import javax.persistence.Column;
import javax.persistence.Entity;

@Entity
public class AddressOrder {
    @Column(name = "id")
    private String id;
    @Column(name = "unique_md5")
    private String uniqueMd5;
    @Column(name = "address_src_md5")
    private String addressSrcMd5;
    @Column(name = "address")
    private String address;
    @Column(name = "origin_src")
    private String originSrc;
    @Column(name = "CREATE_TIME")
    private String createTime;
    @Column(name = "data_time")
    private String dataTime;
    @Column(name = "UPDATE_TIME")
    private String updateTime;
    @Column(name = "waybillNo")
    private String waybillNo;
    @Column(name = "city_code")
    private String city_code;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public AddressOrder() {
    }

    public AddressOrder(String id, String waybillNo, String address, String originSrc,
                        String dataTime, String city_code) {
        this.id = id;
        this.waybillNo = waybillNo;
        this.address = address;
        this.originSrc = originSrc;
        JSONObject jobject = new JSONObject();
        jobject.put("address", address);
        jobject.put("origin_src", originSrc);
        this.addressSrcMd5 = MD5Util.getMD5(jobject.toJSONString());
        jobject.put("waybillNo", waybillNo);
        this.uniqueMd5 = MD5Util.getMD5(jobject.toJSONString());
        this.dataTime = dataTime;
        this.city_code = city_code;
    }

    public String getAddressSrcMd5() {
        return addressSrcMd5;
    }

    public void setAddressSrcMd5(String addressSrcMd5) {
        this.addressSrcMd5 = addressSrcMd5;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUniqueMd5() {
        return uniqueMd5;
    }

    public void setUniqueMd5(String uniqueMd5) {
        this.uniqueMd5 = uniqueMd5;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOriginSrc() {
        return originSrc;
    }

    public void setOriginSrc(String originSrc) {
        this.originSrc = originSrc;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getDataTime() {
        return dataTime;
    }

    public void setDataTime(String dataTime) {
        this.dataTime = dataTime;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

}