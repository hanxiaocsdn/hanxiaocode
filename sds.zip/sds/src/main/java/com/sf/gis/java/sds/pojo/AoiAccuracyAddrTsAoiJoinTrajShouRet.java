package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class AoiAccuracyAddrTsAoiJoinTrajShouRet implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;

    @Column(name = "city_code")
    private String city_code;

    @Column(name = "org_code")
    private String org_code;

    @Column(name = "eventtype")
    private String eventtype;

    @Column(name = "userid")
    private String userid;

    @Column(name = "operatime_new")
    private String operatime_new;

    @Column(name = "pick_lgt")
    private String pick_lgt;

    @Column(name = "pick_lat")
    private String pick_lat;

    @Column(name = "inc_day_gd")
    private String inc_day_gd;

    @Column(name = "req_citycode")
    private String req_citycode;

    @Column(name = "req_address")
    private String req_address;

    @Column(name = "finalaoicode")
    private String finalaoicode;

    @Column(name = "gj_aoiid_t")
    private String gj_aoiid_t;

    @Column(name = "gj_aoicode_t")
    private String gj_aoicode_t;

    @Column(name = "gj_aoiname_t")
    private String gj_aoiname_t;

    @Column(name = "starttime")
    private String starttime;

    @Column(name = "endtime")
    private String endtime;

    @Column(name = "gjaoi_frq")
    private String gjaoi_frq;

    @Column(name = "inc_day_gj")
    private String inc_day_gj;

    @Column(name = "tag1")
    private String tag1;

    @Column(name = "tag2")
    private String tag2;

    @Column(name = "r_aoi")
    private String r_aoi;

    @Column(name = "gisaoicode_rds")
    private String gisaoicode_rds;

    @Column(name = "ksaoicode")
    private String ksaoicode;

    @Column(name = "src_order_no")
    private String src_order_no;

    @Column(name = "isnotundercall")
    private String isnotundercall;

    @Column(name = "syssource")
    private String syssource;

    @Column(name = "req_comp_name")
    private String req_comp_name;

    @Column(name = "finalzc")
    private String finalzc;

    @Column(name = "src")
    private String src;

    @Column(name = "ks_aoi_src")
    private String ks_aoi_src;

    @Column(name = "zonecode")
    private String zonecode;

    @Column(name = "baroprcode")
    private String baroprcode;

    @Column(name = "opcode")
    private String opcode;

    @Column(name = "barscantmstd")
    private String barscantmstd;

    @Column(name = "couriercode")
    private String couriercode;

    @Column(name = "finalaoiid")
    private String finalaoiid;

    @Column(name = "groupid")
    private String groupid;

    @Column(name = "extra")
    private String extra;

    @Column(name = "split_info")
    private String split_info;

    @Column(name = "last13")
    private String last13;

    @Column(name = "last14")
    private String last14;

    @Column(name = "last613")
    private String last613;

    @Column(name = "key_level")
    private String key_level;

    @Column(name = "key_word")
    private String key_word;

    @Column(name = "key_tag")
    private String key_tag;

    @Column(name = "54_aoi_id")
    private String aoi_id_54;

    @Column(name = "54_aoi_code")
    private String aoi_code_54;

    @Column(name = "54_aoi_name")
    private String aoi_name_54;

    @Column(name = "gis_aoi_code")
    private String gis_aoi_code;

    @Column(name = "gis_aoi_name")
    private String gis_aoi_name;

    @Column(name = "gis_aoi_splitinfo")
    private String gis_aoi_splitinfo;

    @Column(name = "54_aoi_splitinfo")
    private String aoi_splitinfo_54;

    @Column(name = "mapa_aoiid")
    private String mapa_aoiid;

    @Column(name = "mapa_aoicode")
    private String mapa_aoicode;

    @Column(name = "mapa_aoiname")
    private String mapa_aoiname;

    @Column(name = "gd_aoiid")
    private String gd_aoiid;

    @Column(name = "gd_aoicode")
    private String gd_aoicode;

    @Column(name = "gd_aoiname")
    private String gd_aoiname;

    @Column(name = "gj_aoicode_else")
    private String gj_aoicode_else;

    @Column(name = "gj_aoiname_else")
    private String gj_aoiname_else;

    @Column(name = "gj_aoiid_else")
    private String gj_aoiid_else;

    @Column(name = "gd_start_1")
    private String gd_start_1;

    @Column(name = "gd_end_1")
    private String gd_end_1;

    @Column(name = "1_min_aoi_list")
    private String min_aoi_list_1;

    @Column(name = "gd_start_2")
    private String gd_start_2;

    @Column(name = "gd_end_2")
    private String gd_end_2;

    @Column(name = "2_min_aoi_list")
    private String min_aoi_list_2;

    @Column(name = "min_aoi_gj")
    private String min_aoi_gj;

    @Column(name = "plan_aoi_code_list")
    private String plan_aoi_code_list;

    @Column(name = "isforward")
    private String isforward;

    @Column(name = "time_dur")
    private String time_dur;

    @Column(name = "tsaoibody")
    private String tsaoibody;

    @Column(name = "nr_aoiid")
    private String nr_aoiid;

    @Column(name = "gd_ps_aoiid")
    private String gd_ps_aoiid;

    private List<String> aoi_code_list;

    private String aoi;
    private String aoisrc;
    private String mobile;
    private String gd_x;
    private String gd_y;

    public String getGd_x() {
        return gd_x;
    }

    public void setGd_x(String gd_x) {
        this.gd_x = gd_x;
    }

    public String getGd_y() {
        return gd_y;
    }

    public void setGd_y(String gd_y) {
        this.gd_y = gd_y;
    }

    public String getGd_ps_aoiid() {
        return gd_ps_aoiid;
    }

    public void setGd_ps_aoiid(String gd_ps_aoiid) {
        this.gd_ps_aoiid = gd_ps_aoiid;
    }

    public String getNr_aoiid() {
        return nr_aoiid;
    }

    public void setNr_aoiid(String nr_aoiid) {
        this.nr_aoiid = nr_aoiid;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getAoisrc() {
        return aoisrc;
    }

    public void setAoisrc(String aoisrc) {
        this.aoisrc = aoisrc;
    }

    public String getTsaoibody() {
        return tsaoibody;
    }

    public void setTsaoibody(String tsaoibody) {
        this.tsaoibody = tsaoibody;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public List<String> getAoi_code_list() {
        return aoi_code_list;
    }

    public String getPlan_aoi_code_list() {
        return plan_aoi_code_list;
    }

    public void setPlan_aoi_code_list(String plan_aoi_code_list) {
        this.plan_aoi_code_list = plan_aoi_code_list;
    }

    public String getIsforward() {
        return isforward;
    }

    public void setIsforward(String isforward) {
        this.isforward = isforward;
    }

    public String getTime_dur() {
        return time_dur;
    }

    public void setTime_dur(String time_dur) {
        this.time_dur = time_dur;
    }

    public void setAoi_code_list(List<String> aoi_code_list) {
        this.aoi_code_list = aoi_code_list;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getEventtype() {
        return eventtype;
    }

    public void setEventtype(String eventtype) {
        this.eventtype = eventtype;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getOperatime_new() {
        return operatime_new;
    }

    public void setOperatime_new(String operatime_new) {
        this.operatime_new = operatime_new;
    }

    public String getPick_lgt() {
        return pick_lgt;
    }

    public void setPick_lgt(String pick_lgt) {
        this.pick_lgt = pick_lgt;
    }

    public String getPick_lat() {
        return pick_lat;
    }

    public void setPick_lat(String pick_lat) {
        this.pick_lat = pick_lat;
    }

    public String getInc_day_gd() {
        return inc_day_gd;
    }

    public void setInc_day_gd(String inc_day_gd) {
        this.inc_day_gd = inc_day_gd;
    }

    public String getReq_citycode() {
        return req_citycode;
    }

    public void setReq_citycode(String req_citycode) {
        this.req_citycode = req_citycode;
    }

    public String getReq_address() {
        return req_address;
    }

    public void setReq_address(String req_address) {
        this.req_address = req_address;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getGj_aoiid_t() {
        return gj_aoiid_t;
    }

    public void setGj_aoiid_t(String gj_aoiid_t) {
        this.gj_aoiid_t = gj_aoiid_t;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getGj_aoiname_t() {
        return gj_aoiname_t;
    }

    public void setGj_aoiname_t(String gj_aoiname_t) {
        this.gj_aoiname_t = gj_aoiname_t;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getGjaoi_frq() {
        return gjaoi_frq;
    }

    public void setGjaoi_frq(String gjaoi_frq) {
        this.gjaoi_frq = gjaoi_frq;
    }

    public String getInc_day_gj() {
        return inc_day_gj;
    }

    public void setInc_day_gj(String inc_day_gj) {
        this.inc_day_gj = inc_day_gj;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getR_aoi() {
        return r_aoi;
    }

    public void setR_aoi(String r_aoi) {
        this.r_aoi = r_aoi;
    }

    public String getGisaoicode_rds() {
        return gisaoicode_rds;
    }

    public void setGisaoicode_rds(String gisaoicode_rds) {
        this.gisaoicode_rds = gisaoicode_rds;
    }

    public String getKsaoicode() {
        return ksaoicode;
    }

    public void setKsaoicode(String ksaoicode) {
        this.ksaoicode = ksaoicode;
    }

    public String getSrc_order_no() {
        return src_order_no;
    }

    public void setSrc_order_no(String src_order_no) {
        this.src_order_no = src_order_no;
    }

    public String getIsnotundercall() {
        return isnotundercall;
    }

    public void setIsnotundercall(String isnotundercall) {
        this.isnotundercall = isnotundercall;
    }

    public String getSyssource() {
        return syssource;
    }

    public void setSyssource(String syssource) {
        this.syssource = syssource;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getKs_aoi_src() {
        return ks_aoi_src;
    }

    public void setKs_aoi_src(String ks_aoi_src) {
        this.ks_aoi_src = ks_aoi_src;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getBaroprcode() {
        return baroprcode;
    }

    public void setBaroprcode(String baroprcode) {
        this.baroprcode = baroprcode;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    public String getBarscantmstd() {
        return barscantmstd;
    }

    public void setBarscantmstd(String barscantmstd) {
        this.barscantmstd = barscantmstd;
    }

    public String getCouriercode() {
        return couriercode;
    }

    public void setCouriercode(String couriercode) {
        this.couriercode = couriercode;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public String getSplit_info() {
        return split_info;
    }

    public void setSplit_info(String split_info) {
        this.split_info = split_info;
    }

    public String getLast13() {
        return last13;
    }

    public void setLast13(String last13) {
        this.last13 = last13;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getLast613() {
        return last613;
    }

    public void setLast613(String last613) {
        this.last613 = last613;
    }

    public String getKey_level() {
        return key_level;
    }

    public void setKey_level(String key_level) {
        this.key_level = key_level;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getKey_tag() {
        return key_tag;
    }

    public void setKey_tag(String key_tag) {
        this.key_tag = key_tag;
    }

    public String getAoi_id_54() {
        return aoi_id_54;
    }

    public void setAoi_id_54(String aoi_id_54) {
        this.aoi_id_54 = aoi_id_54;
    }

    public String getAoi_code_54() {
        return aoi_code_54;
    }

    public void setAoi_code_54(String aoi_code_54) {
        this.aoi_code_54 = aoi_code_54;
    }

    public String getAoi_name_54() {
        return aoi_name_54;
    }

    public void setAoi_name_54(String aoi_name_54) {
        this.aoi_name_54 = aoi_name_54;
    }

    public String getGis_aoi_code() {
        return gis_aoi_code;
    }

    public void setGis_aoi_code(String gis_aoi_code) {
        this.gis_aoi_code = gis_aoi_code;
    }

    public String getGis_aoi_name() {
        return gis_aoi_name;
    }

    public void setGis_aoi_name(String gis_aoi_name) {
        this.gis_aoi_name = gis_aoi_name;
    }

    public String getGis_aoi_splitinfo() {
        return gis_aoi_splitinfo;
    }

    public void setGis_aoi_splitinfo(String gis_aoi_splitinfo) {
        this.gis_aoi_splitinfo = gis_aoi_splitinfo;
    }

    public String getAoi_splitinfo_54() {
        return aoi_splitinfo_54;
    }

    public void setAoi_splitinfo_54(String aoi_splitinfo_54) {
        this.aoi_splitinfo_54 = aoi_splitinfo_54;
    }

    public String getMapa_aoiid() {
        return mapa_aoiid;
    }

    public void setMapa_aoiid(String mapa_aoiid) {
        this.mapa_aoiid = mapa_aoiid;
    }

    public String getMapa_aoicode() {
        return mapa_aoicode;
    }

    public void setMapa_aoicode(String mapa_aoicode) {
        this.mapa_aoicode = mapa_aoicode;
    }

    public String getMapa_aoiname() {
        return mapa_aoiname;
    }

    public void setMapa_aoiname(String mapa_aoiname) {
        this.mapa_aoiname = mapa_aoiname;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getGd_aoicode() {
        return gd_aoicode;
    }

    public void setGd_aoicode(String gd_aoicode) {
        this.gd_aoicode = gd_aoicode;
    }

    public String getGd_aoiname() {
        return gd_aoiname;
    }

    public void setGd_aoiname(String gd_aoiname) {
        this.gd_aoiname = gd_aoiname;
    }

    public String getGj_aoicode_else() {
        return gj_aoicode_else;
    }

    public void setGj_aoicode_else(String gj_aoicode_else) {
        this.gj_aoicode_else = gj_aoicode_else;
    }

    public String getGj_aoiname_else() {
        return gj_aoiname_else;
    }

    public void setGj_aoiname_else(String gj_aoiname_else) {
        this.gj_aoiname_else = gj_aoiname_else;
    }

    public String getGj_aoiid_else() {
        return gj_aoiid_else;
    }

    public void setGj_aoiid_else(String gj_aoiid_else) {
        this.gj_aoiid_else = gj_aoiid_else;
    }

    public String getGd_start_1() {
        return gd_start_1;
    }

    public void setGd_start_1(String gd_start_1) {
        this.gd_start_1 = gd_start_1;
    }

    public String getGd_end_1() {
        return gd_end_1;
    }

    public void setGd_end_1(String gd_end_1) {
        this.gd_end_1 = gd_end_1;
    }

    public String getMin_aoi_list_1() {
        return min_aoi_list_1;
    }

    public void setMin_aoi_list_1(String min_aoi_list_1) {
        this.min_aoi_list_1 = min_aoi_list_1;
    }

    public String getGd_start_2() {
        return gd_start_2;
    }

    public void setGd_start_2(String gd_start_2) {
        this.gd_start_2 = gd_start_2;
    }

    public String getGd_end_2() {
        return gd_end_2;
    }

    public void setGd_end_2(String gd_end_2) {
        this.gd_end_2 = gd_end_2;
    }

    public String getMin_aoi_list_2() {
        return min_aoi_list_2;
    }

    public void setMin_aoi_list_2(String min_aoi_list_2) {
        this.min_aoi_list_2 = min_aoi_list_2;
    }

    public String getMin_aoi_gj() {
        return min_aoi_gj;
    }

    public void setMin_aoi_gj(String min_aoi_gj) {
        this.min_aoi_gj = min_aoi_gj;
    }
}
