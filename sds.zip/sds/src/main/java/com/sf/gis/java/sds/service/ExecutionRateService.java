package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.ExecutionRate;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class ExecutionRateService implements Serializable {
    private Logger logger = LoggerFactory.getLogger(ExecutionRateService.class);

    public JavaRDD<ExecutionRate> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("tals_get_target_data.sql", date, date, date);
        logger.error("tals_get_target_data sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ExecutionRate.class);
    }

    public void saveData(SparkSession spark, JavaRDD<ExecutionRate> inRdd) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getIncMonth(), o.getIncDay(), o.getDay(), o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(),
                    o.getShuttleNumber() + "", o.getTaskNumber() + "", o.getExecutionNumber() + "", o.getSelfSupportTaskNumber() + "", o.getSelfSupportExecutionNumber() + "",
                    o.getNoSelfSupportTaskNumber() + "", o.getNoSelfSupportExecutionNumber() + "", o.getSelfSupportOtherExecutionNumber() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"STAT_MONTH", "STAT_DATE", "STAT_WEEK", "SRC_PROVINCE", "DESC_PROVINCE", "AREA", "SRC_CITYCODE", "DESC_CITYCODE",
                "CLASS_COUNT", "TASK_COUNT", "EXECUTE_COUNT", "ZY_TASK_COUNT", "ZY_EXECUTE_COUNT", "NOT_ZY_TASK_COUNT", "NOT_ZY_EXECUTE_COUNT", "ZY_OTHER_EXECUTE_COUNT"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "ETA_EXECUTE_RATE_STAT_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.ETA_EXECUTE_RATE_STAT";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveToMysql(JavaSparkContext sc, JavaRDD<ExecutionRate> rdd) {
        logger.error("insert into mysql");
        String dbConfig = "mysql.properties";
        Broadcast<String> dbConfigBc = sc.broadcast(dbConfig);
        rdd.repartition(16).foreachPartition(p -> {
            java.sql.Connection conn = DbUtil.getInstance(dbConfigBc.value()).getConn();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement(
                    String.format("insert into ETA_EXECUTE_RATE_STAT(`STAT_MONTH`, `STAT_DATE`, `STAT_WEEK`, `SRC_PROVINCE`, " +
                            "`DESC_PROVINCE`, `AREA`, `SRC_CITYCODE`, `DESC_CITYCODE`, `CLASS_COUNT`, `TASK_COUNT`, `EXECUTE_COUNT`, " +
                            "`ZY_TASK_COUNT`, `ZY_EXECUTE_COUNT`, `NOT_ZY_TASK_COUNT`, `NOT_ZY_EXECUTE_COUNT`, `ZY_OTHER_EXECUTE_COUNT`) " +
                            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            );
            while (p.hasNext()) {
                ExecutionRate o = p.next();
                pstmt.setString(1, o.getIncMonth());
                pstmt.setString(2, o.getIncDay());
                pstmt.setString(3, o.getDay());
                pstmt.setString(4, o.getSrcProvince());
                pstmt.setString(5, o.getDestProvince());
                pstmt.setString(6, o.getTaskAreaCode());
                pstmt.setString(7, o.getSrcCityName());
                pstmt.setString(8, o.getDestCityName());
                pstmt.setInt(9, o.getShuttleNumber());
                pstmt.setInt(10, o.getTaskNumber());
                pstmt.setInt(11, o.getExecutionNumber());
                pstmt.setInt(12, o.getSelfSupportTaskNumber());
                pstmt.setInt(13, o.getSelfSupportExecutionNumber());
                pstmt.setInt(14, o.getNoSelfSupportTaskNumber());
                pstmt.setInt(15, o.getNoSelfSupportExecutionNumber());
                pstmt.setInt(16, o.getSelfSupportOtherExecutionNumber());
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            pstmt.close();
            conn.close();
        });
        logger.error("insert into mysql end");
    }

    //删除mysql数据
    public void delete(String date) {
        java.sql.Connection conn = DbUtil.getInstance("mysql.properties").getConn();
        String sql = String.format("delete from ETA_EXECUTE_RATE_STAT where STAT_DATE = '%s'", date);
        PreparedStatement pst = null;
        try {
            // 创建预编译语句
            pst = conn.prepareStatement(sql);
            // 执行SQL
            pst.executeUpdate();
            logger.error("删除成功");
            // 关闭资源
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("删除失败");
        }
    }

}
