package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AoiChannelInformationQueryController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 工作流任务id:436922(Aoi-资源分层数据汇总) --> 任务id:436926(aoi渠道信息查询和整合)
 * 业务方：01369702（蓝媛青）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月15日11:21:05
 */
public class AppAoiChannelInformationQuery {
    private static Logger logger = LoggerFactory.getLogger(AppAoiChannelInformationQuery.class);

    public static void main(String[] args) {
        String incDay = args[0];
        logger.error("incDay:{}", incDay);
        logger.error("run start");
//        ConfInit.init();
        new AoiChannelInformationQueryController().start(incDay);
        logger.error("run end");
    }
}
