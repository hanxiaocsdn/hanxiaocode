package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;

/**
 * lbs定位管控服务日志映射类
 * @author 01370539 Sep.16 2021
 */
public class LbsLogPnsAoi {
    @Column(name = "gid")
    private String gid;   // 唯一码
    @Column(name = "city")
    private String city;   // 城市编码
    @Column(name = "employee_id")
    private String employeeId;   // 小哥工号
    @Column(name = "aoi_id")
    private String aoiId;   // 派件地址 AOI ID
    @Column(name = "emp_aoi")
    private String empAoi;   // 小哥当前位置 AOI ID
    @Column(name = "waybill_no")
    private String waybillNo;   // 运单号
    @Column(name = "address")
    private String address;   // 运单地址
    @Column(name = "company")
    private String company;   // 公司名称
    @Column(name = "tracks")
    private String tracks;   // 轨迹串，eg：[{\"x\":110.24978508861508,\"y\":21.36276619366625,\"distance\":2.56,\"scope\":1,\"t\":1631495160,\"ac\":4.0},{\"x\":110.2497602930168,\"y\":21.362781941273862,\"distance\":0.92,\"scope\":1,\"t\":1631495165,\"ac\":3.0}]
    @Column(name = "standard")
    private String standard;   // 是否规范
    @Column(name = "match_type")
    private String matchType;   // 规范类型
    @Column(name = "current_tm")
    private String currentTm;   // 时间
    @Column(name = "aoi_side_distance")
    private String aoiSideDistance;
    @Column(name = "standard_result")
    private String standardResult;
    @Column(name = "type_result")
    private String typeResult;
    @Column(name = "poi_id")
    private String poiId;

    @Column(name = "wifilist")
    private String wifilist;
    @Column(name = "wifimatchaddresslist")
    private String wifimatchaddresslist;
    @Column(name = "wifimatchtype")
    private String wifimatchtype;


    @Column(name = "inc_day")
    private String incDay;


    private String msgTm;

    public String getWifilist() {
        return wifilist;
    }

    public void setWifilist(String wifilist) {
        this.wifilist = wifilist;
    }

    public String getWifimatchaddresslist() {
        return wifimatchaddresslist;
    }

    public void setWifimatchaddresslist(String wifimatchaddresslist) {
        this.wifimatchaddresslist = wifimatchaddresslist;
    }

    public String getWifimatchtype() {
        return wifimatchtype;
    }

    public void setWifimatchtype(String wifimatchtype) {
        this.wifimatchtype = wifimatchtype;
    }


    public String getPoiId() {
        return poiId;
    }

    public void setPoiId(String poiId) {
        this.poiId = poiId;
    }

    public String getAoiSideDistance() {
        return aoiSideDistance;
    }

    public void setAoiSideDistance(String aoiSideDistance) {
        this.aoiSideDistance = aoiSideDistance;
    }

    public String getStandardResult() {
        return standardResult;
    }

    public void setStandardResult(String standardResult) {
        this.standardResult = standardResult;
    }

    public String getTypeResult() {
        return typeResult;
    }

    public void setTypeResult(String typeResult) {
        this.typeResult = typeResult;
    }

    public String getGid() {
        return gid;
    }

    public void setGid(String gid) {
        this.gid = gid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getEmpAoi() {
        return empAoi;
    }

    public void setEmpAoi(String empAoi) {
        this.empAoi = empAoi;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getTracks() {
        return tracks;
    }

    public void setTracks(String tracks) {
        this.tracks = tracks;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getMatchType() {
        return matchType;
    }

    public void setMatchType(String matchType) {
        this.matchType = matchType;
    }

    public String getCurrentTm() {
        return currentTm;
    }

    public void setCurrentTm(String currentTm) {
        this.currentTm = currentTm;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public String getMsgTm() {
        return msgTm;
    }

    public void setMsgTm(String msgTm) {
        this.msgTm = msgTm;
    }

    @Override
    public String toString() {
        return "RdsPnsAoiLog{" +
                "gid='" + gid + '\'' +
                ", city='" + city + '\'' +
                ", employeeId='" + employeeId + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", empAoi='" + empAoi + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", address='" + address + '\'' +
                ", company='" + company + '\'' +
                ", tracks='" + tracks + '\'' +
                ", standard='" + standard + '\'' +
                ", matchType='" + matchType + '\'' +
                ", currentTm='" + currentTm + '\'' +
                ", incDay='" + incDay + '\'' +
                ", msgTm='" + msgTm + '\'' +
                '}';
    }
}
