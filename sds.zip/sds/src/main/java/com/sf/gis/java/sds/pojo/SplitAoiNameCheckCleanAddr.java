package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SplitAoiNameCheckCleanAddr implements Serializable {
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "new_aoi_id")
    private String new_aoi_id;
    @Column(name = "old_aoi_id")
    private String old_aoi_id;
    @Column(name = "new_aoi_name")
    private String new_aoi_name;
    @Column(name = "old_aoi_name")
    private String old_aoi_name;
    @Column(name = "address")
    private String address;
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "address_new")
    private String address_new;
    @Column(name = "new_name")
    private String new_name;
    @Column(name = "old_name")
    private String old_name;
    @Column(name = "tag")
    private String tag;
    @Column(name = "resp")
    private String resp;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "zc_aoi_name_list")
    private String zc_aoi_name_list;
    @Column(name = "inc_day")
    private String inc_day;

    private int cnt;

    public String getZc_aoi_name_list() {
        return zc_aoi_name_list;
    }

    public void setZc_aoi_name_list(String zc_aoi_name_list) {
        this.zc_aoi_name_list = zc_aoi_name_list;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getNew_name() {
        return new_name;
    }

    public void setNew_name(String new_name) {
        this.new_name = new_name;
    }

    public String getOld_name() {
        return old_name;
    }

    public void setOld_name(String old_name) {
        this.old_name = old_name;
    }

    public String getAddress_new() {
        return address_new;
    }

    public void setAddress_new(String address_new) {
        this.address_new = address_new;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getNew_aoi_name() {
        return new_aoi_name;
    }

    public void setNew_aoi_name(String new_aoi_name) {
        this.new_aoi_name = new_aoi_name;
    }

    public String getOld_aoi_name() {
        return old_aoi_name;
    }

    public void setOld_aoi_name(String old_aoi_name) {
        this.old_aoi_name = old_aoi_name;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getNew_aoi_id() {
        return new_aoi_id;
    }

    public void setNew_aoi_id(String new_aoi_id) {
        this.new_aoi_id = new_aoi_id;
    }

    public String getOld_aoi_id() {
        return old_aoi_id;
    }

    public void setOld_aoi_id(String old_aoi_id) {
        this.old_aoi_id = old_aoi_id;
    }
}
