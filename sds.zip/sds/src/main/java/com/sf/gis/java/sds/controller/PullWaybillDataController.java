package com.sf.gis.java.sds.controller;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.service.PullWaybillDataService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class PullWaybillDataController {
    private static final Logger logger = LoggerFactory.getLogger(PullWaybillDataController.class);
    private PullWaybillDataService pullWaybillService;
    private Map<String, String> configMap;

    public PullWaybillDataController(Map<String, String> configMap) {
        pullWaybillService = new PullWaybillDataService();
        this.configMap = configMap;

    }

    public void start(String argDate, int argDays) throws Exception {
        List<String> date = findDays(configMap);
        if (argDate != null) {
            date = findDays(argDate, argDays);
        }
        logger.error(date.get(0) + "," + date.get(date.size() - 1));
        for (String item : date) {
            List<String> phoneHookDate = DateUtil.getDaysAgoMulti(item, Integer.valueOf(configMap.get(ConfigKey.phone_hook_days.name())), "yyyyMMdd");
            String hookCity = configMap.get(ConfigKey.phone_hook_city.name());
            if (!hookCity.isEmpty()) {
                pullWaybillService.pullPhoneData(configMap, phoneHookDate);
            }
            pullWaybillService.pullDataByDay(configMap, new String[]{item, item});
        }
    }


    private List<String> findDays(String argDate, int argDays) throws ParseException {
        List<String> date = new ArrayList<>();
        for (int i = 0; i < argDays; i++) {
            date.add(DateUtil.getDayBefore(argDate, "yyyyMMdd", 0-i));
        }
        return date;
    }

    /**
     * 获取天数
     *
     * @param configMap
     * @return
     */
    private List<String> findDays(Map<String, String> configMap) {
        int beginDays = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        int days = Integer.valueOf(configMap.get(ConfigKey.days.name()));
        List<String> date = new ArrayList<>();
        for (int i = 1; i <= days; i++) {
            date.add(DateUtil.getCurrentDateBefore("yyyyMMdd", beginDays + i - 1));
        }
        return date;
    }

}
