package com.sf.gis.java.sds.enumtype;

public enum ProjectType {
    zhiyu, //治愈
    duomi //多米
}
