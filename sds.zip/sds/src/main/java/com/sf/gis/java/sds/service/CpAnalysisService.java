package com.sf.gis.java.sds.service;

import com.github.davidmoten.geo.GeoHash;
import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.GeometryUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.CpaSrc;
import com.sf.gis.java.sds.pojo.CpaStat;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 竞品分析服务类
 * @author 01370539 created on Jun.22 2021
 */
public class CpAnalysisService {
    private static final Logger logger = LoggerFactory.getLogger(CpAnalysisService.class);

    /**
     * 获取竞品分析源数据
     * @param ss SparkSession
     * @param jsc JavaSparkContext
     * @param cityCode 城市编码
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @param isFromOrig 是否从原始表取数
     * @return 运单相关数据
     */
    public JavaRDD<CpaSrc> loadSrcData(SparkSession ss, JavaSparkContext jsc, String cityCode, String startDate, String endDate, String isFromOrig){
        String sql;
        if ("true".equalsIgnoreCase(isFromOrig)) {
            sql = SqlUtil.getSqlStr("cpa_src.sql", startDate, endDate, startDate, endDate, startDate, endDate);
            if (StringUtils.isNotEmpty(cityCode)) {
                sql += " where dg.dest_dist_code = '" + cityCode + "'";
            }
            JavaRDD<CpaSrc> rddCpas = DataUtil.loadData(ss, jsc, sql, CpaSrc.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cpa src data count: {}", rddCpas.count());
            JavaRDD<CpaSrc> rddSrc = rddCpas.map(temp -> {
                if (StringUtils.isNotEmpty(temp.getEventLat()) && StringUtils.isNotEmpty(temp.getEventLng())) {
                    String key = GeoHash.encodeHash(Double.parseDouble(temp.getEventLat()), Double.parseDouble(temp.getEventLng()), 7);
                    temp.setHashLatLng(key);
                }
                temp.setUuid(UUID.randomUUID().toString());
                return temp;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_cpa_src", CpaSrc.class, rddSrc, "dest_dist_code");
            return rddSrc;
        } else {
            if (StringUtils.isEmpty(cityCode)) {
                sql = "select uuid,waybill_no,deliver_address,deliver_address_type,signer_namet,order_no,deliver_emp_code,signer_nameg,signin_tm,consignee_comp_name,consignee_addr,aoi_id string,eventtype,eventlat,eventlng,id,hash_lat_lng,inc_day,dest_dist_code from dm_gis.sds_cpa_src where inc_day between '" + startDate + "' and '" + endDate + "'";
            } else {
                sql = "select uuid,waybill_no,deliver_address,deliver_address_type,signer_namet,order_no,deliver_emp_code,signer_nameg,signin_tm,consignee_comp_name,consignee_addr,aoi_id string,eventtype,eventlat,eventlng,id,hash_lat_lng,inc_day,dest_dist_code from dm_gis.sds_cpa_src where dest_dist_code = '" + cityCode + "' and inc_day between '" + startDate + "' and '" + endDate + "'";
            }
            return DataUtil.loadData(ss, jsc, sql, CpaSrc.class);
        }
    }

    /**
     * 竞品原始数据根据坐标hash key分组进行第一步统计
     * @param rddTpNeedCal 根据坐标hash key分组的数据
     * @return 初步统计结果
     */
    public JavaRDD<CpaStat> calDetail(JavaPairRDD<String, Iterable<CpaSrc>> rddTpNeedCal) {
        return rddTpNeedCal.flatMap(tp -> {
            List<CpaStat> resultList = new ArrayList<>();

            Map<String, CpaSrc> idMap = new HashMap<>();
            tp._2.forEach(temp -> idMap.put(temp.getUuid(), temp));
            logger.error("start the first calculation, key - {} have value count - {}", tp._1, idMap.size());

            String start;
            String end;
            int count;
            List<LatLong> llList;
            List<CpaSrc> subList;

            CpaSrc cs;
            CpaSrc subCs;
            LatLong tempLl;

            List<String> idList = new ArrayList<>(idMap.keySet());
            for (String id : idList) {
                cs = idMap.get(id);
                if (cs != null) {
                    llList = new ArrayList<>();
                    subList = new ArrayList<>();

                    start = cs.getIncDay();
                    end = cs.getIncDay();
                    count = 1;
                    llList.add(new LatLong(Double.parseDouble(cs.getEventLat()), Double.parseDouble(cs.getEventLng())));
                    subList.add(cs);

                    for (String subId : idList) {
                        if (!id.equals(subId)) {
                            subCs = idMap.get(subId);
                            if (subCs != null) {
                                tempLl = new LatLong(Double.parseDouble(subCs.getEventLat()), Double.parseDouble(subCs.getEventLng()));
                                if (GeometryUtil.getDistance(llList, tempLl) <= 10) {
                                    start = StringUtils.isEmpty(start) ? subCs.getIncDay() : (start.compareTo(subCs.getIncDay()) > 0 ? subCs.getIncDay() : start);
                                    end = StringUtils.isEmpty(end) ? subCs.getIncDay() : (end.compareTo(subCs.getIncDay()) > 0 ? end : subCs.getIncDay());
                                    count++;
                                    llList.add(tempLl);
                                    subList.add(subCs);
                                    idMap.remove(subId);
                                }
                            }
                        }
                    }
                    resultList.add(getCpaStat(tp._1, id, start, end, count, llList, subList, cs.getDeliverAddress(), cs.getDestDistCode()));
                }
            }
            count = 0;
            for (CpaStat cpaStat : resultList) {
                count += cpaStat.getSubList().size();
                logger.error("just4count of the first calculation, key: {}, count: {}, value: {}", tp._1, count, cpaStat.toString());

            }
            logger.error("after the first calculation, key - {}, the stat count: {}, the detail count: {}", tp._1, resultList.size(), count);
            return resultList.iterator();
        });
    }

    /**
     * 对已经统计过的竞品数据进行最终统计
     * @param rddTpStatNeedCal 初步统计过的统计结果
     * @return 最终统计结果
     */
    public JavaRDD<CpaStat> calStat(JavaPairRDD<String, Iterable<CpaStat>> rddTpStatNeedCal) {
        return rddTpStatNeedCal.flatMap(tp -> {
            List<CpaStat> resultList = new ArrayList<>();

            Map<String, CpaStat> idMap = new HashMap<>();
            int c = 0;
            for (CpaStat cpaStat : tp._2) {
                idMap.put(cpaStat.getId(), cpaStat);
                c += cpaStat.getSubList().size();
            }
            logger.error("start the second calculation, key - {} have value count - {}", tp._1, c);

            String start;
            String end;
            int count;
            List<LatLong> llList;
            List<CpaSrc> subList;

            CpaStat cs;
            CpaStat subCs;

            List<String> idList = new ArrayList<>(idMap.keySet());
            for (String id : idList) {
                logger.error("check id: {}, idMap count: {}", id, idMap.size());
                cs = idMap.get(id);
                if (cs != null) {
                    start = cs.getStartDate();
                    end = cs.getEndDate();
                    count = Integer.parseInt(cs.getCount());
                    llList = new ArrayList<>(cs.getLlList());
                    subList = new ArrayList<>(cs.getSubList());

                    for (String subId : idList) {
                        if (!id.equals(subId)) {
                            subCs = idMap.get(subId);
                            if (subCs != null) {
                                if (GeometryUtil.getDistance(cs.getLlList(), subCs.getLlList()) <= 10) {
                                    start = StringUtils.isEmpty(start) ? subCs.getStartDate() : (start.compareTo(subCs.getStartDate()) > 0 ? subCs.getStartDate() : start);
                                    end = StringUtils.isEmpty(end) ? subCs.getEndDate() : (end.compareTo(subCs.getEndDate()) > 0 ? end : subCs.getEndDate());
                                    count += Integer.parseInt(subCs.getCount());
                                    llList.addAll(subCs.getLlList());
                                    subList.addAll(subCs.getSubList());
                                    idMap.remove(subId);
                                }
                            }
                        }
                    }
                    resultList.add(getCpaStat(tp._1, id, start, end, count, llList, subList, cs.getDeliverAddress(), cs.getDestDistCode()));
                }
            }

            count = 0;
            for (CpaStat cpaStat : resultList) {
                count += cpaStat.getSubList().size();
                logger.error("just4count of the second calculation, key: {}, count: {}, value: {}", tp._1, count, cpaStat.toString());
            }
            logger.error("after the second calculation, key - {}, the stat count: {}, the detail count: {}", tp._1, resultList.size(), count);

            return resultList.iterator();
        });
    }

    private static CpaStat getCpaStat(String key, String id, String start, String end, int count, List<LatLong> llList, List<CpaSrc> subList, String deliverAddress, String destCityCode) {
        CpaStat result = new CpaStat();
        result.setId(id);
        result.setStartDate(start);
        result.setEndDate(end);
        result.setCount(String.valueOf(count));
        result.setLlList(llList);
        result.setSubList(subList);
        result.setDeliverAddress(deliverAddress);
        result.setDestDistCode(destCityCode);
        logger.error("the statistics result of key: {}, id: {} stat result: {}", key, id, result.toString());
        return result;
    }
}
