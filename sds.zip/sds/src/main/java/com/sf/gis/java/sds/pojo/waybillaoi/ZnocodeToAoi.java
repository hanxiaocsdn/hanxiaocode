package com.sf.gis.java.sds.pojo.waybillaoi;



import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ZnocodeToAoi implements Serializable {
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "aoi_id")
    private String aoi_id;

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }
}
