package com.sf.gis.java.sds.service;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.SocketException;

/**
 * Created by 01368078 on 2020/5/12.
 */
public class FtpManager {
	private static Logger logger = LoggerFactory.getLogger(FtpManager.class);
	private static volatile FtpManager instance;
	private FTPClient ftpClient;
	public boolean success;

	private FtpManager(String host, int port, String username, String password) {
		try {
			ftpClient = new FTPClient();
			ftpClient.connect(host, port);// 连接FTP服务器
			ftpClient.login(username, password);// 登陆FTP服务器
			if (!FTPReply.isPositiveCompletion(ftpClient.getReplyCode())) {
				logger.info("未连接到FTP，用户名或密码错误。");
				ftpClient.disconnect();
			} else {
				success = true;
				logger.info("FTP连接成功。");
			}
			ftpClient.setControlEncoding("UTF-8"); // 中文支持
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
		} catch (SocketException e) {
			e.printStackTrace();
			logger.info("FTP的IP地址可能错误，请正确配置。");
		} catch (IOException e) {
			e.printStackTrace();
			logger.info("FTP的端口错误,请正确配置。");
		}
	}

	public static FtpManager getInstance(String host, int port, String username, String password) {
		if (instance == null) {
			synchronized (FtpManager.class) {
				if (instance == null) {
					instance = new FtpManager(host, port, username, password);
				}
			}
		}
		return instance;
	}

	private void upload(String localPath, String ftpDir) throws Exception {
		if (!ftpClient.changeWorkingDirectory(ftpDir)) {
			if (!createMultiDirectory(ftpClient, ftpDir)) {
				throw new Exception("ftp文件夹创建失败");
			}
		}
		ftpClient.changeWorkingDirectory(ftpDir);
		File f = new File(localPath);
		if (f.isDirectory()) {
			File[] flist = f.listFiles();
			for (int i = 0; i < flist.length; i++) {
				InputStream in = new FileInputStream(flist[i]);
				ftpClient.storeFile(flist[i].getName(), in);
				in.close();
			}
		} else {
			InputStream in = new FileInputStream(f);
			ftpClient.storeFile(f.getName(), in);
			in.close();
		}
	}

	public void uploadFile(String localPath, String ftpDir, String ftpFile) throws Exception {
		if (!ftpClient.changeWorkingDirectory(ftpDir)) {
			if (!createMultiDirectory(ftpClient, ftpDir)) {
				throw new Exception("ftp文件夹创建失败");
			}
		}
		ftpClient.changeWorkingDirectory(ftpDir);
		File f = new File(localPath);
		InputStream in = new FileInputStream(f);
		ftpClient.storeFile(ftpFile, in);
		in.close();
	}

	private boolean createMultiDirectory(FTPClient ftpClient, String multiDirectory) {
		boolean bool = false;
		try {
			String[] dirs = multiDirectory.split("/");
			ftpClient.changeWorkingDirectory("/");

			//按顺序检查目录是否存在，不存在则创建目录
			for (int i = 1; i < dirs.length; i++) {
				if (!ftpClient.changeWorkingDirectory(dirs[i])) {
					if (ftpClient.makeDirectory(dirs[i])) {
						if (!ftpClient.changeWorkingDirectory(dirs[i])) {
							return false;
						}
					} else {
						return false;
					}
				}
			}

			bool = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bool;

	}

	public static void main(String[] args) throws Exception {
		FtpManager ftpManager = FtpManager.getInstance("10.116.49.190", 21, "gis", "brYsj2.023ftKjdev");
		String localPath = "D:/工作内容.txt";
		String ftpDir = "/YangYan/流动人口/test";
		String ftpFile = "工作内容.txt";
		ftpManager.uploadFile(
				localPath,
				new String(ftpDir.getBytes("UTF-8"), "iso-8859-1"),
				new String(ftpFile.getBytes("UTF-8"), "iso-8859-1")
		);
	}
}
