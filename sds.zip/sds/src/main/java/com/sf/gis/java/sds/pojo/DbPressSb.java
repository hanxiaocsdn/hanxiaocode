package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DbPressSb implements Serializable {
    @Column(name = "sn")
    private String sn;
    @Column(name = "address")
    private String address;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "city")
    private String city;
    @Column(name = "depponZc")
    private String depponZc;
    @Column(name = "zc")
    private String zc;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "mapa_precision")
    private String mapa_precision;
    @Column(name = "mapa_x")
    private String mapa_x;
    @Column(name = "mapa_y")
    private String mapa_y;
    @Column(name = "mapa_aoi_id")
    private String mapa_aoi_id;
    @Column(name = "mapa_aoi_name")
    private String mapa_aoi_name;
    @Column(name = "ts_precision")
    private String ts_precision;
    @Column(name = "ts_x")
    private String ts_x;
    @Column(name = "ts_y")
    private String ts_y;
    @Column(name = "ts_aoi_id")
    private String ts_aoi_id;
    @Column(name = "ts_aoi_name")
    private String ts_aoi_name;
    @Column(name = "dataSrc")
    private String dataSrc;
    @Column(name = "src")
    private String src;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "standardization")
    private String standardization;
    @Column(name = "keyWord")
    private String keyWord;
    @Column(name = "model_Zc")
    private String model_Zc;
    @Column(name = "ts_xy_Zc")
    private String ts_xy_Zc;
    @Column(name = "mapa_xy_Zc")
    private String mapa_xy_Zc;
    @Column(name = "mapaAoiZc")
    private String mapaAoiZc;
    @Column(name = "tsAoiZc")
    private String tsAoiZc;

    @Column(name = "zc_new")
    private String zc_new;
    @Column(name = "source_new")
    private String source_new;
    @Column(name = "tc_new")
    private String tc_new;
    @Column(name = "keyword_new")
    private String keyword_new;
    @Column(name = "match_new")
    private String match_new;
    @Column(name = "adcode_new")
    private String adcode_new;
    @Column(name = "msg_new")
    private String msg_new;
    @Column(name = "is_modify")
    private String is_modify;
    @Column(name = "mapa_zc")
    private String mapa_zc;
    @Column(name = "mapa_tc")
    private String mapa_tc;
    @Column(name = "ts_zc")
    private String ts_zc;
    @Column(name = "ts_tc")
    private String ts_tc;
    @Column(name = "gj_zc_equal")
    private String gj_zc_equal;
    @Column(name = "tc_chkn")
    private String tc_chkn;
    @Column(name = "model_zc_pro")
    private String model_zc_pro;
    @Column(name = "rds_aoiid")
    private String rds_aoiid;
    @Column(name = "rds_zc")
    private String rds_zc;
    @Column(name = "rds_sign_zc_equal")
    private String rds_sign_zc_equal;
    @Column(name = "press_chkn")
    private String press_chkn;

    @Column(name = "press_msg")
    private String press_msg;
    @Column(name = "effect_msg")
    private String effect_msg;

    @Column(name = "mod_zc_equal")
    private String mod_zc_equal;

    @Column(name = "addr_fra_num")
    private String addr_fra_num;
    @Column(name = "addr_sign_zc_diff")
    private String addr_sign_zc_diff;
    @Column(name = "addr_reg_zc_diff")
    private String addr_reg_zc_diff;
    @Column(name = "is_fra")
    private String is_fra;

    @Column(name = "inc_day")
    private String inc_day;

    private int explicit;
    private String source;
    private int status;

    public String getIs_fra() {
        return is_fra;
    }

    public void setIs_fra(String is_fra) {
        this.is_fra = is_fra;
    }

    public String getAddr_fra_num() {
        return addr_fra_num;
    }

    public void setAddr_fra_num(String addr_fra_num) {
        this.addr_fra_num = addr_fra_num;
    }

    public String getAddr_sign_zc_diff() {
        return addr_sign_zc_diff;
    }

    public void setAddr_sign_zc_diff(String addr_sign_zc_diff) {
        this.addr_sign_zc_diff = addr_sign_zc_diff;
    }

    public String getAddr_reg_zc_diff() {
        return addr_reg_zc_diff;
    }

    public void setAddr_reg_zc_diff(String addr_reg_zc_diff) {
        this.addr_reg_zc_diff = addr_reg_zc_diff;
    }

    public String getMod_zc_equal() {
        return mod_zc_equal;
    }

    public void setMod_zc_equal(String mod_zc_equal) {
        this.mod_zc_equal = mod_zc_equal;
    }

    public String getPress_msg() {
        return press_msg;
    }

    public void setPress_msg(String press_msg) {
        this.press_msg = press_msg;
    }

    public String getEffect_msg() {
        return effect_msg;
    }

    public void setEffect_msg(String effect_msg) {
        this.effect_msg = effect_msg;
    }

    public String getPress_chkn() {
        return press_chkn;
    }

    public void setPress_chkn(String press_chkn) {
        this.press_chkn = press_chkn;
    }

    public String getRds_sign_zc_equal() {
        return rds_sign_zc_equal;
    }

    public void setRds_sign_zc_equal(String rds_sign_zc_equal) {
        this.rds_sign_zc_equal = rds_sign_zc_equal;
    }

    public String getGj_zc_equal() {
        return gj_zc_equal;
    }

    public void setGj_zc_equal(String gj_zc_equal) {
        this.gj_zc_equal = gj_zc_equal;
    }

    public String getIs_modify() {
        return is_modify;
    }

    public void setIs_modify(String is_modify) {
        this.is_modify = is_modify;
    }

    public String getZc_new() {
        return zc_new;
    }

    public void setZc_new(String zc_new) {
        this.zc_new = zc_new;
    }

    public String getSource_new() {
        return source_new;
    }

    public void setSource_new(String source_new) {
        this.source_new = source_new;
    }

    public String getTc_new() {
        return tc_new;
    }

    public void setTc_new(String tc_new) {
        this.tc_new = tc_new;
    }

    public String getKeyword_new() {
        return keyword_new;
    }

    public void setKeyword_new(String keyword_new) {
        this.keyword_new = keyword_new;
    }

    public String getMatch_new() {
        return match_new;
    }

    public void setMatch_new(String match_new) {
        this.match_new = match_new;
    }

    public String getAdcode_new() {
        return adcode_new;
    }

    public void setAdcode_new(String adcode_new) {
        this.adcode_new = adcode_new;
    }

    public String getMsg_new() {
        return msg_new;
    }

    public void setMsg_new(String msg_new) {
        this.msg_new = msg_new;
    }

    public String getRds_zc() {
        return rds_zc;
    }

    public void setRds_zc(String rds_zc) {
        this.rds_zc = rds_zc;
    }

    public String getRds_aoiid() {
        return rds_aoiid;
    }

    public void setRds_aoiid(String rds_aoiid) {
        this.rds_aoiid = rds_aoiid;
    }

    public String getModel_zc_pro() {
        return model_zc_pro;
    }

    public void setModel_zc_pro(String model_zc_pro) {
        this.model_zc_pro = model_zc_pro;
    }

    public String getTc_chkn() {
        return tc_chkn;
    }

    public void setTc_chkn(String tc_chkn) {
        this.tc_chkn = tc_chkn;
    }

    public String getMapa_zc() {
        return mapa_zc;
    }

    public void setMapa_zc(String mapa_zc) {
        this.mapa_zc = mapa_zc;
    }

    public String getMapa_tc() {
        return mapa_tc;
    }

    public void setMapa_tc(String mapa_tc) {
        this.mapa_tc = mapa_tc;
    }

    public String getTs_zc() {
        return ts_zc;
    }

    public void setTs_zc(String ts_zc) {
        this.ts_zc = ts_zc;
    }

    public String getTs_tc() {
        return ts_tc;
    }

    public void setTs_tc(String ts_tc) {
        this.ts_tc = ts_tc;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public int getExplicit() {
        return explicit;
    }

    public void setExplicit(int explicit) {
        this.explicit = explicit;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDepponZc() {
        return depponZc;
    }

    public void setDepponZc(String depponZc) {
        this.depponZc = depponZc;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getMapa_precision() {
        return mapa_precision;
    }

    public void setMapa_precision(String mapa_precision) {
        this.mapa_precision = mapa_precision;
    }

    public String getMapa_x() {
        return mapa_x;
    }

    public void setMapa_x(String mapa_x) {
        this.mapa_x = mapa_x;
    }

    public String getMapa_y() {
        return mapa_y;
    }

    public void setMapa_y(String mapa_y) {
        this.mapa_y = mapa_y;
    }

    public String getMapa_aoi_id() {
        return mapa_aoi_id;
    }

    public void setMapa_aoi_id(String mapa_aoi_id) {
        this.mapa_aoi_id = mapa_aoi_id;
    }

    public String getMapa_aoi_name() {
        return mapa_aoi_name;
    }

    public void setMapa_aoi_name(String mapa_aoi_name) {
        this.mapa_aoi_name = mapa_aoi_name;
    }

    public String getTs_precision() {
        return ts_precision;
    }

    public void setTs_precision(String ts_precision) {
        this.ts_precision = ts_precision;
    }

    public String getTs_x() {
        return ts_x;
    }

    public void setTs_x(String ts_x) {
        this.ts_x = ts_x;
    }

    public String getTs_y() {
        return ts_y;
    }

    public void setTs_y(String ts_y) {
        this.ts_y = ts_y;
    }

    public String getTs_aoi_id() {
        return ts_aoi_id;
    }

    public void setTs_aoi_id(String ts_aoi_id) {
        this.ts_aoi_id = ts_aoi_id;
    }

    public String getTs_aoi_name() {
        return ts_aoi_name;
    }

    public void setTs_aoi_name(String ts_aoi_name) {
        this.ts_aoi_name = ts_aoi_name;
    }

    public String getDataSrc() {
        return dataSrc;
    }

    public void setDataSrc(String dataSrc) {
        this.dataSrc = dataSrc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getStandardization() {
        return standardization;
    }

    public void setStandardization(String standardization) {
        this.standardization = standardization;
    }

    public String getKeyWord() {
        return keyWord;
    }

    public void setKeyWord(String keyWord) {
        this.keyWord = keyWord;
    }

    public String getModel_Zc() {
        return model_Zc;
    }

    public void setModel_Zc(String model_Zc) {
        this.model_Zc = model_Zc;
    }

    public String getTs_xy_Zc() {
        return ts_xy_Zc;
    }

    public void setTs_xy_Zc(String ts_xy_Zc) {
        this.ts_xy_Zc = ts_xy_Zc;
    }

    public String getMapa_xy_Zc() {
        return mapa_xy_Zc;
    }

    public void setMapa_xy_Zc(String mapa_xy_Zc) {
        this.mapa_xy_Zc = mapa_xy_Zc;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getMapaAoiZc() {
        return mapaAoiZc;
    }

    public void setMapaAoiZc(String mapaAoiZc) {
        this.mapaAoiZc = mapaAoiZc;
    }

    public String getTsAoiZc() {
        return tsAoiZc;
    }

    public void setTsAoiZc(String tsAoiZc) {
        this.tsAoiZc = tsAoiZc;
    }
}
