package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BuildingIdentifyAoiRecWrong implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "address")
    private String address;
    @Column(name = "split")
    private String split;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "x_80")
    private String x_80;
    @Column(name = "y_80")
    private String y_80;
    @Column(name = "group_address")
    private String group_address;
    @Column(name = "group_address_split")
    private String group_address_split;
    @Column(name = "gdps_response")
    private String gdps_response;
    @Column(name = "gd2_response")
    private String gd2_response;
    @Column(name = "bd2_response")
    private String bd2_response;
    @Column(name = "rh1_response")
    private String rh1_response;
    @Column(name = "bs_response")
    private String bs_response;
    @Column(name = "pass_aoi1")
    private String pass_aoi1;
    @Column(name = "pass_aoi2")
    private String pass_aoi2;
    @Column(name = "correct_aoi")
    private String correct_aoi;
    @Column(name = "correct_bld")
    private String correct_bld;
    @Column(name = "inc_day")
    private String inc_day;

    private String tag;
    private String name;
    private String num;
    private String eng;
    private String ch;
    private Aoi aoi;

    public String getGroup_address() {
        return group_address;
    }

    public void setGroup_address(String group_address) {
        this.group_address = group_address;
    }

    public String getGroup_address_split() {
        return group_address_split;
    }

    public void setGroup_address_split(String group_address_split) {
        this.group_address_split = group_address_split;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getX_80() {
        return x_80;
    }

    public void setX_80(String x_80) {
        this.x_80 = x_80;
    }

    public String getY_80() {
        return y_80;
    }

    public void setY_80(String y_80) {
        this.y_80 = y_80;
    }

    public String getGdps_response() {
        return gdps_response;
    }

    public void setGdps_response(String gdps_response) {
        this.gdps_response = gdps_response;
    }

    public String getGd2_response() {
        return gd2_response;
    }

    public void setGd2_response(String gd2_response) {
        this.gd2_response = gd2_response;
    }

    public String getBd2_response() {
        return bd2_response;
    }

    public void setBd2_response(String bd2_response) {
        this.bd2_response = bd2_response;
    }

    public String getRh1_response() {
        return rh1_response;
    }

    public void setRh1_response(String rh1_response) {
        this.rh1_response = rh1_response;
    }

    public String getBs_response() {
        return bs_response;
    }

    public void setBs_response(String bs_response) {
        this.bs_response = bs_response;
    }

    public String getPass_aoi1() {
        return pass_aoi1;
    }

    public void setPass_aoi1(String pass_aoi1) {
        this.pass_aoi1 = pass_aoi1;
    }

    public String getPass_aoi2() {
        return pass_aoi2;
    }

    public void setPass_aoi2(String pass_aoi2) {
        this.pass_aoi2 = pass_aoi2;
    }

    public String getCorrect_aoi() {
        return correct_aoi;
    }

    public void setCorrect_aoi(String correct_aoi) {
        this.correct_aoi = correct_aoi;
    }

    public String getCorrect_bld() {
        return correct_bld;
    }

    public void setCorrect_bld(String correct_bld) {
        this.correct_bld = correct_bld;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getEng() {
        return eng;
    }

    public void setEng(String eng) {
        this.eng = eng;
    }

    public String getCh() {
        return ch;
    }

    public void setCh(String ch) {
        this.ch = ch;
    }

    public Aoi getAoi() {
        return aoi;
    }

    public void setAoi(Aoi aoi) {
        this.aoi = aoi;
    }
}
