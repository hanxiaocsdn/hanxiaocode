package com.sf.gis.java.sds.utils;

import java.nio.charset.Charset;
import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class BackAES
{
    //private static String ivParameter = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    private static String ivParameter = "ABCDEF0123456789";
    //private static String ivParameter = "PVO7@NQNHHDcXX^1";

    private static String WAYS = "AES";
    private static String MODE = "";
    private static boolean isPwd = false;
    private static String ModeCode = "PKCS5Padding";
    private static int type = 0;

    private static int pwdLenght = 16;
    private static String val = "0";

    public static String selectMod(int type)
    {
        // ECB("ECB", "0"), CBC("CBC", "1"), CFB("CFB", "2"), OFB("OFB", "3");
        switch (type)
        {
            case 0:
                isPwd = false;
                MODE = WAYS + "/" + AESType.ECB.key() + "/" + ModeCode;

                break;
            case 1:
                isPwd = true;
                MODE = WAYS + "/" + AESType.CBC.key() + "/" + ModeCode;
                break;
            case 2:
                isPwd = true;
                MODE = WAYS + "/" + AESType.CFB.key() + "/" + ModeCode;
                break;
            case 3:
                isPwd = true;
                MODE = WAYS + "/" + AESType.OFB.key() + "/" + ModeCode;
                break;
            case 4:
                isPwd = true;
                MODE = WAYS + "/" + AESType.CTR.key() + "/" + ModeCode;
                break;
            case 5:
                isPwd = true;
                MODE = WAYS + "/" + AESType.PCBC.key() + "/" + ModeCode;
                break;
        }

        return MODE;

    }

    public static byte[] encrypt(String sSrc, String sKey, int type) throws Exception
    {
        sKey = toMakekey(sKey, pwdLenght, val);
        Cipher cipher = Cipher.getInstance(selectMod(type));
        byte[] raw = sKey.getBytes();
        SecretKeySpec skeySpec = new SecretKeySpec(raw, WAYS);

        IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
        if (isPwd == false)
        {
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        }
        else
        {
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
        }

        byte[] encrypted = cipher.doFinal(sSrc.getBytes("utf-8"));
        return Base64Coder.encode(encrypted).getBytes();// �˴�ʹ��BASE64��ת�롣
    }

     public static String decrypt(String sSrc, String sKey, int type)
    {
        sKey = toMakekey(sKey, pwdLenght, val);
        try
        {
            byte[] raw = sKey.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, WAYS);
            Cipher cipher = Cipher.getInstance(selectMod(type));
            IvParameterSpec iv = new IvParameterSpec(ivParameter.getBytes());
            if (isPwd == false)
            {
            	cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            }
            else
            {
                cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            }
            byte[] encrypted1 = Base64Coder.decode(sSrc);
            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original, "utf-8");
            return originalString;
        }
        catch (Exception ex)
        {
            return null;
        }
    }

    // key
    public static String toMakekey(String str, int strLength, String val)
    {

        int strLen = str.length();
        if (strLen < strLength)
        {
            while (strLen < strLength)
            {
                StringBuffer buffer = new StringBuffer();
                buffer.append(str).append(val);
                str = buffer.toString();
                strLen = str.length();
            }
        }
        return str;
    }

    public static byte[] newencrypt(String content, String password)
    {
        try
        {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(password.getBytes());
            kgen.init(128, secureRandom);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
            Cipher cipher = Cipher.getInstance("AES");// ����AES���ܱ�����
            byte[] byteContent = content.getBytes("UTF-8");
            cipher.init(Cipher.ENCRYPT_MODE, key);// ��ʼ��AES����
            byte[] result = cipher.doFinal(byteContent);
            return result; // AES���ܽ��
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

     public static byte[] newdecrypt(byte[] content, String password)
    {
        try
        {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
            secureRandom.setSeed(password.getBytes());
            kgen.init(128, secureRandom);
            SecretKey secretKey = kgen.generateKey();
            byte[] enCodeFormat = secretKey.getEncoded();
            SecretKeySpec key = new SecretKeySpec(enCodeFormat, "AES");
            Cipher cipher = Cipher.getInstance("AES");// ����AES���ܱ�����
            cipher.init(Cipher.DECRYPT_MODE, key);// ��ʼ��AES����
            byte[] result = cipher.doFinal(content);
            return result; // �õ�AES���ܽ��
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    public static String parseByte2HexStr(byte buf[])
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < buf.length; i++)
        {
            String hex = Integer.toHexString(buf[i] & 0xFF);
            if (hex.length() == 1)
            {
                hex = '0' + hex;
            }
            sb.append(hex.toUpperCase());
        }
        return sb.toString();
    }

    public static byte[] parseHexStr2Byte(String hexStr)
    {
        if (hexStr.length() < 1)
            return null;
        byte[] result = new byte[hexStr.length() / 2];
        for (int i = 0; i < hexStr.length() / 2; i++)
        {
            int high = Integer.parseInt(hexStr.substring(i * 2, i * 2 + 1), 16);
            int low = Integer.parseInt(hexStr.substring(i * 2 + 1, i * 2 + 2), 16);
            result[i] = (byte) (high * 16 + low);
        }
        return result;
    }

    public static String encode(String src,String key){
        return BackAES.parseByte2HexStr(BackAES.newencrypt(src,key));
    }
    public static String decode(String src,String key){
        return new String(BackAES.newdecrypt(BackAES.parseHexStr2Byte(src),key));
    }

    public static void main(String[] args) throws Exception{
		//String s = "mk+fCuFc4yBCvyrdxj4BLNhzMPE7YLpwQh6LPGSWOU+4mXJ6/XQfH6hV1ddoRsIWnSSSwuZLltBeijrFSHfNcEKgm1J8IwicYIUD414LCpbtobankXhoYf1gkPOJkZClPEnmcW3XC/ydbln4AzZHvVsAjuxP11s4cdMLWCGzbAUQxnc60b0sVUcdKNiYv9Vk";
		//byte[] b = s.getBytes();
		//s = new String(Base64Coder.decode(s), Charset.forName("UTF-8"));


		String skey = "Q1Z@3)!(&%*$#@?J";

        System.out.println("skey："+skey);

		String txt = "丰图科技(深圳)有限公司";

		for (int i=0;i<6;i++){
            byte[] s = BackAES.encrypt(txt, skey,i);
            String enc = BackAES.encode(txt,skey);
            System.out.println(i+" 编码结果："+new String(s));
            System.out.println(i+" 加密结果："+enc);

            String t = BackAES.decrypt(new String(s), skey,i);
            String dec = BackAES.decode(enc,skey);
            System.out.println(i+" 解码结果："+t);
            System.out.println(i+" 解密结果："+dec);
        }
	}
}
