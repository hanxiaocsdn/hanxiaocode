package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.DruidManager;
import com.sf.gis.java.sds.db.GislgDbManager;
import com.sf.gis.java.sds.pojo.AddressOrder;
import com.sf.gis.java.sds.service.impl.IOrderMapService;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;


public class OrderMapService extends BaseService implements IOrderMapService {
    private static final Logger logger = LoggerFactory.getLogger(OrderMapService.class);

    public final static String TABLE_NAME = "sss_gis_diff_address_order";

    private final String[] columns = {"id", "unique_md5", "address_src_md5", "address", "origin_src", "data_time", "waybillNo", "city_code"};

    DruidManager druidManager;

    public OrderMapService() {
        druidManager = GislgDbManager.getInstance().getDruidManager();
    }

    @Override
    public void createTable() {
        StringBuilder sb = new StringBuilder("create table IF NOT EXISTS " + TABLE_NAME + "(");
        for (String column : columns) {
            if (column.equals("address")) {
                sb.append(column + " text  ,");
            } else {
                sb.append(column + " VARCHAR(50)  ,");
            }
        }
        sb.append("CREATE_TIME  timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ,");
        sb.append("UPDATE_TIME  timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP ,");
        sb.append(" PRIMARY KEY ( id ), unique INDEX unique_md5(unique_md5 ,city_code),"
                + "INDEX address_src_md5(address_src_md5) ");
        sb.append(")ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        logger.error(sb.toString());
        druidManager.update(sb.toString());
    }

    @Override
    public void insert(List<AddressOrder> list) throws Exception {
        druidManager.excuBatch(list, 5000, new com.sf.gis.java.sds.db.DruidManager.ExcuBatchListener() {
            @Override
            public String createSql() {
                StringBuilder sb = new StringBuilder();
                String insertSql = druidManager.crateIgnoreInsertSqlWithOutValue(columns, TABLE_NAME);
                sb.append(insertSql);
                return sb.toString();
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);
                for (int i = 0; i < columns.length; i++) {
                    stmt.setString(i + 1, (String) map.get(columns[i]));
                }
            }
        });
    }

}
