package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TaskAoiid implements Serializable {
    @Column(name = "address")
    private String address;
    @Column(name = "check_aoi_id")
    private String check_aoi_id;
    @Column(name = "check_dept_code")
    private String check_dept_code;

    public String getCheck_dept_code() {
        return check_dept_code;
    }

    public void setCheck_dept_code(String check_dept_code) {
        this.check_dept_code = check_dept_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCheck_aoi_id() {
        return check_aoi_id;
    }

    public void setCheck_aoi_id(String check_aoi_id) {
        this.check_aoi_id = check_aoi_id;
    }
}
