package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class DeptCodePreWeather implements Serializable {
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "area_name")
    private String area_name;
    @Column(name = "dist_code")
    private String dist_code;
    @Column(name = "city_name")
    private String city_name;
    @Column(name = "dept_type_code")
    private String dept_type_code;
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "dept_name")
    private String dept_name;
    @Column(name = "dept_longitude")
    private String longitude;
    @Column(name = "dept_latitude")
    private String latitude;
    @Column(name = "resp")
    private String resp;
    @Column(name = "s_observe_time")
    private String weather_start_time;
    @Column(name = "e_observe_time")
    private String weather_end_time;
    @Column(name = "observed_time")
    private String observed_time;
    @Column(name = "type")
    private String type;
    @Column(name = "description")
    private String description;
    @Column(name = "level")
    private String level;
    @Column(name = "value")
    private String value;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "hour")
    private String hour;

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getWeather_start_time() {
        return weather_start_time;
    }

    public void setWeather_start_time(String weather_start_time) {
        this.weather_start_time = weather_start_time;
    }

    public String getWeather_end_time() {
        return weather_end_time;
    }

    public void setWeather_end_time(String weather_end_time) {
        this.weather_end_time = weather_end_time;
    }

    public String getObserved_time() {
        return observed_time;
    }

    public void setObserved_time(String observed_time) {
        this.observed_time = observed_time;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getArea_name() {
        return area_name;
    }

    public void setArea_name(String area_name) {
        this.area_name = area_name;
    }

    public String getDist_code() {
        return dist_code;
    }

    public void setDist_code(String dist_code) {
        this.dist_code = dist_code;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getDept_type_code() {
        return dept_type_code;
    }

    public void setDept_type_code(String dept_type_code) {
        this.dept_type_code = dept_type_code;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getDept_name() {
        return dept_name;
    }

    public void setDept_name(String dept_name) {
        this.dept_name = dept_name;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
