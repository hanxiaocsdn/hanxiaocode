package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class EmapLayerFeatureCmsemap implements Serializable {
    @Column(name = "code")
    private String code;
    @Column(name = "lng")
    private String lng;
    @Column(name = "lat")
    private String lat;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }
}
