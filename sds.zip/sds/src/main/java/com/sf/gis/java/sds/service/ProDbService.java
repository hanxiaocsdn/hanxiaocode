package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.ProDbManager;
import com.sf.gis.java.sds.enumtype.AoiRecordType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ProDbService extends BaseService {
    private static final Logger logger = LoggerFactory.getLogger(ProDbService.class);

    // 治愈记录
    private static String TABLE_RECORD = "aoi_zhiyu_record";

    public ProDbService() {
        super(ProDbManager.getInstance());
    }

    public String findWaybillAoiToHiveRecordFileName(String aoiOrderTask, String flag) {
        String sql = "select name from waybill_aoi_to_hive_record where state = 0 and " + "name like '%_" + aoiOrderTask
                + "' and flag='" + flag + "' limit 1";
        return ProDbManager.getInstance().getString(sql);
    }

    // public String findWaybillAoiToHiveRecordFileNameMax() {
    // String sql = "select name from waybill_aoi_to_hive_record where state = 0
    // and name like '%_A' order by id limit 1";
    // return ProDbManager.getInstance().getString(sql);
    // }

    public void deleteWaybillAoiToHiveRecordFileName(String fileName) {
        String sql = "update waybill_aoi_to_hive_record set state = 1 where state = 0 and name='" + fileName + "' ";
        ProDbManager.getInstance().update(sql);
    }

    /**
     * 插入记录
     *
     * @param change
     * @param collect
     * @param collect2
     * @param changeCount
     * @param string
     * @param object
     */
    public void insertIntoAoiRecord(AoiRecordType change, String dept, String city, long changeCount,
                                    String beginDate, String endDate, String mapType, String project) {
        String sql = "insert ignore into " + TABLE_RECORD + "(type,dept,city,count,begin_time,end_time,map_type,project) "
                + " values('" + change.name() + "','" + dept + "','" + city + "'," + changeCount + ",'" + beginDate
                + "','" + endDate + "','" + mapType + "','" + project + "') ";
        logger.error(sql);
        ProDbManager.getInstance().update(sql);
    }

    /**
     * 插入记录
     *
     * @param change
     * @param collect
     * @param collect2
     * @param changeCount
     * @param string
     * @param object
     */
    public void insertIntoAoiRecordOfAdd(AoiRecordType change, String dept, String city, long count,
                                         String beginDate, String endDate, String mapType, String project) {
        String sql = "insert into " + TABLE_RECORD + "(type,dept,city,count,begin_time,end_time,map_type,project) "
                + " values('" + change.name() + "','" + dept + "','" + city + "'," + count + ",'" + beginDate
                + "','" + endDate + "','" + mapType + "','" + project + "') on duplicate key update count=" + count;
        logger.error(sql);
        ProDbManager.getInstance().update(sql);
    }
}
