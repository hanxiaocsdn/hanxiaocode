package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.OperationPlatformMisJudgmentController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:
 */
public class AppOperationPlatformMisJudgment {
    private static Logger logger = LoggerFactory.getLogger(AppOperationPlatformMisJudgment.class);

    public static void main(String[] args) {
        String beforeDate = args[0];
        String date = args[1];
        String sdate = args[2];
        String edate = args[3];
        logger.error("beforeSate:{}, date:{}, sdate:{}, edate:{}", beforeDate, date, sdate, edate);
        logger.error("run start");
        new OperationPlatformMisJudgmentController().start(beforeDate, date, sdate, edate);
        logger.error("run end");
    }
}
