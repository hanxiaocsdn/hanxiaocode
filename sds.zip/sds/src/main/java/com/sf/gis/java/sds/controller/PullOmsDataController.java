package com.sf.gis.java.sds.controller;


import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.service.PullOmsService;

import java.util.Map;

public class PullOmsDataController {
    private PullOmsService pullOmsService;
    private Map<String, String> configMap;

    public PullOmsDataController(Map<String, String> configMap) {
        pullOmsService = new PullOmsService();
        this.configMap = configMap;
    }

    public void start() {
        int commonDayAgo = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        int bigCityDayAgo = Integer.valueOf(configMap.get(ConfigKey.bigCityDayAgo.name()));
        int smallCityDayAgo = Integer.valueOf(configMap.get(ConfigKey.smallCityDayAgo.name()));
        pullOmsService.pullData(commonDayAgo, bigCityDayAgo, smallCityDayAgo, configMap);
    }

    public void startDownloadAoiEmpty() {
        int commonDayAgo = Integer.valueOf(configMap.get(ConfigKey.commonDayAgo.name()));
        pullOmsService.pullAoiEmptyData(commonDayAgo, configMap);
    }

}
