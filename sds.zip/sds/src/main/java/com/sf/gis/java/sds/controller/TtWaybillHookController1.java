package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.waybillaoi.*;
import com.sf.gis.java.sds.service.TtOrderWaybillService;
import com.sf.shiva.oms.csm.utils.NsCfgUtils;
import com.sf.shiva.oms.csm.utils.WaybillNoExtendUtils;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class TtWaybillHookController1 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(TtWaybillHookController1.class);
    private static String ats = "http://gis-int.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&province=%s&cityName=%s&district=%s&city=%s&tel=%s&mobile=%s&company=%s&ak=d54e00e389524aa1a2e73946dc323b2a&opt=zh&callDispatch=1&isNotUnderCall=%s&contacts=&customerAccount=%s";
    private static String ks = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam";
    private static String getAoiByXy = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/coord";
    private static String similarityUrl = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=d54e00e389524aa1a2e73946dc323b2a&beforeAddress=%s&afterAddress=%s";
    TtOrderWaybillService service = new TtOrderWaybillService();

    public void start(String date, String citycode) {
        //初始化spark
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());

        JavaRDD<AoiValue> aoiValueRdd = service.loadAoiValue(sparkInfo, "202203", "0", "755Y").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiValueRdd cnt:{}", aoiValueRdd.count());

        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        if (StringUtils.isNotEmpty(citycode)) {
            String[] citycodes = citycode.split(",");
            for (String city : citycodes) {
                logger.error("city:{}", city);
                String date2 = date.substring(0, 4) + "-" + date.substring(4, 6) + "-" + date.substring(6, 8);
                logger.error("date2:{}", date2);
                JavaRDD<TtEdcsWaybillContentSws> ttEdcsWaybillContentSwsRdd = service.loadTtEdcsWaybillContentSwsData(sparkInfo, date, date2, city, "2").persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttEdcsWaybillContentSwsRdd cnt:{}", ttEdcsWaybillContentSwsRdd.count());

                logger.error("判断是否为签回单");
                List<NsCfgDto> nsCfgList = TtOrderWaybillService.getNsCfgList();
                logger.error("nsCfgList size:{}", nsCfgList.size());
                Broadcast<List<NsCfgDto>> nsCfgListBc = sparkInfo.getContext().broadcast(nsCfgList);
//                boolean cacheFlag = NsCfgUtils.cache(nsCfgList);
//                logger.error("缓存返回标志:{}", cacheFlag);
                JavaRDD<TtEdcsWaybillContentSws> signReceiptRdd = ttEdcsWaybillContentSwsRdd.map(o -> {
                    boolean cacheFlag = NsCfgUtils.cache(nsCfgListBc.value());
                    logger.error("缓存返回标志:{}", cacheFlag);
                    String waybill_no = o.getWaybill_no();
                    boolean signReceipt = WaybillNoExtendUtils.isSignReceipt(waybill_no);
                    o.setSignReceipt(signReceipt);
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("signReceiptRdd cnt:{}", signReceiptRdd.count());
                ttEdcsWaybillContentSwsRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> yesSignReceiptRdd = signReceiptRdd.filter(o -> o.isSignReceipt()).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> noSignReceiptRdd = signReceiptRdd.filter(o -> !o.isSignReceipt()).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("yesSignReceiptRdd cnt:{}", yesSignReceiptRdd.count());
                logger.error("noSignReceiptRdd cnt:{}", noSignReceiptRdd.count());
                signReceiptRdd.unpersist();

                JavaRDD<TtWaybillInfo> ttWaybillInfoRdd = service.loadTtWaybillInfoData(sparkInfo, date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttWaybillInfoRdd cnt:{}", ttWaybillInfoRdd.count());

                JavaRDD<TtEdcsWaybillContentSws> sourceWaybillNoRdd = yesSignReceiptRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                        .leftOuterJoin(ttWaybillInfoRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                TtWaybillInfo ttWaybillInfo = tp._2._2.get();
                                o.setOrder_no(ttWaybillInfo.getOrder_no());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("sourceWaybillNoRdd cnt:{}", sourceWaybillNoRdd.count());
                yesSignReceiptRdd.unpersist();
                ttWaybillInfoRdd.unpersist();

                String before10Date = DateUtil.getDaysBefore(date, 10);
                logger.error("before10Date:{}", before10Date);
                JavaRDD<RdsOmsfromAoi> rdsOmsfromAoiRdd = service.loadRdsOmsfromAoiOrderData(sparkInfo, before10Date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmsfromAoiRdd cnt:{}", rdsOmsfromAoiRdd.count());

                JavaRDD<RdsOmsfromAoi> rdsOmsfromAoiSupAoiRdd = rdsOmsfromAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoicode(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)))
                        .map(tp -> {
                            RdsOmsfromAoi o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                o.setAoiid(cmsAoiSch.getAoi_id());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmsfromAoiSupAoiRdd cnt:{}", rdsOmsfromAoiSupAoiRdd.count());
                rdsOmsfromAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> ttEdcsWaybillContentSwsSupAoiRdd = sourceWaybillNoRdd.mapToPair(o -> new Tuple2<>(o.getOrder_no(), o))
                        .leftOuterJoin(rdsOmsfromAoiSupAoiRdd.mapToPair(o -> new Tuple2<>(o.getOrderno(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                RdsOmsfromAoi rdsOmsfromAoi = tp._2._2.get();
                                o.setAddresseeaoicode(rdsOmsfromAoi.getAoicode());
                                o.setAddresseedeptcode(rdsOmsfromAoi.getDeptcode());
                                o.setAddresseeaoiid(rdsOmsfromAoi.getAoiid());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttEdcsWaybillContentSwsSupAoiRdd cnt:{}", ttEdcsWaybillContentSwsSupAoiRdd.count());
                sourceWaybillNoRdd.unpersist();
                rdsOmsfromAoiSupAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> aoi_id_source_waybillRdd = ttEdcsWaybillContentSwsSupAoiRdd.map(o -> {
                    String addresseedeptcode = o.getAddresseedeptcode();
                    String original_zone_code = o.getDestination_zone_code();
                    if (StringUtils.isNotEmpty(addresseedeptcode) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(addresseedeptcode, original_zone_code)) {
                        String addresseeaoiid = o.getAddresseeaoiid();
                        if (StringUtils.isNotEmpty(addresseeaoiid)) {
                            o.setLastAoiid(addresseeaoiid);
                            o.setTag("aoi_id_source_waybill");
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoi_id_source_waybillRdd cnt:{}", aoi_id_source_waybillRdd.count());
                ttEdcsWaybillContentSwsSupAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> aoi_id_source_waybill_no_emp_last_aoi_Rdd = aoi_id_source_waybillRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> aoi_id_source_waybill_emp_last_aoi_Rdd = aoi_id_source_waybillRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoi_id_source_waybill_no_emp_last_aoi_Rdd cnt:{}", aoi_id_source_waybill_no_emp_last_aoi_Rdd.count());
                logger.error("aoi_id_source_waybill_emp_last_aoi_Rdd cnt:{}", aoi_id_source_waybill_emp_last_aoi_Rdd.count());
                aoi_id_source_waybillRdd.unpersist();

                String before5Date = DateUtil.getDaysBefore(date, 5);
                logger.error("before5Date:{}", before5Date);

                JavaRDD<TtEdcsWaybillContentSws> nextRdd = noSignReceiptRdd.union(aoi_id_source_waybill_emp_last_aoi_Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("nextRdd cnt:{}", nextRdd.count());
                noSignReceiptRdd.unpersist();
                aoi_id_source_waybill_emp_last_aoi_Rdd.unpersist();

                JavaRDD<AddressInfoMapDi> addressInfoMapDiRdd = service.loadAddressInfoMapDiData(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("addressInfoMapDiRdd cnt:{}", addressInfoMapDiRdd.count());

                JavaRDD<TtWaybillInfo> waybillInfo2Rdd = service.loadTtWaybillInfoData3(sparkInfo, before5Date, date)
                        .mapToPair(o -> new Tuple2<>(o.getDest_dist_code(), o))
                        .leftOuterJoin(addressInfoMapDiRdd.mapToPair(o -> new Tuple2<>(o.getCitycode(), o)).reduceByKey((o1, o2) -> o1)).
                                map(tp -> {
                                    TtWaybillInfo o = tp._2._1;
                                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                                        AddressInfoMapDi addressInfoMapDi = tp._2._2.get();
                                        o.setDest_city_code(addressInfoMapDi.getCity());
                                    }
                                    return o;
                                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("waybillInfo2Rdd cnt:{}", waybillInfo2Rdd.count());
                addressInfoMapDiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> atEmpAoiAddrRdd = nextRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).repartition(1000)
                        .leftOuterJoin(waybillInfo2Rdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                TtWaybillInfo ttWaybillInfo = tp._2._2.get();

                                o.setAddresseeaddr(ttWaybillInfo.getConsignee_addr());
                                o.setReceivercity(ttWaybillInfo.getDest_city_code());
                                o.setAddresseecitycode(ttWaybillInfo.getDest_dist_code());
                                o.setReceiverarea(ttWaybillInfo.getDest_county());
                                o.setAddresseecompname(ttWaybillInfo.getConsignee_comp_name());
                                o.setAddresseemobile(ttWaybillInfo.getConsignee_mobile());
                                o.setAddresseephone(ttWaybillInfo.getConsignee_phone());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("atEmpAoiAddrRdd cnt:{}", atEmpAoiAddrRdd.count());
                nextRdd.unpersist();
                waybillInfo2Rdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> atEmpAoiAddrAoiRdd = atEmpAoiAddrRdd.map(o -> {
                    String address = o.getAddresseeaddr();
                    String code = o.getAddresseecitycode();
                    String province = "";
                    String cityName = o.getReceivercity();
                    String district = o.getReceiverarea();
                    String mobile = o.getAddresseemobile();
                    String phone = o.getAddresseephone();
                    String company = o.getAddresseecompname();
                    String isnotundercall = o.getIsnotundercall();
                    String customeraccount = o.getCustomeraccount();
                    String last_aoi = "";
                    if (StringUtils.isNotEmpty(address)) {
                        String req = String.format(ats, URLEncoder.encode(address, "UTF-8"), province, cityName, district, code, phone, mobile, company, isnotundercall, customeraccount);
                        String content = HttpInvokeUtil.sendGet(req);
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                JSONObject result = jsonObject.getJSONObject("result");
                                if (result != null) {
                                    JSONArray tcs = result.getJSONArray("tcs");
                                    if (tcs != null && tcs.size() > 0) {
                                        JSONObject jsonObject1 = tcs.getJSONObject(0);
                                        if (jsonObject1 != null) {
                                            last_aoi = jsonObject1.getString("aoiid");
                                        }
                                    }
                                }
                            }
                        }

                        if (StringUtils.isEmpty(last_aoi)) {
                            JSONObject param = new JSONObject();
                            param.put("ak", "d54e00e389524aa1a2e73946dc323b2a");
                            param.put("address", address);
                            param.put("dept", o.getDestination_zone_code());
                            param.put("city", code);

//                            param.put("province", o.getProvince());
                            param.put("cityName", cityName);
                            param.put("company", company);
                            param.put("mobile", mobile);
                            param.put("tel", phone);

                            String content1 = HttpInvokeUtil.sendPost(ks, param.toJSONString());
                            if (StringUtils.isNotEmpty(content1)) {
                                JSONObject jsonObject = JSON.parseObject(content1);
                                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                    JSONObject result = jsonObject.getJSONObject("result");
                                    if (result != null) {
                                        last_aoi = result.getString("aoi");
                                    }
                                }
                            }
                        }
                    }
                    if (StringUtils.isNotEmpty(last_aoi)) {
                        o.setLastAoiid(last_aoi);
                        o.setTag("aoi_id_tc");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("atEmpAoiAddrAoiRdd cnt:{}", atEmpAoiAddrAoiRdd.count());
                atEmpAoiAddrRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> atEmpAoiAddrNoEmpAoiRdd = atEmpAoiAddrAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> atEmpAoiAddrEmpAoiRdd = atEmpAoiAddrAoiRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("atEmpAoiAddrNoEmpAoiRdd cnt:{}", atEmpAoiAddrNoEmpAoiRdd.count());
                logger.error("atEmpAoiAddrEmpAoiRdd cnt:{}", atEmpAoiAddrEmpAoiRdd.count());
                atEmpAoiAddrAoiRdd.unpersist();

                JavaRDD<ScheduleWidthData> scheduleWidthDataRdd = service.loadScheduleWidthData(sparkInfo, date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("scheduleWidthDataRdd cnt:{}", scheduleWidthDataRdd.count());

                String before30Date = DateUtil.getDaysBefore(date, 30);
                logger.error("before30Date:{}", before30Date);
                JavaRDD<AoiStatAoiid> aoiStatAoiidRdd = service.loadAoiStatAoiid(sparkInfo, before30Date, date)
                        .mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .groupByKey()
                        .map(tp -> {
                            List<AoiStatAoiid> list = Lists.newArrayList(tp._2);
                            AoiStatAoiid aoiStatAoiid = list.get(0);
                            int sum = list.stream().filter(o -> StringUtils.isNotEmpty(o.getCount())).map(o -> Integer.valueOf(o.getCount())).reduce((o1, o2) -> o1 + o2).orElse(0);
                            aoiStatAoiid.setCount(sum + "");
                            return aoiStatAoiid;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiStatAoiidRdd cnt:{}", aoiStatAoiidRdd.count());

                JavaRDD<ScheduleWidthData> scheduleWidthDataAoiNameRdd = scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            ScheduleWidthData o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                o.setAoi_name(cmsAoiSch.getAoi_name());
                            }
                            return o;
                        }).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(aoiValueRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey())
                        .map(tp -> {
                            ScheduleWidthData o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                List<AoiValue> list = Lists.newArrayList(tp._2._2.get());
                                List<AoiValue> collect1 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "1")).collect(Collectors.toList());
                                List<AoiValue> collect2 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "0")).collect(Collectors.toList());
                                if (collect1.size() > 0) {
                                    o.setQd_jiti(collect1.get(0).getWage_level());
                                }
                                if (collect2.size() > 0) {
                                    o.setSp_jiti(collect2.get(0).getWage_level());
                                }
                            }
                            return o;
                        }).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(aoiStatAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            ScheduleWidthData o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                AoiStatAoiid aoiStatAoiid = tp._2._2.get();
                                String count = aoiStatAoiid.getCount();
                                o.setAoi_count(count);
                            }
                            return o;
                        })
                        .persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("scheduleWidthDataAoiNameRdd cnt:{}", scheduleWidthDataAoiNameRdd.count());
                scheduleWidthDataRdd.unpersist();

                JavaRDD<ScheduleWidthData> aoiCntRdd = scheduleWidthDataAoiNameRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o))
                        .groupByKey()
                        .map(tp -> {
                            List<ScheduleWidthData> list = Lists.newArrayList(tp._2);
                            ScheduleWidthData scheduleWidthData = list.get(0);

                            int size = list.stream()
                                    .map(o -> o.getAoi_id())
                                    .filter(o -> StringUtils.isNotEmpty(o))
                                    .distinct()
                                    .collect(Collectors.toList())
                                    .size();
                            if (size >= 1) {
                                ArrayList<CmsAoiSch> aoiList = list.stream()
                                        .filter(o -> StringUtils.isNotEmpty(o.getAoi_id()))
                                        .map(o -> {
                                            CmsAoiSch cmsAoiSch = new CmsAoiSch();
                                            String dept_code = o.getDept_code();
                                            String aoi_id = o.getAoi_id();
                                            String aoi_name = o.getAoi_name();
                                            String jiti = o.getJiti();
                                            String sp_jiti = o.getSp_jiti();
                                            String qd_jiti = o.getQd_jiti();
                                            String aoi_count = o.getAoi_count();

                                            cmsAoiSch.setDept_code(dept_code);
                                            cmsAoiSch.setAoi_count(aoi_count);
                                            cmsAoiSch.setJiti(jiti);
                                            cmsAoiSch.setSp_jiti(sp_jiti);
                                            cmsAoiSch.setQd_jiti(qd_jiti);
                                            cmsAoiSch.setAoi_id(aoi_id);
                                            cmsAoiSch.setAoi_name(aoi_name);
                                            return cmsAoiSch;
                                        }).collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getAoi_id))), ArrayList::new));

                                scheduleWidthData.setList(aoiList);
                            }
                            scheduleWidthData.setAoi_size(size);
                            return scheduleWidthData;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiCntRdd cnt:{}", aoiCntRdd.count());
                scheduleWidthDataAoiNameRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> ttOrderAoiInfoAoiRdd = atEmpAoiAddrEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getTakeover_member_no(), o))
                        .leftOuterJoin(aoiCntRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                ScheduleWidthData scheduleWidthData = tp._2._2.get();
                                o.setAoiid(scheduleWidthData.getAoi_id());
                                o.setDept_code(scheduleWidthData.getDept_code());
                                o.setAoi_size(scheduleWidthData.getAoi_size());
                                o.setList(scheduleWidthData.getList());
                            } else {
                                o.setTag("no_consignee_emp");
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderAoiInfoAoiRdd cnt:{}", ttOrderAoiInfoAoiRdd.count());
                atEmpAoiAddrEmpAoiRdd.unpersist();
                aoiCntRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> ttOrderAoiInfoLastAoiRdd = ttOrderAoiInfoAoiRdd.map(o -> {
                    String aoiid = o.getAoiid();
                    if (StringUtils.isNotEmpty(aoiid)) {
                        int aoiSize = o.getAoi_size();
                        if (aoiSize == 1) {
                            String dept_code = o.getDept_code();
                            String original_zone_code = o.getDestination_zone_code();
                            if (StringUtils.isNotEmpty(dept_code) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(dept_code, original_zone_code)) {
                                o.setLastAoiid(aoiid);
                                o.setTag("aoi_id_unique");
                            }
                        }
                    }
                    return o;
                }).map(o -> {
                    String takeover_tm = o.getTakeover_tm();
                    if (StringUtils.isNotEmpty(takeover_tm)) {
                        String barscantmstd = DateUtil.dateToStamp(takeover_tm);
                        long barscantmstdL = Long.parseLong(barscantmstd);
                        long before = barscantmstdL - 10 * 60 * 1000;
                        long after = barscantmstdL + 10 * 60 * 1000;

                        o.setBarscantmstd(barscantmstd);
                        o.setBefore10min(before + "");
                        o.setAfter10min(after + "");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderAoiInfoLastAoiRdd cnt:{}", ttOrderAoiInfoLastAoiRdd.count());
                ttOrderAoiInfoAoiRdd.unpersist();

                String after1Date = DateUtil.getDaysBefore(date, -1);
                logger.error("after1Date:{}", after1Date);
                JavaRDD<TtEdcsHiveCommissionDetail> ttEdcsHiveCommissionDetailRdd = service.loadTtEdcsHiveCommissionDetail(sparkInfo, date, after1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttEdcsHiveCommissionDetailRdd cnt:{}", ttEdcsHiveCommissionDetailRdd.count());

                JavaRDD<TtEdcsWaybillContentSws> waybillTypeRdd = ttOrderAoiInfoLastAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                        .leftOuterJoin(ttEdcsHiveCommissionDetailRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                TtEdcsHiveCommissionDetail ttEdcsHiveCommissionDetail = tp._2._2.get();
                                o.setWaybill_type(ttEdcsHiveCommissionDetail.getWaybill_type());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("waybillTypeRdd cnt:{}", waybillTypeRdd.count());
                ttOrderAoiInfoLastAoiRdd.unpersist();
                ttEdcsHiveCommissionDetailRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> aoiCntLarge1Rdd = waybillTypeRdd.filter(o -> StringUtils.isNotEmpty(o.getAoiid()) && StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> aoiCntEq1Rdd = waybillTypeRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> otherRdd = waybillTypeRdd.filter(o -> StringUtils.isEmpty(o.getAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiCntLarge1Rdd cnt:{}", aoiCntLarge1Rdd.count());
                logger.error("aoiCntEq1Rdd cnt:{}", aoiCntEq1Rdd.count());
                logger.error("otherRdd cnt:{}", otherRdd.count());
                waybillTypeRdd.unpersist();

                String after3Date = DateUtil.getDaysBefore(date, -3);
                logger.error("after3Date:{}", after3Date);
                JavaRDD<TtWaybillInfo> ttWaybillInfoRdd1 = service.loadTtWaybillInfoData1(sparkInfo, date, after3Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttWaybillInfoRdd1 cnt:{}", ttWaybillInfoRdd1.count());

                JavaRDD<RdsOmsAoi> rdsOmstoAoiRdd1 = service.loadRdsOmstoAoiData1(sparkInfo, date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmstoAoiRdd1 cnt:{}", rdsOmstoAoiRdd1.count());

                JavaRDD<RdsOmsAoi> rdsOmstoAoiEmpRdd1 = rdsOmstoAoiRdd1.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o))
                        .leftOuterJoin(ttWaybillInfoRdd1.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)))
                        .map(tp -> {
                            RdsOmsAoi o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                TtWaybillInfo ttWaybillInfo = tp._2._2.get();
                                o.setEmp_code(ttWaybillInfo.getDeliver_emp_code());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmstoAoiEmpRdd1 cnt:{}", rdsOmstoAoiEmpRdd1.count());
                rdsOmstoAoiRdd1.unpersist();

                JavaRDD<RdsOmsAoi> rdsOmsAoiEmpRdd = rdsOmstoAoiEmpRdd1.map(o -> {
                    String reqtime = o.getReqtime();
                    if (StringUtils.isNotEmpty(reqtime)) {
                        String dateToStamp = DateUtil.dateToStamp(reqtime);
                        o.setReqtimetm(dateToStamp);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmsAoiEmpRdd cnt:{}", rdsOmsAoiEmpRdd.count());
                rdsOmstoAoiEmpRdd1.unpersist();

                JavaRDD<RdsOmsAoi> rdsOmsAoiEmpSupRdd = rdsOmsAoiEmpRdd.mapToPair(o -> new Tuple2<>(o.getAoicode(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)))
                        .map(tp -> {
                            RdsOmsAoi o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                o.setAoiid(cmsAoiSch.getAoi_id());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("rdsOmsAoiEmpSupRdd cnt:{}", rdsOmsAoiEmpSupRdd.count());
                rdsOmsAoiEmpRdd.unpersist();

                JavaRDD<RdsOmsAoi> ttOrderAoiInfoRdd = rdsOmsAoiEmpSupRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o))
                        .leftOuterJoin(aoiValueRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey())
                        .map(tp -> {
                            RdsOmsAoi o = tp._2._1;
                            if (tp._2._2() != null && tp._2._2.isPresent()) {
                                List<AoiValue> list = Lists.newArrayList(tp._2._2.get());
                                List<AoiValue> collect1 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "1")).collect(Collectors.toList());
                                List<AoiValue> collect2 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "0")).collect(Collectors.toList());
                                if (collect1.size() > 0) {
                                    o.setQd_jiti(collect1.get(0).getWage_level());
                                }
                                if (collect2.size() > 0) {
                                    o.setSp_jiti(collect2.get(0).getWage_level());
                                }
                            }
                            return o;
                        })
                        .mapToPair(o -> new Tuple2<>(o.getAoiid(), o))
                        .leftOuterJoin(aoiStatAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            RdsOmsAoi o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                AoiStatAoiid aoiStatAoiid = tp._2._2.get();
                                String count = aoiStatAoiid.getCount();
                                o.setAoi_count(count);
                            }
                            return o;
                        })
                        .persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderAoiInfoRdd cnt:{}", ttOrderAoiInfoRdd.count());
                rdsOmsAoiEmpSupRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> barscantmstd10SortRdd = aoiCntLarge1Rdd.mapToPair(o -> new Tuple2<>(o.getTakeover_member_no(), o)).repartition(120)
                        .leftOuterJoin(ttOrderAoiInfoRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey())
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            String before10min = o.getBefore10min();
                            String after10min = o.getAfter10min();
                            String barscantmstd = o.getBarscantmstd();
                            String original_zone_code = o.getDestination_zone_code();
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                List<RdsOmsAoi> list = Lists.newArrayList(tp._2._2.get());
                                list = list.stream().filter(tt -> {
                                    boolean flag = false;
                                    String reqtimetm = tt.getReqtimetm();
                                    if (StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min) && StringUtils.isNotEmpty(reqtimetm)) {
                                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                                            flag = true;
                                        }
                                    }
                                    return flag;
                                }).collect(Collectors.toList());
                                List<RdsOmsAoi> bigList = list.stream().filter(tt -> StringUtils.isNotEmpty(barscantmstd) &&
                                        StringUtils.isNotEmpty(tt.getReqtimetm()) &&
                                        Long.parseLong(barscantmstd) < Long.parseLong(tt.getReqtimetm())).collect(Collectors.toList());

                                List<RdsOmsAoi> smallList = list.stream().filter(tt -> StringUtils.isNotEmpty(barscantmstd) &&
                                        StringUtils.isNotEmpty(tt.getReqtimetm()) &&
                                        Long.parseLong(barscantmstd) > Long.parseLong(tt.getReqtimetm())).collect(Collectors.toList());
                                String big_aoi = "";
                                String small_aoi = "";
                                String dept_code = "";
                                if (bigList.size() > 0) {
                                    RdsOmsAoi rdsOmsAoi = bigList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0);
                                    big_aoi = rdsOmsAoi.getAoiid();
                                    dept_code = rdsOmsAoi.getDeptcode();
                                }

                                if (smallList.size() > 0) {
                                    small_aoi = smallList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0).getAoiid();
                                }
                                if (StringUtils.isNotEmpty(big_aoi) && StringUtils.isNotEmpty(small_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(big_aoi, small_aoi) && StringUtils.equals(dept_code, original_zone_code)) {
                                    o.setLastAoiid(big_aoi);
                                    o.setTag("aoi_id_80_time");
                                }
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("barscantmstd10SortRdd cnt:{}", barscantmstd10SortRdd.count());
                aoiCntLarge1Rdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd = barscantmstd10SortRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd = barscantmstd10SortRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd cnt:{}", noEmpAoiRdd.count());
                logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
                barscantmstd10SortRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> similarityRdd = empAoiRdd.map(o -> {
                    String url = similarityUrl;
                    String consignor_addr = o.getAddresseeaddr();
                    String original_zone_code = o.getDestination_zone_code();
                    if (StringUtils.isNotEmpty(consignor_addr)) {
                        String last_aoi = "";
                        String dept_code = "";
                        List<CmsAoiSch> list = o.getList();
                        for (CmsAoiSch cmsAoiSch : list) {
                            String aoi_name = cmsAoiSch.getAoi_name();
                            if (StringUtils.isNotEmpty(aoi_name) && consignor_addr.contains(aoi_name)) {
                                last_aoi = cmsAoiSch.getAoi_id();
                                dept_code = cmsAoiSch.getDept_code();
                                break;
                            }
                        }
                        if (StringUtils.isNotEmpty(last_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(dept_code) && StringUtils.equals(dept_code, original_zone_code)) {
                            o.setLastAoiid(last_aoi);
                            o.setTag("similar");
                        } else {
                            List<CmsAoiSch> similarityList = list.stream()
                                    .map(cmsAoiSch -> {
                                        try {
                                            String aoi_name = cmsAoiSch.getAoi_name();
                                            String req = String.format(url, URLEncoder.encode(consignor_addr, "UTF-8"), URLEncoder.encode(aoi_name, "UTF-8"));
                                            String content = HttpInvokeUtil.sendGet(req);
                                            if (StringUtils.isNotEmpty(content)) {
                                                JSONObject jsonObject = JSON.parseObject(content);
                                                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                                    String similarity = jsonObject.getString("result");
                                                    logger.error("similarity:{}", similarity);
                                                    cmsAoiSch.setSimilarity(similarity);
                                                }
                                            }
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                        return cmsAoiSch;
                                    }).collect(Collectors.toList());

                            List<CmsAoiSch> lastList = similarityList.stream()
                                    .filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7)
                                    .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                                    .collect(Collectors.toList());
                            if (lastList.size() > 0) {
                                CmsAoiSch cmsAoiSch = lastList.get(0);
                                String aoi_id = cmsAoiSch.getAoi_id();
                                dept_code = cmsAoiSch.getDept_code();
                                if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(dept_code) && StringUtils.equals(original_zone_code, dept_code)) {
                                    o.setLastAoiid(aoi_id);
                                    o.setTag("similar");
                                }
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("similarityRdd cnt:{}", similarityRdd.count());
                empAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd2 = similarityRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd2 = similarityRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd2 cnt:{}", noEmpAoiRdd2.count());
                logger.error("empAoiRdd2 cnt:{}", empAoiRdd2.count());
                similarityRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> qdJitiAoiRdd = empAoiRdd2.map(o -> {
                    String waybill_type = o.getWaybill_type();
                    String original_zone_code = o.getDestination_zone_code();
                    List<CmsAoiSch> list = o.getList();
                    if (StringUtils.isNotEmpty(waybill_type)) {
                        if (StringUtils.equals(waybill_type, "1") || StringUtils.equals(waybill_type, "3") || StringUtils.equals(waybill_type, "4")) {
                            if (list.size() > 0) {
                                int size = list.stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getQd_jiti()))
                                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getQd_jiti))), ArrayList::new)).size();
                                if (size == 1) {
                                    CmsAoiSch cmsAoiSch = list.get(0);
                                    String dept_code = cmsAoiSch.getDept_code();
                                    String aoi_id = cmsAoiSch.getAoi_id();
                                    if (StringUtils.isNotEmpty(dept_code) && StringUtils.equals(dept_code, original_zone_code)) {
                                        o.setLastAoiid(aoi_id);
                                        o.setTag("aoi_id_random");
                                    }
                                }
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("qdJitiAoiRdd cnt:{}", qdJitiAoiRdd.count());
                empAoiRdd2.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd3 = qdJitiAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd3 = qdJitiAoiRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd3 cnt:{}", noEmpAoiRdd3.count());
                logger.error("empAoiRdd3 cnt:{}", empAoiRdd3.count());
                qdJitiAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd3Count = empAoiRdd3.map(o -> {
                    List<CmsAoiSch> list = o.getList();
                    String original_zone_code = o.getDestination_zone_code();
                    if (list.size() > 0) {
                        List<CmsAoiSch> collect = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDept_code())
                                && StringUtils.equals(original_zone_code, t.getDept_code())
                                && StringUtils.isNotEmpty(t.getAoi_count())).sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
                        if (collect.size() > 0) {
                            String aoi_id = collect.get(0).getAoi_id();
                            o.setLastAoiid(aoi_id);
                            o.setTag("aoi_id_stat");
                        } else {
                            List<CmsAoiSch> collect1 = list.stream().filter(t -> StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, t.getDept_code()))
                                    .collect(Collectors.toList());
                            if (collect1.size() > 0) {
                                o.setLastAoiid(collect1.get(0).getAoi_id());
                                o.setTag("no_stat");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiRdd3Count cnt:{}", empAoiRdd3Count.count());
                empAoiRdd3.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd4 = empAoiRdd3Count.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd4 = empAoiRdd3Count.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd4 cnt:{}", noEmpAoiRdd4.count());
                logger.error("empAoiRdd4 cnt:{}", empAoiRdd4.count());
                empAoiRdd3Count.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> spJitiAoiRdd = empAoiRdd4.map(o -> {
                    String waybill_type_new = o.getWaybill_type();
                    String original_zone_code = o.getDestination_zone_code();
                    List<CmsAoiSch> list = o.getList();
                    if (StringUtils.isNotEmpty(waybill_type_new)) {
                        if (StringUtils.equals(waybill_type_new, "2")) {
                            if (list.size() > 0) {
                                int size = list.stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getSp_jiti()))
                                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getSp_jiti))), ArrayList::new)).size();
                                if (size == 1) {
                                    CmsAoiSch cmsAoiSch = list.get(0);
                                    String dept_code = cmsAoiSch.getDept_code();
                                    String aoi_id = cmsAoiSch.getAoi_id();
                                    if (StringUtils.isNotEmpty(dept_code) && StringUtils.equals(dept_code, original_zone_code)) {
                                        o.setLastAoiid(aoi_id);
                                        o.setTag("aoi_id_random");
                                    }
                                }
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("spJitiAoiRdd cnt:{}", spJitiAoiRdd.count());
                empAoiRdd4.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd5 = spJitiAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd5 = spJitiAoiRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd5 cnt:{}", noEmpAoiRdd5.count());
                logger.error("empAoiRdd5 cnt:{}", empAoiRdd5.count());
                spJitiAoiRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> lastRdd = empAoiRdd5.map(o -> {
                    List<CmsAoiSch> list = o.getList();
                    String original_zone_code = o.getDestination_zone_code();
                    if (list.size() > 0) {
                        List<CmsAoiSch> collect = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDept_code())
                                && StringUtils.equals(original_zone_code, t.getDept_code())
                                && StringUtils.isNotEmpty(t.getAoi_count())).sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
                        if (collect.size() > 0) {
                            String aoi_id = collect.get(0).getAoi_id();
                            o.setLastAoiid(aoi_id);
                            o.setTag("aoi_id_stat");
                        } else {
                            List<CmsAoiSch> collect1 = list.stream().filter(t -> StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, t.getDept_code()))
                                    .collect(Collectors.toList());
                            if (collect1.size() > 0) {
                                o.setLastAoiid(collect1.get(0).getAoi_id());
                                o.setTag("no_stat");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("lastRdd cnt:{}", lastRdd.count());
                empAoiRdd5.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> aoi_id_54_time_no_scheduleRdd = otherRdd.mapToPair(o -> new Tuple2<>(o.getTakeover_member_no(), o))
                        .leftOuterJoin(ttOrderAoiInfoRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey())
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            String before10min = o.getBefore10min();
                            String after10min = o.getAfter10min();
                            String barscantmstd = o.getBarscantmstd();
                            String original_zone_code = o.getDestination_zone_code();
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                List<RdsOmsAoi> list = Lists.newArrayList(tp._2._2.get()).stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getDeptcode()) && StringUtils.equals(t.getDeptcode(), original_zone_code))
                                        .collect(Collectors.toList());
                                list = list.stream().filter(tt -> {
                                    boolean flag = false;
                                    String reqtimetm = tt.getReqtimetm();
                                    if (StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min) && StringUtils.isNotEmpty(reqtimetm)) {
                                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                                            flag = true;
                                        }
                                    }
                                    return flag;
                                }).collect(Collectors.toList());
                                List<RdsOmsAoi> bigList = list.stream().filter(tt -> StringUtils.isNotEmpty(barscantmstd) &&
                                        StringUtils.isNotEmpty(tt.getReqtimetm()) &&
                                        Long.parseLong(barscantmstd) < Long.parseLong(tt.getReqtimetm())).collect(Collectors.toList());

                                List<RdsOmsAoi> smallList = list.stream().filter(tt -> StringUtils.isNotEmpty(barscantmstd) &&
                                        StringUtils.isNotEmpty(tt.getReqtimetm()) &&
                                        Long.parseLong(barscantmstd) > Long.parseLong(tt.getReqtimetm())).collect(Collectors.toList());
                                String big_aoi = "";
                                String small_aoi = "";
                                if (bigList.size() > 0) {
                                    big_aoi = bigList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0).getAoiid();
                                }

                                if (smallList.size() > 0) {
                                    small_aoi = smallList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0).getAoiid();
                                }
                                if (StringUtils.isNotEmpty(big_aoi) && StringUtils.isNotEmpty(small_aoi) && StringUtils.equals(big_aoi, small_aoi)) {
                                    o.setLastAoiid(big_aoi);
                                    o.setTag("aoi_id_80_time_no_schedule");
                                }
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoi_id_54_time_no_scheduleRdd cnt:{}", aoi_id_54_time_no_scheduleRdd.count());
                otherRdd.unpersist();
                ttOrderAoiInfoRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> aoi_id_54_time_no_schedule_no_empAoiRdd = aoi_id_54_time_no_scheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> aoi_id_54_time_no_schedule_empAoiRdd = aoi_id_54_time_no_scheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoi_id_54_time_no_schedule_no_empAoiRdd cnt:{}", aoi_id_54_time_no_schedule_no_empAoiRdd.count());
                logger.error("aoi_id_54_time_no_schedule_empAoiRdd cnt:{}", aoi_id_54_time_no_schedule_empAoiRdd.count());
                aoi_id_54_time_no_scheduleRdd.unpersist();

                JavaRDD<TtOrderAoiInfo> ttOrderWaybillRdd = service.loadTtOrderWaybillData(sparkInfo, before30Date, date).filter(o -> StringUtils.isNotEmpty(o.getConsignee_emp_code()) && StringUtils.isNotEmpty(o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderWaybillRdd cnt:{}", ttOrderWaybillRdd.count());

                JavaRDD<TtOrderAoiInfo> ttOrderWaybillJitiRdd = ttOrderWaybillRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(aoiValueRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey())
                        .map(tp -> {
                            TtOrderAoiInfo ttOrderAoiInfo = tp._2._1;
                            if (tp._2._2() != null && tp._2._2.isPresent()) {
                                List<AoiValue> list = Lists.newArrayList(tp._2._2.get());
                                List<AoiValue> collect1 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "1")).collect(Collectors.toList());
                                List<AoiValue> collect2 = list.stream().filter(t -> StringUtils.equals(t.getChannel(), "0")).collect(Collectors.toList());
                                if (collect1.size() > 0) {
                                    ttOrderAoiInfo.setQd_jiti(collect1.get(0).getWage_level());
                                }
                                if (collect2.size() > 0) {
                                    ttOrderAoiInfo.setSp_jiti(collect2.get(0).getWage_level());
                                }
                            }
                            return ttOrderAoiInfo;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderWaybillJitiRdd cnt:{}", ttOrderWaybillJitiRdd.count());
                ttOrderWaybillRdd.unpersist();

                JavaRDD<TtOrderAoiInfo> ttOrderWaybillSupRdd = ttOrderWaybillJitiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(aoiStatAoiidRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            TtOrderAoiInfo o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                AoiStatAoiid aoiStatAoiid = tp._2._2.get();
                                String count = aoiStatAoiid.getCount();
                                o.setAoi_count(count);
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderWaybillSupRdd cnt:{}", ttOrderWaybillSupRdd.count());
                ttOrderWaybillJitiRdd.unpersist();
                aoiStatAoiidRdd.unpersist();

                JavaRDD<TtOrderAoiInfo> ttOrderWaybillSupAoiNameRdd = ttOrderWaybillSupRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtOrderAoiInfo ttOrderAoiInfo = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                ttOrderAoiInfo.setAoi_name(cmsAoiSch.getAoi_name());
                            }
                            return ttOrderAoiInfo;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttOrderWaybillSupAoiNameRdd cnt:{}", ttOrderWaybillSupAoiNameRdd.count());
                ttOrderWaybillSupRdd.unpersist();


                JavaRDD<TtEdcsWaybillContentSws> finalRdd = aoi_id_54_time_no_schedule_empAoiRdd.mapToPair(o -> new Tuple2<>(o.getTakeover_member_no(), o))
                        .leftOuterJoin(ttOrderWaybillSupAoiNameRdd.mapToPair(o -> new Tuple2<>(o.getConsignee_emp_code(), o)).groupByKey())
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            String url = similarityUrl;
                            String consignor_addr = o.getAddresseeaddr();
                            String original_zone_code = o.getDestination_zone_code();
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                List<TtOrderAoiInfo> list = Lists.newArrayList(tp._2._2.get()).stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getAoi_zc()) && StringUtils.equals(t.getAoi_zc(), original_zone_code))
                                        .collect(Collectors.toList());
                                String last_aoi = "";
                                if (StringUtils.isNotEmpty(consignor_addr)) {
                                    for (TtOrderAoiInfo ttOrderAoiInfo : list) {
                                        String aoi_name = ttOrderAoiInfo.getAoi_name();
                                        if (StringUtils.isNotEmpty(aoi_name) && consignor_addr.contains(aoi_name)) {
                                            last_aoi = ttOrderAoiInfo.getAoi_id();
                                            break;
                                        }
                                    }
                                    if (StringUtils.isNotEmpty(last_aoi)) {
                                        o.setLastAoiid(last_aoi);
                                        o.setTag("similar_no_schedule");
                                    } else {
                                        List<TtOrderAoiInfo> similarityList = list.stream()
                                                .map(ttOrderAoiInfo -> {
                                                    try {
                                                        String aoi_name = ttOrderAoiInfo.getAoi_name();
                                                        String req = String.format(url, URLEncoder.encode(consignor_addr, "UTF-8"), URLEncoder.encode(aoi_name, "UTF-8"));
                                                        String content = HttpInvokeUtil.sendGet(req);
                                                        if (StringUtils.isNotEmpty(content)) {
                                                            JSONObject jsonObject = JSON.parseObject(content);
                                                            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                                                String similarity = jsonObject.getString("result");
                                                                logger.error("similarity:{}", similarity);
                                                                ttOrderAoiInfo.setSimilarity(similarity);
                                                            }
                                                        }
                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                                    return ttOrderAoiInfo;
                                                }).collect(Collectors.toList());

                                        List<TtOrderAoiInfo> lastList = similarityList.stream()
                                                .filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7)
                                                .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                                                .collect(Collectors.toList());
                                        if (lastList.size() > 0) {
                                            TtOrderAoiInfo ttOrderAoiInfo = lastList.get(0);
                                            last_aoi = ttOrderAoiInfo.getAoi_id();
                                            o.setLastAoiid(last_aoi);
                                            o.setTag("similar_no_schedule");
                                        }
                                    }
                                }
                                if (StringUtils.isEmpty(last_aoi)) {
                                    ArrayList<TtOrderAoiInfo> collect = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_id()))
                                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TtOrderAoiInfo::getAoi_id))), ArrayList::new));
                                    if (collect.size() == 1) {
                                        String aoi_id = collect.get(0).getAoi_id();
                                        o.setLastAoiid(aoi_id);
                                        o.setTag("aoi_id_unique_no_schedule");
                                    } else if (collect.size() > 1) {
                                        String waybill_type = o.getWaybill_type();
                                        if (StringUtils.isNotEmpty(waybill_type) &&
                                                (StringUtils.equals(waybill_type, "1") ||
                                                        StringUtils.equals(waybill_type, "3") ||
                                                        StringUtils.equals(waybill_type, "4"))) {
                                            ArrayList<TtOrderAoiInfo> collect1 = collect.stream().filter(t -> StringUtils.isNotEmpty(t.getQd_jiti()))
                                                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TtOrderAoiInfo::getQd_jiti))), ArrayList::new));
                                            if (collect1.size() == 1) {
                                                o.setLastAoiid(collect1.get(0).getAoi_id());
                                                o.setTag("aoi_id_random_no_schedule");
                                            } else if (collect1.size() > 1) {
                                                List<TtOrderAoiInfo> collect2 = collect1.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_count()))
                                                        .sorted((o1, o2) -> o2.compareTo(o1))
                                                        .collect(Collectors.toList());
                                                if (collect2.size() > 0) {
                                                    o.setLastAoiid(collect2.get(0).getAoi_id());
                                                    o.setTag("aoi_id_stat_no_schedule");
                                                }
                                            }
                                        } else if (StringUtils.isNotEmpty(waybill_type) && StringUtils.equals(waybill_type, "2")) {
                                            ArrayList<TtOrderAoiInfo> collect1 = collect.stream().filter(t -> StringUtils.isNotEmpty(t.getSp_jiti()))
                                                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TtOrderAoiInfo::getSp_jiti))), ArrayList::new));
                                            if (collect1.size() == 1) {
                                                o.setLastAoiid(collect1.get(0).getAoi_id());
                                                o.setTag("aoi_id_random_no_schedule");
                                            } else if (collect1.size() > 1) {
                                                List<TtOrderAoiInfo> collect2 = collect1.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_count()))
                                                        .sorted((o1, o2) -> o2.compareTo(o1))
                                                        .collect(Collectors.toList());
                                                if (collect2.size() > 0) {
                                                    o.setLastAoiid(collect2.get(0).getAoi_id());
                                                    o.setTag("aoi_id_stat_no_schedule");
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("finalRdd cnt:{}", finalRdd.count());
                aoi_id_54_time_no_schedule_empAoiRdd.unpersist();
                ttOrderWaybillSupAoiNameRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd6 = finalRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd6 = finalRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd6 cnt:{}", noEmpAoiRdd6.count());
                logger.error("empAoiRdd6 cnt:{}", empAoiRdd6.count());
                finalRdd.unpersist();

                JavaRDD<IncSgsTaskFlowNew> incSgsTaskFlowNewDataRdd = service.loadIncSgsTaskFlowNewData(sparkInfo, date, date)
                        .map(o -> {
                            String operatime_new = o.getOperatime_new();
                            if (StringUtils.isNotEmpty(operatime_new)) {
                                o.setOperatime_new(DateUtil.dateToStamp(operatime_new));
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("incSgsTaskFlowNewDataRdd cnt:{}", incSgsTaskFlowNewDataRdd.count());

                JavaRDD<TtEdcsWaybillContentSws> empAoiRddEventXy6 = empAoiRdd6.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                        .leftOuterJoin(incSgsTaskFlowNewDataRdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).groupByKey())
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                List<IncSgsTaskFlowNew> list = Lists.newArrayList(tp._2._2.get());
                                List<IncSgsTaskFlowNew> collect = list.stream().filter(tt -> StringUtils.equals(tt.getEventtype(), "31201")).collect(Collectors.toList());
                                if (collect.size() > 0) {
                                    IncSgsTaskFlowNew incSgsTaskFlowNew = collect.get(0);
                                    String eventlng = incSgsTaskFlowNew.getEventlng();
                                    String eventlat = incSgsTaskFlowNew.getEventlat();

                                    o.setEventlng(eventlng);
                                    o.setEventlat(eventlat);
                                } else {
                                    List<IncSgsTaskFlowNew> collect1 = list.stream().filter(tt -> StringUtils.equals(tt.getEventtype(), "31127")).collect(Collectors.toList());
                                    if (collect1.size() > 0) {
                                        IncSgsTaskFlowNew incSgsTaskFlowNew = collect1.get(0);
                                        String eventlng = incSgsTaskFlowNew.getEventlng();
                                        String eventlat = incSgsTaskFlowNew.getEventlat();

                                        o.setEventlng(eventlng);
                                        o.setEventlat(eventlat);
                                    }
                                }
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiRddEventXy6 cnt:{}", empAoiRddEventXy6.count());
                empAoiRdd6.unpersist();
                incSgsTaskFlowNewDataRdd.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> empAoiEventAoiRdd6 = empAoiRddEventXy6.map(o -> {
                    String original_zone_code = o.getOriginal_zone_code();
                    String url = getAoiByXy;
                    String eventlng = o.getEventlng();
                    String eventlat = o.getEventlat();
                    String event_aoiid = "";
                    String ac = "";

                    if (StringUtils.isNotEmpty(eventlng) && StringUtils.isNotEmpty(eventlat)) {
                        JSONArray coords = new JSONArray();
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("lng", eventlng);
                        jsonObject.put("lat", eventlat);
                        coords.add(jsonObject);

                        JSONObject param = new JSONObject();
                        param.put("ak", "d54e00e389524aa1a2e73946dc323b2a");
                        param.put("coords", coords);
                        String content = HttpInvokeUtil.sendPost(url, param.toJSONString());
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject1 = JSON.parseObject(content);
                            if (jsonObject1 != null && jsonObject1.getInteger("status") == 0) {
                                JSONObject result = jsonObject1.getJSONObject("result");
                                if (result != null) {
                                    JSONObject data = result.getJSONObject("data");
                                    if (data != null) {
                                        JSONArray aois = data.getJSONArray("aois");
                                        if (aois != null && aois.size() > 0) {
                                            JSONObject jsonObject2 = aois.getJSONObject(0);
                                            event_aoiid = jsonObject2.getString("aoi_id");
                                            ac = jsonObject2.getString("ac");
                                        }
                                    }
                                }
                            }
                        }
                        if (StringUtils.isNotEmpty(ac) && StringUtils.equals(ac, original_zone_code)) {
                            o.setEvent_aoiid(event_aoiid);
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiEventAoiRdd6 cnt:{}", empAoiEventAoiRdd6.count());
                empAoiRddEventXy6.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> empAoiEventAoiNameRdd6 = empAoiEventAoiRdd6.mapToPair(o -> new Tuple2<>(o.getEvent_aoiid(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                o.setAoi_name(cmsAoiSch.getAoi_name());
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiEventAoiNameRdd6 cnt:{}", empAoiEventAoiNameRdd6.count());
                empAoiEventAoiRdd6.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> empAoiEventAoiNameSimilarRdd6 = empAoiEventAoiNameRdd6.map(o -> {
                    String url = similarityUrl;
                    String address = o.getAddress();
                    String aoi_name = o.getAoi_name();
                    String event_aoiid = o.getEvent_aoiid();
                    if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(aoi_name) && StringUtils.isNotEmpty(event_aoiid)) {
                        if (address.contains(aoi_name)) {
                            o.setLastAoiid(event_aoiid);
                            o.setTag("aoi_id_zc_aoiname_similar");
                        } else {
                            String req = String.format(url, URLEncoder.encode(address, "UTF-8"), URLEncoder.encode(aoi_name, "UTF-8"));
                            String content = HttpInvokeUtil.sendGet(req);
                            if (StringUtils.isNotEmpty(content)) {
                                JSONObject jsonObject = JSON.parseObject(content);
                                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                    String similarity = jsonObject.getString("result");
                                    logger.error("similarity:{}", similarity);
                                    if (StringUtils.isNotEmpty(similarity) && Double.parseDouble(similarity) > 0.7) {
                                        o.setLastAoiid(event_aoiid);
                                        o.setTag("aoi_id_zc_aoiname_similar");
                                    }
                                }
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiEventAoiNameSimilarRdd6 cnt:{}", empAoiEventAoiNameSimilarRdd6.count());
                empAoiEventAoiNameRdd6.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> noEmpAoiRdd7 = empAoiEventAoiNameSimilarRdd6.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtEdcsWaybillContentSws> empAoiRdd7 = empAoiEventAoiNameSimilarRdd6.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("noEmpAoiRdd7 cnt:{}", noEmpAoiRdd7.count());
                logger.error("empAoiRdd7 cnt:{}", empAoiRdd7.count());
                empAoiEventAoiNameSimilarRdd6.unpersist();

                JavaRDD<ZnocodeToAoi> znocodeToAoiRdd = service.loadZnocodeToAoiData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("znocodeToAoiRdd cnt:{}", znocodeToAoiRdd.count());

                JavaRDD<TtEdcsWaybillContentSws> empAoiZcRdd7 = empAoiRdd7.mapToPair(o -> new Tuple2<>(o.getOriginal_zone_code(), o))
                        .leftOuterJoin(znocodeToAoiRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                ZnocodeToAoi znocodeToAoi = tp._2._2.get();
                                o.setLastAoiid(znocodeToAoi.getAoi_id());
                                o.setTag("zc");
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("empAoiZcRdd7 cnt:{}", empAoiZcRdd7.count());
                empAoiRdd7.unpersist();
                znocodeToAoiRdd.unpersist();


                JavaRDD<TtEdcsWaybillContentSws> resultRdd = aoi_id_source_waybill_no_emp_last_aoi_Rdd.union(atEmpAoiAddrNoEmpAoiRdd)
                        .union(aoiCntEq1Rdd).union(noEmpAoiRdd).union(noEmpAoiRdd2).union(noEmpAoiRdd3).union(noEmpAoiRdd4)
                        .union(noEmpAoiRdd5).union(lastRdd).union(aoi_id_54_time_no_schedule_no_empAoiRdd)
                        .union(noEmpAoiRdd6).union(noEmpAoiRdd7).union(empAoiZcRdd7)
                        .map(o -> {
                            if (StringUtils.isEmpty(o.getLastAoiid())) {
                                o.setTag("no_sj_no_pj");
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("resultRdd cnt:{}", resultRdd.count());
                aoi_id_source_waybill_no_emp_last_aoi_Rdd.unpersist();
                atEmpAoiAddrNoEmpAoiRdd.unpersist();
                aoiCntEq1Rdd.unpersist();
                noEmpAoiRdd.unpersist();
                noEmpAoiRdd2.unpersist();
                noEmpAoiRdd3.unpersist();
                noEmpAoiRdd4.unpersist();
                noEmpAoiRdd5.unpersist();
                lastRdd.unpersist();
                aoi_id_54_time_no_schedule_no_empAoiRdd.unpersist();
                noEmpAoiRdd6.unpersist();
                noEmpAoiRdd7.unpersist();
                empAoiZcRdd7.unpersist();

                JavaRDD<TtEdcsWaybillContentSws> faTypeRdd = resultRdd.mapToPair(o -> new Tuple2<>(o.getLastAoiid(), o))
                        .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                String aoi_code = cmsAoiSch.getAoi_code();
                                String fa_type = cmsAoiSch.getFa_type();
                                o.setAoi_code(aoi_code);
                                o.setFa_type(fa_type);
                            }
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("faTypeRdd cnt:{}", faTypeRdd.count());
                resultRdd.unpersist();

                JavaRDD<AoiAreaAoi> aoiAreaAoiRdd = service.loadAoiAreaAoiData(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiAreaAoiRdd cnt:{}", aoiAreaAoiRdd.count());

                JavaRDD<TtEdcsWaybillContentSws> overRdd = faTypeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
                        .leftOuterJoin(aoiAreaAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                        .map(tp -> {
                            TtEdcsWaybillContentSws o = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                                o.setAoi_area_code(aoiAreaAoi.getAoi_area_code());
                            }
                            return o;
                        }).mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                        .reduceByKey((o1, o2) -> o1)
                        .map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("overRdd cnt:{}", overRdd.count());
                faTypeRdd.unpersist();

                sparkInfo.getSession().sql(String.format("alter table dm_gis.pj_aoi_new drop if EXISTS partition(inc_day='%s')", date));
                service.saveData(sparkInfo.getSession(), overRdd, "dm_gis.pj_aoi_new", date);
                overRdd.unpersist();
            }
        }
        aoiValueRdd.unpersist();
        cmsAoiSchRdd.unpersist();
    }
}
