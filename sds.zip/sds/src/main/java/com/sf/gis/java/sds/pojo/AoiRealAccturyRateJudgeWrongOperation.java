package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiRealAccturyRateJudgeWrongOperation implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "userid")
    private String userid;
    @Column(name = "operatime_new")
    private String operatime_new;
    @Column(name = "delivery_lgt")
    private String delivery_lgt;
    @Column(name = "delivery_lat")
    private String delivery_lat;
    @Column(name = "inc_day_gd")
    private String inc_day_gd;
    @Column(name = "req_waybillno")
    private String req_waybillno;
    @Column(name = "req_destcitycode")
    private String req_destcitycode;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "req_time")
    private String req_time;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "gj_aoiid_t")
    private String gj_aoiid_t;
    @Column(name = "gj_aoicode_t")
    private String gj_aoicode_t;
    @Column(name = "gj_aoiname_t")
    private String gj_aoiname_t;
    @Column(name = "starttime")
    private String starttime;
    @Column(name = "endtime")
    private String endtime;
    @Column(name = "gjaoi_frq")
    private String gjaoi_frq;
    @Column(name = "inc_day_gj")
    private String inc_day_gj;
    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "r_aoi")
    private String r_aoi;
    @Column(name = "key_word")
    private String key_word;
    @Column(name = "key_tag")
    private String key_tag;
    @Column(name = "last14")
    private String last14;
    @Column(name = "last13")
    private String last13;
    @Column(name = "last613")
    private String last613;
    @Column(name = "gisaoicode_rds")
    private String gisaoicode_rds;
    @Column(name = "ksaoicode")
    private String ksaoicode;
    @Column(name = "mapa_aoiid")
    private String mapa_aoiid;
    @Column(name = "mapa_aoicode")
    private String mapa_aoicode;
    @Column(name = "mapa_aoiname")
    private String mapa_aoiname;
    @Column(name = "gd_aoiid")
    private String gd_aoiid;
    @Column(name = "gd_aoicode")
    private String gd_aoicode;
    @Column(name = "gd_aoiname")
    private String gd_aoiname;
    @Column(name = "gd_start")
    private String gd_start;
    @Column(name = "gd_end")
    private String gd_end;
    @Column(name = "gis_aoi_code")
    private String gis_aoi_code;
    @Column(name = "gis_aoi_name")
    private String gis_aoi_name;
    @Column(name = "gis_splitinfo_info")
    private String gis_splitinfo_info;
    @Column(name = "80_aoi_code")
    private String aoi_80_code;
    @Column(name = "80_aoi_name")
    private String aoi_80_name;
    @Column(name = "80_splitinfo_info")
    private String splitinfo_80_info;
    @Column(name = "arss_dept_re_body")
    private String arss_dept_re_body;
    @Column(name = "arss_dept_req_body")
    private String arss_dept_req_body;
    @Column(name = "aoi_dept_req_body_latest")
    private String aoi_dept_req_body_latest;
    @Column(name = "aoi_dept_re_body_latest")
    private String aoi_dept_re_body_latest;
    @Column(name = "aoi_id_lag")
    private String aoi_id_lag;
    @Column(name = "aoi_id_lead")
    private String aoi_id_lead;
    @Column(name = "operatime_new_lag")
    private String operatime_new_lag;
    @Column(name = "operatime_new_lead")
    private String operatime_new_lead;
    @Column(name = "errortype")
    private String errortype;
    @Column(name = "tag3")
    private String tag3;
    @Column(name = "label")
    private String label;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "group_freq")
    private String group_freq;
    @Column(name = "right_freq")
    private String right_freq;
    @Column(name = "wrong_freq")
    private String wrong_freq;
    @Column(name = "other_freq")
    private String other_freq;
    @Column(name = "right_percent")
    private String right_percent;
    @Column(name = "operate_date")
    private String operate_date;

    private String cms_address;
    @Column(name = "old_cms_aoiid")
    private String old_cms_aoiid;
    private String cms_adcode;
    private String filterFlag;
    @Column(name = "address")
    private String address;
    @Column(name = "guid")
    private String guid;

    private String hpFlag;
    private String companyFlag;
    private String address_freq;
    private String cghsResultData_address_flag;
    private String repeat_address_flag;
    private boolean checkFlag;

    private String adcode;

    @Column(name = "mark")
    private String mark;

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public boolean isCheckFlag() {
        return checkFlag;
    }

    public void setCheckFlag(boolean checkFlag) {
        this.checkFlag = checkFlag;
    }

    public String getRepeat_address_flag() {
        return repeat_address_flag;
    }

    public void setRepeat_address_flag(String repeat_address_flag) {
        this.repeat_address_flag = repeat_address_flag;
    }

    public String getCghsResultData_address_flag() {
        return cghsResultData_address_flag;
    }

    public void setCghsResultData_address_flag(String cghsResultData_address_flag) {
        this.cghsResultData_address_flag = cghsResultData_address_flag;
    }

    public String getAddress_freq() {
        return address_freq;
    }

    public void setAddress_freq(String address_freq) {
        this.address_freq = address_freq;
    }

    public String getHpFlag() {
        return hpFlag;
    }

    public void setHpFlag(String hpFlag) {
        this.hpFlag = hpFlag;
    }

    public String getCompanyFlag() {
        return companyFlag;
    }

    public void setCompanyFlag(String companyFlag) {
        this.companyFlag = companyFlag;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getFilterFlag() {
        return filterFlag;
    }

    public void setFilterFlag(String filterFlag) {
        this.filterFlag = filterFlag;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCms_address() {
        return cms_address;
    }

    public void setCms_address(String cms_address) {
        this.cms_address = cms_address;
    }

    public String getCms_adcode() {
        return cms_adcode;
    }

    public void setCms_adcode(String cms_adcode) {
        this.cms_adcode = cms_adcode;
    }

    public String getOld_cms_aoiid() {
        return old_cms_aoiid;
    }

    public void setOld_cms_aoiid(String old_cms_aoiid) {
        this.old_cms_aoiid = old_cms_aoiid;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getOperatime_new() {
        return operatime_new;
    }

    public void setOperatime_new(String operatime_new) {
        this.operatime_new = operatime_new;
    }

    public String getDelivery_lgt() {
        return delivery_lgt;
    }

    public void setDelivery_lgt(String delivery_lgt) {
        this.delivery_lgt = delivery_lgt;
    }

    public String getDelivery_lat() {
        return delivery_lat;
    }

    public void setDelivery_lat(String delivery_lat) {
        this.delivery_lat = delivery_lat;
    }

    public String getInc_day_gd() {
        return inc_day_gd;
    }

    public void setInc_day_gd(String inc_day_gd) {
        this.inc_day_gd = inc_day_gd;
    }

    public String getReq_waybillno() {
        return req_waybillno;
    }

    public void setReq_waybillno(String req_waybillno) {
        this.req_waybillno = req_waybillno;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getReq_time() {
        return req_time;
    }

    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getGj_aoiid_t() {
        return gj_aoiid_t;
    }

    public void setGj_aoiid_t(String gj_aoiid_t) {
        this.gj_aoiid_t = gj_aoiid_t;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getGj_aoiname_t() {
        return gj_aoiname_t;
    }

    public void setGj_aoiname_t(String gj_aoiname_t) {
        this.gj_aoiname_t = gj_aoiname_t;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public String getGjaoi_frq() {
        return gjaoi_frq;
    }

    public void setGjaoi_frq(String gjaoi_frq) {
        this.gjaoi_frq = gjaoi_frq;
    }

    public String getInc_day_gj() {
        return inc_day_gj;
    }

    public void setInc_day_gj(String inc_day_gj) {
        this.inc_day_gj = inc_day_gj;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getR_aoi() {
        return r_aoi;
    }

    public void setR_aoi(String r_aoi) {
        this.r_aoi = r_aoi;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getKey_tag() {
        return key_tag;
    }

    public void setKey_tag(String key_tag) {
        this.key_tag = key_tag;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getLast13() {
        return last13;
    }

    public void setLast13(String last13) {
        this.last13 = last13;
    }

    public String getLast613() {
        return last613;
    }

    public void setLast613(String last613) {
        this.last613 = last613;
    }

    public String getGisaoicode_rds() {
        return gisaoicode_rds;
    }

    public void setGisaoicode_rds(String gisaoicode_rds) {
        this.gisaoicode_rds = gisaoicode_rds;
    }

    public String getKsaoicode() {
        return ksaoicode;
    }

    public void setKsaoicode(String ksaoicode) {
        this.ksaoicode = ksaoicode;
    }

    public String getMapa_aoiid() {
        return mapa_aoiid;
    }

    public void setMapa_aoiid(String mapa_aoiid) {
        this.mapa_aoiid = mapa_aoiid;
    }

    public String getMapa_aoicode() {
        return mapa_aoicode;
    }

    public void setMapa_aoicode(String mapa_aoicode) {
        this.mapa_aoicode = mapa_aoicode;
    }

    public String getMapa_aoiname() {
        return mapa_aoiname;
    }

    public void setMapa_aoiname(String mapa_aoiname) {
        this.mapa_aoiname = mapa_aoiname;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getGd_aoicode() {
        return gd_aoicode;
    }

    public void setGd_aoicode(String gd_aoicode) {
        this.gd_aoicode = gd_aoicode;
    }

    public String getGd_aoiname() {
        return gd_aoiname;
    }

    public void setGd_aoiname(String gd_aoiname) {
        this.gd_aoiname = gd_aoiname;
    }

    public String getGd_start() {
        return gd_start;
    }

    public void setGd_start(String gd_start) {
        this.gd_start = gd_start;
    }

    public String getGd_end() {
        return gd_end;
    }

    public void setGd_end(String gd_end) {
        this.gd_end = gd_end;
    }

    public String getGis_aoi_code() {
        return gis_aoi_code;
    }

    public void setGis_aoi_code(String gis_aoi_code) {
        this.gis_aoi_code = gis_aoi_code;
    }

    public String getGis_aoi_name() {
        return gis_aoi_name;
    }

    public void setGis_aoi_name(String gis_aoi_name) {
        this.gis_aoi_name = gis_aoi_name;
    }

    public String getGis_splitinfo_info() {
        return gis_splitinfo_info;
    }

    public void setGis_splitinfo_info(String gis_splitinfo_info) {
        this.gis_splitinfo_info = gis_splitinfo_info;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getAoi_80_name() {
        return aoi_80_name;
    }

    public void setAoi_80_name(String aoi_80_name) {
        this.aoi_80_name = aoi_80_name;
    }

    public String getSplitinfo_80_info() {
        return splitinfo_80_info;
    }

    public void setSplitinfo_80_info(String splitinfo_80_info) {
        this.splitinfo_80_info = splitinfo_80_info;
    }

    public String getArss_dept_re_body() {
        return arss_dept_re_body;
    }

    public void setArss_dept_re_body(String arss_dept_re_body) {
        this.arss_dept_re_body = arss_dept_re_body;
    }

    public String getArss_dept_req_body() {
        return arss_dept_req_body;
    }

    public void setArss_dept_req_body(String arss_dept_req_body) {
        this.arss_dept_req_body = arss_dept_req_body;
    }

    public String getAoi_dept_req_body_latest() {
        return aoi_dept_req_body_latest;
    }

    public void setAoi_dept_req_body_latest(String aoi_dept_req_body_latest) {
        this.aoi_dept_req_body_latest = aoi_dept_req_body_latest;
    }

    public String getAoi_dept_re_body_latest() {
        return aoi_dept_re_body_latest;
    }

    public void setAoi_dept_re_body_latest(String aoi_dept_re_body_latest) {
        this.aoi_dept_re_body_latest = aoi_dept_re_body_latest;
    }

    public String getAoi_id_lag() {
        return aoi_id_lag;
    }

    public void setAoi_id_lag(String aoi_id_lag) {
        this.aoi_id_lag = aoi_id_lag;
    }

    public String getAoi_id_lead() {
        return aoi_id_lead;
    }

    public void setAoi_id_lead(String aoi_id_lead) {
        this.aoi_id_lead = aoi_id_lead;
    }

    public String getOperatime_new_lag() {
        return operatime_new_lag;
    }

    public void setOperatime_new_lag(String operatime_new_lag) {
        this.operatime_new_lag = operatime_new_lag;
    }

    public String getOperatime_new_lead() {
        return operatime_new_lead;
    }

    public void setOperatime_new_lead(String operatime_new_lead) {
        this.operatime_new_lead = operatime_new_lead;
    }

    public String getErrortype() {
        return errortype;
    }

    public void setErrortype(String errortype) {
        this.errortype = errortype;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getGroup_freq() {
        return group_freq;
    }

    public void setGroup_freq(String group_freq) {
        this.group_freq = group_freq;
    }

    public String getRight_freq() {
        return right_freq;
    }

    public void setRight_freq(String right_freq) {
        this.right_freq = right_freq;
    }

    public String getWrong_freq() {
        return wrong_freq;
    }

    public void setWrong_freq(String wrong_freq) {
        this.wrong_freq = wrong_freq;
    }

    public String getOther_freq() {
        return other_freq;
    }

    public void setOther_freq(String other_freq) {
        this.other_freq = other_freq;
    }

    public String getRight_percent() {
        return right_percent;
    }

    public void setRight_percent(String right_percent) {
        this.right_percent = right_percent;
    }

    public String getOperate_date() {
        return operate_date;
    }

    public void setOperate_date(String operate_date) {
        this.operate_date = operate_date;
    }
}
