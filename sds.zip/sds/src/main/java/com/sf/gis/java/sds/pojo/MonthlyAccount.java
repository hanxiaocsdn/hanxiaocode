package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class MonthlyAccount implements Serializable {
    @Column(name = "city_code")
    private String city_code;

    @Column(name = "account")
    private String account;

    @Column(name = "aoi_id_atp")
    private String aoi_id_atp;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAoi_id_atp() {
        return aoi_id_atp;
    }

    public void setAoi_id_atp(String aoi_id_atp) {
        this.aoi_id_atp = aoi_id_atp;
    }
}
