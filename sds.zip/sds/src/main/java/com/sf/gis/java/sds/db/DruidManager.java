package com.sf.gis.java.sds.db;

import com.alibaba.druid.pool.DruidDataSource;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.scala.base.util.FileUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class DruidManager {
    private DruidDataSource dataSource;
    private static final Logger logger = LoggerFactory.getLogger(DruidManager.class);

    public DruidManager(String configPath) throws IOException {
        Properties configMap= FileUtil.getFilePropertieRes(configPath);
//        Map<String, String> configMap = ConfigUtil.parserConfig(configPath);
        dataSource = new DruidDataSource();
        dataSource.setDriverClassName(configMap.getProperty("jdbc.driverClassName"));
        dataSource.setUrl(configMap.getProperty("jdbc.url"));
        dataSource.setUsername(configMap.getProperty("jdbc.username"));
        dataSource.setPassword(configMap.getProperty("jdbc.password"));
    }
    public DruidManager(String driverClassName,String jdbcUrl,
                        String jdbcUsername,String jdbcPassword) throws IOException {
        dataSource = new DruidDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(jdbcUrl);
        dataSource.setUsername(jdbcUsername);
        dataSource.setPassword(jdbcPassword);
    }

    public String crateInsertSqlWithValue(HashMap<String, Object> map, String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (String column : columns) {
            sql.append("'" + map.get(column) + "',");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    public String crateSetSqlWithValue(HashMap<String, Object> map, String[] columns) {
        StringBuilder sql = new StringBuilder();
        for (String column : columns) {
            sql.append(column + "='" + map.get(column) + "',");
        }
        sql.deleteCharAt(sql.length() - 1);
        return sql.toString();
    }

    public String crateSetSqlWithOutValue(String[] columns) {
        StringBuilder sql = new StringBuilder();
        for (String column : columns) {
            sql.append(column + "=?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        return sql.toString();
    }

    public String crateInsertSqlWithOutValue(String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (@SuppressWarnings("unused") String column : columns) {
            sql.append("?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    public void close() {
        dataSource.close();
    }

    public void update(String sql) {
        try (Connection conn = dataSource.getConnection();) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }

    @SuppressWarnings("rawtypes")
    public List getResultList(String sql, Class<?> resultClass) {
        try (Connection conn = dataSource.getConnection();) {

            ResultSetMapper resultSetMapper = new ResultSetMapper();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            List resultList = resultSetMapper.mapRersultSetToObject(resultSet, resultClass);
            return resultList;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error("Get deptcode mapper Error :" + e.getMessage());
        }
        return new ArrayList<>();
    }

    @SuppressWarnings("rawtypes")
    public void excuBatch(List list, int batchSize, ExcuBatchListener listener) throws SQLException {
        // LogUtil.d(list.size());
        String sql = listener.createSql();
//		LogUtil.d(sql);
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement stmt = null;
            int i = 1;
            for (Object item : list) {
                if (i == 1) {
                    stmt = conn.prepareStatement(sql);
                }
                listener.prepareParameters(stmt, item);
                stmt.addBatch();
                if (i % batchSize == 0) {
                    stmt.executeBatch();
                    conn.commit();
                    logger.error("insert into :" + batchSize);
                    i = 1;
                    continue;
                }
                i++;
            }
            if (i > 1) {
                stmt.executeBatch();
                conn.commit();
                logger.error("insert into :" + (i - 1));
            }
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
            }
            logger.error(e.getMessage());
        } finally {
            conn.close();
        }
    }

    public String crateIgnoreInsertSqlWithOutValue(String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert ignore into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (@SuppressWarnings("unused") String column : columns) {
            sql.append("?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public List getStringList(String sql) {
        try (Connection conn = dataSource.getConnection();) {
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            List resultList = new ArrayList<>();
            while (resultSet.next()) {
                resultList.add(resultSet.getString(1));
            }
            return resultList;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error("Get deptcode mapper Error :" + e.getMessage());
        }
        return new ArrayList<>();
    }

    @SuppressWarnings("rawtypes")
    public Object getResult(String sql, Class<?> resultClass) {
        try (Connection conn = dataSource.getConnection();) {

            ResultSetMapper resultSetMapper = new ResultSetMapper();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet resultSet = ps.executeQuery();
            List resultList = resultSetMapper.mapRersultSetToObject(resultSet, resultClass);
            if (!resultList.isEmpty()) {
                return resultList.get(0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public interface ExcuBatchListener {
        public String createSql();

        public void prepareParameters(PreparedStatement stmt, Object data) throws Exception;
    }
}
