package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.TotalIndex;
import com.sf.gis.java.sds.service.EconomizeTotalIndexService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class EconomizeTotalIndexController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(EconomizeTotalIndexController.class);
    EconomizeTotalIndexService service = new EconomizeTotalIndexService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<TotalIndex> totalIndexRdd = service.loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("totalIndexRdd cnt:{}", totalIndexRdd.count());
            totalIndexRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            //按大区，片区, 班次分组
            JavaRDD<TotalIndex> LineCodeRdd = totalIndexRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getTask_area_code(), o.getTask_area_name(), o.getLine_area(), o.getLine_code(), o.getInc_day()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<TotalIndex> list = Lists.newArrayList(tp._2);
                TotalIndex totalIndex = list.get(0);

                String stat_type = "CLASSID";
                String stat_type_content = totalIndex.getLine_code();

                totalIndex.setStat_type(stat_type);
                totalIndex.setStat_type_content(stat_type_content);

                //任务量
                int task_count = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setTask_count(task_count);


                //执行量
                int exe_count = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "1") || StringUtils.equals(o.getConduct_type(), "2")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_count(exe_count);

                //完全执行量
                int exe_count_1 = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "1")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_count_1(exe_count_1);

                //类似执行量
                int exe_count_2 = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "2")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_count_2(exe_count_2);

                //未执行量
                int no_exe_count = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "3") || StringUtils.equals(o.getConduct_type(), "4")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setNo_exe_count(no_exe_count);

                //达标量
                int db_count = list.stream()
                        .filter(o -> StringUtils.equals(o.getIs_db(), "1") && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setDb_count(db_count);

                //执行达标数
                int exe_db_count = list.stream()
                        .filter(o -> StringUtils.equals(o.getIs_db(), "1") && (StringUtils.equals(o.getConduct_type(), "1") || StringUtils.equals(o.getConduct_type(), "2")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_db_count(exe_db_count);

                //完全执行达标数
                int exe_db_count_1 = list.stream()
                        .filter(o -> StringUtils.equals(o.getIs_db(), "1") && StringUtils.equals(o.getConduct_type(), "1") && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_db_count_1(exe_db_count_1);


                //类似执行达标数
                int exe_db_count_2 = list.stream()
                        .filter(o -> StringUtils.equals(o.getIs_db(), "1") && StringUtils.equals(o.getConduct_type(), "2") && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setExe_db_count_2(exe_db_count_2);

                //未执行达标数
                int noexe_db_count = list.stream()
                        .filter(o -> StringUtils.equals(o.getIs_db(), "1") && (StringUtils.equals(o.getConduct_type(), "3") || StringUtils.equals(o.getConduct_type(), "4")) && StringUtils.isNotEmpty(o.getTask_id()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TotalIndex::getTask_id))), ArrayList::new))
                        .size();
                totalIndex.setNoexe_db_count(noexe_db_count);

                //省钱金额
                double save_money = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "1") || StringUtils.equals(o.getConduct_type(), "2")) && StringUtils.isNotEmpty(o.getDiff_etc_tolls()))
                        .map(o -> Double.valueOf(o.getDiff_etc_tolls()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setSave_money(save_money);

                //耗时(min)
                double time = list.stream()
                        .filter(o -> StringUtils.isNotEmpty(o.getActual_run_time()))
                        .map(o -> Double.valueOf(o.getActual_run_time()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setTime(time);

                //执行耗时(min)
                double exe_time = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "1") || StringUtils.equals(o.getConduct_type(), "2")) && StringUtils.isNotEmpty(o.getActual_run_time()))
                        .map(o -> Double.valueOf(o.getActual_run_time()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setExe_time(exe_time);

                //完全执行耗时(min)
                double exe_time_1 = list.stream()
                        .filter(o -> StringUtils.equals(o.getConduct_type(), "1") && StringUtils.isNotEmpty(o.getActual_run_time()))
                        .map(o -> Double.valueOf(o.getActual_run_time()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setExe_time_1(exe_time_1);

                //类似执行耗时(min)
                double exe_time_2 = list.stream()
                        .filter(o -> StringUtils.equals(o.getConduct_type(), "2") && StringUtils.isNotEmpty(o.getActual_run_time()))
                        .map(o -> Double.valueOf(o.getActual_run_time()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setExe_time_2(exe_time_2);

                //未执行耗时(min)
                double noexe_time = list.stream()
                        .filter(o -> (StringUtils.equals(o.getConduct_type(), "3") || StringUtils.equals(o.getConduct_type(), "4")) && StringUtils.isNotEmpty(o.getActual_run_time()))
                        .map(o -> Double.valueOf(o.getActual_run_time()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));
                totalIndex.setNoexe_time(noexe_time);

                return totalIndex;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("LineCodeRdd cnt:{}", LineCodeRdd.count());
            LineCodeRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            totalIndexRdd.unpersist();



            //插入bdp平台
            if (LineCodeRdd.count() > 0) {
                String sql = String.format("alter table dm_gis.eta_economize_total_index drop if EXISTS partition(inc_day='%s')", date);
                logger.error("sql:{}", sql);
                spark.sql(sql);
                service.saveData(spark, LineCodeRdd, date);
            } else {
                logger.error("按班次分组查无数据");
            }



            //插入数据库
//            if (finalRdd.count() > 0) {
//                if (flag != size) {
//                    //删除数据
//                    service.delete(date);
//                }
//                service.saveToMysql(sc, finalRdd);
//            } else {
//                logger.error("date:{},查无数据!", date);
//            }
            LineCodeRdd.unpersist();
        }
        spark.stop();
    }
}
