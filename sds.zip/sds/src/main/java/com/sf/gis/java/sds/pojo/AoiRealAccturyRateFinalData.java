package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiRealAccturyRateFinalData implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "inc_day")
    private String inc_day;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }
}
