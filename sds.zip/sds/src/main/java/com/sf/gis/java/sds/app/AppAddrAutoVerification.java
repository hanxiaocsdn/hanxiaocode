package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AddrAutoVerification;
import com.sf.gis.java.sds.pojo.GisRdsOmsto;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.scala.base.pojo.Cnt;
import com.sf.gis.scala.base.pojo.StratTime;
import com.sf.gis.scala.base.spark.SparkUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * 任务id：989437（地址自动化数据验证）
 * 研发：01399581（匡仁衡）
 * 业务：01437374（陈晓晓）
 */
public class AppAddrAutoVerification {
    private static final Logger logger = Logger.getLogger(AppAddrAutoVerification.class);
    private static final String atpoi = "http://gis-gw.int.sfdc.com.cn:9080/atpoi/api";
    private static final String ak = "f580ce8ff4f54bd7971f83632712abb5";
    private static final int limitMin = 2000 / 2;

    private static final String account = "01399581";
    private static final String taskId = "989437";
    private static final String taskName = "地址自动化数据验证";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAddrAutoVerification");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取aoi和网点映射关系");
        JavaRDD<CmsAoiSch> cmsRdd = getCmsAoiSch(spark, sc);
        logger.error("获取近三天派件数据");
        JavaRDD<GisRdsOmsto> omsToRdd = getOmsTo(spark, sc, date);

        logger.error("获取aoi数据源");
        JavaRDD<AddrAutoVerification> aoiRdd = getSourceData(sc, "aoi", date);
        logger.error("aoi数据处理");
        JavaRDD<AddrAutoVerification> aoiLastRdd = processAoi(aoiRdd, cmsRdd, omsToRdd, spark);
        logger.error("aoi数据存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_omsto_addr_auto_verification_aoi_di", AddrAutoVerification.class, aoiLastRdd, "inc_day");
        aoiLastRdd.unpersist();

        logger.error("获取网点数据源");
        JavaRDD<AddrAutoVerification> deptRdd = getSourceData(sc, "dept", date);
        logger.error("网点数据处理");
        JavaRDD<AddrAutoVerification> deptLastRdd = processDept(deptRdd, omsToRdd);
        logger.error("dept数据存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_omsto_addr_auto_verification_dept_di", AddrAutoVerification.class, deptLastRdd, "inc_day");
        deptLastRdd.unpersist();
        sc.stop();
    }

    public static JavaRDD<AddrAutoVerification> processDept(JavaRDD<AddrAutoVerification> deptRdd, JavaRDD<GisRdsOmsto> omsToRdd) {
        JavaRDD<AddrAutoVerification> deptLastRdd = deptRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o))
                .leftOuterJoin(omsToRdd.filter(o -> StringUtils.isNotEmpty(o.getFinalzc())).mapToPair(o -> new Tuple2<>(o.getFinalzc(), o)).groupByKey())
                .flatMap(tp -> {
                    AddrAutoVerification o = tp._2._1;
                    ArrayList<AddrAutoVerification> targetList = new ArrayList<>();
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<GisRdsOmsto> list = Lists.newArrayList(tp._2._2.get());
                        ArrayList<GisRdsOmsto> uniqueList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(GisRdsOmsto::getReq_addresseeaddr))), ArrayList::new));
                        if (uniqueList.size() >= 5) {
                            targetList = getNewList(o, uniqueList.subList(0, 5), targetList);
                        } else {
                            targetList = getNewList(o, uniqueList, targetList);
                        }
                    } else {
                        o.setAddr("无");
                        o.setCity_code("无");
                        targetList.add(o);
                    }
                    return targetList.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptLastRdd cnt:" + deptLastRdd.count());
        deptRdd.unpersist();
        omsToRdd.unpersist();
        return deptLastRdd;
    }

    public static JavaRDD<AddrAutoVerification> processAoi(JavaRDD<AddrAutoVerification> aoiRdd, JavaRDD<CmsAoiSch> cmsRdd, JavaRDD<GisRdsOmsto> omsToRdd, SparkSession spark) {
        logger.error("通过aoi获取网点和地址");
        JavaRDD<AddrAutoVerification> addrRdd = aoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                .leftOuterJoin(cmsRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                .mapToPair(tp -> {
                    AddrAutoVerification o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setZno_code(cmsAoiSch.getZno_code());
                    }
                    return new Tuple2<>(o.getAoi_id(), o);
                }).leftOuterJoin(omsToRdd.filter(o -> StringUtils.isNotEmpty(o.getFinalaoiid())).mapToPair(o -> new Tuple2<>(o.getFinalaoiid(), o)).groupByKey())
                .flatMap(tp -> {
                    AddrAutoVerification o = tp._2._1;
                    ArrayList<AddrAutoVerification> targetList = new ArrayList<>();
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<GisRdsOmsto> list = Lists.newArrayList(tp._2._2.get());
                        ArrayList<GisRdsOmsto> uniqueList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(GisRdsOmsto::getReq_addresseeaddr))), ArrayList::new));
                        //如果大于100条，取100条，否则有多少取多少
                        if (uniqueList.size() >= 100) {
                            targetList = getNewList(o, uniqueList.subList(0, 100), targetList);
                        } else {
                            targetList = getNewList(o, uniqueList, targetList);
                        }
                    } else {
                        targetList.add(o);
                    }
                    return targetList.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrRdd cnt:" + addrRdd.count());
        aoiRdd.unpersist();
        cmsRdd.unpersist();

        logger.error("调接口获取楼栋信息");
        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atpoi, ak, addrRdd.count(), 2);
        JavaRDD<AddrAutoVerification> respRdd = addrRdd.repartition(2).mapPartitionsWithIndex(((index, itr) -> {
            ArrayList<AddrAutoVerification> list = new ArrayList<>();
            StratTime stratTime = new StratTime(System.currentTimeMillis());
            Cnt cnt = new Cnt(0);
            while (itr.hasNext()) {
                SparkUtils.limitAkUse(stratTime, cnt, index, limitMin, logger);
                AddrAutoVerification o = itr.next();
                String addr = o.getAddr();
                String city_code = o.getCity_code();
                String aoi_id = o.getAoi_id();
                if (StringUtils.isNotEmpty(addr)) {
                    JSONObject param = new JSONObject();
                    param.put("address", addr);
                    param.put("cityCode", city_code);
                    param.put("aoiId", aoi_id);
                    param.put("requestId", System.currentTimeMillis());
                    param.put("isFloor", "1");
                    String content = HttpInvokeUtil.sendPostHeader(atpoi, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", ak, "utf-8", "utf-8");
                    o.setResp(content);
                    String floorId = "";
                    String buildingId = "";
                    String roomId = "";
                    try {
                        floorId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("floorId");
                        buildingId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("buildingId");
                        roomId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("roomId");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setFloorId(floorId);
                    o.setBuildingId(buildingId);
                    o.setRoomId(roomId);
                }
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("respRdd cnt:" + respRdd.count());
        addrRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        JavaRDD<AddrAutoVerification> aoiLastRdd = respRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey().flatMap(tp -> {
            List<AddrAutoVerification> list = Lists.newArrayList(tp._2);
            //最终提供5条，优先楼层，其次楼栋（有楼层一定有楼栋）
            List<AddrAutoVerification> floorIdList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getFloorId())).collect(Collectors.toList());
            List<AddrAutoVerification> otherFloorIdList = list.stream().filter(o -> StringUtils.isEmpty(o.getFloorId()) && StringUtils.isNotEmpty(o.getBuildingId())).collect(Collectors.toList());
            int floorCnt = floorIdList.size();
            int otherCnt = otherFloorIdList.size();
            if (floorCnt == 0) {
                List<AddrAutoVerification> buildingList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getBuildingId())).collect(Collectors.toList());
                int buildingCnt = buildingList.size();
                if (buildingCnt >= 5) {
                    return buildingList.subList(0, 5).iterator();
                } else if (buildingCnt > 0) {
                    return buildingList.subList(0, buildingCnt).iterator();
                } else {
                    return list.stream().peek(o -> {
                        o.setFloorId("无");
                        o.setBuildingId("无");
                        o.setRoomId("无");
                    }).iterator();
                }
            } else if (floorCnt < 5) {
                List<AddrAutoVerification> floorIdCntList = floorIdList.subList(0, floorCnt);
                int needCnt = 5 - floorCnt;
                if (otherCnt >= needCnt) {
                    List<AddrAutoVerification> needList = otherFloorIdList.subList(0, needCnt);
                    floorIdCntList.addAll(needList);
                    return floorIdCntList.iterator();
                } else if (otherCnt > 0) {
                    List<AddrAutoVerification> needList = otherFloorIdList.subList(0, otherCnt);
                    floorIdCntList.addAll(needList);
                    return floorIdCntList.iterator();
                } else {
                    return floorIdCntList.iterator();
                }
            } else {
                return floorIdList.subList(0, 5).iterator();
            }
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiLastRdd cnt:" + aoiLastRdd.count());
        respRdd.unpersist();
        return aoiLastRdd;
    }

    public static ArrayList<AddrAutoVerification> getNewList(AddrAutoVerification o, List<GisRdsOmsto> list, ArrayList<AddrAutoVerification> targetList) {
        List<GisRdsOmsto> collect = list.stream().peek(t -> {
            String req_addresseeaddr = t.getReq_addresseeaddr();
            String req_destcitycode = t.getReq_destcitycode();
            String finalzc = t.getFinalzc();
            AddrAutoVerification newO = new AddrAutoVerification();
            try {
                BeanUtils.copyProperties(newO, o);
                newO.setAddr(req_addresseeaddr);
                newO.setCity_code(req_destcitycode);
                newO.setDept_code(finalzc);
                targetList.add(newO);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).collect(Collectors.toList());
        return targetList;
    }

    public static JavaRDD<GisRdsOmsto> getOmsTo(SparkSession spark, JavaSparkContext sc, String date) {
        String oms_to_sql = String.format("select finalaoiid,finalzc,req_addresseeaddr,req_destcitycode from dm_gis.gis_rds_omsto where inc_day between '%s' and '%s' and (req_addresseeaddr is not null and req_addresseeaddr <>'')", DateUtil.getDaysBefore(date, 2), date);
        JavaRDD<GisRdsOmsto> omsToRdd = DataUtil.loadData(spark, sc, oms_to_sql, GisRdsOmsto.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("omsToRdd cnt:" + omsToRdd.count());
        return omsToRdd;
    }

    public static JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String cms_sql = "select aoi_id,zno_code from dm_gis.cms_aoi_sch";
        JavaRDD<CmsAoiSch> cmsRdd = DataUtil.loadData(spark, sc, cms_sql, CmsAoiSch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:" + cmsRdd.count());
        return cmsRdd;
    }

    public static JavaRDD<AddrAutoVerification> getSourceData(JavaSparkContext sc, String tag, String date) {
        String path = "";
        if ("aoi".equals(tag)) {
            path = "hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/ld_offline_aoi.csv";
        } else {
            path = "hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/ld_offline_dept.csv";
        }

        JavaRDD<String> strRdd = sc.textFile(path).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("strRdd cnt:" + strRdd.count());
        String header = strRdd.first();
        logger.error("header:" + header);

        JavaRDD<AddrAutoVerification> rdd = strRdd.filter(o -> !StringUtils.equals(o, header)).map(line -> {
            AddrAutoVerification o = new AddrAutoVerification();
            String[] split = line.split(",");

            String area_name = "";
            String area_code = "";
            String filed = "";
            try {
                area_name = split[0];
            } catch (Exception e) {
//                e.printStackTrace();
            }

            try {
                area_code = split[1];
            } catch (Exception e) {
//                e.printStackTrace();
            }

            try {
                filed = split[2];
            } catch (Exception e) {
//                e.printStackTrace();
            }
            o.setArea_name(area_name);
            o.setArea_code(area_code);

            if ("aoi".equals(tag)) {
                o.setAoi_id(filed);
            } else {
                o.setDept_code(filed);
            }
            o.setInc_day(date);
            return o;
        }).filter(o -> StringUtils.isNotEmpty("aoi".equals(tag) ? o.getAoi_id() : o.getDept_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        strRdd.unpersist();
        return rdd;
    }
}
