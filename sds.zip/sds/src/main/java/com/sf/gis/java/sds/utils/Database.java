package com.sf.gis.java.sds.utils;



import java.sql.*;
//import oracle.sql.*;
import java.io.*;
import java.util.*;
import java.util.Date;

import javax.naming.Context;
import javax.sql.DataSource;

public class Database implements Serializable{
	//private String driver, url, userName, passWord;
	String driver = "com.mysql.jdbc.Driver";
	String url = "jdbc:mysql://16.6.10.90:3306/yjdb?user=appuser&amp;password=Iop**9521&amp;useUnicode=true&amp;characterEncoding=UTF-8&amp;characterSetResults=UTF-8";
	public String userName = "appuser";
	String passWord = "Iop**9521";
	public static Properties prop = null;
	private Connection conn = null;
	private PreparedStatement stmt = null, stmtUpd = null;
	private ResultSet rs = null;
	private ResultSetMetaData rsmd = null;

	private Context ctx;
	private String jndiName;

	public static final int hoursLate = 0;
	
	public Database(Context ctx, String jndiName) throws Exception {
		this.ctx = ctx;
		this.jndiName = jndiName;
		initConnection(ctx, jndiName);
	}

	public Database() throws Exception{
		//if(prop==null){
			InputStream in = getClass().getResourceAsStream("dbconn.properties");
			
			prop = new Properties();
			prop.load(in);
			this.driver = prop.getProperty("driver");
			this.url = prop.getProperty("url");
			this.userName = prop.getProperty("userName");
			this.passWord = prop.getProperty("passWord");
		//}
		initConnection();
	}
	
	public Database(String driver, String url, String userName, String passWord) {
		
		this.driver = driver;
		this.url = url;
		this.userName = userName;
		this.passWord = passWord;
		initConnection();
	}

	public Connection getConnection() {
		return conn;
	}

	private void initConnection() {
		try {
			if (this.jndiName != null) {
				initConnection(ctx, jndiName);
				return;
			}
			Class.forName(driver);
			conn = DriverManager.getConnection(url, userName, passWord);
			conn.setAutoCommit(false);
			//System.out.println("Database started.");
		} catch (Exception e) {
			// System.out.println("driver:" + driver + " url:" + url +
			// " username:" + userName + " password:" + passWord);
			System.out.println(e);
			e.printStackTrace();
			closeConnection();
		}
	}

	private void initConnection(Context ctx, String jndiName) throws Exception {
		try {
			DataSource ds = (DataSource) ctx
					.lookup("java:comp/env/" + jndiName);
			conn = ds.getConnection();
			conn.setAutoCommit(false);
		} catch (Exception e) {
			System.out.println(e);
			closeConnection();
			throw e;
		}
	}

	/** 关闭数据库连接 */
	public void closeConnection() {
		try {
			this.closeResultSet();
			this.closeUpdateStatement();
			if (conn != null && !conn.isClosed())
				conn.close();
			conn = null;
			//System.out.println("Database stoped.");
		} catch (SQLException e) {
			System.out.println("Error in closeConnection()\n" + e);
		}
	}

	public void closeResultSet() {
		try {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			rs = null;
			rsmd = null;
			stmt = null;
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	public void closeUpdateStatement() {
		try {
			if (stmtUpd != null)
				stmtUpd.close();
			stmtUpd = null;
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	protected void finalize() throws Throwable {
		closeConnection();
		super.finalize();
	}

	/** 获取查询结果记录集 */
	public ResultSet executeQuery(String sql) throws Exception {
		try {
			if (conn == null || conn.isClosed())
				initConnection();
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			return rs;
		} catch (SQLException e) {
			System.out.println("Error in executeQuery(\"" + sql + "\")\n" + e);
			closeConnection();
			throw e;
		}
	}

	/** 获取二维矢量查询结果 */
	public Vector getValue(String sql) throws Exception {
		return getValue(sql,true);
	}

	public Vector getValue(String sql,boolean debug) throws Exception {
		if(debug)
			System.out.println(sql);
		Vector table = new Vector();
		int c = 0;
		try {
			rs = this.executeQuery(sql);
			rsmd = rs.getMetaData();
			while (rs.next()) {
				Vector row = new Vector();
				for (int i = 0; i < rsmd.getColumnCount(); i++) {
					String tmp = rs.getString(i + 1);
					if (tmp == null)
						tmp = "";
					row.addElement(tmp);
				}
				table.addElement(row);
				c++;
				if(c%100==0)System.out.print(".");
				if(c%10000==0)System.out.println();
			}
			if(c>100 && c%10000!=0) System.out.println();
			this.closeResultSet();
		} catch (Exception e) {
			this.closeResultSet();
			System.out.println("Error in getValue()" + "\n" + sql + "\n" + e);
			throw e;
		}
		return table;
	}

	public String getJsonValue(String sql) throws Exception {
		double d0 = new Date().getTime();
		StringBuilder sb = new StringBuilder();
		System.out.println(sql);

		try {
			rs = this.executeQuery(sql);
			rsmd = rs.getMetaData();
			sb.append("{\"metadata\":[");
			for (int i = 0; i < rsmd.getColumnCount(); i++) {
				String column = rsmd.getColumnLabel(i + 1);
				int ct = rsmd.getColumnType(i + 1);
				int lt = rsmd.getColumnDisplaySize(i + 1);
				String dataType = "string";
				if (ct == 12) {
					dataType = "string";
				} else
					dataType = "double";
				if (i != 0)
					sb.append(",");
				sb.append("{\"name\":\"" + column + "\",\"type\":\"xs:"
						+ dataType + "\",\"length\":\"" + lt + "\"}");
			}
			sb.append("],\"data\":[");

			int m = 0;

			while (rs.next()) {
				if (m != 0)
					sb.append(",");
				m++;
				sb.append("{");
				for (int i = 0; i < rsmd.getColumnCount(); i++) {
					String column = rsmd.getColumnLabel(i + 1);
					String value = rs.getString(i + 1);
					if (value == null)
						value = "";
					if (i != 0)
						sb.append(",");
					sb.append("\"" + column + "\":\"" + value + "\"");
				}
				sb.append("}");
			}
			this.closeResultSet();
			double d1 = new Date().getTime();
			sb.append("],\"timeCost\":\"" + (d1 - d0) + "\",\"records\":\"" + m
					+ "\"}");
		} catch (Exception e) {
			this.closeResultSet();
			System.out.println("Error in getValue()" + "\n" + sql + "\n" + e);
			throw e;
		}

		return sb.toString();
	}

	/** 获取一个查询结果值 */
	public String getOneValue(String sql) throws Exception {
		Vector table = this.getValue(sql);
		return table.size() == 0 ? "" : ((Vector) (table.elementAt(0)))
				.elementAt(0).toString().trim();
	}

	/** 获取一行查询结果值 */
	public Vector getOneRow(String sql) throws Exception {
		return getOneRow(sql,true);
	}
	public Vector getOneRow(String sql,boolean debug) throws Exception {
		Vector table = this.getValue(sql,debug);
		return table.size() == 0 ? new Vector()
				: ((Vector) (table.elementAt(0)));
	}

	/** 获取一列查询结果值 */
	public Vector getOneColumn(String sql) throws Exception {
		Vector table = this.getValue(sql);
		Vector row = new Vector();
		for (int i = 0; i < table.size(); i++) {
			row.addElement(((Vector) (table.elementAt(i))).elementAt(0));
		}
		return row;
	}

	/** 返回列名 */
	public Vector getColumnNames(String sql) throws Exception {
		Vector row = new Vector();
		try {
			rs = this.executeQuery(sql);
			rsmd = rs.getMetaData();
			int columnCount = rsmd.getColumnCount();
			for (int i = 1; i <= columnCount; i++) {
				row.addElement(rsmd.getColumnName(i).trim());
			}
			rsmd = null;
			closeResultSet();
		} catch (Exception e) {
			closeResultSet();
			closeConnection();
			System.out.println("Error in getColumnNames(): " + e);
			throw e;
		}
		return row;
	}

	/** 执行添加、修改、删除 */
    public int executeUpdate(String sql) throws Exception {
        return executeUpdate(sql,1,0,true);
    }

	public int executeUpdateSilent(String sql) throws Exception {
		return executeUpdate(sql,1,0,false);
	}

	public int executeUpdate(String sql,int tryTimes,int currentTry) throws Exception {
		return executeUpdate(sql,tryTimes,currentTry,true);
	}

	public int executeUpdate(String sql,int tryTimes,int currentTry,boolean debug) throws Exception{
        long tm0 = new Date().getTime();
        SQLException ee = null;
	    if(currentTry<tryTimes){
	        if(currentTry>0)
                System.out.println("【retry】"+currentTry);
            if(debug)
            	System.out.println(sql);
            int returnValue = 0;
            try {
                if (conn == null || conn.isClosed())
                    initConnection();
                stmtUpd = conn.prepareStatement(sql);
                returnValue = stmtUpd.executeUpdate();
                conn.commit();
                closeUpdateStatement();
                long tm1 = new Date().getTime();
                if(debug){

				}
                    //System.out.println("SQL耗时："+Util.formatTime(tm1-tm0,true));
            } catch (SQLException e) {
				System.err.println("**********************************************************************");
                System.err.println("Error in executeUpdate(): " + e + sql + "\n");
				System.err.println("**********************************************************************");
                try {
                    closeUpdateStatement();
                    if(conn!=null && !conn.isClosed()){
                        conn.rollback();
                        conn.close();
                        initConnection();
                    }
                } catch (SQLException ex) {
                    System.out.println(ex);
                    throw ex;
                }
                ee = e;
                return executeUpdate(sql,tryTimes,currentTry+1,debug);
            }
            return returnValue;
        }else if(ee!=null){
            throw ee;
        }else
            throw new Exception("Database.executeUpdate() faild 【"+tryTimes+"】 times:\n"+sql);

    }

	/** 返回表的主键名 */
	public Vector getPrimaryKeyNames(String table) throws Exception {
		Vector PrimaryKeyNames = new Vector();
		try {
			if (conn == null)
				initConnection();
			rs = conn.getMetaData().getPrimaryKeys(null, null,
					table.toUpperCase());
			while (rs.next())
				PrimaryKeyNames.addElement(rs.getString(4));
			closeResultSet();
			// closeConnection();
		} catch (Exception e) {
			closeResultSet();
			closeConnection();
			System.out.println(e);
			throw e;
		}
		return PrimaryKeyNames;
	}

	/** 返回指定的表列值被保存到数据库时的格式 */
	public String dbRepresentation(String tableName, String columnName,
			Object value) throws Exception {
		if (value == null || value.toString().equals(""))
			return "null";
		Class type = this.getColumnClass(tableName, columnName);
		if (type == Number.class || type == Double.class
				|| type == Integer.class
				|| type == Long.class) {
			try {
				Double.parseDouble(value.toString());
				return value.toString();
			} catch (NumberFormatException ex) {
				return "'" + value.toString() + "'";
			}
		} else if (type == Boolean.class) {
			if (value.toString().equals("0") || value.toString().equals("1"))
				return value.toString();
			else
				return "'" + value.toString() + "'";
		} else if (type == String.class || type == Object.class) {
			return "'" + value.toString() + "'";
		} else if (type == java.sql.Date.class
				|| type == Timestamp.class) {
			if (value.toString().length() >= 10)
				return "TO_DATE('" + value.toString().substring(0, 10)
						+ "', 'YYYY-MM-DD')";
			return "NULL";
			// return "'" + value.toString() + "'";
		}
		return "";
	}

	/** 返回列类型 */
	public Class getColumnClass(String tableName, String columnName)
			throws Exception {
		int type = 0;
		String sql = "SELECT \"" + columnName + "\" FROM " + tableName + " WHERE 1=2";
		rs = this.executeQuery(sql);
		try {
			type = rs.getMetaData().getColumnType(1);
			closeResultSet();
		} catch (SQLException e) {
			closeResultSet();
			closeConnection();
			System.out.println("Error in getColumnClass(): " + e);
			throw e;
		}
		switch (type) {
		case Types.CHAR:
		case Types.VARCHAR:
		case Types.LONGVARCHAR:
			return String.class;
		case Types.NUMERIC:
			return Number.class;
		case Types.BIT:
			return Boolean.class;
		case Types.TINYINT:
		case Types.SMALLINT:
		case Types.INTEGER:
			return Integer.class;
		case Types.BIGINT:
			return Long.class;
		case Types.FLOAT:
		case Types.DOUBLE:
			return Double.class;
		case Types.DATE:
			return java.sql.Date.class;
		case Types.TIMESTAMP:
			return Timestamp.class;
		default:
			return Object.class;
		}
	}

	/**
	 * 获取BLOB对象,锁定,生成本地文件 ,用于下载。 sql like: SELECT DATA FROM BLOBTEST WHERE
	 * ID='111' FOR UPDATE
	 * */
//	public synchronized File getBLOBFile(String sql, String fileName)
//			throws Exception {
//		try {
//			if (conn == null || conn.isClosed())
//				this.initConnection();
//			stmt = conn.prepareStatement(sql);
//			rs = stmt.executeQuery();
//			File outfile = new File(fileName);
//			while (rs.next()) {
//				oracle.sql.BLOB blob = (oracle.sql.BLOB) rs.getBlob(1);
//				if (blob == null)
//					continue;
//				BufferedOutputStream out = new BufferedOutputStream(
//						new FileOutputStream(outfile));
//				BufferedInputStream in = new BufferedInputStream(
//						blob.getBinaryStream());
//
//				int target = (int) blob.length();
//				System.out.println("blob size: " + target);
//				int c;
//				while ((c = in.read()) != -1) {
//					out.write(c);
//				}
//				in.close();
//				out.close();
//			}
//			conn.commit();
//			this.closeResultSet();
//			return outfile;
//		} catch (Exception ex) {
//			System.out.println(ex);
//			conn.rollback();
//			this.closeResultSet();
//			throw ex;
//		}
//	}
//
//	public byte[] getBLOBFile(String sql) throws Exception {
//		try {
//			if (conn == null || conn.isClosed())
//				this.initConnection();
//			stmt = conn.prepareStatement(sql);
//			rs = stmt.executeQuery();
//			byte[] datas = null;
//			if (rs.next()) {
//				oracle.sql.BLOB blob = (oracle.sql.BLOB) rs.getBlob(1);
//				BufferedInputStream in = new BufferedInputStream(
//						blob.getBinaryStream());
//
//				int size = (int) blob.length();
//				System.out.println("blob size: " + size);
//				datas = new byte[size];
//				in.read(datas, 0, size);
//				in.close();
//			}
//			conn.commit();
//			this.closeResultSet();
//			return datas;
//		} catch (Exception ex) {
//			System.out.println(ex);
//			conn.rollback();
//			this.closeResultSet();
//			throw ex;
//		}
//	}
//
//	/** 创建一个新的 Blob ,用指定的文件填充 */
//	public void createBLOB(String insertSql, String selectSql, File file)
//			throws Exception {
//		try {
//			if (conn == null || conn.isClosed())
//				this.initConnection();
//			Statement stmtupd = conn.createStatement();
//			stmtupd.executeUpdate(insertSql);
//			conn.commit();
//			Statement stmtque = conn.createStatement();
//			ResultSet rs = stmtque.executeQuery(selectSql);
//			if (rs.next()) {
//				BLOB blob = (BLOB) rs.getBlob(1);
//				BufferedInputStream in = new BufferedInputStream(
//						new FileInputStream(file));
//				OutputStream outstream = blob.getBinaryOutputStream();
//				int i = 0;
//				int length = (int) file.length();
//				int chunk = 1024;
//				if (chunk > length)
//					chunk = length;
//				byte[] data = new byte[chunk];
//				while (i < length) {
//					in.read(data, 0, chunk);
//					outstream.write(data, 0, chunk);
//					i += chunk;
//					if (length - i < chunk)
//						chunk = (int) length - i;
//				}
//				outstream.close();
//				in.close();
//			}
//			conn.commit();
//			stmtupd.close();
//			stmtque.close();
//			rs.close();
//		} catch (Exception ex) {
//			System.out.println("Error in createBLOB()" + ex);
//			try {
//				conn.rollback();
//			} catch (Exception exx) {
//				System.out.println(exx);
//				throw exx;
//			}
//			throw ex;
//		}
//	}
//
//	public void createBLOB(String insertSql, String selectSql, byte[] datas)
//			throws Exception {
//		try {
//			if (conn == null || conn.isClosed())
//				this.initConnection();
//			Statement stmtupd = conn.createStatement();
//			stmtupd.executeUpdate(insertSql);
//			conn.commit();
//			Statement stmtque = conn.createStatement();
//			ResultSet rs = stmtque.executeQuery(selectSql);
//			if (rs.next()) {
//				BLOB blob = (BLOB) rs.getBlob(1);
//				OutputStream outstream = blob.getBinaryOutputStream();
//				outstream.write(datas, 0, datas.length);
//				outstream.close();
//			}
//			conn.commit();
//			stmtupd.close();
//			stmtque.close();
//			rs.close();
//		} catch (Exception ex) {
//			System.out.println("Error in createBLOB()" + ex);
//			try {
//				conn.rollback();
//			} catch (Exception exx) {
//				System.out.println(exx);
//				throw exx;
//			}
//			throw ex;
//		}
//	}
//
//	// 新建 清空 删除一条包含BLOB对象的记录/
//	public int updateBLOB(String sql) throws Exception {
//		int returnValue = -1;
//		try {
//			stmtUpd = conn.prepareStatement(sql);
//			returnValue = stmtUpd.executeUpdate();
//			conn.commit();
//			closeUpdateStatement();
//		} catch (Exception e) {
//			System.out.println(e);
//			try {
//				closeUpdateStatement();
//				conn.rollback();
//			} catch (SQLException ex) {
//				System.out.println(ex);
//				throw ex;
//			}
//			throw e;
//		}
//		return returnValue;
//	}

	public static void main(String[] args) {
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		String uid = "olasuser";
		String pwd = "olasuser";
		Database db = new Database(driver, url, uid, pwd);
		try {
			// File f =
			// db.getBLOBFile("select modelword from fzjc_result_report where objectid = 3226 for update","c:\\test.doc");
			Vector v = db.getValue("select * from customer");
			System.out.println(v.size());
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		db.closeConnection();
	}
}
