package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SrcData4RuralXyAoi implements Serializable {
    @Column(name = "network_id")
    private String networkId;
    @Column(name = "parent_id")
    private String parentId;
    @Column(name = "status")
    private String status;
    @Column(name = "network_name")
    private String networkName;
    @Column(name = "abbr_name")
    private String abbrName;
    @Column(name = "type")
    private String type;
    @Column(name = "province_name")
    private String provinceName;
    @Column(name = "city_name")
    private String cityName;
    @Column(name = "district_name")
    private String districtName;
    @Column(name = "address")
    private String address;
    @Column(name = "town_name")
    private String townName;
    @Column(name = "contact")
    private String contact;
    @Column(name = "mobile")
    private String mobile;
    @Column(name = "network_no")
    private String networkNo;
    @Column(name = "channel_type")
    private String channelType;
    @Column(name = "approval_status")
    private String approvalStatus;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "del_flag")
    private String delFlag;
    @Column(name = "period_time")
    private String periodTime;
    @Column(name = "temporary_status")
    private String temporaryStatus;
    @Column(name = "own_code")
    private String ownCode;
    @Column(name = "business_type")
    private String businessType;
    @Column(name = "network_job_no")
    private String networkJobNo;
    @Column(name = "network_proxy_no")
    private String networkProxyNo;
    @Column(name = "region_type_service")
    private String regionTypeService;
    @Column(name = "emp_code")
    private String empCode;
    @Column(name = "is_house_estate_outsource")
    private String isHouseEstateOutsource;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "aoicode")
    private String aoicode;
    @Column(name = "inc_day")
    private String incDay;

    public String getNetworkId() {
        return networkId;
    }

    public void setNetworkId(String networkId) {
        this.networkId = networkId;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNetworkName() {
        return networkName;
    }

    public void setNetworkName(String networkName) {
        this.networkName = networkName;
    }

    public String getAbbrName() {
        return abbrName;
    }

    public void setAbbrName(String abbrName) {
        this.abbrName = abbrName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTownName() {
        return townName;
    }

    public void setTownName(String townName) {
        this.townName = townName;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getNetworkNo() {
        return networkNo;
    }

    public void setNetworkNo(String networkNo) {
        this.networkNo = networkNo;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }

    public String getPeriodTime() {
        return periodTime;
    }

    public void setPeriodTime(String periodTime) {
        this.periodTime = periodTime;
    }

    public String getTemporaryStatus() {
        return temporaryStatus;
    }

    public void setTemporaryStatus(String temporaryStatus) {
        this.temporaryStatus = temporaryStatus;
    }

    public String getOwnCode() {
        return ownCode;
    }

    public void setOwnCode(String ownCode) {
        this.ownCode = ownCode;
    }

    public String getBusinessType() {
        return businessType;
    }

    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }

    public String getNetworkJobNo() {
        return networkJobNo;
    }

    public void setNetworkJobNo(String networkJobNo) {
        this.networkJobNo = networkJobNo;
    }

    public String getNetworkProxyNo() {
        return networkProxyNo;
    }

    public void setNetworkProxyNo(String networkProxyNo) {
        this.networkProxyNo = networkProxyNo;
    }

    public String getRegionTypeService() {
        return regionTypeService;
    }

    public void setRegionTypeService(String regionTypeService) {
        this.regionTypeService = regionTypeService;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getIsHouseEstateOutsource() {
        return isHouseEstateOutsource;
    }

    public void setIsHouseEstateOutsource(String isHouseEstateOutsource) {
        this.isHouseEstateOutsource = isHouseEstateOutsource;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getAoicode() {
        return aoicode;
    }

    public void setAoicode(String aoicode) {
        this.aoicode = aoicode;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }



    @Override
    public String toString() {
        return "SrcData4RuralXyAoi{" +
                "networkId='" + networkId + '\'' +
                ", parentId='" + parentId + '\'' +
                ", status='" + status + '\'' +
                ", networkName='" + networkName + '\'' +
                ", abbrName='" + abbrName + '\'' +
                ", type='" + type + '\'' +
                ", provinceName='" + provinceName + '\'' +
                ", cityName='" + cityName + '\'' +
                ", districtName='" + districtName + '\'' +
                ", address='" + address + '\'' +
                ", townName='" + townName + '\'' +
                ", contact='" + contact + '\'' +
                ", mobile='" + mobile + '\'' +
                ", networkNo='" + networkNo + '\'' +
                ", channelType='" + channelType + '\'' +
                ", approvalStatus='" + approvalStatus + '\'' +
                ", longitude='" + longitude + '\'' +
                ", latitude='" + latitude + '\'' +
                ", delFlag='" + delFlag + '\'' +
                ", periodTime='" + periodTime + '\'' +
                ", temporaryStatus='" + temporaryStatus + '\'' +
                ", ownCode='" + ownCode + '\'' +
                ", businessType='" + businessType + '\'' +
                ", networkJobNo='" + networkJobNo + '\'' +
                ", networkProxyNo='" + networkProxyNo + '\'' +
                ", regionTypeService='" + regionTypeService + '\'' +
                ", empCode='" + empCode + '\'' +
                ", isHouseEstateOutsource='" + isHouseEstateOutsource + '\'' +
                ", aoiid='" + aoiid + '\'' +
                ", aoicode='" + aoicode + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
