package com.sf.gis.java.sds.pojo.aoicompletion;

import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class EdcsWaybillContentSwsKafka implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "original_zone_code")
    private String original_zone_code;
    @Column(name = "destination_zone_code")
    private String destination_zone_code;
    @Column(name = "emp_code")
    private String emp_code;
    @Column(name = "takeover_tm")
    private String takeover_tm;
    @Column(name = "sending_tm")
    private String sending_tm;
    @Column(name = "aoi_id")
    private String initial_original_aoi_id;

    private String initial_original_aoi_code;
    private String initial_original_aoi_area_code;
    private String initial_original_fa_type;

    private String original_city_code;
    private String destination_city_code;

    private String sourceWaybillNo;
    private String customerAcctCode;
    private String orderNo;
    private String waybillnoOrderNo;

    private String addr;
    private String compName;
    private String mobile;
    private String phone;
    private String city;
    private String county;
    private String cityCode;
    private String province;

    private boolean signReceipt;

    private String finalaoicode;
    private String finalzc;


    private int aoi_size;
    private List<CmsAoiSch> list;

    private String before10min;
    private String after10min;
    private String barscantmstd;

    private String eventlng;
    private String eventlat;

    private String src_lgt;
    private String src_lat;

    private String position_name;
    private String type_code;
    private String dept_code;
    private String parent_dept_code;

    private String emap_lng;
    private String emap_lat;

    private String exts;
    private String ext24;
    private String ext25;

    private String lastAoiid;
    private String tag;

    private String aoi_code;
    private String fa_type;
    private String aoi_area_code;

//    private String waybill_type;

    private String event_aoiid;
    private String aoi_name;

    private String new_dept_code;

    public String getNew_dept_code() {
        return new_dept_code;
    }

    public void setNew_dept_code(String new_dept_code) {
        this.new_dept_code = new_dept_code;
    }

    public String getParent_dept_code() {
        return parent_dept_code;
    }

    public void setParent_dept_code(String parent_dept_code) {
        this.parent_dept_code = parent_dept_code;
    }

    public String getInitial_original_aoi_id() {
        return initial_original_aoi_id;
    }

    public void setInitial_original_aoi_id(String initial_original_aoi_id) {
        this.initial_original_aoi_id = initial_original_aoi_id;
    }

    public String getInitial_original_aoi_code() {
        return initial_original_aoi_code;
    }

    public void setInitial_original_aoi_code(String initial_original_aoi_code) {
        this.initial_original_aoi_code = initial_original_aoi_code;
    }

    public String getInitial_original_aoi_area_code() {
        return initial_original_aoi_area_code;
    }

    public void setInitial_original_aoi_area_code(String initial_original_aoi_area_code) {
        this.initial_original_aoi_area_code = initial_original_aoi_area_code;
    }

    public String getInitial_original_fa_type() {
        return initial_original_fa_type;
    }

    public void setInitial_original_fa_type(String initial_original_fa_type) {
        this.initial_original_fa_type = initial_original_fa_type;
    }

    public String getEvent_aoiid() {
        return event_aoiid;
    }

    public void setEvent_aoiid(String event_aoiid) {
        this.event_aoiid = event_aoiid;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getSourceWaybillNo() {
        return sourceWaybillNo;
    }

    public void setSourceWaybillNo(String sourceWaybillNo) {
        this.sourceWaybillNo = sourceWaybillNo;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCompName() {
        return compName;
    }

    public void setCompName(String compName) {
        this.compName = compName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getSending_tm() {
        return sending_tm;
    }

    public void setSending_tm(String sending_tm) {
        this.sending_tm = sending_tm;
    }

    public String getDestination_city_code() {
        return destination_city_code;
    }

    public void setDestination_city_code(String destination_city_code) {
        this.destination_city_code = destination_city_code;
    }

    public String getDestination_zone_code() {
        return destination_zone_code;
    }

    public void setDestination_zone_code(String destination_zone_code) {
        this.destination_zone_code = destination_zone_code;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getExt24() {
        return ext24;
    }

    public void setExt24(String ext24) {
        this.ext24 = ext24;
    }

    public String getExt25() {
        return ext25;
    }

    public void setExt25(String ext25) {
        this.ext25 = ext25;
    }

    public String getExts() {
        return exts;
    }

    public void setExts(String exts) {
        this.exts = exts;
    }

    public String getEmap_lng() {
        return emap_lng;
    }

    public void setEmap_lng(String emap_lng) {
        this.emap_lng = emap_lng;
    }

    public String getEmap_lat() {
        return emap_lat;
    }

    public void setEmap_lat(String emap_lat) {
        this.emap_lat = emap_lat;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getType_code() {
        return type_code;
    }

    public void setType_code(String type_code) {
        this.type_code = type_code;
    }

    public String getSrc_lgt() {
        return src_lgt;
    }

    public void setSrc_lgt(String src_lgt) {
        this.src_lgt = src_lgt;
    }

    public String getSrc_lat() {
        return src_lat;
    }

    public void setSrc_lat(String src_lat) {
        this.src_lat = src_lat;
    }

    public String getEventlng() {
        return eventlng;
    }

    public void setEventlng(String eventlng) {
        this.eventlng = eventlng;
    }

    public String getEventlat() {
        return eventlat;
    }

    public void setEventlat(String eventlat) {
        this.eventlat = eventlat;
    }

    public String getWaybillnoOrderNo() {
        return waybillnoOrderNo;
    }

    public void setWaybillnoOrderNo(String waybillnoOrderNo) {
        this.waybillnoOrderNo = waybillnoOrderNo;
    }

    public String getBefore10min() {
        return before10min;
    }

    public void setBefore10min(String before10min) {
        this.before10min = before10min;
    }

    public String getAfter10min() {
        return after10min;
    }

    public void setAfter10min(String after10min) {
        this.after10min = after10min;
    }

    public String getBarscantmstd() {
        return barscantmstd;
    }

    public void setBarscantmstd(String barscantmstd) {
        this.barscantmstd = barscantmstd;
    }

    public int getAoi_size() {
        return aoi_size;
    }

    public void setAoi_size(int aoi_size) {
        this.aoi_size = aoi_size;
    }

    public List<CmsAoiSch> getList() {
        return list;
    }

    public void setList(List<CmsAoiSch> list) {
        this.list = list;
    }

    public String getPosition_name() {
        return position_name;
    }

    public void setPosition_name(String position_name) {
        this.position_name = position_name;
    }

    public String getCustomerAcctCode() {
        return customerAcctCode;
    }

    public void setCustomerAcctCode(String customerAcctCode) {
        this.customerAcctCode = customerAcctCode;
    }

    public String getLastAoiid() {
        return lastAoiid;
    }

    public void setLastAoiid(String lastAoiid) {
        this.lastAoiid = lastAoiid;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public boolean isSignReceipt() {
        return signReceipt;
    }

    public void setSignReceipt(boolean signReceipt) {
        this.signReceipt = signReceipt;
    }

    public String getOriginal_city_code() {
        return original_city_code;
    }

    public void setOriginal_city_code(String original_city_code) {
        this.original_city_code = original_city_code;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getOriginal_zone_code() {
        return original_zone_code;
    }

    public void setOriginal_zone_code(String original_zone_code) {
        this.original_zone_code = original_zone_code;
    }

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getTakeover_tm() {
        return takeover_tm;
    }

    public void setTakeover_tm(String takeover_tm) {
        this.takeover_tm = takeover_tm;
    }
}
