package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAoiChangeTaskDetail implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "addr")
    private String addr;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "tag")
    private String tag;
    @Column(name = "type")
    private String type;
    @Column(name = "inc_day")
    private String inc_day;

    private int temp_freq;

    public int getTemp_freq() {
        return temp_freq;
    }

    public void setTemp_freq(int temp_freq) {
        this.temp_freq = temp_freq;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
