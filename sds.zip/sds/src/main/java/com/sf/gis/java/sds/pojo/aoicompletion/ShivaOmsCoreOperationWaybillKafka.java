package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ShivaOmsCoreOperationWaybillKafka implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "order_no")
    private String order_no;

    @Column(name = "sender_comp_name")
    private String sender_comp_name;
    @Column(name = "sender_addr")
    private String sender_addr;
    @Column(name = "sender_province")
    private String sender_province;
    @Column(name = "sender_city")
    private String sender_city;
    @Column(name = "sender_city_code")
    private String sender_city_code;
    @Column(name = "sender_area")
    private String sender_area;
    @Column(name = "sender_phone")
    private String sender_phone;
    @Column(name = "sender_mobile")
    private String sender_mobile;

    @Column(name = "receiver_comp_name")
    private String receiver_comp_name;
    @Column(name = "receiver_addr")
    private String receiver_addr;
    @Column(name = "receiver_province")
    private String receiver_province;
    @Column(name = "receiver_city")
    private String receiver_city;
    @Column(name = "receiver_city_code")
    private String receiver_city_code;
    @Column(name = "receiver_area")
    private String receiver_area;
    @Column(name = "receiver_phone")
    private String receiver_phone;
    @Column(name = "receiver_mobile")
    private String receiver_mobile;

    @Column(name = "operation_waybill_fee_list")
    private String operation_waybill_fee_list;
    @Column(name = "operation_waybill_addition_list")
    private String operation_waybill_addition_list;

    private String source_waybill_no;
    private String customer_acct_code;

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getSender_comp_name() {
        return sender_comp_name;
    }

    public void setSender_comp_name(String sender_comp_name) {
        this.sender_comp_name = sender_comp_name;
    }

    public String getSender_addr() {
        return sender_addr;
    }

    public void setSender_addr(String sender_addr) {
        this.sender_addr = sender_addr;
    }

    public String getSender_province() {
        return sender_province;
    }

    public void setSender_province(String sender_province) {
        this.sender_province = sender_province;
    }

    public String getSender_city() {
        return sender_city;
    }

    public void setSender_city(String sender_city) {
        this.sender_city = sender_city;
    }

    public String getSender_city_code() {
        return sender_city_code;
    }

    public void setSender_city_code(String sender_city_code) {
        this.sender_city_code = sender_city_code;
    }

    public String getSender_area() {
        return sender_area;
    }

    public void setSender_area(String sender_area) {
        this.sender_area = sender_area;
    }

    public String getSender_phone() {
        return sender_phone;
    }

    public void setSender_phone(String sender_phone) {
        this.sender_phone = sender_phone;
    }

    public String getSender_mobile() {
        return sender_mobile;
    }

    public void setSender_mobile(String sender_mobile) {
        this.sender_mobile = sender_mobile;
    }

    public String getReceiver_comp_name() {
        return receiver_comp_name;
    }

    public void setReceiver_comp_name(String receiver_comp_name) {
        this.receiver_comp_name = receiver_comp_name;
    }

    public String getReceiver_addr() {
        return receiver_addr;
    }

    public void setReceiver_addr(String receiver_addr) {
        this.receiver_addr = receiver_addr;
    }

    public String getReceiver_province() {
        return receiver_province;
    }

    public void setReceiver_province(String receiver_province) {
        this.receiver_province = receiver_province;
    }

    public String getReceiver_city() {
        return receiver_city;
    }

    public void setReceiver_city(String receiver_city) {
        this.receiver_city = receiver_city;
    }

    public String getReceiver_city_code() {
        return receiver_city_code;
    }

    public void setReceiver_city_code(String receiver_city_code) {
        this.receiver_city_code = receiver_city_code;
    }

    public String getReceiver_area() {
        return receiver_area;
    }

    public void setReceiver_area(String receiver_area) {
        this.receiver_area = receiver_area;
    }

    public String getReceiver_phone() {
        return receiver_phone;
    }

    public void setReceiver_phone(String receiver_phone) {
        this.receiver_phone = receiver_phone;
    }

    public String getReceiver_mobile() {
        return receiver_mobile;
    }

    public void setReceiver_mobile(String receiver_mobile) {
        this.receiver_mobile = receiver_mobile;
    }

    public String getOperation_waybill_fee_list() {
        return operation_waybill_fee_list;
    }

    public void setOperation_waybill_fee_list(String operation_waybill_fee_list) {
        this.operation_waybill_fee_list = operation_waybill_fee_list;
    }

    public String getOperation_waybill_addition_list() {
        return operation_waybill_addition_list;
    }

    public void setOperation_waybill_addition_list(String operation_waybill_addition_list) {
        this.operation_waybill_addition_list = operation_waybill_addition_list;
    }

    public String getCustomer_acct_code() {
        return customer_acct_code;
    }

    public void setCustomer_acct_code(String customer_acct_code) {
        this.customer_acct_code = customer_acct_code;
    }

    public String getSource_waybill_no() {
        return source_waybill_no;
    }

    public void setSource_waybill_no(String source_waybill_no) {
        this.source_waybill_no = source_waybill_no;
    }
}
