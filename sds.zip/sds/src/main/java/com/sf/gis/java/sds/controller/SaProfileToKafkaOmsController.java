package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.waybillaoi.HiveToKafkaOms;
import com.sf.gis.java.sds.pojo.waybillaoi.SjPjAoi;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

public class SaProfileToKafkaOmsController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(SaProfileToKafkaOmsController.class);
    // ak每分钟限速 / 并发数
    private static int limitMin = 20000 / 20;

    public void start(String date, String citycodes_sp, String citycodes_report) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        SparkConf sparkConf = sparkInfo.getConf();
        sparkConf.registerKryoClasses((Class<?>[]) Arrays.asList(KafkaProducer.class).toArray());

        if (StringUtils.isNotEmpty(citycodes_sp) && StringUtils.isNotEmpty(citycodes_report)) {
            logger.error("获取收件数据");
            JavaRDD<SjPjAoi> sjRdd = loadData(spark, sc, date, mkString(citycodes_sp.split(",")), mkString(citycodes_report.split(",")), "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sjRdd cnt:{}", sjRdd.count());

            JavaRDD<HiveToKafkaOms> sjOmsRdd = sjRdd.map(o -> {
                HiveToKafkaOms hiveToKafkaOms = new HiveToKafkaOms();

                hiveToKafkaOms.setWaybillNo(o.getWaybill_no());
                hiveToKafkaOms.setConsTeamCode(o.getOriginal_aoi_area_code());
                hiveToKafkaOms.setConsDeptCode(o.getOriginal_zone_code());
                hiveToKafkaOms.setConsAoiTypeCode(o.getFa_type());
                hiveToKafkaOms.setConsAoiId(o.getAoi_id());
                hiveToKafkaOms.setConsAoiCode(o.getOriginal_aoi_code());
                hiveToKafkaOms.setAoiCategory(o.getAoi_category());
                hiveToKafkaOms.setTag(o.getTag());

                for (Field f : hiveToKafkaOms.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    if (StringUtils.equals(f.getType().toString(), "class java.lang.String") && f.get(hiveToKafkaOms) == null) { //若字段为空，给该属性赋为空字符串
                        f.set(hiveToKafkaOms, "");
                    }
                }

                return hiveToKafkaOms;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sjOmsRdd cnt:{}", sjOmsRdd.count());
            sjOmsRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            sjRdd.unpersist();

            logger.error("获取派件数据");
            JavaRDD<SjPjAoi> pjRdd = loadData(spark, sc, date, mkString(citycodes_sp.split(",")), mkString(citycodes_report.split(",")), "pj").persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pjRdd cnt:{}", pjRdd.count());

            JavaRDD<HiveToKafkaOms> pjOmsRdd = pjRdd.map(o -> {
                HiveToKafkaOms hiveToKafkaOms = new HiveToKafkaOms();

                hiveToKafkaOms.setWaybillNo(o.getWaybill_no());
                hiveToKafkaOms.setDispAoiArea(o.getOriginal_aoi_area_code());
                hiveToKafkaOms.setDispAoiCode(o.getOriginal_aoi_code());
                hiveToKafkaOms.setDispAoiId(o.getAoi_id());
                hiveToKafkaOms.setDispAoiTypeCode(o.getFa_type());
                hiveToKafkaOms.setConsDeptCode(o.getOriginal_zone_code());
                hiveToKafkaOms.setAoiCategory(o.getAoi_category());
                hiveToKafkaOms.setTag(o.getTag());

                for (Field f : hiveToKafkaOms.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    if (StringUtils.equals(f.getType().toString(), "class java.lang.String") && f.get(hiveToKafkaOms) == null) { //若字段为空，给该属性赋为空字符串
                        f.set(hiveToKafkaOms, "");
                    }
                }

                return hiveToKafkaOms;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pjOmsRdd cnt:{}", pjOmsRdd.count());
            pjOmsRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            pjRdd.unpersist();

            JavaRDD<HiveToKafkaOms> rdd = sjOmsRdd.union(pjOmsRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());
            rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            sjOmsRdd.unpersist();
            pjOmsRdd.unpersist();

            Properties props = new Properties();
            props.put("bootstrap.servers", "10.119.122.74:9092,10.119.122.75:9092,10.119.122.76:9092,10.119.122.77:9092,10.119.122.78:9092");
            props.put("acks", "all");
            props.put("retries", 3);
            props.put("batch.size", 16384);
            props.put("linger.ms", 5);
            props.put("buffer.memory", 33554432);
            props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
            Broadcast<Properties> propsBc = sc.broadcast(props);

            JavaRDD<HiveToKafkaOms> resultRdd = rdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<HiveToKafkaOms> list = new ArrayList<>();
                KafkaProducer<String, String> producer = new KafkaProducer<String, String>(propsBc.value());
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    HiveToKafkaOms o = itr.next();
                    o.setToOmsTm(DateUtil.getTheTimeInSeconds());

                    logger.error("hiveToKafkaOms:{}", JSON.toJSONString(o));
                    try {
                        producer.send(new ProducerRecord<String, String>("GIS_AOI_INFO_TO_OMS", JSON.toJSONString(o)), new Callback() {
                            @Override
                            public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                                if (e != null) {
                                    logger.error("exception ms:{}", e.getMessage());
                                } else {
                                    list.add(o);
                                }
                            }
                        });
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                producer.close();
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            rdd.unpersist();
            resultRdd.unpersist();
        }
    }

    public JavaRDD<SjPjAoi> loadData(SparkSession spark, JavaSparkContext sc, String date, String citycodes_sp, String citycodes_report, String tag) {
        String sql = "";
        if (StringUtils.equals(tag, "sj")) {
            sql = String.format("select *,'gis_sj_dcs' as aoi_category from dm_gis.sj_aoi_new where inc_day = '%s' and original_city_code in (%s) and (aoi_id is not null and aoi_id <>'') union all (select *,'gis_sj_report' as aoi_category from dm_gis.sj_aoi_new_report where inc_day = '%s' and original_city_code in (%s) and (aoi_id is not null and aoi_id <>''))", date, citycodes_sp, date, citycodes_report);
        } else if (StringUtils.equals(tag, "pj")) {
            sql = String.format("select *,'gis_pj_dcs' as aoi_category from dm_gis.pj_aoi_new where inc_day = '%s' and destination_city_code in (%s) and (aoi_id is not null and aoi_id <>'') union all (select *,'gis_pj_report' as aoi_category from dm_gis.pj_aoi_new_report where inc_day = '%s' and destination_city_code in (%s) and (aoi_id is not null and aoi_id <>''))", date, citycodes_sp, date, citycodes_report);
        }
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, SjPjAoi.class);
    }

    public static String mkString(String[] arr) {
        return "\'" + String.join("\',\'", arr) + "\'";
    }

}
