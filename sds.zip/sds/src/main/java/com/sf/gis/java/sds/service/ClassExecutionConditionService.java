package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.ClassExecutionCondition;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class ClassExecutionConditionService implements Serializable {
    private Logger logger = LoggerFactory.getLogger(ClassExecutionConditionService.class);

    public JavaRDD<ClassExecutionCondition> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("tals_get_target_data.sql", date, date, date);
        logger.error("tals_get_target_data sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ClassExecutionCondition.class);
    }

    public double calcMtc(List<ClassExecutionCondition> list) {
        double sumTollCharge = 0;
        for (ClassExecutionCondition classExecutionCondition : list) {
            sumTollCharge = sumTollCharge + Double.valueOf(StringUtils.isNotEmpty(classExecutionCondition.getTollCharge()) ? classExecutionCondition.getTollCharge() : "0");
        }
        return list.size() > 0 ? (double) Math.round((sumTollCharge / list.size()) * 10) / 10 : 0.0;
    }

    public double calcEtc(List<ClassExecutionCondition> list) {
        double sumEtcTollCharge = 0;
        for (ClassExecutionCondition classExecutionCondition : list) {
            sumEtcTollCharge = sumEtcTollCharge + Double.valueOf(StringUtils.isNotEmpty(classExecutionCondition.getEtcTollCharge()) ? classExecutionCondition.getEtcTollCharge() : "0");
        }
        return list.size() > 0 ? (double) Math.round((sumEtcTollCharge / list.size()) * 10) / 10 : 0.0;
    }

    public double calcMileage(List<ClassExecutionCondition> list) {
        double sumMileage = 0;
        for (ClassExecutionCondition classExecutionCondition : list) {
            sumMileage = sumMileage + Double.valueOf(StringUtils.isNotEmpty(classExecutionCondition.getLenNew()) ? classExecutionCondition.getLenNew() : "0") / 1000.0;
        }
        return list.size() > 0 ? (double) Math.round((sumMileage / list.size()) * 10) / 10 : 0.0;
    }

    public double calcTime(List<ClassExecutionCondition> list) {
        long sumTime = 0;
        for (ClassExecutionCondition classExecutionCondition : list) {
            sumTime = sumTime + classExecutionCondition.getActualRunTime();
        }
        return list.size() > 0 ? (double) Math.round((sumTime / list.size()) * 10) / 10 : 0.0;
    }

    public void saveData(SparkSession spark, JavaRDD<ClassExecutionCondition> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getIncMonth(), DateUtil.parseFormat(o.getIncDay()), o.getDay(), o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getLine_area(), o.getLineCode(), o.getSrcCityName(), o.getDestCityName(),
                    o.getReachCount() + "", o.getTaskCount() + "", o.getExecutionCount() + "", o.getNo_reachCount() + "", o.getNo_executionCount() + "", o.getExecuteReachCount() + "",
                    o.getNoExecuteReachCount() + "", o.getSumEtc() + "", o.getExecution_sumEtc() + "", o.getNo_execution_sumEtc() + "", o.getSumDistance() + "",
                    o.getExecution_sumDistance() + "", o.getNo_execution_sumDistance() + "", o.getSumConsumeTime() + "", o.getExecution_sumConsumeTime() + "", o.getNo_execution_sumConsumeTime() + "",
                    o.getSumTimeOut() + "", o.getExecution_sumTimeOut() + "", o.getNo_execution_sumTimeOut() + "", o.getBaseSumEtc() + "", o.getExecute_no_reach_count() + "", o.getNo_execute_no_reach_count() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"STAT_MONTH", "STAT_DATE", "STAT_WEEK", "SRC_PROVINCE", "DESC_PROVINCE", "AREA", "LINE_AREA", "CLASS_ID", "SRC_CITYCODE", "DESC_CITYCODE",
                "REACH_COUNT", "TASK_COUNT", "EXECUTE_COUNT", "NO_REACH_COUNT", "NO_EXECUTE_COUNT", "EXECUTE_REACH_COUNT", "NO_EXECUTE_REACH_COUNT", "TOTAL_ETC",
                "EXECUTE_TOTAL_ETC", "NO_EXECUTE_TOTAL_ETC", "TOTAL_DISTANCE", "EXECUTE_TOTAL_DISTANCE", "NO_EXECUTE_TOTAL_DISTANCE", "TOTAL_TIME", "EXECUTE_TOTAL_TIME",
                "NO_EXECUTE_TOTAL_TIME", "DELAY_MIN", "EXECUTE_DELAY_MIN", "NO_EXECUTE_DELAY_MIN", "BASE_TOTAL_ETC", "EXECUTE_NO_REACH_COUNT", "NO_EXECUTE_NO_REACH_COUNT"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "eta_class_execute_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.eta_class_execute_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveToMysql(JavaSparkContext sc, JavaRDD<ClassExecutionCondition> rdd) {
        String dbConfig = "mysql.properties";
        logger.error("rdd cnt: {}", rdd.count());

        logger.error("insert into mysql");
        Broadcast<String> dbConfigBc = sc.broadcast(dbConfig);
        rdd.repartition(16).foreachPartition(p -> {
            Connection conn = DbUtil.getInstance(dbConfigBc.value()).getConn();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement(
                    String.format("insert into ETA_CLASS_EXECUTE_STAT(`STAT_MONTH`,`STAT_DATE`,`STAT_WEEK`,`STAT_TYPE`,`STAT_TYPE_CONTENT`,`SRC_PROVINCE`,`DESC_PROVINCE`," +
                            "`AREA`,`LINE_AREA`,`CLASS_ID`,`SRC_CITYCODE`,`DESC_CITYCODE`," +
                            "`REACH_COUNT`,`TASK_COUNT`,`EXECUTE_COUNT`,`NO_REACH_COUNT`,`NO_EXECUTE_COUNT`,`EXECUTE_REACH_COUNT`,`NO_EXECUTE_REACH_COUNT`,`TOTAL_ETC`," +
                            "`EXECUTE_TOTAL_ETC`,`NO_EXECUTE_TOTAL_ETC`,`TOTAL_DISTANCE`,`EXECUTE_TOTAL_DISTANCE`,`NO_EXECUTE_TOTAL_DISTANCE`,`TOTAL_TIME`,`EXECUTE_TOTAL_TIME`," +
                            "`NO_EXECUTE_TOTAL_TIME`,`DELAY_MIN`,`EXECUTE_DELAY_MIN`,`NO_EXECUTE_DELAY_MIN`,`BASE_TOTAL_ETC`) " +
                            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            );
            while (p.hasNext()) {
                ClassExecutionCondition o = p.next();
                pstmt.setString(1, o.getIncMonth());
                pstmt.setString(2, o.getIncDay());
                pstmt.setString(3, o.getDay());
                pstmt.setString(4, o.getStat_type());
                pstmt.setString(5, o.getStat_type_content());
                pstmt.setString(6, o.getSrcProvince());
                pstmt.setString(7, o.getDestProvince());
                pstmt.setString(8, o.getTaskAreaCode());
                pstmt.setString(9, o.getLine_area());
                pstmt.setString(10, o.getLineCode());
                pstmt.setString(11, o.getSrcCityName());
                pstmt.setString(12, o.getDestCityName());
                pstmt.setInt(13, o.getReachCount());
                pstmt.setInt(14, o.getTaskCount());
                pstmt.setInt(15, o.getExecutionCount());
                pstmt.setInt(16, o.getNo_reachCount());
                pstmt.setInt(17, o.getNo_executionCount());
                pstmt.setInt(18, o.getExecuteReachCount());
                pstmt.setInt(19, o.getNoExecuteReachCount());
                pstmt.setDouble(20, o.getSumEtc());
                pstmt.setDouble(21, o.getExecution_sumEtc());
                pstmt.setDouble(22, o.getNo_execution_sumEtc());
                pstmt.setDouble(23, o.getSumDistance());
                pstmt.setDouble(24, o.getExecution_sumDistance());
                pstmt.setDouble(25, o.getNo_execution_sumDistance());
                pstmt.setDouble(26, o.getSumConsumeTime());
                pstmt.setDouble(27, o.getExecution_sumConsumeTime());
                pstmt.setDouble(28, o.getNo_execution_sumConsumeTime());
                pstmt.setDouble(29, o.getSumTimeOut());
                pstmt.setDouble(30, o.getExecution_sumTimeOut());
                pstmt.setDouble(31, o.getNo_execution_sumTimeOut());
                pstmt.setDouble(32, o.getBaseSumEtc());

                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            pstmt.close();
            conn.close();
        });
        logger.error("insert into mysql end");
    }

    public void delete(String date) {
        Connection conn = DbUtil.getInstance("mysql.properties").getConn();
        String sql = String.format("delete from ETA_CLASS_EXECUTE_STAT where STAT_DATE = '%s'", date);
        PreparedStatement pst = null;
        try {
            // 创建预编译语句
            pst = conn.prepareStatement(sql);
            // 执行SQL
            pst.executeUpdate();
            logger.error("删除成功");
            // 关闭资源
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("删除失败");
        }
    }

}
