package com.sf.gis.java.sds.service;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.ShellExcutor;
import com.sf.gis.java.sds.bean.FtpClient;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.pojo.GisToAddrStat;
import com.sf.gis.java.sds.utils.ZipCompress;
import com.sf.gis.scala.base.spark.Spark;

import com.sf.gis.scala.base.util.HttpClientUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PullOmsService implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(PullOmsService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    private String GIS_TOADDR_STAT_NEW = "dm_gis.gis_toaddr_stat_new2";
    private String GIS_OMS_TO = "dm_gis.gis_rds_omsto";

    public PullOmsService() {
        sparkSession = Spark.getSparkSession(PullOmsService.class.getSimpleName(), null, false, 2);
    }

    public void pullData(int commonDayAgo, int bigCityDayAgo, int smallCityDayAgo, Map<String, String> configMap) {
        String endDate = DateUtil.getCurrentDateBefore("yyyyMMdd", commonDayAgo);
        String bigBegin = DateUtil.getCurrentDateBefore("yyyyMMdd", bigCityDayAgo + commonDayAgo);
        String smallBegin = DateUtil.getCurrentDateBefore("yyyyMMdd", smallCityDayAgo + commonDayAgo);
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        logger.error(smallBegin + "," + bigBegin + "," + endDate);
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());

        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        parserCity(openCityList.stream().collect(Collectors.joining("','")), bigBegin, endDate, ftpClient, ftpPath,
                ftpFileName, configMap);

        ftpClient.close();
    }

    private void parserCity(String city, String beginDate, String endDate, FtpClient ftpClient, String ftpPath,
                            String ftpFileName, Map<String, String> configMap) {
        // if(city.equals("898")){
        // cityCode = "'898','8981'";
        // }
        String sql = "SELECT waybillno, '' as id,"
                + " regexp_replace(address, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') norm_address,"
                + " log_sssdeptcode sss_deptcode,( case when deptcode = xiaoge_deptcode "
                + " then deptcode  else '' end ) deptcode, teamcode his_teamcode,"
                + " inc_day, citycode, '1' as count, zonecode,xiaoge_deptcode,xiaoge_no, logteamcode,"
                + " regexp_replace(req_province, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') req_province,"
                + " regexp_replace(req_city, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') req_city,"
                + " regexp_replace(req_area, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') req_area,"
                + " regexp_replace(req_comp_name, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') req_comp_name" + " FROM "
                + GIS_TOADDR_STAT_NEW + " where inc_day >= '" + beginDate + "' and inc_day <= '" + endDate
                + "' and citycode in ('" + city + "') and deptcode <> '' and deptcode not like '%,%' and teamcode not like '%,%' ";
        String group_sql = "select first(waybillno)  ,first(id) ,norm_address,first(sss_deptcode) ,"
                + "deptcode,his_teamcode,first(inc_day) ,"
                + "citycode,sum(count) ,zonecode,xiaoge_deptcode, first(xiaoge_no) , first(logteamcode),"
                + "first(req_province), first(req_city),first(req_area),first(req_comp_name) from (" + sql
                + ") b group by citycode,norm_address,deptcode,zonecode,his_teamcode,xiaoge_deptcode ";
        logger.error(group_sql);
        JavaRDD<GisToAddrStat> dataRdd = sparkSession.sql(group_sql).javaRDD()
                .persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> new GisToAddrStat(x.getString(0), x.getString(1), x.getString(2), x.getString(3),
                        x.getString(4), x.getString(5), x.getString(6), x.getString(7),
                        String.valueOf((int) ((double) x.getDouble(8))), x.getString(9), x.getString(10),
                        x.getString(11), x.getString(12), x.getString(13), x.getString(14), x.getString(15),
                        x.getString(16)));
        parserAllData(city, dataRdd, ftpClient, ftpPath, ftpFileName, configMap, beginDate);
    }

    private void parserAllData(String city, JavaRDD<GisToAddrStat> dataRdd, FtpClient ftpClient, String ftpPath,
                               String ftpFileName, Map<String, String> configMap, String beginDate) {
        // 加上分区得到唯一id
        JavaRDD<String> ret = dataRdd.map(x -> x.getWaybillno() + ","
                + x.getCitycode() + "," + x.getDeptcode() + "," + x.getHis_teamcode() + "," + x.getInc_day() + ","
                + x.getNorm_address() + "," + x.getSss_deptcode() + "," + x.getCount() + "," + x.getZonecode() + ","
                + x.getXiaoge_deptcode() + "," + x.getXiaoge_no() + "," + x.getLogteamcode() + "," + x.getReq_province()
                + "," + x.getReq_city() + "," + x.getReq_area() + "," + x.getReq_comp_name());

        String srcName = "multi" + ftpFileName;
        try {
            String hdfsFile = "/user/01374443/upload/tmp/oms_data/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.zipWithIndex().map(obj -> {
                return obj._2 + "," + obj._1;
            }).saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);

            logger.error("增加文件头~");
            ShellExcutor.exeCmd("sed -i '1i\\id,waybillno,citycode,deptcode,"
                    + "his_teamcode,inc_day,norm_address,sss_deptcode,count,zonecode,xiaoge_deptcode,xiaoge_no,logteamcode,req_province,req_city,req_area,req_comp_name' "
                    + srcName + ".csv");

            ftpPath = ftpPath + "/" + beginDate;

            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient, ftpPath);
            delete_file(srcName);
            String forward = configMap.get(ConfigKey.forward.name());
            if (forward != null && forward.equals("true")) {
                String moveUrl = configMap.get(ConfigKey.move_data_url.name());

                HttpClientUtil.getStrByGet(String.format(moveUrl, ftpPath, srcName + ".zip", beginDate + "/" + srcName + ".zip"),"UTF-8");

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private void delete_file(String srcName) {
        File file = new File(srcName + ".zip");
        if (file.exists()) {
            file.delete();
        }
        file = new File(srcName + ".csv");
        if (file.exists()) {
            file.delete();
        }
    }

    private boolean checkFile(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return false;
        } else if (file.length() == 0) {
            file.delete();
            return false;
        }
        return true;
    }

    private void uploadFile(String fileName, FtpClient ftpClient, String ftpPath) {
        try {
            logger.error(fileName);
            ftpClient.uploadFile(fileName, ftpPath);
        } catch (Exception e) {
            logger.error("ftp error:" + e.getMessage());
        }
    }

    /**
     * 空aoi数据
     *
     * @param commonDayAgo
     * @param configMap
     */
    public void pullAoiWrongData(int commonDayAgo, Map<String, String> configMap) {
        String endDate = DateUtil.getCurrentDateBefore("yyyyMMdd", commonDayAgo);
//		logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
//		List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        pullAoiWrongDataCity(endDate, endDate, ftpClient,
                ftpPath, ftpFileName, configMap);

        ftpClient.close();
    }

    public void pullAoiEmptyData(int commonDayAgo, Map<String, String> configMap) {
        String endDate = DateUtil.getCurrentDateBefore("yyyyMMdd", commonDayAgo);
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        parserAoiEmptyCity(openCityList.stream().collect(Collectors.joining("','")), endDate, endDate, ftpClient,
                ftpPath, ftpFileName, configMap);

        ftpClient.close();
    }

    private void parserAoiEmptyCity(String city_str, String beginDate, String endDate, FtpClient ftpClient,
                                    String ftpPath, String ftpFileName, Map<String, String> configMap) {
        String sql = "SELECT inc_day,req_destcitycode,req_waybillno  ,"
                + " regexp_replace(req_addresseeaddr , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') ,"
                + " regexp_replace(req_comp_name  , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') ,"
                + " req_addresseephone,req_addresseemobile ,"
                + " regexp_replace(splitresult  , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') ,"
                + " regexp_replace(keywords  , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') ,"
                + " gis_to_sys_gisdeptcodeto ,gis_to_sys_gisteamcodeto ,gis_to_sys_src ,"
                + " finalzc  ,finalzcby ,finaltc,finalzcby,gisAoiSrc,gis_to_sys_groupid ,"
                + " regexp_replace(standardization   , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') ,"
                + " groupids ,matchids,filters,finalAoiCode"
                + " from " + GIS_OMS_TO + " where inc_day between '" + beginDate + "' and '" + endDate + "' "
                + " and gisAoiCode='' and ksAoiCode=''";
        logger.error(sql);
        JavaRDD<String> ret = sparkSession.sql(sql).javaRDD()
                .map(x -> x.getString(0) + "," + x.getString(1) + "," + x.getString(2) + "," + x.getString(3) + ","
                        + x.getString(4) + "," + x.getString(5) + "," + x.getString(6) + "," + x.getString(7) + ","
                        + x.getString(8) + "," + x.getString(9) + "," + x.getString(10) + "," + x.getString(11) + ","
                        + x.getString(12) + "," + x.getString(13) + "," + x.getString(14) + "," + x.getString(15) + ","
                        + x.getString(16) + "," + x.getString(17) + "," + x.getString(18) + "," + x.getString(19) + ","
                        + x.getString(20) + "," + x.getString(21) + "," + x.getString(22));
        // 加上分区得到唯一id
        String srcName = "multi" + "_" + beginDate + ftpFileName;
        try {
            String hdfsFile = "/user/01374443/upload/tmp/aoi_empty_pai/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);

            logger.error("增加文件头~");
            ShellExcutor.exeCmd("sed -i '1i\\inc_day,cityCode,waybillno,address,"
                    + "company,mobile,phone,split,keyword,gisDept,gisTc,deptSrc,"
                    + "finalDept,findDeptSrc,finalTc,finalTcSrc,aoiSrc,bigGroupId,"
                    + "standard_address,group_group,groupId,filter,finalAoiCode' "
                    + srcName + ".csv");
            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient, ftpPath);
            delete_file(srcName);
            String moveUrl = configMap.get(ConfigKey.move_data_url.name());
            String useUrl = String.format(moveUrl, ftpPath, srcName + ".zip");
            logger.error(useUrl);
            HttpClientUtil.getJsonByGet(useUrl);

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private void pullAoiWrongDataCity(String beginDate, String endDate, FtpClient ftpClient,
                                      String ftpPath, String ftpFileName, Map<String, String> configMap) {
        String sql = "select '' as id,citycode as city_code,'' as sch_code,"
                + "regexp_replace(concat(province,city,county,address) , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') as address,"
                + "'' as address_md5,sysorderno as waybill_no,real_distribute_time as data_time,"
                + "'' as province,'' as city1,'' as county,deptcode as zno_code,"
                + "'WRONG_AOI_S' as source,'' as emp_id,distribute_code,"
                + "act_code as delivered_code,regexp_replace(company , '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') as company from dm_gis.aoi_fc_for_area where inc_day='" + beginDate + "' "
                + " and datatype='wd' ";
        logger.error(sql);
        JavaRDD<String> ret = sparkSession.sql(sql).javaRDD()
                .map(x -> {
                    String distribute_code = x.getString(13);
                    if (distribute_code != null && distribute_code.contains(",")) {
                        distribute_code = "\"" + distribute_code + "\"";
                    }
                    String delivered_code = x.getString(14);
                    if (delivered_code != null && delivered_code.contains(",")) {
                        delivered_code = "\"" + delivered_code + "\"";
                    }
                    return x.getString(0) + "," + x.getString(1) + "," + x.getString(2) + "," + x.getString(3) + ","
                            + x.getString(4) + "," + x.getString(5) + "," + x.getString(6) + "," + x.getString(7) + ","
                            + x.getString(8) + "," + x.getString(9) + "," + x.getString(10) + "," + x.getString(11) + ","
                            + x.getString(12) + "," + distribute_code + "," + delivered_code + "," + x.getString(15);
                });
        // 加上分区得到唯一id
        String srcName = DateUtil.getCurrentDateBefore("yyyyMMdd", 0);
        try {
            String hdfsFile = "/user/01374443/upload/tmp/aoi_wrong/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);

            logger.error("增加文件头~");
            ShellExcutor.exeCmd("sed -i '1i\\id,city_code,sch_code,address,"
                    + "address_md5,waybill_no,data_time,province,city,county,zno_code,source,"
                    + "emp_id,distribute_code,delivered_code,company' "
                    + srcName + ".csv");
            if (!checkFile(srcName + ".csv")) {
                logger.error("空文件");
                return;
            }
            uploadFile(srcName + ".csv", ftpClient, ftpPath);
            delete_file(srcName);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }
}