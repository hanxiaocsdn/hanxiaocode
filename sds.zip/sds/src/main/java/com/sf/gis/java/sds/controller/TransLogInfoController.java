package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.TransLogInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class TransLogInfoController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(TransLogInfoController.class);

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

//        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
//        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        logger.error("获取数据源");
        JavaRDD<TransLogInfo> transLogInfoRdd = loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("transLogInfoRdd cnt:{}", transLogInfoRdd.count());
//        transLogInfoRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("解析log");
        JavaRDD<TransLogInfo> resultRdd = transLogInfoRdd.map(o -> {
            String log = o.getLog();
            if (StringUtils.isNotEmpty(log)) {
//                log = log.replace("\"{", "{").replace("}\"", "}").replace("\\", "");
//                o.setLog(log);
                JSONObject jsonObject = JSON.parseObject(log);
                if (jsonObject != null) {
                    JSONObject message = jsonObject.getJSONObject("message");
                    if (message != null) {
                        String dateTime = message.getString("dateTime");
                        String sn = message.getString("sn");
                        o.setDateTime(dateTime);
                        o.setSn(sn);
                        JSONObject url = message.getJSONObject("url");
                        if (url != null) {
                            String reqId = url.getString("reqId");
                            String employeeId = url.getString("employeeId");
                            String cityCode = url.getString("cityCode");
                            String lng = url.getString("lng");
                            String lat = url.getString("lat");
                            String vehicleType = url.getString("vehicleType");
                            o.setReqId(reqId);
                            o.setEmployeeId(employeeId);
                            o.setCityCode(cityCode);
                            o.setLng(lng);
                            o.setLat(lat);
                            o.setVehicleType(vehicleType);
                            JSONObject aoiOrders = url.getJSONObject("aoiOrders");
                            if (aoiOrders != null) {
                                int aoiCount = aoiOrders.size();
                                int waybillCount = 0;
                                int poiWaybillCount = 0;
                                for (String key : aoiOrders.keySet()) {
                                    String value = aoiOrders.getString(key).replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                    String[] split = value.split("\\|");
                                    for (String s : split) {
                                        String s1 = s.replaceAll("\"", "");
                                        String[] split1 = s1.split(",");
                                        if (StringUtils.isNotEmpty(split1[0])) {
                                            waybillCount++;
                                        }
                                        if (split1.length == 2 && StringUtils.isNotEmpty(split1[1])) {
                                            poiWaybillCount++;
                                        }
                                    }
                                }
                                o.setAoiCount(aoiCount + "");
                                o.setWaybillCount(waybillCount + "");
                                o.setPoiWaybillCount(poiWaybillCount + "");
                            }
                        }
                        String time = message.getString("time");
                        o.setTime(time);
                        JSONObject data = message.getJSONObject("data");
                        if (data != null) {
                            JSONObject result = data.getJSONObject("result");
                            if (result != null) {
                                JSONObject data1 = result.getJSONObject("data");
                                if (data1 != null) {
                                    String employeeAoiId = data1.getString("employeeAoiId");
                                    o.setEmployeeAoiId(employeeAoiId);

                                    String poiInfoList = data1.getString("poiInfoList");
                                    int poiCount = 0;
                                    int poiBuildingCount = 0;
                                    int poiEntranceCount = 0;
                                    if (StringUtils.isNotEmpty(poiInfoList)) {
                                        poiInfoList = poiInfoList.replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                        String[] split = poiInfoList.split("\\|");
                                        for (String s : split) {
                                            String s1 = s.replaceAll("\"", "");
                                            String[] split1 = s1.split(",");
                                            if (StringUtils.isNotEmpty(split1[0])) {
                                                poiCount++;
                                            }
                                            if (split1.length == 2 && StringUtils.equals(split1[1], "1")) {
                                                poiBuildingCount++;
                                            }
                                            if (split1.length == 2 && StringUtils.equals(split1[1], "0")) {
                                                poiEntranceCount++;
                                            }
                                        }
                                    }
                                    o.setPoiCount(poiCount + "");
                                    o.setPoiBuildingCount(poiBuildingCount + "");
                                    o.setPoiEntranceCount(poiEntranceCount + "");

                                    String aoiTimeDistMatrix = data1.getString("aoiTimeDistMatrix");
                                    int aoiMatrixCount = 0;
                                    int aoiMatrix0Count = 0;
                                    int aoiMatrix1Count = 0;
                                    int aoiMatrix2Count = 0;
                                    int aoiMatrix3Count = 0;
                                    if (StringUtils.isNotEmpty(aoiTimeDistMatrix)) {
                                        aoiTimeDistMatrix = aoiTimeDistMatrix.replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                        String[] split = aoiTimeDistMatrix.split("\\|");
                                        for (String s : split) {
                                            String s1 = s.replaceAll("\"", "");
                                            String[] split1 = s1.split(",");
                                            if (StringUtils.isNotEmpty(split1[0])) {
                                                if (split1[0].contains("-")) {
                                                    aoiMatrixCount++;
                                                }
                                            }
                                            if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "0")) {
                                                aoiMatrix0Count++;
                                            }
                                            if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "1")) {
                                                aoiMatrix1Count++;
                                            }
                                            if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "2")) {
                                                aoiMatrix2Count++;
                                            }
                                            if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "3")) {
                                                aoiMatrix3Count++;
                                            }
                                        }
                                    }
                                    o.setAoiMatrixCount(aoiMatrixCount + "");
                                    o.setAoiMatrix0Count(aoiMatrix0Count + "");
                                    o.setAoiMatrix1Count(aoiMatrix1Count + "");
                                    o.setAoiMatrix2Count(aoiMatrix2Count + "");
                                    o.setAoiMatrix3Count(aoiMatrix3Count + "");

                                    JSONObject poiTimeDistMatrix = data1.getJSONObject("poiTimeDistMatrix");
                                    int poiMatrixCount = 0;
                                    int poiMatrix0Count = 0;
                                    int poiMatrix1Count = 0;
                                    int poiMatrix2Count = 0;
                                    int poiMatrix3Count = 0;
                                    if (poiTimeDistMatrix != null) {
                                        for (String key : poiTimeDistMatrix.keySet()) {
                                            String value = poiTimeDistMatrix.getString(key).replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                            String[] split = value.split("\\|");
                                            for (String s : split) {
                                                String s1 = s.replaceAll("\"", "");
                                                String[] split1 = s1.split(",");
                                                if (StringUtils.isNotEmpty(split1[0])) {
                                                    if (split1[0].contains("-")) {
                                                        poiMatrixCount++;
                                                    }
                                                }
                                                if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "0")) {
                                                    poiMatrix0Count++;
                                                }
                                                if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "1")) {
                                                    poiMatrix1Count++;
                                                }
                                                if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "2")) {
                                                    poiMatrix2Count++;
                                                }
                                                if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "3")) {
                                                    poiMatrix3Count++;
                                                }
                                            }
                                        }
                                    }
                                    o.setPoiMatrixCount(poiMatrixCount + "");
                                    o.setPoiMatrix0Count(poiMatrix0Count + "");
                                    o.setPoiMatrix1Count(poiMatrix1Count + "");
                                    o.setPoiMatrix2Count(poiMatrix2Count + "");
                                    o.setPoiMatrix3Count(poiMatrix3Count + "");

                                    String missingAoiList = data1.getString("missingAoiList");
                                    String missingBuildingList = data1.getString("missingBuildingList");
                                    int missAoiCount = 0;
                                    int missPoiCount = 0;
                                    if (StringUtils.isNotEmpty(missingAoiList)) {
                                        missingAoiList = missingAoiList.replaceAll("(\\[|])", "");
                                        String[] split = missingAoiList.split(",");
                                        for (int i = 0; i < split.length; i++) {
                                            if (StringUtils.isNotEmpty(split[i])) {
                                                missAoiCount++;
                                            }
                                        }
                                    }
                                    o.setMissAoiCount(missAoiCount + "");

                                    if (StringUtils.isNotEmpty(missingBuildingList)) {
                                        missingBuildingList = missingBuildingList.replaceAll("(\\[|])", "");
                                        String[] split = missingBuildingList.split(",");
                                        for (int i = 0; i < split.length; i++) {
                                            if (StringUtils.isNotEmpty(split[i])) {
                                                missPoiCount++;
                                            }
                                        }
                                    }
                                    o.setMissPoiCount(missPoiCount + "");
                                }
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        resultRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        transLogInfoRdd.unpersist();

        logger.error("结果数据存储");
        String executeSql = String.format("alter table dm_gis.trans_log_info_stat drop if EXISTS partition( inc_day='%s' )", date);
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, resultRdd, date);
        resultRdd.unpersist();
        spark.stop();
    }

    public JavaRDD<TransLogInfo> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select log from dm_gis.trans_log_info where inc_day = '%s' and log like '%%url_e%%'", date);
        logger.error("trans_log_info sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TransLogInfo.class);
    }

    public void saveData(SparkSession spark, JavaRDD<TransLogInfo> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getDateTime(), o.getSn(), o.getReqId(), o.getEmployeeId(), o.getCityCode(), o.getLng(), o.getLat(), o.getVehicleType(), o.getAoiCount(),
                    o.getWaybillCount(), o.getPoiWaybillCount(), o.getTime(), o.getEmployeeAoiId(), o.getPoiCount(), o.getPoiBuildingCount(), o.getPoiEntranceCount(),
                    o.getAoiMatrixCount(), o.getAoiMatrix0Count(), o.getAoiMatrix1Count(), o.getAoiMatrix2Count(), o.getAoiMatrix3Count(),
                    o.getPoiMatrixCount(), o.getPoiMatrix0Count(), o.getPoiMatrix1Count(), o.getPoiMatrix2Count(), o.getPoiMatrix3Count(), o.getMissAoiCount(), o.getMissPoiCount()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "datetime", "sn", "reqid", "employeeId", "citycode", "lng", "lat",
                "vehicletype", "aoicount", "waybillcount", "poiwaybillcount", "time", "employeeaoiid", "poicount",
                "poibuildingcount", "poientrancecount", "aoimatrixcount", "aoimatrix0count", "aoimatrix1count", "aoimatrix2count", "aoimatrix3count",
                "poimatrixcount", "poimatrix0count", "poimatrix1count", "poimatrix2count", "poimatrix3count", "missaoicount", "misspoicount"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "trans_log_info_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.trans_log_info_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public static void main(String[] args) {

        String log = "{\"@timestamp\":\"2021-09-01T08:14:02.606Z\",\"@metadata\":{\"beat\":\"filebeat\",\"type\":\"_doc\",\"version\":\"7.6.2\"},\"message\":\"{\\\"appName\\\":\\\"GIS-RDS-PNS-QUERY\\\",\\\"dateTime\\\":\\\"2021-09-01 16:14:01.654\\\",\\\"type\\\":\\\"url_e\\\",\\\"sn\\\":\\\"0001522021090116140155938974\\\",\\\"url\\\":{\\\"createTime\\\":1630484041560,\\\"ak\\\":\\\"76cf25e640ef4aa988f9f8aeae0b7646\\\",\\\"remoteIp\\\":\\\"10.189.0.104\\\",\\\"url\\\":\\\"http://nginxwa/rdspns/stMatrix\\\",\\\"reqId\\\":\\\"16304840414135829\\\",\\\"employeeId\\\":\\\"41308207\\\",\\\"cityCode\\\":\\\"527\\\",\\\"vehicleType\\\":\\\"1\\\",\\\"aoiOrders\\\":{\\\"6B497C495690451AE0530EF4520AA364\\\":[\\\"SF1320053962617,\\\",\\\"SF1805191649243,\\\",\\\"182154838885,\\\",\\\"SF1320053962247,\\\",\\\"182198469916,\\\",\\\"SF1332631859580,\\\",\\\"SF1300828166689,\\\",\\\"SF1805182829956,\\\",\\\"SF1332692982523,\\\",\\\"SF1805214631069,\\\"],\\\"62556EAEB7B21B9DE0530EF4520A0CFC\\\":[\\\"SF1309738260669,\\\"],\\\"62556EAEB79D1B9DE0530EF4520A0CFC\\\":[\\\"SF1316236575490,\\\",\\\"SF1316156225478,\\\",\\\"182195176657,\\\",\\\"SF1805201209905,\\\",\\\"SF1316985264919,\\\"],\\\"0EED8E6FA7EC4A7E9CB057419446F524\\\":[\\\"CX2193659001782351,\\\",\\\"CX2193658448143074,\\\",\\\"CX2193661006667923,\\\",\\\"CX2193660553691231,\\\",\\\"CX2193659807088673,\\\",\\\"CX2193072604545048,\\\",\\\"CX2193659387658260,\\\",\\\"CX2193660226560002,\\\",\\\"CX2193657332490361,\\\"],\\\"62556EAEB8C31B9DE0530EF4520A0CFC\\\":[\\\"CX2193639405994032,\\\",\\\"SF1316825440646,\\\"]}},\\\"time\\\":95,\\\"data\\\":{\\\"src\\\":\\\"stMatrix\\\",\\\"status\\\":0,\\\"result\\\":{\\\"src\\\":\\\"stMatrix\\\",\\\"data\\\":{\\\"employeeId\\\":\\\"41308207\\\",\\\"employeeAoiId\\\":\\\"RD01\\\",\\\"poiInfoList\\\":[],\\\"aoiTimeDistMatrix\\\":[\\\"62556EAEB7B21B9DE0530EF4520A0CFC-0EED8E6FA7EC4A7E9CB057419446F524,,1004,255,1,0\\\",\\\"0EED8E6FA7EC4A7E9CB057419446F524-62556EAEB7B21B9DE0530EF4520A0CFC,,867,173,1,0\\\",\\\"62556EAEB7B21B9DE0530EF4520A0CFC-62556EAEB8C31B9DE0530EF4520A0CFC,,469,137,1,0\\\",\\\"62556EAEB8C31B9DE0530EF4520A0CFC-62556EAEB7B21B9DE0530EF4520A0CFC,,458,91,1,0\\\",\\\"62556EAEB7B21B9DE0530EF4520A0CFC-6B497C495690451AE0530EF4520AA364,,530,136,1,0\\\",\\\"6B497C495690451AE0530EF4520AA364-62556EAEB7B21B9DE0530EF4520A0CFC,,519,103,1,0\\\",\\\"62556EAEB7B21B9DE0530EF4520A0CFC-62556EAEB79D1B9DE0530EF4520A0CFC,,88,17,1,1\\\",\\\"62556EAEB79D1B9DE0530EF4520A0CFC-62556EAEB7B21B9DE0530EF4520A0CFC,,241,48,1,1\\\",\\\"0EED8E6FA7EC4A7E9CB057419446F524-62556EAEB8C31B9DE0530EF4520A0CFC,,627,125,1,0\\\",\\\"62556EAEB8C31B9DE0530EF4520A0CFC-0EED8E6FA7EC4A7E9CB057419446F524,,753,150,1,0\\\",\\\"0EED8E6FA7EC4A7E9CB057419446F524-6B497C495690451AE0530EF4520AA364,,392,116,1,0\\\",\\\"6B497C495690451AE0530EF4520AA364-0EED8E6FA7EC4A7E9CB057419446F524,,392,78,1,0\\\",\\\"0EED8E6FA7EC4A7E9CB057419446F524-62556EAEB79D1B9DE0530EF4520A0CFC,,757,151,1,0\\\",\\\"62556EAEB79D1B9DE0530EF4520A0CFC-0EED8E6FA7EC4A7E9CB057419446F524,,879,175,1,0\\\",\\\"62556EAEB8C31B9DE0530EF4520A0CFC-6B497C495690451AE0530EF4520AA364,,60,12,1,1\\\",\\\"6B497C495690451AE0530EF4520AA364-62556EAEB8C31B9DE0530EF4520A0CFC,,8,1,1,1\\\",\\\"62556EAEB8C31B9DE0530EF4520A0CFC-62556EAEB79D1B9DE0530EF4520A0CFC,,41,8,1,1\\\",\\\"62556EAEB79D1B9DE0530EF4520A0CFC-62556EAEB8C31B9DE0530EF4520A0CFC,,122,24,1,1\\\",\\\"6B497C495690451AE0530EF4520AA364-62556EAEB79D1B9DE0530EF4520A0CFC,,699,139,1,0\\\",\\\"62556EAEB79D1B9DE0530EF4520A0CFC-6B497C495690451AE0530EF4520AA364,,695,138,1,0\\\"],\\\"poiTimeDistMatrix\\\":{\\\"6B497C495690451AE0530EF4520AA364,146,133\\\":[],\\\"62556EAEB8C31B9DE0530EF4520A0CFC,112,102\\\":[],\\\"62556EAEB79D1B9DE0530EF4520A0CFC,152,138\\\":[],\\\"0EED8E6FA7EC4A7E9CB057419446F524,49,44\\\":[],\\\"62556EAEB7B21B9DE0530EF4520A0CFC,210,191\\\":[]},\\\"doorInfoList\\\":{},\\\"missingAoiList\\\":[],\\\"missingBuildingList\\\":[],\\\"aoiAzimuthInfo\\\":{}}}}}\",\"fields\":{\"osip\":\"100.86.73.113\",\"log_topics\":\"GIS_RDS_PNS_QUERY_LOG\"}}";
        JSONObject jsonObject = JSON.parseObject(log);
        TransLogInfo o = new TransLogInfo();
        if (jsonObject != null) {
            JSONObject message = jsonObject.getJSONObject("message");
            if (message != null) {
                String dateTime = message.getString("dateTime");
                String sn = message.getString("sn");
                o.setDateTime(dateTime);
                o.setSn(sn);
                JSONObject url = message.getJSONObject("url");
                if (url != null) {
                    String reqId = url.getString("reqId");
                    String employeeId = url.getString("employeeId");
                    String cityCode = url.getString("cityCode");
                    String lng = url.getString("lng");
                    String lat = url.getString("lat");
                    String vehicleType = url.getString("vehicleType");
                    o.setReqId(reqId);
                    o.setEmployeeId(employeeId);
                    o.setCityCode(cityCode);
                    o.setLng(lng);
                    o.setLat(lat);
                    o.setVehicleType(vehicleType);
                    JSONObject aoiOrders = url.getJSONObject("aoiOrders");
                    if (aoiOrders != null) {
                        int aoiCount = aoiOrders.size();
                        int waybillCount = 0;
                        int poiWaybillCount = 0;
                        for (String key : aoiOrders.keySet()) {
                            String value = aoiOrders.getString(key).replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                            String[] split = value.split("\\|");
                            for (String s : split) {
                                String s1 = s.replaceAll("\"", "");
                                String[] split1 = s1.split(",");
                                if (StringUtils.isNotEmpty(split1[0])) {
                                    waybillCount++;
                                }
                                if (split1.length == 2 && StringUtils.isNotEmpty(split1[1])) {
                                    poiWaybillCount++;
                                }
                            }
                        }
                        o.setAoiCount(aoiCount + "");
                        o.setWaybillCount(waybillCount + "");
                        o.setPoiWaybillCount(poiWaybillCount + "");
                    }
                }
                String time = message.getString("time");
                o.setTime(time);
                JSONObject data = message.getJSONObject("data");
                if (data != null) {
                    JSONObject result = data.getJSONObject("result");
                    if (result != null) {
                        JSONObject data1 = result.getJSONObject("data");
                        if (data1 != null) {
                            String employeeAoiId = data1.getString("employeeAoiId");
                            o.setEmployeeAoiId(employeeAoiId);

                            String poiInfoList = data1.getString("poiInfoList");
                            int poiCount = 0;
                            int poiBuildingCount = 0;
                            int poiEntranceCount = 0;
                            if (StringUtils.isNotEmpty(poiInfoList)) {
                                poiInfoList = poiInfoList.replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                String[] split = poiInfoList.split("\\|");
                                for (String s : split) {
                                    String s1 = s.replaceAll("\"", "");
                                    String[] split1 = s1.split(",");
                                    if (StringUtils.isNotEmpty(split1[0])) {
                                        poiCount++;
                                    }
                                    if (split1.length == 2 && StringUtils.equals(split1[1], "1")) {
                                        poiBuildingCount++;
                                    }
                                    if (split1.length == 2 && StringUtils.equals(split1[1], "0")) {
                                        poiEntranceCount++;
                                    }
                                }
                            }
                            o.setPoiCount(poiCount + "");
                            o.setPoiBuildingCount(poiBuildingCount + "");
                            o.setPoiEntranceCount(poiEntranceCount + "");

                            String aoiTimeDistMatrix = data1.getString("aoiTimeDistMatrix");
                            int aoiMatrixCount = 0;
                            int aoiMatrix0Count = 0;
                            int aoiMatrix1Count = 0;
                            int aoiMatrix2Count = 0;
                            int aoiMatrix3Count = 0;
                            if (StringUtils.isNotEmpty(aoiTimeDistMatrix)) {
                                aoiTimeDistMatrix = aoiTimeDistMatrix.replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                String[] split = aoiTimeDistMatrix.split("\\|");
                                for (String s : split) {
                                    String s1 = s.replaceAll("\"", "");
                                    String[] split1 = s1.split(",");
                                    if (StringUtils.isNotEmpty(split1[0])) {
                                        if (split1[0].contains("-")) {
                                            aoiMatrixCount++;
                                        }
                                    }
                                    if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "0")) {
                                        aoiMatrix0Count++;
                                    }
                                    if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "1")) {
                                        aoiMatrix1Count++;
                                    }
                                    if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "2")) {
                                        aoiMatrix2Count++;
                                    }
                                    if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "3")) {
                                        aoiMatrix3Count++;
                                    }
                                }
                            }
                            o.setAoiMatrixCount(aoiMatrixCount + "");
                            o.setAoiMatrix0Count(aoiMatrix0Count + "");
                            o.setAoiMatrix1Count(aoiMatrix1Count + "");
                            o.setAoiMatrix2Count(aoiMatrix2Count + "");
                            o.setAoiMatrix3Count(aoiMatrix3Count + "");

                            JSONObject poiTimeDistMatrix = data1.getJSONObject("poiTimeDistMatrix");
                            int poiMatrixCount = 0;
                            int poiMatrix0Count = 0;
                            int poiMatrix1Count = 0;
                            int poiMatrix2Count = 0;
                            int poiMatrix3Count = 0;
                            if (poiTimeDistMatrix != null) {
                                for (String key : poiTimeDistMatrix.keySet()) {
                                    String value = poiTimeDistMatrix.getString(key).replaceAll("\",\"", "\"|\"").replaceAll("(\\[|])", "");
                                    String[] split = value.split("\\|");
                                    for (String s : split) {
                                        String s1 = s.replaceAll("\"", "");
                                        String[] split1 = s1.split(",");
                                        if (StringUtils.isNotEmpty(split1[0])) {
                                            if (split1[0].contains("-")) {
                                                poiMatrixCount++;
                                            }
                                        }
                                        if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "0")) {
                                            poiMatrix0Count++;
                                        }
                                        if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "1")) {
                                            poiMatrix1Count++;
                                        }
                                        if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "2")) {
                                            poiMatrix2Count++;
                                        }
                                        if (StringUtils.isNotEmpty(split1[split1.length - 1]) && StringUtils.equals(split1[split1.length - 1], "3")) {
                                            poiMatrix3Count++;
                                        }
                                    }
                                }
                            }
                            o.setPoiMatrixCount(poiMatrixCount + "");
                            o.setPoiMatrix0Count(poiMatrix0Count + "");
                            o.setPoiMatrix1Count(poiMatrix1Count + "");
                            o.setPoiMatrix2Count(poiMatrix2Count + "");
                            o.setPoiMatrix3Count(poiMatrix3Count + "");

                            String missingAoiList = data1.getString("missingAoiList");
                            String missingBuildingList = data1.getString("missingBuildingList");
                            int missAoiCount = 0;
                            int missPoiCount = 0;
                            if (StringUtils.isNotEmpty(missingAoiList)) {
                                missingAoiList = missingAoiList.replaceAll("(\\[|])", "");
                                String[] split = missingAoiList.split(",");
                                for (int i = 0; i < split.length; i++) {
                                    if (StringUtils.isNotEmpty(split[i])) {
                                        missAoiCount++;
                                    }
                                }
                            }
                            o.setMissAoiCount(missAoiCount + "");

                            if (StringUtils.isNotEmpty(missingBuildingList)) {
                                missingBuildingList = missingBuildingList.replaceAll("(\\[|])", "");
                                String[] split = missingBuildingList.split(",");
                                for (int i = 0; i < split.length; i++) {
                                    if (StringUtils.isNotEmpty(split[i])) {
                                        missPoiCount++;
                                    }
                                }
                            }
                            o.setMissPoiCount(missPoiCount + "");
                        }
                    }
                }
            }
        }
        logger.error("o:{}", JSON.toJSONString(o));
    }
}
