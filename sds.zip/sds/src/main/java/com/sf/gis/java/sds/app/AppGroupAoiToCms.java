package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.GroupAoiToCmsController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppGroupAoiToCms {
    private static Logger logger = LoggerFactory.getLogger(AppGroupAoiToCms.class);

    public static void main(String[] args) {
        String incDay = args[0];
        logger.error("incDay:{}", incDay);
        logger.error("run start");
        new GroupAoiToCmsController().start(incDay);
        logger.error("run end");


    }
}
