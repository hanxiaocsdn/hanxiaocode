package com.sf.gis.java.sds.bean;

public class HookTableInfo {
    public String tableName;
    public String cityColumn;
    public String zcColumn;
    public String addressColumn;
    public HookTableInfo(String tableName, String cityColumn, String zcColumn,
                         String addressColumn) {
        this.tableName = tableName;
        this.cityColumn = cityColumn;
        this.zcColumn = zcColumn;
        this.addressColumn = addressColumn;
    }

}