package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.HisTtAndTelInterceptController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppHisTtAndTelIntercept {
    private static Logger logger = LoggerFactory.getLogger(AppHisTtAndTelIntercept.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        new HisTtAndTelInterceptController().process(date);
        logger.error("process end");
    }
}
