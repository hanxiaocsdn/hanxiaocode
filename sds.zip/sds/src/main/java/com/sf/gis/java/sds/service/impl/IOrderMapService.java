package com.sf.gis.java.sds.service.impl;

import com.sf.gis.java.sds.pojo.AddressOrder;

import java.util.List;

public interface IOrderMapService {

    void createTable();

    void insert(List<AddressOrder> saveResult) throws Exception;

}
