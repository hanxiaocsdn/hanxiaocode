package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CmsAddress;
import com.sf.gis.java.sds.pojo.CmsIndexStat;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;

/**
 * 任务id：909307（【壹竿-SD】CMS地址库锁定地址数量统计）
 * 需求方：01434066（宋雨莲）
 * 研发：01399581（匡仁衡）
 */
public class AppCmsIndexStat {
    private static Logger logger = LoggerFactory.getLogger(AppCmsIndexStat.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppCmsIndexStat");
        SparkSession spark = sparkInfo.getSession();
        JavaSparkContext sc = sparkInfo.getContext();
        spark.sql(String.format("alter table dm_gis.cms_count_lock_num drop if EXISTS partition(inc_day='%s')", date));
        Properties city_num_map = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        for (Map.Entry<Object, Object> map : city_num_map.entrySet()) {
            String city = (String) map.getKey();
//            if (!StringUtils.equals(city, "010")) {
//                continue;
//            }
            String num = (String) map.getValue();
            String table = "wchka.cms_address_" + num;
            String condition = String.format("city_code = '%s' and status != 2 and del_flag != 1", city);
            logger.error("获取表:{},city_code:{},数据", table, city);
            JavaRDD<CmsAddress> rdd = spark.read().format("jdbc")
                    .option("driver", "com.mysql.jdbc.Driver")
                    .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                    .option("dbtable", table)
                    .option("user", "wchka_aoi")
                    .option("password", "giscmsaoi123")
                    .load()
                    .where(condition)
                    .select("city_code", "adcode", "type", "status", "del_flag", "extend_attach1")
                    .repartition(20)
                    .toJavaRDD()
                    .map(row -> {
                        String city_code = "";
                        String adcode = "";
                        String type = "";
                        String status = "";
                        String del_flag = "";
                        String extend_attach1 = "";

                        try {
                            city_code = row.getString(0);
                        } catch (Exception e) {
                        }

                        try {
                            adcode = row.getString(1);
                        } catch (Exception e) {
                        }

                        try {
                            type = row.getInt(2) + "";
                        } catch (Exception e) {
                        }

                        try {
                            status = row.getInt(3) + "";
                        } catch (Exception e) {
                        }

                        try {
                            del_flag = row.getInt(4) + "";
                        } catch (Exception e) {
                        }

                        try {
                            extend_attach1 = row.getString(5);
                        } catch (Exception e) {
                        }

                        CmsAddress o = new CmsAddress();
                        o.setCity_code(fixnulltoStr(city_code));
                        o.setAdcode(fixnulltoStr(adcode));
                        o.setType(fixnulltoStr(type));
                        o.setStatus(fixnulltoStr(status));
                        o.setDel_flag(fixnulltoStr(del_flag));
                        o.setExtend_attach1(fixnulltoStr(extend_attach1));

                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());
            rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<CmsAddress> lockStatusRdd = rdd.map(o -> {
                String lock_status = "0";
                String adcode = o.getAdcode();
                if (Arrays.asList("1,4,5,6,7,8,9,10,11".split(",")).contains(adcode) || (StringUtils.isNotEmpty(adcode) && isNumeric(adcode) && adcode.length() <= 2 && Integer.parseInt(adcode) > 11 && Integer.parseInt(adcode) < 100)) {
                    lock_status = "1";
                }
                String extend_attach1 = o.getExtend_attach1();
                if (StringUtils.equals(extend_attach1, "1")) {
                    lock_status = "1";
                }
                o.setLock_status(lock_status);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("lockStatusRdd cnt:{}", lockStatusRdd.count());
            rdd.unpersist();

//            saveData(spark, lockStatusRdd, date);

            logger.error("统计表:{},city_code:{},指标", table, city);
            JavaRDD<CmsIndexStat> resultRdd = lockStatusRdd.mapToPair(o -> {
                String city_code = o.getCity_code();
                String type = o.getType();
                String lock_status = o.getLock_status();
                String adcode = o.getAdcode();
                String extend_attach1 = o.getExtend_attach1();

                int total_num = 1;
                int lock_num = "1".equals(lock_status) ? 1 : 0;
                int ad1_num = "1".equals(adcode) ? 1 : 0;
                int ad4_num = "4".equals(adcode) ? 1 : 0;
                int ad5_num = "5".equals(adcode) ? 1 : 0;
                int ad6_num = "6".equals(adcode) ? 1 : 0;
                int ad7_num = "7".equals(adcode) ? 1 : 0;
                int ad8_num = "8".equals(adcode) ? 1 : 0;
                int ad9_num = "9".equals(adcode) ? 1 : 0;
                int ad10_num = "10".equals(adcode) ? 1 : 0;
                int ad11_num = "11".equals(adcode) ? 1 : 0;

                int other_ad_num = "1".equals(lock_status) && StringUtils.isNotEmpty(adcode) && isNumeric(adcode) && adcode.length() <= 2 && Integer.parseInt(adcode) < 100 && Integer.parseInt(adcode) > 11 ? 1 : 0;
                int addr_lock_num = "1".equals(extend_attach1) && (Arrays.asList("2,3".split(",")).contains(adcode) || adcode.length() > 2 || StringUtils.isEmpty(adcode)) ? 1 : 0;

                return new Tuple2<>(city_code + "_" + type, new Integer[]{total_num, lock_num, ad1_num, ad4_num, ad5_num, ad6_num, ad7_num, ad8_num, ad9_num, ad10_num, ad11_num, other_ad_num, addr_lock_num});
            }).reduceByKey((o1, o2) -> new Integer[]{o1[0] + o2[0], o1[1] + o2[1], o1[2] + o2[2], o1[3] + o2[3], o1[4] + o2[4], o1[5] + o2[5], o1[6] + o2[6], o1[7] + o2[7], o1[8] + o2[8], o1[9] + o2[9], o1[10] + o2[10], o1[11] + o2[11], o1[12] + o2[12]})
                    .map(tp -> {
                        String key = tp._1;
                        String city_code = key.split("_")[0];
                        String type = key.split("_")[1];
                        CmsIndexStat o = new CmsIndexStat();
                        o.setCity_code(city_code);
                        o.setType(type);
                        o.setInc_day(date);
                        Integer[] list = tp._2;

                        o.setTotal_num(list[0] + "");
                        o.setLock_num(list[1] + "");
                        o.setAd1_num(list[2] + "");
                        o.setAd4_num(list[3] + "");
                        o.setAd5_num(list[4] + "");
                        o.setAd6_num(list[5] + "");
                        o.setAd7_num(list[6] + "");
                        o.setAd8_num(list[7] + "");
                        o.setAd9_num(list[8] + "");
                        o.setAd10_num(list[9] + "");
                        o.setAd11_num(list[10] + "");
                        o.setOther_ad_num(list[11] + "");
                        o.setAddr_lock_num(list[12] + "");
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            lockStatusRdd.unpersist();

            DataUtil.saveInto(spark, sc, "dm_gis.cms_count_lock_num", CmsIndexStat.class, resultRdd, "inc_day");
            resultRdd.unpersist();
            logger.error("===============================================================");
        }
        logger.error("end...");
        sc.stop();
    }

    public static boolean isNumeric(String str) {
        return str.matches("^\\d+$");
    }

    public static String fixnulltoStr(String str) {
        if (str == null || str.trim().toLowerCase() == "null") {
            return "";
        }
        return str;
    }

    public static void saveData(SparkSession spark, JavaRDD<CmsAddress> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCity_code(), o.getAdcode(), o.getType(), o.getStatus(), o.getDel_flag(), o.getExtend_attach1(), o.getLock_status()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "city_code", "adcode", "type", "status", "del_flag", "extend_attach1", "lock_status"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cms_count_lock_num_detail_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.cms_count_lock_num_detail";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
