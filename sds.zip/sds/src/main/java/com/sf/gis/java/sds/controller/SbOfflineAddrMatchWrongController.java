package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.sds.pojo.ChknEtlV3;
import com.sf.gis.java.sds.utils.DistanceTool;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class SbOfflineAddrMatchWrongController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(SbOfflineAddrMatchWrongController.class);
    private static String aoi_url = "http://gis-apis.int.sfcloud.local:1080/dept2/zctc/aoiid?aoi_id=%s&ak=c756dacde4814522b8b0f3f8d6d844b6&opt=area";
    private static String getteam_url = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam?ak=c756dacde4814522b8b0f3f8d6d844b6&address=%s&city=%s&company=&province=&cityName=&dept=%s&sssDept=&tc2Dept=&tc2Tc=&tc2Aoi=&tc2AoiCode=&x=&y=&mobile=&opt=ks16";
    private static String split_url = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=c756dacde4814522b8b0f3f8d6d844b6";
    private static String keyword_url = "http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?ak=c756dacde4814522b8b0f3f8d6d844b6&address=%s&addrType=0";
    private static String atdispatch_url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=e6a874c441cc41eda1b443d420f6632d&opt=normdetail&address=%s&city=%s";
    private static String match_url = "http://10.242.5.159:8090/match?input1=%s&input2=%s";
    private static int limitSec = 50 / 10;

    private static String account = "01399581";
    private static String taskId = "856";
    private static String taskName = "审补下线地址匹配错误工艺";

    public void start(String date) {
        //初始化spark
        SparkSession spark = Spark.getSparkSession("SbOfflineAddrMatchWrongController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        String sql = String.format("select " +
                "  c.is_vague_addr is_vague_addr, " +
                "  c.norm_is_identify norm_is_identify, " +
                "  c.city_code city_code, " +
                "  c.chknid chknid, " +
                "  c.address address, " +
                "  c.dept_chkn dept_chkn, " +
                "  c.dept_norm dept_norm, " +
                "  c.dept_equal1 dept_equal1, " +
                "  c.aoiid_norm aoiid_norm, " +
                "  c.aoiname_norm aoiname_norm, " +
                "  c.aoiid_chkn aoiid_chkn, " +
                "  c.aoiname_chkn aoiname_chkn, " +
                "  c.group_id group_id, " +
                "  c.standard standard, " +
                "  c.splitinfo_chkn splitinfo_chkn, " +
                "  c.norm_rsp norm_rsp, " +
                "  c.inc_day inc_day " +
                "from " +
                "  ( " +
                "    select " +
                "      if( " +
                "        ( " +
                "          tag = '1' " +
                "          and ( " +
                "            hasloc = 'true' " +
                "            or hasdist = 'true' " +
                "          ) " +
                "          and ( " +
                "            hastxt = 'false' " +
                "            or ( " +
                "              hastxt = 'true' " +
                "              and isbehind = 'false' " +
                "            ) " +
                "          ) " +
                "        ), " +
                "        '模糊地址', " +
                "        '非模糊地址' " +
                "      ) as is_vague_addr, " +
                "      if( " +
                "        dept <> '' " +
                "        and group_id <> '', " +
                "        'norm识别', " +
                "        'norm不识别' " +
                "      ) as norm_is_identify, " +
                "      city_code, " +
                "      chknid, " +
                "      address, " +
                "      zno_code as dept_chkn, " +
                "      dept as dept_norm, " +
                "      dept_equal1, " +
                "      aoiid_norm, " +
                "      b2.aoi_name as aoiname_norm, " +
                "      aoiid_chkn, " +
                "      b1.aoi_name as aoiname_chkn, " +
                "      group_id, " +
                "      standard, " +
                "      splitinfo_chkn, " +
                "      norm_rsp, " +
                "      inc_day " +
                "    from " +
                "      dm_gis.chkn_etl_v4 a " +
                "      left join ( " +
                "        select " +
                "          aoi_id, " +
                "          aoi_name " +
                "        from " +
                "          dm_gis.cms_aoi_sch " +
                "        where " +
                "          del_flag != '1' " +
                "      ) b1 on a.aoiid_chkn = b1.aoi_id " +
                "      left join ( " +
                "        select " +
                "          aoi_id, " +
                "          aoi_name " +
                "        from " +
                "          dm_gis.cms_aoi_sch " +
                "        where " +
                "          del_flag != '1' " +
                "      ) b2 on a.aoiid_norm = b2.aoi_id " +
                "    where " +
                "      a.inc_day = '%s' " +
                "      and a.action != '0' " +
                "  ) c " +
                "where " +
                "  c.is_vague_addr = '非模糊地址' " +
                "  and c.norm_is_identify = 'norm识别'", date);
        JavaRDD<ChknEtlV3> rdd = DataUtil.loadData(spark, sc, sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", aoi_url, "c756dacde4814522b8b0f3f8d6d844b6", rdd.count() * 2, 10);
        JavaRDD<ChknEtlV3> xyRdd = rdd.map(o -> {
            o = getXy(o, "chkn");
            o = getXy(o, "norm");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xyRdd cnt:{}", xyRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        JavaRDD<ChknEtlV3> distanceRdd = xyRdd.map(o -> {
            String xcoord_chkn = o.getXcoord_chkn();
            String ycoord_chkn = o.getYcoord_chkn();
            String xcoord_norm = o.getXcoord_norm();
            String ycoord_norm = o.getYcoord_norm();

            if (StringUtils.isNotEmpty(xcoord_chkn) && StringUtils.isNotEmpty(ycoord_chkn) && StringUtils.isNotEmpty(xcoord_norm) && StringUtils.isNotEmpty(ycoord_norm)) {
                double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(xcoord_chkn), Double.parseDouble(ycoord_chkn), Double.parseDouble(xcoord_norm), Double.parseDouble(ycoord_norm));
                o.setDistance(distance + "");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("distanceRdd cnt:{}", distanceRdd.count());
        xyRdd.unpersist();

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getteam_url, "c756dacde4814522b8b0f3f8d6d844b6", distanceRdd.count(), 10);
        JavaRDD<ChknEtlV3> aoiRdd = distanceRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getCity_code() + "_" + o.getDept_chkn(), o)).groupByKey().flatMap(tp -> {
            List<ChknEtlV3> list = Lists.newArrayList(tp._2);
            ChknEtlV3 o = list.get(0);
            String address = o.getAddress();
            String city_code = o.getCity_code();
            String dept_chkn = o.getDept_chkn();
            String aoi = "";
            if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(dept_chkn)) {
                String req = String.format(getteam_url, URLEncoder.encode(address, "UTF-8"), city_code, dept_chkn);
                String resp = HttpInvokeUtil.sendGet(req);
                try {
                    aoi = JSON.parseObject(resp).getJSONObject("result").getString("aoi");
                    o.setAoiid_chkn_ks16(aoi);
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
            String finalAoi = aoi;
            return list.stream().peek(t -> t.setAoiid_chkn_ks16(finalAoi)).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:{}", aoiRdd.count());
        distanceRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", split_url, "c756dacde4814522b8b0f3f8d6d844b6", aoiRdd.count(), 10);
        JavaRDD<ChknEtlV3> splitNormRdd = aoiRdd.map(o -> {
            String standard = o.getStandard();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(standard)) {
                String req = String.format(split_url, URLEncoder.encode(standard, "UTF-8"), city_code);
                String resp = HttpInvokeUtil.sendGet(req);
                String split = getSplit(resp);
                o.setSplitinfo_norm(split);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitNormRdd cnt:{}", splitNormRdd.count());
        aoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", keyword_url, "c756dacde4814522b8b0f3f8d6d844b6", splitNormRdd.count(), 10);
        JavaRDD<ChknEtlV3> keywordRdd = splitNormRdd.map(o -> {
            String address = o.getAddress();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(keyword_url, URLEncoder.encode(address, "UTF-8"));
                String resp = HttpInvokeUtil.sendGet(req);
                String key_word = "";
                try {
                    key_word = JSON.parseObject(resp).getJSONObject("result").getJSONObject("keyInfo").getString("key_word").replace("|", "");
                    o.setKeyword_chkn(key_word);
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setAddress_nokeyword(address.replace(key_word, ""));
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("keywordRdd cnt:{}", keywordRdd.count());
        splitNormRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id4);

        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atdispatch_url, "e6a874c441cc41eda1b443d420f6632d", keywordRdd.count(), 10);
        JavaRDD<ChknEtlV3> afterDeptRdd = keywordRdd.map(o -> {
            String address_nokeyword = o.getAddress_nokeyword();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(address_nokeyword)) {
                String req = String.format(atdispatch_url, URLEncoder.encode(address_nokeyword, "UTF-8"), city_code);
                String resp = HttpInvokeUtil.sendGet(req);
                try {
                    String dept = JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept");
                    o.setAfterdept_nokeyword(dept);
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("afterDeptRdd cnt:{}", afterDeptRdd.count());
        keywordRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id5);

//        String match_wrong_sql = "select * from dm_gis.chkn_etl_v3_sb_offline_addr_match_wrong where inc_day = '20230505'";
//        JavaRDD<ChknEtlV3> match_wrongRdd = DataUtil.loadData(spark, sc, match_wrong_sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("match_wrongRdd cnt:{}", match_wrongRdd.count());
//
//        String match_sql = "select * from dm_gis.chkn_etl_v3_sb_offline_addr_match where inc_day = '20230505'";
//        JavaRDD<ChknEtlV3> matchRdd = DataUtil.loadData(spark, sc, match_sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("matchRdd cnt:{}", matchRdd.count());
//
//        JavaRDD<ChknEtlV3> afterDeptRdd = match_wrongRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getStandard(), o)).leftOuterJoin(matchRdd.mapToPair(o -> new Tuple2<>(o.getAddress() + "_" + o.getStandard(), o))).map(tp -> {
//            ChknEtlV3 o = tp._2._1;
//            if (tp._2._2 != null && tp._2._2.isPresent()) {
//                ChknEtlV3 chknEtlV3 = tp._2._2.get();
//
//                o.setLabel(chknEtlV3.getLabel());
//                o.setScore(chknEtlV3.getScore());
//            }
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("afterDeptRdd cnt:{}", afterDeptRdd.count());
//        match_wrongRdd.unpersist();
//        matchRdd.unpersist();

//        JavaRDD<ChknEtlV3> resultRdd = afterDeptRdd.map(o -> {
//            String label = o.getLabel();
//            String score = o.getScore();
//            String distance = o.getDistance();
//            String result_mgeo_aoidistance = "";
//            if (StringUtils.equals(label, "not_match") && StringUtils.isNotEmpty(score) && Double.parseDouble(score) > 0.95 && StringUtils.isNotEmpty(distance) && Double.parseDouble(distance) >= 800) {
//                result_mgeo_aoidistance = "匹配错误";
//            }
//
//            String aoiid_chkn = o.getAoiid_chkn();
//            String aoiid_norm = o.getAoiid_norm();
//            String aoiid_chkn_ks16 = o.getAoiid_chkn_ks16();
//            String result_mgeo_ks16chknaoi = "";
//            if (StringUtils.equals(label, "not_match") && !StringUtils.equals(aoiid_chkn, aoiid_norm) && StringUtils.isNotEmpty(aoiid_chkn_ks16) && StringUtils.equals(aoiid_chkn_ks16, aoiid_chkn)) {
//                result_mgeo_ks16chknaoi = "匹配错误";
//            }
//
//            String dept_equal1 = o.getDept_equal1();
//            String dept_chkn = o.getDept_chkn();
//            String afterdept_nokeyword = o.getAfterdept_nokeyword();
//            String splitinfo_chkn = o.getSplitinfo_chkn();
//            String splitinfo_norm = o.getSplitinfo_norm();
//            String result_nokeyword_dept = "";
//            if (StringUtils.equals(dept_equal1, "false") && StringUtils.isNotEmpty(dept_chkn) && StringUtils.equals(dept_chkn, afterdept_nokeyword) && !judge(splitinfo_chkn, splitinfo_norm)) {
//                result_nokeyword_dept = "匹配错误";
//            }
//            o.setResult_mgeo_aoidistance(result_mgeo_aoidistance);
//            o.setResult_mgeo_ks16chknaoi(result_mgeo_ks16chknaoi);
//            o.setResult_nokeyword_dept(result_nokeyword_dept);
//
//            String unmatch_result_combine = "";
//            if (StringUtils.isNotEmpty(result_mgeo_aoidistance) || StringUtils.isNotEmpty(result_mgeo_ks16chknaoi) || StringUtils.isNotEmpty(result_nokeyword_dept)) {
//                unmatch_result_combine = "y";
//            }
//
//            o.setUnmatch_result_combine(unmatch_result_combine);
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        afterDeptRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.chkn_etl_v3_sb_offline_addr_match_wrong drop if EXISTS partition(inc_day='%s')", date));
        DataUtil.saveInto(spark, sc, "dm_gis.chkn_etl_v3_sb_offline_addr_match_wrong", ChknEtlV3.class, afterDeptRdd, "inc_day");
        afterDeptRdd.unpersist();
        sc.stop();
    }

    public boolean judge(String split_chkn, String split_norm) {
        if (StringUtils.isNotEmpty(split_chkn) && StringUtils.isNotEmpty(split_norm)) {
            try {
                String[] chkn = split_chkn.split(",");
                String[] norm = split_norm.split(",");

                String[] last_chkn = chkn[chkn.length - 1].split("\\^");
                String[] last_norm = norm[norm.length - 1].split("\\^");

                if (last_chkn.length >= 2 && last_norm.length >= 2) {
                    String chkn_word = last_chkn[0];
                    String chkn_level = last_chkn[1];
                    String chkn_after = chkn_level.substring(1, chkn_level.length());

                    String norm_word = last_norm[0];
                    String norm_level = last_norm[1];
                    String norm_after = norm_level.substring(1, norm_level.length());

                    if (StringUtils.equals(chkn_after, "13") && StringUtils.equals(chkn_after, norm_after) && StringUtils.equals(chkn_word, norm_word)) {
                        return true;
                    }
                }
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return false;
    }

    public String getSplit(String content) {
        ArrayList<String> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(content)) {
            try {
                JSONArray info = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("info");
                for (int i = 0; i < info.size(); i++) {
                    JSONObject jsonObject = info.getJSONObject(i);

                    String level = jsonObject.getString("level");
                    String name = jsonObject.getString("name");
                    String prop = jsonObject.getString("prop");
                    list.add(name + "^" + prop + level);
                }
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        return list.size() > 0 ? String.join(",", list) : "";
    }

    public ChknEtlV3 getXy(ChknEtlV3 o, String tag) {
        String aoi = "";
        String x = "";
        String y = "";
        if (StringUtils.equals(tag, "chkn")) {
            aoi = o.getAoiid_chkn();
        } else if (StringUtils.equals(tag, "norm")) {
            aoi = o.getAoiid_norm();
        }
        if (StringUtils.isNotEmpty(aoi)) {
            String req = String.format(aoi_url, aoi);
            String resp = HttpInvokeUtil.sendGet(req);

            try {
                x = JSON.parseObject(resp).getJSONObject("result").getJSONArray("data").getJSONObject(0).getJSONObject("central_coord").getString("x");
                y = JSON.parseObject(resp).getJSONObject("result").getJSONArray("data").getJSONObject(0).getJSONObject("central_coord").getString("y");
            } catch (Exception e) {
//                e.printStackTrace();
            }
        }
        if (StringUtils.equals(tag, "chkn")) {
            o.setXcoord_chkn(x);
            o.setYcoord_chkn(y);
        } else if (StringUtils.equals(tag, "norm")) {
            o.setXcoord_norm(x);
            o.setYcoord_norm(y);
        }
        return o;
    }

}
