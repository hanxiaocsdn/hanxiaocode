package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.StdAddrCoincideJudgeSameAoiBuildingController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;

/**
 * 研发：匡仁衡
 * 需求：【B库质量提升】标准地址重合判断_同aoi内楼栋号一致
 * 需求方：赵媛
 */
public class AppStdAddrCoincideJudgeSameAoiBuilding{
    private static Logger logger = LoggerFactory.getLogger(AppStdAddrCoincideJudgeSameAoiBuilding.class);

    public static void main(String[] args) {
        String statDate = args[0];
        logger.error("statDate:{}", statDate);
        logger.error("run start");
        new StdAddrCoincideJudgeSameAoiBuildingController().start(statDate);
        logger.error("run end");
    }
}
