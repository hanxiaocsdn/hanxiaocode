package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.waybillaoi.*;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TtOrderWaybillService implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(TtOrderWaybillService.class);

    public JavaRDD<AoiValue> loadAoiValue(SparkInfo si, String date, String is_pick, String area_code) {
        String sql = String.format("select aoi_id,channel,wage_level from dm_tc_waybillinfo.aoi_value_aoi where inc_month = '%s' and is_pick = '%s' and area_code = '%s'", date, is_pick, area_code);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, AoiValue.class);
    }

    public JavaRDD<ZnocodeToAoi> loadZnocodeToAoiData(SparkInfo si, String date) {
        String sql = String.format("select dept_code,aoi_id from dm_gis.znocode_2_aoi where inc_day = '%s' and (aoi_id is not null and aoi_id <>'')", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, ZnocodeToAoi.class);
    }

    public JavaRDD<AoiAreaAoi> loadAoiAreaAoiData(SparkInfo si) {
        String sql = "select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi";
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, AoiAreaAoi.class);
    }

    public JavaRDD<TtWaybillInfo> loadTtWaybillInfoData1(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybill_no,order_no,consignee_emp_code,deliver_emp_code from dm_gis.tt_waybill_info where inc_day between '%s' and '%s' and (waybill_no is not null and waybill_no <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtWaybillInfo.class);
    }

    public JavaRDD<TtWaybillInfo> loadTtWaybillInfoData2(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybill_no,src_city_code,src_county,src_dist_code,consignor_addr,consignor_mobile,consignor_phone,consignor_comp_name,freight_monthly_acct_code from dm_gis.tt_waybill_info where inc_day between '%s' and '%s' and (waybill_no is not null and waybill_no <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtWaybillInfo.class);
    }

    public JavaRDD<TtWaybillInfo> loadTtWaybillInfoData3(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybill_no,dest_city_code,dest_county,dest_dist_code,consignee_addr,consignee_mobile,consignee_phone,consignee_comp_name from dm_gis.tt_waybill_info where inc_day between '%s' and '%s' and (waybill_no is not null and waybill_no <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtWaybillInfo.class);
    }

    public JavaRDD<AddressInfoMapDi> loadAddressInfoMapDiData(SparkInfo si) {
        String sql = "select * from dm_gis.city_name_map where inc_day = '20210317'";
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, AddressInfoMapDi.class);
    }

    public JavaRDD<RdsOmsAoi> loadRdsOmsfromAoiData1(SparkInfo si, String date1, String date2) {
        String sql = String.format("select orderno,deptcode,aoicode,reqtime from dm_gis.rds_omsfrom_aoi where inc_day between '%s' and '%s' and (waybillno is not null and waybillno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmsAoi.class);
    }

    public JavaRDD<RdsOmsAoi> loadRdsOmstoAoiData1(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybillno,addresseedeptcode deptcode,addresseeaoicode aoicode,reqtime from dm_gis.rds_omsto_aoi where inc_day between '%s' and '%s' and (waybillno is not null and waybillno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmsAoi.class);
    }

    public JavaRDD<RdsOmsfromAoi> loadRdsOmsfromAoiData(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybillno,province,city,citycode,address,county,orderno,customeraccount,mobile,phone,company,isnotundercall from dm_gis.rds_omsfrom_aoi where inc_day between '%s' and '%s' and (waybillno is not null and waybillno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmsfromAoi.class);
    }

    public JavaRDD<RdsOmsfromAoi> loadRdsOmsfromAoiOrderData(SparkInfo si, String date1, String date2) {
        String sql = String.format("select orderno,deptcode,aoicode from dm_gis.rds_omsfrom_aoi where inc_day between '%s' and '%s' and (orderno is not null and orderno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmsfromAoi.class);
    }

    public JavaRDD<RdsOmstoAoi> loadRdsOmstoAoiData(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybillno,addresseeaoicode,addresseedeptcode,orderno from dm_gis.rds_omsto_aoi where inc_day between '%s' and '%s' and (waybillno is not null and waybillno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmstoAoi.class);
    }

    public JavaRDD<RdsOmstoAoi> loadRdsOmstoAoiAddrData(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybillno,receiverprovince,receivercity,addresseecitycode,addresseeaddr,receiverarea,addresseecompname,orderno,addresseemobile,addresseephone from dm_gis.rds_omsto_aoi where inc_day between '%s' and '%s' and (waybillno is not null and waybillno <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, RdsOmstoAoi.class);
    }

    public JavaRDD<TtWaybillInfo> loadTtWaybillInfoData(SparkInfo si, String date1, String date2) {
        String sql = String.format("select waybill_no,source_waybill_no,order_no from dm_gis.tt_waybill_info where inc_day between '%s' and '%s' and (waybill_no is not null and waybill_no <>'')", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtWaybillInfo.class);
    }

    public JavaRDD<TtEdcsWaybillContentSws> loadTtEdcsWaybillContentSwsData(SparkInfo si, String date1, String date2, String citycode, String audit_type_code) {
        String sql = "";
        if (StringUtils.equals(audit_type_code, "1")) {
            sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws.sql", date1, audit_type_code, citycode);
        } else if (StringUtils.equals(audit_type_code, "2")) {
            sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws1.sql", date1, audit_type_code, citycode);
        }
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtEdcsWaybillContentSws.class);
    }

    public JavaRDD<TtEdcsWaybillContentSws> loadTtEdcsWaybillContentSwsData1(SparkInfo si, String date1, String date2, String citycode, String audit_type_code) {
        String sql = "";
        if (StringUtils.equals(audit_type_code, "1")) {
            sql = String.format("select waybill_no,original_zone_code,takeover_member_no,takeover_tm,inc_day from dm_ecas_dcs.tt_edcs_waybill_content_sws where inc_day between '%s' and '%s' and audit_type_code = '%s' and original_zone_code like '%s%%' and locate('aoiCode', waybill_content) != 0 and (waybill_no is not null and waybill_no <>'')", date1, date2, audit_type_code, citycode);
        } else if (StringUtils.equals(audit_type_code, "2")) {
//            sql = DataUtil.loadSql("tt_edcs_waybill_content_sws1.sql", date1, audit_type_code, date2, citycode);
        }
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtEdcsWaybillContentSws.class);
    }

    public JavaRDD<TtOrderAoiInfo> loadTtOrderWaybillData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select consignee_emp_code,aoi_id,aoi_zc from dm_gis.tt_order_hook where inc_day between '%s' and '%s' union (select deliver_emp_code consignee_emp_code,aoi_id,aoi_zc from dm_gis.tt_waybill_hook where inc_day between '%s' and '%s')", startDate, endDate, startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtOrderAoiInfo.class);
    }

    public JavaRDD<TtOrderAoiInfo> loadTtOrderData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select waybill_no waybill_id,consignee_emp_code,consigned_tm,aoi_id,src_lgt,src_lat,consignor_addr,order_no,source_waybill_no,src_dist_code,src_county from dm_gis.tt_order_hook where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtOrderAoiInfo.class);
    }

    public JavaRDD<TtOrderAoiInfo> loadTtWayBillData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select waybill_no waybill_id,deliver_emp_code consignee_emp_code,signin_tm consigned_tm,aoi_id,delivery_lgt src_lgt,delivery_lat src_lat,consignee_addr from dm_gis.tt_waybill_hook where inc_day between '%s' and '%s'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtOrderAoiInfo.class);
    }

    public JavaRDD<TtEdcsHiveCommissionDetail> loadTtEdcsHiveCommissionDetail(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select waybill_no,waybill_type from (select waybill_no,waybill_type,row_number() over(partition by waybill_no order by inc_day desc) as rank from dm_ecas_dcs.tt_edcs_hive_commission_detail where inc_day between '%s' and '%s' and audit_type = '2' and (waybill_no is not null and waybill_no <>'')) a where rank = 1", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtEdcsHiveCommissionDetail.class);
    }

    public JavaRDD<IncSgsTaskFlowNew> loadIncSgsTaskFlowNewData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select waybillno,operatime_new,eventlng,eventlat,eventtype,inc_day from ods_inc_sgs_core.inc_sgs_task_flow_new where inc_day between '%s' and '%s' and eventtype in('31201','31127')", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, IncSgsTaskFlowNew.class);
    }

    public JavaRDD<FvpCoreFactRoute> loadFvpCoreFactRoute(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select waybillno,opcode,barscantmstd from ods_kafka_fvp.fvp_core_fact_route where inc_day between '%s' and '%s' and destzonecode like '755%%'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, FvpCoreFactRoute.class);
    }

    public JavaRDD<AoiStatAoiid> loadAoiStatAoiid(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select aoi_id,count,inc_day from dm_gis.aoi_stat_aoiid where inc_day between '%s' and '%s' and stattype = 'all'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, AoiStatAoiid.class);
    }

    public JavaRDD<ScheduleWidthData> loadScheduleWidthData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select dept_code,dt,loginid,guid aoi_id from dm_tc_waybillinfo.schedule_width_data where inc_day between '%s' and '%s' and (guid is not null and guid <>'')", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, ScheduleWidthData.class);
    }

    public JavaRDD<TtAppointAddition> loadTtAppointAddition(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select appoint_internal_no,addition_key,addition_value from ods_shiva_oms.tt_appoint_addition where inc_day between '%s' and '%s' and addition_key in ('LONGITUDE','LATITUDE')", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, TtAppointAddition.class);
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkInfo si) {
        String sql = "select aoi_id,aoi_code,aoi_name,fa_type,zno_code from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, CmsAoiSch.class);
    }

    public void saveData(SparkSession spark, JavaRDD<TtEdcsWaybillContentSws> inRdd, String targetTable, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getOriginal_zone_code(), StringUtils.isNotEmpty(o.getOriginal_zone_code()) ? o.getOriginal_zone_code().substring(0, 3) : "",
                    o.getTakeover_member_no(), o.getTakeover_tm(), o.getLastAoiid(), o.getAoi_code(), o.getAoi_area_code(), o.getFa_type(), o.getTag(), o.getDestination_zone_code()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "waybill_no", "original_zone_code", "original_city_code", "member_no", "tm", "aoi_id", "original_aoi_code", "original_aoi_area_code", "fa_type", "tag", "destination_zone_code"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "spj_aoi_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public static List<NsCfgDto> getNsCfgList() {
        String dbConfig = "rls-mysql.properties";
        Connection conn = DbUtil.getInstance(dbConfig).getConn();
        List<NsCfgDto> nsCfgList = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select ns_code,ns_type_code,check_code_rule,extend from TM_NS_CFG");
            while (rs.next()) {
                NsCfgDto nsCfgDto = new NsCfgDto();
                String ns_code = rs.getString(1);
                String ns_type_code = rs.getString(2);
                String check_code_rule = rs.getString(3);
                String extend = rs.getString(4);

                nsCfgDto.setNsCode(ns_code);
                nsCfgDto.setNsTypeCode(ns_type_code);
                nsCfgDto.setCheckCodeRule(check_code_rule);
                nsCfgDto.setExtend(extend);
                nsCfgList.add(nsCfgDto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nsCfgList;
    }
}
