package com.sf.gis.java.sds.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.HttpUtils;
import com.sf.gis.scala.base.util.StringUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
//import com.sf.address.acf.bdp.http.HttpRequest;

public class BuildingGeo {
  public static List<String> getXY(String name) {
	List<String> listResult = new ArrayList<>();
	if (!StringUtils.nonEmpty(name)) {
		return listResult;
	}
	name = name.replace("\n", "").replace(" ", "").replace("#", "").replace("&", "")
			  .replace(",", "").replace("|", "");
	String sParams = String.format("address=%s&ak=6eeefc8dcc7c42869bd4f84a746f428d&opt=ma1", name);

	String sFormatUrl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?%s";
	String url = String.format(sFormatUrl, sParams);


    String xcoord = "";
    String ycoord = "";
    String level_13 = "";
    String level_14 = "";

	for (int index = 0; index < 5; ++index) {
		try {
//			String sResult = HttpRequest.doGet(url, "utf-8");
//			JSONObject jsonObject = JSON.parseObject(sResult);
			JSONObject jsonObject= HttpUtils.urlConnectionGetJson(url,5000);
			String sStatus = jsonObject.getString("status");
			System.out.println(jsonObject);
			if (sStatus.equals("0") == true) {
				JSONObject result = jsonObject.getJSONObject("result");
				xcoord = result.getString("xcoord");
				ycoord = result.getString("ycoord");
				JSONArray adrList = result.getJSONArray("addSplitInfo");
				for (int i = 0; i < adrList.size(); ++i) {
					JSONObject adrItem = (JSONObject) adrList.get(i);
					String level = adrItem.getString("level");
					String text = adrItem.getString("text");
					if (level.equals("13") == true) {
						if (text.endsWith("期") || text.endsWith("区") || text.endsWith("座"))
							level_13 = level_13 + text;
						else
							level_13 = level_13 + "|" + text;
					} else if (level.equals("14") == true) {
						level_14 = level_14 + "|" + text;
					}
				}
				break;
			} else {
				return listResult;
			}
		} catch (Exception e) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException tmp) {
			}
			if (index == 4){
				return listResult;
			}
		}
	}

    listResult.add(xcoord);
    listResult.add(ycoord);
    listResult.add(level_13);
    listResult.add(level_14);
    return listResult;
  }

  public static JSONArray sortJsonArray(JSONArray array){
	  array.sort(Comparator.comparing(obj->((JSONObject)obj).getString("ss"),Comparator.nullsFirst(Comparator.naturalOrder())));
	  return array;
  }
  public static List<String> getAssembleInfo(String name) {
  	List<String> listResult = new ArrayList<>();
	if (name.equals("") == true) {
		return listResult;
	}
	name = name.replace("\n", "").replace(" ", "").replace("#", "").replace("&", "")
			.replace(",", "").replace("|", "");
	String sParams = String.format("address=%s&ak=6eeefc8dcc7c42869bd4f84a746f428d&opt=ma1", name);

	String sFormatUrl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?%s";
	String url = String.format(sFormatUrl, sParams);


    String xcoord = "";
    String ycoord = "";
    String level_13 = "";
    String level_14 = "";
    String bld_name = "";
    String bld_id = "";
    String bld_group = "";

	for (int index = 0; index < 5; ++index) {
		String sResult = "";
		try {
//			sResult = HttpRequest.doGet(url, "utf-8");
//			JSONObject jsonObject = JSON.parseObject(sResult);
			JSONObject jsonObject=HttpUtils.urlConnectionGetJson(url,5000);
			String sStatus = jsonObject.getString("status");
			if (sStatus.equals("0") == true) {
				JSONObject result = jsonObject.getJSONObject("result");
				xcoord = result.getString("xcoord");
				ycoord = result.getString("ycoord");
				JSONArray adrList = result.getJSONArray("addSplitInfo");
				for (int i = 0; i < adrList.size(); ++i) {
					JSONObject adrItem = (JSONObject) adrList.get(i);
					String level = adrItem.getString("level");
					String text = adrItem.getString("text");
					if (level.equals("13") == true) {
						if (text.endsWith("期") || text.endsWith("区") || text.endsWith("座"))
							level_13 = level_13 + text;
						else
							level_13 = level_13 + "|" + text;
					} else if (level.equals("14") == true) {
						level_14 = level_14 + "|" + text;
					}
				}
				JSONObject assemble = result.getJSONObject("other");
				if (assemble.containsKey("aoi")) {
					bld_group = assemble.getString("aoi");
				}
				if (assemble.containsKey("group")) {
					bld_id = assemble.getString("group");
				}
				if (assemble.containsKey("match_address")) {
					bld_name = assemble.getString("match_address");
				}
				break;
			} else {
				JSONObject errObj = jsonObject.getJSONObject("result");
				String errMsg = errObj.getString("msg");
				listResult.add(level_13);
				listResult.add(level_14);
				listResult.add(errMsg + "&&" + errMsg + "&&" + errMsg + "&&" + "-1" + "&&" + "-1");
				return listResult;
			}
		} catch (Exception e) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException tmp) {
			}

			if (index == 4){
				String errMsg = sResult + " ==" + e.toString();
				listResult.add(level_13);
				listResult.add(level_14);
				listResult.add(errMsg + "&&" + errMsg + "&&" + errMsg + "&&" + "-1" + "&&" + "-1");
				return listResult;
			}
		}
	}

	listResult.add(level_13);
	listResult.add(level_14);
	listResult.add(bld_name + "&&" + bld_id + "&&" + bld_group + "&&" + xcoord + "&&" + ycoord);
	return listResult;
  }

  public static String[] getSplitWordResult(String adr) {
	  String[] levelWord = new String[21];
	  levelWord[0] = "success";
	  for (int i = 1; i < 20; ++i) {
		  levelWord[i] = "";
	  }
	  if (adr.equals("") == true) {
		  return levelWord;
	  }
	  adr = adr.replace("\n", "").replace(" ", "").replace("#", "").replace("&", "")
			  .replace(",", "").replace("|", "");
	  String sParams = String.format("address=%s&ak=6eeefc8dcc7c42869bd4f84a746f428d&opt=ma1", adr);

	  String sFormatUrl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?%s";
	  String url = String.format(sFormatUrl, sParams);

	  for (int index = 0; index < 5; ++index) {
		  String sResult = "";
		  try {
//			  sResult = HttpRequest.doGet(url, "utf-8");
//			  JSONObject jsonObject = JSON.parseObject(sResult);
			  JSONObject jsonObject=HttpUtils.urlConnectionGetJson(url,5000);
			  String sStatus = jsonObject.getString("status");
			  if (sStatus.equals("0") == true) {
				  JSONObject result = jsonObject.getJSONObject("result");
				  JSONArray adrList = result.getJSONArray("addSplitInfo");
				  for (int i = 0; i < adrList.size(); ++i) {
					  JSONObject adrItem = (JSONObject) adrList.get(i);
					  String level = adrItem.getString("level");
					  String text = adrItem.getString("text");
                      int int_level = Integer.parseInt(level);
                      if (int_level > 17)
                          continue;

                      if (levelWord[int_level + 1].equals(""))
                          levelWord[int_level + 1] = text;
                      else
                          levelWord[int_level + 1] = levelWord[int_level + 1] + "|" + text;
				  }
				  JSONObject assemble = result.getJSONObject("other");
				  if (assemble.containsKey("aoi")) {
                      levelWord[19] = assemble.getString("aoi");
				  }
				  if (assemble.containsKey("group")) {
                      levelWord[20] = assemble.getString("group");
				  }
				  break;
			  } else {
				  JSONObject errObj = jsonObject.getJSONObject("result");
				  String errMsg = errObj.getString("msg");
				  levelWord[0] = errMsg;
				  return levelWord;
			  }
		  } catch (Exception e) {
			  try {
				  Thread.sleep(1000);
			  } catch (InterruptedException tmp) {
			  }

			  if (index == 4){
				  String errMsg = sResult + " ==" + e.toString();
                  levelWord[0] = errMsg;
                  return levelWord;
			  }
		  }
	  }
	  return levelWord;
  }

  public static void main(String args[]) {
      System.out.println("Hello World!");
      //BuildingGeo.getXY("");
      System.out.print(BuildingGeo.getAssembleInfo("桥碧螺山庄5区").toString());
  }
}
