package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.LbsLctCtrlController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * lbs定位管控重构（需求：刘雨婷）
 * @author 01370539
 * 2022年7月20日
 */
public class LbsLctCtrlApp {
    private static final Logger logger = LoggerFactory.getLogger(LbsLctCtrlApp.class);
    public static void main(String[] args) {
        if (args.length >=2) {
            String incDay = args[0];
            String isFromRs = args[1];
            new LbsLctCtrlController().process(incDay, isFromRs);
        } else {
            logger.error("参数传递有误： {}", args);
        }
    }
}
