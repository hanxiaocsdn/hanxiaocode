package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiElevator;
import com.sf.gis.java.sds.pojo.CmsAoiSch;
import com.sf.gis.java.sds.pojo.GroupElevator;
import com.sf.gis.java.sds.pojo.TtWayBillHook;
import com.sf.gis.java.sds.service.DispatchGoUpstairsService1;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class DispatchGoUpstairsController1 implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(DispatchGoUpstairsController1.class);
    DispatchGoUpstairsService1 service = new DispatchGoUpstairsService1();
    public static String atdispatchUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=12797991c7e64fadb1272910d9d01aef&opt=zh";

    public void start(String startDate, String endDate, String cityCodes) throws Exception {
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        String hdfsClientDir = "/user/01403862/upload/group3_black.csv";
        JavaRDD<String> aoiBlackRdd = sc.textFile(hdfsClientDir).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiBlackRdd cnt:{}", aoiBlackRdd.count());

        //获取cms,关联aoi_type
        JavaRDD<CmsAoiSch> cmsRdd = service.loadCmsData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());
        cmsRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        String[] split = cityCodes.split(",");
        for (String citycode : split) {
            logger.error("citycode:{}", citycode);

//            List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
//            for (String date : dates) {
//            }
            List<String[]> dateSliceByMonth = DateUtil.dateSliceByMonth(startDate, endDate, "yyyyMMdd", "yyyyMM");
            for (String[] slices : dateSliceByMonth) {
                String start = slices[1];
                String end = slices[2];
                logger.error("start:{}, end:{}", start, end);

                logger.error("start:{}", start);
                String beforeDate = DateUtil.getDaysBefore(start, 1);
                logger.error("beforeDate:{}", beforeDate);

                JavaRDD<TtWayBillHook> ttWayRdd = service.loadTtWayData(spark, sc, start, end, citycode).map(o -> {
                    o.setProcess_address(o.getConsignee_addr());
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttWayRdd cnt:{}", ttWayRdd.count());
                ttWayRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

                //跑服务得到group_id,aoi_id,floor,std_addr
                JavaRDD<TtWayBillHook> ttWayStdAddrRdd = ttWayRdd.mapToPair(o -> new Tuple2<>(o.getConsignee_addr(), o))
                        .groupByKey()
                        .flatMap(tp -> {
                            ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
                            TtWayBillHook o = list.get(0);
                            String addr = o.getConsignee_addr();
                            String content = "";
                            String groupid = "";
                            String aoiid = "";
                            String floor = "";
                            String standardization = "";
                            if (StringUtils.isNotEmpty(addr)) {
//                    addr = addr.replaceAll(regexBc.value(), "");
                                Set<Integer> acLimitCodeSet = acLimitCodeSetBc.value();
                                content = service.runAtdispatch(atdispatchUrl, addr, o.getDest_dist_code(), acLimitCodeSet);
                                if (StringUtils.isNotEmpty(content)) {
                                    JSONObject jsonObject = JSON.parseObject(content);
                                    int status = jsonObject.getInteger("status");
                                    if (status == 0) {
                                        JSONObject result = jsonObject.getJSONObject("result");
                                        JSONArray tcs = result.getJSONArray("tcs");
                                        groupid = tcs.getJSONObject(0).getString("groupid");
                                        aoiid = tcs.getJSONObject(0).getString("aoiid");
                                        logger.error("groupid:{}", groupid);
                                        logger.error("aoiid:{}", aoiid);
                                        o.setGroupId(groupid);
                                        o.setAoiId(aoiid);
                                        JSONObject other = result.getJSONObject("other");
                                        if (other != null) {
                                            JSONObject normresp = other.getJSONObject("normresp");
                                            if (normresp != null) {
                                                Boolean success = normresp.getBoolean("success");
                                                if (success) {
                                                    JSONObject result1 = normresp.getJSONObject("result");
                                                    if (result1 != null) {
                                                        Integer status1 = result1.getInteger("status");
                                                        if (status1 == 0) {
                                                            JSONArray geocoder = result1.getJSONArray("geocoder");
                                                            if (geocoder.size() > 0) {
                                                                floor = geocoder.getJSONObject(0).getString("floor");
                                                                standardization = geocoder.getJSONObject(0).getString("standardization");
                                                                logger.error("floor:{}", floor);
                                                                logger.error("standardization:{}", standardization);
                                                                o.setFloor(floor);
                                                                o.setStdAddr(standardization);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            String finalGroupid = groupid;
                            String finalAoiid = aoiid;
                            String finalFloor = floor;
                            String finalStandardization = standardization;
                            return list.stream().map(tt -> {
                                tt.setGroupId(finalGroupid);
                                tt.setAoiId(finalAoiid);
                                tt.setFloor(finalFloor);
                                tt.setStdAddr(finalStandardization);

                                return tt;
                            }).collect(Collectors.toList()).iterator();
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("ttWayStdAddrRdd cnt:{}", ttWayStdAddrRdd.count());
                ttWayStdAddrRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
                ttWayRdd.unpersist();

//            JavaRDD<TtWayBillHook> floorRdd = ttWayStdAddrRdd.filter(o -> StringUtils.isNotEmpty(o.getFloor()) && ((Integer.valueOf(o.getFloor()) >= 10 && Integer.valueOf(o.getFloor()) <= 100) || (Integer.valueOf(o.getFloor()) < 0 && Integer.valueOf(o.getFloor()) >= -4)))
//                    .map(o -> {
//                        String tag1 = "";
//                        String tag2 = "";
//                        String tag3 = "";
//                        String consignee_addr = o.getConsignee_addr();
//                        if (StringUtils.isNotEmpty(consignee_addr)) {
//                            if (consignee_addr.contains("号楼") || consignee_addr.contains("栋") || consignee_addr.contains("幢") || consignee_addr.contains("座")) {
//                                tag1 = "楼栋后缀";
//                            }
//                            String regex1 = "\\d[(.*?)#@\\[\\],，-]+\\d";
//                            Pattern p1 = Pattern.compile(regex1);
//                            Matcher m1 = p1.matcher(consignee_addr);
//                            StringBuilder sb = new StringBuilder();
//                            while (m1.find()) {
//                                sb.append(m1.group());
//                            }
//                            String result = sb.toString().replaceAll("\\d+", "");
//                            tag2 = "符号" + result;
//
//                            String regex2 = ".*[a-zA-Z]\\d{4,}";
//                            Pattern p2 = Pattern.compile(regex2);
//                            Matcher m2 = p2.matcher(consignee_addr);
//                            if (m2.find()) {
//                                tag3 = "字母";
//                            }
//                        }
//                        o.setTag1(tag1);
//                        o.setTag2(tag2);
//                        o.setTag3(tag3);
//                        return o;
//                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("floorRdd cnt:{}", floorRdd.count());
//            floorRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
//            ttWayStdAddrRdd.unpersist();

//            JavaRDD<TtWayBillHook> groupRdd = ttWayStdAddrRdd.filter(o -> StringUtils.isNotEmpty(o.getGroupId())).map(o -> {
//                o.setIs_groupid_elevator("1");
//                o.setGroup_source("3");
//                return o;
//            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            JavaRDD<TtWayBillHook> noGroupRdd = ttWayStdAddrRdd.filter(o -> StringUtils.isEmpty(o.getGroupId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("groupRdd cnt:{}", groupRdd.count());
//            logger.error("noGroupRdd cnt:{}", noGroupRdd.count());
//            ttWayStdAddrRdd.unpersist();

//            String executeSql1 = String.format("alter table dm_gis.tt_group_elevator_process drop if EXISTS partition(inc_day='%s')", date);
//            logger.error("executeSql1 :{}", executeSql1);
//            spark.sql(executeSql1);
//            service.saveGroupData(spark, groupRdd, date);

                JavaRDD<TtWayBillHook> aoiGroupRdd = ttWayStdAddrRdd.filter(o -> StringUtils.isNotEmpty(o.getAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtWayBillHook> empAoiGroupRdd = ttWayStdAddrRdd.filter(o -> StringUtils.isEmpty(o.getAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiGroupRdd cnt:{}, empAoiGroupRdd cnt:{}", aoiGroupRdd.count(), empAoiGroupRdd.count());
                ttWayStdAddrRdd.unpersist();

                JavaRDD<TtWayBillHook> aoiTypeGroupRdd = aoiGroupRdd.mapToPair(o -> new Tuple2<>(o.getAoiId(), o))
                        .leftOuterJoin(cmsRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtWayBillHook ttWayBillHook = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                ttWayBillHook.setAoiType(cmsAoiSch.getFa_type());
                            }
                            return ttWayBillHook;
                        }).union(empAoiGroupRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiTypeGroupRdd cnt:{}", aoiTypeGroupRdd.count());
                aoiGroupRdd.unpersist();
                empAoiGroupRdd.unpersist();

                JavaRDD<TtWayBillHook> processAddrRdd = aoiTypeGroupRdd.map(o -> {
                    String process_address = o.getProcess_address();
                    String aoiType = o.getAoiType();
                    if (StringUtils.isNotEmpty(process_address)) {
//                    process_address = StringNumUtils.outputArabNumberString(process_address);
                        if (service.aoiTypejudge1(aoiType)) {
                            process_address = "";
                        }
                        if (StringUtils.isNotEmpty(process_address) && service.judgeAddr1(process_address)) {
                            process_address = "";
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            String[] addrAndTag = service.processAddr1(process_address, "");
                            process_address = addrAndTag[0];
                            o.setTag1(addrAndTag[1]);
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            String[] addrAndTag = service.processAddr2(process_address, "");
                            process_address = addrAndTag[0];
                            o.setTag2(addrAndTag[1]);
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            String[] addrAndTag = service.processAddr3(process_address, "");
                            process_address = addrAndTag[0];
                            o.setTag3(addrAndTag[1]);
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            String[] addrAndTag = service.processAddr4(process_address, "", aoiType);
                            process_address = addrAndTag[0];
                            o.setTag4(addrAndTag[1]);
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            String[] addrAndTag = service.processAddr5(process_address, "");
                            process_address = addrAndTag[0];
                            o.setTag5(addrAndTag[1]);
                        }
                        if (StringUtils.isNotEmpty(process_address)) {
                            if (service.processAddr6(process_address)) {
                                o.setTag6("结尾");
                            }
                        }
                    }
                    o.setProcess_address(process_address);
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("processAddrRdd cnt:{}", processAddrRdd.count());
                aoiTypeGroupRdd.unpersist();

                JavaRDD<TtWayBillHook> splitResutRdd = processAddrRdd.mapToPair(o -> new Tuple2<>(o.getProcess_address(), o))
                        .groupByKey()
                        .flatMap(tp -> {
                            ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
                            TtWayBillHook o = list.get(0);
                            String process_address = o.getProcess_address();
                            String dest_dist_code = o.getDest_dist_code();
                            String content = "";
                            String splitResult = "";
                            String groupid = "";
                            String aoiid = "";
                            String floor = "";
                            String standardization = "";
                            if (StringUtils.isNotEmpty(process_address)) {
//                    addr = addr.replaceAll(regexBc.value(), "");
                                Set<Integer> acLimitCodeSet = acLimitCodeSetBc.value();
                                content = service.runAtdispatch(atdispatchUrl, process_address, dest_dist_code, acLimitCodeSet);
                                if (StringUtils.isNotEmpty(content)) {
                                    JSONObject jsonObject = JSON.parseObject(content);
                                    int status = jsonObject.getInteger("status");
                                    if (status == 0) {
                                        JSONObject result = jsonObject.getJSONObject("result");
                                        JSONArray tcs = result.getJSONArray("tcs");
                                        groupid = tcs.getJSONObject(0).getString("groupid");
                                        aoiid = tcs.getJSONObject(0).getString("aoiid");
                                        logger.error("groupid:{}", groupid);
                                        logger.error("aoiid:{}", aoiid);
                                        o.setGroup_id_2(groupid);
                                        o.setAoi_id_2(aoiid);
                                        JSONObject other = result.getJSONObject("other");
                                        if (other != null) {
                                            JSONObject normresp = other.getJSONObject("normresp");
                                            if (normresp != null) {
                                                Boolean success = normresp.getBoolean("success");
                                                if (success) {
                                                    JSONObject result1 = normresp.getJSONObject("result");
                                                    if (result1 != null) {
                                                        Integer status1 = result1.getInteger("status");
                                                        if (status1 == 0) {
                                                            JSONArray geocoder = result1.getJSONArray("geocoder");
                                                            if (geocoder.size() > 0) {
                                                                floor = geocoder.getJSONObject(0).getString("floor");
                                                                standardization = geocoder.getJSONObject(0).getString("standardization");
                                                                logger.error("floor:{}", floor);
                                                                logger.error("standardization:{}", standardization);
                                                                o.setFloor_2(floor);
                                                                o.setNorm_address_2(standardization);
                                                            }
                                                            splitResult = result1.getString("splitResult");
                                                            logger.error("splitResult:{}", splitResult);
                                                            o.setSplitResult(splitResult);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            String finalGroupid = groupid;
                            String finalAoiid = aoiid;
                            String finalFloor = floor;
                            String finalStandardization = standardization;
                            String finalSplitResult = splitResult;
                            return list.stream().map(tt -> {
                                tt.setGroup_id_2(finalGroupid);
                                tt.setAoi_id_2(finalAoiid);
                                tt.setFloor_2(finalFloor);
                                tt.setNorm_address_2(finalStandardization);
                                tt.setSplitResult(finalSplitResult);
                                return tt;
                            }).collect(Collectors.toList()).iterator();

                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("splitResutRdd cnt:{}", splitResutRdd.count());
                processAddrRdd.unpersist();

                JavaRDD<TtWayBillHook> lastRdd = splitResutRdd.map(o -> {
                    try {
                        String[] last = service.getLast(o.getSplitResult());
                        String last14 = last[0];
                        String last15 = last[1];
                        o.setLast14(last14);
                        o.setLast15(last15);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return o;
                }).map(o -> {
                    String aoiType = o.getAoiType();
                    String process_address = o.getProcess_address();
                    if (StringUtils.isNotEmpty(process_address)) {
                        if ((StringUtils.equals(aoiType, "120302") || StringUtils.equals(aoiType, "120301") || StringUtils.equals(aoiType, "120305")) && StringUtils.isEmpty(o.getLast14()) && StringUtils.isEmpty(o.getLast15())) {
                            o.setProcess_address("");
                            o.setGroup_id_2("");
                            o.setAoi_id_2("");
                            o.setFloor_2("");
                            o.setNorm_address_2("");
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("lastRdd cnt:{}", lastRdd.count());
                splitResutRdd.unpersist();

                JavaRDD<TtWayBillHook> processFloor2Rdd = lastRdd.map(o -> {
                    String process_address = o.getProcess_address();
                    String aoiType = o.getAoiType();
                    if (service.processAddr7(process_address, aoiType)) {
                        o.setFloor_2("1");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("processFloor2Rdd cnt:{}", processFloor2Rdd.count());
                lastRdd.unpersist();

//            JavaRDD<TtWayBillHook> group_freqRdd = processFloor2Rdd.mapToPair(o -> new Tuple2<>(o.getGroup_id_2(), o))
//                    .groupByKey()
//                    .flatMap(tp -> {
//                        ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
//                        int freq = list.size();
//                        List<TtWayBillHook> resultList = list.stream().map(o -> {
//                            o.setGroup2_freq(freq + "");
//                            return o;
//                        }).collect(Collectors.toList());
//                        return resultList.iterator();
//                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("group_freqRdd cnt:{}", group_freqRdd.count());
//            processFloor2Rdd.unpersist();

                JavaRDD<TtWayBillHook> normSplitRdd = processFloor2Rdd.mapToPair(o -> new Tuple2<>(o.getNorm_address_2(), o))
                        .groupByKey()
                        .flatMap(tp -> {
                            ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
                            TtWayBillHook o = list.get(0);
                            String norm_address_2 = o.getNorm_address_2();
                            String dest_dist_code = o.getDest_dist_code();
                            String content = "";
                            String splitResult = "";
                            if (StringUtils.isNotEmpty(norm_address_2)) {
//                    addr = addr.replaceAll(regexBc.value(), "");
                                Set<Integer> acLimitCodeSet = acLimitCodeSetBc.value();
                                content = service.runAtdispatch(atdispatchUrl, norm_address_2, dest_dist_code, acLimitCodeSet);
                                if (StringUtils.isNotEmpty(content)) {
                                    JSONObject jsonObject = JSON.parseObject(content);
                                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                        JSONObject result = jsonObject.getJSONObject("result");
                                        JSONObject other = result.getJSONObject("other");
                                        if (other != null) {
                                            JSONObject normresp = other.getJSONObject("normresp");
                                            if (normresp != null) {
                                                Boolean success = normresp.getBoolean("success");
                                                if (success) {
                                                    JSONObject result1 = normresp.getJSONObject("result");
                                                    if (result1 != null) {
                                                        Integer status1 = result1.getInteger("status");
                                                        if (status1 == 0) {
                                                            splitResult = result1.getString("splitResult");
                                                            logger.error("splitResult:{}", splitResult);
                                                            o.setNorm_addr_split(splitResult);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            String finalSplitResult = splitResult;
                            return list.stream().map(tt -> {
                                tt.setNorm_addr_split(finalSplitResult);
                                return tt;
                            }).collect(Collectors.toList()).iterator();
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("normSplitRdd cnt:{}", normSplitRdd.count());
                processFloor2Rdd.unpersist();

                JavaRDD<TtWayBillHook> maxSplitRdd = normSplitRdd.map(o -> {
                    String norm_addr_split = o.getNorm_addr_split();
                    if (StringUtils.isNotEmpty(norm_addr_split)) {
                        String maxSplit = service.getMaxSplit(norm_addr_split);
                        o.setMaxSplit(maxSplit);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("maxSplitRdd cnt:{}", maxSplitRdd.count());
                normSplitRdd.unpersist();

//            spark.sql(String.format("alter table dm_gis.tt_group_elevator_process_n_final drop if EXISTS partition(inc_day='%s', city='%s')", date, citycode));
                service.saveGroupDataN(spark, maxSplitRdd, "dm_gis.tt_group_elevator_process_n_final");

                JavaRDD<TtWayBillHook> floor_2Rdd = maxSplitRdd.filter(o -> StringUtils.isNotEmpty(o.getFloor_2()) && ((Integer.parseInt(o.getFloor_2()) >= 10 && Integer.parseInt(o.getFloor_2()) <= 100) || (Integer.parseInt(o.getFloor_2()) < 0 && Integer.parseInt(o.getFloor_2()) >= -4))).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("floor_2Rdd cnt:{}", floor_2Rdd.count());
                maxSplitRdd.unpersist();

                JavaRDD<TtWayBillHook> groupId2Rdd = floor_2Rdd.filter(o -> StringUtils.isNotEmpty(o.getGroup_id_2())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                JavaRDD<TtWayBillHook> empGroupId2Rdd = floor_2Rdd.filter(o -> StringUtils.isEmpty(o.getGroup_id_2())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("groupId2Rdd cnt:{}, empGroupId2Rdd cnt:{}", groupId2Rdd.count(), empGroupId2Rdd.count());
                floor_2Rdd.unpersist();

                JavaRDD<TtWayBillHook> notInBlackGroupRdd = groupId2Rdd.mapToPair(o -> new Tuple2<>(o.getAoi_id_2(), o))
                        .leftOuterJoin(aoiBlackRdd.mapToPair(o -> new Tuple2<>(o, o)))
                        .filter(tp -> {
                            boolean flag = true;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                flag = false;
                            }
                            return flag;
                        })
                        .map(tp -> tp._2._1)
                        .persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("notInBlackGroupRdd cnt:{}", notInBlackGroupRdd.count());
                groupId2Rdd.unpersist();

                JavaRDD<GroupElevator> statFinalGroupRdd = notInBlackGroupRdd.mapToPair(o -> new Tuple2<>(o.getGroup_id_2(), o))
                        .groupByKey()
                        .map(tp -> {
                            ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
                            int size = list.size();
                            TtWayBillHook o = list.get(0);
                            o.setElevator_cnt(size + "");
                            return o;
                        }).map(tt -> {
                            GroupElevator o = new GroupElevator();
                            o.setGroup_id(tt.getGroup_id_2());
                            o.setCityCode(tt.getDest_dist_code());
                            o.setSource("3");
                            o.setNorm_address(tt.getNorm_address_2());
                            o.setAoi_id(tt.getAoi_id_2());
                            o.setElevator_cnt(tt.getElevator_cnt());
                            return o;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("statFinalGroupRdd cnt:{}", statFinalGroupRdd.count());
                statFinalGroupRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
                notInBlackGroupRdd.unpersist();

                logger.error("合并历史group数据");
                JavaRDD<GroupElevator> beforeGroupStatRdd = service.loadGroupStatData(spark, sc, beforeDate, citycode).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("beforeGroupStatRdd cnt:{}", beforeGroupStatRdd.count());

                JavaRDD<GroupElevator> resultGroupRdd = beforeGroupStatRdd.union(statFinalGroupRdd).mapToPair(o -> new Tuple2<>(o.getGroup_id(), o))
                        .groupByKey()
                        .map(tp -> {
                            ArrayList<GroupElevator> list = Lists.newArrayList(tp._2);
                            GroupElevator groupElevator = list.get(0);
                            int elevatorCnt = list.stream().map(o -> StringUtils.isNotEmpty(o.getElevator_cnt()) ? Integer.parseInt(o.getElevator_cnt()) : 0).reduce((o1, o2) -> o1 + o2).get();
                            groupElevator.setElevator_cnt(elevatorCnt + "");
                            return groupElevator;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("resultGroupRdd cnt:{}", resultGroupRdd.count());
                beforeGroupStatRdd.unpersist();
                statFinalGroupRdd.unpersist();

                spark.sql(String.format("alter table dm_gis.tt_group_elevator_stat_final drop if EXISTS partition(inc_day='%s', city='%s')", end, citycode));
                service.saveGroupStatData(spark, resultGroupRdd, end, citycode);
                resultGroupRdd.unpersist();

                JavaRDD<TtWayBillHook> aoiTypeRdd = empGroupId2Rdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_id_2()))
                        .mapToPair(o -> new Tuple2<>(o.getAoi_id_2(), o))
                        .leftOuterJoin(cmsRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1))
                        .map(tp -> {
                            TtWayBillHook ttWayBillHook = tp._2._1;
                            if (tp._2._2 != null && tp._2._2.isPresent()) {
                                CmsAoiSch cmsAoiSch = tp._2._2.get();
                                ttWayBillHook.setAoi_2Type(cmsAoiSch.getFa_type());
                            }
                            return ttWayBillHook;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiTypeRdd cnt:{}", aoiTypeRdd.count());
                aoiTypeRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
                empGroupId2Rdd.unpersist();

                JavaRDD<TtWayBillHook> aoiRdd = aoiTypeRdd.filter(o -> service.judge_aoi_type(o.getAoi_2Type())).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("aoiRdd cnt:{}", aoiRdd.count());
                aoiTypeRdd.unpersist();

//            spark.sql(String.format("alter table dm_gis.tt_aoi_elevator_process_n_final drop if EXISTS partition(inc_day='%s', city='%s')", date, citycode));
                service.saveAoiDataN(spark, aoiRdd, "dm_gis.tt_aoi_elevator_process_n_final");

                JavaRDD<AoiElevator> statFinalAoiRdd = aoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id_2(), o))
                        .groupByKey()
                        .map(tp -> {
                            ArrayList<TtWayBillHook> list = Lists.newArrayList(tp._2);
                            TtWayBillHook o = list.get(0);
                            int size = list.size();
                            o.setElevator_cnt(size + "");
                            return o;
                        }).map(tt -> {
                            AoiElevator o = new AoiElevator();
                            o.setAoi_id(tt.getAoi_id_2());
                            o.setCityCode(tt.getDest_dist_code());
                            o.setSource("2");
                            o.setAoi_type(tt.getAoi_2Type());
                            o.setElevator_cnt(tt.getElevator_cnt());
                            return o;
                        })
                        .persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("statFinalAoiRdd cnt:{}", statFinalAoiRdd.count());
                statFinalAoiRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
                aoiRdd.unpersist();

                logger.error("合并历史aoi数据");
                JavaRDD<AoiElevator> beforeAoiRdd = service.loadAoiStatData(spark, sc, beforeDate, citycode).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("beforeAoiRdd cnt:{}", beforeAoiRdd.count());

                JavaRDD<AoiElevator> resultAoiRdd = beforeAoiRdd.union(statFinalAoiRdd).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))
                        .groupByKey()
                        .map(tp -> {
                            ArrayList<AoiElevator> list = Lists.newArrayList(tp._2);
                            AoiElevator aoiElevator = list.get(0);
                            int cnt = list.stream().map(o -> StringUtils.isNotEmpty(o.getElevator_cnt()) ? Integer.parseInt(o.getElevator_cnt()) : 0).reduce((o1, o2) -> o1 + o2).get();
                            aoiElevator.setElevator_cnt(cnt + "");
                            return aoiElevator;
                        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("resultAoiRdd cnt:{}", resultAoiRdd.count());
                beforeAoiRdd.unpersist();
                statFinalAoiRdd.unpersist();

                spark.sql(String.format("alter table dm_gis.tt_aoi_elevator_stat_final drop if EXISTS partition(inc_day='%s',city='%s')", end, citycode));
                service.saveAoiStatData(spark, resultAoiRdd, end, citycode);
                resultAoiRdd.unpersist();
            }
        }

        cmsRdd.unpersist();
        aoiBlackRdd.unpersist();
        spark.stop();
    }
}
