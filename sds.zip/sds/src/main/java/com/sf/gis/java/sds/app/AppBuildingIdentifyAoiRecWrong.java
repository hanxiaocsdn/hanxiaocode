package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.Aoi;
import com.sf.gis.java.sds.pojo.BuildingIdentifyAoiRecWrong;
import com.sf.gis.scala.base.util.DistanceTool;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * 任务id：906400(自动化识别楼栋详细运单AOI识别错误工艺)
 * 需求方：01425213(潘文辉)
 * 研发：01399581（匡仁衡）
 */

public class AppBuildingIdentifyAoiRecWrong {
    private static Logger logger = LoggerFactory.getLogger(AppBuildingIdentifyAoiRecWrong.class);
    private static String getAoiByXy = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/radius?x=%s&y=%s&radius=100&ak=87106f6380af4df0845a693eee58843c";
    private static String gdurl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s";
    private static String geourl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=%s&ak=87106f6380af4df0845a693eee58843c";
    private static String search = "https://fmap.sf-express.com/ds/bs/search?ak=700b37a477254300ad76dd945f5a0ede&query=%s&region=%s&page_size=10&infos=1";
    private static String atpoi = "http://gis-gw.int.sfdc.com.cn:9080/atpoi/api";

    private static String account = "01399581";
    private static String taskId = "906400";
    private static String taskName = "自动化识别楼栋详细运单AOI识别错误工艺";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppBuildingIdentifyAoiRecWrong");
        SparkSession spark = sparkInfo.getSession();
        JavaSparkContext sc = sparkInfo.getContext();

        Map<String, String> city_adcode_map = getMap(spark);
        logger.error("city_adcode_map size:{}", city_adcode_map.size());
        Broadcast<Map<String, String>> city_adcode_mapBc = sc.broadcast(city_adcode_map);

        String before3Date = DateUtil.getDaysBefore(date, 3);
        String before6Date = DateUtil.getDaysBefore(date, 6);

        logger.error("获取数据");
        String sql = String.format("select\n" +
                "  a.*,\n" +
                "  b.delivery_lgt x_80,\n" +
                "  b.delivery_lat y_80\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      waybillno,address,final_split split,aoi_id,citycode,zno_code,aoi_code,inc_day\n" +
                "    from\n" +
                "      dm_gis.bld_recognition_rate_delivery_detail\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and is_complete = '1'\n" +
                "      and (\n" +
                "        buildingid is null\n" +
                "        or buildingid = ''\n" +
                "      )\n" +
                "      and lvl14_info = '1'\n" +
                "      and (\n" +
                "        nametag is null\n" +
                "        or nametag = ''\n" +
                "      )\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      *\n" +
                "    from(\n" +
                "        select\n" +
                "          waybill_no,\n" +
                "          delivery_lgt,\n" +
                "          delivery_lat,\n" +
                "          delivery_xy_aoiid,\n" +
                "          row_number() over(\n" +
                "            partition by waybill_no\n" +
                "            order by\n" +
                "              modified_tm desc\n" +
                "          ) as rk\n" +
                "        from\n" +
                "          dm_gis.dwd_waybill_info_dtl_di\n" +
                "        where\n" +
                "          inc_day between '%s'\n" +
                "          and '%s'\n" +
                "          and (waybill_no is not null and waybill_no <>'')\n" +
                "          and (delivery_lgt is not null and delivery_lgt <>'')\n" +
                "          and (delivery_lat is not null and delivery_lat <>'')\n" +
                "      ) x\n" +
                "    where\n" +
                "      x.rk = 1\n" +
                "  ) b on a.waybillno = b.waybill_no", before3Date, before6Date, date);
        logger.error("sql:{}", sql);
        JavaRDD<BuildingIdentifyAoiRecWrong> rdd = DataUtil.loadData(spark, sc, sql, BuildingIdentifyAoiRecWrong.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        logger.error("生成对应eng,num,ch");
        JavaRDD<BuildingIdentifyAoiRecWrong> eng_num_ch_rdd = getTagAndName(rdd);

        logger.error("根据aoi_id,tag,num,eng,ch分组统计");
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getAoiByXy, "3eb300d2e06947f7945cd02530a32fd2", eng_num_ch_rdd.count(), 2);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gdurl, "860aafa74c7846a3b4519f552851a5aa", eng_num_ch_rdd.count(), 2);
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", geourl, "87106f6380af4df0845a693eee58843c", eng_num_ch_rdd.count(), 2);
        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", search, "700b37a477254300ad76dd945f5a0ede", eng_num_ch_rdd.count(), 2);
        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atpoi, "668ad914f8f2466eb3efa0ac5c862264", eng_num_ch_rdd.count(), 2);
        JavaRDD<BuildingIdentifyAoiRecWrong> resultRdd = groupStat(eng_num_ch_rdd, city_adcode_mapBc);
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        BdpTaskRecordUtil.endNetworkInterface(account, id3);
        BdpTaskRecordUtil.endNetworkInterface(account, id4);
        BdpTaskRecordUtil.endNetworkInterface(account, id5);

        logger.error("结果存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.bld_recognition_rate_delivery_detail_group", BuildingIdentifyAoiRecWrong.class, resultRdd, "inc_day");
        sc.stop();

    }

    public static JavaRDD<BuildingIdentifyAoiRecWrong> groupStat(JavaRDD<BuildingIdentifyAoiRecWrong> eng_num_ch_rdd, Broadcast<Map<String, String>> city_adcode_mapBc) {
        JavaRDD<BuildingIdentifyAoiRecWrong> resultRdd = eng_num_ch_rdd
                .mapToPair(o -> new Tuple2<>(o.getAoi_id() + "_" + o.getTag() + "_" + o.getNum() + "_" + o.getEng() + "_" + o.getCh(), o))
                .groupByKey(2)
                .flatMap(tp -> {
                    List<BuildingIdentifyAoiRecWrong> list = Lists.newArrayList(tp._2);

                    BuildingIdentifyAoiRecWrong o = list.get(0);
                    String aoi_id = o.getAoi_id();
                    String zno_code = o.getZno_code();
                    String citycode = o.getCitycode();

                    String split = o.getSplit();
                    String address = o.getAddress();

                    List<BuildingIdentifyAoiRecWrong> aoi_list = list.stream().peek(t -> {
                        Aoi aoi = getAoiByXy(t.getX_80(), t.getY_80());
                        t.setAoi(aoi);
                    }).collect(Collectors.toList());

                    aoi_list.forEach(t -> {
                        t.setGroup_address(address);
                        t.setGroup_address_split(split);
                    });

                    //aoi_80的众数
                    List<String> aoi_80s = new ArrayList<>();
                    List<Aoi> xy_80s = new ArrayList<>();
                    List<Aoi> collect = aoi_list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi().getAoiId())).map(BuildingIdentifyAoiRecWrong::getAoi).collect(Collectors.toList());
                    if (collect.size() > 0) {
                        aoi_80s = getMaxAoi(collect);
                        List<String> finalAoi_80s = aoi_80s;
                        xy_80s = collect.stream().filter(t -> finalAoi_80s.contains(t.getAoiId())).collect(Collectors.toList());
                    }

                    List<String> pass_aoi1 = new ArrayList<>();
                    //1.调高德
                    String gd_result = gd(address);
                    List<Aoi> gdList = getGdList(gd_result);
                    List<String> gd_aoi_check = check(gdList, aoi_id, zno_code, xy_80s, aoi_80s);
                    pass_aoi1.addAll(gd_aoi_check);

                    //2.调大搜接口
                    String adcode = city_adcode_mapBc.value().get(citycode);
                    String search_result = getSearch(address, adcode);
                    List<Aoi> searchList = getSearchList(search_result);
                    List<String> search_aoi_check = check(searchList, aoi_id, zno_code, xy_80s, aoi_80s);
                    pass_aoi1.addAll(search_aoi_check);

                    aoi_list.forEach(t -> {
                        t.setGdps_response(gd_result);
                        t.setBs_response(search_result);
                    });

                    //3.调用图商接口
                    List<Aoi> tsList = getTsList(address, citycode, aoi_list);
                    List<String> ts_aoi_check = check(tsList, aoi_id, zno_code, xy_80s, aoi_80s);
                    pass_aoi1.addAll(ts_aoi_check);

                    //4.对pass_aoi1 进行去重，对其中的AOIID进行楼栋识别服务校验
                    if (pass_aoi1.size() > 0) {
                        pass_aoi1 = pass_aoi1.stream().distinct().collect(Collectors.toList());
                        CheckPassAoi(pass_aoi1, address, citycode, aoi_list);
                    }
                    return aoi_list.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        eng_num_ch_rdd.unpersist();
        return resultRdd;
    }

    public static void CheckPassAoi(List<String> pass_aoi1, String addr, String citycode, List<BuildingIdentifyAoiRecWrong> aoi_list) {
        aoi_list.forEach(t -> {
            t.setPass_aoi1(String.join("$", pass_aoi1));
        });

        List<String> pass_aoi2 = new ArrayList<>();
        List<String> pass_bld = new ArrayList<>();
        pass_aoi1.forEach(o -> {
            JSONObject param = new JSONObject();
            param.put("cityCode", citycode);
            param.put("address", addr);
            param.put("aoiId", o);
            param.put("requestId", System.currentTimeMillis());
            String content = HttpInvokeUtil.sendPostHeader(atpoi, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", "668ad914f8f2466eb3efa0ac5c862264", "utf-8", "utf-8");
            try {
                String buildingId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("buildingId");
                String levelSrc = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("levelSrc");
                if (StringUtils.isNotEmpty(buildingId) && "14levelMatch".equals(levelSrc)) {
                    pass_aoi2.add(o);
                    pass_bld.add(buildingId);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        if (pass_aoi2.size() > 0) {

            aoi_list.forEach(t -> {
                t.setPass_aoi2(String.join("$", pass_aoi2));
            });

            if (pass_aoi2.size() == 1) {
                //只有唯一的一个AOIID通过楼栋识别服务校验,运单组内的所有运单都判错，通过校验的AOIID作为正确的AOIID
                String right_aoi = pass_aoi2.get(0);
                String buildingId = pass_bld.get(0);
                aoi_list.forEach(t -> {
                    t.setCorrect_aoi(right_aoi);
                    t.setCorrect_bld(buildingId);
                });
            }
        }

    }

    public static List<Aoi> getSearchList(String content) {
        List<Aoi> list = new ArrayList<>();
        try {
            JSONArray result = JSON.parseObject(content).getJSONArray("result");
            for (int i = 0; i < result.size(); i++) {
                JSONObject jsonObject = result.getJSONObject(i);
                JSONObject location = jsonObject.getJSONObject("location");
                String x = location.getString("lng");
                String y = location.getString("lat");
                Aoi aoi = getAoiByXy(x, y);
                list.add(aoi);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public static String getSearch(String addr, String adcode) {
        String content = "";
        try {
            String req = String.format(search, URLEncoder.encode(addr, "UTF-8"), adcode);
            content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    public static Map<String, String> getMap(SparkSession spark) {
        Map<String, String> res = new HashMap<>();
        Map<String, String> map = spark.sql("select citycode,adcode from dm_gis.city_name_map group by citycode,adcode").toJavaRDD().mapToPair(row -> {
            String citycode = row.getString(0);
            String adcode = row.getString(1);
            return new Tuple2<>(citycode, adcode);
        }).collectAsMap();
        res.putAll(map);
        return res;
    }

    public static List<String> check(List<Aoi> tsList, String aoi_id, String zno_code, List<Aoi> xy_80s, List<String> aoi_80s) {
        List<String> ts_aoi_check = new ArrayList<>();
        //aoi检验
        List<Aoi> tsAoiFilterList = tsList.stream().filter(t -> StringUtils.isNotEmpty(t.getAoiId()) && !StringUtils.equals(t.getAoiId(), aoi_id)).collect(Collectors.toList());
        //网点检验
        if (tsAoiFilterList.size() > 0) {
            List<Aoi> tsZcFilterList = tsAoiFilterList.stream().filter(t -> StringUtils.isNotEmpty(t.getZno_code()) && StringUtils.equals(t.getZno_code(), zno_code)).collect(Collectors.toList());
            //距离校验
            if (tsZcFilterList.size() > 0) {
                List<Aoi> tsDistanceFilterList = tsZcFilterList.stream().filter(t -> {
                    String x1 = t.getX();
                    String y1 = t.getY();
                    String aoiId = t.getAoiId();

                    if (xy_80s.size() > 0) {
                        for (Aoi finalXy_80 : xy_80s) {
                            String x2 = finalXy_80.getX();
                            String y2 = finalXy_80.getY();
                            double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(x1), Double.parseDouble(y1), Double.parseDouble(x2), Double.parseDouble(y2));
                            if (distance < 50 || (distance < 150 && aoi_80s.size() > 0 && aoi_80s.contains(aoiId))) {
                                return true;
                            }
                        }
                    }
                    return false;
                }).collect(Collectors.toList());

                if (tsDistanceFilterList.size() > 0) {
                    //同时通过aoi校验、网点校验和距离校验
                    ts_aoi_check = tsDistanceFilterList.stream().map(Aoi::getAoiId).collect(Collectors.toList());
                }
            }
        }
        return ts_aoi_check;
    }

    public static List<Aoi> getGdList(String gd_result) {
        List<Aoi> list = new ArrayList<>();
        if (StringUtils.isNotEmpty(gd_result)) {
            try {
                JSONArray pois = JSON.parseObject(gd_result).getJSONObject("result").getJSONArray("pois");
                for (int i = 0; i < pois.size(); i++) {
                    JSONObject jsonObject = pois.getJSONObject(i);
                    String location = jsonObject.getString("location");
                    if (StringUtils.isNotEmpty(location)) {
                        String[] split = location.split(",");
                        if (split.length >= 2) {
                            String x = split[0];
                            String y = split[1];
                            Aoi aoi = getAoiByXy(x, y);
                            list.add(aoi);
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    //跑图商获取aoi
    public static List<Aoi> getTsList(String addr, String citycode, List<BuildingIdentifyAoiRecWrong> aoi_list) {
        List<Aoi> ts_list = new ArrayList<>();
        try {
            //gd2、rh1、bd2
            String gd2_req = String.format(geourl, URLEncoder.encode(addr, "UTF-8"), citycode, "gd2");
            String rh1_req = String.format(geourl, URLEncoder.encode(addr, "UTF-8"), citycode, "rh1");
            String bd2_req = String.format(geourl, URLEncoder.encode(addr, "UTF-8"), citycode, "bd2");
            Aoi gdAoi = getTsAoi(gd2_req);
            Aoi rhAoi = getTsAoi(rh1_req);
            Aoi bdAoi = getTsAoi(bd2_req);

            aoi_list.forEach(t -> {
                t.setGd2_response(gdAoi.getResponse());
                t.setRh1_response(rhAoi.getResponse());
                t.setBd2_response(bdAoi.getResponse());
            });

            ts_list.add(gdAoi);
            ts_list.add(rhAoi);
            ts_list.add(bdAoi);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return ts_list;
    }

    public static Aoi getTsAoi(String req) {
        Aoi aoi = null;
        String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
        String x = "";
        String y = "";
        try {
            x = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
            y = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
        } catch (Exception e) {
            e.printStackTrace();
        }
        aoi = getAoiByXy(x, y);
        aoi.setResponse(content);
        return aoi;
    }

    public static String gd(String addr) {
        String content = "";
        try {
            String req = String.format(gdurl, URLEncoder.encode(addr, "UTF-8"));
            content = HttpInvokeUtil.sendGet(req, "ak", "860aafa74c7846a3b4519f552851a5aa");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    public static List<String> getMaxAoi(List<Aoi> collect) {
        Map<String, Integer> map = new HashMap<>();
        for (Aoi aoi : collect) {
            map.put(aoi.getAoiId(), map.getOrDefault(aoi.getAoiId(), 0) + 1);
        }
        List<Integer> frequency = new ArrayList<>();
        map.forEach((k, v) -> {
            frequency.add(v);
        });
        Collections.sort(frequency);
        int maxFrequency = frequency.get(frequency.size() - 1);
        List<String> result = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            if (entry.getValue() == maxFrequency) {
                result.add(entry.getKey());
            }
        }
        return result;
    }

    //获取每个经纬度100半径内aoi_dist最小的aoi
    public static Aoi getAoiByXy(String x, String y) {
        Aoi aoi = new Aoi();
        if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
            String req = String.format(getAoiByXy, x, y);
            String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            aoi = getMinDistAoi(content);
            aoi.setX(x);
            aoi.setY(y);
        }
        return aoi;
    }

    public static Aoi getMinDistAoi(String content) {
        String aoi_id = "";
        String aoi_code = "";
        double temp_dist = 1000;
        try {
            JSONArray aois = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("aois");
            if (aois != null && aois.size() > 0) {
                for (int i = 0; i < aois.size(); i++) {
                    JSONObject json = aois.getJSONObject(i);
                    double aoi_dist = json.getDouble("aoi_dist");
                    if (aoi_dist < temp_dist) {
                        temp_dist = aoi_dist;
                        aoi_id = json.getString("aoi_id");
                        aoi_code = json.getString("aoi_code");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Aoi aoi = new Aoi();
        aoi.setAoiId(aoi_id);
        aoi.setAoiCode(aoi_code);
        if (StringUtils.isNotEmpty(aoi_code)) {
            aoi.setZno_code(aoi_code.substring(0, aoi_code.length() - 6));
        }
        return aoi;
    }

    public static JavaRDD<BuildingIdentifyAoiRecWrong> getTagAndName(JavaRDD<BuildingIdentifyAoiRecWrong> rdd) {
        JavaRDD<BuildingIdentifyAoiRecWrong> eng_num_ch_rdd = rdd.map(o -> {
            String tag = "";
            ArrayList<String> list = new ArrayList<>();
            String final_split = o.getSplit();
            if (StringUtils.isNotEmpty(final_split)) {
                String[] split = final_split.split("\\|");
                int tag_flag = 0;
                for (String s : split) {
                    String[] multi = s.split("\\^");
                    if (multi.length >= 3) {
                        String name = multi[0];
                        String level = multi[1];
                        String prop = multi[2];
                        if ("14".equals(level)) {
                            list.add(name);
                            if (tag_flag == 0) {
                                tag_flag = 1;
                            }
                        }
                        if (tag_flag == 0 && "13".equals(level) && "6".equals(prop)) {
                            tag = name;
                        }
                    }
                }
            }

            if (list.size() > 0) {
                boolean flag = false;
                for (String s : list) {
                    if (s.endsWith("号楼") || s.endsWith("幢") || s.endsWith("栋") || s.endsWith("座") || s.endsWith("塔")) {
                        flag = true;
                        break;
                    }
                }

                ArrayList<String> eng_list = new ArrayList<>();
                ArrayList<String> num_list = new ArrayList<>();
                ArrayList<String> ch_list = new ArrayList<>();
                if (flag) {
                    for (String s : list) {
                        String arab = StringNumUtils.outputArabNumberString(s.toLowerCase());
                        String eng = getMatch(arab, "[a-zA-Z]+");
                        String num = getMatch(arab, "[0-9]+");
                        String ch = getMatch(arab, "[\u4E00-\u9FFF]+");

                        if (StringUtils.isNotEmpty(eng)) {
                            eng_list.add(eng);
                        }

                        if (StringUtils.isNotEmpty(num)) {
                            num_list.add(num);
                        }

                        if (StringUtils.isNotEmpty(ch)) {
                            ch_list.add(ch);
                        }
                    }
                    o.setTag(tag);
                    o.setName(String.join("$", list));

                    if (eng_list.size() > 0) {
                        List<String> eng_sort = eng_list.stream().distinct().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList());
                        o.setEng(String.join("$", eng_sort));
                    }

                    if (num_list.size() > 0) {
                        List<String> num_sort = num_list.stream().distinct().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList());
                        o.setNum(String.join("$", num_sort));
                    }

                    if (ch_list.size() > 0) {
                        List<String> ch_sort = ch_list.stream().distinct().sorted((o1, o2) -> o1.compareTo(o2)).collect(Collectors.toList());
                        o.setCh(String.join("$", ch_sort));
                    }
                }
            }
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getTag()) && StringUtils.isNotEmpty(o.getName())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eng_num_ch_rdd cnt:{}", eng_num_ch_rdd.count());
        rdd.unpersist();
        return eng_num_ch_rdd;
    }

    public static String getMatch(String str, String regex) {
        StringBuilder sb = new StringBuilder();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            sb.append(matcher.group());
        }
        return sb.toString();
    }

}
