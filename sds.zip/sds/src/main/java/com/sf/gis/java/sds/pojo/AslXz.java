package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AslXz implements Serializable {
    @Column(name = "p_address")
    private String p_address;
    @Column(name = "p_city_code")
    private String p_city_code;
    @Column(name = "p_sys_code")
    private String p_sys_code;
    @Column(name = "p_aoiid")
    private String p_aoiid;
    @Column(name = "p_at_aoi_src")
    private String p_at_aoi_src;
    @Column(name = "p_aoi_code")
    private String p_aoi_code;
    @Column(name = "p_split_result")
    private String p_split_result;
    @Column(name = "p_standardization")
    private String p_standardization;
    @Column(name = "r_vilname")
    private String r_vilname;
    @Column(name = "r_vilcode")
    private String r_vilcode;
    @Column(name = "r_vil_space_code")
    private String r_vil_space_code;
    @Column(name = "r_class_code")
    private String r_class_code;
    @Column(name = "r_aoiid")
    private String r_aoiid;
    @Column(name = "r_distance")
    private String r_distance;
    @Column(name = "r_filter")
    private String r_filter;
    @Column(name = "r_level")
    private String r_level;
    @Column(name = "r_src")
    private String r_src;
    @Column(name = "r_msg")
    private String r_msg;
    @Column(name = "opt")
    private String opt;

    @Column(name = "xz_result")
    private String xz_result;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "town")
    private String town;
    @Column(name = "src")
    private String src;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "vilname")
    private String vilName;
    @Column(name = "vilspacecode")
    private String vilSpaceCode;
    @Column(name = "classcode")
    private String classCode;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "vilcode")
    private String vilcode;
    @Column(name = "townadcode")
    private String townAdcode;
    @Column(name = "geox")
    private String geoX;
    @Column(name = "geoy")
    private String geoY;
    @Column(name = "groupid")
    private String groupId;
    @Column(name = "splitresult")
    private String splitResult;
    @Column(name = "standardization")
    private String standardization;
    @Column(name = "ataoisrc")
    private String atAoiSrc;
    @Column(name = "townx")
    private String townX;
    @Column(name = "towny")
    private String townY;
    @Column(name = "distance")
    private String distance;
    @Column(name = "aoicode")
    private String aoiCode;
    @Column(name = "deptcode")
    private String deptCode;
    @Column(name = "filter")
    private String filter;
    @Column(name = "level")
    private String level;
    @Column(name = "compare")
    private String compare;

    @Column(name = "pro_xz_result")
    private String pro_xz_result;
    @Column(name = "pro_province")
    private String pro_province;
    @Column(name = "pro_city")
    private String pro_city;
    @Column(name = "pro_county")
    private String pro_county;
    @Column(name = "pro_town")
    private String pro_town;
    @Column(name = "pro_src")
    private String pro_src;
    @Column(name = "pro_x")
    private String pro_x;
    @Column(name = "pro_y")
    private String pro_y;
    @Column(name = "pro_vilname")
    private String pro_vilName;
    @Column(name = "pro_vilspacecode")
    private String pro_vilSpaceCode;
    @Column(name = "pro_classcode")
    private String pro_classCode;
    @Column(name = "pro_aoiid")
    private String pro_aoiid;
    @Column(name = "pro_vilcode")
    private String pro_vilcode;
    @Column(name = "pro_townadcode")
    private String pro_townAdcode;
    @Column(name = "pro_geox")
    private String pro_geoX;
    @Column(name = "pro_geoy")
    private String pro_geoY;
    @Column(name = "pro_groupid")
    private String pro_groupId;
    @Column(name = "pro_splitresult")
    private String pro_splitResult;
    @Column(name = "pro_standardization")
    private String pro_standardization;
    @Column(name = "pro_ataoisrc")
    private String pro_atAoiSrc;
    @Column(name = "pro_townx")
    private String pro_townX;
    @Column(name = "pro_towny")
    private String pro_townY;
    @Column(name = "pro_distance")
    private String pro_distance;
    @Column(name = "pro_aoicode")
    private String pro_aoiCode;
    @Column(name = "pro_deptcode")
    private String pro_deptCode;
    @Column(name = "pro_filter")
    private String pro_filter;
    @Column(name = "pro_level")
    private String pro_level;
    @Column(name = "pro_compare")
    private String pro_compare;
    @Column(name = "inc_day")
    private String inc_day;

    public String getR_vilname() {
        return r_vilname;
    }

    public void setR_vilname(String r_vilname) {
        this.r_vilname = r_vilname;
    }

    public String getR_vilcode() {
        return r_vilcode;
    }

    public void setR_vilcode(String r_vilcode) {
        this.r_vilcode = r_vilcode;
    }

    public String getR_class_code() {
        return r_class_code;
    }

    public void setR_class_code(String r_class_code) {
        this.r_class_code = r_class_code;
    }

    public String getR_aoiid() {
        return r_aoiid;
    }

    public void setR_aoiid(String r_aoiid) {
        this.r_aoiid = r_aoiid;
    }

    public String getR_distance() {
        return r_distance;
    }

    public void setR_distance(String r_distance) {
        this.r_distance = r_distance;
    }

    public String getR_filter() {
        return r_filter;
    }

    public void setR_filter(String r_filter) {
        this.r_filter = r_filter;
    }

    public String getR_level() {
        return r_level;
    }

    public void setR_level(String r_level) {
        this.r_level = r_level;
    }

    public String getR_src() {
        return r_src;
    }

    public void setR_src(String r_src) {
        this.r_src = r_src;
    }

    public String getR_msg() {
        return r_msg;
    }

    public void setR_msg(String r_msg) {
        this.r_msg = r_msg;
    }

    public String getCompare() {
        return compare;
    }

    public void setCompare(String compare) {
        this.compare = compare;
    }

    public String getPro_compare() {
        return pro_compare;
    }

    public void setPro_compare(String pro_compare) {
        this.pro_compare = pro_compare;
    }

    public String getPro_xz_result() {
        return pro_xz_result;
    }

    public void setPro_xz_result(String pro_xz_result) {
        this.pro_xz_result = pro_xz_result;
    }

    public String getPro_province() {
        return pro_province;
    }

    public void setPro_province(String pro_province) {
        this.pro_province = pro_province;
    }

    public String getPro_city() {
        return pro_city;
    }

    public void setPro_city(String pro_city) {
        this.pro_city = pro_city;
    }

    public String getPro_county() {
        return pro_county;
    }

    public void setPro_county(String pro_county) {
        this.pro_county = pro_county;
    }

    public String getPro_town() {
        return pro_town;
    }

    public void setPro_town(String pro_town) {
        this.pro_town = pro_town;
    }

    public String getPro_src() {
        return pro_src;
    }

    public void setPro_src(String pro_src) {
        this.pro_src = pro_src;
    }

    public String getPro_x() {
        return pro_x;
    }

    public void setPro_x(String pro_x) {
        this.pro_x = pro_x;
    }

    public String getPro_y() {
        return pro_y;
    }

    public void setPro_y(String pro_y) {
        this.pro_y = pro_y;
    }

    public String getPro_vilName() {
        return pro_vilName;
    }

    public void setPro_vilName(String pro_vilName) {
        this.pro_vilName = pro_vilName;
    }

    public String getPro_vilSpaceCode() {
        return pro_vilSpaceCode;
    }

    public void setPro_vilSpaceCode(String pro_vilSpaceCode) {
        this.pro_vilSpaceCode = pro_vilSpaceCode;
    }

    public String getPro_classCode() {
        return pro_classCode;
    }

    public void setPro_classCode(String pro_classCode) {
        this.pro_classCode = pro_classCode;
    }

    public String getPro_aoiid() {
        return pro_aoiid;
    }

    public void setPro_aoiid(String pro_aoiid) {
        this.pro_aoiid = pro_aoiid;
    }

    public String getPro_vilcode() {
        return pro_vilcode;
    }

    public void setPro_vilcode(String pro_vilcode) {
        this.pro_vilcode = pro_vilcode;
    }

    public String getPro_townAdcode() {
        return pro_townAdcode;
    }

    public void setPro_townAdcode(String pro_townAdcode) {
        this.pro_townAdcode = pro_townAdcode;
    }

    public String getPro_geoX() {
        return pro_geoX;
    }

    public void setPro_geoX(String pro_geoX) {
        this.pro_geoX = pro_geoX;
    }

    public String getPro_geoY() {
        return pro_geoY;
    }

    public void setPro_geoY(String pro_geoY) {
        this.pro_geoY = pro_geoY;
    }

    public String getPro_groupId() {
        return pro_groupId;
    }

    public void setPro_groupId(String pro_groupId) {
        this.pro_groupId = pro_groupId;
    }

    public String getPro_splitResult() {
        return pro_splitResult;
    }

    public void setPro_splitResult(String pro_splitResult) {
        this.pro_splitResult = pro_splitResult;
    }

    public String getPro_standardization() {
        return pro_standardization;
    }

    public void setPro_standardization(String pro_standardization) {
        this.pro_standardization = pro_standardization;
    }

    public String getPro_atAoiSrc() {
        return pro_atAoiSrc;
    }

    public void setPro_atAoiSrc(String pro_atAoiSrc) {
        this.pro_atAoiSrc = pro_atAoiSrc;
    }

    public String getPro_townX() {
        return pro_townX;
    }

    public void setPro_townX(String pro_townX) {
        this.pro_townX = pro_townX;
    }

    public String getPro_townY() {
        return pro_townY;
    }

    public void setPro_townY(String pro_townY) {
        this.pro_townY = pro_townY;
    }

    public String getPro_distance() {
        return pro_distance;
    }

    public void setPro_distance(String pro_distance) {
        this.pro_distance = pro_distance;
    }

    public String getPro_aoiCode() {
        return pro_aoiCode;
    }

    public void setPro_aoiCode(String pro_aoiCode) {
        this.pro_aoiCode = pro_aoiCode;
    }

    public String getPro_deptCode() {
        return pro_deptCode;
    }

    public void setPro_deptCode(String pro_deptCode) {
        this.pro_deptCode = pro_deptCode;
    }

    public String getPro_filter() {
        return pro_filter;
    }

    public void setPro_filter(String pro_filter) {
        this.pro_filter = pro_filter;
    }

    public String getPro_level() {
        return pro_level;
    }

    public void setPro_level(String pro_level) {
        this.pro_level = pro_level;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAtAoiSrc() {
        return atAoiSrc;
    }

    public void setAtAoiSrc(String atAoiSrc) {
        this.atAoiSrc = atAoiSrc;
    }

    public String getXz_result() {
        return xz_result;
    }

    public void setXz_result(String xz_result) {
        this.xz_result = xz_result;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getVilName() {
        return vilName;
    }

    public void setVilName(String vilName) {
        this.vilName = vilName;
    }

    public String getVilSpaceCode() {
        return vilSpaceCode;
    }

    public void setVilSpaceCode(String vilSpaceCode) {
        this.vilSpaceCode = vilSpaceCode;
    }

    public String getClassCode() {
        return classCode;
    }

    public void setClassCode(String classCode) {
        this.classCode = classCode;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getVilcode() {
        return vilcode;
    }

    public void setVilcode(String vilcode) {
        this.vilcode = vilcode;
    }

    public String getTownAdcode() {
        return townAdcode;
    }

    public void setTownAdcode(String townAdcode) {
        this.townAdcode = townAdcode;
    }

    public String getGeoX() {
        return geoX;
    }

    public void setGeoX(String geoX) {
        this.geoX = geoX;
    }

    public String getGeoY() {
        return geoY;
    }

    public void setGeoY(String geoY) {
        this.geoY = geoY;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getStandardization() {
        return standardization;
    }

    public void setStandardization(String standardization) {
        this.standardization = standardization;
    }

    public String getTownX() {
        return townX;
    }

    public void setTownX(String townX) {
        this.townX = townX;
    }

    public String getTownY() {
        return townY;
    }

    public void setTownY(String townY) {
        this.townY = townY;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getP_address() {
        return p_address;
    }

    public void setP_address(String p_address) {
        this.p_address = p_address;
    }

    public String getP_city_code() {
        return p_city_code;
    }

    public void setP_city_code(String p_city_code) {
        this.p_city_code = p_city_code;
    }

    public String getP_sys_code() {
        return p_sys_code;
    }

    public void setP_sys_code(String p_sys_code) {
        this.p_sys_code = p_sys_code;
    }

    public String getP_aoiid() {
        return p_aoiid;
    }

    public void setP_aoiid(String p_aoiid) {
        this.p_aoiid = p_aoiid;
    }

    public String getP_at_aoi_src() {
        return p_at_aoi_src;
    }

    public void setP_at_aoi_src(String p_at_aoi_src) {
        this.p_at_aoi_src = p_at_aoi_src;
    }

    public String getP_aoi_code() {
        return p_aoi_code;
    }

    public void setP_aoi_code(String p_aoi_code) {
        this.p_aoi_code = p_aoi_code;
    }

    public String getP_split_result() {
        return p_split_result;
    }

    public void setP_split_result(String p_split_result) {
        this.p_split_result = p_split_result;
    }

    public String getP_standardization() {
        return p_standardization;
    }

    public void setP_standardization(String p_standardization) {
        this.p_standardization = p_standardization;
    }

    public String getR_vil_space_code() {
        return r_vil_space_code;
    }

    public void setR_vil_space_code(String r_vil_space_code) {
        this.r_vil_space_code = r_vil_space_code;
    }
}

