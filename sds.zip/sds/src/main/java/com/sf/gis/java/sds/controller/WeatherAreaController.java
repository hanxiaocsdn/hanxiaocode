package com.sf.gis.java.sds.controller;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.SparkUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WeatherAreaController {
    private static final Logger logger = LoggerFactory.getLogger(WeatherAreaController.class);
    public void ftpFile2Hive() {
        SparkInfo si = SparkUtil.getSpark(WeatherAreaController.class.getName());
        si.getSession().read().textFile("ftp://gis:brYsj2.023ftKjdev@10.116.49.190:21/YangYan/202110-202203data/ ");
    }
}
