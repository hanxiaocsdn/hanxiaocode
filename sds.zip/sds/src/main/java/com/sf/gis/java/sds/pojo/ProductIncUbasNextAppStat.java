package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ProductIncUbasNextAppStat implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "city")
    private String city;
    @Column(name = "employee_id")
    private String employee_id;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "address")
    private String address;
    @Column(name = "match_type")
    private String match_type;
    @Column(name = "current_tm")
    private String current_tm;
    @Column(name = "properties_type")
    private String properties_type;
    @Column(name = "properties_content")
    private String properties_content;
    @Column(name = "properties_time")
    private String properties_time;
    @Column(name = "tracks")
    private String tracks;
    @Column(name = "cnt_1")
    private String cnt_1;
    @Column(name = "cnt_1_5")
    private String cnt_1_5;
    @Column(name = "cnt_5_10")
    private String cnt_5_10;
    @Column(name = "cnt_10_20")
    private String cnt_10_20;
    @Column(name = "cnt_20_50")
    private String cnt_20_50;
    @Column(name = "cnt_50_75")
    private String cnt_50_75;
    @Column(name = "cnt_75_100")
    private String cnt_75_100;
    @Column(name = "cnt_100")
    private String cnt_100;
    @Column(name = "inc_day")
    private String inc_day;

    public String getCnt_1() {
        return cnt_1;
    }

    public void setCnt_1(String cnt_1) {
        this.cnt_1 = cnt_1;
    }

    public String getCnt_1_5() {
        return cnt_1_5;
    }

    public void setCnt_1_5(String cnt_1_5) {
        this.cnt_1_5 = cnt_1_5;
    }

    public String getCnt_5_10() {
        return cnt_5_10;
    }

    public void setCnt_5_10(String cnt_5_10) {
        this.cnt_5_10 = cnt_5_10;
    }

    public String getCnt_10_20() {
        return cnt_10_20;
    }

    public void setCnt_10_20(String cnt_10_20) {
        this.cnt_10_20 = cnt_10_20;
    }

    public String getCnt_20_50() {
        return cnt_20_50;
    }

    public void setCnt_20_50(String cnt_20_50) {
        this.cnt_20_50 = cnt_20_50;
    }

    public String getCnt_50_75() {
        return cnt_50_75;
    }

    public void setCnt_50_75(String cnt_50_75) {
        this.cnt_50_75 = cnt_50_75;
    }

    public String getCnt_75_100() {
        return cnt_75_100;
    }

    public void setCnt_75_100(String cnt_75_100) {
        this.cnt_75_100 = cnt_75_100;
    }

    public String getCnt_100() {
        return cnt_100;
    }

    public void setCnt_100(String cnt_100) {
        this.cnt_100 = cnt_100;
    }

    public String getTracks() {
        return tracks;
    }

    public void setTracks(String tracks) {
        this.tracks = tracks;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMatch_type() {
        return match_type;
    }

    public void setMatch_type(String match_type) {
        this.match_type = match_type;
    }

    public String getCurrent_tm() {
        return current_tm;
    }

    public void setCurrent_tm(String current_tm) {
        this.current_tm = current_tm;
    }

    public String getProperties_type() {
        return properties_type;
    }

    public void setProperties_type(String properties_type) {
        this.properties_type = properties_type;
    }

    public String getProperties_content() {
        return properties_content;
    }

    public void setProperties_content(String properties_content) {
        this.properties_content = properties_content;
    }

    public String getProperties_time() {
        return properties_time;
    }

    public void setProperties_time(String properties_time) {
        this.properties_time = properties_time;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
