package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfileIncoming;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * GIS-SDS-CORE:【壹竿-虚假管控】SA虚假获利事中逻辑（未达揽收）对接计提需求_V1.0
 * 需求方：刘雨婷（01408947）
 * @author 韩笑（01417629）
 * 任务id：762699
 */

public class TheShippingAddressDoesNotMatchNew3 {
    private static Logger logger = LoggerFactory.getLogger(TheShippingAddressDoesNotMatchNew3.class);

    public static void main(String[] args) {
        String date = args[0];
        String hour1 = args[1];
        String hour_1 = hour1.split(" ")[1].split(":")[0];
        new EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfileIncoming().process(date,hour_1);
        logger.error("process end...");
    }
}
