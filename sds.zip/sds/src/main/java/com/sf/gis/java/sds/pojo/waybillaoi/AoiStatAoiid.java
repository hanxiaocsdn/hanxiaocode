package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class AoiStatAoiid implements Serializable {
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "count")
    private String count;
    @Column(name = "inc_day")
    private String inc_day;

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
