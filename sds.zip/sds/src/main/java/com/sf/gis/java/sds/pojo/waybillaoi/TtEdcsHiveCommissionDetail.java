package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class TtEdcsHiveCommissionDetail implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "waybill_type")
    private String waybill_type;
    @Column(name = "inc_day")
    private String inc_day;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getWaybill_type() {
        return waybill_type;
    }

    public void setWaybill_type(String waybill_type) {
        this.waybill_type = waybill_type;
    }
}
