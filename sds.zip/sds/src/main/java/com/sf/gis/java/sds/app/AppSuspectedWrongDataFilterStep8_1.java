package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.waybillaoi.AppSuspectedWrongDataFilterStep8;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import java.util.stream.Collectors;

/**
 * (工艺8：标准地址判错)
 * 业务方：01424110（喻少丰）
 * 研发：01417629
 * 任务id:930957
 */

public class AppSuspectedWrongDataFilterStep8_1 {
    private static final Logger logger = LoggerFactory.getLogger(AppSuspectedWrongDataFilterStep8_1.class);
    private static final String getAddrByCityCodeAndAddr = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s";
    private static final String geourl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=gd2&address=%s&city=%s";
    private static final String byxyurl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=87106f6380af4df0845a693eee58843c&x=%s&y=%s&opt=aoi&geom=0";

    private static final int limitMin = 4000 / 20;
    private static final String account = "01417629";
    private static final String taskId = "930957";
    private static final String taskName = "aoi准确率3期：工艺8标准地址判错";

    public static void main(String[] args) {
        String date = args[0];
        String startDate = args[1];//t-11
        String endDate = args[2];//t-2
        logger.error("date:{}, date1:{}, date2:{}", date, startDate, endDate);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSuspectedWrongDataFilterStep8_1");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        String sql = String.format("select city_code,gis_to_sys_groupid,80_aoi_code,gisaoisrc from dm_gis.aoi_accuracy_res_step_new2 where inc_day between '%s' and '%s' and city_code not in('852', '853', '886') and gisaoisrc = 'norm' and (80_aoi_code is not null and 80_aoi_code <>'')", startDate, endDate);
        JavaRDD<AppSuspectedWrongDataFilterStep8> rdd = DataUtil.loadData(spark, sc, sql, AppSuspectedWrongDataFilterStep8.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<AppSuspectedWrongDataFilterStep8> filterRdd = rdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o))
                .groupByKey()
                .filter(tp -> Lists.newArrayList(tp._2).size() >= 10)
                .map(tp -> {
                    List<AppSuspectedWrongDataFilterStep8> list = Lists.newArrayList(tp._2);
                    int gis_to_sys_groupid_freq = list.size();
                    Map<String, List<AppSuspectedWrongDataFilterStep8>> map = list.stream().collect(Collectors.groupingBy(AppSuspectedWrongDataFilterStep8::getAoi_80_code));
                    for (Map.Entry<String, List<AppSuspectedWrongDataFilterStep8>> stringListEntry : map.entrySet()) {
                        String key = stringListEntry.getKey();
                        List<AppSuspectedWrongDataFilterStep8> value = stringListEntry.getValue();
                        int aoi_80_code_freq = value.size();
                        double pro_80 = (double) aoi_80_code_freq / (double) gis_to_sys_groupid_freq;
                        list = list.stream().peek(t -> {
                            String aoi_80_code = t.getAoi_80_code();
                            if (StringUtils.equals(aoi_80_code, key)) {
                                t.setPro_80(pro_80);
                            }
                        }).collect(Collectors.toList());
                    }

                    AppSuspectedWrongDataFilterStep8 appSuspectedWrongDataFilterStep8 = list.stream().sorted(Comparator.comparing(AppSuspectedWrongDataFilterStep8::getPro_80, Comparator.reverseOrder())).collect(Collectors.toList()).get(0);
                    String max_80_aoicode = appSuspectedWrongDataFilterStep8.getAoi_80_code();
                    double max_80_pro = appSuspectedWrongDataFilterStep8.getPro_80();

                    appSuspectedWrongDataFilterStep8.setFreq(gis_to_sys_groupid_freq + "");
                    appSuspectedWrongDataFilterStep8.setMax_80_aoicode(max_80_aoicode);
                    appSuspectedWrongDataFilterStep8.setMax_80_pro(max_80_pro + "");
                    appSuspectedWrongDataFilterStep8.setInc_day(date);
                    appSuspectedWrongDataFilterStep8.setFlag("1");

                    return appSuspectedWrongDataFilterStep8;
                }).filter(o -> Double.parseDouble(o.getMax_80_pro()) >= 0.7).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        rdd.unpersist();

        String before1Date = DateUtil.getDaysBefore(date, 1);

        /*String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, getAddrByCityCodeAndAddr, "", filterRdd.count(), 20);
        JavaRDD<AppSuspectedWrongDataFilterStep8> cmsRdd = filterRdd.repartition(60).mapPartitions(itr -> {
            ArrayList<AppSuspectedWrongDataFilterStep8> list = new ArrayList<>();
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                AppSuspectedWrongDataFilterStep8 o = itr.next();
                String city_code = o.getCity_code();
                String group_id = o.getGis_to_sys_groupid();
                String cms_address = "";
                String cms_aoiid = "";
                String cms_znocode = "";
                if (StringUtils.isNotEmpty(group_id)) {
                    String req = String.format(getAddrByCityCodeAndAddr, city_code, group_id);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            try {
                                cms_address = jsonObject.getJSONObject("data").getString("address");
                            } catch (Exception e) {
//                            e.printStackTrace();
                            }
                            try {
                                cms_aoiid = jsonObject.getJSONObject("data").getString("aoiId");
                            } catch (Exception e) {
//                            e.printStackTrace();
                            }

                            try {
                                cms_znocode = jsonObject.getJSONObject("data").getString("znoCode");
                            } catch (Exception e) {
//                            e.printStackTrace();
                            }
                            logger.error("cms_aoiid:{}", cms_aoiid);
                        }
                    }
                }
                o.setCms_address(cms_address);
                o.setCms_aoiid(cms_aoiid);
                o.setCms_znocode(cms_znocode);
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());
        filterRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);*/
        JavaRDD<AppSuspectedWrongDataFilterStep8> cmsRdd = filterRdd.repartition(60).mapPartitions(itr -> {
            Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
            Statement stmt = conn.createStatement();
            ArrayList<AppSuspectedWrongDataFilterStep8> list = new ArrayList<>();
            try {
                while (itr.hasNext()) {
                    AppSuspectedWrongDataFilterStep8 o = itr.next();
                    String city_code = o.getCity_code();
                    String group_id = o.getGis_to_sys_groupid();
                    if (StringUtils.isNotEmpty(group_id) && StringUtils.isNotEmpty(city_code)) {
                        String temp_sql = String.format("select address,zno_code,aoi_id from cms_address_%s where city_code='%s' and address_id = '%s' and `type`=1 group by address,zno_code,aoi_id", cityDbPro.getProperty(city_code), city_code, group_id);
                        logger.info("temp_sql:{}", temp_sql);
                        if (StringUtils.isNotEmpty(temp_sql)) {
                            ResultSet rs = stmt.executeQuery(temp_sql);
                            List<AppSuspectedWrongDataFilterStep8> temp_list = new ArrayList<>();
                            while (rs.next()) {
                                AppSuspectedWrongDataFilterStep8 newO = new AppSuspectedWrongDataFilterStep8();
                                BeanUtils.copyProperties(newO, o);
                                String cms_address = rs.getString("address");
                                String cms_znocode = rs.getString("zno_code");
                                String cms_aoiid = rs.getString("aoi_id");
                                newO.setCms_address(cms_address);
                                newO.setCms_aoiid(cms_aoiid);
                                newO.setCms_znocode(cms_znocode);
                                temp_list.add(newO);
                            }
                            if (temp_list.size() > 0) {
                                list.addAll(temp_list);
                            } else {
                                list.add(o);
                            }
                        } else {
                            list.add(o);
                        }
                    } else {
                        list.add(o);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                stmt.close();
                conn.close();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());
        filterRdd.unpersist();

        String cms_sql = "select aoi_id,aoi_name,zno_code,aoi_code from dm_gis.cms_aoi_sch";
        JavaRDD<CmsAoiSch> cmsAoiSchRdd = DataUtil.loadData(spark, sc, cms_sql, CmsAoiSch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<AppSuspectedWrongDataFilterStep8> cmsNameRdd = cmsRdd.mapToPair(o -> new Tuple2<>(o.getMax_80_aoicode(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
            AppSuspectedWrongDataFilterStep8 o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                o.setMax_80_aoiid(cmsAoiSch.getAoi_id());
                o.setMax_80_aoi_name(cmsAoiSch.getAoi_name());
                o.setMax_80_znocode(cmsAoiSch.getZno_code());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsNameRdd cnt:{}", cmsNameRdd.count());
        cmsRdd.unpersist();

        JavaRDD<AppSuspectedWrongDataFilterStep8> stayRdd = cmsNameRdd.filter(o -> StringUtils.equals(o.getMax_80_znocode(), o.getCms_znocode()) && !StringUtils.equals(o.getMax_80_aoiid(), o.getCms_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AppSuspectedWrongDataFilterStep8> otherRdd = cmsNameRdd.filter(o -> !(StringUtils.equals(o.getMax_80_znocode(), o.getCms_znocode()) && !StringUtils.equals(o.getMax_80_aoiid(), o.getCms_aoiid()))).map(o -> {
            o.setFlag("0");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stayRdd cnt:{}", stayRdd.count());
        logger.error("otherRdd cnt:{}", otherRdd.count());
        cmsNameRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected_suspected_wrong_data_step8 drop if EXISTS partition(inc_day='%s',flag='%s')", date, "0"));
        DataUtil.saveInto(spark, sc, "dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected_suspected_wrong_data_step8", AppSuspectedWrongDataFilterStep8.class, otherRdd, "inc_day", "flag");
        otherRdd.unpersist();

        JavaRDD<AppSuspectedWrongDataFilterStep8> stayAoiNameRdd = stayRdd.mapToPair(o -> new Tuple2<>(o.getCms_aoiid(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    AppSuspectedWrongDataFilterStep8 o = tp._2._1;
                    if (tp._2._1 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setCms_aoiname(cmsAoiSch.getAoi_name());
                    }
                    return o;
                }).filter(o -> {
                    boolean flag = true;
                    String cms_aoiname = o.getCms_aoiname();
                    if (StringUtils.isNotEmpty(cms_aoiname)) {
                        if (cms_aoiname.contains("小学") || cms_aoiname.contains("中学") || cms_aoiname.contains("高中") || cms_aoiname.contains("大学") || cms_aoiname.contains("学校") || cms_aoiname.contains("学院")) {
                            flag = false;
                        }
                    }
                    return flag;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stayAoiNameRdd cnt:{}", stayAoiNameRdd.count());
        stayRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        JavaRDD<AppSuspectedWrongDataFilterStep8> arabNumberAndLowerRdd = stayAoiNameRdd.map(o -> {
            String cms_address = o.getCms_address();
            String cms_aoiname = o.getCms_aoiname();
            String max_80_aoi_name = o.getMax_80_aoi_name();
            if (StringUtils.isNotEmpty(cms_address)) {
                o.setCms_address1(StringNumUtils.outputArabNumberString(cms_address.toLowerCase()));
            }

            if (StringUtils.isNotEmpty(cms_aoiname)) {
                o.setCms_aoiname1(StringNumUtils.outputArabNumberString(cms_aoiname.toLowerCase()));
            }

            if (StringUtils.isNotEmpty(max_80_aoi_name)) {
                o.setMax_80_aoi_name1(StringNumUtils.outputArabNumberString(max_80_aoi_name.toLowerCase()));
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("arabNumberAndLowerRdd cnt:{}", arabNumberAndLowerRdd.count());
        stayAoiNameRdd.unpersist();

        JavaRDD<AppSuspectedWrongDataFilterStep8> wrongRdd = arabNumberAndLowerRdd.map(o -> {
            String max_80_aoi_name1 = o.getMax_80_aoi_name1();
            String cms_aoiname1 = o.getCms_aoiname1();
            String cms_address1 = o.getCms_address1();
            String wrong = "0";

            double max_80_aoi_name_pro = 0;
            if (StringUtils.isNotEmpty(max_80_aoi_name1)) {
                int cnt = sameCnt(max_80_aoi_name1, cms_address1);
                max_80_aoi_name_pro = (double) cnt / (double) (max_80_aoi_name1.length());
                o.setMax_80_aoi_name_pro(max_80_aoi_name_pro + "");
            }

            double cms_aoi_name_pro = 0;
            if (StringUtils.isNotEmpty(cms_aoiname1)) {
                int cnt = sameCnt(cms_aoiname1, cms_address1);
                cms_aoi_name_pro = (double) cnt / (double) (cms_aoiname1.length());
                o.setCms_aoi_name_pro(cms_aoi_name_pro + "");
            }

            double aoiname_pro = 0;
            if (StringUtils.isNotEmpty(max_80_aoi_name1) && StringUtils.isNotEmpty(cms_aoiname1)) {
                int cnt = sameCnt(max_80_aoi_name1, cms_aoiname1);
                int length = Math.min(max_80_aoi_name1.length(), cms_aoiname1.length());
                aoiname_pro = (double) cnt / (double) length;
                o.setAoiname_pro(aoiname_pro + "");
            }

            if (max_80_aoi_name_pro > cms_aoi_name_pro && max_80_aoi_name_pro > 0.5 && aoiname_pro < 0.5) {
                wrong = "1";
            }
            o.setWrong(wrong);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("wrongRdd cnt:{}", wrongRdd.count());
        arabNumberAndLowerRdd.unpersist();

        String dept_sql = String.format("select dept_code cms_znocode from dim.dim_dept_info_df where inc_day = '%s' and dept_type_code = 'DB05-DLD' group by dept_code", before1Date);
        JavaPairRDD<String, AppSuspectedWrongDataFilterStep8> deptRdd = DataUtil.loadData(spark, sc, dept_sql, AppSuspectedWrongDataFilterStep8.class).mapToPair(o -> new Tuple2<>(o.getCms_znocode(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptRdd cnt:{}", deptRdd.count());

        JavaRDD<AppSuspectedWrongDataFilterStep8> wrongDeptRdd = wrongRdd.mapToPair(o -> new Tuple2<>(o.getCms_znocode(), o)).leftOuterJoin(deptRdd).map(tp -> {
            AppSuspectedWrongDataFilterStep8 o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                o.setWrong("0");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("wrongDeptRdd cnt:{}", wrongDeptRdd.count());
        wrongRdd.unpersist();
        deptRdd.unpersist();

        JavaRDD<AppSuspectedWrongDataFilterStep8> eqWrongRdd = wrongDeptRdd.filter(o -> StringUtils.equals(o.getWrong(), "0")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AppSuspectedWrongDataFilterStep8> noEqWrongRdd = wrongDeptRdd.filter(o -> !StringUtils.equals(o.getWrong(), "0")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqWrongRdd cnt:{}", eqWrongRdd.count());
        logger.error("noEqWrongRdd cnt:{}", noEqWrongRdd.count());
        wrongDeptRdd.unpersist();

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, geourl, "87106f6380af4df0845a693eee58843c", eqWrongRdd.count(), 20);
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, byxyurl, "87106f6380af4df0845a693eee58843c", eqWrongRdd.count(), 20);
        JavaRDD<AppSuspectedWrongDataFilterStep8> gdAoiRdd = eqWrongRdd.repartition(20).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<AppSuspectedWrongDataFilterStep8> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                AppSuspectedWrongDataFilterStep8 o = itr.next();
                String cms_address = o.getCms_address();
                String city_code = o.getCity_code();
                if (StringUtils.isNotEmpty(cms_address)) {
                    String req = String.format(geourl, URLEncoder.encode(cms_address, "UTF-8"), city_code);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);

                    String precision = "";
                    String xcoord = "";
                    String ycoord = "";
                    try {
                        precision = JSON.parseObject(content).getJSONObject("result").getString("precision");
                        xcoord = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
                        ycoord = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
                        logger.error("xcoord:{}, ycoord:{}", xcoord, ycoord);

                    } catch (Exception e) {
//                        e.printStackTrace();
                    }

                    o.setPrecision(precision);
                    o.setXcoord(xcoord);
                    o.setYcoord(ycoord);
                    String gd_aoiid = "";
                    if (StringUtils.equals(precision, "2") && StringUtils.isNotEmpty(xcoord) && StringUtils.isNotEmpty(ycoord)) {
                        String aoi_req = String.format(byxyurl, xcoord, ycoord);
                        String xy_content = HttpInvokeUtil.sendGet(aoi_req, FixedConstant.MAX_TRY_TIME_ONCE);
                        try {
                            gd_aoiid = JSON.parseObject(xy_content).getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id");
                            logger.error("gd_aoiid:{}", gd_aoiid);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }
                    }
                    o.setGd_aoiid(gd_aoiid);
                }
                list.add(o);
            }
            return list.iterator();
        }).map(o -> {
            String gd_aoiid = o.getGd_aoiid();
            String max_80_aoiid = o.getMax_80_aoiid();
            if (StringUtils.isNotEmpty(gd_aoiid) && StringUtils.equals(gd_aoiid, max_80_aoiid)) {
                o.setWrong("2");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdAoiRdd cnt:{}", gdAoiRdd.count());
        eqWrongRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        JavaRDD<AppSuspectedWrongDataFilterStep8> resultRdd = gdAoiRdd.union(noEqWrongRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        gdAoiRdd.unpersist();
        noEqWrongRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected_suspected_wrong_data_step8 drop if EXISTS partition(inc_day='%s',flag='%s')", date, "1"));
        DataUtil.saveInto(spark, sc, "dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected_suspected_wrong_data_step8", AppSuspectedWrongDataFilterStep8.class, resultRdd, "inc_day", "flag");
        resultRdd.unpersist();
        sc.stop();
        logger.error("process end...");
    }

    public static int sameCnt(String before, String after) {
        int cnt = 0;
        if (StringUtils.isNotEmpty(before) && StringUtils.isNotEmpty(after)) {
            for (char c : before.toCharArray()) {
                if (after.contains(c + "")) {
                    cnt++;
                }
            }
        }
        return cnt;
    }
}
