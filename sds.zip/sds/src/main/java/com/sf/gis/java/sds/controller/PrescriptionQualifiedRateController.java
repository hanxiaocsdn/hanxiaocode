package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.PrescriptionQualifiedRate;
import com.sf.gis.java.sds.service.PrescriptionQualifiedRateService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class PrescriptionQualifiedRateController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(PrescriptionQualifiedRateController.class);
    PrescriptionQualifiedRateService service = new PrescriptionQualifiedRateService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<PrescriptionQualifiedRate> prescriptionQualifiedRateRdd = service.loadData(spark, sc, date).filter(o -> (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.equals(o.getIsPushLine(), "1")).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("prescriptionQualifiedRateRdd cnt:{}", prescriptionQualifiedRateRdd.count());
            prescriptionQualifiedRateRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<PrescriptionQualifiedRate> prescriptionQualifiedRateResultRdd = prescriptionQualifiedRateRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<PrescriptionQualifiedRate> list = Lists.newArrayList(tp._2);
                PrescriptionQualifiedRate prescriptionQualifiedRate = list.get(0);

                //[自营]任务量
                int zy_taskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //[自营]达成量
                int zy_qualifiedNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //自营达成量[执行]
                int zy_executionQualifiedNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //自营达成量[未执行]
                int zy_noExecutionQualifiedNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //自营执行量
                int zy_executionNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //自营其他执行任务量
                int zy_otherExecutionNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //[自营]执行_超时任务量
                int zy_executionTimeOutNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //[自营]执行_超时总时长
                long zy_executionSumTimeOut = list.stream()
                        .filter(o -> o.getIsZy() == 1 && (StringUtils.equals(o.getConductType(), "1") || StringUtils.equals(o.getConductType(), "2")) && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .stream()
                        .map(o -> o.getNodbDelayMin())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //[自营]未执行_超时任务量
                int zy_no_executionTimeOutNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                //[自营]未执行_超时总时长
                long zy_no_executionSumTimeOut = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getConductType()) && Integer.valueOf(o.getConductType()) > 2 && o.getIsDb() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .stream()
                        .map(o -> o.getNodbDelayMin())
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Long.valueOf(0));

                //[外包]任务量
                int no_zy_taskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();


                //[外包]达成量
                int no_zy_qualifiedNumber = list.stream()
                        .filter(o -> o.getIsZy() == 0 && o.getIsDb() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(PrescriptionQualifiedRate::getTaskId))), ArrayList::new))
                        .size();

                prescriptionQualifiedRate.setZy_taskNumber(zy_taskNumber);
                prescriptionQualifiedRate.setZy_qualifiedNumber(zy_qualifiedNumber);
                prescriptionQualifiedRate.setZy_executionQualifiedNumber(zy_executionQualifiedNumber);
                prescriptionQualifiedRate.setZy_noExecutionQualifiedNumber(zy_noExecutionQualifiedNumber);
                prescriptionQualifiedRate.setZy_executionTimeOutNumber(zy_executionTimeOutNumber);
                prescriptionQualifiedRate.setZy_executionSumTimeOut(zy_executionSumTimeOut);
                prescriptionQualifiedRate.setZy_no_executionTimeOutNumber(zy_no_executionTimeOutNumber);
                prescriptionQualifiedRate.setZy_no_executionSumTimeOut(zy_no_executionSumTimeOut);
                prescriptionQualifiedRate.setNo_zy_taskNumber(no_zy_taskNumber);
                prescriptionQualifiedRate.setNo_zy_qualifiedNumber(no_zy_qualifiedNumber);
                prescriptionQualifiedRate.setZy_executionNumber(zy_executionNumber);
                prescriptionQualifiedRate.setZy_otherExecutionNumber(zy_otherExecutionNumber);

                return prescriptionQualifiedRate;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("prescriptionQualifiedRateResultRdd cnt:{}", prescriptionQualifiedRateResultRdd.count());
            prescriptionQualifiedRateResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            prescriptionQualifiedRateRdd.unpersist();
            if (prescriptionQualifiedRateResultRdd.count() > 0) {
                if (flag != size) {
                    //删除数据
                    spark.sql(String.format("insert overwrite table dm_gis.ETA_EFFECT_PERIOD_REACH_STAT select * from dm_gis.ETA_EFFECT_PERIOD_REACH_STAT where stat_date != '%s'", date));
                    service.delete(date);
                }
                service.saveData(spark, prescriptionQualifiedRateResultRdd);
                service.saveToMysql(sc, prescriptionQualifiedRateResultRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            prescriptionQualifiedRateResultRdd.unpersist();
        }
        spark.stop();
    }
}
