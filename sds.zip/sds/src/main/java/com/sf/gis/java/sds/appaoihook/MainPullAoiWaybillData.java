package com.sf.gis.java.sds.appaoihook;


import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import com.sf.gis.java.sds.controller.PullWaybillDataController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

/**
 * @ProductManager:01369702
 * @Author: 01374443
 * @CreateTime: 2023-03-01
 * @TaskId:225177,225176
 * @TaskName:获取运单挂接aoi-收件-预跑缓存1,获取运单挂接aoi-派件-预跑缓存1
 * @Description:获取运单,走线下挂接流程, 当前挂接流程有一些aoi中心点,在线上无法获取到,所以不好迁到平台上,线下流程在10.119.80.248上python执行
 */
public class MainPullAoiWaybillData {
    private static final Logger logger = LoggerFactory.getLogger(MainPullAoiWaybillData.class);

    public static void main(String[] args) throws Exception {
//		logger.error("begin Main");
//		logger.error("高峰不让跑");
//		System.exit(0);
        long begin = System.currentTimeMillis();
//        try {
            start(args);
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error(e.getMessage());
//            logger.error("over:" + (System.currentTimeMillis() - begin));
//            System.exit(-1);
//        }
        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
        Map<String, String> configMap = ConfigUtil
                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");
        PullWaybillDataController sssWrongDistribute = new PullWaybillDataController(configMap);
        String beginDate = null;
        int days = 0;
        if (args.length == 2) {
            beginDate = args[0];
            days = Integer.valueOf(args[1]);
        }

        sssWrongDistribute.start(beginDate, days);

    }

}
