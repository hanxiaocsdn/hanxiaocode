package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.EtDeliveryAssistantClockInfo;
import com.sf.gis.java.sds.pojo.SaTrajectoryAoi;
import com.sf.gis.java.sds.pojo.TtWayBillHook;
import com.sf.gis.java.sds.utils.DistanceTool;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 需求：双人派件上门校验
 * 需求方：丁汀（01430258）
 * 研发：匡仁衡（01399581）
 * 任务id:739239
 * Modify：（优化部分校验逻辑）01417629 --20231127
 */

public class AppEtDeliveryAssistantClockInfo {
    private static Logger logger = LoggerFactory.getLogger(AppEtDeliveryAssistantClockInfo.class);
    private static String geoUrl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?address=%s&ak=1edc4b681e8945f1be1c9894c0f6aa25";
    private static String queryUrl = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/query";

    private static String atpUrl = "http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh&showserver=true";
    private static String ksUrl = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam?ak=%s&address=%s&city=%s&company=&province=&cityName=&dept=&sssDept=&tc2Dept=&tc2Tc=&tc2Aoi=&tc2AoiCode=&x=&y=&mobile=";
    private static String ak = "282c719ad68049af9740a33a463cd9c3";
    private static String getCircleAoiBaseUrl = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=50";
    private static String getCoorAoiDistUrl = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side";
    private static String account = "01399581";
    private static String taskId = "739239";
    private static String taskName = "双人派件上门校验";

    private static int limitMin = 5000 / 20;

    public static void main(String[] args) {
        String date = args[0];
        String date7 = args[1];//t-7
        logger.error("date:{}", date);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppEtDeliveryAssistantClockInfo");

        JavaRDD<EtDeliveryAssistantClockInfo> rdd = loadData(sparkInfo.getSession(), sparkInfo.getContext(), date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaPairRDD<String, TtWayBillHook> addrRdd = loadAddrData(sparkInfo.getSession(), sparkInfo.getContext(), date, date7).mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrRdd cnt:{}", addrRdd.count());

        JavaRDD<EtDeliveryAssistantClockInfo> supplementRdd = rdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).leftOuterJoin(addrRdd).map(tp -> {
            EtDeliveryAssistantClockInfo o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TtWayBillHook ttWayBillHook = tp._2._2.get();
                o.setConsignee_addr(ttWayBillHook.getConsignee_addr());
                o.setDest_dist_code(ttWayBillHook.getDest_dist_code());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("supplementRdd cnt:{}", supplementRdd.count());
        rdd.unpersist();
        addrRdd.unpersist();

        logger.error("获取地址对应aoiid");
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", atpUrl, ak, supplementRdd.count(), 3);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", ksUrl, ak, supplementRdd.count(), 3);
        JavaRDD<EtDeliveryAssistantClockInfo> aoiRdd = getAoiid(supplementRdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        logger.error("获取小哥前后5分钟的轨迹");
        JavaRDD<EtDeliveryAssistantClockInfo> empTrajectoryRdd = getTrajectory(aoiRdd, sparkInfo.getSession(), sparkInfo.getContext(), date);
        logger.error("生成is_emp1_onsite,is_emp2_onsite,is_emps_onsite");
        JavaRDD<EtDeliveryAssistantClockInfo> empOnsiteRdd = getEmpOnsite(empTrajectoryRdd);
        logger.error("生成is_onsite");
        JavaRDD<EtDeliveryAssistantClockInfo> resultRdd = getIsOnsite(empOnsiteRdd);
        logger.error("结果存储");
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.et_delivery_assistant_clock_info_stat", EtDeliveryAssistantClockInfo.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sparkInfo.getContext().stop();


//        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", geoUrl, "1edc4b681e8945f1be1c9894c0f6aa25", supplementRdd.count(), 20);
//        JavaRDD<EtDeliveryAssistantClockInfo> addrPositionRdd = supplementRdd.mapPartitions(itr -> {
//            int cnt = 0;
//            long startTime = System.currentTimeMillis();
//            List<EtDeliveryAssistantClockInfo> list = new ArrayList<>();
//            while (itr.hasNext()) {
//                cnt = cnt + 1;
//                if (cnt == limitMin) {
//                    long endTime = System.currentTimeMillis() - startTime;
//                    if (endTime < 60000) {
//                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
//                        Thread.sleep(60000 - endTime);
//                    }
//                    startTime = System.currentTimeMillis();
//                    cnt = 0;
//                }
//                EtDeliveryAssistantClockInfo o = itr.next();
//                String consignee_addr = o.getConsignee_addr();
//                if (StringUtils.isNotEmpty(consignee_addr)) {
//                    String req = String.format(geoUrl, URLEncoder.encode(consignee_addr, "UTF-8"));
//                    String content = HttpInvokeUtil.sendGet(req);
//                    String xcoord = "";
//                    String ycoord = "";
//                    try {
//                        xcoord = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
//                        ycoord = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
//                    } catch (Exception e) {
////                        e.printStackTrace();
//                    }
//                    if (StringUtils.isNotEmpty(xcoord) && StringUtils.isNotEmpty(ycoord)) {
//                        o.setAddr_position(xcoord + "," + ycoord);
//                    }
//                }
//                list.add(o);
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("addrPositionRdd cnt:{}", addrPositionRdd.count());
//        supplementRdd.unpersist();
//        BdpTaskRecordUtil.endNetworkInterface(account, id1);
//
//        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, taskName, queryUrl, "52d620a978a94d8184c338bd709cd83b", addrPositionRdd.count(), 20);
//        JavaRDD<EtDeliveryAssistantClockInfo> emp1Rdd = addrPositionRdd.mapPartitions(itr -> {
//            int cnt = 0;
//            long startTime = System.currentTimeMillis();
//            List<EtDeliveryAssistantClockInfo> list = new ArrayList<>();
//            while (itr.hasNext()) {
//                cnt = cnt + 1;
//                if (cnt == limitMin) {
//                    long endTime = System.currentTimeMillis() - startTime;
//                    if (endTime < 60000) {
//                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
//                        Thread.sleep(60000 - endTime);
//                    }
//                    startTime = System.currentTimeMillis();
//                    cnt = 0;
//                }
//                EtDeliveryAssistantClockInfo o = itr.next();
//                o = getPosition(o, "emp1");
//                list.add(o);
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("emp1Rdd cnt:{}", emp1Rdd.count());
//        addrPositionRdd.unpersist();
//        BdpTaskRecordUtil.endNetworkInterface(account, id2);
//
//        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, taskName, queryUrl, "52d620a978a94d8184c338bd709cd83b", emp1Rdd.count(), 20);
//        JavaRDD<EtDeliveryAssistantClockInfo> emp2Rdd = emp1Rdd.mapPartitions(itr -> {
//            int cnt = 0;
//            long startTime = System.currentTimeMillis();
//            List<EtDeliveryAssistantClockInfo> list = new ArrayList<>();
//            while (itr.hasNext()) {
//                cnt = cnt + 1;
//                if (cnt == limitMin) {
//                    long endTime = System.currentTimeMillis() - startTime;
//                    if (endTime < 60000) {
//                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
//                        Thread.sleep(60000 - endTime);
//                    }
//                    startTime = System.currentTimeMillis();
//                    cnt = 0;
//                }
//                EtDeliveryAssistantClockInfo o = itr.next();
//                o = getPosition(o, "emp2");
//                list.add(o);
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("emp2Rdd cnt:{}", emp2Rdd.count());
//        emp2Rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        emp1Rdd.unpersist();
//        BdpTaskRecordUtil.endNetworkInterface(account, id3);
//
//        JavaRDD<EtDeliveryAssistantClockInfo> onsiteRdd = emp2Rdd.map(o -> {
//            String addr_position = o.getAddr_position();
//            String emp1_position = o.getEmp1_position();
//            String emp2_position = o.getEmp2_position();
//
//            String emp1_onsite = getOnsite(addr_position, emp1_position);
//            String emp2_onsite = getOnsite(addr_position, emp2_position);
//            String emps_onsite = getOnsite(emp1_position, emp2_position);
//
//            o.setIs_emp1_onsite(emp1_onsite);
//            o.setIs_emp2_onsite(emp2_onsite);
//            //若emp1_position为空，则取is_emp2_onsite的结果
//            if (StringUtils.isEmpty(emp1_position)) {
//                o.setIs_emps_onsite(emp2_onsite);
//            } else {
//                o.setIs_emps_onsite(emps_onsite);
//            }
//
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("onsiteRdd cnt:{}", onsiteRdd.count());
//        emp2Rdd.unpersist();
//
//        JavaRDD<EtDeliveryAssistantClockInfo> resultRdd = onsiteRdd.map(o -> {
//            String is_emp1_onsite = o.getIs_emp1_onsite();
//            String is_emp2_onsite = o.getIs_emp2_onsite();
//            String is_emps_onsite = o.getIs_emps_onsite();
//
//            ArrayList<String> list = new ArrayList<>();
//            //list.add(is_emp1_onsite);
//            list.add(is_emp2_onsite);
//            list.add(is_emps_onsite);
//
//            long count1 = list.stream().filter(t -> StringUtils.equals(t, "1")).count();
//            long count0 = list.stream().filter(t -> StringUtils.equals(t, "0")).count();
//
//            String is_onsite = "-1";
//            if (count1 >= 2) {
//                is_onsite = "1";
//            }
//
//            if (count0 >= 2) {
//                is_onsite = "0";
//            }
//
//            o.setIs_onsite(is_onsite);
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        onsiteRdd.unpersist();
//
//        DataUtil.saveOverwrite(sparkInfo, "dm_gis.et_delivery_assistant_clock_info_stat", EtDeliveryAssistantClockInfo.class, resultRdd, "inc_day");
//        resultRdd.unpersist();

        logger.error("process end...");
    }

    public static JavaRDD<EtDeliveryAssistantClockInfo> getIsOnsite(JavaRDD<EtDeliveryAssistantClockInfo> empOnsiteRdd) {
        JavaRDD<EtDeliveryAssistantClockInfo> resultRdd = empOnsiteRdd.map(o -> {
            String aoiid = o.getAoiid();
            String position1 = o.getEmp1_position();
            String position2 = o.getEmp2_position();
            //地址是否识别到aoiid
            if (StringUtils.isNotEmpty(aoiid)) {
                //副岗小哥轨迹是否存在
                if (StringUtils.isNotEmpty(position2)) {
                    //副岗小哥是否达到客户地址，轨迹在aoi 100米内
                    double minDistanceAoi2 = getMinDistanceAoi(aoiid, position2);
                    if (minDistanceAoi2 <= 100) {
                        o.setIs_onsite("1");
                    } else {
                        //主岗小哥轨迹是否存在
                        if (StringUtils.isNotEmpty(position1)) {
                            //主岗小哥是否达到客户地址，轨迹在aoi 100米内
                            double minDistanceAoi1 = getMinDistanceAoi(aoiid, position1);
                            if (minDistanceAoi1 <= 100) {
                                //主副岗小哥最近距离是否<=100
                                double min_distance = getMinDistance(position1, position2);
                                if (min_distance <= 100) {
                                    o.setIs_onsite("1");
                                    o.setTag("no_rearch");
                                } else {
                                    o.setIs_onsite("0");
                                    o.setTag("no_rearch");
                                    o.setDis(minDistanceAoi2 + "");
                                }

                            } else {
                                o.setIs_onsite("0");
                                o.setTag("no_rearch");
                                o.setDis(minDistanceAoi2 + "");
                            }

                        } else {
                            o.setIs_onsite("-1");
                            o.setTag("no_emp1");
                        }
                    }

                } else {
                    o.setIs_onsite("-1");
                    o.setTag("no_track");
                }

            } else {
                //主副岗小哥轨迹是否可获取
                if (StringUtils.isNotEmpty(position1) && StringUtils.isNotEmpty(position2)) {
                    //主副岗小哥最近距离是否<=100
                    double min_distance = getMinDistance(position1, position2);
                    if (min_distance <= 100) {
                        o.setIs_onsite("1");
                        o.setTag("no_addr");
                    } else {
                        o.setIs_onsite("0");
                        o.setTag("no_addr");
                        o.setDis(min_distance + "");
                    }
                } else {
                    o.setIs_onsite("-1");
                    o.setTag("no_addr");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        empOnsiteRdd.unpersist();
        return resultRdd;
    }

    public static double getMinDistanceAoi(String aoiid, String position) {
        double min_distance_aoi = Double.MAX_VALUE;
        String[] split = position.split("#");
        for (String s : split) {
            String x = s.split(",")[0];
            String y = s.split(",")[1];
            String req = String.format(getCoorAoiDistUrl, x, y, aoiid);
            String res = HttpInvokeUtil.sendGet(req);
            String data = "";
            try {
                data = JSON.parseObject(res).getString("data");
            } catch (Exception e) {
//                e.printStackTrace();
            }
            if (StringUtils.isNotEmpty(data)) {
                double distance = Double.parseDouble(data);
                if (distance < min_distance_aoi) {
                    min_distance_aoi = distance;
                }
            }
        }
        return min_distance_aoi;
    }

    public static double getMinDistance(String position1, String position2) {
        double min_distance = Double.MAX_VALUE;
        String[] split1 = position1.split("#");
        for (String s1 : split1) {
            String x1 = s1.split(",")[0];
            String y1 = s1.split(",")[1];
            String[] split = position2.split("#");
            for (String s : split) {
                String x2 = s.split(",")[0];
                String y2 = s.split(",")[1];
                double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(x1), Double.parseDouble(y1), Double.parseDouble(x2), Double.parseDouble(y2));
                if (distance < min_distance) {
                    min_distance = distance;
                }
            }
        }
        return min_distance;
    }

    public static JavaRDD<EtDeliveryAssistantClockInfo> getEmpOnsite(JavaRDD<EtDeliveryAssistantClockInfo> empTrajectoryRdd) {
        JavaRDD<EtDeliveryAssistantClockInfo> empOnsiteRdd = empTrajectoryRdd.repartition(400).map(o -> {
            String aoiid = o.getAoiid();
            String emp1_position = o.getEmp1_position();
            String emp2_position = o.getEmp2_position();
            String is_emp1_onsite = getEmp1_2_onsite(aoiid, emp1_position);
            String is_emp2_onsite = getEmp1_2_onsite(aoiid, emp2_position);
            String onsite = getOnsite(emp1_position, emp2_position);

            o.setIs_emp1_onsite(is_emp1_onsite);
            o.setIs_emp2_onsite(is_emp2_onsite);
            o.setIs_emps_onsite(onsite);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empOnsiteRdd cnt:{}", empOnsiteRdd.count());
        empTrajectoryRdd.unpersist();
        return empOnsiteRdd;
    }

    public static String getEmp1_2_onsite(String aoiid, String emp_position) {
        if (StringUtils.isNotEmpty(aoiid) && StringUtils.isNotEmpty(emp_position)) {
            String[] split = emp_position.split("#");
            for (String s : split) {
                String[] split1 = s.split(",");
                String x = split1[0];
                String y = split1[1];
                String req = String.format(getCircleAoiBaseUrl, x, y);
                String res = HttpInvokeUtil.sendGet(req);
                try {
                    JSONArray data = JSON.parseObject(res).getJSONArray("data");
                    for (int i = 0; i < data.size(); i++) {
                        JSONObject jsonObject = data.getJSONObject(i);
                        String id = jsonObject.getString("id");
                        if (StringUtils.equals(id, aoiid)) {
                            return "1";
                        }
                    }
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
            return "0";
        } else {
            return "-1";
        }
    }


    public static JavaRDD<EtDeliveryAssistantClockInfo> getTrajectory(JavaRDD<EtDeliveryAssistantClockInfo> aoiRdd, SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select un,dx,dy,tm from dm_gis.esg_gis_loc_trajectory where inc_day = '%s' and (un is not null and un <>'') and ak = '1' and (dx is not null and dx <>'' and dx != '-1.0') and (dy is not null and dy <>'' and dy != '-1.0') and (tm is not null and tm <>'')", date);
        JavaRDD<SaTrajectoryAoi> trajectoryRdd = DataUtil.loadData(spark, sc, sql, SaTrajectoryAoi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trajectoryRdd cnt:{}", trajectoryRdd.count());

        JavaPairRDD<String, Iterable<SaTrajectoryAoi>> unTrajectoryRdd = trajectoryRdd.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unTrajectoryRdd cnt:{}", unTrajectoryRdd.count());
        trajectoryRdd.unpersist();

        JavaRDD<EtDeliveryAssistantClockInfo> empTrajectoryRdd = aoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp1_code(), o)).leftOuterJoin(unTrajectoryRdd).map(tp -> {
            EtDeliveryAssistantClockInfo o = tp._2._1;
            String emp1_tm = o.getEmp1_tm();
            if (StringUtils.isNotEmpty(emp1_tm)) {
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<SaTrajectoryAoi> list = Lists.newArrayList(tp._2._2.get());
                    o.setEmp1_position(getTrajectoryList(emp1_tm, list));
                }
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getEmp2_code(), o)).leftOuterJoin(unTrajectoryRdd).map(tp -> {
            EtDeliveryAssistantClockInfo o = tp._2._1;
            String emp2_tm = o.getEmp2_tm();
            if (StringUtils.isNotEmpty(emp2_tm)) {
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<SaTrajectoryAoi> list = Lists.newArrayList(tp._2._2.get());
                    o.setEmp2_position(getTrajectoryList(emp2_tm, list));
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empTrajectoryRdd cnt:{}", empTrajectoryRdd.count());
        aoiRdd.unpersist();
        unTrajectoryRdd.unpersist();
        return empTrajectoryRdd;
    }

    public static String getTrajectoryList(String time, List<SaTrajectoryAoi> list) {
        long barscantmstdL = Long.parseLong(time);
        long beforeBarscantmstd = barscantmstdL - 300 * 1000;
        long afterBarscantmstd = barscantmstdL + 300 * 1000;

        List<String> collect = list.stream().filter(o -> {
            long tm = Long.parseLong(o.getTm() + "000");
            return tm >= beforeBarscantmstd && tm <= afterBarscantmstd;
        }).map(o -> o.getDx() + "," + o.getDy()).collect(Collectors.toList());
        return collect.size() > 0 ? String.join("#", collect) : "";
    }

    public static JavaRDD<EtDeliveryAssistantClockInfo> getAoiid(JavaRDD<EtDeliveryAssistantClockInfo> supplementRdd) {
        JavaRDD<EtDeliveryAssistantClockInfo> aoiRdd = supplementRdd.repartition(3).map(o -> {
            String consignee_addr = o.getConsignee_addr();
            String dest_dist_code = o.getDest_dist_code();
            String aoiid = "";
            if (StringUtils.isNotEmpty(consignee_addr)) {
                String atp_req = String.format(atpUrl, URLEncoder.encode(consignee_addr, "UTF-8"), dest_dist_code, ak);
                String atp_rs = HttpInvokeUtil.sendGet(atp_req);
                try {
                    aoiid = JSON.parseObject(atp_rs).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                logger.error("atp aoi:{}", aoiid);
                if (StringUtils.isEmpty(aoiid)) {
                    String ks_req = String.format(ksUrl, ak, URLEncoder.encode(consignee_addr, "UTF-8"), dest_dist_code);
                    String ks_rs = HttpInvokeUtil.sendGet(ks_req);
                    try {
                        aoiid = JSON.parseObject(ks_rs).getJSONObject("result").getString("aoi");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    logger.error("ks aoi:{}", aoiid);
                }
            }
            o.setAoiid(aoiid);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:{}", aoiRdd.count());
        supplementRdd.unpersist();
        return aoiRdd;
    }

    public static String getOnsite(String position1, String positio2) {
        if (StringUtils.isNotEmpty(position1) && StringUtils.isNotEmpty(positio2)) {
            String[] split1 = position1.split("#");
            for (String s1 : split1) {
                String x1 = s1.split(",")[0];
                String y1 = s1.split(",")[1];
                String[] split = positio2.split("#");
                for (String s : split) {
                    String x2 = s.split(",")[0];
                    String y2 = s.split(",")[1];
                    double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(x1), Double.parseDouble(y1), Double.parseDouble(x2), Double.parseDouble(y2));
                    if (distance <= 100) {
                        return "1";
                    }
                }
            }
            return "0";
        } else {
            return "-1";
        }
    }

    public static EtDeliveryAssistantClockInfo getPosition(EtDeliveryAssistantClockInfo o, String tag) {
        String un = "";
        String time = "";
        if (StringUtils.equals(tag, "emp1")) {
            un = o.getEmp1_code();
            time = o.getEmp1_tm();
        } else if (StringUtils.equals(tag, "emp2")) {
            un = o.getEmp2_code();
            time = o.getEmp2_tm();
        }

        if (StringUtils.isNotEmpty(un) && StringUtils.isNotEmpty(time)) {
//            String barscantmstd = DateUtil.dateToStamp(time);
            long barscantmstdL = Long.parseLong(time);
            long beforeBarscantmstd = barscantmstdL - 300 * 1000;
            long afterBarscantmstd = barscantmstdL + 300 * 1000;

            JSONObject param = new JSONObject();
            param.put("type", "1");
            param.put("un", un);
            param.put("unType", "0");
            param.put("rectify", false);
            param.put("ak", "52d620a978a94d8184c338bd709cd83b");
            param.put("beginDateTime", DateUtil.tmToDate(beforeBarscantmstd + "", "yyyyMMddHHmmss"));
            param.put("endDateTime", DateUtil.tmToDate(afterBarscantmstd + "", "yyyyMMddHHmmss"));

            String content = HttpInvokeUtil.sendPost(queryUrl, param.toJSONString());
            if (StringUtils.equals(tag, "emp1")) {
                o.setResp1(content);
            } else if (StringUtils.equals(tag, "emp2")) {
                o.setResp2(content);
            }

            ArrayList<String> list = new ArrayList<>();
            if (StringUtils.isNotEmpty(content)) {
                try {
                    JSONArray track = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("track");
                    for (int i = 0; i < track.size(); i++) {
                        JSONObject jsonObject = track.getJSONObject(i);
                        String dx = jsonObject.getString("dx");
                        String dy = jsonObject.getString("dy");
                        if (StringUtils.isNotEmpty(dx) && StringUtils.isNotEmpty(dy)) {
                            list.add(dx + "," + dy);
                        }
                    }
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                if (StringUtils.equals(tag, "emp1")) {
                    o.setEmp1_position(list.size() > 0 ? String.join("#", list) : "");
                } else if (StringUtils.equals(tag, "emp2")) {
                    o.setEmp2_position(list.size() > 0 ? String.join("#", list) : "");
                }
            }
        }
        return o;
    }

    public static JavaRDD<EtDeliveryAssistantClockInfo> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select\n" +
                "  waybillno,\n" +
                "  barscantm signin_tm,\n" +
                "  baroprcode emp1_code,\n" +
                "  barscantm emp1_tm,\n" +
                "  get_json_object(exts['ext40'],'$.assistantWorkerId') emp2_code,\n" +
                "  barscantm emp2_tm,\n" +
                "  inc_day\n" +
                "from \n" +
                "  ods_kafka_fvp.fvp_core_fact_route_op\n" +
                "where\n" +
                "  inc_day = '%s'\n" +
                "  and opcode = '80'\n" +
                "  and get_json_object(exts['ext40'], '$.sopDoubleDeliveryTag') = '1'", date);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, EtDeliveryAssistantClockInfo.class);
    }


    public static JavaRDD<EtDeliveryAssistantClockInfo> loadEmp1TmData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select waybill_no waybillno,sign_time emp1_tm from ods_fophds.et_delivery_sign_info where inc_day = '%s' and sign_time is not null and sign_time <>''", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, EtDeliveryAssistantClockInfo.class);
    }

    public static JavaRDD<TtWayBillHook> loadAddrData(SparkSession spark, JavaSparkContext sc, String date, String date7) {
        spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01417629/sfdencrpt.ini");
        spark.sql("add jar hdfs://sfbdp1//tmp/udf/01377105/131623/1002/decrypt-2.0.jar");
        spark.sql("create temporary function bdp_decrypt as 'com.sf.udf.decrypt_v2.Decrypt'");
        String sql = String.format("select waybill_no,bdp_decrypt(waybill_no,consignee_addr,false) as consignee_addr,dest_dist_code,waybill_tag from dwd.dwd_waybill_base_info_dtl_di where inc_day between '%s' and '%s' and (consignee_addr is not null and consignee_addr <>'')", date7, date);
        return DataUtil.loadData(spark, sc, sql, TtWayBillHook.class);
    }
}
