package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ArsLogAddressResultMonthMatch implements Serializable {
    @Column(name = "new_tag")
    private String new_tag;
    @Column(name = "pre_tag")
    private String pre_tag;
    @Column(name = "sn")
    private String sn;
    @Column(name = "ak")
    private String ak;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "district")
    private String district;
    @Column(name = "address")
    private String address;
    @Column(name = "pre_city_code")
    private String pre_city_code;
    @Column(name = "pre_province")
    private String pre_province;
    @Column(name = "pre_city")
    private String pre_city;
    @Column(name = "pre_county")
    private String pre_county;
    @Column(name = "pre_town")
    private String pre_town;
    @Column(name = "pre_village")
    private String pre_village;
    @Column(name = "pre_detailinfo")
    private String pre_detailinfo;
    @Column(name = "pre_source")
    private String pre_source;
    @Column(name = "pre_src")
    private String pre_src;
    @Column(name = "pre_result")
    private String pre_result;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "freq")
    private String freq;
    @Column(name = "oper_date")
    private String oper_date;

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getNew_tag() {
        return new_tag;
    }

    public void setNew_tag(String new_tag) {
        this.new_tag = new_tag;
    }

    public String getPre_tag() {
        return pre_tag;
    }

    public void setPre_tag(String pre_tag) {
        this.pre_tag = pre_tag;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPre_city_code() {
        return pre_city_code;
    }

    public void setPre_city_code(String pre_city_code) {
        this.pre_city_code = pre_city_code;
    }

    public String getPre_province() {
        return pre_province;
    }

    public void setPre_province(String pre_province) {
        this.pre_province = pre_province;
    }

    public String getPre_city() {
        return pre_city;
    }

    public void setPre_city(String pre_city) {
        this.pre_city = pre_city;
    }

    public String getPre_county() {
        return pre_county;
    }

    public void setPre_county(String pre_county) {
        this.pre_county = pre_county;
    }

    public String getPre_town() {
        return pre_town;
    }

    public void setPre_town(String pre_town) {
        this.pre_town = pre_town;
    }

    public String getPre_village() {
        return pre_village;
    }

    public void setPre_village(String pre_village) {
        this.pre_village = pre_village;
    }

    public String getPre_detailinfo() {
        return pre_detailinfo;
    }

    public void setPre_detailinfo(String pre_detailinfo) {
        this.pre_detailinfo = pre_detailinfo;
    }

    public String getPre_source() {
        return pre_source;
    }

    public void setPre_source(String pre_source) {
        this.pre_source = pre_source;
    }

    public String getPre_src() {
        return pre_src;
    }

    public void setPre_src(String pre_src) {
        this.pre_src = pre_src;
    }

    public String getPre_result() {
        return pre_result;
    }

    public void setPre_result(String pre_result) {
        this.pre_result = pre_result;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getOper_date() {
        return oper_date;
    }

    public void setOper_date(String oper_date) {
        this.oper_date = oper_date;
    }
}
