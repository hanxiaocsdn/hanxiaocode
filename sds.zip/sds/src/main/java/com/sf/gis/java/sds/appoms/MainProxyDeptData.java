package com.sf.gis.java.sds.appoms;


import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import com.sf.gis.java.sds.controller.PullProxyDeptDataController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

public class MainProxyDeptData {
    private static final Logger logger = LoggerFactory.getLogger(MainProxyDeptData.class);

    public static void main(String[] args) throws IOException {
        logger.error("begin Main");
        long begin = System.currentTimeMillis();
        try {
            start(args);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
        Map<String, String> configMap = ConfigUtil
                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");
        PullProxyDeptDataController aoiDataDistribute = new PullProxyDeptDataController(configMap);

        aoiDataDistribute.start();

    }

}