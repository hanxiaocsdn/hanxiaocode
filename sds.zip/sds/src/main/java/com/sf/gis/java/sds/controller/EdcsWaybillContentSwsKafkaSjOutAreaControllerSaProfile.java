package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.graph.aoi.common.util.KeyWordUtil;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.aoicompletion.*;
import com.sf.gis.java.sds.pojo.waybillaoi.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.pojo.waybillaoi.ScheduleWidthData;
import com.sf.gis.java.sds.pojo.waybillaoi.ZnocodeToAoi;
import com.sf.gis.java.sds.service.EdcsWaybillContentSwsKafkaService;
import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.Table;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.Optional;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfile implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfile.class);
    EdcsWaybillContentSwsKafkaService service = new EdcsWaybillContentSwsKafkaService();
    private static final String ats = "http://gis-int.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&province=%s&cityName=%s&district=%s&city=%s&tel=%s&mobile=%s&company=%s&ak=2d56aff133e7456584abd3c1be674f0f&opt=zh&callDispatch=1&isNotUnderCall=%s&contacts=&customerAccount=%s";
    private static final String ks = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam";
    private static final String majorCode = "http://public-int-gw.int.sfdc.com.cn:1080/bdus-api/employees/%s?fields=empNum,empName,majorCode";
    private static final String getAoiByXyUrl = "http://gis-int.int.sfdc.com.cn:1080/dept2/info/aoi/coord";
    private static final String similarityUrl = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=2d56aff133e7456584abd3c1be674f0f&beforeAddress=%s&afterAddress=%s";

    private static final int limitMin = 30000 / 100;
    private static final int limitMinSimilar = 60000 / 100;

    public void process(String date) {

        //初始化spark
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfile");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCodeSet = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCodeSet);

        //SELECT dept_code,loginid,aoi_id,aoi_name,pick_jiti,send_jiti,aoi_count FROM dm_gis.tm_schedule_width_data_v2_pretreatment
        JavaRDD<ScheduleWidthData> scheduleWidthDataRdd = service.loadScheduleWidthPretreatmentData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataRdd cnt:{}", scheduleWidthDataRdd.count());

        //SELECT waybillno,syncreqdatetime,finalaoicode,deptcode,emp_code,reqtimetm,aoi_id,orderno FROM dm_gis.gis_rds_omsfrom_pretreatment_emp_code
        JavaRDD<GisRdsOmsfrom> rdsOmsfromRdd = service.loadRdsOmsfromPretreatmentEmpCodeData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsOmsfromRdd cnt:{}", rdsOmsfromRdd.count());

        //SELECT emp_code,aoi_id,aoi_zc,aoi_name,aoi_count,pick_jiti,send_jiti FROM dm_gis.hook_pretreatment
        JavaRDD<OrderWaybillHook> orderWaybillHookRdd = service.loadTtOrderWaybillPretreatmentData(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("orderWaybillHookRdd cnt:{}", orderWaybillHookRdd.count());

        //SELECT mainwaybillno,exts FROM dm_gis.fvp_core_fact_route_rt_pretreatment
        JavaRDD<FvpCoreFactRouteRt> extsRdd = service.loadFvpCoreFactRouteRtExtsPretreatmentData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("extsRdd cnt:{}", extsRdd.count());

        //waybillNo,originalZoneCode,destinationZoneCode,empCode,takeoverTm,aoiId dm_gis.the_shipping_address_does_not_match_1
        JavaRDD<EdcsWaybillContentSwsKafka> filterTagSjRdd = service.loadTheShippingAddressDoesNotMatch(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sjRdd cnt:{}", filterTagSjRdd.count());


        //elect aoi_id,aoi_code,aoi_name,fa_type,zno_code from dm_gis.cms_aoi_sch
        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        //Properties operationInfo = ConfigurationUtil.loadProperties2("operationwaybillhbase.properties");
        Properties operationInfo = ConfigUtil.loadPropertiesConfiguration("operationwaybillhbase.properties");
        logger.error("operationInfo:{}", operationInfo.toString());
        Broadcast<Properties> operationInfoBc = sc.broadcast(operationInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> addrRdd = filterTagSjRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = operationInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("opw" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getOperationWaybill(jsonList, tempList, "sj"));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getOperationWaybill(jsonList, tempList, "sj"));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrRdd cnt:{}", addrRdd.count());
        filterTagSjRdd.unpersist();


        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤1处理:获取员工岗位主岗 ☆☆☆☆☆☆☆☆☆☆");
        //select emp_code,position_name,dept_code from dm_gis.the_shipping_address_does_not_match_1
        JavaRDD<EmpInfoDtlDf> empInfoDtlDfRdd = service.loadEmpInfoAll_1(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empInfoDtlDfRdd cnt:{}", empInfoDtlDfRdd.count());

        JavaPairRDD<String, EmpInfoDtlDf> empInfoDtlDfXzRdd = empInfoDtlDfRdd.filter(o -> StringUtils.equals(o.getPosition_name(), "协助员")).mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empInfoDtlDfXzRdd cnt:{}", empInfoDtlDfXzRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzRdd = addrRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(empInfoDtlDfXzRdd).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                EmpInfoDtlDf empInfoDtlDf = tp._2._2.get();
                o.setPosition_name(empInfoDtlDf.getPosition_name());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("positionNameXzRdd cnt:{}", positionNameXzRdd.count());
        addrRdd.unpersist();
        empInfoDtlDfXzRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzNoEmpRdd = positionNameXzRdd.filter(o -> StringUtils.equals(o.getPosition_name(), "协助员")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> positionNameXzEmpRdd = positionNameXzRdd.filter(o -> !StringUtils.equals(o.getPosition_name(), "协助员")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("positionNameXzNoEmpRdd cnt:{}", positionNameXzNoEmpRdd.count());
        logger.error("positionNameXzEmpRdd cnt:{}", positionNameXzEmpRdd.count());
        positionNameXzRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> majorCodeRdd = positionNameXzNoEmpRdd.map(o -> {
            String emp_code = o.getEmp_code();
            if (StringUtils.isNotEmpty(emp_code)) {
                String req = String.format(majorCode, emp_code);
                String content = service.doGet(req, "6265fafb263ab0e4cab9513e");
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        String majorCode = jsonObject.getString("majorCode");
                        logger.error("majorCode:{}", majorCode);
                        if (StringUtils.isNotEmpty(majorCode)) {
                            majorCode = service.processTakeoverMemberNo(majorCode);
                            o.setEmp_code(majorCode);
                        }
                    }
                }
            }
            return o;
        }).union(positionNameXzEmpRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("majorCodeRdd cnt:{}", majorCodeRdd.count());
        positionNameXzNoEmpRdd.unpersist();
        positionNameXzEmpRdd.unpersist();

        logger.error("========================================");
        logger.error("☆☆☆☆☆☆☆☆☆☆ 步骤2处理:关联排班表 ☆☆☆☆☆☆☆☆☆☆");

        JavaRDD<ScheduleWidthData> scheduleWidthDataSizeRdd = scheduleWidthDataRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o)).groupByKey().map(tp -> {
            List<ScheduleWidthData> list = Lists.newArrayList(tp._2);
            ScheduleWidthData scheduleWidthData = list.get(0);
            List<ScheduleWidthData> distinctList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(ScheduleWidthData::getAoi_id))), ArrayList::new));
            int size = distinctList.size();
            if (size >= 1) {
                List<CmsAoiSch> cmsAoiSchList = distinctList.stream().map(o -> {
                    CmsAoiSch cmsAoiSch = new CmsAoiSch();

                    cmsAoiSch.setAoi_id(o.getAoi_id());
                    cmsAoiSch.setDept_code(o.getDept_code());
                    cmsAoiSch.setAoi_name(o.getAoi_name());
                    cmsAoiSch.setJiti(o.getPick_jiti());
                    cmsAoiSch.setAoi_count(o.getAoi_count());
                    return cmsAoiSch;
                }).collect(Collectors.toList());
                scheduleWidthData.setList(cmsAoiSchList);
            }
            scheduleWidthData.setAoi_size(size);
            return scheduleWidthData;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("scheduleWidthDataSizeRdd cnt:{}", scheduleWidthDataSizeRdd.count());
        scheduleWidthDataRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> majorCodeScheduleWidthRdd = majorCodeRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(scheduleWidthDataSizeRdd.mapToPair(o -> new Tuple2<>(o.getLoginid(), o))).map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        ScheduleWidthData scheduleWidthData = tp._2._2.get();
                        o.setAoi_size(scheduleWidthData.getAoi_size());
                        o.setList(scheduleWidthData.getList());
                    } else {
                        o.setTag("no_consignee_emp");
                    }
                    return o;
                }).map(o -> {
                    String takeover_tm = o.getTakeover_tm();
                    if (StringUtils.isNotEmpty(takeover_tm)) {
                        String barscantmstd = DateUtil.dateToStamp(takeover_tm);
                        long barscantmstdL = Long.parseLong(barscantmstd);
                        long before = barscantmstdL - 10 * 60 * 1000;
                        long after = barscantmstdL + 10 * 60 * 1000;

                        o.setBarscantmstd(barscantmstd);
                        o.setBefore10min(before + "");
                        o.setAfter10min(after + "");
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("majorCodeScheduleWidthRdd cnt:{}", majorCodeScheduleWidthRdd.count());
        majorCodeRdd.unpersist();
        scheduleWidthDataSizeRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiSizeEq1Rdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() == 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiSizeGt1Rdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() > 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> otherRdd = majorCodeScheduleWidthRdd.filter(o -> o.getAoi_size() == 0).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiSizeEq1Rdd cnt:{}", aoiSizeEq1Rdd.count());
        logger.error("aoiSizeGt1Rdd cnt:{}", aoiSizeGt1Rdd.count());
        logger.error("otherRdd cnt:{}", otherRdd.count());
        majorCodeScheduleWidthRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueRdd = aoiSizeEq1Rdd.map(o -> {
            CmsAoiSch cmsAoiSch = o.getList().get(0);
            String original_zone_code = o.getOriginal_zone_code();
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, cmsAoiSch.getDept_code())) {
                o.setLastAoiid(cmsAoiSch.getAoi_id());
                o.setTag("aoi_id_unique");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdUniqueRdd cnt:{}", aoiIdUniqueRdd.count());
        aoiSizeEq1Rdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueAoiRdd = aoiIdUniqueRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdUniqueEmpAoiRdd = aoiIdUniqueRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdUniqueAoiRdd cnt:{}", aoiIdUniqueAoiRdd.count());
        logger.error("aoiIdUniqueEmpAoiRdd cnt:{}", aoiIdUniqueEmpAoiRdd.count());
        aoiIdUniqueRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeRdd = aoiSizeGt1Rdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(rdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            String before10min = o.getBefore10min();
            String after10min = o.getAfter10min();
            String barscantmstd = o.getBarscantmstd();
            String original_zone_code = o.getOriginal_zone_code();
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<GisRdsOmsfrom> list = Lists.newArrayList(tp._2._2.get());
                list = list.stream().filter(t -> {
                    boolean flag = false;
                    String reqtimetm = t.getReqtimetm();
                    if (StringUtils.isNotEmpty(reqtimetm) && StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min)) {
                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                            flag = true;
                        }
                    }
                    return flag;
                }).collect(Collectors.toList());

                List<GisRdsOmsfrom> gtList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) < Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                List<GisRdsOmsfrom> ltList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) > Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                String gt_aoi = "";
                String lt_aoi = "";
                String dept_code = "";
                if (gtList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = gtList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0);
                    gt_aoi = gisRdsOmsfrom.getAoi_id();
                    dept_code = gisRdsOmsfrom.getDeptcode();
                }
                if (ltList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = ltList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0);
                    lt_aoi = gisRdsOmsfrom.getAoi_id();
                }
                if (StringUtils.isNotEmpty(gt_aoi) && StringUtils.equals(gt_aoi, lt_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, dept_code)) {
                    o.setLastAoiid(gt_aoi);
                    o.setTag("aoi_id_54_time");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeRdd cnt:{}", aoiId54TimeRdd.count());
        aoiSizeGt1Rdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeAoiRdd = aoiId54TimeRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeEmpAoiRdd = aoiId54TimeRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeAoiRdd cnt:{}", aoiId54TimeAoiRdd.count());
        logger.error("aoiId54TimeEmpAoiRdd cnt:{}", aoiId54TimeEmpAoiRdd.count());
        aoiId54TimeRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd1 = aoiIdUniqueAoiRdd.union(aoiId54TimeAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd1 cnt:{}", rdd1.count());
        aoiIdUniqueAoiRdd.unpersist();
        aoiId54TimeAoiRdd.unpersist();

        //Properties bizlogsjInfo = ConfigurationUtil.loadProperties2("bizlogsjhbase.properties");
        Properties bizlogsjInfo = ConfigUtil.loadPropertiesConfiguration("bizlogsjhbase.properties");
        logger.error("bizlogsjInfo:{}", bizlogsjInfo.toString());
        Broadcast<Properties> bizlogsjInfoBc = sc.broadcast(bizlogsjInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> eventXyRdd = aoiId54TimeEmpAoiRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = bizlogsjInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("sks" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getEventlngXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getEventlngXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eventXyRdd cnt:{}", eventXyRdd.count());
        aoiId54TimeEmpAoiRdd.unpersist();

        Properties ttappointadditionInfo = ConfigUtil.loadPropertiesConfiguration("ttappointadditionhbase.properties");
        logger.error("ttappointadditionInfo:{}", ttappointadditionInfo.toString());
        Broadcast<Properties> ttappointadditionInfoBc = sc.broadcast(ttappointadditionInfo);
        JavaRDD<EdcsWaybillContentSwsKafka> srcXyRdd = eventXyRdd.filter(o -> StringUtils.isNotEmpty(o.getWaybillnoOrderNo())).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = ttappointadditionInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("taa" + "_" + o.getWaybillnoOrderNo(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getSrcXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getSrcXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).union(eventXyRdd.filter(o -> StringUtils.isEmpty(o.getWaybillnoOrderNo()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("srcXyRdd cnt:{}", srcXyRdd.count());
        eventXyRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordRdd = srcXyRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            String eventlng = o.getEventlng();
            String eventlat = o.getEventlat();
            String event_aoiAndzc = "";

            String src_lgt = o.getSrc_lgt();
            String src_lat = o.getSrc_lat();
            String src_aoiAndzc = "";

            if (StringUtils.isNotEmpty(eventlng) && StringUtils.isNotEmpty(eventlat)) {
                event_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, eventlng, eventlat);
            }
            if (StringUtils.isNotEmpty(src_lgt) && StringUtils.isNotEmpty(src_lat)) {
                src_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, src_lgt, src_lat);
            }
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(event_aoiAndzc) && event_aoiAndzc.split(",").length == 2
                    && StringUtils.isNotEmpty(src_aoiAndzc) && src_aoiAndzc.split(",").length == 2 && StringUtils.equals(event_aoiAndzc.split(",")[0], src_aoiAndzc.split(",")[0]) && StringUtils.equals(event_aoiAndzc.split(",")[1], original_zone_code)) {
                o.setLastAoiid(event_aoiAndzc.split(",")[0]);
                o.setTag("aoi_id_54_coord");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordRdd cnt:{}", aoiId54CoordRdd.count());
        srcXyRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordAoiRdd = aoiId54CoordRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordEmpAoiRdd = aoiId54CoordRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordAoiRdd cnt:{}", aoiId54CoordAoiRdd.count());
        logger.error("aoiId54CoordEmpAoiRdd cnt:{}", aoiId54CoordEmpAoiRdd.count());
        aoiId54CoordRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd2 = rdd1.union(aoiId54CoordAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd2 cnt:{}", rdd2.count());
        rdd1.unpersist();
        aoiId54CoordAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsRdd = aoiId54CoordEmpAoiRdd.map(o -> {
            String addr = o.getAddr();
            String original_zone_code = o.getOriginal_zone_code();
            if (StringUtils.isNotEmpty(addr)) {
                List<CmsAoiSch> list = o.getList();
                for (CmsAoiSch cmsAoiSch : list) {
                    String aoi_name = cmsAoiSch.getAoi_name();
                    if (StringUtils.isNotEmpty(aoi_name) && addr.contains(aoi_name)) {
                        String aoi_id = cmsAoiSch.getAoi_id();
                        String dept_code = cmsAoiSch.getDept_code();
                        if (StringUtils.isNotEmpty(aoi_id) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(dept_code, original_zone_code)) {
                            o.setLastAoiid(aoi_id);
                            o.setTag("similar");
                            break;
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarContainsRdd cnt:{}", similarContainsRdd.count());
        aoiId54CoordEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsAoiRdd = similarContainsRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarContainsEmpAoiRdd = similarContainsRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarContainsAoiRdd cnt:{}", similarContainsAoiRdd.count());
        logger.error("similarContainsEmpAoiRdd cnt:{}", similarContainsEmpAoiRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> rdd3 = rdd2.union(similarContainsAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd3 cnt:{}", rdd3.count());
        rdd2.unpersist();
        similarContainsAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameRdd = similarContainsEmpAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getAddr())).repartition(SysConstant.PARTITION_COUNT).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                String addr = o.getAddr();
                String original_zone_code = o.getOriginal_zone_code();
                List<CmsAoiSch> aoiNameList = o.getList().stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_name())).collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getAoi_name))), ArrayList::new));
                for (CmsAoiSch cmsAoiSch : aoiNameList) {
                    String aoi_name = cmsAoiSch.getAoi_name();
                    double similarity = KeyWordUtil.similarity(addr, aoi_name);
                    cmsAoiSch.setSimilarity(similarity + "");
                }

                List<CmsAoiSch> sortList = aoiNameList.stream().filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7 && StringUtils.isNotEmpty(t.getDept_code()) && StringUtils.equals(t.getDept_code(), original_zone_code))
                        .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                        .collect(Collectors.toList());

                if (sortList.size() > 0) {
                    CmsAoiSch cmsAoiSch = sortList.get(0);
                    String aoi_id = cmsAoiSch.getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("similar");
                    }
                }
                result.add(o);
            }
            return result.iterator();
        }).union(similarContainsEmpAoiRdd.filter(o -> StringUtils.isEmpty(o.getAddr()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarAddrAoiNameRdd cnt:{}", similarAddrAoiNameRdd.count());
        similarContainsEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameAoiRdd = similarAddrAoiNameRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarAddrAoiNameEmpAoiRdd = similarAddrAoiNameRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarAddrAoiNameAoiRdd cnt:{}", similarAddrAoiNameAoiRdd.count());
        logger.error("similarAddrAoiNameEmpAoiRdd cnt:{}", similarAddrAoiNameEmpAoiRdd.count());
        similarAddrAoiNameRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd4 = rdd3.union(similarAddrAoiNameAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd4 cnt:{}", rdd4.count());
        rdd3.unpersist();
        similarAddrAoiNameAoiRdd.unpersist();

        JavaRDD<ZnocodeToAoi> znocodeToAoiRdd = service.loadZnocodeToAoi(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("znocodeToAoiRdd cnt:{}", znocodeToAoiRdd.count());

        JavaRDD<TmDepartment> tmDepartmentRdd = service.loadTmDepartment(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tmDepartmentRdd cnt:{}", tmDepartmentRdd.count());

        JavaRDD<EmapLayerFeatureCmsemap> emapLayerFeatureCmsemapRdd = service.loadEmapLayer(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("emapLayerFeatureCmsemapRdd cnt:{}", emapLayerFeatureCmsemapRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> supPositionNameRdd = service.joinPositionName(similarAddrAoiNameEmpAoiRdd, tmDepartmentRdd, empInfoDtlDfRdd, emapLayerFeatureCmsemapRdd, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("supPositionNameRdd cnt:{}", supPositionNameRdd.count());
        similarAddrAoiNameEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransRdd = service.joinZnocodeToAoi(supPositionNameRdd, znocodeToAoiRdd, getAoiByXyUrl, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransRdd cnt:{}", zcAndTransRdd.count());
        supPositionNameRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransAoiRdd = zcAndTransRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransEmpAoiRdd = zcAndTransRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransAoiRdd cnt:{}", zcAndTransAoiRdd.count());
        logger.error("zcAndTransEmpAoiRdd cnt:{}", zcAndTransEmpAoiRdd.count());
        zcAndTransRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd5 = rdd4.union(zcAndTransAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd5 cnt:{}", rdd5.count());
        rdd4.unpersist();
        zcAndTransAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomRdd = zcAndTransEmpAoiRdd.map(o -> {
            List<CmsAoiSch> list = o.getList();
            if (list.size() > 0) {
                ArrayList<CmsAoiSch> uniqueJitiList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getJiti()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(CmsAoiSch::getJiti))), ArrayList::new));
                if (uniqueJitiList.size() == 1) {
                    String aoi_id = uniqueJitiList.get(0).getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("aoi_id_random");
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdRandomRdd cnt:{}", aoiIdRandomRdd.count());
        zcAndTransEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomAoiRdd = aoiIdRandomRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdRandomEmpAoiRdd = aoiIdRandomRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdRandomAoiRdd cnt:{}", aoiIdRandomAoiRdd.count());
        logger.error("aoiIdRandomEmpAoiRdd cnt:{}", aoiIdRandomEmpAoiRdd.count());
        aoiIdRandomRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd6 = rdd5.union(aoiIdRandomAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd6 cnt:{}", rdd6.count());
        rdd5.unpersist();
        aoiIdRandomAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatRdd = aoiIdRandomEmpAoiRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            List<CmsAoiSch> list = o.getList();
            if (list.size() > 0) {
                List<CmsAoiSch> aoiCountList = list.stream()
                        .filter(t -> StringUtils.isNotEmpty(t.getDept_code()) && StringUtils.equals(original_zone_code, t.getDept_code()) && StringUtils.isNotEmpty(t.getAoi_count()))
                        .sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList());
                if (aoiCountList.size() > 0) {
                    String aoi_id = aoiCountList.get(0).getAoi_id();
                    if (StringUtils.isNotEmpty(aoi_id)) {
                        o.setLastAoiid(aoi_id);
                        o.setTag("aoi_id_stat");
                    }
                } else {
                    o.setTag("no_stat");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatRdd cnt:{}", aoiIdStatRdd.count());
        aoiIdRandomEmpAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatAoiRdd = aoiIdStatRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatEmpAoiRdd = aoiIdStatRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatAoiRdd cnt:{}", aoiIdStatAoiRdd.count());
        logger.error("aoiIdStatEmpAoiRdd cnt:{}", aoiIdStatEmpAoiRdd.count());
        aoiIdStatRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd7 = rdd6.union(aoiIdStatAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd7 cnt:{}", rdd7.count());
        rdd6.unpersist();
        aoiIdStatAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleRdd = otherRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(rdsOmsfromRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            String before10min = o.getBefore10min();
            String after10min = o.getAfter10min();
            String barscantmstd = o.getBarscantmstd();
            String original_zone_code = o.getOriginal_zone_code();
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<GisRdsOmsfrom> list = Lists.newArrayList(tp._2._2.get());
                list = list.stream().filter(t -> {
                    boolean flag = false;
                    String reqtimetm = t.getReqtimetm();
                    if (StringUtils.isNotEmpty(reqtimetm) && StringUtils.isNotEmpty(before10min) && StringUtils.isNotEmpty(after10min)) {
                        if (Long.parseLong(before10min) <= Long.parseLong(reqtimetm) && Long.parseLong(after10min) >= Long.parseLong(reqtimetm)) {
                            flag = true;
                        }
                    }
                    return flag;
                }).collect(Collectors.toList());

                List<GisRdsOmsfrom> gtList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) < Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                List<GisRdsOmsfrom> ltList = list.stream().filter(t -> StringUtils.isNotEmpty(barscantmstd) && StringUtils.isNotEmpty(t.getReqtimetm()) && Long.parseLong(barscantmstd) > Long.parseLong(t.getReqtimetm())).collect(Collectors.toList());
                String gt_aoi = "";
                String lt_aoi = "";
                String dept_code = "";
                if (gtList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = gtList.stream().sorted((o1, o2) -> o1.getReqtimetm().compareTo(o2.getReqtimetm())).collect(Collectors.toList()).get(0);
                    gt_aoi = gisRdsOmsfrom.getAoi_id();
                    dept_code = gisRdsOmsfrom.getDeptcode();
                }
                if (ltList.size() > 0) {
                    GisRdsOmsfrom gisRdsOmsfrom = ltList.stream().sorted((o1, o2) -> o2.getReqtimetm().compareTo(o1.getReqtimetm())).collect(Collectors.toList()).get(0);
                    lt_aoi = gisRdsOmsfrom.getAoi_id();
                }
                if (StringUtils.isNotEmpty(gt_aoi) && StringUtils.equals(gt_aoi, lt_aoi) && StringUtils.isNotEmpty(original_zone_code) && StringUtils.equals(original_zone_code, dept_code)) {
                    o.setLastAoiid(gt_aoi);
                    o.setTag("aoi_id_54_time_no_schedule");
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleRdd cnt:{}", aoiId54TimeNoScheduleRdd.count());
        otherRdd.unpersist();
        rdsOmsfromRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleAoiRdd = aoiId54TimeNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiRdd = aoiId54TimeNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleAoiRdd cnt:{}", aoiId54TimeNoScheduleAoiRdd.count());
        logger.error("aoiId54TimeNoScheduleEmpAoiRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiRdd.count());
        aoiId54TimeNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd8 = rdd7.union(aoiId54TimeNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd8 cnt:{}", rdd8.count());
        rdd7.unpersist();
        aoiId54TimeNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiEventXyRdd = aoiId54TimeNoScheduleEmpAoiRdd.mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = bizlogsjInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("sks" + "_" + o.getWaybill_no(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getEventlngXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getEventlngXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleEmpAoiEventXyRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiEventXyRdd.count());
        aoiId54TimeNoScheduleEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54TimeNoScheduleEmpAoiSrcXyRdd = aoiId54TimeNoScheduleEmpAoiEventXyRdd.filter(o -> StringUtils.isNotEmpty(o.getWaybillnoOrderNo())).mapPartitions(itr -> {
            List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
            Properties prop = ttappointadditionInfoBc.getValue();
            HbaseUtil.setProperties(prop);
            String tableName = prop.getProperty("hbase.gis.table");
            String family = prop.getProperty("hbase.gis.family");
            String column = prop.getProperty("hbase.gis.column");
            int putSize = Integer.parseInt(prop.getProperty("batchSize"));
            Connection conn = HbaseUtil.getConnection();
            Table table = HbaseUtil.getTable(conn, tableName);
            List<Get> getList = new ArrayList<>();
            List<EdcsWaybillContentSwsKafka> tempList = new ArrayList<>();

            while (itr.hasNext()) {
                EdcsWaybillContentSwsKafka o = itr.next();
                tempList.add(o);
                String rowKey = HbaseUtil.getKeyStr("taa" + "_" + o.getWaybillnoOrderNo(), 100);
                getList.add(HbaseUtil.getGet(rowKey, family, column));
                if (getList.size() == putSize) {
                    List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                    result.addAll(service.getSrcXy(jsonList, tempList));
                    getList.clear();
                    tempList.clear();
                }
            }
            if (!getList.isEmpty()) {
                List<JSONObject> jsonList = HbaseUtil.getByKeys2(table, getList, family, column);
                result.addAll(service.getSrcXy(jsonList, tempList));
                getList.clear();
                tempList.clear();
            }
            return result.iterator();
        }).union(aoiId54TimeNoScheduleEmpAoiEventXyRdd.filter(o -> StringUtils.isEmpty(o.getWaybillnoOrderNo()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54TimeNoScheduleEmpAoiSrcXyRdd cnt:{}", aoiId54TimeNoScheduleEmpAoiSrcXyRdd.count());
        aoiId54TimeNoScheduleEmpAoiEventXyRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleRdd = aoiId54TimeNoScheduleEmpAoiSrcXyRdd.map(o -> {
            String original_zone_code = o.getOriginal_zone_code();
            String eventlng = o.getEventlng();
            String eventlat = o.getEventlat();
            String event_aoiAndzc = "";

            String src_lgt = o.getSrc_lgt();
            String src_lat = o.getSrc_lat();
            String src_aoiAndzc = "";

            if (StringUtils.isNotEmpty(eventlng) && StringUtils.isNotEmpty(eventlat)) {
                event_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, eventlng, eventlat);
            }
            if (StringUtils.isNotEmpty(src_lgt) && StringUtils.isNotEmpty(src_lat)) {
                src_aoiAndzc = service.getAoiByXy(getAoiByXyUrl, src_lgt, src_lat);
            }
            if (StringUtils.isNotEmpty(original_zone_code) && StringUtils.isNotEmpty(event_aoiAndzc) && StringUtils.isNotEmpty(src_aoiAndzc) && event_aoiAndzc.split(",").length == 2 && src_aoiAndzc.split(",").length == 2
                    && StringUtils.equals(event_aoiAndzc.split(",")[0], src_aoiAndzc.split(",")[0]) && StringUtils.equals(event_aoiAndzc.split(",")[1], original_zone_code)) {
                o.setLastAoiid(event_aoiAndzc.split(",")[0]);
                o.setTag("aoi_id_54_coord_no_schedule");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleRdd cnt:{}", aoiId54CoordNoScheduleRdd.count());
        aoiId54TimeNoScheduleEmpAoiSrcXyRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleAoiRdd = aoiId54CoordNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleEmpAoiRdd = aoiId54CoordNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleAoiRdd cnt:{}", aoiId54CoordNoScheduleAoiRdd.count());
        logger.error("aoiId54CoordNoScheduleEmpAoiRdd cnt:{}", aoiId54CoordNoScheduleEmpAoiRdd.count());
        aoiId54CoordNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd9 = rdd8.union(aoiId54CoordNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd9 cnt:{}", rdd9.count());
        rdd8.unpersist();
        aoiId54CoordNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd = service.joinPositionName(aoiId54CoordNoScheduleEmpAoiRdd, tmDepartmentRdd, empInfoDtlDfRdd, emapLayerFeatureCmsemapRdd, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd cnt:{}", aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd.count());
        aoiId54CoordNoScheduleEmpAoiRdd.unpersist();
        tmDepartmentRdd.unpersist();
        emapLayerFeatureCmsemapRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleRdd = service.joinZnocodeToAoi(aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd, znocodeToAoiRdd, getAoiByXyUrl, "sj").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransNoScheduleRdd cnt:{}", zcAndTransNoScheduleRdd.count());
        aoiId54CoordNoScheduleEmpAoiRddSupPositionNameRdd.unpersist();
        znocodeToAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleAoiRdd = zcAndTransNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> zcAndTransNoScheduleEmpAoiRdd = zcAndTransNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcAndTransNoScheduleAoiRdd cnt:{}", zcAndTransNoScheduleAoiRdd.count());
        logger.error("zcAndTransNoScheduleEmpAoiRdd cnt:{}", zcAndTransNoScheduleEmpAoiRdd.count());
        zcAndTransNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd10 = rdd9.union(zcAndTransNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd10 cnt:{}", rdd10.count());
        rdd9.unpersist();
        zcAndTransNoScheduleAoiRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleRdd = zcAndTransNoScheduleEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(orderWaybillHookRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey())
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    String addr = o.getAddr();
                    String original_zone_code = o.getOriginal_zone_code();
                    if (StringUtils.isNotEmpty(addr)) {
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<OrderWaybillHook> list = Lists.newArrayList(tp._2._2.get()).stream()
                                    .filter(t -> StringUtils.isNotEmpty(t.getAoi_zc()) && StringUtils.equals(t.getAoi_zc(), original_zone_code))
                                    .collect(Collectors.toList());
                            String last_aoi = "";
                            for (OrderWaybillHook orderWaybillHook : list) {
                                String aoi_name = orderWaybillHook.getAoi_name();
                                if (StringUtils.isNotEmpty(aoi_name) && addr.contains(aoi_name)) {
                                    last_aoi = orderWaybillHook.getAoi_id();
                                    break;
                                }
                            }
                            if (StringUtils.isNotEmpty(last_aoi)) {
                                o.setLastAoiid(last_aoi);
                                o.setTag("similar_no_schedule");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarNoScheduleRdd cnt:{}", similarNoScheduleRdd.count());
        zcAndTransNoScheduleEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleAoiRdd = similarNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> similarNoScheduleEmpAoiRdd = similarNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarNoScheduleAoiRdd cnt:{}", similarNoScheduleAoiRdd.count());
        logger.error("similarNoScheduleEmpAoiRdd cnt:{}", similarNoScheduleEmpAoiRdd.count());
        similarNoScheduleRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleRdd = similarNoScheduleEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(orderWaybillHookRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey(), SysConstant.PARTITION_COUNT)
                .mapPartitions(itr -> {
                    List<EdcsWaybillContentSwsKafka> result = new ArrayList<>();
                    while (itr.hasNext()) {
                        Tuple2<String, Tuple2<EdcsWaybillContentSwsKafka, Optional<Iterable<OrderWaybillHook>>>> tp = itr.next();
                        EdcsWaybillContentSwsKafka o = tp._2._1;
                        String original_zone_code = o.getOriginal_zone_code();
                        String addr = o.getAddr();
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<OrderWaybillHook> list = Lists.newArrayList(tp._2._2.get()).stream()
                                    .filter(t -> StringUtils.isNotEmpty(t.getAoi_zc()) && StringUtils.equals(t.getAoi_zc(), original_zone_code))
                                    .collect(Collectors.toList());
                            String last_aoi = "";
                            if (StringUtils.isNotEmpty(addr)) {
                                List<OrderWaybillHook> aoiNameList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_name()))
                                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getAoi_name))), ArrayList::new));
                                for (OrderWaybillHook orderWaybillHook : aoiNameList) {
                                    String aoi_name = orderWaybillHook.getAoi_name();
                                    double similarity = KeyWordUtil.similarity(addr, aoi_name);
                                    orderWaybillHook.setSimilarity(similarity + "");
                                }
                                List<OrderWaybillHook> sortList = aoiNameList.stream()
                                        .filter(t -> StringUtils.isNotEmpty(t.getSimilarity()) && Double.parseDouble(t.getSimilarity()) > 0.7)
                                        .sorted((o1, o2) -> o2.getSimilarity().compareTo(o1.getSimilarity()))
                                        .collect(Collectors.toList());
                                if (sortList.size() > 0) {
                                    OrderWaybillHook orderWaybillHook = sortList.get(0);
                                    last_aoi = orderWaybillHook.getAoi_id();
                                    if (StringUtils.isNotEmpty(last_aoi)) {
                                        o.setLastAoiid(last_aoi);
                                        o.setTag("similar_no_schedule");
                                    }
                                }
                            }
                            if (StringUtils.isEmpty(last_aoi)) {
                                ArrayList<OrderWaybillHook> uniqueList = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getAoi_id))), ArrayList::new));
                                if (uniqueList.size() == 1) {
                                    String aoi_id = uniqueList.get(0).getAoi_id();
                                    o.setLastAoiid(aoi_id);
                                    o.setTag("aoi_id_unique_no_schedule");
                                } else if (uniqueList.size() > 1) {
                                    ArrayList<OrderWaybillHook> jitiList = uniqueList.stream().filter(t -> StringUtils.isNotEmpty(t.getPick_jiti()))
                                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OrderWaybillHook::getPick_jiti))), ArrayList::new));
                                    if (jitiList.size() == 1) {
                                        String aoi_id = jitiList.get(0).getAoi_id();
                                        o.setLastAoiid(aoi_id);
                                        o.setTag("aoi_id_random_no_schedule");
                                    } else if (jitiList.size() > 1) {
                                        List<OrderWaybillHook> aoiCountList = uniqueList.stream().filter(t -> StringUtils.isNotEmpty(t.getAoi_count()))
                                                .sorted((o1, o2) -> o2.compareTo(o1))
                                                .collect(Collectors.toList());
                                        if (aoiCountList.size() > 0) {
                                            String aoi_id = aoiCountList.get(0).getAoi_id();
                                            o.setLastAoiid(aoi_id);
                                            o.setTag("aoi_id_stat_no_schedule");
                                        }
                                    }
                                }
                            }
                        }
                        result.add(o);
                    }
                    return result.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatNoScheduleRdd cnt:{}", aoiIdStatNoScheduleRdd.count());
        similarNoScheduleEmpAoiRdd.unpersist();
        orderWaybillHookRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleAoiRdd = aoiIdStatNoScheduleRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdStatNoScheduleEmpAoiRdd = aoiIdStatNoScheduleRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdStatNoScheduleAoiRdd cnt:{}", aoiIdStatNoScheduleAoiRdd.count());
        logger.error("aoiIdStatNoScheduleEmpAoiRdd cnt:{}", aoiIdStatNoScheduleEmpAoiRdd.count());
        aoiIdStatNoScheduleRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd11 = rdd10.union(similarNoScheduleAoiRdd).union(aoiIdStatNoScheduleAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd11 cnt:{}", rdd11.count());
        rdd10.unpersist();
        similarNoScheduleAoiRdd.unpersist();
        aoiIdStatNoScheduleAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> empAoiRdd = aoiIdUniqueEmpAoiRdd.union(aoiIdStatEmpAoiRdd).union(aoiIdStatNoScheduleEmpAoiRdd)
                .map(o -> {
                    o.setTag("no_sj_no_pj");
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
        aoiIdUniqueEmpAoiRdd.unpersist();
        aoiIdStatEmpAoiRdd.unpersist();
        aoiIdStatNoScheduleEmpAoiRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> empAoiExtsRdd = empAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(extsRdd.mapToPair(o -> new Tuple2<>(o.getMainwaybillno(), o))).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                FvpCoreFactRouteRt fvpCoreFactRouteRt = tp._2._2.get();
                o.setExts(fvpCoreFactRouteRt.getExts());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empAoiExtsRdd cnt:{}", empAoiExtsRdd.count());
        empAoiRdd.unpersist();
        extsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> ext24And25Rdd = empAoiExtsRdd.map(o -> {
            String exts = o.getExts();
            if (StringUtils.isNotEmpty(exts)) {
                String[] split = exts.replaceAll("\\{|\\}", "").split(",");
                String ext24 = "";
                String ext25 = "";
                for (String ext : split) {
                    if (StringUtils.isNotEmpty(ext)) {
                        String[] split1 = ext.split("=");
                        if (split1.length >= 2) {
                            String s = split1[0].replaceAll(" ", "");
                            if (StringUtils.equals(s, "ext24")) {
                                ext24 = split1[1];
                            }
                            if (StringUtils.equals(s, "ext25")) {
                                ext25 = split1[1];
                            }
                        }
                    }
                }
                o.setExt24(ext24);
                o.setExt25(ext25);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ext24And25Rdd cnt:{}", ext24And25Rdd.count());
        empAoiExtsRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordRdd = ext24And25Rdd.filter(o -> StringUtils.isNotEmpty(o.getExt24())).map(o -> {
            String ext24 = o.getExt24();
            String[] splits = ext24.split("\\|");
            if (splits.length >= 2) {
                String x = splits[0];
                String y = splits[1];
                if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                    String aoiAndzc = service.getAoiByXy(getAoiByXyUrl, x, y);
                    if (StringUtils.isNotEmpty(aoiAndzc) && aoiAndzc.split(",").length > 0) {
                        String aoi = aoiAndzc.split(",")[0];
                        if (StringUtils.isNotEmpty(aoi)) {
                            o.setLastAoiid(aoi);
                            o.setTag("aoi_id_36_coord");
                        }
                    }
                }
            }
            return o;
        }).union(ext24And25Rdd.filter(o -> StringUtils.isEmpty(o.getExt24()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordRdd cnt:{}", aoiId36CoordRdd.count());
        ext24And25Rdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordAoiRdd = aoiId36CoordRdd.filter(o -> StringUtils.isNotEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> aoiId36CoordEmpAoiRdd = aoiId36CoordRdd.filter(o -> StringUtils.isEmpty(o.getLastAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiId36CoordAoiRdd cnt:{}", aoiId36CoordAoiRdd.count());
        logger.error("aoiId36CoordEmpAoiRdd cnt:{}", aoiId36CoordEmpAoiRdd.count());
        aoiId36CoordRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> rdd12 = rdd11.union(aoiId36CoordAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd12 cnt:{}", rdd12.count());
        rdd11.unpersist();
        aoiId36CoordAoiRdd.unpersist();

        JavaRDD<TmDepartment> tmDepartmentWageLevelRdd = service.loadTmDepartmentWageLevel(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tmDepartmentWageLevelRdd cnt:{}", tmDepartmentWageLevelRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafka> aoiIdDoudiZcRdd = aoiId36CoordEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o))
                .leftOuterJoin(empInfoDtlDfRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        EmpInfoDtlDf empInfoDtlDf = tp._2._2.get();
                        o.setPosition_name(empInfoDtlDf.getPosition_name());
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getOriginal_zone_code(), o))
                .leftOuterJoin(tmDepartmentWageLevelRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TmDepartment tmDepartment = tp._2._2.get();
                        String position_name = o.getPosition_name();
                        if (StringUtils.isNotEmpty(position_name) && position_name.contains("收派")) {
                            String pick_wage_aoi_id = tmDepartment.getPick_wage_aoi_id();
                            if (StringUtils.isNotEmpty(pick_wage_aoi_id)) {
                                o.setLastAoiid(pick_wage_aoi_id);
                                o.setTag("aoi_id_doudi_zc");
                            } else {
                                String dept_aoi_id = tmDepartment.getDept_aoi_id();
                                if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                    o.setLastAoiid(dept_aoi_id);
                                    o.setTag("aoi_id_doudi_zc");
                                }
                            }
                        } else {
                            String dept_aoi_id = tmDepartment.getDept_aoi_id();
                            if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                o.setLastAoiid(dept_aoi_id);
                                o.setTag("aoi_id_doudi_zc");
                            }
                        }
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiIdDoudiZcRdd cnt:{}", aoiIdDoudiZcRdd.count());
        aoiId36CoordEmpAoiRdd.unpersist();
        empInfoDtlDfRdd.unpersist();
        tmDepartmentWageLevelRdd.unpersist();


        JavaRDD<EdcsWaybillContentSwsKafka> lastAoiRdd = rdd12.union(aoiIdDoudiZcRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastAoiRdd cnt:{}", lastAoiRdd.count());
        rdd12.unpersist();
        aoiIdDoudiZcRdd.unpersist();

        JavaRDD<EdcsWaybillContentSwsKafka> aoiCodeRdd = lastAoiRdd.mapToPair(o -> new Tuple2<>(o.getLastAoiid(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        String aoi_code = cmsAoiSch.getAoi_code();
                        String fa_type = cmsAoiSch.getFa_type();
                        o.setAoi_code(aoi_code);
                        o.setFa_type(fa_type);
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getInitial_original_aoi_id(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        String aoi_code = cmsAoiSch.getAoi_code();
                        String fa_type = cmsAoiSch.getFa_type();

                        o.setInitial_original_aoi_code(aoi_code);
                        o.setInitial_original_fa_type(fa_type);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiCodeRdd cnt:{}", aoiCodeRdd.count());
        lastAoiRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        JavaRDD<AoiAreaAoi> aoiAreaAoiRdd = service.loadAoiAreaAoiData(sparkInfo).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaAoiRdd cnt:{}", aoiAreaAoiRdd.count());

        JavaRDD<EdcsWaybillContentSwsKafkaSjOutArea> resultRdd = aoiCodeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))
                .leftOuterJoin(aoiAreaAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        o.setAoi_area_code(aoiAreaAoi.getAoi_area_code());
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getInitial_original_aoi_code(), o))
                .leftOuterJoin(aoiAreaAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                        o.setInitial_original_aoi_area_code(aoiAreaAoi.getAoi_area_code());
                    }
                    return o;
                }).map(o -> {
                    EdcsWaybillContentSwsKafkaSjOutArea sj = new EdcsWaybillContentSwsKafkaSjOutArea();
                    sj.setOriginal_waybill_no(o.getWaybill_no());
                    sj.setOriginal_zone_code(o.getOriginal_zone_code());
                    sj.setOriginal_city_code(o.getOriginal_city_code());
                    sj.setOriginal_member_no(o.getEmp_code());
                    sj.setOriginal_tm(o.getTakeover_tm());
                    sj.setOriginal_aoi_id(o.getLastAoiid());//实际aoiid
                    sj.setOriginal_aoi_code(o.getAoi_code());
                    sj.setOriginal_aoi_area_code(o.getAoi_area_code());
                    sj.setOriginal_fa_type(o.getFa_type());
                    sj.setOriginal_tag(o.getTag());
                    sj.setDestination_zone_code(o.getDestination_zone_code());
                    sj.setDestination_city_code(o.getDestination_city_code());

                    sj.setInitial_original_aoi_id(o.getInitial_original_aoi_id());
                    sj.setInitial_original_aoi_code(o.getInitial_original_aoi_code());
                    sj.setInitial_original_aoi_area_code(o.getInitial_original_aoi_area_code());
                    sj.setInitial_original_fa_type(o.getInitial_original_fa_type());

                    sj.setInc_day(date);

                    return sj;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        aoiCodeRdd.unpersist();
        aoiAreaAoiRdd.unpersist();

        DataUtil.saveInto(spark, sc, "dm_gis.sj_aoi_out_area_sa", EdcsWaybillContentSwsKafkaSjOutArea.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
    }
}
