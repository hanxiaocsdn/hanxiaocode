package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.sds.pojo.AoiAccuracyAddrTsAoiJoinTrajShouRet;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AoiRealAccturyRateService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AoiRealAccturyRateService.class);

    public void saveData(SparkSession spark, JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> inRdd, String date, String table) {

        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybillno(), o.getCity_code(), o.getOrg_code(), o.getEventtype(), o.getUserid(), o.getOperatime_new(), o.getPick_lgt(), o.getPick_lat(), o.getInc_day_gd(), o.getReq_citycode(),
                    o.getReq_address(), o.getFinalaoicode(), o.getGj_aoiid_t(), o.getGj_aoicode_t(), o.getGj_aoiname_t(), o.getStarttime(), o.getEndtime(), o.getGjaoi_frq(), o.getInc_day_gj(), o.getTag1(),
                    o.getTag2(), o.getR_aoi(), o.getGisaoicode_rds(), o.getKsaoicode(), o.getSrc_order_no(), o.getIsnotundercall(), o.getSyssource(), o.getReq_comp_name(), o.getFinalzc(), o.getSrc(),
                    o.getKs_aoi_src(), o.getZonecode(), o.getBaroprcode(), o.getOpcode(), o.getBarscantmstd(), o.getCouriercode(), o.getFinalaoiid(), o.getGroupid(), o.getExtra(), o.getSplit_info(),
                    o.getLast13(), o.getLast14(), o.getLast613(), o.getKey_level(), o.getKey_word(), o.getKey_tag(), o.getAoi_id_54(), o.getAoi_code_54(), o.getAoi_name_54(), o.getGis_aoi_code(),
                    o.getGis_aoi_name(), o.getGis_aoi_splitinfo(), o.getAoi_splitinfo_54(), o.getMapa_aoiid(), o.getMapa_aoicode(), o.getMapa_aoiname(), o.getGd_aoiid(), o.getGd_aoicode(), o.getGd_aoiname(), o.getGj_aoicode_else(),
                    o.getGj_aoiname_else(), o.getGj_aoiid_else(), o.getGd_start_1(), o.getGd_end_1(), o.getMin_aoi_list_1(), o.getGd_start_2(), o.getGd_end_2(), o.getMin_aoi_list_2(), o.getMin_aoi_gj(),
                    o.getPlan_aoi_code_list(), o.getIsforward(), o.getTime_dur()

            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybillno", "city_code", "org_code", "eventtype", "userid", "operatime_new", "pick_lgt", "pick_lat", "inc_day_gd", "req_citycode",
                "req_address", "finalaoicode", "gj_aoiid_t", "gj_aoicode_t", "gj_aoiname_t", "starttime", "endtime", "gjaoi_frq", "inc_day_gj", "tag1",
                "tag2", "r_aoi", "gisaoicode_rds", "ksaoicode", "src_order_no", "isnotundercall", "syssource", "req_comp_name", "finalzc", "src",
                "ks_aoi_src", "zonecode", "baroprcode", "opcode", "barscantmstd", "couriercode", "finalaoiid", "groupid", "extra", "split_info",
                "last13", "last14", "last613", "key_level", "key_word", "key_tag", "54_aoi_id", "54_aoi_code", "54_aoi_name", "gis_aoi_code",
                "gis_aoi_name", "gis_aoi_splitinfo", "54_aoi_splitinfo", "mapa_aoiid", "mapa_aoicode", "mapa_aoiname", "gd_aoiid", "gd_aoicode", "gd_aoiname", "gj_aoicode_else",
                "gj_aoiname_else", "gj_aoiid_else", "gd_start_1", "gd_end_1", "1_min_aoi_list", "gd_start_2", "gd_end_2", "2_min_aoi_list", "min_aoi_gj",
                "plan_aoi_code_list", "isforward", "time_dur"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_accuracy_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", table, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

}
