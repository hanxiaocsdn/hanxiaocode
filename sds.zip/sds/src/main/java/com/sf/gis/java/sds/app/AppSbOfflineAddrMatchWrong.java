package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SbOfflineAddrMatchWrongController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 需求：【B库质量提升】审补下线地址匹配错误工艺
 * 需求方：谭雨祯（01425216）
 * 研发：匡仁衡（01399581）
 * 任务id：856（新平台）
 */
public class AppSbOfflineAddrMatchWrong {
    private static Logger logger = LoggerFactory.getLogger(AppSbOfflineAddrMatchWrong.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new SbOfflineAddrMatchWrongController().start(date);
        logger.error("run end");
    }
}
