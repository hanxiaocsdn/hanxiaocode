package com.sf.gis.java.sds.pojo;


public class GisToAddrStat {
    private String waybillno;
    private String id;
    private String norm_address;
    private String sss_deptcode;
    private String deptcode;
    private String his_teamcode;
    private String inc_day;
    private String citycode;
    private String count;
    private String zonecode;
    private String xiaoge_deptcode;
    private String xiaoge_no;
    private String logteamcode;
    private String req_province;
    private String req_city;
    private String req_area;
    private String req_comp_name;

    public GisToAddrStat() {
    }

    public GisToAddrStat(String waybillno, String id, String norm_address, String sss_deptcode, String deptcode,
                         String his_teamcode, String inc_day, String citycode, String count, String zonecode,
                         String xiaoge_deptcode, String xiaoge_no, String logteamcode, String req_province, String req_city,
                         String req_area, String req_comp_name) {
        this.waybillno = waybillno;
        this.id = id;
        this.norm_address = norm_address;
        this.sss_deptcode = sss_deptcode;
        this.deptcode = deptcode;
        this.his_teamcode = his_teamcode;
        this.inc_day = inc_day;
        this.citycode = citycode;
        this.count = count;
        this.zonecode = zonecode;
        this.xiaoge_deptcode = xiaoge_deptcode;
        this.xiaoge_no = xiaoge_no;
        this.logteamcode = "null".equals(logteamcode) ? "" : logteamcode;
        this.req_province = req_province;
        this.req_city = req_city;
        this.req_area = req_area;
        this.req_comp_name = req_comp_name;
    }

    public String getReq_province() {
        return req_province;
    }

    public void setReq_province(String req_province) {
        this.req_province = req_province;
    }

    public String getReq_city() {
        return req_city;
    }

    public void setReq_city(String req_city) {
        this.req_city = req_city;
    }

    public String getReq_area() {
        return req_area;
    }

    public void setReq_area(String req_area) {
        this.req_area = req_area;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getLogteamcode() {
        return logteamcode;
    }

    public void setLogteamcode(String logteamcode) {
        this.logteamcode = logteamcode;
    }

    public String getXiaoge_no() {
        return xiaoge_no;
    }

    public void setXiaoge_no(String xiaoge_no) {
        this.xiaoge_no = xiaoge_no;
    }

    public String getXiaoge_deptcode() {
        return xiaoge_deptcode;
    }

    public void setXiaoge_deptcode(String xiaoge_deptcode) {
        this.xiaoge_deptcode = xiaoge_deptcode;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNorm_address() {
        return norm_address;
    }

    public void setNorm_address(String norm_address) {
        this.norm_address = norm_address;
    }

    public String getSss_deptcode() {
        return sss_deptcode;
    }

    public void setSss_deptcode(String sss_deptcode) {
        this.sss_deptcode = sss_deptcode;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getHis_teamcode() {
        return his_teamcode;
    }

    public void setHis_teamcode(String his_teamcode) {
        this.his_teamcode = his_teamcode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

}