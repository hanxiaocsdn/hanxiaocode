package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SssDwdWaybillInfoDtlDi implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "consignee_phone")
    private String consignee_phone;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "deliver_emp_code")
    private String deliver_emp_code;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "dept_type_code")
    private String dept_type_code;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "opcode")
    private String opcode;

    private String new_splitresult;

    public String getNew_splitresult() {
        return new_splitresult;
    }

    public void setNew_splitresult(String new_splitresult) {
        this.new_splitresult = new_splitresult;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getConsignee_phone() {
        return consignee_phone;
    }

    public void setConsignee_phone(String consignee_phone) {
        this.consignee_phone = consignee_phone;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getDeliver_emp_code() {
        return deliver_emp_code;
    }

    public void setDeliver_emp_code(String deliver_emp_code) {
        this.deliver_emp_code = deliver_emp_code;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getDept_type_code() {
        return dept_type_code;
    }

    public void setDept_type_code(String dept_type_code) {
        this.dept_type_code = dept_type_code;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }
}
