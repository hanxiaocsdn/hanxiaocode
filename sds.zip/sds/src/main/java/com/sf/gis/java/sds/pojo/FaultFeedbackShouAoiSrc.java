package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class FaultFeedbackShouAoiSrc implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "src_order_no")
    private String src_order_no;
    @Column(name = "customeraccount")
    private String customeraccount;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "req_address")
    private String req_address;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "src")
    private String src;
    @Column(name = "fault_reason")
    private String fault_reason;
    @Column(name = "create_time")
    private String create_time;
    @Column(name = "create_by")
    private String create_by;
    @Column(name = "data_date")
    private String data_date;
    @Column(name = "aoisrc")
    private String aoisrc;
    @Column(name = "mobile")
    private String mobile;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSrc_order_no() {
        return src_order_no;
    }

    public void setSrc_order_no(String src_order_no) {
        this.src_order_no = src_order_no;
    }

    public String getCustomeraccount() {
        return customeraccount;
    }

    public void setCustomeraccount(String customeraccount) {
        this.customeraccount = customeraccount;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getReq_address() {
        return req_address;
    }

    public void setReq_address(String req_address) {
        this.req_address = req_address;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getFault_reason() {
        return fault_reason;
    }

    public void setFault_reason(String fault_reason) {
        this.fault_reason = fault_reason;
    }

    public String getCreate_time() {
        return create_time;
    }

    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getCreate_by() {
        return create_by;
    }

    public void setCreate_by(String create_by) {
        this.create_by = create_by;
    }

    public String getData_date() {
        return data_date;
    }

    public void setData_date(String data_date) {
        this.data_date = data_date;
    }

    public String getAoisrc() {
        return aoisrc;
    }

    public void setAoisrc(String aoisrc) {
        this.aoisrc = aoisrc;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
