package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.Addr4Ho;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * 地址服务
 *
 * @author 01370539 Created On: May.27 2021
 */
public class AddrService {
    private final Logger logger = LoggerFactory.getLogger(AddrService.class);

    /**
     * 获取标杆库数据
     *
     * @param ss       SparkSession
     * @param jsc      JavaSparkContext
     * @param statDate 统计日期
     * @param city     城市编码
     * @return 标杆库数据
     */
    public JavaRDD<Addr4Ho> loadBgLib(SparkSession ss, JavaSparkContext jsc, String statDate, String city) {
        String sql = SqlUtil.getSqlStr("bg_lib.sql", statDate, city);
        return DataUtil.loadData(ss, jsc, sql, Addr4Ho.class);
    }

    /**
     * 获取城市网点信息
     *
     * @param conn      Connection
     * @param cityCode 城市编码
     * @return 城市网点信息
     */
    public JavaRDD<String> loadZc(JavaSparkContext jsc, Connection conn, String cityCode) {
        String sql = "select zno_code from st_department where city_code='" + cityCode + "'";
        List<String> result = new ArrayList<>();
        try {
            ResultSet rs = conn.prepareStatement(sql).executeQuery();
            while (rs.next()) {
                result.add(rs.getString(1));
            }
            rs.close();
            conn.close();
        }catch (Exception e) {
            logger.error("loadZc execute error. ", e);
        }
        logger.error("zc count: {}", result.size());
        return jsc.parallelize(result);
    }
}
