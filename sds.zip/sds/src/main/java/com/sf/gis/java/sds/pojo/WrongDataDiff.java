package com.sf.gis.java.sds.pojo;


import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.MD5Util;
import com.sf.gis.java.sds.bean.DeptData;

import javax.persistence.Column;

public class WrongDataDiff {
    @Column(name = "id")
    private String id;
    @Column(name = "is_done")
    private Integer isDone;
    @Column(name = "address")
    private String address;
    @Column(name = "unique_md5")
    private String uniqueMd5;
    @Column(name = "sss_dept")
    private String sssDept;
    @Column(name = "gis_dept")
    private String gisDept;
    @Column(name = "origin_src")
    private String originSrc;
    @Column(name = "data_time")
    private String dataTime;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "frequency")
    private Integer frequency;
    @Column(name = "waybillNo")
    private String waybillNo;
    @Column(name = "type")
    private String type;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "arssDeptCode")
    private String arssDeptCode;

    public WrongDataDiff(DeptData x, String dataTime) {
        this.isDone = 0;
        this.frequency = 1;
        this.address = x.getReq_address();
        this.originSrc = x.getSrc();
        JSONObject jobject = new JSONObject();
        jobject.put("address", address);
        jobject.put("origin_src", originSrc);
        this.uniqueMd5 = MD5Util.getMD5(jobject.toJSONString());
        ;
        this.sssDept = x.getSssDept();
        this.gisDept = x.getGisDept();
        this.dataTime = dataTime;
        this.city_code = x.getCityCode();
        this.waybillNo = x.getReq_billno();
        this.arssDeptCode = x.getSbDept();
        if (x.isSb()) {
            this.type = "1";
            this.deptcode = x.getSbAddress();
        } else if (x.isUseGis()) {
            this.type = "2";
            this.deptcode = x.getGisDept();
        } else if (x.isUseSss()) {
            this.type = "3";
            this.deptcode = x.getSssDept();
        } else {
            this.type = "4";
            this.deptcode = "";
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getIsDone() {
        return isDone;
    }

    public void setIsDone(Integer isDone) {
        this.isDone = isDone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUniqueMd5() {
        return uniqueMd5;
    }

    public void setUniqueMd5(String uniqueMd5) {
        this.uniqueMd5 = uniqueMd5;
    }

    public String getSssDept() {
        return sssDept;
    }

    public void setSssDept(String sssDept) {
        this.sssDept = sssDept;
    }

    public String getGisDept() {
        return gisDept;
    }

    public void setGisDept(String gisDept) {
        this.gisDept = gisDept;
    }

    public String getOriginSrc() {
        return originSrc;
    }

    public void setOriginSrc(String originSrc) {
        this.originSrc = originSrc;
    }

    public String getDataTime() {
        return dataTime;
    }

    public void setDataTime(String dataTime) {
        this.dataTime = dataTime;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public Integer getFrequency() {
        return frequency;
    }

    public void setFrequency(Integer frequency) {
        this.frequency = frequency;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getArssDeptCode() {
        return arssDeptCode;
    }

    public void setArssDeptCode(String arssDeptCode) {
        this.arssDeptCode = arssDeptCode;
    }

}