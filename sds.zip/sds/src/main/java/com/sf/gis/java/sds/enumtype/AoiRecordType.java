package com.sf.gis.java.sds.enumtype;

public enum AoiRecordType {
    add, //新增数据
    change //变更数据
}
