package com.sf.gis.java.sds.appoms;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-11-13 17:12
 * @TaskId:
 * @TaskName:
 * @Description:
 */

import java.io.IOException;
import java.util.Map;

import com.sf.gis.java.sds.controller.PullOmsDataController;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:225221
 * 任务名称：每日工单
 * 开发：张想远
 * 业务：何华众
 */
public class Main {
    private static final Logger logger = LoggerFactory.getLogger(Main.class);
    public static void main(String[] args) throws IOException {
        logger.error("begin Main");
        long begin = System.currentTimeMillis();
        try {
            start(args);
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
        Map<String, String> configMap = ConfigUtil
                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");
        PullOmsDataController sssWrongDistribute = new PullOmsDataController(configMap);

        sssWrongDistribute.start();

    }

}
