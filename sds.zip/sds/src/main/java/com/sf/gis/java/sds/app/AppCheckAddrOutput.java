package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.CheckAddrOutput;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class AppCheckAddrOutput {
    private static final Logger logger = LoggerFactory.getLogger(AppCheckAddrOutput.class);
    private static String diffurl = "http://gis-apis.int.sfcloud.local:1080/diff/api/ce?address=%s&citycode=%s&ak=9c1d529c40f54877a9a6372e686fee47&show=1";
    private static String spliturl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=e9106d80834e483189c3439938bac5d2&address=%s&city=%s&opt=zh";
    private static String account = "01399581";
    private static String taskId = "632108";
    private static String taskName = "自动化每月定时聚合冷运未识别地址";

    /**
     * 需求：【特殊入仓】自动化每月定时聚合冷运未识别地址
     * 需求:谭雨祯(01425216)
     * 研发：匡仁衡（01399581）
     * 任务id:632108
     */
    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        String date = args[2];
        logger.error("date1:{},date2:{}", date1, date2);
        logger.error("process date:{}", date);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppCheckAddrOutput");

        JavaRDD<CheckAddrOutput> rdd = loadData(sparkInfo.getSession(), sparkInfo.getContext(), date1, date2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<CheckAddrOutput> uniqueWaybillRdd = rdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueWaybillRdd cnt:{}", uniqueWaybillRdd.count());
        rdd.unpersist();

        JavaRDD<CheckAddrOutput> fullAddrRdd = uniqueWaybillRdd.map(o -> {
            String receiver_province_name = o.getReceiver_province_name();
            String receiver_city_name = o.getReceiver_city_name();
            String receiver_area_name = o.getReceiver_area_name();
            String address = o.getAddress();
            String receiver_company = o.getReceiver_company();
            String receiver_name = o.getReceiver_name();

            o.setFulladdress(receiver_province_name + receiver_city_name + receiver_area_name + address);
            o.setFulladdress_r(receiver_province_name + receiver_city_name + receiver_area_name + address + receiver_company + receiver_name);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fullAddrRdd cnt:{}", fullAddrRdd.count());
        fullAddrRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        uniqueWaybillRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", diffurl, "9c1d529c40f54877a9a6372e686fee47", fullAddrRdd.count(), 40);
        JavaRDD<CheckAddrOutput> diffRdd = fullAddrRdd.map(o -> {
            String fulladdress_r = o.getFulladdress_r();
            String receiver_city_number = o.getReceiver_city_number();
            if (StringUtils.isNotEmpty(fulladdress_r)) {
                String req = String.format(diffurl, URLEncoder.encode(fulladdress_r, "UTF-8"), receiver_city_number);
                String content = HttpInvokeUtil.sendGet(req);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        int status = jsonObject.getInteger("status");
                        o.setStatus(status);
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("diffRdd cnt:{}", diffRdd.count());
        fullAddrRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        JavaRDD<CheckAddrOutput> noDistinguishRdd = diffRdd.filter(o -> o.getStatus() == 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noDistinguishRdd cnt:{}", noDistinguishRdd.count());
        diffRdd.unpersist();

        JavaRDD<CheckAddrOutput> addrWsbFreqRdd = noDistinguishRdd.mapToPair(o -> new Tuple2<>(o.getFulladdress(), o)).groupByKey().map(tp -> {
            List<CheckAddrOutput> list = Lists.newArrayList(tp._2);
            int size = list.size();
            CheckAddrOutput o = list.get(0);
            o.setAddr_wsbfreq(size + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrWsbFreqRdd cnt:{}", addrWsbFreqRdd.count());
        noDistinguishRdd.unpersist();

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", spliturl, "e9106d80834e483189c3439938bac5d2", addrWsbFreqRdd.count(), 40);
        JavaRDD<CheckAddrOutput> splitResultRdd = addrWsbFreqRdd.map(o -> {
            String addr = o.getFulladdress();
            String receiver_city_number = o.getReceiver_city_number();
            String splitResult = "";
            if (StringUtils.isNotEmpty(addr)) {
                String req = String.format(spliturl, URLEncoder.encode(addr, "UTF-8"), receiver_city_number);
                String content = HttpInvokeUtil.sendGet(req);
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        splitResult = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            o.setSplitResult(splitResult);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitResultRdd cnt:{}", splitResultRdd.count());
        addrWsbFreqRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        JavaRDD<CheckAddrOutput> joinRdd = splitResultRdd.map(o -> {
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
                String[] split1 = split.split(",");
                List<String> list = new ArrayList<>();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String level = split2[1];
                        if (!StringUtils.equals(level, "613")) {
                            list.add(level.substring(1, level.length()));
                        }
                    }
                }
                String join = list.size() > 0 ? String.join("#", list) : "";
                o.setJoin_level("#" + join);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("joinRdd cnt:{}", joinRdd.count());
        splitResultRdd.unpersist();

        JavaRDD<CheckAddrOutput> term1Rdd = joinRdd.map(o -> {
            return processJoin(o);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("term1Rdd cnt:{}", term1Rdd.count());
        joinRdd.unpersist();

        JavaRDD<CheckAddrOutput> noEqRdd = term1Rdd.filter(o -> !(StringUtils.equals(o.getType(), "4") || StringUtils.equals(o.getType(), "8") || StringUtils.equals(o.getType(), "9"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEqRdd cnt:{}", noEqRdd.count());

        JavaRDD<CheckAddrOutput> eq1or2Rdd = noEqRdd.filter(o -> StringUtils.equals(o.getType(), "1") || StringUtils.equals(o.getType(), "2")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CheckAddrOutput> noEq1or2Rdd = noEqRdd.filter(o -> !(StringUtils.equals(o.getType(), "1") || StringUtils.equals(o.getType(), "2"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Rdd cnt:{}", eq1or2Rdd.count());
        logger.error("noEq1or2Rdd cnt:{}", noEq1or2Rdd.count());
        noEqRdd.unpersist();

        JavaRDD<CheckAddrOutput> eq1or2Contains13Rdd = eq1or2Rdd.filter(o -> StringUtils.isNotEmpty(o.getJoin_level()) && o.getJoin_level().contains("#13")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CheckAddrOutput> eq1or2NoContains13Rdd = eq1or2Rdd.filter(o -> !(StringUtils.isNotEmpty(o.getJoin_level()) && o.getJoin_level().contains("#13"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Contains13Rdd cnt:{}", eq1or2Contains13Rdd.count());
        logger.error("eq1or2NoContains13Rdd cnt:{}", eq1or2NoContains13Rdd.count());
        eq1or2Rdd.unpersist();

        JavaRDD<CheckAddrOutput> eq1or2Contains13Term2Rdd = eq1or2Contains13Rdd.map(o -> {
            String term1 = o.getTerm1();
            String term2 = "";
            String splitResult = o.getSplitResult();
            String split = splitResult.split(";")[0];
            String[] split1 = split.split(",");
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                String word = split2[0];
                String level = split2[1];
                String substring = level.substring(1, level.length());
                if (!StringUtils.equals(level, "613") && StringUtils.equals(substring, "13")) {
                    term2 = term1 + word;
                    break;
                }
            }
            o.setTerm2(term2);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Contains13Term2Rdd cnt:{}", eq1or2Contains13Term2Rdd.count());
        eq1or2Contains13Rdd.unpersist();

        JavaRDD<CheckAddrOutput> eq1or2NoContains13Term2Rdd = eq1or2NoContains13Rdd.filter(o -> {
            boolean flag = false;
            String join_level = o.getJoin_level();
            if (StringUtils.isNotEmpty(join_level) && join_level.contains("#11")) {
                int index11 = join_level.indexOf("#11");
                String splitResult = o.getSplitResult();
                if (StringUtils.isNotEmpty(splitResult)) {
                    String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
                    String[] split1 = split.split(",");
                    List<String> list = new ArrayList<>();
                    for (String s : split1) {
                        String[] split2 = s.split("\\^");
                        if (split2.length >= 2) {
                            String level = split2[1];
                            if (!StringUtils.equals(level, "613")) {
                                list.add(level.substring(1, level.length()));
                            } else {
                                list.add(level);
                            }
                        }
                    }

                    String join = list.size() > 0 ? String.join("#", list) : "";
                    String temp_join_level = "#" + join;

                    if ((StringUtils.isNotEmpty(temp_join_level) && temp_join_level.contains("#613") && temp_join_level.indexOf("#613") > temp_join_level.indexOf("#11")) || (join_level.contains("#16") && join_level.indexOf("#16") > index11) || (join_level.contains("#17") && join_level.indexOf("#17") > index11)) {
                        flag = true;
                    }
                }
            }
            return flag;
        }).map(o -> {
            String term1 = o.getTerm1();
            String term2 = "";
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    String word = split2[0];
                    String level = split2[1];
                    String substring = level.substring(1, level.length());
                    if (StringUtils.equals(level, "613") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                        term2 = term1 + word;
                        break;
                    }
                }
            }
            o.setTerm2(term2);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2NoContains13Term2Rdd cnt:{}", eq1or2NoContains13Term2Rdd.count());
        eq1or2NoContains13Rdd.unpersist();

        JavaRDD<CheckAddrOutput> term3Rdd = eq1or2Contains13Term2Rdd.union(noEq1or2Rdd).map(o -> {
            String term3 = "";
            int cnt = caculate(o);
            if (cnt > 1) {
                String type = o.getType();
                if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2")) {
                    String term2 = o.getTerm2();
                    StringBuilder sb = new StringBuilder(StringUtils.isNotEmpty(term2) ? term2 : "");
                    String splitResult = o.getSplitResult();
                    if (StringUtils.isNotEmpty(splitResult)) {
                        String split = splitResult.split(";")[0];
                        String[] split1 = split.split(",");
                        for (String s : split1) {
                            String[] split2 = s.split("\\^");
                            String word = split2[0];
                            String level = split2[1];
                            String substring = level.substring(1, level.length());
                            if (StringUtils.equals(substring, "13")) {
                                if (!term2.contains(word)) {
                                    sb.append(word);
                                }
                            }
                        }
                    }
                    term3 = sb.toString();
                } else if (StringUtils.equals(type, "3") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7")) {
                    String term1 = o.getTerm1();
                    StringBuilder sb = new StringBuilder(StringUtils.isNotEmpty(term1) ? term1 : "");
                    String splitResult = o.getSplitResult();
                    if (StringUtils.isNotEmpty(splitResult)) {
                        String split = splitResult.split(";")[0];
                        String[] split1 = split.split(",");
                        for (String s : split1) {
                            String[] split2 = s.split("\\^");
                            String word = split2[0];
                            String level = split2[1];
                            String substring = level.substring(1, level.length());
                            if (StringUtils.equals(substring, "13")) {
                                if (!term1.contains(word)) {
                                    sb.append(word);
                                }
                            }
                        }
                    }
                    term3 = sb.toString();
                }
            } else {
                if (processSplit(o)) {
                    String type = o.getType();
                    if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2")) {
                        String term2 = o.getTerm2();
                        String splitResult = o.getSplitResult();
                        if (StringUtils.isNotEmpty(splitResult)) {
                            String split = splitResult.split(";")[0];
                            String[] split1 = split.split(",");
                            for (String s : split1) {
                                String[] split2 = s.split("\\^");
                                String word = split2[0];
                                String level = split2[1];
                                String substring = level.substring(1, level.length());
                                if (StringUtils.equals(substring, "14") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                                    term3 = term2 + word;
                                    break;
                                }
                            }
                        }
                    } else if (StringUtils.equals(type, "3") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7")) {
                        String term1 = o.getTerm1();
                        String splitResult = o.getSplitResult();
                        if (StringUtils.isNotEmpty(splitResult)) {
                            String split = splitResult.split(";")[0];
                            String[] split1 = split.split(",");
                            for (String s : split1) {
                                String[] split2 = s.split("\\^");
                                String word = split2[0];
                                String level = split2[1];
                                String substring = level.substring(1, level.length());
                                if (StringUtils.equals(substring, "14") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                                    term3 = term1 + word;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            o.setTerm3(term3);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("term3Rdd cnt:{}", term3Rdd.count());
        eq1or2Contains13Term2Rdd.unpersist();
        noEq1or2Rdd.unpersist();

        JavaRDD<CheckAddrOutput> termRdd = term3Rdd.union(eq1or2NoContains13Term2Rdd).union(term1Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termRdd cnt:{}", termRdd.count());
        term3Rdd.unpersist();
        eq1or2NoContains13Term2Rdd.unpersist();
        term1Rdd.unpersist();

        JavaRDD<CheckAddrOutput> areaRdd = termRdd.map(o -> {
            String splitResult = o.getSplitResult();
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) <= 3) {
                            sb.append(word);
                        }
                    }
                }
            }
            o.setArea(sb.toString());
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("areaRdd cnt:{}", areaRdd.count());
        termRdd.unpersist();

        JavaRDD<CheckAddrOutput> finalAreaRdd = areaRdd.mapToPair(o -> new Tuple2<>(o.getReceiver_city_number() + "_" + o.getTerm1(), o)).groupByKey().flatMap(tp -> {
            List<CheckAddrOutput> list = Lists.newArrayList(tp._2);
            String finalarea = "";
            List<CheckAddrOutput> filterList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getArea())).collect(Collectors.toList());
            if (filterList.size() > 0) {
                finalarea = filterList.stream()
                        .collect(Collectors.groupingBy(CheckAddrOutput::getArea))
                        .values()
                        .stream()
                        .max(Comparator.comparing(List::size))
                        .get()
                        .get(0)
                        .getArea();
            }
            String finalArea = finalarea;
            return list.stream().peek(o -> o.setFinalarea(finalArea)).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalAreaRdd cnt:{}", finalAreaRdd.count());
        areaRdd.unpersist();

        JavaRDD<CheckAddrOutput> termAddrRdd = finalAreaRdd.map(o -> {
            String type = o.getType();
            if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2") || StringUtils.equals(type, "3") || StringUtils.equals(type, "4") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7") || StringUtils.equals(type, "8")) {
                o.setTerm1_addr(o.getFinalarea() + o.getTerm1());
            } else if (StringUtils.equals(type, "9")) {
                o.setTerm1_addr(o.getTerm1());
            }

            String term2 = o.getTerm2();
            if (StringUtils.isNotEmpty(term2)) {
                o.setTerm2_addr(o.getFinalarea() + term2);
            }

            String term3 = o.getTerm3();
            if (StringUtils.isNotEmpty(term3)) {
                o.setTerm3_addr(o.getFinalarea() + term3);
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termAddrRdd cnt:{}", termAddrRdd.count());
        finalAreaRdd.unpersist();

        JavaRDD<CheckAddrOutput> termFreqRdd = termAddrRdd.mapToPair(o -> new Tuple2<>(o.getTerm1_addr(), o)).groupByKey().flatMap(tp -> {
            List<CheckAddrOutput> list = Lists.newArrayList(tp._2);
            int term1_freq = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAddr_wsbfreq())).map(o -> Integer.parseInt(o.getAddr_wsbfreq())).reduce(Integer::sum).orElse(0);
            return list.stream().peek(o -> o.setTerm1_freq(term1_freq + "")).collect(Collectors.toList()).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getTerm2_addr(), o)).groupByKey().flatMap(tp -> {
            List<CheckAddrOutput> list = Lists.newArrayList(tp._2);
            int term2_freq = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAddr_wsbfreq())).map(o -> Integer.parseInt(o.getAddr_wsbfreq())).reduce(Integer::sum).orElse(0);
            return list.stream().peek(o -> o.setTerm2_freq(term2_freq + "")).collect(Collectors.toList()).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getTerm3_addr(), o)).groupByKey().flatMap(tp -> {
            List<CheckAddrOutput> list = Lists.newArrayList(tp._2);
            int term3_freq = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAddr_wsbfreq())).map(o -> Integer.parseInt(o.getAddr_wsbfreq())).reduce(Integer::sum).orElse(0);
            return list.stream().peek(o -> o.setTerm3_freq(term3_freq + "")).collect(Collectors.toList()).iterator();
        }).map(o -> {
            String term1_addr = o.getTerm1_addr();
            String term2_addr = o.getTerm2_addr();
            String term3_addr = o.getTerm3_addr();

            if (StringUtils.isEmpty(term1_addr)) {
                o.setTerm1_freq("");
            }

            if (StringUtils.isEmpty(term2_addr)) {
                o.setTerm2_freq("");
            }

            if (StringUtils.isEmpty(term3_addr)) {
                o.setTerm3_freq("");
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termFreqRdd cnt:{}", termFreqRdd.count());
        termAddrRdd.unpersist();

        JavaRDD<CheckAddrOutput> resultRdd = termFreqRdd.mapToPair(o -> new Tuple2<>(o.getTerm1_addr() + "_" + o.getTerm2_addr() + "_" + o.getTerm3_addr(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        termFreqRdd.unpersist();

        saveData(sparkInfo.getSession(), resultRdd, date, "dm_gis.specialstorage_lengyun_verification");
        resultRdd.unpersist();

        sparkInfo.getContext().stop();
    }

    public static void saveData(SparkSession spark, JavaRDD<CheckAddrOutput> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getReceiver_website_code(), o.getReceiver_city_number(), o.getSplitResult(),
                    o.getTerm1(), o.getTerm1_addr(), o.getTerm1_freq(),
                    o.getTerm2(), o.getTerm2_addr(), o.getTerm2_freq(),
                    o.getTerm3(), o.getTerm3_addr(), o.getTerm3_freq()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{
                    "waybill", "zc", "citycode", "splitResult",
                    "term1", "term1_addr", "term1_freq",
                    "term2", "term2_addr", "term2_freq",
                    "term3", "term3_addr", "term3_freq"
            };
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "specialstorage_lengyun_verification_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", table);
            spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s') " +
                    "select * from %s", table, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }

    public static boolean processSplit(CheckAddrOutput o) {
        boolean flag1 = false;
        boolean flag2 = false;
        String splitResult = o.getSplitResult();
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
            String[] split1 = split.split(",");
            List<String> list = new ArrayList<>();
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                if (split2.length >= 2) {
                    String word = split2[0];
                    String level = split2[1];
                    String substring = level.substring(1, level.length());
                    if (!StringUtils.equals(level, "613")) {
                        list.add(substring);
                        if (StringUtils.equals(substring, "13")) {
                            if (StringUtils.isNotEmpty(word) && (word.endsWith("物流园") || word.endsWith("产业园") || word.endsWith("工业园") || word.endsWith("园区") || word.endsWith("基地"))) {
                                flag1 = true;
                            }
                        }
                    } else {
                        list.add(substring);
                    }
                }
            }
            String join = list.size() > 0 ? String.join("#", list) : "";
            String temp_join_level = "#" + join;
            if (StringUtils.isNotEmpty(temp_join_level) && temp_join_level.contains("#13")) {
                int index13 = temp_join_level.indexOf("#13");
                int index14 = temp_join_level.indexOf("#14");
                int index16 = temp_join_level.indexOf("#16");
                int index17 = temp_join_level.indexOf("#17");
                if (index14 > index13 || index16 > index13 || index17 > index13) {
                    flag2 = true;
                }
            }
        }
        return flag1 && flag2;
    }

    public static int caculate(CheckAddrOutput o) {
        String splitResult = o.getSplitResult();
        int cnt = 0;
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
            String[] split1 = split.split(",");
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                String level = split2[1];
                String substring = level.substring(1, level.length());
                if (StringUtils.equals(substring, "13")) {
                    cnt++;
                }
            }
        }
        return cnt;
    }

    public static CheckAddrOutput processJoin(CheckAddrOutput o) {
        String join_level = o.getJoin_level();
        if (StringUtils.isNotEmpty(join_level)) {
            String splitResult = o.getSplitResult();
            if (join_level.contains("#9#10#11")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag10 = 0;
                int tag11 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "10") || StringUtils.equals(substring, "11")) {
                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }
                            if (StringUtils.equals(substring, "10") && tag10 == 0) {
                                term1.append(word);
                                tag10 = tag10 + 1;
                            }
                            if (StringUtils.equals(substring, "11") && tag11 == 0) {
                                term1.append(word);
                                tag11 = tag11 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("1");
            } else if (join_level.contains("#9#11")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag11 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "11")) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "11") && tag11 == 0) {
                                term1.append(word);
                                tag11 = tag11 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("2");

            } else if (join_level.contains("#9") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("3");
            } else if (join_level.contains("#9#14")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag14 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "14")) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "14") && tag14 == 0) {
                                term1.append(word);
                                tag14 = tag14 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("4");
            } else if (join_level.contains("#6") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag6 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "6") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "6") && tag6 == 0) {
                                term1.append(word);
                                tag6 = tag6 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("5");
            } else if (join_level.contains("#5") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag5 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "5") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "5") && tag5 == 0) {
                                term1.append(word);
                                tag5 = tag5 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("6");
            } else if (join_level.contains("#13")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && StringUtils.equals(substring, "13")) {

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("7");
            } else if (join_level.contains("#9")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) >= 9) {
                            term1.append(word);
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("8");
            } else if (join_level.contains("#11") || join_level.contains("#12") || join_level.contains("#13") || join_level.contains("#14") || join_level.contains("#15") || join_level.contains("#16") || join_level.contains("#17") || join_level.contains("#18")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring)) {
                            term1.append(word);
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("9");
            }
        }
        return o;
    }

    public static String sortSplitResult(String splitResult) {
        String sortSplit = "";
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
            List<String> collect = Arrays.stream(split.split(",")).sorted((o1, o2) -> {
                String level1 = o1.split("\\^")[1];
                String level2 = o2.split("\\^")[1];

                String substring1 = level1.substring(1, level1.length());
                String substring2 = level2.substring(1, level2.length());
                int code = 0;
                if (Integer.parseInt(substring1) < Integer.parseInt(substring2)) {
                    code = -1;
                } else if (Integer.parseInt(substring1) > Integer.parseInt(substring2)) {
                    code = 1;
                }
                return code;
            }).collect(Collectors.toList());
            sortSplit = String.join(",", collect);
        }
        return sortSplit;
    }

    public static JavaRDD<CheckAddrOutput> loadData(SparkSession spark, JavaSparkContext sc, String date1, String date2) {
        spark.sql("add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar");
        spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01399581/sfdencrpt.ini");
        spark.sql("create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt'");
        String sql = String.format("select\n" +
                "  waybill_no,\n" +
                "  receiver_city_number,\n" +
                "  receiver_website_code,\n" +
                "  receiver_province_name,\n" +
                "  receiver_city_name,\n" +
                "  receiver_area_name,\n" +
                "  receiver_company,\n" +
                "  receiver_name,\n" +
                "  regexp_replace(new_decrypt(receiver_detail_address),'[\\r\\n\\t]+','') as address\n" +
                "from\n" +
                "  ods_scs_oms2order.t_order\n" +
                "where\n" +
                "  inc_day between '%s' and '%s'\n" +
                "  and is_special_warehousing = 'Y'", date1, date2);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CheckAddrOutput.class);
    }
}
