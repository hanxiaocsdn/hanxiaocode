package com.sf.gis.java.sds.appaoihook;

import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import com.sf.gis.java.sds.controller.SyncWaybillAoiDataToProjectController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
/**
 * Created by 01374443 on 2018/10/24.
 * 任务id:225152/225153
 * 业务：01369702 蓝媛青
 * 描述：给智域项目其他部门提供挂接数据
 */

public class MainSyncWaybillDataToProject {
    private static final Logger logger = LoggerFactory.getLogger(MainSyncWaybillDataToProject.class);

    public static void main(String[] args) throws Exception {
        logger.error("begin Main");
        long begin = System.currentTimeMillis();
        start(args);

        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
//        Map<String, String> configMap = ConfigUtil
//                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");

        SyncWaybillAoiDataToProjectController sssWrongDistribute = new SyncWaybillAoiDataToProjectController();

        String beginDate = args[0];
//        int days = Integer.valueOf(args[1]);
        String dataType=args[1];
        //目前都是全量传递
        String syncCityStr="";
        //"zhiyu"
        String projectType="zhiyu";
        sssWrongDistribute.start(beginDate, dataType,syncCityStr,projectType);
    }
}
