package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoieletaskResult;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class AddrEleInfoToBaseController {
    private static Logger logger = LoggerFactory.getLogger(AddrEleInfoToBaseController.class);
    private static String queryElevatorUrl = "http://gis-gw.int.sfdc.com.cn:9080/elevator/api/queryElevator";
    private static String ak = "a9e526f45b2a4243af103128f19a3889";
    private static String getAddrByCityCodeAndAddrUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s";
    private static String splitUrl = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=3eb300d2e06947f7945cd02530a32fd2";
    private static String tokenUrl = "http://orion-gateway.sf-express.com/uac/oauth/token?grant_type=password&username=01412989&password=2989@Bdp";
    private static String tuthorization = "Basic R0lTLUFTUy1BT1MtQkRQLUVMRVY6YW9zQmRwRWxldiMyMDIy";
    private static String insert = "https://gis-orion-work.sf-express.com/work/api/groupElevator/insert";
    private static String delete = "https://gis-orion-work.sf-express.com/work/api/groupElevator/delete";
    private static String account = "01399581";
    private static String taskId = "666131";
    private static String taskName = "地址电梯信息入库";

    public void start(String startDate, String endDate, String date2) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        JavaRDD<AoieletaskResult> rdd = loadAoieletaskResultData(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        long cnt = rdd.count();
        logger.error("rdd cnt:{}", cnt);

        if (cnt > 0) {

            JavaRDD<AoieletaskResult> uniqueAddrRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).groupByKey().filter(tp -> {
                List<AoieletaskResult> list = Lists.newArrayList(tp._2);
                int size = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(AoieletaskResult::getAddr_ele))), ArrayList::new)).size();
                return size < 2;
            }).flatMap(tp -> Lists.newArrayList(tp._2).iterator()).mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("uniqueAddrRdd cnt:{}", uniqueAddrRdd.count());
            rdd.unpersist();

            JavaRDD<AoieletaskResult> eleRdd = uniqueAddrRdd.map(o -> {
                String addr_ele = o.getAddr_ele();
                if (StringUtils.equals(addr_ele, "1")) {
                    o.setEle("1");
                    o.setClimb("0");
                } else if (StringUtils.equals(addr_ele, "2")) {
                    o.setEle("0");
                    o.setClimb("1");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("eleRdd cnt:{}", eleRdd.count());
            uniqueAddrRdd.unpersist();

            String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", queryElevatorUrl, ak, eleRdd.count(), 40);
            JavaRDD<AoieletaskResult> groupidRdd = eleRdd.map(o -> {
                String address = o.getAddress();
                String city_code = o.getCity_code();
                String group_id = "";
                String is_elevator = "";
                String data_src = "";
                if (StringUtils.isNotEmpty(address)) {
                    JSONObject param = new JSONObject();
                    param.put("address", address);
                    param.put("citycode", city_code);
                    String content = HttpInvokeUtil.sendPostHeader(queryElevatorUrl, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", ak, "UTF-8", "UTF-8");
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            try {
                                group_id = jsonObject.getJSONObject("result").getJSONObject("data").getString("group_id");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {
                                is_elevator = jsonObject.getJSONObject("result").getJSONObject("data").getString("isElevator");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {
                                data_src = jsonObject.getJSONObject("result").getJSONObject("data").getString("data_src");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            o.setGroup_id(group_id);
                            o.setIs_elevator(is_elevator);
                            o.setData_src(data_src);
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("groupidRdd cnt:{}", groupidRdd.count());
            eleRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id1);

            JavaPairRDD<String, AoieletaskResult> filterGroupidRdd = groupidRdd.mapToPair(o -> new Tuple2<>(o.getGroup_id(), o)).groupByKey().filter(tp -> {
                List<AoieletaskResult> list = Lists.newArrayList(tp._2);
                int size = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(AoieletaskResult::getAddr_ele))), ArrayList::new)).size();
                return size < 2;
            }).flatMap(tp -> Lists.newArrayList(tp._2).iterator()).mapToPair(o -> new Tuple2<>(o.getGroup_id(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("filterGroupidRdd cnt:{}", filterGroupidRdd.count());
            groupidRdd.unpersist();

            JavaRDD<AoieletaskResult> tdGroupElevatorResultAosRdd = loadTdGroupElevatorResultAosData(spark, sc, date2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("tdGroupElevatorResultAosRdd cnt:{}", tdGroupElevatorResultAosRdd.count());

            JavaRDD<AoieletaskResult> nowRdd = filterGroupidRdd.leftOuterJoin(tdGroupElevatorResultAosRdd.mapToPair(o -> new Tuple2<>(o.getGroup_id(), o))).map(tp -> {
                AoieletaskResult o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    AoieletaskResult aoieletaskResult = tp._2._2.get();
                    o.setNow_ele(aoieletaskResult.getNow_ele());
                    o.setNow_src(aoieletaskResult.getNow_src());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("nowRdd cnt:{}", nowRdd.count());
            filterGroupidRdd.unpersist();
            tdGroupElevatorResultAosRdd.unpersist();

            JavaRDD<AoieletaskResult> srcFilterRdd = nowRdd.filter(o -> {
                String now_src = o.getNow_src();
                if (StringUtils.isNotEmpty(now_src)) {
                    String[] split = now_src.split("\\|");
                    for (String s : split) {
                        if (StringUtils.equals(s, "6")) {
                            return false;
                        }
                    }
                }
                return true;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("srcFilterRdd cnt:{}", srcFilterRdd.count());
            nowRdd.unpersist();

            JavaRDD<AoieletaskResult> eleSrcFilterRdd = srcFilterRdd.filter(o -> {
                String now_ele = o.getNow_ele();
                String now_src = o.getNow_src();
                if (StringUtils.isNotEmpty(now_ele) && !now_ele.contains("|") && StringUtils.isNotEmpty(now_src) && now_src.contains("|")) {
                    return false;
                }
                return true;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("eleSrcFilterRdd cnt:{}", eleSrcFilterRdd.count());
            srcFilterRdd.unpersist();

            String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getAddrByCityCodeAndAddrUrl, "", eleSrcFilterRdd.count(), 40);
            JavaRDD<AoieletaskResult> cmsRdd = eleSrcFilterRdd.map(o -> {
                String group_id = o.getGroup_id();
                String city_code = o.getCity_code();
                String address = "";
                String aoiid = "";
                if (StringUtils.isNotEmpty(group_id)) {
                    String req = String.format(getAddrByCityCodeAndAddrUrl, city_code, group_id);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            try {
                                address = jsonObject.getJSONObject("data").getString("address");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            try {
                                aoiid = jsonObject.getJSONObject("data").getString("aoiId");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            o.setCms_address(address);
                            o.setCms_aoi_id(aoiid);
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsRdd cnt:{}", cmsRdd.count());
            eleSrcFilterRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id2);

            String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", splitUrl, "3eb300d2e06947f7945cd02530a32fd2", cmsRdd.count(), 40);
            JavaRDD<AoieletaskResult> levelRdd = cmsRdd.filter(o -> {
                String address = o.getCms_address();
                String city_code = o.getCity_code();
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(splitUrl, URLEncoder.encode(address, "UTF-8"), city_code);
                    String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                JSONObject data = result.getJSONObject("data");
                                if (data != null) {
                                    JSONArray info = data.getJSONArray("info");
                                    if (info != null && info.size() > 0) {
                                        for (int i = 0; i < info.size(); i++) {
                                            JSONObject jsonObject1 = info.getJSONObject(i);
                                            int level = jsonObject1.getInteger("level");
                                            if (level == 14) {
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("levelRdd cnt:{}", levelRdd.count());
            cmsRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id3);

            logger.error("数据存储");
            DataUtil.saveOverwrite(spark, sc, "dm_gis.aoieletask_addrele", AoieletaskResult.class, levelRdd, "inc_day");

            String token = getToken(tokenUrl, "Authorization", tuthorization);
            logger.error("token:{}", token);
            Broadcast<String> tokenBc = sc.broadcast(token);

            String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", insert, "Bearer " + token, levelRdd.count(), 40);
            String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", delete, "Bearer " + token, levelRdd.count(), 40);
            JavaRDD<AoieletaskResult> resultRdd = levelRdd.map(o -> {
                String tk = tokenBc.value();
                String ele = o.getEle();
                String now_ele = o.getNow_ele();

                String cms_aoi_id = o.getCms_aoi_id();
                String city_code = o.getCity_code();
                String group_id = o.getGroup_id();
                String climb = o.getClimb();

                JSONObject param = new JSONObject();
                param.put("aoiId", cms_aoi_id);
                param.put("cityCode", city_code);
                param.put("groupId", group_id);
                param.put("isClimb", climb);
                param.put("isElevator", ele);
                if (StringUtils.isEmpty(now_ele)) {
                    param.put("source", "100");
                    param.put("updateReason", "S100-外包核实");
                    String resp = HttpInvokeUtil.sendPostHeader(insert, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "Authorization", "Bearer " + tk, "UTF-8", "UTF-8");
                    o.setInsertSource100Resp(resp);

                } else {
                    if (StringUtils.equals(now_ele, ele)) {
                        param.put("source", "99");
                        param.put("updateReason", "R99-人工定向运营");
                        String resp = HttpInvokeUtil.sendPostHeader(insert, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "Authorization", "Bearer " + tk, "UTF-8", "UTF-8");
                        o.setInsertSource99Resp(resp);

                    } else {
                        JSONObject deleteParam = new JSONObject();
                        deleteParam.put("cityCode", city_code);
                        deleteParam.put("groupId", group_id);
                        deleteParam.put("updateReason", "S100-外包核实");
                        String now_src = o.getNow_src();
                        if (StringUtils.isNotEmpty(now_src)) {
                            String[] split = now_src.split("\\|");
                            for (String s : split) {
                                deleteParam.put("source", s);
                                String resp = HttpInvokeUtil.sendPostHeader(delete, deleteParam.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "Authorization", "Bearer " + tk, "UTF-8", "UTF-8");
                                o.setDeleteResp(resp);
                            }
                        }

                        param.put("source", "100");
                        param.put("updateReason", "S100-外包核实");
                        String resp = HttpInvokeUtil.sendPostHeader(insert, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "Authorization", "Bearer " + tk, "UTF-8", "UTF-8");
                        o.setInsertSource100Resp(resp);

                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            resultRdd.take(5).forEach(o -> logger.error(JSON.toJSONString(o)));
            levelRdd.unpersist();
            resultRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id4);
            BdpTaskRecordUtil.endNetworkInterface(account, id5);
        }
        sc.stop();
    }

    public static String getToken(String url, String header, String tuthorization) {
        String access_token = "";
        String content = HttpInvokeUtil.sendPostHeader(url, "", FixedConstant.MAX_TRY_TIME_ONCE, header, tuthorization, "UTF-8", "UTF-8");
        if (StringUtils.isNotEmpty(content)) {
            JSONObject jsonObject = JSON.parseObject(content);
            if (jsonObject != null) {
                access_token = jsonObject.getString("access_token");
            }
        }
        return access_token;
    }

    public static JavaRDD<AoieletaskResult> loadTdGroupElevatorResultAosData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select\n" +
                "  b.group_id group_id,\n" +
                "  concat_ws('|', collect_set(b.is_elevator)) now_ele,\n" +
                "  concat_ws('|', collect_set(b.source)) now_src\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      group_id,\n" +
                "      is_elevator,\n" +
                "      source\n" +
                "    from\n" +
                "      dm_gis.td_group_elevator_result_aos\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and is_delete = '0'\n" +
                "  ) b\n" +
                "group by\n" +
                "  b.group_id", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoieletaskResult.class);
    }

    public static JavaRDD<AoieletaskResult> loadAoieletaskResultData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select\n" +
                "  batch_no,\n" +
                "  city_code,\n" +
                "  address,\n" +
                "  aoi_id,\n" +
                "  addr_ele," +
                "  inc_day\n" +
                "from\n" +
                "  dm_gis.aoieletask_result\n" +
                "where\n" +
                "  inc_day between '%s' and '%s'\n" +
                "  and addr_ele in ('1', '2')", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoieletaskResult.class);
    }
}
