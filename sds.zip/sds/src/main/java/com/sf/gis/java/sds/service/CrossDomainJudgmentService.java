package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.ApplicationNocallPickCrossRegional;
import com.sf.gis.java.sds.pojo.CmsAoiSch;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class CrossDomainJudgmentService implements Serializable {
    private Logger logger = LoggerFactory.getLogger(CrossDomainJudgmentService.class);

    public JavaRDD<ApplicationNocallPickCrossRegional> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select time,src_order_no,inner_order_no,waybill_no,zonecode,order_time,act_loginid,act_time,city_code,city_name,aoi_group,eventlng,eventlat from dm_tdos.application_nocall_pick_cross_regional where inc_day = '%s' and eventlng <>'' and eventlat <>''", date);
        logger.error("applicationnocallpickcrossregional sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ApplicationNocallPickCrossRegional.class);
    }

    public JavaRDD<ApplicationNocallPickCrossRegional> loadCrossDomainJudgeData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select time,src_order_no,inner_order_no,waybill_no,zonecode from dm_gis.cross_domain_judge where inc_day = '%s' and coor_aoi <> ''", date);
        logger.error("cross_domain_judge sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, ApplicationNocallPickCrossRegional.class);
    }

    public JavaRDD<AoiAreaAoi> loadAoiAreaAoi(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi where status=1";
        logger.error("aoi_area_aoi sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiAreaAoi.class);
    }

    public JavaRDD<CmsAoiSch> loadCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select city_code,aoi_id,aoi_code from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public String runAoi(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            logger.error("aoi url:{}", url);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request aoi error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public void saveData(SparkSession spark, JavaRDD<ApplicationNocallPickCrossRegional> inRdd, String date) {

        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getTime(), o.getSrc_order_no(), o.getInner_order_no(), o.getWaybill_no(), o.getZonecode(), o.getOrder_time(), o.getAct_loginid(),
                    o.getAct_time(), o.getCity_code(), o.getCity_name(), o.getAoi_group(), o.getEventlng(), o.getEventlat(),
                    o.getCoor_aoi(), o.getCoor_aoi_group(), o.getCoor_area_dist(), o.getCoor_zno_dist()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"time", "src_order_no", "inner_order_no", "waybill_no", "zonecode", "order_time", "act_loginid",
                "act_time", "city_code", "city_name", "aoi_group", "eventlng", "eventlat",
                "coor_aoi", "coor_aoi_group", "coor_area_dist", "coor_zno_dist"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cross_domain_judge_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.cross_domain_judge";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
