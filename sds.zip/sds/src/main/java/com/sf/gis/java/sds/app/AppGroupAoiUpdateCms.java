package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.GroupAoiUpdateCmsController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppGroupAoiUpdateCms {
    private static Logger logger = LoggerFactory.getLogger(AppGroupAoiUpdateCms.class);

    public static void main(String[] args) {
        String incDay = args[0];
        logger.error("incDay:{}", incDay);
        logger.error("run start");
        new GroupAoiUpdateCmsController().start(incDay);
        logger.error("run end");


    }
}
