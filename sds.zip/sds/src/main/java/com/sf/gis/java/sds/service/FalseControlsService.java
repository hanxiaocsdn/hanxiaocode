package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.WbTrack;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.pojo.FcDlv;
import com.sf.gis.java.sds.pojo.FcPu;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 虚假管控：实时弹窗逻辑修正验证（数据获取）
 * @author 01370539
 * Created on Jun.20 2022
 */
public class FalseControlsService {
    private static final Logger logger = LoggerFactory.getLogger(FalseControlsService.class);

    /**
     * 获取运单妥投相关信息
     */
    public JavaRDD<FcDlv> loadWbDlvInfo(SparkInfo si, String cityCode, String incDay) {
        String sql = "select couriercode,waybill_no,area_code,city_code,dest_zone_code,aoi_code aoi_id,aoi_type_name,aoi_type_code,barscantm80,lng80,lat80,istougui,iszijiziqu,isdld,iswd,iszhuanjituihui,istoken,isphone100,iscopyphone,iscallphone,isfwsjg2g,isexternal,inc_day from dm_gis.lbs_loc_index where inc_day = '" + incDay + "'";
        if (!"ALL".equals(cityCode)) {
            sql += " and city_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si, sql, FcDlv.class);
    }

    /**
     * 获取轨迹相关信息
     */
    public JavaRDD<WbTrack> loadTrackInfo(SparkInfo si, String cityCode, String incDay) {
        String sql = "select waybill_no, aoi_id, courier, lng_track, lat_track, tm_track, tp_track, aoi_id, dis, inc_day from dm_gis.dwb_wb_track_dlv_di where inc_day = '" + incDay + "' and ac_track <= 300";
        if (!"ALL".equals(cityCode)) {
            sql += " and bn_track like '" + cityCode + "%'";
        }
        return DataUtil.loadData(si, sql, WbTrack.class);
    }

    /**
     * 获取运单地址信息（派件）
     */
    public JavaRDD<FcDlv> loadWbDlvAddr(SparkInfo si, String cityCode, String incDay) {
        String sql = "select waybill_no, dest_dist_code city_code, consignee_addr addr, dest_lgt lng_zc, dest_lat lat_zc, inc_day from dm_gis.tt_waybill_hook where inc_day = '" + incDay + "'";
        if (!"ALL".equals(cityCode)) {
            sql += " and dest_dist_code = '" + cityCode + "'";
        }
        return DataUtil.loadData(si, sql, FcDlv.class);
    }

    /**
     * 获取ADDR是否可识别（派件）
     */
    public JavaRDD<FcDlv> loadDlvAddrRcg(SparkInfo si, String cityCode, String incDay) {
        String startDate = DateUtil.getDayBefore(incDay, "yyyyMMdd", 6);
        String sql = "select req_waybillno waybill_no, req_destcitycode city_code, inc_day from dm_gis.gis_rds_omsto where inc_day between '" + startDate + "' and '" + incDay + "' and (gisaoicode <> '' or ksaoicode <> '')";
        if (!"ALL".equals(cityCode)) {
            sql += " and req_destcitycode = '" + cityCode + "'";
        }
        return DataUtil.loadData(si, sql, FcDlv.class);
    }

    /**
     * 获取ADDR是否识别正确（派件）
     */
    public JavaRDD<FcDlv> loadDlvAddrRcgRs(SparkInfo si, String cityCode, String incDay) {
        String sql = "select waybillno waybill_no, req_destcitycode city_code, tag1 addr_tag, gisaoisrc addr_src, inc_day from dm_gis.dm_aoi_real_acctury_rate_judge_bottomcorrected_2024_di where inc_day = '" + incDay + "'";
        if (!"ALL".equals(cityCode)) {
            sql += " and req_destcitycode = '" + cityCode + "'";
        }
        return DataUtil.loadData(si, sql, FcDlv.class);
    }
}
