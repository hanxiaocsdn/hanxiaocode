package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.CmsAoiChangeTask;
import com.sf.gis.java.sds.pojo.CmsAoiChangeTaskDetail;
import com.sf.gis.java.sds.pojo.CmsAoiChangeTaskStat;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;

/**
 * 任务id:806644(区域场景AOI变更过程快照)
 * 业务方：01416486（张剑佩）
 * 研发：01399581（匡仁衡）
 * 时间：2023年9月14日16:35:42
 */

public class AppCmsAoiChangeTask {
    private static Logger logger = LoggerFactory.getLogger(AppCmsAoiChangeTask.class);

    public static void main(String[] args) throws Exception {
        String stat_start = args[0];
        String stat_end = args[1];
        String date = args[2];
        String type = args[3];
        logger.error("stat_start:{}", stat_start);
        logger.error("stat_end:{}", stat_end);
        logger.error("date:{}", date);
        logger.error("type:{}", type);

        SparkInfo sparkInfo = SparkUtil.getSpark("AppCmsAoiChangeTask");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String cms_aoi_sql = String.format("select aoi_id from dm_gis.cms_aoi where inc_day = '%s' and del_flag = '0'", date);
        JavaRDD<CmsAoiChangeTask> allRdd = DataUtil.loadData(spark, sc, cms_aoi_sql, CmsAoiChangeTask.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("allRdd cnt:{}", allRdd.count());

        String change_aoi_sql = String.format("select\n" +
                "  t.aoi_id aoi_id\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      old_aoi_id aoi_id\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_change_task\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and DATE_FORMAT(create_date, 'yyyyMMdd') between '%s' and '%s'\n" +
                "    union all\n" +
                "    select\n" +
                "      new_aoi_id aoi_id\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_change_task\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and DATE_FORMAT(create_date, 'yyyyMMdd') between '%s' and '%s'\n" +
                "  ) t group by t.aoi_id", date, stat_start, stat_end, date, stat_start, stat_end);
        JavaRDD<CmsAoiChangeTask> changeRdd = DataUtil.loadData(spark, sc, change_aoi_sql, CmsAoiChangeTask.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("changeRdd cnt:{}", changeRdd.count());

        JavaPairRDD<String, CmsAoiChangeTask> unchangeRdd = allRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(changeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))).filter(tp -> {
            boolean flag = true;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                flag = false;
            }
            return flag;
        }).map(tp -> tp._2._1).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unchangeRdd cnt:{}", unchangeRdd.count());
        allRdd.unpersist();
        changeRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.tt_addr_aoi_change_temp drop if EXISTS partition(type = '%s',inc_day='%s')", type, date));
        spark.sql(String.format("alter table dm_gis.tt_addr_aoi_unchange_temp drop if EXISTS partition(type = '%s',inc_day='%s')", type, date));

        String before365Date = DateUtil.getDaysBefore(stat_end, 364);
        List<String[]> dateSliceByMonth = DateUtil.dateSliceByMonth(before365Date, stat_end, "yyyyMMdd", "yyyyMM");
        for (String[] slices : dateSliceByMonth) {
            String month = slices[0];
            String startDate = slices[1];
            String endDate = slices[2];
            logger.error("month:{},startDate:{},endDate:{}", month, startDate, endDate);

            String tt_waybill_info_sql = String.format("select waybill_no,consignor_addr,consignee_addr,delivery_xy_aoiid pj_aoi,consign_xy_aoiid sj_aoi from dm_gis.tt_waybill_info where inc_day between '%s' and '%s'", startDate, endDate);
            JavaRDD<CmsAoiChangeTask> wayBillInfoRdd = DataUtil.loadData(spark, sc, tt_waybill_info_sql, CmsAoiChangeTask.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("wayBillInfoRdd cnt:{}", wayBillInfoRdd.count());

            JavaRDD<CmsAoiChangeTask> empSjAoiRdd = wayBillInfoRdd.filter(o -> StringUtils.isEmpty(o.getSj_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<CmsAoiChangeTask> noEmpSjAoiRdd = wayBillInfoRdd.filter(o -> StringUtils.isNotEmpty(o.getSj_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("empSjAoiRdd cnt:{}", empSjAoiRdd.count());
            logger.error("noEmpSjAoiRdd cnt:{}", noEmpSjAoiRdd.count());
            wayBillInfoRdd.unpersist();

            String tt_order_hook_sql = String.format("select waybill_no,aoi_id from dm_gis.tt_order_hook where inc_day between '%s' and '%s' and aoi_id is not null and aoi_id<>''", startDate, endDate);
            JavaRDD<CmsAoiChangeTask> orderHookRdd = DataUtil.loadData(spark, sc, tt_order_hook_sql, CmsAoiChangeTask.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("orderHookRdd cnt:{}", orderHookRdd.count());

            JavaRDD<CmsAoiChangeTask> sjAoiRdd = empSjAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(orderHookRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                CmsAoiChangeTask o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiChangeTask cmsAoiChangeTask = tp._2._2.get();
                    o.setSj_aoi(cmsAoiChangeTask.getAoi_id());
                }
                return o;
            }).union(noEmpSjAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("sjAoiRdd cnt:{}", sjAoiRdd.count());
            empSjAoiRdd.unpersist();
            orderHookRdd.unpersist();
            noEmpSjAoiRdd.unpersist();

            JavaRDD<CmsAoiChangeTask> empPjAoiRdd = sjAoiRdd.filter(o -> StringUtils.isEmpty(o.getPj_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<CmsAoiChangeTask> noEmpPjAoiRdd = sjAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getPj_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("empPjAoiRdd cnt:{}", empPjAoiRdd.count());
            logger.error("noEmpPjAoiRdd cnt:{}", noEmpPjAoiRdd.count());
            sjAoiRdd.unpersist();

            String after15Date = DateUtil.getDaysBefore(endDate, -15);
            String tt_waybill_hook_sql = String.format("select waybill_no,aoi_id from dm_gis.tt_waybill_hook where inc_day between '%s' and '%s' and aoi_id is not null and aoi_id <>''", startDate, after15Date);
            JavaRDD<CmsAoiChangeTask> waybillHookRdd = DataUtil.loadData(spark, sc, tt_waybill_hook_sql, CmsAoiChangeTask.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("waybillHookRdd cnt:{}", waybillHookRdd.count());

            JavaRDD<CmsAoiChangeTask> pjAoiRdd = empPjAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(waybillHookRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                CmsAoiChangeTask o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiChangeTask cmsAoiChangeTask = tp._2._2.get();
                    o.setPj_aoi(cmsAoiChangeTask.getAoi_id());
                }
                return o;
            }).union(noEmpPjAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pjAoiRdd cnt:{}", pjAoiRdd.count());
            empPjAoiRdd.unpersist();
            waybillHookRdd.unpersist();
            noEmpPjAoiRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskDetail> detailRdd = pjAoiRdd.flatMap(o -> {
                String waybill_no = o.getWaybill_no();

                String consignor_addr = o.getConsignor_addr();
                String pj_aoi = o.getPj_aoi();
                CmsAoiChangeTaskDetail o1 = new CmsAoiChangeTaskDetail();
                o1.setWaybill_no(waybill_no);
                o1.setAddr(consignor_addr);
                o1.setAoi_id(pj_aoi);

                CmsAoiChangeTaskDetail o2 = new CmsAoiChangeTaskDetail();
                String consignee_addr = o.getConsignee_addr();
                String sj_aoi = o.getSj_aoi();
                o2.setWaybill_no(waybill_no);
                o2.setAddr(consignee_addr);
                o2.setAoi_id(sj_aoi);

                ArrayList<CmsAoiChangeTaskDetail> list = new ArrayList<>();
                list.add(o1);
                list.add(o2);
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("detailRdd cnt:{}", detailRdd.count());
            pjAoiRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskDetail> empAoiRdd = detailRdd.filter(o -> StringUtils.isEmpty(o.getAoi_id())).map(o -> {
                o.setTag("change");
                o.setType(type);
                o.setInc_day(date);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<CmsAoiChangeTaskDetail> noEmpAoiRdd = detailRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
            logger.error("noEmpAoiRdd cnt:{}", noEmpAoiRdd.count());
            detailRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskDetail> tagRdd = noEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(unchangeRdd).map(tp -> {
                CmsAoiChangeTaskDetail o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    o.setTag("unchange");
                } else {
                    o.setTag("change");
                }
                o.setType(type);
                o.setInc_day(date);
                return o;
            }).union(empAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("tagRdd cnt:{}", tagRdd.count());
            noEmpAoiRdd.unpersist();
            empAoiRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskDetail> changeTempRdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "change")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<CmsAoiChangeTaskDetail> unChangeTempRdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "unchange")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("changeTempRdd cnt:{}", changeTempRdd.count());
            logger.error("unChangeTempRdd cnt:{}", unChangeTempRdd.count());
            tagRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskStat> changeResultRdd = stat(sc, changeTempRdd, "change", type, date);
            DataUtil.saveInto(spark, sc, "dm_gis.tt_addr_aoi_change_temp", CmsAoiChangeTaskStat.class, changeResultRdd, "type", "inc_day");
            changeResultRdd.unpersist();

            JavaRDD<CmsAoiChangeTaskStat> unchangeResultRdd = stat(sc, unChangeTempRdd, "unchange", type, date);
            DataUtil.saveInto(spark, sc, "dm_gis.tt_addr_aoi_unchange_temp", CmsAoiChangeTaskStat.class, unchangeResultRdd, "type", "inc_day");
            unchangeResultRdd.unpersist();

        }
        unchangeRdd.unpersist();

        logger.error("last stat...");
        String change_sql = String.format("select * from dm_gis.tt_addr_aoi_change_temp where type = '%s' and inc_day = '%s'", type, date);
        JavaRDD<CmsAoiChangeTaskStat> tempChangeRdd = DataUtil.loadData(spark, sc, change_sql, CmsAoiChangeTaskStat.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tempChangeRdd cnt:{}", tempChangeRdd.count());
        JavaRDD<CmsAoiChangeTaskStat> changeResultRdd = groupAll(tempChangeRdd);
        tempChangeRdd.unpersist();
        spark.sql(String.format("alter table dm_gis.tt_addr_aoi_change drop if EXISTS partition(type = '%s',inc_day='%s')", type, date));
        DataUtil.saveInto(spark, sc, "dm_gis.tt_addr_aoi_change", CmsAoiChangeTaskStat.class, changeResultRdd, "type", "inc_day");
        changeResultRdd.unpersist();

        String unchange_sql = String.format("select * from dm_gis.tt_addr_aoi_unchange_temp where type = '%s' and inc_day = '%s'", type, date);
        JavaRDD<CmsAoiChangeTaskStat> tempUnchangeRdd = DataUtil.loadData(spark, sc, unchange_sql, CmsAoiChangeTaskStat.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tempUnchangeRdd cnt:{}", tempUnchangeRdd.count());
        JavaRDD<CmsAoiChangeTaskStat> unchangeResultRdd = groupAll(tempUnchangeRdd);
        tempUnchangeRdd.unpersist();
        spark.sql(String.format("alter table dm_gis.tt_addr_aoi_unchange drop if EXISTS partition(type = '%s',inc_day='%s')", type, date));
        DataUtil.saveInto(spark, sc, "dm_gis.tt_addr_aoi_unchange", CmsAoiChangeTaskStat.class, unchangeResultRdd, "type", "inc_day");
        unchangeResultRdd.unpersist();

        sc.stop();
    }

    public static JavaRDD<CmsAoiChangeTaskStat> groupAll(JavaRDD<CmsAoiChangeTaskStat> rdd) {
        JavaRDD<CmsAoiChangeTaskStat> groupRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).reduceByKey((o1, o2) -> {
            int freq_1 = StringUtils.isNotEmpty(o1.getFreq()) ? Integer.parseInt(o1.getFreq()) : 0;
            int freq_2 = StringUtils.isNotEmpty(o2.getFreq()) ? Integer.parseInt(o2.getFreq()) : 0;
            o1.setFreq((freq_1 + freq_2) + "");
            return o1;
        }).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("groupRdd cnt:{}", groupRdd.count());
        return groupRdd;
    }

    public static JavaRDD<CmsAoiChangeTaskStat> stat(JavaSparkContext sc, JavaRDD<CmsAoiChangeTaskDetail> rdd, String tag, String type, String date) {
        JavaRDD<CmsAoiChangeTaskDetail> noEmpAddrRdd = rdd.filter(o -> StringUtils.isNotEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CmsAoiChangeTaskDetail> empAddrRdd = rdd.filter(o -> StringUtils.isEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpAddrRdd cnt:{}", noEmpAddrRdd.count());
        long emp_addr_cnt = empAddrRdd.count();
        logger.error("empAddrRdd cnt:{}", emp_addr_cnt);
        rdd.unpersist();

        String aoi_id = empAddrRdd.take(1).get(0).getAoi_id();
        CmsAoiChangeTaskStat taskStat = new CmsAoiChangeTaskStat();
        taskStat.setType(type);
        taskStat.setInc_day(date);
        taskStat.setFreq(emp_addr_cnt + "");
        if (StringUtils.equals(tag, "unchange")) {
            taskStat.setAoi_id(aoi_id);
        }
        ArrayList<CmsAoiChangeTaskStat> emp_addr_list = new ArrayList<>();
        emp_addr_list.add(taskStat);
        JavaRDD<CmsAoiChangeTaskStat> empStatRdd = sc.parallelize(emp_addr_list).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empStatRdd cnt:{}", empStatRdd.count());
        empAddrRdd.unpersist();

        JavaRDD<CmsAoiChangeTaskStat> statRdd = noEmpAddrRdd.map(o -> {
            o.setTemp_freq(1);
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAddr(), o)).reduceByKey((o1, o2) -> {
            o1.setTemp_freq(o1.getTemp_freq() + o2.getTemp_freq());
            return o1;
        }).map(tp -> tp._2).map(o -> {
            CmsAoiChangeTaskStat stat = new CmsAoiChangeTaskStat();
            stat.setAddr(o.getAddr());
            if (StringUtils.equals(tag, "unchange")) {
                stat.setAoi_id(o.getAoi_id());
            }
            stat.setFreq(o.getTemp_freq() + "");
            stat.setType(type);
            stat.setInc_day(date);
            return stat;
        }).union(empStatRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:{}", statRdd.count());
        noEmpAddrRdd.unpersist();
        empStatRdd.unpersist();
        return statRdd;
    }
}
