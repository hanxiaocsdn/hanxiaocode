package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.CmsAddress;
import com.sf.gis.java.sds.pojo.CmsAddressDuplicate;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.service.StdAddrCoincideJudgeService;
import com.sf.gis.java.sds.utils.DistanceTool;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.Statement;
import java.util.*;
import java.util.stream.Collectors;

public class StdAddrCoincideJudgeController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(StdAddrCoincideJudgeController.class);
    StdAddrCoincideJudgeService service = new StdAddrCoincideJudgeService();

    private static String atp = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&showserver=true&ak=dec044d089524419b371bc94555c539d&opt=zh";
    private static String similarUrl = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=3eb300d2e06947f7945cd02530a32fd2&beforeAddress=%s&afterAddress=%s";
    private static String distanceaoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept/routeplan/aoi?aoi_code1=%s&city_code1=%s&aoi_code2=%s&city_code2=%s&ak=3eb300d2e06947f7945cd02530a32fd2";

    private static int limitSec = 2000 / 40;

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        JavaPairRDD<String, CmsAoiSch> cmsAoiSchRdd = service.getCmsAoiSch(spark, sc).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaPairRDD<String, AoiAreaAoi> aoiAreaAoiRdd = service.loadAoiAreaAoiData(spark, sc).mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaAoiRdd cnt:{}", aoiAreaAoiRdd.count());

        List<String> synonymList = ConfigurationUtil.loadFileByConf("synonym.csv");
        List<String> synonym_sort_list = new ArrayList<>();
        for (String s : synonymList) {
            List<String> list = Arrays.asList(s.split(","));
            list.sort(new Comparator<String>() {
                @Override
                public int compare(String o1, String o2) {
                    if (o1.length() > o2.length()) {
                        return 1;
                    } else if (o1.length() < o2.length()) {
                        return -1;
                    }
                    return 0;
                }
            });
            synonym_sort_list.add(String.join(",", list));
        }
        Broadcast<List<String>> synonym_sort_listBc = sc.broadcast(synonym_sort_list);

        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        for (Map.Entry<Object, Object> objectObjectEntry : cityDbPro.entrySet()) {
            String city = (String) objectObjectEntry.getKey();

            if (!StringUtils.equals(city, "010")) {
                continue;
            }

            String number = (String) objectObjectEntry.getValue();
            String table = "wchka.cms_address_" + number;
            logger.error("city:{},number:{},table:{}", city, number, table);
            String condition = String.format("city_code = '%s' and status != 2 and zno_code != ''", city);
            logger.error("condition:{}", condition);

            JavaRDD<CmsAddress> rdd = spark.read().format("jdbc")
                    .option("driver", "com.mysql.jdbc.Driver")
                    .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                    .option("dbtable", table)
                    .option("user", "wchka_aoi")
                    .option("password", "giscmsaoi123")
                    .load()
                    .where(condition)
                    .select("city_code", "address_id", "address_md5", "address", "keyword", "zno_code", "receipt_zno_code", "x", "y", "type", "delivery_type", "status", "aoi_id", "src", "city")
                    .toJavaRDD()
                    .repartition(400)
                    .map(row -> {
                        CmsAddress o = new CmsAddress();

                        String city_code = row.getString(0);
                        String address_id = row.getString(1);
                        String address_md5 = row.getString(2);
                        String address = row.getString(3);
                        String keyword = row.getString(4);
                        String zno_code = row.getString(5);
                        String receipt_zno_code = row.getString(6);
                        double x = row.getDouble(7);
                        double y = row.getDouble(8);
                        int type = row.getInt(9);
                        int delivery_type = row.getInt(10);
                        int status = row.getInt(11);
                        String aoi_id = row.getString(12);
                        int src = row.getInt(13);
                        String city_name = row.getString(14);

                        o.setCity_code(city_code);
                        o.setAddress_id(address_id);
                        o.setAddress_md5(address_md5);
                        o.setAddress(address);
                        o.setKeyword(keyword);
                        o.setZno_code(zno_code);
                        o.setReceipt_zno_code(receipt_zno_code);
                        o.setX(x + "");
                        o.setY(y + "");
                        o.setType(type + "");
                        o.setDelivery_type(delivery_type + "");
                        o.setStatus(status + "");
                        o.setAoi_id(aoi_id);
                        o.setSrc(src + "");
                        o.setCity(city_name);

                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());

            JavaRDD<CmsAddress> aoiAreaCodeRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(cmsAoiSchRdd).map(tp -> {
                CmsAddress o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiSch cmsAoiSch = tp._2._2.get();
                    o.setAoi_code(cmsAoiSch.getAoi_code());
                    o.setAoi_name(cmsAoiSch.getAoi_name());
                    o.setFa_type(cmsAoiSch.getFa_type());
                }
                return o;
            }).mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)).leftOuterJoin(aoiAreaAoiRdd).map(tp -> {
                CmsAddress o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    AoiAreaAoi aoiAreaAoi = tp._2._2.get();
                    o.setAoi_area_code(aoiAreaAoi.getAoi_area_code());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiAreaCodeRdd cnt:{}", aoiAreaCodeRdd.count());
            rdd.unpersist();
            cmsAoiSchRdd.unpersist();
            aoiAreaAoiRdd.unpersist();

            JavaRDD<CmsAddress> gjRdd = aoiAreaCodeRdd.filter(o -> StringUtils.equals(o.getSrc(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<CmsAddress> djRdd = aoiAreaCodeRdd.filter(o -> StringUtils.equals(o.getSrc(), "2")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gjRdd cnt:{},djRdd cnt:{}", gjRdd.count(), djRdd.count());
            aoiAreaCodeRdd.unpersist();

            JavaRDD<CmsAddress> gjGroupRdd = gjRdd.mapPartitions(itr -> {
                Connection conn = JdbcUtil.getMysqlConnection("gj-mysql.properties");
                Statement stmt = conn.createStatement();
                List<CmsAddress> list = new ArrayList<>();
                try {
                    while (itr.hasNext()) {
                        CmsAddress o = itr.next();
                        o = service.processGdj(o, stmt);
                        list.add(o);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    stmt.close();
                    conn.close();
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gjGroupRdd cnt:{}", gjGroupRdd.count());
            gjRdd.unpersist();

            JavaRDD<CmsAddress> djGroupRdd = djRdd.mapPartitions(itr -> {
                Connection conn = JdbcUtil.getMysqlConnection("dj-mysql.properties");
                Statement stmt = conn.createStatement();
                List<CmsAddress> list = new ArrayList<>();
                try {
                    while (itr.hasNext()) {
                        CmsAddress o = itr.next();
                        o = service.processGdj(o, stmt);
                        list.add(o);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    stmt.close();
                    conn.close();
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("djGroupRdd cnt:{}", djGroupRdd.count());
            djRdd.unpersist();


            JavaRDD<CmsAddress> splitInfoRdd = gjGroupRdd.union(djGroupRdd).mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<CmsAddress> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitSec) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 1000) {
                            logger.error("每秒钟访问量超过限制:{},休眠:{}ms中", limitSec, 1000 - endTime);
                            Thread.sleep(1000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    CmsAddress o = itr.next();
                    String address = o.getAddress();
                    String city_code = o.getCity_code();
                    if (StringUtils.isNotEmpty(address)) {
                        String req = String.format(atp, URLEncoder.encode(address, "UTF-8"), city_code);
                        String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                        if (StringUtils.isNotEmpty(content)) {
                            String address_split_info = "";
                            try {
                                address_split_info = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                            } catch (Exception e) {
//                                e.printStackTrace();
                            }
                            o.setAddress_split_info(address_split_info);
                        }
                    }

                    String keyword = o.getKeyword();
                    if (StringUtils.isNotEmpty(keyword)) {
                        String req = String.format(atp, URLEncoder.encode(keyword, "UTF-8"), city_code);
                        String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                        if (StringUtils.isNotEmpty(content)) {
                            String key_split_info = "";
                            try {
                                key_split_info = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                            } catch (Exception e) {
//                                e.printStackTrace();
                            }
                            o.setKey_split_info(key_split_info);
                        }
                    }

                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("splitInfoRdd cnt:{}", splitInfoRdd.count());
            gjGroupRdd.unpersist();
            djGroupRdd.unpersist();

            JavaRDD<CmsAddress> maxSplitRdd = splitInfoRdd.map(o -> {
                String address_split_info = o.getAddress_split_info();
                String key_split_info = o.getKey_split_info();
                if (StringUtils.isNotEmpty(address_split_info)) {
                    String[] split = address_split_info.split(";");
                    String text = split[0];
                    String level = split[1];
                    o.setMax_split_addr(level);
                    List<String> list = Arrays.stream(text.split(",")).distinct().collect(Collectors.toList());
                    o.setAddress_split_info(String.join(",", list));
                }
                if (StringUtils.isNotEmpty(key_split_info)) {
                    String[] split = key_split_info.split(";");
                    String text = split[0];
                    String level = split[1];
                    o.setMax_split_key(level);
                    List<String> list = Arrays.stream(text.split(",")).distinct().collect(Collectors.toList());
                    o.setKey_split_info(String.join(",", list));
                }

                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("maxSplitRdd cnt:{}", maxSplitRdd.count());
            splitInfoRdd.unpersist();

            JavaRDD<CmsAddress> splitInfoNewRdd = maxSplitRdd.map(o -> {
                List<String> value = synonym_sort_listBc.value();
                String city_name = o.getCity();
                String address_split_info = o.getAddress_split_info();
                address_split_info = service.replaceSplit(address_split_info, city_name, value);

                String key_split_info = o.getKey_split_info();
                key_split_info = service.replaceSplit(key_split_info, city_name, value);

                o.setAddress_split_info(address_split_info);
                o.setKey_split_info(key_split_info);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("splitInfoNewRdd cnt:{}", splitInfoNewRdd.count());
            maxSplitRdd.unpersist();

            JavaRDD<CmsAddress> addrSplitRdd = splitInfoNewRdd.map(o -> {
                String fa_type = o.getFa_type();
                if (!StringUtils.equals(fa_type, "190109")) {
                    String address_split_info = o.getAddress_split_info();
                    ArrayList<String> list = new ArrayList<>();
                    if (StringUtils.isNotEmpty(address_split_info)) {
                        for (String s : address_split_info.split(",")) {
                            if (StringUtils.isNotEmpty(s) && s.split("\\^").length >= 2) {
                                String word = s.split("\\^")[0];
                                String level = s.split("\\^")[1];
                                if (service.judge(word, level)) {
                                    list.add(word + "^" + level);
                                }
                            }
                        }
                        o.setAddress_split_info(list.size() > 0 ? String.join(",", list) : "");
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("addrSplitRdd cnt:{}", addrSplitRdd.count());
            splitInfoNewRdd.unpersist();

            JavaRDD<CmsAddress> keySplitLevel5Rdd = addrSplitRdd.map(o -> {
                String key_split_info = o.getKey_split_info();
                if (StringUtils.isNotEmpty(key_split_info)) {
                    ArrayList<String> list = new ArrayList<>();
                    for (String s : key_split_info.split(",")) {
                        if (StringUtils.isNotEmpty(s) && s.split("\\^").length >= 2) {
                            String word = s.split("\\^")[0];
                            String level = s.split("\\^")[1];
                            if (service.judgeLevel(level)) {
                                list.add(word + "^" + level);
                            }
                        }
                    }
                    o.setKey_split_info(list.size() > 0 ? String.join(",", list) : "");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keySplitLevel5Rdd cnt:{}", keySplitLevel5Rdd.count());
            addrSplitRdd.unpersist();

            JavaRDD<CmsAddress> keySplitLevel18Rdd = keySplitLevel5Rdd.map(o -> {
                String fa_type = o.getFa_type();
                if (StringUtils.equals(fa_type, "120302") || StringUtils.equals(fa_type, "120301")) {
                    String key_split_info = o.getKey_split_info();
                    ArrayList<String> list = new ArrayList<>();
                    if (StringUtils.isNotEmpty(key_split_info)) {
                        for (String s : key_split_info.split(",")) {
                            String word = s.split("\\^")[0];
                            String level = s.split("\\^")[1];
                            if (service.judgeKey18(word, level)) {
                                list.add(word + "^" + level);
                            }
                        }
                        o.setKey_split_info(list.size() > 0 ? String.join(",", list) : "");
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keySplitLevel18Rdd cnt:{}", keySplitLevel18Rdd.count());
            keySplitLevel5Rdd.unpersist();

            JavaRDD<CmsAddress> keySplitLevel13Rdd = keySplitLevel18Rdd.map(o -> {
                o = service.process13Level(o);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keySplitLevel13Rdd cnt:{}", keySplitLevel13Rdd.count());
            keySplitLevel18Rdd.unpersist();

            JavaRDD<CmsAddress> keySplitLevel14Rdd = keySplitLevel13Rdd.map(o -> {
                o = service.process14Level(o);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keySplitLevel14Rdd cnt:{}", keySplitLevel14Rdd.count());
            keySplitLevel13Rdd.unpersist();

            JavaRDD<CmsAddress> keySplitLevel13CntRdd = keySplitLevel14Rdd.map(o -> {
                o = service.process13CntLevel(o);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keySplitLevel13CntRdd cnt:{}", keySplitLevel13CntRdd.count());
            keySplitLevel14Rdd.unpersist();

            JavaRDD<CmsAddress> keyDeny14Rdd = keySplitLevel13CntRdd.map(o -> {
                o = service.processKeyDeny14(o);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keyDeny14Rdd cnt:{}", keyDeny14Rdd.count());
            keySplitLevel13CntRdd.unpersist();

            JavaRDD<CmsAddress> newRdd = keyDeny14Rdd.map(o -> {
                String address_new = service.processKeyNew(o.getAddress_split_info());
                String key_new = service.processKeyNew(o.getKey_split_info());

                o.setAddress_new(address_new);
                o.setKey_new(key_new);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("newRdd cnt:{}", newRdd.count());
            keyDeny14Rdd.unpersist();


            JavaRDD<CmsAddress> pinYinRdd = newRdd.map(o -> {
                String address_new = o.getAddress_new();
                String key_new = o.getKey_new();
                String key_deny14_t = o.getKey_deny14_t();
                String address_new_sp = service.convertHanzi2Pinyin(address_new, false);
                String key_new_sp = service.convertHanzi2Pinyin(key_new, false);
                String key_deny14_t_sp = service.convertHanzi2Pinyin(key_deny14_t, false);
                o.setAddress_new_sp(address_new_sp);
                o.setKey_new_sp(key_new_sp);
                o.setKey_deny14_t_sp(key_deny14_t_sp);

                String address_new_qp = service.convertHanzi2Pinyin(address_new, true);
                String key_new_qp = service.convertHanzi2Pinyin(key_new, true);
                String key_deny14_t_qp = service.convertHanzi2Pinyin(key_deny14_t, true);
                o.setAddress_new_qp(address_new_qp);
                o.setKey_new_qp(key_new_qp);
                o.setKey_deny14_t_qp(key_deny14_t_qp);

                o.setInc_day(date);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("pinYinRdd cnt:{}", pinYinRdd.count());
            newRdd.unpersist();

            spark.sql(String.format("alter table dm_gis.cms_address_std_coincide_judge drop if EXISTS partition(inc_day='%s',city_code='%s')", date, city));
            DataUtil.saveInto(spark, sc, "dm_gis.cms_address_std_coincide_judge", CmsAddress.class, pinYinRdd, "inc_day", "city_code");


            //标准地址一致查找
            JavaRDD<CmsAddressDuplicate> cdRdd = pinYinRdd.mapToPair(o -> new Tuple2<>(o.getAddress_new(), o)).leftOuterJoin(pinYinRdd.mapToPair(o -> new Tuple2<>(o.getAddress_new(), o)).groupByKey()).flatMap(tp -> {
                ArrayList<CmsAddressDuplicate> result_list = new ArrayList<>();
                CmsAddress o = tp._2._1;
                String address_id = o.getAddress_id();
                String zno_code = o.getZno_code();
                String type = o.getType();
                String key_new = o.getKey_new();
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<CmsAddress> list = Lists.newArrayList(tp._2._2.get());
                    List<CmsAddress> filterList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAddress_id()) &&
                            !StringUtils.equals(address_id, t.getAddress_id()) &&
                            StringUtils.equals(zno_code, t.getZno_code()) &&
                            StringUtils.equals(type, t.getType()) &&
                            StringUtils.isNotEmpty(t.getKey_new())).collect(Collectors.toList());

                    if (StringUtils.isNotEmpty(key_new) && filterList.size() > 0) {
                        int cnt = 0;
                        long startTime = System.currentTimeMillis();
                        for (CmsAddress cmsAddress : filterList) {
                            cnt = cnt + 1;
                            if (cnt == limitSec) {
                                long endTime = System.currentTimeMillis() - startTime;
                                if (endTime < 1000) {
                                    logger.error("每秒钟访问量超过限制:{},休眠:{}ms中", limitSec, 1000 - endTime);
                                    Thread.sleep(1000 - endTime);
                                }
                                startTime = System.currentTimeMillis();
                                cnt = 0;
                            }
                            String key_new_b = cmsAddress.getKey_new();
                            String req = String.format(similarUrl, URLEncoder.encode(key_new, "UTF-8"), URLEncoder.encode(key_new_b, "UTF-8"));
                            String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                            double similar = 0;
                            try {
                                similar = JSON.parseObject(content).getDouble("result");
                            } catch (Exception e) {
//                                e.printStackTrace();
                            }
                            cmsAddress.setSimilar(similar);
                        }
                        List<CmsAddress> final_list_b = filterList.stream().filter(t -> t.getSimilar() >= 0.8).collect(Collectors.toList());
                        if (final_list_b.size() > 0) {
                            for (CmsAddress cmsAddress : final_list_b) {
                                CmsAddressDuplicate cd = new CmsAddressDuplicate();
                                cd = service.copy(cd, o, cmsAddress, "stdaddr");
                                result_list.add(cd);
                            }
                        }
                    }
                }
                return result_list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cdRdd cnt:{}", cdRdd.count());

            spark.sql(String.format("alter table dm_gis.cms_address_std_coincide_judge_stdaddr_find drop if EXISTS partition(inc_day='%s',city_code='%s')", date, city));
            DataUtil.saveInto(spark, sc, "dm_gis.cms_address_std_coincide_judge_stdaddr_find", CmsAddressDuplicate.class, cdRdd, "inc_day", "city_code");
            cdRdd.unpersist();

            //关键词一致查找
            JavaRDD<CmsAddressDuplicate> keyWordRdd = pinYinRdd.mapToPair(o -> new Tuple2<>(o.getKey_new_sp(), o)).leftOuterJoin(pinYinRdd.mapToPair(o -> new Tuple2<>(o.getKey_new_sp(), o)).groupByKey()).flatMap(tp -> {
                ArrayList<CmsAddressDuplicate> result_list = new ArrayList<>();
                ArrayList<CmsAddress> temp_list = new ArrayList<>();
                CmsAddress o = tp._2._1;
                String address_id = o.getAddress_id();
                String key_new = o.getKey_new();
                String max_split_addr = o.getMax_split_addr();
                String aoi_code = o.getAoi_code();
                String aoi_id = o.getAoi_id();
                String key_new_qp = o.getKey_new_qp();
                String group_adcode = o.getGroup_adcode();
                String x = o.getX();
                String y = o.getY();
                String city_code = o.getCity_code();
                String aoi_name = o.getAoi_name();
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<CmsAddress> list = Lists.newArrayList(tp._2._2.get());
                    if (StringUtils.isNotEmpty(key_new)) {
                        if (StringUtils.isNotEmpty(group_adcode)) {
                            long size = Arrays.stream(group_adcode.split("\\$")).distinct().count();
                            if (size == 1) {
                                List<CmsAddress> filterList = list.stream().filter(t -> StringUtils.isNotEmpty(t.getAddress_id()) &&
                                        !StringUtils.equals(t.getAddress_id(), address_id) &&
                                        StringUtils.isNotEmpty(t.getKey_new()) &&
                                        StringUtils.equals(max_split_addr, t.getMax_split_addr())).collect(Collectors.toList());
                                if (filterList.size() > 0) {
                                    List<CmsAddress> eqAoiList = filterList.stream().filter(t -> StringUtils.isNotEmpty(aoi_id) && StringUtils.equals(aoi_id, t.getAoi_id())).collect(Collectors.toList());
                                    List<CmsAddress> noEqAoiList = filterList.stream().filter(t -> !(StringUtils.isNotEmpty(aoi_id) && StringUtils.equals(aoi_id, t.getAoi_id()))).collect(Collectors.toList());

                                    List<CmsAddress> eqAoiTagList = eqAoiList.stream().peek(t -> {
                                        String tag = "";
                                        String key_new_b = t.getKey_new();
                                        String key_new_qp_b = t.getKey_new_qp();
                                        if (StringUtils.equals(key_new, key_new_b)) {
                                            tag = "key_同aoi_文本一致";
                                        } else {
                                            if (StringUtils.isNotEmpty(key_new_qp) && StringUtils.equals(key_new_qp, key_new_qp_b)) {
                                                tag = "key_同aoi_全拼一致";
                                            } else {
                                                tag = "key_同aoi_首拼一致";
                                            }
                                        }
                                        t.setTag(tag);
                                    }).collect(Collectors.toList());
                                    temp_list.addAll(eqAoiTagList);

                                    List<CmsAddress> noEqAoiGroupAdcodeFilterList = noEqAoiList.stream().filter(t -> {
                                        String group_adcode_b = t.getGroup_adcode();
                                        if (StringUtils.isNotEmpty(group_adcode_b)) {
                                            long size_b = Arrays.stream(group_adcode_b.split("\\$")).distinct().count();
                                            return size_b == 1;
                                        }
                                        return false;
                                    }).collect(Collectors.toList());

                                    if (noEqAoiGroupAdcodeFilterList.size() > 0) {
                                        List<CmsAddress> distanceXyList = noEqAoiGroupAdcodeFilterList.stream().peek(t -> {
                                            String x_b = t.getX();
                                            String y_b = t.getY();
                                            if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y) && StringUtils.isNotEmpty(x_b) && StringUtils.isNotEmpty(y_b)) {
                                                double distance_xy = DistanceTool.getGreatCircleDistance(Double.parseDouble(x), Double.parseDouble(y), Double.parseDouble(x_b), Double.parseDouble(y_b));
                                                t.setDistance_xy(distance_xy);
                                            }
                                        }).collect(Collectors.toList());

                                        int cnt = 0;
                                        long startTime = System.currentTimeMillis();
                                        for (CmsAddress cmsAddress : distanceXyList) {
                                            String aoi_code_b = cmsAddress.getAoi_code();
                                            String city_code_b = cmsAddress.getCity_code();
                                            cnt = cnt + 1;
                                            if (cnt == limitSec) {
                                                long endTime = System.currentTimeMillis() - startTime;
                                                if (endTime < 1000) {
                                                    logger.error("每秒钟访问量超过限制:{},休眠:{}ms中", limitSec, 1000 - endTime);
                                                    Thread.sleep(1000 - endTime);
                                                }
                                                startTime = System.currentTimeMillis();
                                                cnt = 0;
                                            }
                                            if (StringUtils.isNotEmpty(aoi_code) && StringUtils.isNotEmpty(aoi_code_b)) {
                                                String req = String.format(distanceaoiUrl, aoi_code, city_code, aoi_code_b, city_code_b);
                                                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                                                double distance_aoi = 0;

                                                try {
                                                    distance_aoi = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONObject("direct").getDouble("dist");
                                                } catch (Exception e) {
//                                        e.printStackTrace();
                                                }
                                                cmsAddress.setDistance_aoi(distance_aoi);
                                            }
                                        }
                                        List<CmsAddress> distanceXyTagList = distanceXyList.stream().peek(t -> {
                                            double distance_xy = t.getDistance_xy();
                                            double distance_aoi = t.getDistance_aoi();
                                            String aoi_name_b = t.getAoi_name();
                                            String tag = "";
                                            if (distance_xy < 100) {
                                                tag = "key_跨aoi_坐标距离";
                                            } else {
                                                if (distance_aoi < 100) {
                                                    tag = "key_跨aoi_aoi距离";
                                                } else {
                                                    if (StringUtils.isNotEmpty(aoi_name) && StringUtils.isNotEmpty(aoi_name_b)) {
                                                        String match_a = service.getMatch(aoi_name, "[a-z0-9A-Z东南西北][期|区|座|苑|里]");
                                                        String match_b = service.getMatch(aoi_name_b, "[a-z0-9A-Z东南西北][期|区|座|苑|里]");
                                                        if (StringUtils.isNotEmpty(match_a) && !StringUtils.equals(match_a, match_b)) {
                                                            tag = "key_跨aoi_aoi名称冲突";
                                                        }
                                                    }
                                                }
                                            }
                                            t.setTag(tag);
                                        }).collect(Collectors.toList());
                                        temp_list.addAll(distanceXyTagList);
                                    }
                                }
                                if (temp_list.size() > 0) {
                                    for (CmsAddress cmsAddress : temp_list) {
                                        CmsAddressDuplicate cd = new CmsAddressDuplicate();
                                        cd = service.copy(cd, o, cmsAddress, "key");
                                        result_list.add(cd);
                                    }
                                }
                            }
                        }
                    }
                }
                return result_list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keyWordRdd cnt:{}", keyWordRdd.count());

            spark.sql(String.format("alter table dm_gis.cms_address_std_coincide_judge_key_find drop if EXISTS partition(inc_day='%s',city_code='%s')", date, city));
            DataUtil.saveInto(spark, sc, "dm_gis.cms_address_std_coincide_judge_key_find", CmsAddressDuplicate.class, keyWordRdd, "inc_day", "city_code");
            keyWordRdd.unpersist();

        }
        cmsAoiSchRdd.unpersist();
        aoiAreaAoiRdd.unpersist();

    }
}
