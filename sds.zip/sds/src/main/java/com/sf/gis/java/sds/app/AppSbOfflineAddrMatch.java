package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.sds.pojo.ChknEtlV3;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * 需求：【B库质量提升】审补下线地址匹配错误工艺 _获取lable_score
 * 需求方：谭雨祯（01425216）
 * 研发：匡仁衡（01399581）
 * 任务id：860（新平台）
 */

public class AppSbOfflineAddrMatch {
    private static Logger logger = LoggerFactory.getLogger(AppSbOfflineAddrMatch.class);
    private static String match_url = "http://10.242.5.159:8090/match?input1=%s&input2=%s";
    private static int limitSec = 30 / 5;

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");

        //初始化spark
        SparkSession spark = Spark.getSparkSession("AppSbOfflineAddrMatch", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        String sql = String.format("select\n" +
                "  c.address address,\n" +
                "  c.standard standard,\n" +
                "  c.inc_day inc_day\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      if(\n" +
                "        (\n" +
                "          tag = '1'\n" +
                "          and (\n" +
                "            hasloc = 'true'\n" +
                "            or hasdist = 'true'\n" +
                "          )\n" +
                "          and (\n" +
                "            hastxt = 'false'\n" +
                "            or (\n" +
                "              hastxt = 'true'\n" +
                "              and isbehind = 'false'\n" +
                "            )\n" +
                "          )\n" +
                "        ),\n" +
                "        '模糊地址',\n" +
                "        '非模糊地址'\n" +
                "      ) as is_vague_addr,\n" +
                "      if(\n" +
                "        dept <> ''\n" +
                "        and group_id <> '',\n" +
                "        'norm识别',\n" +
                "        'norm不识别'\n" +
                "      ) as norm_is_identify,\n" +
                "      address,\n" +
                "      standard,\n" +
                "      inc_day\n" +
                "    from\n" +
                "      dm_gis.chkn_etl_v4\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and action != '0'\n" +
                "      and (address is not null and address <> '')\n" +
                "      and (standard is not null and standard <> '')\n" +
                "  ) c\n" +
                "where\n" +
                "  c.is_vague_addr = '非模糊地址'\n" +
                "  and c.norm_is_identify = 'norm识别'\n" +
                "group by\n" +
                "  c.address,\n" +
                "  c.standard,\n" +
                "  c.inc_day", date);
        JavaRDD<ChknEtlV3> rdd = DataUtil.loadData(spark, sc, sql, ChknEtlV3.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

//        JavaRDD<ChknEtlV3> lableRdd = rdd.mapPartitions(itr -> {
//            int cnt = 0;
//            long startTime = System.currentTimeMillis();
//            List<ChknEtlV3> list = new ArrayList<>();
//            while (itr.hasNext()) {
//                cnt = cnt + 1;
//                if (cnt == limitSec) {
//                    long endTime = System.currentTimeMillis() - startTime;
//                    if (endTime < 1000) {
//                        logger.error("每秒钟访问量超过限制:{},休眠:{}ms中", limitSec, 1000 - endTime);
//                        Thread.sleep(1000 - endTime);
//                    }
//                    startTime = System.currentTimeMillis();
//                    cnt = 0;
//                }
//                ChknEtlV3 o = itr.next();
//                String address = o.getAddress();
//                String standard = o.getStandard();
//                if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(standard)) {
//                    String req = String.format(match_url, URLEncoder.encode(address.replace("#", ""), "UTF-8"), URLEncoder.encode(standard.replace("#", ""), "UTF-8"));
//                    String resp = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
//                    logger.error("resp:{}", resp);
//                    o.setMatch_resp(resp);
//                    try {
//                        String label = JSON.parseObject(resp).getJSONObject("result").getString("label");
//                        String score = JSON.parseObject(resp).getJSONObject("result").getString("score");
//
//                        o.setLabel(label);
//                        o.setScore(score);
//                    } catch (Exception e) {
////                    e.printStackTrace();
//                    }
//                }
//                list.add(o);
//            }
//            return list.iterator();
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("lableRdd cnt:{}", lableRdd.count());
//        rdd.unpersist();

        JavaRDD<ChknEtlV3> lableRdd = rdd.repartition(1).map(o -> {
            String address = o.getAddress();
            String standard = o.getStandard();
            if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(standard)) {
                String req = String.format(match_url, URLEncoder.encode(address.replace("#", ""), "UTF-8"), URLEncoder.encode(standard.replace("#", ""), "UTF-8"));
                String resp = HttpInvokeUtil.sendGet(req);
                Thread.sleep(200);
                o.setMatch_resp(resp);
                try {
                    String label = JSON.parseObject(resp).getJSONObject("result").getString("label");
                    String score = JSON.parseObject(resp).getJSONObject("result").getString("score");
                    logger.error("label:{},score:{}", label, score);

                    o.setLabel(label);
                    o.setScore(score);
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lableRdd cnt:{}", lableRdd.count());
        rdd.unpersist();

        spark.sql(String.format("alter table dm_gis.chkn_etl_v3_sb_offline_addr_match drop if EXISTS partition(inc_day='%s')", date));
        saveData(spark, lableRdd, "dm_gis.chkn_etl_v3_sb_offline_addr_match", date);
        lableRdd.unpersist();
        sc.stop();
        logger.error("run end");
    }

    public static void saveData(SparkSession spark, JavaRDD<ChknEtlV3> inRdd, String targetTable, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAddress(), o.getStandard(), o.getLabel(), o.getScore(), o.getMatch_resp()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "address", "standard", "label", "score", "match_resp"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "chkn_etl_v3_sb_offline_addr_match_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);
    }
}
