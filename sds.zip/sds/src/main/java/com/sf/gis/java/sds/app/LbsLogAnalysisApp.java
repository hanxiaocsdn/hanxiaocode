package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.LbsLogAnalysisController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * LBS定位管控日志解析
 *
 * @author 01370539 Created On: Sep.16 2021
 * 任务id：372159（小哥行为管控服务日志解析）
 * 业务方：01408947（刘雨婷）
 * 研发：01399581（匡仁衡）
 */
public class LbsLogAnalysisApp {
    private static final Logger logger = LoggerFactory.getLogger(LbsLogAnalysisApp.class);

    public static void main(String[] args) throws Exception {
        String startDate;
        String endDate;
        if (args != null && args.length >= 2) {
            startDate = args[0];
            endDate = args[1];
        } else {
            String curDate = DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY);
            startDate = DateUtil.getDayBefore(curDate, FixedConstant.DATE_FORMATE_INCDAY, 1);
            endDate = curDate;
        }

        if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
            logger.error("date format must be yyyyMMdd, startDate - {}, endDate - {}", startDate, endDate);
            System.exit(0);
        }

        new LbsLogAnalysisController().process(startDate, endDate);
    }

}
