package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.CityNameMap;
import com.sf.gis.java.sds.pojo.CmsAddress;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class OptimizeAoiXzStdPrepareDataController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(OptimizeAoiXzStdPrepareDataController.class);

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        spark.sql(String.format("alter table dm_gis.cms_address_std_aoi_prepare drop if EXISTS partition(inc_day='%s')", date));


        String city_sql = String.format("select city_name city,prov_name province from dm_gis.dim_city_info_df where inc_day = '%s'", DateUtil.getDaysBefore(date, 2));
        Map<String, String> map = DataUtil.loadData(spark, sc, city_sql, CityNameMap.class).collect().stream().collect(Collectors.toMap(CityNameMap::getCity, CityNameMap::getProvince, (key1, key2) -> key2));
        logger.error("map size:{}", map.size());
        Broadcast<Map<String, String>> mapBc = sc.broadcast(map);

        for (int i = 1; i <= 20; i++) {
            String table = "wchka.cms_address_" + i;
            logger.error("table:{}", table);
            String condition = "type = 1 and status = 1 and aoi_id != ''";

            JavaRDD<CmsAddress> rdd = spark.read().format("jdbc")
                    .option("driver", "com.mysql.jdbc.Driver")
                    .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                    .option("dbtable", table)
                    .option("user", "wchka_aoi")
                    .option("password", "giscmsaoi123")
                    .load()
                    .where(condition)
                    .select("aoi_id", "province", "city", "county", "town")
                    .toJavaRDD()
                    .repartition(400)
                    .map(row -> {
                        String aoi_id = "";
                        String province = "";
                        String city = "";
                        String county = "";
                        String town = "";

                        try {
                            aoi_id = row.getString(0);
                        } catch (Exception e) {
                        }

                        try {
                            province = row.getString(1);
                        } catch (Exception e) {
                        }

                        try {
                            city = row.getString(2);
                        } catch (Exception e) {
                        }

                        try {
                            county = row.getString(3);
                        } catch (Exception e) {
                        }

                        try {
                            town = row.getString(4);
                        } catch (Exception e) {
                        }
                        CmsAddress o = new CmsAddress();
                        o.setAoi_id(aoi_id);
                        o.setProvince(province);
                        o.setCity(city);
                        o.setCounty(county);
                        o.setTown(town);

                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());
            rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<CmsAddress> finalRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey().flatMap(tp -> {
                List<CmsAddress> list = Lists.newArrayList(tp._2);

//                String finalprovince = list.stream().filter(o -> StringUtils.isNotEmpty(o.getProvince()))
//                        .collect(Collectors.groupingBy(o -> o.getProvince()))
//                        .values()
//                        .stream()
//                        .max(Comparator.comparing(l -> l.size()))
//                        .get()
//                        .get(0)
//                        .getProvince();

                String finalcity = "";
                List<CmsAddress> cityList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getCity())).collect(Collectors.toList());
                if (cityList.size() > 0) {
                    finalcity = cityList.stream()
                            .collect(Collectors.groupingBy(o -> o.getCity()))
                            .values()
                            .stream()
                            .max(Comparator.comparing(l -> l.size()))
                            .get()
                            .get(0)
                            .getCity();
                }

                String finalcounty = "";
                List<CmsAddress> countyList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getCounty())).collect(Collectors.toList());
                if (countyList.size() > 0) {
                    finalcounty = countyList.stream()
                            .collect(Collectors.groupingBy(o -> o.getCounty()))
                            .values()
                            .stream()
                            .max(Comparator.comparing(l -> l.size()))
                            .get()
                            .get(0)
                            .getCounty();
                }
                String finalprovince = "";
                if (StringUtils.isNotEmpty(finalcity)) {
                    finalprovince = mapBc.value().get(finalcity);
                }


                String finalProvince = finalprovince;
                String finalCity = finalcity;
                String finalCounty = finalcounty;

                return list.stream().peek(o -> {
                    o.setFinalprovince(finalProvince);
                    o.setFinalcity(finalCity);
                    o.setFinalcounty(finalCounty);
                }).collect(Collectors.toList()).iterator();
            }).filter(o -> StringUtils.isNotEmpty(o.getTown())).map(o -> {
                o.setTown(StringNumUtils.toChinese(o.getTown()));
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            rdd.unpersist();

            JavaRDD<CmsAddress> resultRdd = finalRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey().map(tp -> {
                List<CmsAddress> list = Lists.newArrayList(tp._2);
                int cnt = list.size();
                CmsAddress cmsAddress = list.get(0);

                List<String> after_process_sufix_list = list.stream().map(o -> {
                    String town = o.getTown();
                    String str = town.replaceAll("(街道|地区|街道镇|街道乡|镇|乡)$", "");
                    if (str.length() >= 2) {
                        return str;
                    } else {
                        return town;
                    }
                }).collect(Collectors.toList());

                List<String> max_list = after_process_sufix_list.stream()
                        .collect(Collectors.groupingBy(o -> o))
                        .values()
                        .stream()
                        .max(Comparator.comparing(l -> l.size()))
                        .get();
                String max_word = max_list.get(0);
                int max_cnt = max_list.size();

                double freq5_norm = (double) max_cnt / (double) cnt;
                cmsAddress.setFreq5_norm(freq5_norm + "");

                String final_word = list.stream().filter(o -> o.getTown().contains(max_word))
                        .collect(Collectors.groupingBy(o -> o.getTown()))
                        .values()
                        .stream()
                        .max(Comparator.comparing(l -> l.size()))
                        .get()
                        .get(0)
                        .getTown();
                cmsAddress.setL5_norm(final_word);
                return cmsAddress;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            finalRdd.unpersist();

            saveData(spark, resultRdd, "dm_gis.cms_address_std_aoi_prepare", date);
            resultRdd.unpersist();
        }
        sc.stop();
    }


    public void saveData(SparkSession spark, JavaRDD<CmsAddress> inRdd, String table, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAoi_id(), o.getFinalprovince(), o.getFinalcity(), o.getFinalcounty(), o.getL5_norm(), o.getFreq5_norm()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "aoi_id", "finalprovince", "finalcity", "finalcounty", "l5_norm", "freq5_norm"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "cms_address_std_aoi_prepare_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", table, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

}
