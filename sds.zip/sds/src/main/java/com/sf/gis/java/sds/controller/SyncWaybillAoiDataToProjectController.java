package com.sf.gis.java.sds.controller;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.enumtype.AoiRecordType;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.enumtype.MapType;
import com.sf.gis.java.sds.service.ProDbService;
import com.sf.gis.java.sds.service.SyncWaybillAoiDataToProjectService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class SyncWaybillAoiDataToProjectController {
    private SyncWaybillAoiDataToProjectService service;
    //    private Map<String, String> configMap;
    private static final Logger logger = LoggerFactory.getLogger(SyncWaybillAoiDataToProjectController.class);

    public SyncWaybillAoiDataToProjectController() {
        service = new SyncWaybillAoiDataToProjectService();
//        this.configMap = configMap;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void start(String beginDate, String dataType,
                      String syncCityStr, String project) throws Exception {
        Set<String> syncCityList = new HashSet(Arrays.asList(syncCityStr.trim().split(",")));
        syncCityList.remove("");
//        String project = configMap.get(ConfigKey.project_type.name());
//		if(beginDate != null){
//        String checkDate = DateUtil.getCurrentDateBefore("yyyyMMdd",2);
//        for(int i = 0; i < days;i++){
//        String argDate = DateUtil.getDayBefore(beginDate, "yyyyMMdd", 0 - i);
//            if(argDate.equals(checkDate)){
        logger.error("当前日期为2天前，需要检测数据是否存在:" + beginDate);
        while (!service.checkDataExist(beginDate, dataType)) {
            logger.error("日期数据不存在");
//					if(new Date().getHours()>=17){
//						LogUtil.e("超过17点，报错~");
//						throw new Exception();
//					}
            Thread.sleep(5 * 60 * 1000);
            continue;
        }
//            }
        startSync(beginDate, project,
                dataType, syncCityList);
//        }

        return;

//		}
        // 测试使用
//		daysAgo = 728;
//		for (int i = daysAgo; i >=0 ; i--) {
//			String dataTime = DateUtils.getDaysAgoSingle(daysAgo - i, "yyyyMMdd");
////			if (Integer.valueOf(dataTime) < 20200413 || Integer.valueOf(dataTime) > 20200413) {
////				// 测试使用
////				continue;
////			}
//			startSync(dataTime,project,
//					dataType,syncCityList);
//		}

    }

    @SuppressWarnings({"unchecked", "rawtypes"})
//    public void startDuomi(String beginDate, int days) throws Exception {
//        String dataType = configMap.get(ConfigKey.data_type.name());
////		int daysAgo = Integer.valueOf(configMap.get(ConfigKey.days.name()));
////		int save_sta_day = Integer.valueOf(configMap.get(ConfigKey.save_sta_day.name()));
//        Set<String> syncCityList = new HashSet(Arrays.asList(configMap.get(ConfigKey.sync_city.name()).trim().split(",")));
//        syncCityList.remove("");
////		String project = configMap.get(ConfigKey.project_type.name());
////		if(beginDate != null){
//        String checkDate = DateUtil.getCurrentDateBefore("yyyyMMdd", 2);
//        for (int i = 0; i < days; i++) {
//            String argDate = DateUtil.getDayBefore(beginDate, "yyyyMMdd", 0 - i);
//            if (argDate.equals(checkDate)) {
//                logger.error("当前日期为2天前，需要检测数据是否存在:" + checkDate);
//                while (!service.checkDataExist(argDate, dataType)) {
//                    logger.error("日期数据不存在");
//                    if (new Date().getHours() >= 17) {
//                        logger.error("超过17点，报错~");
//                        throw new Exception();
//                    }
//                    Thread.sleep(5 * 60 * 1000);
//                    continue;
//                }
//            }
//            startSyncDuomi(argDate,
//                    dataType, syncCityList);
//        }
//
//        return;
//    }

    private void startSyncDuomi(String dataTime,
                                String dataType, Set<String> syncCityList) {
        logger.error(dataTime);
        long count = calProjectInfoDuomi(dataType, dataTime, syncCityList);
        if (count != 0) {
            service.syncWaybillAoiToProjectDuomi(dataType, dataTime, syncCityList);
        }
    }

    private void startSync(String dataTime, String project,
                           String dataType, Set<String> syncCityList) {
        logger.error(dataTime);
        long count = calProjectInfo(project, dataType, dataTime, syncCityList);
        if (count != 0) {
            service.syncWaybillAoiToProject(project, dataType, dataTime, syncCityList);
        }
    }

    /**
     * 处理治愈相关
     */
    private long calProjectInfo(String project, String dataType, String date, Set<String> targetCity) {
        long count = -1;
        try {
            try {
                count = service.calAddDataCount(targetCity, date, dataType);
                ProDbService proDbService = new ProDbService();
                String tmpDataType = null;
                if (dataType.equals(MapType.shou.name())) {
                    tmpDataType = "A";
                } else if (dataType.equals(MapType.pai.name())) {
                    tmpDataType = "B";
                }
                proDbService.insertIntoAoiRecordOfAdd(AoiRecordType.add, "", "", count, date, date, tmpDataType,
                        project);
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return count;
    }

    private long calProjectInfoDuomi(String dataType, String date, Set<String> targetCity) {
        long count = -1;
        try {
            try {
                count = service.calAddDataCount(targetCity, date, dataType);
                ProDbService proDbService = new ProDbService();
                String tmpDataType = null;
                if (dataType.equals(MapType.shou.name())) {
                    tmpDataType = "A";
                } else if (dataType.equals(MapType.pai.name())) {
                    tmpDataType = "B";
                }
                proDbService.insertIntoAoiRecordOfAdd(AoiRecordType.add, "", "", count, date, date, tmpDataType,
                        "dmxq");
            } catch (Exception e) {
                logger.error(e.getMessage());
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
        return count;
    }
}
