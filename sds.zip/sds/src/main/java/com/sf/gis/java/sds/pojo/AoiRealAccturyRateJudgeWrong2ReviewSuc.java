package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiRealAccturyRateJudgeWrong2ReviewSuc implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;

    @Column(name = "city_code")
    private String city_code;

    @Column(name = "dept")
    private String dept;

    @Column(name = "inc_day")
    private String inc_day;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
