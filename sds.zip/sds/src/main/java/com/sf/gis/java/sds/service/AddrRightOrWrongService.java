package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AddrRightOrWrongService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AddrRightOrWrongService.class);

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadAoiRealAccturyRateJudgeWrongOperation(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("aoi_real_acctury_rate_judge_wrong_operation.sql", startDate, endDate);
        logger.error("aoi_real_acctury_rate_judge_wrong_operation sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

    public void saveData(SparkSession spark, JavaRDD<AoiRealAccturyRateJudgeWrongOperation> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybillno(), o.getCity_code(), o.getOrg_code(), o.getUserid(), o.getOperatime_new(), o.getDelivery_lgt(),
                    o.getDelivery_lat(), o.getInc_day_gd(), o.getReq_waybillno(), o.getReq_destcitycode(), o.getReq_addresseeaddr(), o.getReq_comp_name(),
                    o.getFinalzc(), o.getFinalaoicode(), o.getFinalaoiid(), o.getReq_time(), o.getGis_to_sys_groupid(), o.getGisaoisrc(),
                    o.getSplitresult(), o.getGj_aoiid_t(), o.getGj_aoicode_t(), o.getGj_aoiname_t(), o.getStarttime(), o.getEndtime(),
                    o.getGjaoi_frq(), o.getInc_day_gj(), o.getTag1(), o.getTag2(), o.getR_aoi(), o.getKey_word(),
                    o.getKey_tag(), o.getLast14(), o.getLast13(), o.getLast613(), o.getGisaoicode_rds(), o.getKsaoicode(),
                    o.getMapa_aoiid(), o.getMapa_aoicode(), o.getMapa_aoiname(), o.getGd_aoiid(), o.getGd_aoicode(), o.getGd_aoiname(),
                    o.getGd_start(), o.getGd_end(), o.getGis_aoi_code(), o.getGis_aoi_name(), o.getGis_splitinfo_info(), o.getAoi_80_code(),
                    o.getAoi_80_name(), o.getSplitinfo_80_info(), o.getArss_dept_re_body(), o.getArss_dept_req_body(), o.getAoi_dept_req_body_latest(), o.getAoi_dept_re_body_latest(),
                    o.getAoi_id_lag(), o.getAoi_id_lead(), o.getOperatime_new_lag(), o.getOperatime_new_lead(), o.getErrortype(), o.getTag3(),
                    o.getLabel(), o.getGroup_freq(), o.getRight_freq(), o.getWrong_freq(), o.getOther_freq(), o.getRight_percent(), o.getInc_day()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "waybillno", "city_code", "org_code", "userid", "operatime_new", "delivery_lgt",
                "delivery_lat", "inc_day_gd", "req_waybillno", "req_destcitycode", "req_addresseeaddr", "req_comp_name",
                "finalzc", "finalaoicode", "finalaoiid", "req_time", "gis_to_sys_groupid", "gisaoisrc",
                "splitresult", "gj_aoiid_t", "gj_aoicode_t", "gj_aoiname_t", "starttime", "endtime",
                "gjaoi_frq", "inc_day_gj", "tag1", "tag2", "r_aoi", "key_word",
                "key_tag", "last14", "last13", "last613", "gisaoicode_rds", "ksaoicode",
                "mapa_aoiid", "mapa_aoicode", "mapa_aoiname", "gd_aoiid", "gd_aoicode", "gd_aoiname",
                "gd_start", "gd_end", "gis_aoi_code", "gis_aoi_name", "gis_splitinfo_info", "80_aoi_code",
                "80_aoi_name", "80_splitinfo_info", "arss_dept_re_body", "arss_dept_req_body", "aoi_dept_req_body_latest", "aoi_dept_re_body_latest",
                "aoi_id_lag", "aoi_id_lead", "operatime_new_lag", "operatime_new_lead", "errortype", "tag3",
                "label", "group_freq", "right_freq", "wrong_freq", "other_freq", "right_percent", "inc_day"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "aoi_real_acctury_rate_judge_wrong_operation_week_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.aoi_real_acctury_rate_judge_wrong_operation_week_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(operate_date = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
