package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.pojo.LbsLogPnsAoi;
import com.sf.gis.java.sds.pojo.LbsLogPnsAoiStat;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * LBS定位管控日志解析
 *
 * @author 01370539 Created On: Sep.16 2021
 */
public class LbsLogAnalysisService {

    private static final Logger logger = LoggerFactory.getLogger(LbsLogAnalysisService.class);

    /**
     * 加载原始日志
     *
     * @param sparkInfo spark相关信息
     * @param startDate 加载某一周期内的数据，周期开始时间
     * @param endDate   加载某一周期内的数据，周期结束时间
     * @return 原始日志
     */
    public JavaRDD<Row> loadOrigLog(SparkInfo sparkInfo, String startDate, String endDate) {
        String sql = "select log from dm_gis.lbs_log_kafka_pnsaoi where inc_day between '" + startDate + "' and '" + endDate + "'";
        return DataUtil.loadData(sparkInfo.getSession(), sql);
    }


    public JavaRDD<Row> loadOrigLog2(SparkInfo sparkInfo, String startDate, String endDate) {
        String sql = String.format("select log from dm_gis.lbs_log_kafka_pnsaoi where inc_day between '%s' and '%s' and log like '%%empStdRslt%%'", startDate, endDate);
        return DataUtil.loadData(sparkInfo.getSession(), sql);
    }


    public JavaRDD<Row> loadOrigLog3(SparkInfo sparkInfo, String startDate, String endDate) {
        String sql = String.format("select log from dm_gis.lbs_log_kafka_pnsaoi where inc_day between '%s' and '%s' and log like '%%wifiList%%'", startDate, endDate);
        return DataUtil.loadData(sparkInfo.getSession(), sql);
    }


    /**
     * 解析日志
     *
     * @param rddRow   日志数据
     * @param statDate 只解析改解析的日志，此日志的过滤时间
     * @return 解析完成的日志数据
     */
    public JavaRDD<LbsLogPnsAoi> analysis(JavaRDD<Row> rddRow, String statDate) {
        logger.error("analysis log, analysis count: {}", rddRow.count());
        return rddRow.map(row -> {
            LbsLogPnsAoi result = new LbsLogPnsAoi();
            try {
                if (StringUtils.isNotEmpty(row.getString(0))) {
                    JSONObject json = JSONObject.parseObject(row.getString(0));
                    result.setIncDay(statDate);
                    result.setMsgTm(DateUtil.getDateStrFromUsStr(json.getString("@timestamp"), "yyyyMMdd"));
                    String message = json.getString("message");
                    if (StringUtils.isNotEmpty(message)) {
                        int startIndex = message.indexOf("{");
                        int endIndex = message.lastIndexOf("}");
                        if (startIndex < endIndex) {
                            String ctx = message.substring(startIndex, endIndex + 1);
                            JSONObject ctxJson = JSONObject.parseObject(ctx);
                            result.setGid(ctxJson.getString("gid"));
                            result.setCity(ctxJson.getString("city"));
                            result.setEmployeeId(ctxJson.getString("employeeId"));
                            result.setAoiId(ctxJson.getString("aoiId"));
                            result.setEmpAoi(ctxJson.getString("empAoi"));
                            result.setWaybillNo(ctxJson.getString("waybillNo"));
                            result.setAddress(ctxJson.getString("address"));
                            result.setCompany(ctxJson.getString("company"));
                            result.setTracks(ctxJson.getString("tracks"));
                            result.setStandard(ctxJson.getString("standard"));
                            result.setMatchType(ctxJson.getString("matchType"));
                            result.setAoiSideDistance(ctxJson.getString("aoiSideDistance"));
                            result.setCurrentTm(DateUtil.getDateFromLongStr(ctxJson.getString("currentTm"), "yyyy-MM-dd HH:mm:ss.SSS"));
                            String poiId = ctxJson.getString("poiId");
                            if (StringUtils.isNotEmpty(poiId)) {
                                result.setPoiId(poiId.replace("|", ""));
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        });
    }

    public JavaRDD<LbsLogPnsAoi> analysis2(JavaRDD<Row> rddRow, String statDate) {
        logger.error("analysis log, analysis count: {}", rddRow.count());
        return rddRow.map(row -> {
            LbsLogPnsAoi result = new LbsLogPnsAoi();
            try {
                if (StringUtils.isNotEmpty(row.getString(0))) {
                    JSONObject json = JSONObject.parseObject(row.getString(0));
                    result.setIncDay(statDate);
                    result.setMsgTm(DateUtil.getDateStrFromUsStr(json.getString("@timestamp"), "yyyyMMdd"));
                    JSONObject message = json.getJSONObject("message");
                    if (message != null) {
                        JSONObject data = message.getJSONObject("data");
                        if (data != null) {
                            JSONObject result1 = data.getJSONObject("result");
                            if (result1 != null) {
                                String gid = result1.getString("gid");
                                String standard = result1.getString("standard");
                                String type = result1.getString("type");

                                result.setGid(gid);
                                result.setStandardResult(standard);
                                result.setTypeResult(type);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        });
    }

    public JavaRDD<LbsLogPnsAoi> analysis3(JavaRDD<Row> rddRow, String statDate) {
        logger.error("analysis log, analysis count: {}", rddRow.count());
        return rddRow.map(row -> {
            LbsLogPnsAoi result = new LbsLogPnsAoi();
            try {
                if (StringUtils.isNotEmpty(row.getString(0))) {
                    JSONObject json = JSONObject.parseObject(row.getString(0));
                    result.setIncDay(statDate);
                    result.setMsgTm(DateUtil.getDateStrFromUsStr(json.getString("@timestamp"), "yyyyMMdd"));
                    String message = json.getString("message");
                    if (StringUtils.isNotEmpty(message)) {
                        int startIndex = message.indexOf("{");
                        int endIndex = message.lastIndexOf("}");
                        if (startIndex < endIndex) {
                            String ctx = message.substring(startIndex, endIndex + 1);
                            JSONObject ctxJson = JSONObject.parseObject(ctx);
                            result.setGid(ctxJson.getString("gid"));
                            result.setWifilist(ctxJson.getString("wifiList"));
                            result.setWifimatchaddresslist(ctxJson.getString("wifiMatchAddressList"));
                            result.setWifimatchtype(ctxJson.getString("wifiMatchType"));

                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        });
    }

    public JavaRDD<LbsLogPnsAoi> join(JavaRDD<LbsLogPnsAoi> rddLog1, JavaRDD<LbsLogPnsAoi> rddLog2) {
        JavaRDD<LbsLogPnsAoi> noEmpRdd = rddLog1.filter(o -> StringUtils.isNotEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<LbsLogPnsAoi> empRdd = rddLog1.filter(o -> StringUtils.isEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpRdd cnt:{}", noEmpRdd.count());
        logger.error("empRdd cnt:{}", empRdd.count());
        rddLog1.unpersist();

        return noEmpRdd.mapToPair(o -> new Tuple2<>(o.getGid(), o))
                .leftOuterJoin(rddLog2.mapToPair(o -> new Tuple2<>(o.getGid(), o)).reduceByKey((o1, o2) -> o1)).repartition(1200)
                .map(tp -> {
                    LbsLogPnsAoi o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        LbsLogPnsAoi lbsLogPnsAoi = tp._2._2.get();
                        o.setStandardResult(lbsLogPnsAoi.getStandardResult());
                        o.setTypeResult(lbsLogPnsAoi.getTypeResult());
                    }
                    return o;
                }).union(empRdd);
    }


    public JavaRDD<LbsLogPnsAoi> join2(JavaRDD<LbsLogPnsAoi> rddLog1, JavaRDD<LbsLogPnsAoi> rddLog2) {
        JavaRDD<LbsLogPnsAoi> noEmpRdd = rddLog1.filter(o -> StringUtils.isNotEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<LbsLogPnsAoi> empRdd = rddLog1.filter(o -> StringUtils.isEmpty(o.getGid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpRdd cnt:{}", noEmpRdd.count());
        logger.error("empRdd cnt:{}", empRdd.count());
        rddLog1.unpersist();

        return noEmpRdd.mapToPair(o -> new Tuple2<>(o.getGid(), o))
                .leftOuterJoin(rddLog2.mapToPair(o -> new Tuple2<>(o.getGid(), o)).reduceByKey((o1, o2) -> o1)).repartition(1200)
                .map(tp -> {
                    LbsLogPnsAoi o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        LbsLogPnsAoi lbsLogPnsAoi = tp._2._2.get();
                        o.setWifilist(lbsLogPnsAoi.getWifilist());
                        o.setWifimatchtype(lbsLogPnsAoi.getWifimatchtype());
                        o.setWifimatchaddresslist(lbsLogPnsAoi.getWifimatchaddresslist());
                    }
                    return o;
                }).union(empRdd);
    }
    public JavaRDD<LbsLogPnsAoiStat> analysisStat(JavaSparkContext sc, JavaRDD<LbsLogPnsAoi> rddLog, String date) {
        return rddLog.map(o -> {
            String city = o.getCity();
            int standardNum = StringUtils.equals(o.getStandard(), "1") ? 1 : 0;
            int lessTracks = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "LESS_TRACKS")) ? 1 : 0;
            int standard = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "STANDARD")) ? 1 : 0;
            int emptyTracks = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "EMPTY_TRACKS")) ? 1 : 0;
            int notAoiErr = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "NOT_AOI_ERR")) ? 1 : 0;
            int paramErr = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "PARAM_ERR")) ? 1 : 0;
            int unknownGid = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "UNKNOWN_GID")) ? 1 : 0;
            int unknownErr = (StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "UNKNOWN_ERR")) ? 1 : 0;
            int noStandardNum = (StringUtils.equals(o.getStandard(), "0")) ? 1 : 0;
            int aoiSideLimit = (StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "AOI_SIDE_LIMIT")) ? 1 : 0;
            int aoiDistanceLimit = (StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "AOI_DISTANCE_LIMIT")) ? 1 : 0;
            int poiSideLimit = (StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "POI_LIMIT")) ? 1 : 0;

            LbsLogPnsAoiStat lbsLogPnsAoiStat = new LbsLogPnsAoiStat();
            lbsLogPnsAoiStat.setStandardNum(standardNum + "");
            lbsLogPnsAoiStat.setLessTracks(lessTracks + "");
            lbsLogPnsAoiStat.setStandard(standard + "");
            lbsLogPnsAoiStat.setEmptyTracks(emptyTracks + "");
            lbsLogPnsAoiStat.setNotAoiErr(notAoiErr + "");
            lbsLogPnsAoiStat.setParamErr(paramErr + "");
            lbsLogPnsAoiStat.setUnknownGid(unknownGid + "");
            lbsLogPnsAoiStat.setUnknownErr(unknownErr + "");
            lbsLogPnsAoiStat.setNoStandardNum(noStandardNum + "");
            lbsLogPnsAoiStat.setAoiSideLimit(aoiSideLimit + "");
            lbsLogPnsAoiStat.setAoiDistanceLimit(aoiDistanceLimit + "");
            lbsLogPnsAoiStat.setPoiSideLimit(poiSideLimit + "");
            lbsLogPnsAoiStat.setCityCode(city);
            lbsLogPnsAoiStat.setIncDay(date);
            return lbsLogPnsAoiStat;
        }).mapToPair(o -> new Tuple2<>(o.getCityCode(), o)).reduceByKey((o1, o2) -> {
            o1.setStandardNum((Integer.parseInt(o1.getStandardNum()) + Integer.parseInt(o2.getStandardNum())) + "");
            o1.setLessTracks((Integer.parseInt(o1.getLessTracks()) + Integer.parseInt(o2.getLessTracks())) + "");
            o1.setStandard((Integer.parseInt(o1.getStandard()) + Integer.parseInt(o2.getStandard())) + "");
            o1.setEmptyTracks((Integer.parseInt(o1.getEmptyTracks()) + Integer.parseInt(o2.getEmptyTracks())) + "");
            o1.setNotAoiErr((Integer.parseInt(o1.getNotAoiErr()) + Integer.parseInt(o2.getNotAoiErr())) + "");
            o1.setParamErr((Integer.parseInt(o1.getParamErr()) + Integer.parseInt(o2.getParamErr())) + "");
            o1.setUnknownGid((Integer.parseInt(o1.getUnknownGid()) + Integer.parseInt(o2.getUnknownGid())) + "");
            o1.setUnknownErr((Integer.parseInt(o1.getUnknownErr()) + Integer.parseInt(o2.getUnknownErr())) + "");
            o1.setNoStandardNum((Integer.parseInt(o1.getNoStandardNum()) + Integer.parseInt(o2.getNoStandardNum())) + "");
            o1.setAoiSideLimit((Integer.parseInt(o1.getAoiSideLimit()) + Integer.parseInt(o2.getAoiSideLimit())) + "");
            o1.setAoiDistanceLimit((Integer.parseInt(o1.getAoiDistanceLimit()) + Integer.parseInt(o2.getAoiDistanceLimit())) + "");
            o1.setPoiSideLimit((Integer.parseInt(o1.getPoiSideLimit()) + Integer.parseInt(o2.getPoiSideLimit())) + "");
            return o1;
        }).map(tp -> tp._2);


//        return rddLog.mapToPair(o -> new Tuple2<>(o.getCity(), o)).groupByKey().repartition(2400).map(tp -> {
//            List<LbsLogPnsAoi> list = Lists.newArrayList(tp._2);
//            LbsLogPnsAoi lbsLogPnsAoi = list.get(0);
//            String city = lbsLogPnsAoi.getCity();
//
//            int standardNum = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1")).collect(Collectors.toList()).size();
//            int lessTracks = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "LESS_TRACKS")).collect(Collectors.toList()).size();
//            int standard = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "STANDARD")).collect(Collectors.toList()).size();
//            int emptyTracks = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "EMPTY_TRACKS")).collect(Collectors.toList()).size();
//            int notAoiErr = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "NOT_AOI_ERR")).collect(Collectors.toList()).size();
//            int paramErr = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "PARAM_ERR")).collect(Collectors.toList()).size();
//            int unknownGid = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "UNKNOWN_GID")).collect(Collectors.toList()).size();
//            int unknownErr = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "1") && StringUtils.equals(o.getMatchType(), "UNKNOWN_ERR")).collect(Collectors.toList()).size();
//            int noStandardNum = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "0")).collect(Collectors.toList()).size();
//            int aoiSideLimit = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "AOI_SIDE_LIMIT")).collect(Collectors.toList()).size();
//            int aoiDistanceLimit = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "AOI_DISTANCE_LIMIT")).collect(Collectors.toList()).size();
//            int poiSideLimit = list.stream().filter(o -> StringUtils.equals(o.getStandard(), "0") && StringUtils.equals(o.getMatchType(), "POI_LIMIT")).collect(Collectors.toList()).size();
//
//            LbsLogPnsAoiStat lbsLogPnsAoiStat = new LbsLogPnsAoiStat();
//            lbsLogPnsAoiStat.setStandardNum(standardNum + "");
//            lbsLogPnsAoiStat.setLessTracks(lessTracks + "");
//            lbsLogPnsAoiStat.setStandard(standard + "");
//            lbsLogPnsAoiStat.setEmptyTracks(emptyTracks + "");
//            lbsLogPnsAoiStat.setNotAoiErr(notAoiErr + "");
//            lbsLogPnsAoiStat.setParamErr(paramErr + "");
//            lbsLogPnsAoiStat.setUnknownGid(unknownGid + "");
//            lbsLogPnsAoiStat.setUnknownErr(unknownErr + "");
//            lbsLogPnsAoiStat.setNoStandardNum(noStandardNum + "");
//            lbsLogPnsAoiStat.setAoiSideLimit(aoiSideLimit + "");
//            lbsLogPnsAoiStat.setAoiDistanceLimit(aoiDistanceLimit + "");
//            lbsLogPnsAoiStat.setPoiSideLimit(poiSideLimit + "");
//            lbsLogPnsAoiStat.setCityCode(city);
//            lbsLogPnsAoiStat.setIncDay(date);
//            return lbsLogPnsAoiStat;
//        });
    }

}
