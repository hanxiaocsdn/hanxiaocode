package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class FvpCoreFactRouteOverRangeZjStat implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "stat_type")
    private String stat_type;
    @Column(name = "stat_type_content")
    private String stat_type_content;
    @Column(name = "stat_date")
    private String stat_date;
    @Column(name = "province_name")
    private String province_name;
    @Column(name = "city_name")
    private String city_name;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "cnt")
    private String cnt;
    @Column(name = "bsp_cnt")
    private String bsp_cnt;
    @Column(name = "cx_cnt")
    private String cx_cnt;
    @Column(name = "other_cnt")
    private String other_cnt;
    @Column(name = "contract_cnt")
    private String contract_cnt;
    @Column(name = "no_contract_cnt")
    private String no_contract_cnt;
    @Column(name = "ziqu_cnt")
    private String ziqu_cnt;
    @Column(name = "no_ziqu_cnt")
    private String no_ziqu_cnt;
    @Column(name = "qg_cnt")
    private String qg_cnt;
    @Column(name = "inc_day")
    private String inc_day;

    public String getQg_cnt() {
        return qg_cnt;
    }

    public void setQg_cnt(String qg_cnt) {
        this.qg_cnt = qg_cnt;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getStat_date() {
        return stat_date;
    }

    public void setStat_date(String stat_date) {
        this.stat_date = stat_date;
    }

    public String getProvince_name() {
        return province_name;
    }

    public void setProvince_name(String province_name) {
        this.province_name = province_name;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getCnt() {
        return cnt;
    }

    public void setCnt(String cnt) {
        this.cnt = cnt;
    }

    public String getBsp_cnt() {
        return bsp_cnt;
    }

    public void setBsp_cnt(String bsp_cnt) {
        this.bsp_cnt = bsp_cnt;
    }

    public String getCx_cnt() {
        return cx_cnt;
    }

    public void setCx_cnt(String cx_cnt) {
        this.cx_cnt = cx_cnt;
    }

    public String getOther_cnt() {
        return other_cnt;
    }

    public void setOther_cnt(String other_cnt) {
        this.other_cnt = other_cnt;
    }

    public String getContract_cnt() {
        return contract_cnt;
    }

    public void setContract_cnt(String contract_cnt) {
        this.contract_cnt = contract_cnt;
    }

    public String getNo_contract_cnt() {
        return no_contract_cnt;
    }

    public void setNo_contract_cnt(String no_contract_cnt) {
        this.no_contract_cnt = no_contract_cnt;
    }

    public String getZiqu_cnt() {
        return ziqu_cnt;
    }

    public void setZiqu_cnt(String ziqu_cnt) {
        this.ziqu_cnt = ziqu_cnt;
    }

    public String getNo_ziqu_cnt() {
        return no_ziqu_cnt;
    }

    public void setNo_ziqu_cnt(String no_ziqu_cnt) {
        this.no_ziqu_cnt = no_ziqu_cnt;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
