package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.service.AddrRightOrWrongService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AddrRightOrWrongController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AddrRightOrWrongController.class);
    AddrRightOrWrongService service = new AddrRightOrWrongService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        String today = DateUtil.getDaysBefore(0, "yyyyMMdd");
        logger.error("stat date:{}", today);
        logger.error("获取数据源");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> aoiRealAccturyRateJudgeWrongOperationRdd = service.loadAoiRealAccturyRateJudgeWrongOperation(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRealAccturyRateJudgeWrongOperationRdd cnt:{}", aoiRealAccturyRateJudgeWrongOperationRdd.count());
        aoiRealAccturyRateJudgeWrongOperationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("norm标签数据");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> normRdd = aoiRealAccturyRateJudgeWrongOperationRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:{}", normRdd.count());

        logger.error("chkn标签数据");
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> chknRdd = aoiRealAccturyRateJudgeWrongOperationRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "chkn")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("chknRdd cnt:{}", chknRdd.count());

        aoiRealAccturyRateJudgeWrongOperationRdd.unpersist();

        logger.error("norm 统计");
        normRdd = normRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).groupByKey().flatMap(tp -> {
            List<AoiRealAccturyRateJudgeWrongOperation> list = Lists.newArrayList(tp._2);
            int size = list.size();
            int right = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "right")).collect(Collectors.toList()).size();
            int wrong = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "wrong")).collect(Collectors.toList()).size();
            int other = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "other")).collect(Collectors.toList()).size();
            double right_percent = (double) right / (double) (right + wrong);

            list = list.stream().map(o -> {
                o.setGroup_freq(size + "");
                o.setRight_freq(right + "");
                o.setWrong_freq(wrong + "");
                o.setOther_freq(other + "");
                o.setRight_percent(right_percent + "");

                return o;
            }).collect(Collectors.toList());
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:{}", normRdd.count());
        normRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("chkn 统计");
        chknRdd = chknRdd.mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o)).groupByKey().flatMap(tp -> {
            List<AoiRealAccturyRateJudgeWrongOperation> list = Lists.newArrayList(tp._2);
            int size = list.size();
            int right = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "right")).collect(Collectors.toList()).size();
            int wrong = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "wrong")).collect(Collectors.toList()).size();
            int other = list.stream().filter(o -> StringUtils.equals(o.getLabel(), "other")).collect(Collectors.toList()).size();
            double right_percent = (double) right / (double) (right + wrong);

            list = list.stream().map(o -> {
                o.setGroup_freq(size + "");
                o.setRight_freq(right + "");
                o.setWrong_freq(wrong + "");
                o.setOther_freq(other + "");
                o.setRight_percent(right_percent + "");

                return o;
            }).collect(Collectors.toList());
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("chknRdd cnt:{}", chknRdd.count());
        chknRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> finalRdd = normRdd.union(chknRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalRdd cnt:{}", finalRdd.count());
        finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        normRdd.unpersist();
        chknRdd.unpersist();

        logger.error("数据入库");
        service.saveData(spark, finalRdd, today);
        finalRdd.unpersist();

        spark.stop();
    }
}
