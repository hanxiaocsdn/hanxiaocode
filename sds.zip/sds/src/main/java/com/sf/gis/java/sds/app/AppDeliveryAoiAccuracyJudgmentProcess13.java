package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.base.util.StringNumUtils;
import com.sf.gis.scala.base.spark.SparkRead;
import com.sf.gis.scala.base.spark.SparkWrite;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务id:1002585（派件aoi准确率判断工艺13）
 * 研发:01399581（匡仁衡）
 * 业务:01424110（喻少丰）
 */
public class AppDeliveryAoiAccuracyJudgmentProcess13 {
    private static final Logger logger = Logger.getLogger(AppDeliveryAoiAccuracyJudgmentProcess13.class);
    private static final String[] saveKey = new String[]{"waybillno", "city_code", "org_code", "userid", "operatime_new", "delivery_lgt", "delivery_lat", "inc_day_gd", "req_waybillno", "req_destcitycode", "req_addresseeaddr", "req_comp_name", "finalzc", "finalaoicode", "finalaoiid", "req_time", "gis_to_sys_groupid", "gisaoisrc", "splitresult", "gj_aoiid_t", "gj_aoicode_t", "gj_aoiname_t", "starttime", "endtime", "gjaoi_frq", "inc_day_gj", "tag1", "tag2", "r_aoi", "key_word", "key_tag", "last14", "last13", "last613", "gisaoicode_rds", "ksaoicode", "mapa_aoiid", "mapa_aoicode", "mapa_aoiname", "gd_aoiid", "gd_aoicode", "gd_aoiname", "gd_start", "gd_end", "gis_aoi_code", "gis_aoi_name", "gis_splitinfo_info", "80_aoi_code", "80_aoi_name", "80_splitinfo_info", "arss_dept_re_body", "arss_dept_req_body", "aoi_dept_req_body_latest", "aoi_dept_re_body_latest", "aoi_id_lag", "aoi_id_lead", "operatime_new_lag", "operatime_new_lead", "errortype", "tag3", "bottomcorrected", "adcode", "nr_aoiid", "gd_ps_aoiid",
            "lvl113name", "type_113", "lvl213name", "type_213", "lvl911name", "type_911", "lvl613name", "type_613", "lvl214name", "type_214", "new_tag1", "new_tag2", "new_tag3"};


    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppDeliveryAoiAccuracyJudgmentProcess13");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        logger.error("取数");
        JavaRDD<JSONObject> rdd = getData(spark, date);
        logger.error("获取name");
        JavaRDD<JSONObject> nameRdd = process(rdd);
        logger.error("分组比较");
        JavaRDD<JSONObject> lastRdd = compare(nameRdd);
        logger.error("存储");
        SparkWrite.save2HiveStaticNew(spark, lastRdd.rdd(), saveKey, "dm_gis.dm_aoi_real_acctury_rate_judge_bottomcorrected_2024_process13_di", new Tuple2[]{new Tuple2<>("inc_day", date)}, 10, SaveMode.Overwrite, true);
        lastRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static JavaRDD<JSONObject> compare(JavaRDD<JSONObject> nameRdd) {
        JavaRDD<JSONObject> lastRdd = nameRdd.mapToPair(o -> new Tuple2<>(o.getString("finalzc"), o)).groupByKey().flatMap(tp -> {
            List<JSONObject> list = Lists.newArrayList(tp._2);
            List<JSONObject> judge_list = list.stream().filter(o -> "no".equals(o.getString("tag1")) || "fin_lead_lag".equals(o.getString("tag2"))).collect(Collectors.toList());
            List<JSONObject> compare_list = list.stream().filter(o -> "wrong".equals(o.getString("tag1")) || ("correct".equals(o.getString("tag1")) && !"fin_lead_lag".equals(o.getString("tag2")))).collect(Collectors.toList());

            judge_list = judge_list.stream().peek(jsonObject -> {
                String judge_finalaoiid = jsonObject.getString("finalaoiid");
                if (StringUtils.isNotEmpty(judge_finalaoiid)) {
                    Tuple2<String, List<JSONObject>> tag2_list = find(jsonObject, compare_list);
                    String tag2 = tag2_list._1();
                    if (StringUtils.isNotEmpty(tag2)) {
                        jsonObject.put("new_tag2", tag2);
                        List<JSONObject> noEmpFinalaoiidList = tag2_list._2().stream().filter(o -> StringUtils.isNotEmpty(o.getString("finalaoiid"))).collect(Collectors.toList());
                        int total_size = noEmpFinalaoiidList.size();
                        if (total_size > 0) {
                            int eq_size = noEmpFinalaoiidList.stream().filter(o -> judge_finalaoiid.equals(o.getString("finalaoiid"))).collect(Collectors.toList()).size();
                            long correct_cnt = noEmpFinalaoiidList.stream().filter(o -> "correct".equals(o.getString("tag1"))).count();
                            long wrong_cnt = noEmpFinalaoiidList.stream().filter(o -> "wrong".equals(o.getString("tag1"))).count();
                            String new_tag1 = "";
                            if (eq_size == total_size) {
                                //1、关联上判断组识别aoi与关联上的对比组的所有aoi一致则把对比组的tag1赋值给判断组的tag1，tag3赋值1，优先取coreect，否则取wrong
                                if (correct_cnt > 0) {
                                    new_tag1 = "correct";
                                } else {
                                    new_tag1 = "wrong";
                                }
                                jsonObject.put("new_tag1", new_tag1);
                                jsonObject.put("new_tag3", "1");

                            } else if (eq_size == 0) {
                                //2、关联上判断组识别aoi与关联上的对比组的所有aoi不一致则把对比组的tag1取反赋值给判断组的tag1、tag3赋值2，如果tag1有correct和wrong则取no，如果全是correct则取wrong，如果全是wrong则取correct
                                if (correct_cnt > 0 && wrong_cnt > 0) {
                                    new_tag1 = "no";
                                } else if (correct_cnt > 0) {
                                    new_tag1 = "wrong";
                                } else if (wrong_cnt > 0) {
                                    new_tag1 = "correct";
                                }
                                jsonObject.put("new_tag1", new_tag1);
                                jsonObject.put("new_tag3", "2");
                            } else {
                                //3、关联上判断组识别aoi与关联上的对比组的aoi有一致且有不一致tag1赋值no，tag3赋值3
                                new_tag1 = "no";
                                jsonObject.put("new_tag1", new_tag1);
                                jsonObject.put("new_tag3", "3");
                            }
                        }
                    }
                }
            }).collect(Collectors.toList());
            judge_list.addAll(compare_list);
            return judge_list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:" + lastRdd.count());
        nameRdd.unpersist();
        return lastRdd;
    }

    public static Tuple2<String, List<JSONObject>> find(JSONObject jsonObject, List<JSONObject> compare_list) {

        String lvl113name = jsonObject.getString("lvl113name");
        String lvl213name = jsonObject.getString("lvl213name");
        String lvl911name = jsonObject.getString("lvl911name");
        String lvl613name = jsonObject.getString("lvl613name");
        String lvl214name = jsonObject.getString("lvl214name");
        List<JSONObject> filter_list = new ArrayList<>();

        //关联字段，判断顺序从1到12，已有判断结果的数据不想走后面的判断逻辑
        HashMap<String, String> map = new HashMap<>();
        String tag2 = "";
        //1、Lvl113name有值，Lvl613name有值，Lvl214Name有值—Tag2赋值        lvl164
        if (StringUtils.isNotEmpty(lvl113name) && StringUtils.isNotEmpty(lvl613name) && StringUtils.isNotEmpty(lvl214name)) {
            map.put("lvl113name", lvl113name);
            map.put("lvl613name", lvl613name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl164";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //2、Lvl911name有值，Lvl613name有值，Lvl214Name有值—Tag2赋值        lvl964
        if (StringUtils.isNotEmpty(lvl911name) && StringUtils.isNotEmpty(lvl613name) && StringUtils.isNotEmpty(lvl214name)) {
            map.clear();
            map.put("lvl911name", lvl911name);
            map.put("lvl613name", lvl613name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl964";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //3、Lvl213name有值，Lvl613name有值，Lvl214Name有值—Tag2赋值        lvl264
        if (StringUtils.isNotEmpty(lvl213name) && StringUtils.isNotEmpty(lvl613name) && StringUtils.isNotEmpty(lvl214name)) {
            map.clear();
            map.put("lvl213name", lvl213name);
            map.put("lvl613name", lvl613name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl264";
                return new Tuple2<>(tag2, filter_list);
            }
        }

        //4、Lvl113name有值，Lvl613name有值，Lvl214Name不看—Tag2赋值        lvl160
        if (StringUtils.isNotEmpty(lvl113name) && StringUtils.isNotEmpty(lvl613name)) {
            map.clear();
            map.put("lvl113name", lvl113name);
            map.put("lvl613name", lvl613name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl160";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //5、Lvl1911name有值，Lvl613name有值，Lvl214Name不看—Tag2赋值        lvl960
        if (StringUtils.isNotEmpty(lvl911name) && StringUtils.isNotEmpty(lvl613name)) {
            map.clear();
            map.put("lvl911name", lvl911name);
            map.put("lvl613name", lvl613name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl960";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //6、Lvl213name有值，Lvl613name有值，Lvl214Name不看—Tag2赋值        lvl260
        if (StringUtils.isNotEmpty(lvl213name) && StringUtils.isNotEmpty(lvl613name)) {
            map.clear();
            map.put("lvl213name", lvl213name);
            map.put("lvl613name", lvl613name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl260";
                return new Tuple2<>(tag2, filter_list);
            }
        }

        //7、Lvl113name有值，Lvl613name不看，Lvl214Name有值—Tag2赋值        lvl104
        if (StringUtils.isNotEmpty(lvl113name) && StringUtils.isNotEmpty(lvl214name)) {
            map.clear();
            map.put("lvl113name", lvl113name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl104";
                return new Tuple2<>(tag2, filter_list);
            }
        }

        //8、Lvl1911name有值，Lvl613name不看，Lvl214Name有值—Tag2赋值        lvl904
        if (StringUtils.isNotEmpty(lvl911name) && StringUtils.isNotEmpty(lvl214name)) {
            map.clear();
            map.put("lvl911name", lvl911name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl904";
                return new Tuple2<>(tag2, filter_list);
            }
        }

        //9、Lvl213name有值，Lvl613name不看，Lvl214Name有值—Tag2赋值        lvl204
        if (StringUtils.isNotEmpty(lvl213name) && StringUtils.isNotEmpty(lvl214name)) {
            map.clear();
            map.put("lvl213name", lvl213name);
            map.put("lvl214name", lvl214name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl204";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //10、Lvl113name有值，Lvl613name不看，Lvl214Name不看—Tag2赋值        lvl113
        if (StringUtils.isNotEmpty(lvl113name)) {
            map.clear();
            map.put("lvl113name", lvl113name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl113";
                return new Tuple2<>(tag2, filter_list);
            }
        }

        //11、Lvl1911name有值，Lvl613name不看，Lvl214Name不看—Tag2赋值        lvl911
        if (StringUtils.isNotEmpty(lvl911name)) {
            map.clear();
            map.put("lvl911name", lvl911name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl911";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        //12、Lvl213name有值，Lvl613name不看，Lvl214Name不看—Tag2赋值        lvl213
        if (StringUtils.isNotEmpty(lvl213name)) {
            map.clear();
            map.put("lvl213name", lvl213name);
            filter_list = filter(map, compare_list);
            if (filter_list.size() > 0) {
                tag2 = "lvl213";
                return new Tuple2<>(tag2, filter_list);
            }
        }
        return new Tuple2<>(tag2, null);
    }

    public static List<JSONObject> filter(Map<String, String> map, List<JSONObject> list) {
        return list.stream().filter(o -> {
            int size = map.size();
            ArrayList<Boolean> booleans_list = new ArrayList<>();
            for (Map.Entry<String, String> stringStringEntry : map.entrySet()) {
                String key = stringStringEntry.getKey();
                String value = stringStringEntry.getValue();
                booleans_list.add(StringUtils.equals(o.getString(key), value));
            }
            int true_size = (int) booleans_list.stream().filter(t -> t).count();
            return size == true_size;
        }).collect(Collectors.toList());
    }

    public static JavaRDD<JSONObject> process(JavaRDD<JSONObject> rdd) {
        JavaRDD<JSONObject> nameRdd = rdd.map(o -> {
            String splitresult = o.getString("splitresult");
            ArrayList<String> allNameList = new ArrayList<>();
            ArrayList<String> allLevelList = new ArrayList<>();

            ArrayList<String> name_113_list = new ArrayList<>();
            ArrayList<String> name_213_list = new ArrayList<>();
            List<String> execept_list = Arrays.asList("菜鸟驿站,中通快递,圆通快递,中通快递,申通快递,顺丰快递".split(","));
            StringBuilder lvl911name = new StringBuilder();
            String type_911 = "";
            int type_911_cnt = 0;

            ArrayList<String> lvl613name = new ArrayList<>();
            String type_613 = "";

            ArrayList<String> lvl214name = new ArrayList<>();
            String type_214 = "";
            if (StringUtils.isNotEmpty(splitresult)) {
                //广东省^11|广州市^12|增城区^13|新塘镇^15|新塘牛仔城^113|1路^210|12号^211|同兴花样加工^213;13
                //广东省^11|广州市^12|增城区^13|新塘镇^15|新塘牛仔城^113|1路^210|12号^211|同兴花样加工^213
                List<String> split = Arrays.asList(splitresult.split(";")[0].split("\\|"));
                int length = split.size();
                for (int i = 0; i < length; i++) {
                    String s = split.get(i);
                    String[] split1 = s.split("\\^");
                    if (split1.length >= 2) {
                        String name = split1[0];
                        String level = split1[1];

                        //Lvl911name，从splitresult字段中取出连在一起的19和211的名称拼接放入或连在一起29和211的名称拼接放入，有多个值的则全部取出type取值c
                        if ("19".equals(level) || "29".equals(level)) {
                            if (i != length - 1) {
                                String s1 = split.get(i + 1);
                                String[] split2 = s1.split("\\^");
                                if (split2.length >= 2) {
                                    String name_211 = split2[0];
                                    String level_211 = split2[1];
                                    if ("211".equals(level_211)) {
                                        lvl911name.append(name).append(name_211);
                                        ++type_911_cnt;
                                        if (type_911_cnt >= 2) {
                                            type_911 = "c";
                                        }
                                    }
                                }
                            }
                        }

                        //新增一列命名Lvl613name，从splitresult字段中取出613的名称放入，
                        //规则1、把大写的一到一百中文字符的改成小写的数字，大写字母全部改成小写字母
                        //2、只取接在113、213、613、211后面的613名称，其他的都不要
                        //2、有多个直接拼接放入，type取值d
                        if ("613".equals(level) && StringUtils.isNotEmpty(name)) {
                            if (i != 0) {
                                List<String> before_613_list = split.subList(0, i);
                                String before_613_str = String.join("", before_613_list);
                                if (before_613_str.contains("^113") || before_613_str.contains("^213") || before_613_str.contains("^613") || before_613_str.contains("^211")) {
                                    lvl613name.add(StringNumUtils.outputArabNumberString(name.toLowerCase(), "[一二三四五六七八九十百]+"));
                                }
                            }
                        }

                        //新增一列命名Lvl214name，从splitresult字段中取出214的名称放入，
                        //规则1、把大写的一到一百中文字符的改成小写的数字，大写字母全部改成小写字母
                        //2、只取接在113、213、613、211后面的214名称，其他的都不要
                        //3、把【坐】【座】【幢】【号楼】转为【栋】
                        //4、有多个直接拼接放入，type取值e
                        if ("214".equals(level) && StringUtils.isNotEmpty(name)) {
                            if (i != 0) {
                                List<String> before_214_list = split.subList(0, i);
                                String before_214_str = String.join("", before_214_list);
                                if (before_214_str.contains("^113") || before_214_str.contains("^213") || before_214_str.contains("^613") || before_214_str.contains("^211")) {
                                    lvl214name.add(StringNumUtils.outputArabNumberString(name.toLowerCase().replaceAll("坐|座|幢|号楼", "栋"), "[一二三四五六七八九十百]+"));
                                }
                            }
                        }


                        allNameList.add(name);
                        allLevelList.add(level);
                        if (!execept_list.contains(name)) {
                            if ("113".equals(level)) {
                                name_113_list.add(name);
                            }

                            if ("213".equals(level)) {
                                name_213_list.add(name);
                            }
                        }


                    }
                }
            }
            //Lvl113name赋值
            Tuple2<String, String> tp_113 = getNameAndType(name_113_list, allLevelList, allNameList, "113", execept_list);
            String lvl113name = tp_113._1();
            String type_113 = tp_113._2();
            o.put("lvl113name", lvl113name);
            o.put("type_113", type_113);

            //Lvl213name赋值
            if (StringUtils.isEmpty(lvl113name)) {
                Tuple2<String, String> tp_213 = getNameAndType(name_213_list, allLevelList, allNameList, "213", execept_list);
                String lvl213name = tp_213._1();
                String type_213 = tp_213._2();
                o.put("lvl213name", lvl213name);
                o.put("type_213", type_213);
            }
            //lvl911name赋值
            o.put("lvl911name", lvl911name);
            o.put("type_911", type_911);

            //lvl613name赋值
            o.put("lvl613name", String.join("", lvl613name));
            if (lvl613name.size() > 1) {
                type_613 = "d";
                o.put("type_613", type_613);
            }
            //lvl214name赋值
            o.put("lvl214name", String.join("", lvl214name));
            if (lvl214name.size() > 1) {
                type_214 = "e";
                o.put("type_214", type_214);
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("nameRdd cnt:" + nameRdd.count());
        rdd.unpersist();
        return nameRdd;
    }

    public static Tuple2<String, String> getNameAndType(ArrayList<String> name_list, ArrayList<String> allLevelList, ArrayList<String> allNameList, String level, List<String> execept_list) {
        int size = name_list.size();
        if (size > 0) {
            //1、一个直接取
            if (size == 1) {
                return new Tuple2<>(name_list.get(0), "");
            }
            //2、如果有多个113/213级，取613、214、215、216、217级前面紧挨着的113/213级
            for (int i = 0; i < allLevelList.size(); i++) {
                String temp_level = allLevelList.get(i);
                if (StringUtils.equals(temp_level, level)) {
                    if (i != allLevelList.size() - 1) {
                        String after_level = allLevelList.get(i + 1);
                        if (Arrays.asList("613,214,215,216,217".split(",")).contains(after_level)) {
                            return new Tuple2<>(allNameList.get(i), "");
                        }
                    }
                }
            }
            //3、如果还有多个113/213级，如果有118或者218或者318或者518则取后面那个18级后面的那个113
            for (String temp_level : allLevelList) {
                if (Arrays.asList("118,218,318,518".split(",")).contains(temp_level)) {
                    int index_temp = allLevelList.indexOf(temp_level);
                    List<String> temp_level_sub_list = allLevelList.subList(index_temp, allLevelList.size());
                    int index_18_13 = temp_level_sub_list.indexOf(level);
                    if (index_18_13 != -1) {
                        List<String> temp_name_sub_list = allNameList.subList(index_temp, allNameList.size());
                        for (int i = 0; i < temp_level_sub_list.size(); i++) {
                            String target_level = temp_level_sub_list.get(i);
                            if (level.equals(target_level)) {
                                String target_name = temp_name_sub_list.get(i);
                                if (!execept_list.contains(target_name)) {
                                    return new Tuple2<>(target_name, "");
                                }
                            }
                        }
                    }
                }
            }
            //4、再有多个113/213级则全部取下并新增一列取名Type，有多个113则type取值为a
            return new Tuple2<>(String.join("", name_list), "113".equals(level) ? "a" : "b");
        }
        return new Tuple2<>("", "");
    }


    public static JavaRDD<JSONObject> getData(SparkSession spark, String date) {
        String sql = String.format("select * from dm_gis.dm_aoi_real_acctury_rate_judge_bottomcorrected_2024_di where inc_day = '%s'", date);
        return SparkRead.readHiveAsJson(spark, sql, 0)._1().toJavaRDD();
    }
}
