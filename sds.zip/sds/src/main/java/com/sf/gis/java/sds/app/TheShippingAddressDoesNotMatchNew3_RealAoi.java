package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfileRealAoi;
import com.sf.gis.java.sds.utils.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Iterator;
import java.util.List;


/**
 * 虚假寄件地址不符真实aoi判断
 * 需求方：刘雨婷（01408947）
 * @author 韩笑（01417629）
 * 任务id：913126
 */

public class TheShippingAddressDoesNotMatchNew3_RealAoi {
    private static Logger logger = LoggerFactory.getLogger(TheShippingAddressDoesNotMatchNew3_RealAoi.class);

    public static void main(String[] args) {
        String date = args[0];
        new EdcsWaybillContentSwsKafkaSjOutAreaControllerSaProfileRealAoi().process(date);
        logger.error("process end...");
    }
}
