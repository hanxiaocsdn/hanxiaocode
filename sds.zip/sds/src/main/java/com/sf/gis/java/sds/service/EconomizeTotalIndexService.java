package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.ClassExecutionCondition;
import com.sf.gis.java.sds.pojo.TotalIndex;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class EconomizeTotalIndexService implements Serializable {
    private Logger logger = LoggerFactory.getLogger(EconomizeTotalIndexService.class);

    public JavaRDD<TotalIndex> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("total_index.sql", date);
        logger.error("total_index sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TotalIndex.class);
    }

    public void saveData(SparkSession spark, JavaRDD<TotalIndex> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getInc_month(), DateUtil.parseFormat(o.getInc_day()), o.getDay(), o.getTask_area_code(), o.getTask_area_name(), o.getLine_area(), o.getLine_code(),
                    o.getTask_count() + "", o.getExe_count() + "", o.getExe_count_1() + "", o.getExe_count_2() + "", o.getNo_exe_count() + "", o.getDb_count() + "", o.getExe_db_count() + "",
                    o.getExe_db_count_1() + "", o.getExe_db_count_2() + "", o.getNoexe_db_count() + "", o.getSave_money() + "", o.getTime() + "",
                    o.getExe_time() + "", o.getExe_time_1() + "", o.getExe_time_2() + "", o.getNoexe_time() + ""
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"stat_month", "stat_date", "stat_week", "task_area_code", "task_area_name", "line_area", "line_code", "task_count", "exe_count", "exe_count_1",
                "exe_count_2", "no_exe_count", "db_count", "exe_db_count", "exe_db_count_1", "exe_db_count_2", "noexe_db_count", "save_money",
                "time", "exe_time", "exe_time_1", "exe_time_2", "noexe_time"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "eta_economize_total_index_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.eta_economize_total_index";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveToMysql(JavaSparkContext sc, JavaRDD<ClassExecutionCondition> rdd) {
        String dbConfig = "mysql.properties";
        logger.error("rdd cnt: {}", rdd.count());

        logger.error("insert into mysql");
        Broadcast<String> dbConfigBc = sc.broadcast(dbConfig);
        rdd.repartition(16).foreachPartition(p -> {
            Connection conn = DbUtil.getInstance(dbConfigBc.value()).getConn();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement(
                    String.format("insert into ETA_CLASS_EXECUTE_STAT(`STAT_MONTH`,`STAT_DATE`,`STAT_WEEK`,`STAT_TYPE`,`STAT_TYPE_CONTENT`,`SRC_PROVINCE`,`DESC_PROVINCE`," +
                            "`AREA`,`LINE_AREA`,`CLASS_ID`,`SRC_CITYCODE`,`DESC_CITYCODE`," +
                            "`REACH_COUNT`,`TASK_COUNT`,`EXECUTE_COUNT`,`NO_REACH_COUNT`,`NO_EXECUTE_COUNT`,`EXECUTE_REACH_COUNT`,`NO_EXECUTE_REACH_COUNT`,`TOTAL_ETC`," +
                            "`EXECUTE_TOTAL_ETC`,`NO_EXECUTE_TOTAL_ETC`,`TOTAL_DISTANCE`,`EXECUTE_TOTAL_DISTANCE`,`NO_EXECUTE_TOTAL_DISTANCE`,`TOTAL_TIME`,`EXECUTE_TOTAL_TIME`," +
                            "`NO_EXECUTE_TOTAL_TIME`,`DELAY_MIN`,`EXECUTE_DELAY_MIN`,`NO_EXECUTE_DELAY_MIN`,`BASE_TOTAL_ETC`) " +
                            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            );
            while (p.hasNext()) {
                ClassExecutionCondition o = p.next();
                pstmt.setString(1, o.getIncMonth());
                pstmt.setString(2, o.getIncDay());
                pstmt.setString(3, o.getDay());
                pstmt.setString(4, o.getStat_type());
                pstmt.setString(5, o.getStat_type_content());
                pstmt.setString(6, o.getSrcProvince());
                pstmt.setString(7, o.getDestProvince());
                pstmt.setString(8, o.getTaskAreaCode());
                pstmt.setString(9, o.getLine_area());
                pstmt.setString(10, o.getLineCode());
                pstmt.setString(11, o.getSrcCityName());
                pstmt.setString(12, o.getDestCityName());
                pstmt.setInt(13, o.getReachCount());
                pstmt.setInt(14, o.getTaskCount());
                pstmt.setInt(15, o.getExecutionCount());
                pstmt.setInt(16, o.getNo_reachCount());
                pstmt.setInt(17, o.getNo_executionCount());
                pstmt.setInt(18, o.getExecuteReachCount());
                pstmt.setInt(19, o.getNoExecuteReachCount());
                pstmt.setDouble(20, o.getSumEtc());
                pstmt.setDouble(21, o.getExecution_sumEtc());
                pstmt.setDouble(22, o.getNo_execution_sumEtc());
                pstmt.setDouble(23, o.getSumDistance());
                pstmt.setDouble(24, o.getExecution_sumDistance());
                pstmt.setDouble(25, o.getNo_execution_sumDistance());
                pstmt.setDouble(26, o.getSumConsumeTime());
                pstmt.setDouble(27, o.getExecution_sumConsumeTime());
                pstmt.setDouble(28, o.getNo_execution_sumConsumeTime());
                pstmt.setDouble(29, o.getSumTimeOut());
                pstmt.setDouble(30, o.getExecution_sumTimeOut());
                pstmt.setDouble(31, o.getNo_execution_sumTimeOut());
                pstmt.setDouble(32, o.getBaseSumEtc());

                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            pstmt.close();
            conn.close();
        });
        logger.error("insert into mysql end");
    }

    public void delete(String date) {
        Connection conn = DbUtil.getInstance("mysql.properties").getConn();
        String sql = String.format("delete from ETA_CLASS_EXECUTE_STAT where STAT_DATE = '%s'", date);
        PreparedStatement pst = null;
        try {
            // 创建预编译语句
            pst = conn.prepareStatement(sql);
            // 执行SQL
            pst.executeUpdate();
            logger.error("删除成功");
            // 关闭资源
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("删除失败");
        }
    }
}
