package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AppSuspectedWrongDataFilterStep8 implements Serializable {
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "80_aoi_code")
    private String aoi_80_code;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "freq")
    private String freq;
    @Column(name = "max_80_aoicode")
    private String max_80_aoicode;
    @Column(name = "max_80_pro")
    private String max_80_pro;
    @Column(name = "cms_address")
    private String cms_address;
    @Column(name = "cms_aoiid")
    private String cms_aoiid;
    @Column(name = "cms_znocode")
    private String cms_znocode;
    @Column(name = "cms_aoiname")
    private String cms_aoiname;
    @Column(name = "max_80_aoiid")
    private String max_80_aoiid;
    @Column(name = "max_80_znocode")
    private String max_80_znocode;
    @Column(name = "max_80_aoi_name")
    private String max_80_aoi_name;
    @Column(name = "cms_address1")
    private String cms_address1;
    @Column(name = "cms_aoiname1")
    private String cms_aoiname1;
    @Column(name = "max_80_aoi_name1")
    private String max_80_aoi_name1;
    @Column(name = "max_80_aoi_name_pro")
    private String max_80_aoi_name_pro;
    @Column(name = "cms_aoi_name_pro")
    private String cms_aoi_name_pro;
    @Column(name = "aoiname_pro")
    private String aoiname_pro;
    @Column(name = "wrong")
    private String wrong;
    @Column(name = "xcoord")
    private String xcoord;
    @Column(name = "ycoord")
    private String ycoord;
    @Column(name = "precision")
    private String precision;
    @Column(name = "gd_aoiid")
    private String gd_aoiid;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "flag")
    private String flag;

    private double pro_80;

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getXcoord() {
        return xcoord;
    }

    public void setXcoord(String xcoord) {
        this.xcoord = xcoord;
    }

    public String getYcoord() {
        return ycoord;
    }

    public void setYcoord(String ycoord) {
        this.ycoord = ycoord;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getWrong() {
        return wrong;
    }

    public void setWrong(String wrong) {
        this.wrong = wrong;
    }

    public String getMax_80_aoi_name_pro() {
        return max_80_aoi_name_pro;
    }

    public void setMax_80_aoi_name_pro(String max_80_aoi_name_pro) {
        this.max_80_aoi_name_pro = max_80_aoi_name_pro;
    }

    public String getCms_aoi_name_pro() {
        return cms_aoi_name_pro;
    }

    public void setCms_aoi_name_pro(String cms_aoi_name_pro) {
        this.cms_aoi_name_pro = cms_aoi_name_pro;
    }

    public String getAoiname_pro() {
        return aoiname_pro;
    }

    public void setAoiname_pro(String aoiname_pro) {
        this.aoiname_pro = aoiname_pro;
    }

    public String getCms_address1() {
        return cms_address1;
    }

    public void setCms_address1(String cms_address1) {
        this.cms_address1 = cms_address1;
    }

    public String getCms_aoiname1() {
        return cms_aoiname1;
    }

    public void setCms_aoiname1(String cms_aoiname1) {
        this.cms_aoiname1 = cms_aoiname1;
    }

    public String getMax_80_aoi_name1() {
        return max_80_aoi_name1;
    }

    public void setMax_80_aoi_name1(String max_80_aoi_name1) {
        this.max_80_aoi_name1 = max_80_aoi_name1;
    }

    public String getCms_aoiname() {
        return cms_aoiname;
    }

    public void setCms_aoiname(String cms_aoiname) {
        this.cms_aoiname = cms_aoiname;
    }

    public String getMax_80_aoiid() {
        return max_80_aoiid;
    }

    public void setMax_80_aoiid(String max_80_aoiid) {
        this.max_80_aoiid = max_80_aoiid;
    }

    public String getMax_80_znocode() {
        return max_80_znocode;
    }

    public void setMax_80_znocode(String max_80_znocode) {
        this.max_80_znocode = max_80_znocode;
    }

    public String getMax_80_aoi_name() {
        return max_80_aoi_name;
    }

    public void setMax_80_aoi_name(String max_80_aoi_name) {
        this.max_80_aoi_name = max_80_aoi_name;
    }

    public String getCms_address() {
        return cms_address;
    }

    public void setCms_address(String cms_address) {
        this.cms_address = cms_address;
    }

    public String getCms_aoiid() {
        return cms_aoiid;
    }

    public void setCms_aoiid(String cms_aoiid) {
        this.cms_aoiid = cms_aoiid;
    }

    public String getCms_znocode() {
        return cms_znocode;
    }

    public void setCms_znocode(String cms_znocode) {
        this.cms_znocode = cms_znocode;
    }

    public double getPro_80() {
        return pro_80;
    }

    public void setPro_80(double pro_80) {
        this.pro_80 = pro_80;
    }

    public String getMax_80_aoicode() {
        return max_80_aoicode;
    }

    public void setMax_80_aoicode(String max_80_aoicode) {
        this.max_80_aoicode = max_80_aoicode;
    }

    public String getMax_80_pro() {
        return max_80_pro;
    }

    public void setMax_80_pro(String max_80_pro) {
        this.max_80_pro = max_80_pro;
    }

    public String getFreq() {
        return freq;
    }

    public void setFreq(String freq) {
        this.freq = freq;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }
}
