package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class WaybillFairsAoiInfoDi implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "consigned_dt")
    private String consigned_dt;
    @Column(name = "consigned_tm")
    private String consigned_tm;
    @Column(name = "src_aoi_name")
    private String src_aoi_name;
    @Column(name = "src_city_code")
    private String src_city_code;
    @Column(name = "src_city_name")
    private String src_city_name;
    @Column(name = "dest_aoi_name")
    private String dest_aoi_name;
    @Column(name = "dest_city_code")
    private String dest_city_code;
    @Column(name = "dest_city_name")
    private String dest_city_name;
    @Column(name = "fairs_type")
    private String fairs_type;
    @Column(name = "service_prod_code")
    private String service_prod_code;
    @Column(name = "add_serve_name")
    private String add_serve_name;
    @Column(name = "add_serve_fee")
    private String add_serve_fee;
    @Column(name = "consignor_mobile")
    private String consignor_mobile;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "consignee_addr_udf")
    private String consignee_addr_udf;
    @Column(name = "hdata_matchtype")
    private String hdata_matchtype;
    @Column(name = "hdata_exhibitionid")
    private String hdata_exhibitionid;
    @Column(name = "resp")
    private String resp;

    @Column(name = "consignor_addr")
    private String consignor_addr;
    @Column(name = "consignor_addr_udf")
    private String consignor_addr_udf;
    @Column(name = "chdata_matchtype")
    private String chdata_matchtype;
    @Column(name = "chdata_exhibitionid")
    private String chdata_exhibitionid;
    @Column(name = "inc_day")
    private String inc_day;

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getConsignor_addr_udf() {
        return consignor_addr_udf;
    }

    public void setConsignor_addr_udf(String consignor_addr_udf) {
        this.consignor_addr_udf = consignor_addr_udf;
    }

    public String getChdata_matchtype() {
        return chdata_matchtype;
    }

    public void setChdata_matchtype(String chdata_matchtype) {
        this.chdata_matchtype = chdata_matchtype;
    }

    public String getChdata_exhibitionid() {
        return chdata_exhibitionid;
    }

    public void setChdata_exhibitionid(String chdata_exhibitionid) {
        this.chdata_exhibitionid = chdata_exhibitionid;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getHdata_matchtype() {
        return hdata_matchtype;
    }

    public void setHdata_matchtype(String hdata_matchtype) {
        this.hdata_matchtype = hdata_matchtype;
    }

    public String getHdata_exhibitionid() {
        return hdata_exhibitionid;
    }

    public void setHdata_exhibitionid(String hdata_exhibitionid) {
        this.hdata_exhibitionid = hdata_exhibitionid;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getConsigned_dt() {
        return consigned_dt;
    }

    public void setConsigned_dt(String consigned_dt) {
        this.consigned_dt = consigned_dt;
    }

    public String getConsigned_tm() {
        return consigned_tm;
    }

    public void setConsigned_tm(String consigned_tm) {
        this.consigned_tm = consigned_tm;
    }

    public String getSrc_aoi_name() {
        return src_aoi_name;
    }

    public void setSrc_aoi_name(String src_aoi_name) {
        this.src_aoi_name = src_aoi_name;
    }

    public String getSrc_city_code() {
        return src_city_code;
    }

    public void setSrc_city_code(String src_city_code) {
        this.src_city_code = src_city_code;
    }

    public String getSrc_city_name() {
        return src_city_name;
    }

    public void setSrc_city_name(String src_city_name) {
        this.src_city_name = src_city_name;
    }

    public String getDest_aoi_name() {
        return dest_aoi_name;
    }

    public void setDest_aoi_name(String dest_aoi_name) {
        this.dest_aoi_name = dest_aoi_name;
    }

    public String getDest_city_code() {
        return dest_city_code;
    }

    public void setDest_city_code(String dest_city_code) {
        this.dest_city_code = dest_city_code;
    }

    public String getDest_city_name() {
        return dest_city_name;
    }

    public void setDest_city_name(String dest_city_name) {
        this.dest_city_name = dest_city_name;
    }

    public String getFairs_type() {
        return fairs_type;
    }

    public void setFairs_type(String fairs_type) {
        this.fairs_type = fairs_type;
    }

    public String getService_prod_code() {
        return service_prod_code;
    }

    public void setService_prod_code(String service_prod_code) {
        this.service_prod_code = service_prod_code;
    }

    public String getAdd_serve_name() {
        return add_serve_name;
    }

    public void setAdd_serve_name(String add_serve_name) {
        this.add_serve_name = add_serve_name;
    }

    public String getAdd_serve_fee() {
        return add_serve_fee;
    }

    public void setAdd_serve_fee(String add_serve_fee) {
        this.add_serve_fee = add_serve_fee;
    }

    public String getConsignor_mobile() {
        return consignor_mobile;
    }

    public void setConsignor_mobile(String consignor_mobile) {
        this.consignor_mobile = consignor_mobile;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getConsignee_addr_udf() {
        return consignee_addr_udf;
    }

    public void setConsignee_addr_udf(String consignee_addr_udf) {
        this.consignee_addr_udf = consignee_addr_udf;
    }
}
