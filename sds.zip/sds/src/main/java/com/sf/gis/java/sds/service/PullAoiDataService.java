package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.bean.FtpClient;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.pojo.GisPaiAddrFreqStat;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class PullAoiDataService implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(PullAoiDataService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    private String GIS_PAI_ADDR_FREQ_STAT = "dm_gis.gis_pai_addr_freq_stat";

    public PullAoiDataService() {
        sparkSession = Spark.getSparkSession(PullAoiDataService.class.getSimpleName(), null, false, 2);
    }

    public void pullData(Map<String, String> configMap, String[] date) {
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        FtpClient ftpClient = creattFtpClient(configMap, "");
        for (String city : openCityList) {
            try {
                parserCity(city, date[0], date[1], ftpClient, configMap);
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("Exception:" + e.getMessage());
            }
        }
        ftpClient.close();
    }

    public void pullDataByDay(Map<String, String> configMap, String[] dates) {
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        FtpClient ftpClient = creattFtpClient(configMap, "");
        for (String date : dates) {
            logger.error("date:" + date);
            for (String city : openCityList) {
                try {
                    parserCity(city, date, date, ftpClient, configMap);
                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("Exception:" + e.getMessage());
                }
            }
        }

        ftpClient.close();
    }

    private FtpClient creattFtpClient(Map<String, String> configMap, String inc_day) {
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        ftpClient.setFtpFilePath(ftpPath);
        String saveByDay = configMap.get(ConfigKey.save_by_day.name());
        if ("true".equals(saveByDay)) {
            ftpClient.setFtpFilePath(ftpClient.getFtpFilePath() + "/" + inc_day);
        }
        ftpClient.setFtpFileName(ftpFileName);
        return ftpClient;
    }

    private void parserCity(String city, String begin_day, String end_day, FtpClient ftpClient,
                            Map<String, String> configMap) throws Exception {
        String cityCode = "'" + city + "'";
        String sql = "select first(key),address_id, first(address),sum(match_freq),first(src),citycode,inc_day"
                + " from " + GIS_PAI_ADDR_FREQ_STAT + " where inc_day between '" + begin_day + "' and '" + end_day
                + "' and citycode in (" + cityCode + ") group by inc_day,citycode,address_id ";
        logger.error(sql);
        JavaRDD<GisPaiAddrFreqStat> dataRdd = sparkSession.sql(sql).javaRDD()
                .persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> new GisPaiAddrFreqStat(x.getString(0), x.getString(1), x.getString(2), x.getDouble(3),
                        x.getString(4), x.getString(5), x.getString(6)));
        save_to_db(dataRdd.collect(), city);
        // parserAllData(city, dataRdd, ftpClient, configMap);
    }

    /**
     * 保存到数据库
     *
     * @throws Exception
     */
    private void save_to_db(List<GisPaiAddrFreqStat> list, String cityCode) throws Exception {
        AoiDbService aoiDbService = new AoiDbService();
        aoiDbService.insertBatch(list, cityCode);
    }

}