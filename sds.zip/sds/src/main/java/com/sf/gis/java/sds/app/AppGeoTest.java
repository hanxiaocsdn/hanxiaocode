package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.sds.pojo.BeeLogsGisGeoParse;
import com.sf.gis.java.sds.pojo.ExpressDeliveryToVillagesCostModel;
import com.sf.gis.scala.base.spark.Spark;
import com.sf.gis.scala.base.spark.SparkRead;
import com.sf.gis.scala.base.spark.SparkWrite;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 任务id：9：新平台测试环境（geo测试）
 * 业务：01381101（匡可心）
 * 研发：01399581（匡仁衡）
 */
public class AppGeoTest {
    private static Logger logger = LoggerFactory.getLogger(AppGeoTest.class);
    private static String geoUrl = "http://gis-int.intsit.sfdc.com.cn:1080/geo/api?ak=663ee55ce37c42b182c17e37e66171a7&opt=%s&cc=%s&address=%s&city=%s";
    private static String account = "01399581";
    private static String taskId = "9";
    private static String taskName = "geo测试";
    private static final String[] saveKey = new String[]{
            "ak",
            "address",
            "city",
            "opt",
            "cc",
            "src",
            "match_level",
            "data_type",
            "precision",
            "xcoord",
            "ycoord",
            "adcode",
            "regcode",
            "adname",
            "src_address",
            "datasrc",
            "src_test",
            "match_level_test",
            "data_type_test",
            "precision_test",
            "xcoord_test",
            "ycoord_test",
            "adcode_test",
            "regcode_test",
            "adname_test",
            "src_address_test",
            "datasrc_test",
            "flag"
    };

    public static void main(String[] args) {
        String date = args[0];
        String step = args[1];
        String start = args[2];
        String end = args[3];
        logger.error("date:{}, step:{}", date, step);
        logger.error("start:{},end:{}", start, end);

        SparkSession spark = Spark.getSparkSession("AppGeoTest", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        if ("1".equals(step)) {
            JavaRDD<String> lineRdd = sc.textFile("hdfs://node1:8020/tmp/bee_logs_gis_geo_parse.csv", 20).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("lineRdd cnt:{}", lineRdd.count());
            String head = lineRdd.first();
            logger.error("head:{}", head);
            logger.error("将数据分为8个分区存储");
            JavaRDD<BeeLogsGisGeoParse> rdd = lineRdd.filter(o -> !StringUtils.equals(o, head)).map(AppGeoTest::getField).persist(StorageLevel.MEMORY_AND_DISK_SER());
            rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            logger.error("rdd cnt:{}", rdd.count());
            logger.error("分区数据存储");
            DataUtil.saveOverwrite(spark, sc, "dm_gis.geo_data", BeeLogsGisGeoParse.class, rdd, "inc_day");
        } else {
            int i1 = Integer.parseInt(start);
            int i2 = Integer.parseInt(end);
            for (int i = i1; i <= i2; i++) {
                try {
                    logger.error("process分区:{}", i);
                    String sql = String.format("select * from dm_gis.geo_data where inc_day = '%s'", i);

                    JavaRDD<BeeLogsGisGeoParse> rdd = DataUtil.loadData(spark, sc, sql, BeeLogsGisGeoParse.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
                    logger.error("rdd cnt:{}", rdd.count());
                    JavaRDD<BeeLogsGisGeoParse> resultRdd = getResult(rdd, date);
                    logger.error("分区:{},数据存储", i);
                    DataUtil.saveInto(spark, sc, "dm_gis.geo_api_test", BeeLogsGisGeoParse.class, resultRdd, "inc_day");
                    resultRdd.unpersist();

//                    JavaRDD<JSONObject> rdd = SparkRead.readHiveAsJson(spark, sql, 0)._1().toJavaRDD();
//                    JavaRDD<JSONObject> jsResultRdd = getJsResult(rdd, date);
//                    SparkWrite.save2HiveStaticNew(spark, jsResultRdd.rdd(), saveKey, "dm_gis.geo_api_test", new Tuple2[]{new Tuple2<>("inc_day", date)}, 10, SaveMode.Append, true);
//                    jsResultRdd.unpersist();

                } catch (Exception e) {
                    e.printStackTrace();
                    logger.error("process分区:{},失败", i);
                }
            }
        }
        sc.stop();
        logger.error("process end...");
    }

    public static JavaRDD<JSONObject> getJsResult(JavaRDD<JSONObject> rdd, String date) {
        JavaRDD<JSONObject> resultRdd = rdd.map(o -> {
            String address = o.getString("address");
            String opt = o.getString("opt");
            String cc = o.getString("cc");
            String city = o.getString("city");
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(geoUrl, opt, cc, URLEncoder.encode(address, "UTF-8"), city);
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);

                try {
                    String match_level_test = JSON.parseObject(content).getJSONObject("result").getString("match_level");
                    String type_test = JSON.parseObject(content).getJSONObject("result").getString("type");
                    String precision_test = JSON.parseObject(content).getJSONObject("result").getString("precision");
                    String xcoord_test = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
                    String ycoord_test = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
                    String adcode_test = JSON.parseObject(content).getJSONObject("result").getString("adcode");
                    String regcode_test = JSON.parseObject(content).getJSONObject("result").getString("regcode");
                    String adname_test = JSON.parseObject(content).getJSONObject("result").getString("adname");
                    String src_address_test = JSON.parseObject(content).getJSONObject("result").getString("src_address");
                    String src_test = JSON.parseObject(content).getJSONObject("result").getString("src");

                    o.put("match_level_test", match_level_test);
                    o.put("data_type_test", type_test);
                    o.put("precision_test", precision_test);
                    o.put("xcoord_test", xcoord_test);
                    o.put("ycoord_test", ycoord_test);
                    o.put("adcode_test", adcode_test);
                    o.put("regcode_test", regcode_test);
                    o.put("adname_test", adname_test);
                    o.put("src_address_test", src_address_test);
                    o.put("src_test", src_test);

                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    String dataSrc = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getString("dataSrc");
                    o.put("datasrc_test", dataSrc);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return o;
        }).map(o -> {
            List<String> list = new ArrayList<>();
            String src_test = o.getString("src_test");
            String datasrc = o.getString("datasrc");

            if (!StringUtils.equals(src_test, datasrc)) {
                list.add("datasrc");
            }

            String match_level = o.getString("match_level");
            String match_level_test = o.getString("match_level_test");
            if (!StringUtils.equals(match_level, match_level_test)) {
                list.add("match_level");
            }

            String data_type = o.getString("data_type");
            String data_type_test = o.getString("data_type_test");
            if (!StringUtils.equals(data_type, data_type_test)) {
                list.add("data_type");
            }

            String precision = o.getString("precision");
            String precision_test = o.getString("precision_test");
            if (!StringUtils.equals(precision, precision_test)) {
                list.add("precision");
            }

            String xcoord = o.getString("xcoord");
            String xcoord_test = o.getString("xcoord_test");
            if (!StringUtils.equals(xcoord, xcoord_test)) {
                list.add("xcoord");
            }

            String ycoord = o.getString("ycoord");
            String ycoord_test = o.getString("ycoord_test");
            if (!StringUtils.equals(ycoord, ycoord_test)) {
                list.add("ycoord");
            }

            String adcode = o.getString("adcode");
            String adcode_test = o.getString("adcode_test");
            if (!StringUtils.equals(adcode, adcode_test)) {
                list.add("adcode");
            }

            String regcode = o.getString("regcode");
            String regcode_test = o.getString("regcode_test");
            if (!StringUtils.equals(regcode, regcode_test)) {
                list.add("regcode");
            }
            o.put("flag", list.size() > 0 ? String.join("|", list) : "");
            o.put("inc_day", date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rdd.unpersist();
        return resultRdd;
    }

    public static JavaRDD<BeeLogsGisGeoParse> getResult(JavaRDD<BeeLogsGisGeoParse> rdd, String date) {
        JavaRDD<BeeLogsGisGeoParse> resultRdd = rdd.map(o -> {
            String address = o.getAddress();
            String opt = o.getOpt();
            String cc = o.getCc();
            String city = o.getCity();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(geoUrl, opt, cc, URLEncoder.encode(address, "UTF-8"), city);
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);

                try {
                    String match_level_test = JSON.parseObject(content).getJSONObject("result").getString("match_level");
                    String type_test = JSON.parseObject(content).getJSONObject("result").getString("type");
                    String precision_test = JSON.parseObject(content).getJSONObject("result").getString("precision");
                    String xcoord_test = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
                    String ycoord_test = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
                    String adcode_test = JSON.parseObject(content).getJSONObject("result").getString("adcode");
                    String regcode_test = JSON.parseObject(content).getJSONObject("result").getString("regcode");
                    String adname_test = JSON.parseObject(content).getJSONObject("result").getString("adname");
                    String src_address_test = JSON.parseObject(content).getJSONObject("result").getString("src_address");
                    String src_test = JSON.parseObject(content).getJSONObject("result").getString("src");

                    o.setMatch_level_test(match_level_test);
                    o.setData_type_test(type_test);
                    o.setPrecision_test(precision_test);
                    o.setXcoord_test(xcoord_test);
                    o.setYcoord_test(ycoord_test);
                    o.setAdcode_test(adcode_test);
                    o.setRegcode_test(regcode_test);
                    o.setAdname_test(adname_test);
                    o.setSrc_address_test(src_address_test);
                    o.setSrc_test(src_test);

                } catch (Exception e) {
                    e.printStackTrace();
                }

                try {
                    String dataSrc = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getString("dataSrc");
                    o.setDatasrc_test(dataSrc);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return o;
        }).map(o -> {
            List<String> list = new ArrayList<>();
            String src_test = o.getSrc_test();
            String datasrc = o.getDatasrc();

            if (!StringUtils.equals(src_test, datasrc)) {
                list.add("datasrc");
            }

            String match_level = o.getMatch_level();
            String match_level_test = o.getMatch_level_test();
            if (!StringUtils.equals(match_level, match_level_test)) {
                list.add("match_level");
            }

            String data_type = o.getData_type();
            String data_type_test = o.getData_type_test();
            if (!StringUtils.equals(data_type, data_type_test)) {
                list.add("data_type");
            }

            String precision = o.getPrecision();
            String precision_test = o.getPrecision_test();
            if (!StringUtils.equals(precision, precision_test)) {
                list.add("precision");
            }

            String xcoord = o.getXcoord();
            String xcoord_test = o.getXcoord_test();
            if (!StringUtils.equals(xcoord, xcoord_test)) {
                list.add("xcoord");
            }

            String ycoord = o.getYcoord();
            String ycoord_test = o.getYcoord_test();
            if (!StringUtils.equals(ycoord, ycoord_test)) {
                list.add("ycoord");
            }

            String adcode = o.getAdcode();
            String adcode_test = o.getAdcode_test();
            if (!StringUtils.equals(adcode, adcode_test)) {
                list.add("adcode");
            }

            String regcode = o.getRegcode();
            String regcode_test = o.getRegcode_test();
            if (!StringUtils.equals(regcode, regcode_test)) {
                list.add("regcode");
            }
            o.setFlag(list.size() > 0 ? String.join("|", list) : "");
            o.setInc_day(date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rdd.unpersist();
        return resultRdd;
    }

    public static BeeLogsGisGeoParse getField(String line) {
        BeeLogsGisGeoParse o = new BeeLogsGisGeoParse();
        String[] split = line.split("\t");

        try {
            o.setDatasrc(split[15]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setSrc_address(split[14]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setAdname(split[13]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setRegcode(split[12]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setAdcode(split[11]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setYcoord(split[10]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setXcoord(split[9]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setPrecision(split[8]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setData_type(split[7]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {

            o.setMatch_level(split[6]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {

            o.setSrc(split[5]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setCc(split[4]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            o.setOpt(split[3]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            o.setCity(split[2]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            o.setAddress(split[1]);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            o.setAk(split[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 生成1到8之间的随机数字
        Random random = new Random();
        int number = random.nextInt(8) + 1;
        o.setInc_day(number + "");
        return o;
    }
}
