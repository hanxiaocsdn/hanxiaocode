package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TbResUser implements Serializable {
    @Column(name = "loginid")
    private String loginid;
    @Column(name = "org_code")
    private String org_code;
    @Column(name = "service_dept")
    private String service_dept;

    public String getService_dept() {
        return service_dept;
    }

    public void setService_dept(String service_dept) {
        this.service_dept = service_dept;
    }

    public String getLoginid() {
        return loginid;
    }

    public void setLoginid(String loginid) {
        this.loginid = loginid;
    }

    public String getOrg_code() {
        return org_code;
    }

    public void setOrg_code(String org_code) {
        this.org_code = org_code;
    }
}
