package com.sf.gis.scala.sx.util

/**
  * Created by 01366807 on 2017/4/5.
  */
object Build {
  val DEBUG = 0
  val PRODUCT = 1
  val SAMPLETEST = true
  var target = Build.PRODUCT
}
