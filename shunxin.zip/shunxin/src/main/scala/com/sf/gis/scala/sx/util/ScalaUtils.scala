package com.sf.gis.scala.sx.util

import java.io.File
import java.text.SimpleDateFormat
import java.util.{Calendar, Date, Properties, UUID}

import com.sf.gis.java.sx.constant.util.{FileUtil, HttpRequest}
import org.apache.hadoop.fs.Path
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

import scala.collection.mutable
import scala.io.Source
import scala.sys.process._

/**
 * Created by 01366807 on 2017/5/8.
 */
object ScalaUtils {
    val properties = new java.util.Properties()
    var sc:SparkContext = null
    var spark:SparkSession = null
    var defaultPartitionSize = 100
    var defaultAppName = this.getClass.getSimpleName
    var bashInited = false

  def loadConfigInJar(path:String):Properties={
    val url = this.getClass.getClassLoader.getResource(path)//"conf.properties"
    System.err.println("==================="+url)
    val source = Source.fromURL(url)
    val prop = source.getLines().toArray.filter(item=>item.trim.length>0&&item.trim.indexOf("#")!=0).map(item=>item.split("=")).foreach(d=>{
      if(d.length==2){
        //System.err.println(d(0)+"="+d(1))
        properties.put(d(0).trim,d(1).trim)
      }else if(d.length==1){
        //System.err.println(d(0)+"=null")
        properties.put(d(0).trim,"")
      }else if(d.length>2){
        val key = d(0)
        var value = d.toIndexedSeq.slice(1,d.length).mkString("","=","")
        //System.err.println(key+"="+value)
        properties.put(key.trim,value.trim)
      }
    })
    properties
  }

    def defaultSparkConf()={
      val confPath = if(Build.target == Build.DEBUG) "conf.debug.properties" else "conf.product.properties"
      val properties = ScalaUtils.loadConfigInJar(confPath)
      System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

      val memrate = "0.5"
      val conf = new SparkConf()
        //.set("spark.rdd.compress", "true")
        //      .set("spark.memory.fraction",memrate)
        //      .set("spark.memory.storageFraction",memrate)
        //      .set("spark.storage.storageFraction",memrate)
        //.set("spark.shuffle.memoryFraction","0.3")//1.6版之前的旧的静态内存管理配置参数，1.6后已弃用
        //.set("spark.sql.autoBroadcastJoinThreshold","5242880") //join操作中数据量小于此值（10m默认）的表记录将被广播到各个executor上，-1表示禁用广播
        .set("spark.sql.autoBroadcastJoinThreshold","-1")
        .set("spark.sql.broadcastTimeout",(20*60).toString)
        .set("spark.shuffle.consolidateFiles","true")  //map端合并小文件
        .set("spark.shuffle.file.buffer","512k")
        .set("spark.reducer.maxSizeInFlight","24M")
        .set("spark.shuffle.io.maxRetries","120")
        .set("spark.shuffle.io.retryWait","30s")
        .set("spark.locality.wait","10")
        .set("spark.hadoop.validateOutputSpecs", "false")//数据直接覆盖写入hdfs，不进行存在判断。
        .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .set("spark.kryoserializer.buffer.max",ScalaUtils.getProperty("spark.kryoserializer.buffer.max"))
        .set("spark.core.connection.ack.wait.timeout","90000")//shuffle 网络连接超时时间默认60秒
        .set("spark.executor.heartbeatInterval","30000") //executor 向 the driver 汇报心跳的时间间隔，单位毫秒 。 默认10秒
        .set("spark.network.timeout","90000")
        .set("spark.rpc.askTimeout","90000")
        .set("spark.scheduler.maxRegisteredResourcesWaitingTime","90000")
        .set("dfs.client.read.shortcircuit","false")
        .set("spark.speculation","false")
        .set("spark.sql.crossJoin.enabled", "true")
        .set("spark.eventQueue.size","1000000")
        .set("spark.event.listener.logEnable","true")
        .set("spark.executor.memoryOverhead",ScalaUtils.getProperty("spark.executor.memoryOverhead"))
        //.set("spark.memory.offHeap.enabled","true")
        //.set("spark.memory.offHeap.size","4096")
        .set("spark.driver.extraJavaOptions",ScalaUtils.getProperty("spark.driver.extraJavaOptions"))
        .set("spark.executor.extraJavaOptions",ScalaUtils.getProperty("spark.executor.extraJavaOptions"))
        .set("spark.port.maxRetries","60000")
        .set("spark.driver.maxResultSize", "128g")
        .set("spark.rpc.io.backLog", "10000")
        .set("spark.cleaner.referenceTracking.blocking", "false")
        .set("hive.execution.engine","mr")
        .set("spark.streaming.stopGracefullyOnShutdown", "true")
        .set("spark.io.compression.codec","org.apache.spark.io.SnappyCompressionCodec")
        .set("spark.driver.allowMultipleContexts","true")
        .set("spark.sql.tungsten.enabled", "false")
        .set("mapreduce.map.log.level","ERROR")
        .set("mapreduce.reduce.log.level","ERROR")
        .set("yarn.nodemanager.pmem-check-enabled","false")
        .set("yarn.nodemanager.vmem-check-enabled","false")
        .set("spark.blacklist.enabled","true")
        .set("spark.yarn.maxAppAttempts","1000")
      //                .set("spark.sql.warehouse.dir","hdfs://sfbdp1/user/hive/warehouse/")
      //                .set("hive.metastore.warehouse.dir","hdfs://sfbdp1/user/hive/warehouse/")

      //.set("spark.sql.files.ignoreCorruptFiles","true")
      //.set("parquet.column.index.access","false")
      //.set("spark.sql.parquet.mergeSchema","true")
      //.set("spark.sql.hive.convertMetastoreParquet","true")
      //.set("spark.sql.hive.convertMetastoreParquet.mergeSchema","true")


      //.set("spark.eventLog.enabled","true")
      //.set("spark.yarn.historyServer.address","http://cnsz17pl2288:18080")
      //.set("spark.eventLog.dir","hdfs://sfbd/log/spark")

      conf
    }

    var t0 = 0l
    var t0Total = 0l
    def memTime() = {
        t0 = new Date().getTime
    }


  def getProperty(key:String) ={
    val value = properties.getProperty(key)
    if(value==null){
      System.err.println("-------------- WARN Util.getProperty(\""+key+"\") return null --------------")
    }
    value
  }

  def getWeek(dayid:String) ={
    val t = dayid.replaceAll("-","")
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
    begintm.getTime().getDay
  }

  def showCost(title:String="",enter:Boolean=true)={
    val mss = new Date().getTime - t0
    val s = formatTime(mss)
    System.err.println((if(title.indexOf("耗时")== -1) title+"，耗时：" else title)+s + (if(enter)"\n" else ""))
    ScalaUtils.memTime()
    s
  }

    def initSpark(appName:String=this.getClass.getSimpleName,initConf:SparkConf=null,cleanEnv:Boolean=true) ={
        if(ScalaUtils.spark == null || ScalaUtils.spark.sparkContext==null || ScalaUtils.spark.sparkContext.isStopped){
          ScalaUtils.memTime()
            defaultAppName = appName//MD5Util.getMD5(appName)
            val conf = if(initConf == null) defaultSparkConf().setAppName(defaultAppName) else initConf.setAppName(defaultAppName)

            spark = SparkSession.builder().config(conf).config("spark.sql.warehouse.dir","hdfs://sfbdp1/user/hive/warehouse/").enableHiveSupport().getOrCreate()
            sc=spark.sparkContext
            sc.setLogLevel("ERROR")
            defaultPartitionSize = sc.getConf.get("spark.executor.instances", "16").toInt * sc.getConf.get("spark.executor.cores", "2").toInt * 2
            //val spark = new HiveContext(sc)
            val mmm = ScalaUtils.getProperty("hive.mapreduce.map.memory.mb")
            val mrm = ScalaUtils.getProperty("hive.mapreduce.reduce.memory.mb")
            val ynv = ScalaUtils.getProperty("hive.yarn.nodemanager.vmem-pmem-ratio")
            spark.sql("set dfs.client.read.shortcircuit=false")
            spark.sql("set spark.sql.thriftserver.scheduler.pool=spark")
            spark.sql("set mapred.max.split.size=1000000000")
            spark.sql("set mapred.min.split.size.per.node=1000000000")
            spark.sql("set mapred.min.split.size.per.rack=1000000000")
            spark.sql("set hive.fetch.task.conversion=more")
            spark.sql("set hive.cli.print.header=true")
            spark.sql("set hive.execution.engine=mr")
            spark.sql("set hive.exec.mode.local.auto=false")
            spark.sql("set hive.exec.reducers.max=500")
            spark.sql("set hive.exec.compress.output=false")
            spark.sql("set hive.exec.compress.intermediate=true")
            spark.sql("set hive.exec.dynamic.partition=true")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.sql("set hive.exec.max.dynamic.partitions=100000")
            spark.sql("set hive.exec.max.dynamic.partitions.pernode=100000")
            spark.sql("set hive.groupby.skewindata=true")
            spark.sql("set hive.auto.convert.join=true")
            spark.sql("set hive.metastore.schema.verification=false")
            spark.sql("set hive.input.format=org.apache.Hadoop.hive.ql.io.CombineHiveInputFormat")
            spark.sql("set hive.merge.mapfiles=true")
            spark.sql("set hive.merge.mapredfiles=true")
            spark.sql("set hive.merge.size.per.task=1000000000")
            spark.sql("set hive.merge.smallfiles.avgsize=1000000000")
            spark.sql("set mapreduce.map.memory.mb="+mmm);
            spark.sql("set mapreduce.reduce.memory.mb="+mrm);
            spark.sql("set spark.sql.shuffle.partitions=50")
            spark.sql("set parquet.block.size=268435456") //256m

            //Util.runShellCmd(s"./rm -rf /log/hive/hive/spark_tmp_${defaultAppName.replaceAll("$","")}")
            val week = ScalaUtils.getWeek(ScalaUtils.getTodayDayid())
            if(week==6 && cleanEnv){
                //        spark.sparkContext.makeRDD(0 to Util.defaultPartitionSize).repartition(Util.defaultPartitionSize/2).foreachPartition(p=>{
                //          val f = new File("/log/hive/hive")
                //          if(f.exists() && f.canWrite())
                //            Util.runShellCmd(s"./rm -rf /log/hive/hive/spark_tmp_${appName.replaceAll("$","")}")
                //        })
            }
            //    scala.sys.addShutdownHook {
            //      //stopSpark(cleanEnv)
            //      try{
            //        if(week == 6 && cleanEnv)
            //          Util.runShellCmd(s"./rm -rf /log/hive/hive/spark_tmp_${defaultAppName.replaceAll("$","")}")
            //        sc.stop()
            //        spark.stop()
            //        //      if(sc!=null && !sc.isStopped ){
            //        //        sc.stop()
            //        //        sc = null
            //        //      }
            //      }catch{
            //        case e:Exception=>{
            //          //e.printStackTrace(System.err)
            //        }
            //      }
            //    }

          ScalaUtils.showCost("spark 初始化完毕")

            println("--------------------------------------------------------------------")
            println(s"tracking URL: http://cnsz17pl2288:54315/proxy/${spark.sparkContext.applicationId}/")
            println(s"tracking URL: http://bdp.sf-express.com/proxy/${spark.sparkContext.applicationId}/")
            //println("spark.driver.appUIAddress : "+spark.conf.get("spark.driver.appUIAddress","not found"))

            spark.conf.getAll.foreach(d=>{
                println(s"${d._1}: ${d._2}")
            })
            println("--------------------------------------------------------------------")
            println("今日星期："+ScalaUtils.getWeek(ScalaUtils.getTodayDayid()))
        }

        spark
    }

    def getTodayDayid() ={
        val begintm = Calendar.getInstance()
        new SimpleDateFormat("yyyyMMdd").format(begintm.getTime())
    }

    def formatTime(mss:Long,showCurrentTime:Boolean = true) ={
        val days = mss / (1000 * 60 * 60 * 24)
        val hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
        val minutes = (mss % (1000 * 60 * 60)) / (1000 * 60)
        val seconds = (mss % (1000 * 60)) / 1000
        var s = if(days>0) days+"天 " else ""
        s = s + (if(hours>0) hours+"小时 " else "")
        s = s + (if(minutes>0) minutes+"分钟 " else "")
        s = s + (if(seconds>0) seconds+"秒" else (mss % (1000 * 60) + "毫秒"))
        if(showCurrentTime)
            s = s + " ["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())+"]"
        s
    }

  def hdfsMkdir(path:String)={
    val hadoopConf = spark.sparkContext.hadoopConfiguration
    val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
    val p = new Path(path)
    if(!hdfs.exists(p))
      hdfs.mkdirs(p)
    if(!hdfs.exists(new Path(path))){
      s"hdfs dfs -mkdir -p $path"!;
    }
  }

  def hdfsRM(path:String):Unit={
    val log = ScalaUtils.runShellCmd(s"hdfs dfs -rm -r -f $path")
    if(log!=null && log.contains("无法删除受保护目录")){
      val hadoopConf = spark.sparkContext.hadoopConfiguration
      val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
      val p = new Path(path)
      if(hdfs.exists(p))
        hdfs.delete(p,true)
    }
  }

  def freeMem(keep:RDD[_]*): Unit ={
    clearGroupByQueryCache()

    ScalaUtils.spark.catalog.clearCache()
    var cnt = 0 //Util.spark.sparkContext.getPersistentRDDs.size
    //System.err.println("----------------------------------------【清除缓存RDD开始】------------------------------------------")
    ScalaUtils.spark.sparkContext.getPersistentRDDs.foreach(d=>{
      //System.err.println("清除缓存RDD："+d._2.toString())
      if(keep.isEmpty || !keep.contains(d._2)){
        d._2.unpersist()
        cnt += 1
      }
    })
    //System.gc()
    //System.err.println("----------------------------------------【清除缓存RDD完成】------------------------------------------")
    System.err.println(s"【清除缓存RDD数量：${cnt}】")
  }

  val hm_makeGroupByQuery = new mutable.HashMap[String,Boolean]()

  def clearGroupByQueryCache(): Unit ={
    hm_makeGroupByQuery.keys.foreach(k=>{
      ScalaUtils.spark.catalog.uncacheTable(k)
    })
    hm_makeGroupByQuery.clear()
  }

  def addPartition(db:String,table:String,partitionBy:String,hdfsPath:String)={
    if(db!=null && db.length>0 && partitionBy!=null && partitionBy.length>0){
      if(spark!=null && !spark.sparkContext.isStopped){
        val cmd = s"alter table $db."+table+" add if not exists partition ("+partitionBy+") location '"+hdfsPath+"'"
        spark.sql(cmd)
      }else{
        val sql = s"""
use $db;
alter table $table add if not exists partition ($partitionBy) location '$hdfsPath';"""
        ScalaUtils.runHiveSQL(db,sql)
      }
    }
  }

  def fixnull(ak:String,defaultVal:String = "")={
    if(ak==null||ak.trim==""||ak.trim.toLowerCase()=="null") defaultVal else ak
  }

  def printException(e:Exception): Unit ={
    System.err.println(e.getMessage+"\t"+e.getCause)
    e.printStackTrace(System.err)
  }

  def tryPost(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1):String = {
    // --jars httpclient-4.5.3.jar
    var result:String = null
    try{
      result = HttpRequest.sendPost(url,para)
    }catch{
      case e:Exception=>{
        if(msgLength== -1)
          System.err.println("++++++++++++++++++++++++++++++++\n"+para)
        else if(msgLength>0){
          System.err.println("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
        }
        ScalaUtils.printException(e)
        if(currentTrys<tryTimes){
          val wait = (currentTrys+1) * 2
          //System.err.println("retry waiting seconds: "+ wait)
          Thread.sleep(wait * 500)
          result = tryPost(url,para,tryTimes,currentTrys+1,msgLength)
        }
      }
    }
    result
  }

  def tryGet(url:String,tryTimes:Int,currentTrys:Int=0,responseEncode:String="utf-8"):String = {
    // --jars httpclient-4.5.3.jar

    var result:String = null
    try{
      //result = HttpRequest.sendGet(url)
      result = HttpRequest.sendGetEncode(url,responseEncode)
    }catch{
      case e:Exception=>{
        if(currentTrys == tryTimes-1) {
          System.err.println("【REQ】"+url)
          System.err.println("【RST】"+result)
        }

        if(currentTrys<tryTimes){
          //System.err.println("retry waiting seconds: "+(currentTrys+1))
          Thread.sleep((currentTrys+1)*1000)
          result = tryGet(url,tryTimes,currentTrys+1,responseEncode)
        }
      }
    }
    result
  }

  def runHiveSQL(db:String,sql:String,logPath:String=null): Unit ={
    var log = ""
    val sh = "./_runhivesql_"+UUID.randomUUID()+".sh"
    val sqlFile = "./_runhivesql_"+UUID.randomUUID()+".sql"
    var cmd = ""
    if(logPath!=null){
      log = " > "+logPath
    }

    var useSqlFile = false
    val d = "" //"--hiveconf hive.root.logger=OFF -S"
    if(sql.indexOf(";") != -1 || sql.indexOf("\n") != -1){
      FileUtil.save(sqlFile,sql)

      cmd = "/app/hive/bin/hive "+d+" --database "+db+" -f "+sqlFile + log
      System.err.println(sql)
      System.err.println(cmd)
      useSqlFile = true
    }else{
      cmd = "/app/hive/bin/hive "+d+" --database "+db+" -e \""+sql+"\"" +log
      System.err.println(cmd)
    }

    FileUtil.save(sh,cmd)
    //    "chmod +x "+sh !;
    //    sh !;
    //    "./rm -rf "+sh !;
    initBash
    try{
      "./bash "+sh !;
    }catch {
      case e:Exception=>{
        "chmod +x "+sh !;
        sh !;
      }
    }
    new File(sh).deleteOnExit()
    if(useSqlFile)
      try{
        "./rm -rf "+sqlFile !;
      }catch{
        case e:Exception=>{
          "rm -rf "+sqlFile !;
        }
      }

  }

    def runShellCmd(cmd:String,logPath:String=null,printCmd:Boolean=true,printResult:Boolean=true): String ={
        //System.err.println
        if(System.getProperty("sun.desktop")=="windows"){
            cmd !;
            return ""
        }
        initBash
        if(printCmd)
            System.err.println(cmd)
        val sh = "./_runShellCmd_"+UUID.randomUUID+".sh"
        val tmplog = "./_tmplog_"+UUID.randomUUID+".txt"
        val logFile = if(logPath!=null && logPath.length>0) logPath else tmplog
        FileUtil.save(sh,cmd + " &>"+logFile)
        //"chmod +x "+sh !;
        try{
            "./bash "+sh !;
        }catch {
            case e:Exception=>{
                "chmod +x "+sh !;
                sh !;
            }
        }
        new File(sh).deleteOnExit()
        //System.err.println("cat "+logFile)
        //"cat "+logFile !;

        val f = new File(logFile)
        if(f.exists()){
            val log = FileUtil.readFileByLines(logFile,false)
            if(logPath==null || logPath.length==0)
                f.delete()
            if(printResult)
                System.err.println(log)
            log
        }else ""
    }

    def initBash(): Unit ={
        this.synchronized {
            if(System.getProperty("sun.desktop")=="windows")
                return

            var hasException = false
            while((!hasException) && (!new File("./rm").exists() || !new File("./sed").exists() || !new File("./bash").exists())){
                try{
                    "rm -rf ./bash.zip"!;
                    "rm -rf ./rm"!;
                    "rm -rf ./sed"!;
                    "rm -rf ./bash"!;
                    "hdfs dfs -get /user/01366807/upload/bash.zip ."!;
                    "unzip -o ./bash.zip"!;
                    "chmod +x ./bash"!;
                    "chmod +x ./rm"!;
                    "chmod +x ./sed"!;
                }catch {
                    case e:Exception=>{
                        System.err.println("----------------------------------------------------------------------")
                        System.err.println("bash download faild")
                        System.err.println("----------------------------------------------------------------------")
                        hasException = true
                    }
                }

                var c = 0
                while(c<600 && new File("./bash").length() != 951096){
                    System.err.print(".")
                    if((c+1) % 100 == 0)
                        System.err.println()
                    Thread.sleep(100)
                    c += 1
                }

                System.err.println("""【bash size】 """+new File("./bash").length())
                if(c>=600){
                    System.err.println("----------------------------------------------------------------------")
                    System.err.println("bash size faild")
                    System.err.println("----------------------------------------------------------------------")
                    hasException = true
                }else{
                    System.err.println("========================================================================")
                    "./bash --version"!;
                    System.err.println("========================================================================")
                }
            }
            bashInited = true
        }
    }
}
