package com.sf.gis.scala.sx.util

import java.io.{BufferedReader, InputStream, InputStreamReader}
import java.net.{HttpURLConnection, URL}

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger

/**
  * Created by 01375125 on 2018/11/6.
  * HttpClient工具类
  */
object HttpClientUtil {
  val logger:Logger = Logger.getLogger(this.getClass.getName.replaceAll("$",""))

  /**
    * 访问http请求，返回字符串结果
    * @param url
    * @return
    */
  def getStrByGet(url:String): String ={
    val httpClient = HttpClients.createDefault()
    try {
      val httpGet = new HttpGet(url)
      var httpResponse:CloseableHttpResponse = null
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity:HttpEntity = httpResponse.getEntity

        try{
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          return stringEntity
        }
        catch {
          case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
        }
      }
      httpResponse.close()
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    httpClient.close()
    null
  }

  /**
    * 访问http请求，返回字符串结果
    * @param url
    * @return
    */
  def getStreamByGet(url:String): InputStream ={
    val httpClient = HttpClients.createDefault()
    var is: InputStream= null
    val httpGet = new HttpGet(url)
    var httpResponse:CloseableHttpResponse = null

    try {
      httpResponse = httpClient.execute(httpGet)
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
      val httpEntity:HttpEntity = httpResponse.getEntity
      if(httpEntity!=null){

        try {
          is = httpEntity.getContent
        } catch {
          case e:Exception =>logger.error(">>>获取数据流失败："+e)
        }
      }

    }
    is
  }

  /**
    * 访问http请求，返回JSON结果
    * @param url
    * @return
    */
  def getJsonByGet(url:String): JSONObject ={
    val httpClient = HttpClients.createDefault()
    var jsonObj:JSONObject = null
    try {
      var httpResponse:CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity:HttpEntity = httpResponse.getEntity

        try{
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
          }
        }
        catch {
          case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
        }
      }
      httpResponse.close()
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    httpClient.close()
    jsonObj
  }
  /**
    * 访问http请求，返回JSON结果
    * @param url
    * @return
    */
  def getJsonByGet(url:String,tryCnt:Int): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    var count = 0
    while (count < tryCnt) {
      count = count + 1
      try {
        var httpResponse: CloseableHttpResponse = null
        val httpGet = new HttpGet(url)
        httpResponse = httpClient.execute(httpGet)
        if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
          val httpEntity: HttpEntity = httpResponse.getEntity
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          jsonObj = JSON.parseObject(stringEntity)
          count = tryCnt
        }
        httpResponse.close()
      }
      catch {
        case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
          Thread.sleep(1000)
      }

  }
    httpClient.close()
    jsonObj
  }
}
