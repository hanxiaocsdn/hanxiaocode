package com.sf.gis.scala.sx.util

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import scala.collection.mutable.ArrayBuffer

object DateTimeUtil extends Serializable {

    def main(args: Array[String]): Unit = {
//        println(getConvertFormatDate("2020-09-17 17:12:52","yyyy-MM-dd HH:mm:ss","yyyy-MM-dd"))


        println(DateTimeUtil.getDaysApartDate("yyyyMMdd", "20210730", -30))
    }


    /**
      * @note 将日期转换为指定的日期格式
      * @param srcDate  源日期
      * @param srcDateFormat   源日期格式
      * @param destDateFormat   目标日期格式
      * @return
      */
    def getConvertFormatDate(srcDate: String, srcDateFormat: String, destDateFormat: String): String = {
        val date = new SimpleDateFormat(srcDateFormat).parse(srcDate)
        val destDate = new SimpleDateFormat(destDateFormat).format(date)
        destDate
    }

    /**
      * 获得两个字符串日期中所有日期的字符格式集合
      * @param startDateStr
      * @param endDateStr
      * @return
      */
    def getBetweenDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
        val sdf = new SimpleDateFormat("yyyy-MM-dd")
        val dateListStr = new ArrayBuffer[String]
        try {
            val startDate = sdf.parse(startDateStr)
            val endDate = sdf.parse(endDateStr)
            val dateList = getBetweenDates(startDate, endDate)
            for (date <- dateList)
                dateListStr += sdf.format(date)
        } catch {
            case e: ParseException => println(">>>Date Convert Exception..." + e)
        }
        dateListStr
    }

    def getBetweenDatesStr(startDateStr: String, endDateStr: String, dateFormat:String): ArrayBuffer[String] = {
        val sdf = new SimpleDateFormat(dateFormat)
        val dateListStr = new ArrayBuffer[String]
        try {
            val startDate: Date = sdf.parse(startDateStr)
            val endDate: Date = sdf.parse(endDateStr)
            val dateList = getBetweenDates(startDate, endDate)
            for (date <- dateList)
                dateListStr += sdf.format(date)
        } catch {
            case e: ParseException => println(">>>Date Convert Exception..." + e)
        }
        dateListStr
    }


    /**
      * 获得两个日期之间的所有日期列表
      * @param start
      * @param end
      * @return
      */
    def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
        val result = new ArrayBuffer[Date]
        val tempStart = Calendar.getInstance
        tempStart.setTime(start)
        tempStart.add(Calendar.DAY_OF_YEAR, 1)
        val tempEnd = Calendar.getInstance
        tempEnd.setTime(end)
        while (tempStart.before(tempEnd)) {
            result += tempStart.getTime
            tempStart.add(Calendar.DAY_OF_YEAR, 1)
        }
        result
    }

    /**
      * 获取本机日历日期
      * @param delta
      * @return
      */
    def dateDelta(delta: Int): String = {
        dateDelta(delta, "-")
    }

    /**
      * 获取本机日历日期
      * @param delta
      * @return
      */
    def dateDelta(delta: Int, separator: String): String = {
        val sdf = new SimpleDateFormat("yyyy" + separator + "MM" + separator + "dd")
        val cal = Calendar.getInstance()
        cal.add(Calendar.DATE, delta)
        val date = sdf.format(cal.getTime)
        date
    }

    /**
      * 获取本机当前系统时间并转换为指定日期格式
      * @param  format 日期格式
      * @return
      */
    def getCurrentSystemTime(format: String): String ={
        val simpleDateFormat = new SimpleDateFormat(format)
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DATE, 0)
        val dateTime = simpleDateFormat.format(calendar.getTime)
        dateTime
    }


    /**
      * @note   获取距离指定日期相隔days天的的日期：
      * @param inputDateStr 指定日期
      * @param days          相隔天数 正数表示在之后n天，负数表示在之前n天
      * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
      * @return
      **/
    def getDaysApartDate(dateFormat: String, inputDateStr: String, days: Integer): String = {
        val simpleDateFormat = new SimpleDateFormat(dateFormat)
        val inputDate: Date = simpleDateFormat.parse(inputDateStr)
        val calendar = Calendar.getInstance
        calendar.setTime(inputDate)
        calendar.add(Calendar.DAY_OF_YEAR, days)
        val date = calendar.getTime
        val dateStr = simpleDateFormat.format(date).trim
        dateStr
    }

    /**
      * 时间字符串转换成毫秒值
      * @param time
      * @return
      */
    @throws[ParseException]
    def timeToLong(time: String, format: String): Long = {
        val sf = new SimpleDateFormat(format)
        sf.parse(time).getTime
    }

    /**
      * @note   时间戳转换为时分秒
      * @param timestamp
      * @param format
      * @return
      */
    def longToTime(timestamp:Long,format:String, duration:Long=0L ): String ={
        var datetime = ""
        try {
            val simpleDateFormat = new SimpleDateFormat(format)
            datetime = simpleDateFormat.format(new Date(timestamp + duration))
        } catch {
            case e:Exception =>println(">>>>>>时间戳解析异常Exception: " + e)
        }
        datetime
    }

    /**
      * @note   时间戳转换为指定的日期格式
      * @param timestamp
      * @param format 指定的日期格式
      * @return
      */
    def timestampConvertDate(timestamp:Long, format:String): String ={
        var datetime = timestamp.toString
        try {
            val simpleDateFormat = new SimpleDateFormat(format)
            datetime = simpleDateFormat.format(timestamp)
        } catch {
            case e:Exception =>println(">>>>>>时间戳解析异常Exception: " + e)
        }
        datetime
    }


}
