package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util.Date
import java.util.concurrent.{Callable, Executors}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.sx.constant.util.{Database, FileAppender}
import com.sf.gis.scala.sx.util.{Counter, ScalaUtils}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.storage.StorageLevel

import scala.sys.process._

object ChknETLV2 {
    case class Detail(address: String, cityCode: String, deliverytype: String, zno_code: String,dept: String,znocode:String,
                      depart_code: String,aoiid:String,aoi_id:String, group_id:String,group_group: String, standardization: String,
                      keyword: String, hasloc:Boolean,hastxt:Boolean,isbehind:Boolean,tag: Int,tag1:Int,tag2:Int,splitinfo: String,
                      action:Int,result:Int,one_group:String, norm_rsp: String, hp_rsp: String,extend_attach8:String,aoiunit_norm:String,aoiunit_hp:String,aoiunit_redis:String,flag:String)


    val sep = "\u0001"
    val driver = "com.mysql.jdbc.Driver"
    val url = "jdbc:mysql://wchka-m.dbdr.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull"
    val uid = "wchka_aoi"
    val pwd = "giscmsaoi123"

    def countCity(): Unit ={
        val citydef =
            s"""010=1
               |020=2
               |021=3
               |755=4
               |022,023,024,025,027,028,029,052,053,086,088,310,311,312,313,314,315,316,317,318=5
               |319,335,349,350,351,352,353,354,355,356,357,358,359,370,371,372,373,374,375,376=6
               |377,378,379,391,392,393,394,395,396,398,411,412,414,415,416,417,418,419,421,427=7
               |429,431,432,433,434,435,436,437,438,439,451,452,453,454,455,456,457,458,459,464=8
               |467,468,469,470,471,472,473,474,475,476,477,478,479,482,483,510,511,512,513,514=9
               |515,516,517,518,519,523,527,530,531,532,533,534,535,536,537,538,539,543,546,550=10
               |551,552,553,554,555,556,557,558,559,561,562,563,564,566,570,571,572,573,574,575=11
               |576,577,578,579,580,591,592,593,594,595,596,597,598,599,631,632,633,634,635,660=12
               |662,663,668,691,692,701,710,711,712,713,714,715,716,717,718,719,722,724,728,730=13
               |7311,7312,7313,734,735,736,737,738,739,743,744,745,746,750,751,752,753,754,756,757=14
               |758,759,760,762,763,766,768,769,770,771,772,773,774,775,776,777,778,779,790,791=15
               |792,793,794,795,796,797,798,799,812,813,816,817,818,825,826,827,830,831,832,833=16
               |834,835,836,837,838,839,851,852,853,854,855,856,857,858,859,870,871,872,873,874=17
               |875,876,877,878,879,883,886,887,891,892,893,894,895,896,897,898,8981,8982,8983,901=18
               |902,903,906,908,909,911,912,913,914,915,916,917,919,930,931,932,933,934,935,936=19
               |937,938,939,941,943,951,952,953,954,955,970,971,972,973,974,975,976,977,979,990,991,992,993,994,995,996,997,998,999=20""".stripMargin
                    .split("\n").filter(_.length > 0).map(d => {

                val t = d.split("=")
                if (t.size > 1) {
                    val v = t(1)
                    t(0).split(",").map(cityCode => {
                        (cityCode, v)
                    })
                } else {
                    println("parse error:" + d)
                    null
                }
            }).filter(_ != null).flatMap(d => d).toMap

        val citys = s"010,020,021,022,023,024,025,027,028,029,052,053,086,088,310,311,312,313,314,315,316,317,318,319,335,349,350,351,352,353,354,355,356,357,358,359,370,371,372,373,374,375,376,377,378,379,391,392,393,394,395,396,398,411,412,414,415,416,417,418,419,421,427,429,431,432,433,434,435,436,437,438,439,451,452,453,454,455,456,457,458,459,464,467,468,469,470,471,472,473,474,475,476,477,478,479,482,483,510,511,512,513,514,515,516,517,518,519,523,527,530,531,532,533,534,535,536,537,538,539,543,546,550,551,552,553,554,555,556,557,558,559,561,562,563,564,566,570,571,572,573,574,575,576,577,578,579,580,591,592,593,594,595,596,597,598,599,631,632,633,634,635,660,662,663,668,691,692,701,710,711,712,713,714,715,716,717,718,719,722,724,728,730,7311,7312,7313,734,735,736,737,738,739,743,744,745,746,750,751,752,753,754,755,756,757,758,759,760,762,763,766,768,769,770,771,772,773,774,775,776,777,778,779,790,791,792,793,794,795,796,797,798,799,812,813,816,817,818,825,826,827,830,831,832,833,834,835,836,837,838,839,851,852,853,854,855,856,857,858,859,870,871,872,873,874,875,876,877,878,879,883,887,891,892,893,894,895,896,897,898,8981,901,902,903,906,908,909,911,912,913,914,915,916,917,919,930,931,932,933,934,935,936,937,938,939,941,943,951,952,953,954,955,970,971,972,973,974,975,976,977,979,990,991,992,993,994,995,996,997,998,999".split(",")
        val db = new com.sf.gis.java.sx.constant.util.Database(driver, url, uid, pwd)



        citys.map(cityCode=>{
            val cityPartition = citydef.getOrElse(cityCode, "0")
            val debugZcCnd = "" // and zno_code ='512QC'" //todo remove this //  " and zno_code ='512QC'" //
//extend_attach8 is not null and extend_attach8<>'' and
            var sql = s"""select count(1) from wchka.cms_address_$cityPartition where city_code='$cityCode' and `type`=2 and delivery_type in (0,2) and del_flag=0 and zno_code like '$cityCode%' $debugZcCnd """
            val cnt = db.getOneValue(sql)

            //extend_attach8 is not null and extend_attach8<>'' and
            sql = s"""select * from wchka.cms_address_$cityPartition where city_code='$cityCode' and `type`=2 and delivery_type in (0,2) and del_flag=0 and zno_code like '$cityCode%' $debugZcCnd limit 3"""
            val json = db.getJsonValue(sql)
            println(json)
            println(cityCode+","+cnt)
            (cityCode,cnt)
        }).foreach(d=>println(d.productIterator.mkString(",")))

        db.closeConnection()
    }

    def main(args: Array[String]): Unit = {

//        countCity()
//        if(true)
//            return
        val day = ScalaUtils.getTodayDayid().substring(6,8).toInt.toString

      ScalaUtils.initSpark(this.getClass.getSimpleName)

        println("---------------------------------------------------------------------")
        "ls -l -a *CRC*"!;
        "ls -l -a *crc*"!;
        "ls -l -a *csv*"!;
        println("---------------------------------------------------------------------")
        s"rm -rf *.csv*"!;
        s"rm -rf ./*.csv*"!;
        s"rm -rf *crc*"!;
        s"rm -rf ./*crc*"!;
        s"rm -rf *CRC*"!;
        s"rm -rf ./*CRC*"!;
      ScalaUtils.runShellCmd(s"./rm -rf *.csv*")
      ScalaUtils.runShellCmd(s"./rm -rf ./*.csv*")
      ScalaUtils.runShellCmd(s"./rm -rf *crc*")
      ScalaUtils.runShellCmd(s"./rm -rf ./*crc*")
      ScalaUtils.runShellCmd(s"./rm -rf *CRC*")
      ScalaUtils.runShellCmd(s"./rm -rf ./*CRC*")
        println("=====================================================================")
        "ls -l -a *CRC*"!;
        "ls -l -a *crc*"!;
        "ls -l -a *csv*"!;
        println("=====================================================================")

        val tbPath = "hdfs://sfbdp1/user/hive/warehouse/dm_gis.db/chkn_etl_v2"
        //Util.spark.sql("drop table if exists dm_gis.chkn_etl_v2")
        //Util.hdfsRM(tbPath)
      ScalaUtils.hdfsMkdir(tbPath)
      ScalaUtils.spark.sql(
            s"""
               |create external table if not exists dm_gis.chkn_etl_v2(
               |    address String,
               |    citycode String,
               |    deliverytype String,
               |    zno_code String,
               |    dept String,
               |    znocode String,
               |    depart_code String,
               |    aoiid String,
               |    aoi_id String,
               |    group_id String,
               |    group_group String,
               |    standard String,
               |    keyword String,
               |    hasloc String,
               |    hastxt String,
               |    isbehind String,
               |    tag Int,
               |    tag1 Int,
               |    tag2 Int,
               |    splitinfo String,
               |    action Int,
               |    result Int,
               |    one_group String,
               |    norm_rsp String,
               |    hp_rsp String,
               |    extend_attach8 String,
               |    aoiunit_norm String,
               |    aoiunit_hp String,
               |    aoiunit_redis String,
               |    flag String
               |    ) PARTITIONED BY (inc_day string,city_code string)  ROW FORMAT DELIMITED FIELDS TERMINATED BY '$sep' LINES TERMINATED BY '\\n' LOCATION '$tbPath'""".stripMargin)

        //val plans = s"""023,20201218;028,20201221;411,20201222;510,20201222;836,20201222;837,20201222;511,20201223;514,20201223;519,20201223;894,20201223;592,20201224;594,20201224;817,20201224;818,20201224;825,20201224;595,20201225;812,20201225;813,20201225;816,20201225;826,20201228;827,20201228;830,20201228;894,20201228;831,20201229;832,20201229;833,20201229;834,20201229;835,20201229;838,20201229;839,20201229;891,20201229;892,20201229;891,20201230;892,20201230;894,20201230""".stripMargin
        //val plans = s"""025,20210108;355,20210108;415,20210108;459,20210108;527,20210108;563,20210108;660,20210108;736,20210108;771,20210108;856,20210108;939,20210108;997,20210108;027,20210109;464,20210109;530,20210109;564,20210109;662,20210109;737,20210109;772,20210109;857,20210109;901,20210109;941,20210109;998,20210109;029,20210110;357,20210110;417,20210110;467,20210110;566,20210110;738,20210110;773,20210110;858,20210110;902,20210110;943,20210110;999,20210110;052,20210111;358,20210111;418,20210111;468,20210111;532,20210111;570,20210111;668,20210111;739,20210111;774,20210111;859,20210111;903,20210111;951,20210111;053,20210112;359,20210112;421,20210112;469,20210112;533,20210112;571,20210112;691,20210112;743,20210112;775,20210112;870,20210112;906,20210112;952,20210112;086,20210113;370,20210113;427,20210113;470,20210113;534,20210113;572,20210113;692,20210113;744,20210113;776,20210113;871,20210113;908,20210113;953,20210113;088,20210114;371,20210114;429,20210114;471,20210114;535,20210114;573,20210114;701,20210114;745,20210114;777,20210114;872,20210114;909,20210114;954,20210114;372,20210115;431,20210115;472,20210115;536,20210115;574,20210115;746,20210115;778,20210115;873,20210115;911,20210115;955,20210115;311,20210116;373,20210116;432,20210116;473,20210116;575,20210116;712,20210116;750,20210116;779,20210116;874,20210116;912,20210116;970,20210116;312,20210117;433,20210117;474,20210117;538,20210117;576,20210117;713,20210117;751,20210117;790,20210117;875,20210117;913,20210117;971,20210117;313,20210118;375,20210118;434,20210118;475,20210118;539,20210118;714,20210118;752,20210118;876,20210118;914,20210118;972,20210118;314,20210119;376,20210119;435,20210119;476,20210119;543,20210119;578,20210119;715,20210119;753,20210119;792,20210119;877,20210119;915,20210119;973,20210119;377,20210120;436,20210120;477,20210120;546,20210120;579,20210120;716,20210120;754,20210120;793,20210120;878,20210120;916,20210120;974,20210120;316,20210121;378,20210121;437,20210121;478,20210121;531,20210121;537,20210121;550,20210121;580,20210121;717,20210121;794,20210121;879,20210121;917,20210121;975,20210121;317,20210122;379,20210122;438,20210122;479,20210122;551,20210122;591,20210122;718,20210122;756,20210122;795,20210122;883,20210122;919,20210122;976,20210122;391,20210123;439,20210123;482,20210123;552,20210123;593,20210123;719,20210123;757,20210123;796,20210123;886,20210123;930,20210123;977,20210123;319,20210124;392,20210124;451,20210124;483,20210124;553,20210124;597,20210124;724,20210124;758,20210124;797,20210124;887,20210124;931,20210124;979,20210124;335,20210125;393,20210125;452,20210125;512,20210125;554,20210125;598,20210125;728,20210125;759,20210125;798,20210125;893,20210125;932,20210125;990,20210125;349,20210126;394,20210126;453,20210126;513,20210126;555,20210126;599,20210126;760,20210126;799,20210126;895,20210126;933,20210126;991,20210126;350,20210127;395,20210127;454,20210127;515,20210127;631,20210127;7311,20210127;762,20210127;851,20210127;896,20210127;934,20210127;992,20210127;351,20210128;396,20210128;455,20210128;557,20210128;632,20210128;7312,20210128;766,20210128;852,20210128;935,20210128;993,20210128;352,20210129;398,20210129;456,20210129;517,20210129;558,20210129;633,20210129;7313,20210129;768,20210129;853,20210129;898,20210129;936,20210129;994,20210129;353,20210130;412,20210130;457,20210130;559,20210130;734,20210130;769,20210130;854,20210130;8981,20210130;937,20210130;995,20210130;354,20210131;414,20210131;458,20210131;523,20210131;561,20210131;577,20210131;635,20210131;735,20210131;770,20210131;855,20210131;938,20210131;996,20210131;310,20210202;315,20210202;356,20210202;374,20210202;416,20210202;663,20210202;710,20210202;791,20210202;755,20210203;318,20210204;516,20210204;518,20210204;556,20210204;730,20210204"""
        //val plans = s"""851,${Util.getTodayDayid()}"""
        //val plans = s"""532,20210223;311,20210223;576,20210223;513,20210224;516,20210224;551,20210224;591,20210225;760,20210225;771,20210225;536,20210226;431,20210226;539,20210226;515,20210227;558,20210227;377,20210227;052,20210227;315,20210228;376,20210228;663,20210228;310,20210228"""
        //val plans = s"""752,20210308;871,20210308;7311,20210308;579,20210308;531,20210308;898,20210308;573,20210309;451,20210309;991,20210309;317,20210309;351,20210309;575,20210309;758,20210309;537,20210309;535,20210309;759,20210309;750,20210310;797,20210310;775,20210310;931,20210310;710,20210310;396,20210310;379,20210310;756,20210310;730,20210310;530,20210310;716,20210310;319,20210310;471,20210310;373,20210311;792,202103011;913,202103011;572,202103011;370,202103011;668,202103011;534,202103011;793,202103011;518,202103011;912,202103011;739,202103011;533,202103011;517,202103011;857,202103011;855,202103011;772,202103012;854,202103012;7313,202103012;713,202103012;712,202103012;391,202103012;374,202103012;313,202103012;736,202103012;753,202103012;768,202103012;734,202103012;856,202103012;660,202103012;728,202103012;472,202103012;635,202103013;314,202103013;476,202103013;746,202103013;412,202103013;527,202103013;719,202103013;556,202103013;593,202103013;751,202103013;372,202103013;745,202103013;359,202103013;550,202103013;717,202103013;773,202103013;375,202103013;762,202103013;994,202103013;774,202103014;543,202103014;538,202103014;735,202103014;858,202103014;795,202103014;354,202103014;352,202103014;715,202103014;718,202103014;378,202103014;917,202103014;916,202103014;355,202103014;631,202103014;766,202103014;318,202103014;432,202103014;357,202103014;477,202103014;599,202103014;553,202103015;417,202103015;951,202103015;564,202103015;597,202103015;738,202103015;662,202103015;470,202103015;873,202103015;358,202103015;874,202103015;796,202103015;475,202103015;632,202103015;737,202103015;557,202103015;053,202103015;859,202103015;794,202103015;872,202103015;7312,202103015;757,202103016;578,202103016;911,202103016;714,202103016;454,202103016;455,202103016;393,202103016;724,202103016;563,202103016;743,202103016;937,202103016;452,202103016;335,202103016;915,202103016;429,202103016;438,202103016;416,202103016;421,202103016;996,202103016;459,202103016;434,202103016;870,202103016;893,202103016;896,202103016;970,202103016;974,202103016;895,202103016;976,202103016;973,202103016;975,202103016;546,202103017;479,202103017;633,202103017;971,202103017;554,202103017;474,202103017;935,202103017;570,202103017;435,202103017;395,202103017;433,202103017;552,202103017;555,202103017;598,202103017;776,202103017;997,202103017;356,202103017;877,202103017;478,202103017;876,202103017;938,202103017;778,202103017;744,202103017;427,202103017;701,202103017;473,202103017;469,202103017;903,202103017;919,202103017;909,202103017;979,202103017;790,202103017;955,202103017;954,202103017;952,202103017;972,202103017;457,202103017;992,202103017;483,202103017;941,202103017;995,202103017;464,202103017;908,202103017;887,202103017;977,202103017;086,202103017;418,202103018;777,202103018;999,202103018;436,202103018;875,202103018;798,202103018;398,202103018;414,202103018;934,202103018;580,202103018;932,202103018;914,202103018;998,202103018;878,202103018;415,202103018;692,202103018;349,202103018;691,202103018;482,202103018;933,202103018;779,202103018;439,202103018;906,202103018;879,202103018;993,202103018;799,202103018;559,202103018;456,202103018;902,202103018;901,202103018;943,202103018;939,202103018;566,202103018;088,202103018;467,202103018;953,202103018;353,202103018;883,202103018;561,202103018;936,202103018;468,202103018;930,202103018;437,202103018;990,202103018;392,202103018;770,202103018;458,202103018;769,202103019;571,202103019;022,202103019;021,202103021;350,202103021;020,202103022;634,202103022;897,202103022;010,202103023;8982,202103023;8983,202103023;755,202103024"""
        //val plans = s"""772,20210315;854,20210315;7313,20210315;713,20210315;712,20210315;391,20210315;374,20210315;313,20210315;736,20210315;753,20210315;768,20210315;734,20210315;856,20210315;660,20210315;728,20210315;472,20210315;635,20210315;314,20210315;476,20210315;746,20210315;412,20210315;527,20210315;719,20210315;556,20210315;593,20210315;751,20210315;372,20210315;745,20210315;359,20210315;550,20210315;717,20210315;773,20210315;375,20210315;762,20210315;994,20210315;774,20210316;543,20210316;538,20210316;735,20210316;858,20210316;795,20210316;354,20210316;352,20210316;715,20210316;718,20210316;378,20210316;917,20210316;916,20210316;355,20210316;631,20210316;766,20210316;318,20210316;432,20210316;357,20210316;477,20210316;599,20210316;010,20210316;8982,20210316;8983,20210316"""
        val plans = s"""755,20210330;020,20210331;010,20210332;023,20210402;757,20210403;028,20210404;852,20210405;029,20210406;021,20210408;027,20210409;769,20210410;512,20210411;577,20210412;024,20210411;371,20210410;851,20210409;574,20210408;752,20210407;898,20210406;595,20210405;312,20210403;025,20210402;513,20210407;576,20210407;7311,20210412;8981,20210404;311,20210407;991,20210332;537,20210403;575,20210404;730,20210405;535,20210407;931,20210408;514,20210409;750,20210409;793,20210410;792,20210411;370,20210411;530,20210412;668,20210412;857,20210412;913,20210406;010,20210413"""
        //val citys = plans.split(";").map(_.split(",")).filter(d=>d(1)==dayid).map(d=>d(0)).mkString(",")

        val cityplan =
            s"""
               |2:027,022,512
               |3:028,029,769
               |4:023,757,571
               |5:010
               |6:021
               |7:020
               |8:755
               |9:576,532,531,431,8981
               |10:591,516,551,771,311,754
               |11:760,377,579,052,539,558
               |12:536,663,515,376,315,791,451
               |13:519,573,394,310,411,775,797,758,759
               |14:316,396,592,317,351,379,991,523,575,537
               |15:710,730,716,750,931,793,530,792,514,370,763
               |16:535,739,857,373,756,319,668,913,855,912,854,768
               |17:534,471,391,596,856,713,736,712,772,572,533,660,728
               |18:753,7313,518,374,746,517,511,635,734,593,556,476,313,372
               |19:816,314,762,773,745,719,774,412,735,472,795,858,717,718,550,375
               |20:817,594,527,359,751,831,543,378,352,916,538,355,715,796,432,859,917
               |21:354,053,553,738,766,477,599,564,357,874,737,597,470,994,475,662,318,557,951
               |22:873,794,358,818,393,417,632,870,7312,631,872,714,911,454,743,724,455,563,915,452,830,937
               |23:459,578,438,350,722,479,546,935,633,776,832,421,778,429,335,554,474,395,838,555,833,826,433,938,777,552,934,598,416
               |24:453,798,435,744,570,971,876,813,996,478,825,839,398,418,834,877,932,997,356,827,436,999,914,434,875,878,998,415,933,427,419,691,482,580,939
               |25:779,799,692,349,943,879,414,883,456,566
               |26:559,439,467,562,993,906,953,936,353,561,930,088,902,901,891,468,701,392,458,711,770,835,812,437,469,919,972,473,903,954,955,790,909,952,979,457,990,894,941,992,483,837,464,836,995,977,086,887,908,893,896,970,974,892,895,976,973,975
               |27:595,871,7311,513,312
               |28:574,752,898,025,510
               |29:577,371,024,851
               |""".stripMargin

        val citys = cityplan.split("\n").filter(_.startsWith(day+":"))(0).split(":")(1).replaceAll("\r","").replaceAll("\n","")
        //val citys = "023,995,977,086,887,908,893,896,970,974,892,895,976,973,975"
        //val citys = "576,532,531,431,8981"

        val dayid = ScalaUtils.getTodayDayid()
        System.err.println(s"$dayid 待处理城市：$citys")

        //val citys = args(0)
        citys.split(",").foreach(cityCode => {
            if(cityCode!=""){
                init(dayid, cityCode)//
                //syncData(dayid,cityCode)
              ScalaUtils.freeMem()
            }
        })
    }


    def init(dayid: String, cityCode: String) = {
        val hdfsPath = s"/user/hive/warehouse/dm_gis.db/chkn_etl_v2/$dayid/$cityCode"
      ScalaUtils.hdfsRM(hdfsPath)
      ScalaUtils.runShellCmd(s"hdfs dfs -mkdir -p $hdfsPath")
      ScalaUtils.runShellCmd(s"hdfs dfs -rm -r -f $hdfsPath/*")

        var sql =
            s"""
               |select groupid,max(inc_day) as inc_day from dm_gis.gis_error_call_check_standard_library t where city_code='$cityCode' and type_flag='GIS错误' group by groupid
               |""".stripMargin
        val dic_gid = ScalaUtils.spark.sql(sql).rdd.map(d => (d.getString(0), 1)).collectAsMap()
        val b_dic_gid = ScalaUtils.spark.sparkContext.broadcast(dic_gid)

        //构造 CMS地址变更城市名到数据库表映射
        val token = "五环到六环之间,地铁20号口,内环到三环里,内环到二环里,地铁19号口,地铁18号口,地铁13号口,地铁12号口,地铁17号口,地铁11号口,地铁16号口,地铁15号口,内环到四环里,地铁10号口,地铁21号口,地铁14号口,二环到三环,地铁5号口,地铁6号口,的十字路口,地铁4号口,地铁9号口,地铁8号口,地铁7号口,往西走到底,地铁1号口,往南走到底,五环到六环,内环到四环,往东走到底,一环到二环,内环到三环,往城头方向,往北走顺路,地铁3号口,四环到五环,地铁2号口,的交叉路口,内环到二环,三环到四环,自西向东,西四门市,东南方向,西三门市,东南门市,马路对面,西南门市,东一门市,西南方向,二环以内,西二门市,二环以外,交叉路口,下电梯口,西北门市,南二门市,进去即是,西北方向,六环以内,进入网站,右转到底,六环以外,五环以外,五环以内,楼下门市,向东直行,三叉路口,向北直行,马路对门,的入口处,往西到底,下楼梯口,的十字路,往南到底,下扶梯口,北二门市,北四门市,北三门市,往东到底,自南向北,自东向西,自北向南,西转盘处,往北到底,东北门市,北转盘处,的出口处,的交叉口,转弯角处,四环以外,四环以内,小转盘路,小转盘处,向南直行,东门路口,东北方向,三岔路口,十字路口,的交汇处,的交界处,三环以外,向西直行,三环以内,西北角,西北侧,那条路,五环外,靠左手,靠右手,左手边,靠西面,靠西边,靠南面,左侧街,靠南边,靠东面,最外面,最里面,靠东边,靠北边,转弯角,进站口,交口处,转盘旁,转盘路,转盘街,转角处,交界口,交界处,中间的,交接的,交接处,交会处,正西面,正西方,正西侧,正南面,正南方,正南侧,交汇处,正畸科,正对着,正对面,正对门,正对过,正对个,交差口,正东面,正东方,正东侧,正大门,正北面,正北方,正北侧,这条路,交叉口,站牌旁,站牌处,交叉处,过马路,拐弯处,附属楼,负一层,二环外,右手边,东院区,东一门,东入口,右侧街,东南门,东南角,东南侧,东大院,东大门,东侧厅,东北隅,东北门,东北角,东北侧,地下室,北三门,北入口,延长线,延伸线,延伸段,新转盘,斜对面,斜对过,北二门,五车间,往里走,停靠站,四环外,四车间,北大门,的入口,的路口,的交口,的交汇,的出口,单行道,大门外,大门前,大门口,出站口,出入口,出口处,便道上,三环外,入门处,入口处,西转盘,西院区,米左右,六环外,靠北面,南三门,西南隅,西南首,南入口,西南角,西南侧,南二门,南大院,南大门,那条巷,以北,街口,边头,边上,背面,背后,北走,外围,接近,往北,脚下,北头,北厅,北梯,北塔,往里,那排,往南,往西,往右,往左,西边,西侧,西端,左数,左首,左手,左面,左段,左侧,左边,对门,西行,西户,转入,转角,左转,中间,直入,之间,正门,正对,这里,西邻,西临,院内,右转,右数,右首,右手,右面,右段,右侧,右边,西门,西面,西墙,以西,以外,以内,以南,以东,西首,一侧,沿线,斜对,西数,巷内,巷口,向左,向右,向下,向西,向上,向南,向里,向东,向北,相邻,下面,下滑,下行,下段,西厅,西头,交口,西塔,南口,交界,米处,门外,门前,交会,南数,交汇,南走,前边,路西,路尾,交叉,后走,后有,后厅,后面,后门,后楼,后栋,后边,河边,过去,过桥,路南,过了,过道,路东,拐弯,拐角,隔壁,前行,路边,附近,路北,前楼,前面,内侧,西梯,对面,街边,对过,能到,东数,东头,东厅,上面,前往,旁边,两侧,前约,东面,前走,东门,东临,东邻,东口,东户,东行,里边,南行,南首,东侧,东边,南墙,桥北,南端,靠西,桥东,南面,掉头,店内,南门,桥南,北数,北首,桥西,靠南,靠近,北墙,北面,北门,北临,北邻,北口,北户,北行,南侧,北端,南边,靠东,北侧,北边,挨着,入口,西口,南临,靠北,上行,顺着,外侧,外面,南邻,到底,往东,进入,其他,村北,进去,紧邻,出去,街上,出口,朝北,侧面,侧门,侧边,靠,旁,侧".split(",")
        val citydef =
            s"""010=1
               |020=2
               |021=3
               |755=4
               |022,023,024,025,027,028,029,052,053,086,088,310,311,312,313,314,315,316,317,318=5
               |319,335,349,350,351,352,353,354,355,356,357,358,359,370,371,372,373,374,375,376=6
               |377,378,379,391,392,393,394,395,396,398,411,412,414,415,416,417,418,419,421,427=7
               |429,431,432,433,434,435,436,437,438,439,451,452,453,454,455,456,457,458,459,464=8
               |467,468,469,470,471,472,473,474,475,476,477,478,479,482,483,510,511,512,513,514=9
               |515,516,517,518,519,523,527,530,531,532,533,534,535,536,537,538,539,543,546,550=10
               |551,552,553,554,555,556,557,558,559,561,562,563,564,566,570,571,572,573,574,575=11
               |576,577,578,579,580,591,592,593,594,595,596,597,598,599,631,632,633,634,635,660=12
               |662,663,668,691,692,701,710,711,712,713,714,715,716,717,718,719,722,724,728,730=13
               |7311,7312,7313,734,735,736,737,738,739,743,744,745,746,750,751,752,753,754,756,757=14
               |758,759,760,762,763,766,768,769,770,771,772,773,774,775,776,777,778,779,790,791=15
               |792,793,794,795,796,797,798,799,812,813,816,817,818,825,826,827,830,831,832,833=16
               |834,835,836,837,838,839,851,852,853,854,855,856,857,858,859,870,871,872,873,874=17
               |875,876,877,878,879,883,886,887,891,892,893,894,895,896,897,898,8981,8982,8983,901=18
               |902,903,906,908,909,911,912,913,914,915,916,917,919,930,931,932,933,934,935,936=19
               |937,938,939,941,943,951,952,953,954,955,970,971,972,973,974,975,976,977,979,990,991,992,993,994,995,996,997,998,999=20""".stripMargin
                    .split("\n").filter(_.length > 0).map(d => {

                val t = d.split("=")
                if (t.size > 1) {
                    val v = t(1)
                    t(0).split(",").map(cityCode => {
                        (cityCode, v)
                    })
                } else {
                    println("parse error:" + d)
                    null
                }
            }).filter(_ != null).flatMap(d => d).toMap
        println("----------------------------------------------------------------------------------------------")

        val cityPartition = citydef.getOrElse(cityCode, "0")
        val db = new Database(driver, url, uid, pwd)

        val debugZcCnd ="" // "and (zno_code='021FD')" // and zno_code ='512QC'" //todo remove this //  " and zno_code ='512QC'" //
        sql = s"""select zno_code,count(1) from wchka.cms_address_$cityPartition where city_code='$cityCode' and `type`=2 and delivery_type in (0,2) and del_flag=0 and zno_code like '$cityCode%' $debugZcCnd group by zno_code"""

        val zcList = db.getValue(sql).toArray().map(d => {
            val row = d.asInstanceOf[java.util.Vector[String]]
            val zc = row.elementAt(0).toString
            val cnt = row.elementAt(1).toString.toInt
            (zc, cnt)
        }).filter(_._1.startsWith(cityCode)).sortBy(_._1)

        val total = zcList.map(_._2).sum
        System.err.println("城市：" + cityCode + "，待处理记录数：" + total)

        zcList.foreach(d => println(d.productIterator.mkString("=")))

        db.closeConnection()

        val taskCnt = zcList.size
        val batchSize = 4
        val batchCount = if (taskCnt % batchSize > 0) taskCnt / batchSize + 1 else taskCnt / batchSize
        System.err.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        System.err.println("城市：" + cityCode + "，网点数：" + taskCnt + ",批量：" + batchSize + "，迭代数：" + batchCount)
        ScalaUtils.memTime()

        val threadCnt = 5

        val executorService = Executors.newFixedThreadPool(threadCnt)
        val list = new java.util.ArrayList[Callable[Void]]()

        (0 to batchCount - 1).foreach(i => {
            val jobIdx = i + 0

            if (threadCnt == 1) {
                process(jobIdx, zcList, cityCode, batchCount, hdfsPath, batchSize, taskCnt, cityPartition, dayid, token, b_dic_gid)
            } else {
                list.add(new Callable[Void] {
                    val jid = jobIdx
                    val zl = zcList
                    val cc = cityCode
                    val bc = batchCount
                    val hp = hdfsPath
                    val bs = batchSize
                    val tc = taskCnt
                    val cp = cityPartition
                    val dy = dayid
                    val tk = token
                    val dg = b_dic_gid
                    override def call(): Void = {
                        process(jid, zl, cc, bc, hp, bs, tc, cp, dy, tk, dg)
                        null
                    }
                })
            }
        })

        if (threadCnt > 1) {
            executorService.invokeAll(list)
            executorService.shutdown()
            list.clear()
        }

      ScalaUtils.addPartition("dm_gis","chkn_etl_v2",s"inc_day='$dayid',city_code='$cityCode'",hdfsPath)

      ScalaUtils.showCost("城市：" + cityCode + "，网点数：" + taskCnt + ",批量：" + batchSize + "，迭代数：" + batchCount + "，处理完毕")

//        Util.sql2ftp(sql=s"SELECT * from dm_gis.chkn_etl_v2 where inc_day=$dayid and city_code=$cityCode",
//                header="address,cityCode,deliverytype,zno_code,dept,znocode,depart_code,aoiid,aoi_id,group_id,group_group,standardization,keyword,hasloc,hastxt,isbehind,tag,tag1,tag2,splitinfo,action,result,one_group,norm_rsp,hp_rsp,inc_day,city_code".split(",").mkString("\t"),
//                fileName = s"chkn_etl_v2_${dayid}_$cityCode.csv",
//                ftpPath = "/GIS-ASS-AOS/01366807",
//                delimiter = "\t",
//                tgz = true,
//                unpersist = true)


        val processed = ScalaUtils.spark.sql(s"select * from dm_gis.chkn_etl_v2 where inc_day='$dayid' and city_code='$cityCode'").persist(StorageLevel.MEMORY_AND_DISK_SER)
        val p1 = zcList.map(_._2).sum.toLong
        val t1 = "审补库总量"
        val r1 = ""

        val p2 = processed.where("depart_code<>'' and depart_code is not null").count()
        val t2 = "匹上标准库数据"
        val r2 = rate(p2,p1)

        val p3 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null").count()
        val t3 = "审补网点和标准网点相等数据"
        val r3 = rate(p3,p1)

        val p4 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and aoiid<>'' and aoiid is not null and aoiid=aoi_id").count()
        val t4 = "审补网点和标准网点相等&审补有AOI&审补AOI=标准AOI"
        val r4 = rate(p4,p1)

        val p5 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and (aoi_id='' or aoi_id is null)").count()
        val t5 = "审补网点和标准网点相等&审补无AOI&标准无AOI"
        val r5 = rate(p5,p1)

        val p6 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and aoi_id<>'' and aoi_id is not null and one_group='true'").count()
        val t6 = "审补网点和标准网点相等&审补无AOI&标准有AOI&大组唯一"
        val r6 = rate(p6,p1)

        val p7 = processed.where("znocode=depart_code and znocode<>'' and znocode is not null and (aoiid='' or aoiid is null) and aoi_id<>'' and aoi_id is not null and one_group='false'").count()
        val t7 = "审补网点和标准网点相等&审补无AOI&标准有AOI&大组不唯一"
        val r7 = rate(p7,p1)

        val p8 = processed.where("tag=0 and tag1=0").count()
        val t8 = "拟下线数据中被normhp匹上"
        val r8 = rate(p8,p1)

        val p9 = processed.where("tag=0 and tag1=1").count()
        val t9 = "拟下线数据中未被normhp匹上"
        val r9 = rate(p9,p1)

        val p10 = processed.where("tag=0").count()
        val t10 = "拟下线数据"
        val r10 = rate(p10,p1)

        val p11a = processed.where("tag=0 and flag='0'").count()
        val t11a = "拟下线数据_AOI单元ID校验后"
        val r11a = rate(p11a,p1)

        val p11 = processed.where("tag=0 and flag='0' and tag2=0 and action=0").count()
        val t11 = "审补最终下线结果数"
        val r11 = rate(p11,p1)

        val p12 = processed.where("tag=0 and flag='0' and tag2=0 and action=1").count()
        val t12 = "redis不符"
        val r12 = rate(p12,p1)

        val p13 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='false'").count()
        val t13 = "审补下线结果中无方位词"
        val r13 = rate(p13,p1)

        val p14 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='false'").count()
        val t14 = "审补下线结果中有方位词且无文本"
        val r14 = rate(p14,p1)

        val p15 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true'").count()
        val t15 = "审补下线结果中有方位词且有文本"
        val r15 = rate(p15,p1)

        val p16 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true' and isbehind='true'").count()
        val t16 = "审补下线结果中有方位词且有文本且文本在方位词之后"
        val r16 = rate(p16,p1)

        val p17 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and hasloc='true' and hastxt='true' and isbehind='false'").count()
        val t17 = "审补下线结果中有方位词且有文本且文本不在方位词之后"
        val r17 = rate(p17,p1)

        val p18 = processed.where("tag=0 and flag='0' and tag2=0 and action=0 and result=0").count()
        val t18 = "审补下线成功"
        val r18 = rate(p18,p1)

        val result = List(
            (1,t1,p1,r1),
            (2,t2,p2,r2),
            (3,t3,p3,r3),
            (4,t4,p4,r4),
            (5,t5,p5,r5),
            (6,t6,p6,r6),
            (7,t7,p7,r7),
            (8,t8,p8,r8),
            (9,t9,p9,r9),
            (10,t10,p10,r10),
            (11,t11a,p11a,r11a),
            (12,t11,p11,r11),
            (13,t12,p12,r12),
            (14,t13,p13,r13),
            (15,t14,p14,r14),
            (16,t15,p15,r15),
            (17,t16,p16,r16),
            (18,t17,p17,r17),
            (19,t18,p18,r18)
        )
        val spark = ScalaUtils.spark
        import spark.implicits._
      ScalaUtils.spark.sparkContext
                .makeRDD(result)
                .toDF("序号","标题","数量","占比")
                .sort("序号")
                .show(false)

//        1	审补库总量	总数
//        2	匹上标准库数据	depart_code不为空
//        3	审补网点和标准网点相等数据	znocode=depart_code
//        4	审补网点和标准网点相等&审补有AOI&审补AOI=标准AOI	znocode=depart_code & aoiid不为空 & aoiid=aoi_id
//        5	审补网点和标准网点相等&审补无AOI&标准无AOI	znocode=depart_code & aoiid为空 & aoi_id为空
//        6	审补网点和标准网点相等&审补无AOI&标准有AOI&大组唯一	znocode=depart_code & aoiid为空 & aoi_id不为空 & one_group=true
//        7	审补网点和标准网点相等&审补无AOI&标准有AOI&大组不唯一	znocode=depart_code & aoiid为空 & aoi_id不为空 & one_group=false
//        8	拟下线数据中被normhp匹上	tag=0 & tag1=0
//        9	拟下线数据中未被normhp匹上	tag=0 & tag1=1
//        10	拟下线数据	tag=0
//        11	审补最终下线结果数	tag=0 & tag2=0 & action=0
//        12	redis不符	tag=0 & tag2=0 & action=1
//        13	审补下线结果中无方位词	tag=0 & tag2=0 & action=0 & hasloc=false
//        14	审补下线结果中有方位词且无文本	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=false
//        15	审补下线结果中有方位词且有文本	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true
//        16	审补下线结果中有方位词且有文本且文本在方位词之后	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true & isbehind=true
//        17	审补下线结果中有方位词且有文本且文本不在方位词之后	tag=0 & tag2=0 & action=0 & hasloc=true & hastxt=true & isbehind=false
//        18	审补下线成功	tag=0 & tag2=0 & action=0 & result=0




    }

    def rate(a:Long,b:Long) ={
        (Math.round(a.toDouble/b.toDouble * 10000)/100.0).toString+"%"
    }

    def getZnocode(cityCode:String,zno_code: String) = {
//        """http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySzDepart?cityCode=516&znoCode=516DE&typeCode=DB05-DB"""
//        """
//          |{
//          |  "code": 200,
//          |  "data": [
//          |    {
//          |      "cityCode": "516",
//          |      "znoCode": "516DE",
//          |      "departCode": "516DE",
//          |      "typeCode": "DB05-DB",
//          |      "isFixed": "0"
//          |    }
//          |  ],
//          |  "subCode": "",
//          |  "success": true,
//          |  "message": ""
//          |}
//          |""".stripMargin
//        val url = s"""http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySzDepart?cityCode=$cityCode&znoCode=$zno_code&typeCode=DB05-DB"""
//        var rsp = ""
//        try{
//            rsp = Util.tryGet(url,3)
//            val json = JSON.parseObject(rsp)
//            if(json.getIntValue("code")==200 && json.getBooleanValue("success")==true){
//                val data = json.getJSONArray("data")
//                if(data.size()>0){
//                    val dc = data.getJSONObject(0).getString("departCode")
//                    if(dc!=null && dc!="")
//                        dc
//                    else
//                        zno_code
//                }else{
//                    zno_code
//                }
//            }else{
//                zno_code
//            }
//
//        }catch {
//            case e:Exception=>{
//                System.err.println("【REQ】"+url)
//                System.err.println("【RST】"+rsp)
////                Util.printException(e)
//                zno_code
//            }
//        }
        getSSSZnoCode(cityCode,zno_code)
    }

    def getSSSZnoCode(cityCode: String, zno_code: String) = {
        val url = s"""http://gis-cms-bg.sf-express.com/cms/api/zno/getZnoBySssZnoDepart?cityCode=$cityCode&znoCode=$zno_code""" //&typeCode=FB04-GX
        var rsp = ""
        try{
            rsp = ScalaUtils.tryGet(url,5)
            val json = JSON.parseObject(rsp)
            if(json.getIntValue("code")==200 && json.getBooleanValue("success")==true){
                val data = json.getJSONArray("data")
                if(data.size()>0){
                    val dc = data.getJSONObject(0).getString("departCode")
                    if(dc!=null && dc!="")
                        dc
                    else
                        zno_code
                }else{
                    zno_code
                }
            }else{
                zno_code
            }

        }catch {
            case e:Exception=>{
                System.err.println("【REQ】"+url)
                System.err.println("【RST】"+rsp)
                //                Util.printException(e)
                zno_code
            }
        }
    }

    def process(jobIdx: Int, zcList: Array[(String, Int)], cityCode: String, batchCount: Int, hdfsPath: String, batchSize: Int, taskCnt: Int, cityPartition: String, dayid: String, token: Array[String], b_dic_gid: Broadcast[collection.Map[String, Int]]) = {
        val i = jobIdx
        val start = i * batchSize
        val end = Math.min((i+1)*batchSize,taskCnt)
        val zcs = zcList.slice(start,end).map(_._1)
        val zcin = zcs.mkString("'","','","'")

      ScalaUtils.showCost("城市："+cityCode+"，批次：["+(i+1)+" / "+batchCount+"]，记录：["+(start+1)+" / "+end+"]，网点：["+zcs.mkString(",")+"] 处理开始")

        val id = i + "_" + new Date().getTime()

        val log = ScalaUtils.runShellCmd(s"hdfs dfs -ls $hdfsPath/$id.csv")

        """
          |sch_code 删掉；zno_code 映射为 （cms 接口待定取名 znocode）
          |""".stripMargin
        // TODO: hide this 
        val debugZcCnd = "" //"and zno_code='021FD'"
        val debugAddressCnd = "" // and address='江苏省苏州市昆山市开发区庆丰路路富花园西村18栋车库'"
        val src = ScalaUtils.spark.read.format("jdbc")
                .option("driver", driver)
                .option("url", url)
                .option("dbtable", s"wchka.cms_address_$cityPartition")
                .option("user", uid)
                .option("password", pwd)
                .load()
                .where(s"city_code='$cityCode' and zno_code in($zcin) and `type`=2 and delivery_type in (0,2) and del_flag=0 $debugZcCnd $debugAddressCnd")
                .select("address", "zno_code", "aoi_id", "delivery_type", "keyword","extend_attach8")
                .repartition(ScalaUtils.defaultPartitionSize * 4).persist(StorageLevel.MEMORY_AND_DISK_SER)
                //.createOrReplaceTempView(s"addr_${dayid}_$jobIdx")
      ScalaUtils.memTime()
      ScalaUtils.showCost(s"【$cityCode - ${zcs.mkString(",")}】记录数${src.count}")

        src.show(20,false)

//        val znocodeMap = Util.spark.sql(s"select distinct zno_code from addr_${dayid}_$jobIdx").rdd.map(d=>{
//            val zno_code = d.getString(0)
//            val znocode = getZnocode(cityCode,zno_code)
//            (zno_code,znocode)
//        }).collectAsMap()
        val znocodeMap = src.select("zno_code").distinct().rdd.map(d=>{
            val zno_code = d.getString(0)
            val znocode = getZnocode(cityCode,zno_code)
            (zno_code,znocode)
        }).collectAsMap()
        znocodeMap.foreach(d=>println(d.productIterator.mkString("=>")))
        val b_znocodeMap = ScalaUtils.spark.sparkContext.broadcast(znocodeMap)
      ScalaUtils.showCost(s"【$cityCode - ${zcs.mkString(",")}】审补网点编码映射完毕")

        //val sql = s"""select * from addr_${dayid}_$jobIdx"""
        //val addrRdd = Util.spark.sql(sql).repartition(Util.defaultPartitionSize * 4).persist(StorageLevel.MEMORY_AND_DISK_SER)
        //println(sql)


        //跑派件容灾
        val speedLimit = 10000 / ScalaUtils.sc.getConf.get("spark.executor.instances", "20").toInt
        val b_speedLimit = ScalaUtils.spark.sparkContext.broadcast(speedLimit)
        val detail = src.rdd.mapPartitions(p=>{
            //限制了每分钟访问量:6000, 每秒访问量100,【100cpu】每cpu每秒访问量1

            Counter.speedLimit = b_speedLimit.value
            def sleep(t0:Long): Unit ={
                Counter.count(t0)
                //        val cpuCores = 100
                //        val akSpeedPerMin = 100000 //6000
                //        val akSpeedPerSecPerCpu = akSpeedPerMin.toDouble / 60.0 / cpuCores.toDouble
                //        val taskTime = (1000.0 / akSpeedPerSecPerCpu).toInt
                //
                //        val t1 = new Date().getTime
                //        val delta = taskTime - (t1 - t0)
                //        if(delta>0) {
                //            System.err.println("sleep: "+delta)
                //            Thread.sleep(delta)
                //        }
            }

            p.map(f = d => {
                val t0 = new Date().getTime
                val addr = ScalaUtils.fixnull(d.getString(0))
                val zno_code = ScalaUtils.fixnull(d.getString(1)).toUpperCase()
                val znocode = b_znocodeMap.value.getOrElse(zno_code, zno_code) // dept
                val aoi = ScalaUtils.fixnull(d.getString(2)).toUpperCase()
                val dt = d.getInt(3).toString
                val keyword = ScalaUtils.fixnull(d.getString(4))
                val extend_attach8 = ScalaUtils.fixnull(d.getString(5))
                var aoiunit_norm = ""
                var aoiunit_hp = ""
                var aoiunit_redis = ""
                var flag = ""
                var rsp = ""
                var groupid = ""
                var aoiid = ""
                var teams = "".split(",")
                var depts = "".split(",")
                var standard = ""
                var dept = ""
                var depart_code = ""
                //var team = ""


                var tag = -1
                var tag1 = -1
                var tag2 = -1
                var action = -1
                var action_result = -1

                var standardization = ""
                var splitinfo = ""
                var one_group = "false"

                //ak before:0c3cd2c65820417d970b514122f16a1c  //6000 / min
                // ak new:e6a874c441cc41eda1b443d420f6632d    //10000 /min
                // 0c3cd2c65820417d970b514122f16a1c //100000 /min
                val url = s"""http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=${URLEncoder.encode(addr, "utf8")}&city=$cityCode&ak=e6a874c441cc41eda1b443d420f6632d&opt=normdetail"""
                //{"status":0,"result":{"src":"normdetail","count":1,"tcs":[{"src":"norm","flag":2,"dept":"512FP","team":"512FP017","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","notc":"0","aoicode":"512FP000136","aoiid":"62556EAEAE531B9DE0530EF4520A0CFC"}],"other":{"normresp":{"success":true,"errorCode":0,"result":{"status":0,"count":1,"geocoder":[{"floor":"0","adcode":320506,"filter":2,"group":"E1D3C6802D5011E8B7CF6C92BF74D4C8","name":"江苏省苏州市吴中区钟南街|208号","x":120.759,"y":31.314,"standardization":"江苏省苏州市吴中区苏州新加坡国际学校钟南街208号","score":1,"level":"GL_STREETNO","mainid":"162758","poi_typecode":"0","id":"408F2F302D5011E887E86C92BF74D4C8","sflag":0,"key":"1|2"}],"source":"suzhou","splitResult":"jiangsuprovincesuzhoucitywuzhong208zhongnanstreet^218,钟南街^19,208号^211;11","splitType":0,"addrSplitInfo":[{"match":"0","prop":"2","level":18,"name":"jiangsuprovincesuzhoucitywuzhong208zhongnanstreet"},{"match":"1","prop":"1","level":9,"name":"钟南街"},{"match":"1","prop":"2","level":11,"name":"208号"}],"guid":"D9ADECA9-418A-4EF8-8FD2-69E6FC576D50"}},"cacheresp":{"success":true,"errorCode":0,"result":[{"city":"512","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","floor":0,"result":[{"tc":"512FP017","dept":"512FP","notc":"0","aoiId":"62556EAEAE531B9DE0530EF4520A0CFC","aoiCode":"512FP000136","aoiTC":[{"dept":"512FP","tc":"512FP017"}]}],"query":{"adcode":320506,"floor":0,"filter":2,"city":"512"}}]},"normfilters":[{"src":"norm","flag":2,"dept":"512FP","team":"512FP017","groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8","aoicode":"512FP000136","aoiid":"62556EAEAE531B9DE0530EF4520A0CFC"}],"arg":{"createTime":1568877410168,"ak":"0c3cd2c65820417d970b514122f16a1c","remoteIp":"10.116.101.181","url":"http://nginx_wa/atdispatch/api?address=%22Jiangsu+ProvinceSuzhou+CityWuZhong208+Zhong+Nan+Street++%E9%92%9F%E5%8D%97%E8%A1%97208%22&city=512&ak=0c3cd2c65820417d970b514122f16a1c&opt=normdetail","city":"512","opt":"normdetail","address":"JiangsuProvinceSuzhouCityWuZhong208ZhongNanStreet钟南街208","adcode":"320500","originalAddress":"\"Jiangsu ProvinceSuzhou CityWuZhong208 Zhong Nan Street  钟南街208\""},"city":"512","adcode":"320500","filters":[2],"groupid":"E1D3C6802D5011E8B7CF6C92BF74D4C8"}}}

                try {
                    rsp = ScalaUtils.tryGet(url, 5)
                    if (rsp != null && rsp != "") {
                        val json = JSON.parseObject(rsp)
                        if (json.getIntValue("status") == 0) {

                            val result = json.getJSONObject("result")
                            val tcs = result.getJSONArray("tcs")
                            if (tcs.size() > 0) {
                                val tc = tcs.getJSONObject(0)
                                groupid = ScalaUtils.fixnull(tc.getString("groupid"))
                                aoiid = ScalaUtils.fixnull(tc.getString("aoiid"))
                                aoiunit_norm = ScalaUtils.fixnull(tc.getString("aoiUnit"))

                                """
                                  |team 是TC模块，删掉不用
                                  |""".stripMargin

                                //                                teams = tcs.toArray.map(tc => {
                                //                                    try {
                                //                                        tc.asInstanceOf[JSONObject].getString("team").toUpperCase()
                                //                                    } catch {
                                //                                        case e: Exception => {
                                //                                            null
                                //                                        }
                                //                                    }
                                //                                }).filter(_ != null).distinct

                                """
                                  |dept 映射上级网点 名为：depart_code
                                  |""".stripMargin

                                /////////////////////////////////// 必选
                                depts = tcs.toArray.map(tc => {
                                    try {
                                        val tcbefore = tc.asInstanceOf[JSONObject].getString("dept").toUpperCase()
                                        val tcafter = getSSSZnoCode(cityCode, tcbefore)
                                        tcafter
                                    } catch {
                                        case e: Exception => {
                                            null
                                        }
                                    }
                                }).filter(_ != null).distinct


                                /////////////////////////////////// 保留
                                try {
                                    //group_group 拼接来源
                                    standard = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").toArray()
                                            .filter(d => {
                                                d.asInstanceOf[JSONObject].getString("group") == groupid
                                            })(0).asInstanceOf[JSONObject].getString("standardization")
                                    standard = ScalaUtils.fixnull(standard)
                                } catch {
                                    case e: Exception => {
                                        //e.printStackTrace(System.err)
                                        //System.err.println("【解析standardization失败】" + rst)
                                    }
                                }

                                //team = if (teams.size > 0) Util.fixnull(teams(0)).toUpperCase() else ""
                                dept = if (depts.size > 0) ScalaUtils.fixnull(depts(0)).toUpperCase() else ""
                                depart_code = if (dept != "") getSSSZnoCode(cityCode, dept) else ""

                               // """方位词 都保留"""
                                //地址是否包含方位词
                                val locationToken = token.map(t => {
                                    if (addr.contains(t)) t else null
                                }).filter(_ != null)


                                //方位词后是否有文本
                                var hastxt = true
                                locationToken.foreach(d => {
                                    if (addr.endsWith(d))
                                        hastxt = false
                                })

                                var kxy = "".split(",").map(d => false).filter(d => d)
                                var groupCnt = 0
                                var group_group = ""
                                //获取地址切词结果，比对方位词位置
                                try {
                                    val rst = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result")
                                    val geocoder = rst.getJSONArray("geocoder").toArray().map(d => {
                                        val t = d.asInstanceOf[JSONObject]
                                        if (standardization == "")
                                            standardization = ScalaUtils.fixnull(t.getString("standardization"))
                                      ScalaUtils.fixnull(t.getString("group"))
                                    }).filter(_ != "")

                                    groupCnt = geocoder.distinct.size
                                    one_group = (groupCnt == 1).toString
                                    group_group = geocoder.distinct.mkString("$")

                                    val addrSplitInfo = rst.getJSONArray("addrSplitInfo").toArray().map(d => {
                                        val t = d.asInstanceOf[JSONObject]
                                        val name = t.getString("name")
                                        val level = t.getIntValue("level")
                                        val matchid = t.getIntValue("match")
                                        val prop = t.getIntValue("prop")
                                        (name, level, matchid, prop)
                                    })
                                    splitinfo = addrSplitInfo.sortBy(_._2).map(d => {
                                        d._1 + "^" + d._2 + "^" + d._4 + "^" + d._3
                                    }).mkString("|")

                                    val splitInfoMatched = addrSplitInfo.filter(_._3 == 1) //匹配上了matchkye

                                    //matchkey 在方位词之后？
                                    kxy = splitInfoMatched.map(d => {
                                        var behand = true
                                        val l0 = addr.lastIndexOf(d._1) + d._1.length
                                        locationToken.foreach(d => {
                                            val l1 = addr.lastIndexOf(d) + d.length
                                            if (l0 <= l1) {
                                                behand = false
                                            }
                                        })
                                        behand
                                    }).filter(d => d).distinct
                                } catch {
                                    case e: Exception => {
                                        System.err.println("group_group 信息解析失败：" + e.getMessage + "\t" + e.getCause)
                                        System.err.println(rsp)
                                    }
                                }

                                if (znocode != "" && zno_code == depart_code) {
                                    if (aoi != "") {
                                        if (aoi == aoiid) {
                                            if (locationToken.size > 0) {
                                                if (hastxt) {
                                                    if (kxy.size > 0) {
                                                        tag = 0
                                                    } else {
                                                        tag = 1
                                                    }
                                                } else {
                                                    tag = 1
                                                }
                                            } else {
                                                tag = 0
                                            }
                                        } else {
                                            tag = 1
                                        }
                                    } else if (aoiid != "") {
                                        if (groupCnt == 1) {
                                            tag = 0
                                        } else {
                                            tag = 1
                                        }
                                    } else {
                                        tag = 0
                                    }

                                } else {
                                    tag = 1
                                }

                                //                                if (zc == dept ) {
                                //                                    //容灾有aoi和tc 且 审补无tc；或 审补无tc且无aoi 且 （容灾有tc或容灾有aoi）
                                //                                    if (aoiid != "" && team != "" && (tc == "" || aoiid == "") || tc == "" && aoi == "" && (team != "" || aoiid != "")) {
                                //                                        information = 2
                                //
                                //                                        //地址不包含方位词
                                //                                        if (locationToken.size == 0 || hastxt && kxy.size == 1 && kxy(0)) {
                                //                                            if (b_dic_gid.value.getOrElse(groupid, 0) == 0) {
                                //                                                //审补有TC无AOI,且标准地址有TC&AOI
                                //                                                if (tc != "" && aoi == "" && team != "" && aoiid != "") {
                                //                                                    action = if (tc == team) 0 else 1
                                //                                                    //                              System.err.println(s"""tc != "" && aoi == "" && team != "" && aoiid != """"")
                                //                                                    //                              System.err.println("action="+action)
                                //                                                } else if (tc == "" && aoi != "" && team != "" && aoiid != "") {
                                //                                                    action = if (aoi == aoiid) 0 else 1
                                //                                                    //                              System.err.println(s"""tc == "" && aoi != "" && team != "" && aoiid != """"")
                                //                                                    //                              System.err.println("action="+action)
                                //                                                } else if (tc == "" && aoi == "" && (team != "" || aoiid != "")) {
                                //                                                    action = 0
                                //                                                    //                              System.err.println(s"""tc == "" && aoi == "" && (team != "" || aoiid != """"")
                                //                                                    //                              System.err.println("action="+action)
                                //                                                }
                                //                                            }
                                //                                        }else
                                //                                            action = 1
                                //                                        //地址包含方位词
                                //                                        //                        else {
                                //                                        //                          if (hastxt) {
                                //                                        //                            //在方位词之后
                                //                                        //                            action = if (kxy.size == 1 && kxy(0)) 0 else 1
                                //                                        ////                            System.err.println(s"""在方位词之后""")
                                //                                        ////                            System.err.println("action="+action)
                                //                                        //                          } else {
                                //                                        //                            action = 1
                                //                                        ////                            System.err.println(s"""不在方位词之后""")
                                //                                        ////                            System.err.println("action="+action)
                                //                                        //                          }
                                //                                        //
                                //                                        //                        }
                                //
                                //                                    }
                                //
                                //                                    //审补tc=容灾tc 且 审补aoi=容灾aoi
                                //                                    if(tc!="" && team!="" && aoi=="" && aoiid=="" || aoi!="" && aoiid!="" && tc=="" && team=="" || tc=="" && team=="" && aoi=="" && aoiid=="" || tc!="" && team!="" && aoi!="" && aoiid!="" ){
                                //                                        information = 1
                                //                                    }
                                //                                    if (tc == team && aoi == aoiid) {
                                //                                        //                        System.err.println(s"""tc == team && aoi == aoiid""")
                                //
                                //                                        //地址不包含方位词
                                //                                        if (locationToken.size == 0) {
                                //                                            action = 0
                                //                                            //                          System.err.println(s"""locationToken.size == 0""")
                                //                                            //                          System.err.println("action="+action)
                                //                                        } else if (hastxt) { //方位词后有文本
                                //                                            //matchkey在方位词之后
                                //                                            action = if (kxy.size == 1 && kxy(0)) 0 else 1
                                //                                            //                          System.err.println(s"""hastxt""")
                                //                                            //                          System.err.println("action="+action)
                                //                                        } else {
                                //                                            action = 1
                                //                                            //                          System.err.println(s"""not hastxt""")
                                //                                            //                          System.err.println("action="+action)
                                //                                        }
                                //                                    }
                                //
                                //                                } else {
                                //                                    //                      System.err.println("zc!=dept ["+zc+"!="+dept+"] 保留 action=1")
                                //                                    action = 1 // 0-下线; 1-保留,不处理
                                //                                    //                      System.err.println("action="+action)
                                //                                }


                                //增加aoi单元区域验证
                                if(extend_attach8==""){
                                    flag = "0"
                                }else if(extend_attach8 == aoiunit_norm){
                                    flag = "0"
                                }else{
                                    flag = "1"
                                }

                                var hprsp = ""
                                //normhp 验证
                                if (tag == 0 && flag == "0") {
                                    val url = s"""http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=${URLEncoder.encode(addr, "utf8")}&city=$cityCode&ak=0c3cd2c65820417d970b514122f16a1c&opt=hpdetail"""

                                    s"""
                                       |{
                                       |	"status": 0,
                                       |	"result": {
                                       |		"src": "hpdetail",
                                       |		"count": 1,
                                       |		"tcs": [{
                                       |			"src": "normhp",
                                       |			"flag": 1,
                                       |			"dept": "711E",
                                       |			"groupid": "DA6787E8A52711E8B3130894EF519FCA",
                                       |			"aoicode": "711E000313",
                                       |			"aoiid": "944409A5D7B9400EB04DA565985B40B2"
                                       |		}],
                                       |		"other": {
                                       |			"normresp": {
                                       |				"success": true,
                                       |				"errorCode": 0,
                                       |				"result": {
                                       |					"status": 0,
                                       |					"count": 3,
                                       |					"geocoder": [{
                                       |						"floor": "0",
                                       |						"adcode": 420704,
                                       |						"filter": 2,
                                       |						"group": "DA9A9B4CA52711E8B3130894EF519FCA",
                                       |						"name": "湖北省鄂州市鄂城区市政府",
                                       |						"x": 114.920887,
                                       |						"y": 30.398043,
                                       |						"standardization": "湖北省鄂州市鄂城区滨湖西路市政府",
                                       |						"score": 1,
                                       |						"level": "GL_POI",
                                       |						"mainid": "298496",
                                       |						"poi_typecode": "130100",
                                       |						"id": "A98935FEA52711E891F70894EF519FCA",
                                       |						"sflag": 0,
                                       |						"key": "4"
                                       |					}, {
                                       |						"floor": "0",
                                       |						"adcode": 420704,
                                       |						"filter": 2,
                                       |						"group": "58DE8EE4A5F211E8B6350894EF519FCA",
                                       |						"name": "湖北省鄂州市鄂城区市政府",
                                       |						"x": 114.891887,
                                       |						"y": 30.389043,
                                       |						"standardization": "湖北省鄂州市鄂城区凤凰街道滨湖北路特1号市政府办公大楼",
                                       |						"score": 1,
                                       |						"level": "GL_POI",
                                       |						"mainid": "344018",
                                       |						"poi_typecode": "130100",
                                       |						"id": "3DF38F1CA5F211E899D80894EF519FCA",
                                       |						"sflag": 0,
                                       |						"key": "4"
                                       |					}, {
                                       |						"floor": "0",
                                       |						"adcode": 420704,
                                       |						"filter": 2,
                                       |						"group": "DA6787E8A52711E8B3130894EF519FCA",
                                       |						"name": "湖北省鄂州市鄂城区市政府",
                                       |						"x": 114.894887,
                                       |						"y": 30.393043,
                                       |						"standardization": "湖北省鄂州市鄂城区凤凰街道滨湖北路市政府",
                                       |						"score": 1,
                                       |						"level": "GL_POI",
                                       |						"mainid": "363920",
                                       |						"poi_typecode": "130100",
                                       |						"id": "A989212CA52711E891F70894EF519FCA",
                                       |						"sflag": 0,
                                       |						"key": "4"
                                       |					}],
                                       |					"source": "ezhou",
                                       |					"splitResult": "湖北省^11,鄂州市^12,鄂城区^13,滨海阔天空总店^213,市政府^313,对面^118,湖北路^29,22号^211;13",
                                       |					"splitType": 0,
                                       |					"addrSplitInfo": [{
                                       |						"match": "1",
                                       |						"prop": "1",
                                       |						"level": 1,
                                       |						"name": "湖北省"
                                       |					}, {
                                       |						"match": "1",
                                       |						"prop": "1",
                                       |						"level": 2,
                                       |						"name": "鄂州市"
                                       |					}, {
                                       |						"match": "1",
                                       |						"prop": "1",
                                       |						"level": 3,
                                       |						"name": "鄂城区"
                                       |					}, {
                                       |						"match": "0",
                                       |						"prop": "2",
                                       |						"level": 13,
                                       |						"name": "滨海阔天空总店"
                                       |					}, {
                                       |						"match": "1",
                                       |						"prop": "3",
                                       |						"level": 13,
                                       |						"name": "市政府"
                                       |					}, {
                                       |						"match": "0",
                                       |						"prop": "1",
                                       |						"level": 18,
                                       |						"name": "对面"
                                       |					}, {
                                       |						"match": "1",
                                       |						"prop": "2",
                                       |						"level": 9,
                                       |						"name": "湖北路"
                                       |					}, {
                                       |						"match": "0",
                                       |						"prop": "2",
                                       |						"level": 11,
                                       |						"name": "22号"
                                       |					}],
                                       |					"guid": "108FAF2A-7F55-465B-A8F7-83C9917D32C0"
                                       |				}
                                       |			},
                                       |			"arg": {
                                       |				"createTime": 1606802826308,
                                       |				"ak": "0c3cd2c65820417d970b514122f16a1c",
                                       |				"remoteIp": "10.220.21.77",
                                       |				"url": "http://nginxwa/atdispatch/api?address=%E6%B9%96%E5%8C%97%E7%9C%81%E9%84%82%E5%B7%9E%E5%B8%82%E9%84%82%E5%9F%8E%E5%8C%BA%E6%BB%A8%E6%B5%B7%E9%98%94%E5%A4%A9%E7%A9%BA%E6%80%BB%E5%BA%97%E5%B8%82%E6%94%BF%E5%BA%9C%E5%AF%B9%E9%9D%A2%E6%B9%96%E5%8C%97%E8%B7%AF22%E5%8F%B7&city=711&ak=0c3cd2c65820417d970b514122f16a1c&opt=hpdetail",
                                       |				"city": "711",
                                       |				"opt": "hpdetail",
                                       |				"q": "0",
                                       |				"address": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号",
                                       |				"adcode": "420700",
                                       |				"originalAddress": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号",
                                       |				"fullAddress": "湖北省鄂州市鄂城区滨海阔天空总店市政府对面湖北路22号"
                                       |			},
                                       |			"hpcacheresp": {
                                       |				"success": true,
                                       |				"errorCode": 0,
                                       |				"result": [{
                                       |					"citycode": "711",
                                       |					"groupid": "DA9A9B4CA52711E8B3130894EF519FCA",
                                       |					"result": [{
                                       |						"hp": "市政府对面安置楼",
                                       |						"dept": "711E",
                                       |						"aoiId": "7C0E429C3B4349FB88708B1F29DD06EA",
                                       |						"aoiCode": "711E000220"
                                       |					}]
                                       |				}, {
                                       |					"citycode": "711",
                                       |					"groupid": "58DE8EE4A5F211E8B6350894EF519FCA",
                                       |					"result": null
                                       |				}, {
                                       |					"citycode": "711",
                                       |					"groupid": "DA6787E8A52711E8B3130894EF519FCA",
                                       |					"result": [{
                                       |						"hp": "市政府对面",
                                       |						"dept": "711E",
                                       |						"aoiId": "944409A5D7B9400EB04DA565985B40B2",
                                       |						"aoiCode": "711E000313"
                                       |					}]
                                       |				}]
                                       |			},
                                       |			"city": "711",
                                       |			"adcode": "420700",
                                       |			"groupid": "DA6787E8A52711E8B3130894EF519FCA"
                                       |		}
                                       |	}
                                       |}
                                       |""".stripMargin

                                    hprsp = ScalaUtils.tryGet(url, 5)
                                    val json = JSON.parseObject(rsp)
                                    val result = json.getJSONObject("result")
                                    val tcs = result.getJSONArray("tcs")
                                    var tcs_src = ""
                                    var depart_code_hp = ""
                                    var aoiid_hp = ""

                                    if (tcs.size() > 0) {
                                        val tc = tcs.getJSONObject(0)
                                        tcs_src = ScalaUtils.fixnull(tc.getString("src"))
                                        depart_code_hp = ScalaUtils.fixnull(tc.getString("dept"))
                                        depart_code_hp = getSSSZnoCode(cityCode, depart_code_hp)
                                        aoiid_hp = ScalaUtils.fixnull(tc.getString("aoiid"))
                                        aoiunit_hp = ScalaUtils.fixnull(tc.getString("aoiUnit"))
                                    }

                                    if (tcs_src == "normhp") {
                                        tag1 = 0
                                        if (aoi != "") {
                                            tag2 = if (znocode != "" && aoiid != "" && extend_attach8!="" && znocode == depart_code_hp && aoiid == aoiid_hp && extend_attach8==aoiunit_hp) 0 else 1
                                        } else {
                                            tag2 = if (znocode != "" && znocode == depart_code_hp) 0 else 1
                                        }
                                    } else {
                                        tag1 = 1
                                        tag2 = 0
                                    }
                                }

                                //redis验证，下线
                                if (tag2 == 0) {
                                    if (tag1 == 0) {
                                        //下线 进行下线并将下线结果赋给Result，action=0
                                        action = 0
                                        action_result = addressOffline(cityCode, addr, dt, aoiid)
                                    } else {
                                        val p = URLEncoder.encode(s"""{"query":[{"city":"$cityCode","groupid":"$groupid"}]}""", "utf8")
                                        var redisUrl = s"""http://gis-int.int.sfdc.com.cn:1080/atalter/team/bygroup?ak=3eb300d2e06947f7945cd02530a32fd2&p=$p"""
                                        var rsp = ""
                                        s"""
                                           |{
                                           |  "status": 0,
                                           |  "result": [
                                           |    {
                                           |      "city": "711",
                                           |      "groupid": "46672EF67A5811EAACD440EEDD0EF9F6",
                                           |      "tcresult": {
                                           |        "status": 0,
                                           |        "result": [
                                           |          {
                                           |            "dept": "711D",
                                           |            "tc": "711D010",
                                           |            "notc": "0",
                                           |            "aoiId": "0F240F4873F24049A021DE84ED407AD0",
                                           |            "aoiCode": "711D000029",
                                           |            "aoiSrc": "S100",
                                           |            "aoiTC": [
                                           |              {
                                           |                "dept": "711D",
                                           |                "tc": "711D010"
                                           |              }
                                           |            ]
                                           |          }
                                           |        ]
                                           |      }
                                           |    }
                                           |  ]
                                           |}
                                           |""".stripMargin
                                        try {
                                            rsp = ScalaUtils.tryGet(redisUrl, 5)
                                            if (rsp == null) {
                                                val pd = s"""{"query":[{"city":"$cityCode","groupid":"$groupid"}]}"""
                                                redisUrl = "http://gis-int.int.sfdc.com.cn:1080/atalter/team/bygroup?ak=3eb300d2e06947f7945cd02530a32fd2"
                                                rsp = ScalaUtils.tryPost(redisUrl, pd, 5)
                                            }
                                            val json = JSON.parseObject(rsp)
                                            val results = json.getJSONArray("result").getJSONObject(0).getJSONObject("tcresult").getJSONArray("result")
                                            val result = results.getJSONObject(0)
                                            val redisAoiid = ScalaUtils.fixnull(result.getString("aoiId"))
                                            val redisDept = b_znocodeMap.value.getOrElse(ScalaUtils.fixnull(result.getString("dept")), "")
                                            if (depart_code != "" && aoiid != "" && depart_code == redisDept && aoiid == redisAoiid) {

                                                val aoiUnitArr = results.toArray().map(d=>{
                                                    val t = d.asInstanceOf[JSONObject]
                                                    if(t.containsKey("aoiUnit"))
                                                      ScalaUtils.fixnull(t.getString("aoiUnit"))
                                                    else ""
                                                }).filter(_!="")

                                                if(aoiUnitArr.size == 0){
                                                    if(aoiunit_norm=="") {
                                                        //下线
                                                        action = 0
                                                        action_result = addressOffline(cityCode, addr, dt, aoiid)
                                                    } else{
                                                        action = 1
                                                    }
                                                }else if(aoiUnitArr.size == 1){
                                                    aoiunit_redis = aoiUnitArr(0)
                                                    if(aoiunit_redis == aoiunit_norm){
                                                        //下线
                                                        action = 0
                                                        action_result = addressOffline(cityCode, addr, dt, aoiid)
                                                    }else{
                                                        action = 1
                                                    }
                                                }else if(aoiUnitArr.contains(aoiunit_norm)){
                                                    aoiunit_redis = aoiunit_norm
                                                    //下线
                                                    action = 0
                                                    action_result = addressOffline(cityCode, addr, dt, aoiid)
                                                }else{
                                                    action = 1
                                                }
                                            } else {
                                                action = 1
                                            }

                                        } catch {
                                            case e: Exception => {
                                                System.err.println(s"【REQ】$redisUrl")
                                                System.err.println(s"【RSP】$rsp")
                                            }
                                        }
                                    }
                                }

                                val detail = Detail(address = addr, cityCode = cityCode, deliverytype = dt, zno_code = zno_code, dept = dept, znocode = znocode,
                                    depart_code = depart_code, aoiid = aoi, aoi_id = aoiid, group_id = groupid, group_group = group_group, standardization = standard,
                                    keyword = keyword, hasloc = locationToken.size > 0, hastxt = hastxt, isbehind = kxy.size > 0, tag = tag, tag1 = tag1, tag2 = tag2, splitinfo = splitinfo,
                                    action = action, result = action_result, one_group = one_group, norm_rsp = rsp, hp_rsp = hprsp,extend_attach8=extend_attach8,aoiunit_norm = aoiunit_norm,aoiunit_hp = aoiunit_hp,aoiunit_redis=aoiunit_redis,flag=flag)

                                //Detail(addr, cityCode, znocode, dt, depart_code, group_group, standardization, keyword,hasloc=locationToken.size>0,hastxt,isbehind = kxy.size>0, tag,tag1,tag2, splitinfo, action,action_result,aoi,aoiid,one_group,rsp,hprsp)

                                sleep(t0)
                                detail
                            } else {
                                sleep(t0)
                                null
                            }
                        } else {
                            System.err.println("【REQ】" + url)
                            System.err.println("【RSP】" + rsp)
                            if(rsp!=null && rsp.contains("访问限制")){
                                Counter.sleep += 1
                                Counter.overSpeed = true
                            }
                            sleep(t0)
                            null
                        }
                    } else {
                        System.err.println("【REQ】" + url)
                        System.err.println("【RSP】" + rsp)
                        sleep(t0)
                        null
                    }
                } catch {
                    case e: Exception => {
                        System.err.println("【REQ】" + url)
                        System.err.println("【RSP】" + rsp)
                        sleep(t0)
                        null
                    }
                }
            })
        }).filter(_!=null ).persist(StorageLevel.MEMORY_AND_DISK_SER)

        val cnt = detail.count()
      ScalaUtils.showCost(s"【$cityCode - ${zcs.mkString(",")}】容灾跑数结果记录数:"+cnt)

        val tag0 = detail.filter(_.tag==0).count()
      ScalaUtils.showCost(s"【$cityCode - ${zcs.mkString(",")}】tag=0 记录数:$tag0，占比：${tag0.toDouble/cnt.toDouble * 100}")

        val tag1 = detail.filter(_.tag==1).count()
      ScalaUtils.showCost(s"【$cityCode - ${zcs.mkString(",")}】tag=1 记录数:$tag1，占比：${tag1.toDouble/cnt.toDouble * 100}")

        s"rm -rf $id.csv*"!;
        s"rm -rf ./$id.csv*"!;

        val fa = new FileAppender(s"./$id.csv",true,100)
        detail.map(_.productIterator.mkString(sep)+"\n").collect().foreach(d=>fa.append(d))
        fa.close()
      ScalaUtils.runShellCmd(s"rm -rf *.crc")
      ScalaUtils.runShellCmd(s"rm -rf ./*.crc")
      ScalaUtils.runShellCmd(s"rm -rf *.CRC")
      ScalaUtils.runShellCmd(s"rm -rf ./*.CRC")
      ScalaUtils.runShellCmd(s"./rm -rf *.crc")
      ScalaUtils.runShellCmd(s"./rm -rf ./*.crc")
      ScalaUtils.runShellCmd(s"./rm -rf *.CRC")
      ScalaUtils.runShellCmd(s"./rm -rf ./*.CRC")
      ScalaUtils.runShellCmd(s"hdfs dfs -put ./$id.csv $hdfsPath")
      ScalaUtils.runShellCmd(s"./rm -rf $id.csv")

        detail.unpersist()
        src.unpersist()

    }



    def addressOffline(cityCode:String,address:String,tp:String,aoi:String) ={
        s"""
           |{"operSource":"sb_delete","operUserName":"01386736","addressDel":[{"address":"湖北省鄂州市鄂城区凤凰街道永利花园9栋","cityCode":"711","type":2}],"ak":"7577390e76cc40b6ad6542640edd9d84"}
           |{"code":200,"subCode":"","success":true,"message":""}
           |""".stripMargin

        val url = s"http://gis-cms-bg.sf-express.com/cms/api/address/batchDelRgsbAddr"
        val json = JSON.parseObject("{}")
        json.put("ak","7577390e76cc40b6ad6542640edd9d84")
        json.put("operSource","sb_delete")
        json.put("operUserName","01386736")

        val addrs = JSON.parseArray("[]")
        val ad = JSON.parseObject("{}")
        ad.put("cityCode",cityCode)
        ad.put("address",address)
        ad.put("type",tp.toInt)
        addrs.add(ad)
        json.put("addressDel",addrs)

        val postdata = json.toString()
        var rst:String = ""
        var ret = -1
        try{
            // TODO: free this
            rst = ScalaUtils.tryPost(url,postdata,10)
            ret = if(JSON.parseObject(rst).getBoolean("success")) 0 else 1//0 成功，1失败
        }catch{
            case e:Exception=>{
                System.err.println(s"【REQ】$url\t${json.toJSONString}")
                System.err.println(s"【RSP】$rst")
                ret = 1
            }
        }
        ret
    }
}

