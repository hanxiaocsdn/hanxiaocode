package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.sx.util.{SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks.{break, breakable}

/**
  * Created by 01374443 on 2021/11/24
  * 任务信息：391901
 * 任务名称 ：顺心识别率统计
  */

object ShunxinRecognition {
  @transient lazy val logger: Logger = Logger.getLogger(ShunxinRecognition.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val split_url = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=1245f89114fb4f5e896213904b4923a5"

  case class result(
                     cityCode: String
                     , city: String
                     , req_total_num: Int
                     , req_zc_num: Int
                     , req_ewb_num: Int
                     , req_notewb_num: Int
                     , req_notopen_num: Int
                     , req_md_num: Int
                     , req_keyword_num: Int
                     , req_undetail_num: Int
                     , req_his_num: Int
                     , req_aoi_num: Int
                     , req_mutil_num: Int
                     , req_mapb_num: Int
                     , req_geo_num: Int
                     , req_highgeo_num: Int
                     , req_lowgeo_num: Int
                     , req_ts_num: Int
                     , req_unknown_num: Int
                   )


  case class logDetail(
                        sn: String
                        , req_type: String
                        , url_time: String
                        , appName: String
                        , req_time: String
                        , req_src: String
                        , log_topics: String
                        , req_address: String
                        , code: String
                        , codeSource: String
                        , geo_tag: String
                        , gis_aoiid: String
                        , province: String
                        , city: String
                        , county: String
                        , town: String
                        , citycode: String
                        , acreage: String
                        , msg: String
                        , eds_inc_day: String
                        , rslt_tag: String
                        , city_map: String
                        , citycode_map: String
                        , splitRet: String
                        , ewb_tag: String
                      )


  def main(args: Array[String]): Unit = {
    logger.error("=====>version_20220428")
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd: RDD[JSONObject] = getDataDf(spark, incDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("获取签收表")
    val signDataRdd = querySignData(spark, incDay)

    logger.error("获取城市映射表")
    val shunxinCityMapBc: Broadcast[collection.Map[String, String]] = queryShunXinCityMap(spark)

    logger.error("开始打标签")
    val checkRdd = checkTagData(dataRdd, signDataRdd, shunxinCityMapBc)
    logger.error("开始统计")
    val indexRdd: RDD[result] = staIndex(checkRdd)
    logger.error("开始入库")
    //入库
    saveTable(spark, indexRdd, checkRdd, incDay)

    logger.error("开始解析")
    analysisRdd(spark, checkRdd, incDay)
    logger.error("结束所有运行")

  }


  def queryShunXinCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql = "select citycode,city from dm_gis.city_name_map group by citycode,city"
    val dataMap = spark.sql(sql).rdd.map(obj => {
      (obj.getString(0), obj.getString(1))
    }).collectAsMap()
    logger.error("顺心城市表数量:" + dataMap.size)

    logger.error(dataMap.take(10).toString())

    val shunxinCityMapBc = spark.sparkContext.broadcast(dataMap)
    shunxinCityMapBc
  }

  //获取签收表
  def querySignData(spark: SparkSession, incDay: String) = {
    val sql =
      s"""
         |select
         |last_gis_sn
         |--from ky.ods_sxne.hs_gis_feedback
         |--from ky.ods_sx_abws_waybill.wb_gis_feedback
         |from dm_gis.sx_sign_jm
         |where inc_day ='$incDay'
         |group by last_gis_sn
      """.stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sqlpartition)
      .map(o => (JSONUtil.getJsonVal(o, "last_gis_sn", ""), JSONUtil.getJsonVal(o, "last_gis_sn", ""))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("顺心签收单号总数量：" + dataRdd.count())
    dataRdd
  }

  def staIndex(checkOverRdd: RDD[JSONObject]) = {

    val indexRdd = checkOverRdd.map(obj => {
      val staCoverObj: result = staCoverData(obj)
      ((staCoverObj.cityCode, staCoverObj.city), staCoverObj)
    }).reduceByKey((obj1, obj2) => {
      val staCoverObj = mergeShunxinCover(obj1, obj2)
      staCoverObj
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("聚合后数量:" + indexRdd.count())
    indexRdd
  }


  def staCoverData(obj: JSONObject) = {
    val tag = JSONUtil.getJsonVal(obj, "tag", "")
    val ewb_tag = JSONUtil.getJsonVal(obj, "ewb_tag", "")
    val rslt_tag = JSONUtil.getJsonVal(obj, "rslt_tag", "")
    val city = JSONUtil.getJsonVal(obj, "city", "")
    val cityCode = JSONUtil.getJsonVal(obj, "citycode", "")

    //区域维度
    val req_total_num = 1
    var
    req_zc_num
    , req_ewb_num
    , req_notewb_num
    , req_notopen_num
    , req_md_num
    , req_keyword_num
    , req_undetail_num
    , req_his_num
    , req_aoi_num
    , req_mutil_num
    , req_mapb_num
    , req_geo_num
    , req_highgeo_num
    , req_lowgeo_num
    , req_ts_num
    , req_unknown_num = 0




    if (tag.equals("code_nonEmpty")) req_zc_num = 1
    ewb_tag match {
      case "Ewb" => req_ewb_num = 1
      case "NotEwb" => req_notewb_num = 1
      case _ =>
    }

    rslt_tag match {
      case "sxDeptNotOpen" => req_notopen_num = 1
      case "sxDeptNotCover" => req_md_num = 1
      case "keyword" => req_keyword_num = 1
      case "addressUndetail" => req_undetail_num = 1
      case "HIS" => req_his_num = 1
      case "AOI" => req_aoi_num = 1
      case "Mutil" => req_mutil_num = 1
      case "MAPB" => req_mapb_num = 1
      case "HighGeo" => {
        req_highgeo_num = 1
        req_geo_num = 1
      }
      case "LowGeo" => {
        req_lowgeo_num = 1
        req_geo_num = 1
      }
      case "TS" => req_ts_num = 1
      case "gisEmpty" => req_unknown_num = 1
      case _ =>
    }


    result(
      cityCode
      , city
      , req_total_num
      , req_zc_num
      , req_ewb_num
      , req_notewb_num
      , req_notopen_num
      , req_md_num
      , req_keyword_num
      , req_undetail_num
      , req_his_num
      , req_aoi_num
      , req_mutil_num
      , req_mapb_num
      , req_geo_num
      , req_highgeo_num
      , req_lowgeo_num
      , req_ts_num
      , req_unknown_num
    )

  }

  //打标签

  def checkTagData(dataRdd: RDD[JSONObject], signDataRdd: RDD[(String, String)], shunxinCityMapBc: Broadcast[collection.Map[String, String]]) = {

    val rsltRdd: RDD[JSONObject] = dataRdd.repartition(10).map(o => {
      val code = JSONUtil.getJsonVal(o, "code", "")
      val msg = JSONUtil.getJsonVal(o, "msg", "")
      val req_address = JSONUtil.getJsonVal(o, "req_address", "")
      var citycode = JSONUtil.getJsonVal(o, "citycode", "")


      if (citycode.isEmpty) {
        val mapBc: collection.Map[String, String] = shunxinCityMapBc.value
        breakable {
          for (elem <- mapBc) {
            if (req_address.contains(elem._2)) {
              citycode = elem._1
              o.put("citycode_map", elem._1)
              o.put("city_map", elem._2)
              break()
            }
          }
        }
      }

      val geo_tag = JSONUtil.getJsonVal(o, "geo_tag", "")
      val codeSource = JSONUtil.getJsonVal(o, "codeSource", "").toUpperCase()
      val regexSign = """自提|电联|自取|电话联系""".r
      if (code.isEmpty) {
        msg match {
          case "code的DispThingStatus不符合" => o.put("rslt_tag", "sxDeptNotOpen")
          case "AOI无法匹配顺心网点" => o.put("rslt_tag", "sxDeptNotCover")
          case "地址找不到顺心网点" => o.put("rslt_tag", "sxDeptNotCover")
          case _ => if (req_address.isEmpty || regexSign.findFirstMatchIn(req_address).nonEmpty) o.put("rslt_tag", "keyword")
          else {
            //调切词服务
            val (level, ret) = runSplit(split_url, req_address, citycode)
            o.put("splitLevel", level)
            o.put("splitRet", ret)
            if (level <= 4 || req_address.size <= 5) o.put("rslt_tag", "addressUndetail") else o.put("rslt_tag", "gisEmpty")
          }
        }
      } else {
        o.put("tag", "code_nonEmpty")
        codeSource match {
          case "HIS" => o.put("rslt_tag", "HIS")
          case "AOI" => o.put("rslt_tag", "AOI")
          case "MAPB" => o.put("rslt_tag", "MAPB")
          case "GEO|TS1" => o.put("rslt_tag", "TS")
          case "GEO|TS2" => o.put("rslt_tag", "TS")
          case "MUTILSOURCE" => o.put("rslt_tag", "Mutil")
          case _ => if (geo_tag.equals("1")) o.put("rslt_tag", "HighGeo")
          else if (geo_tag.equals("0")) o.put("rslt_tag", "LowGeo")
        }
      }
      o
    }).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK)


    logger.error("打完rslt_tag标签的数据量：" + rsltRdd.filter(o => JSONUtil.getJsonVal(o, "rslt_tag", "").nonEmpty).count())
    logger.error("关联签收表")

    val reRdd = rsltRdd.map(o => (JSONUtil.getJsonVal(o, "sn", ""), o))
      .leftOuterJoin(signDataRdd)
      .map(o => {
        val left = o._2._1
        val right = o._2._2
        val code = JSONUtil.getJsonVal(left, "code", "")
        if (code.nonEmpty) if (right.nonEmpty) left.put("ewb_tag", "Ewb") else left.put("ewb_tag", "NotEwb")
        left
      }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("打ewb_tag标签的数据量:" + reRdd.filter(o => JSONUtil.getJsonVal(o, "ewb_tag", "").nonEmpty).count())
    reRdd
  }

  def mergeShunxinCover(obj1: result, obj2: result) = {
    val cityCode = obj1.cityCode
    val city = obj1.city

    val req_total_num = obj1.req_total_num + obj2.req_total_num
    val req_zc_num = obj1.req_zc_num + obj2.req_zc_num
    val req_ewb_num = obj1.req_ewb_num + obj2.req_ewb_num
    val req_notewb_num = obj1.req_notewb_num + obj2.req_notewb_num
    val req_notopen_num = obj1.req_notopen_num + obj2.req_notopen_num
    val req_md_num = obj1.req_md_num + obj2.req_md_num
    val req_keyword_num = obj1.req_keyword_num + obj2.req_keyword_num
    val req_undetail_num = obj1.req_undetail_num + obj2.req_undetail_num
    val req_his_num = obj1.req_his_num + obj2.req_his_num
    val req_aoi_num = obj1.req_aoi_num + obj2.req_aoi_num
    val req_mutil_num = obj1.req_mutil_num + obj2.req_mutil_num
    val req_mapb_num = obj1.req_mapb_num + obj2.req_mapb_num
    val req_geo_num = obj1.req_geo_num + obj2.req_geo_num
    val req_highgeo_num = obj1.req_highgeo_num + obj2.req_highgeo_num
    val req_lowgeo_num = obj1.req_lowgeo_num + obj2.req_lowgeo_num
    val req_ts_num = obj1.req_ts_num + obj2.req_ts_num
    val req_unknown_num = obj1.req_unknown_num + obj2.req_unknown_num

    result(
      cityCode
      , city
      , req_total_num
      , req_zc_num
      , req_ewb_num
      , req_notewb_num
      , req_notopen_num
      , req_md_num
      , req_keyword_num
      , req_undetail_num
      , req_his_num
      , req_aoi_num
      , req_mutil_num
      , req_mapb_num
      , req_geo_num
      , req_highgeo_num
      , req_lowgeo_num
      , req_ts_num
      , req_unknown_num
    )


  }

  //入库
  def saveTable(spark: SparkSession, indexRdd: RDD[result], checkRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = checkRdd.map(_.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val tableName = "dm_gis.ods_gis_ass_eds_sx_log" //生产数据表
    rowDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("入明细表完毕")


    logger.error("入指标表的数据量：" + rowDf.count())
    val indexTableName = "dm_gis.ods_gis_ass_eds_sx_index" //生产数据表
    indexRdd.toDF().repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(indexTableName)
    logger.error("入指标表完毕")
  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      """
        |select
        |get_json_object(get_json_object(log, '$.message'), '$.sn') sn,
        |get_json_object(get_json_object(log, '$.message'), '$.type') req_type,
        |get_json_object(get_json_object(log, '$.message'), '$.time') url_time,
        |get_json_object(get_json_object(log, '$.message'), '$.appName') appName,
        |get_json_object(get_json_object(log, '$.message'), '$.dateTime') req_time,
        |get_json_object(get_json_object(get_json_object(log, '$.message'), '$.data'),'$.src') req_src,
        |get_json_object(get_json_object(log, '$.fields'), '$.log_topics') log_topics,
        |regexp_replace(get_json_object(  get_json_object(log, '$.message'),  '$.url.address'),'[\r\n\t]+',''   ) req_address,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.sxData.code'   ) code,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.sxData.codeSource'   ) codeSource,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.sxData.tag'   ) geo_tag,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.uid'   ) gis_aoiid,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.province'   ) province,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.city'   ) city,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.county'   ) county,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.town'   ) town,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.cityCode'   ) citycode,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '$.message'), '$.data'),  '$.result'),'$.areaData.acreage'   ) acreage,
        |get_json_object(get_json_object(get_json_object(get_json_object(log, '$.message'), '$.data'),'$.result'),'$.msg') msg
        |,inc_day as eds_inc_day
        |from
        |dm_gis.ods_gis_ass_eds_sx
        |where
        |inc_day = '%s'
        |and get_json_object(get_json_object(get_json_object(log, '$.message'), '$.url'),'$.ak')='c4066396181d4041bbe63bf5f1607d5f'
        |and get_json_object(get_json_object(log, '$.message'), '$.type') = 'url_e'
      """.stripMargin


    val formatSql = String.format(totalDfSql, incDay)

    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  //跑切词
  def runSplit(url: String, address: String, citycode: String): (Int, JSONObject) = {
    var ret = null: JSONObject
    try {
      val encodeAddress = URLEncoder.encode(address, "utf-8")
      ret = HttpClientUtil.getJsonByGet(String.format(split_url, encodeAddress, citycode))
      if (ret != null && ret.getJSONObject("result") != null) {
        if (ret.getJSONObject("result").getInteger("err") == 109) {
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep(60 - second)
          return runSplit(url, address, citycode)
        }
        val levelArray = JSONUtil.getJsonArrayFromObject(ret, "result.data.info", new JSONArray())
        var maxLevel = -1
        for (i <- 0 until levelArray.size()) {
          val tmpLevel = JSONUtil.getJsonValInt(levelArray.getJSONObject(i), "level", -1)
          if (tmpLevel > maxLevel) {
            maxLevel = tmpLevel
          }
        }
        if (maxLevel == -1) {
          maxLevel = 10000
        }
        return (maxLevel, ret)

      }
    } catch {
      case e: Exception => logger.error(e)
    }
    (10000, ret)
  }


  //日志解析
  def analysisRdd(spark: SparkSession, dataRdd: RDD[JSONObject], incDay: String) = {


    import spark.implicits._

    logger.error("解析的数据量" + dataRdd.count())

    val finalRdd = dataRdd.map(obj => {

      logDetail(
        JSONUtil.getJsonVal(obj, "sn", "")
        , JSONUtil.getJsonVal(obj, "req_type", "")
        , JSONUtil.getJsonVal(obj, "url_time", "")
        , JSONUtil.getJsonVal(obj, "appName", "")
        , JSONUtil.getJsonVal(obj, "req_time", "")
        , JSONUtil.getJsonVal(obj, "req_src", "")
        , JSONUtil.getJsonVal(obj, "log_topics", "")
        , JSONUtil.getJsonVal(obj, "req_address", "")
        , JSONUtil.getJsonVal(obj, "code", "")
        , JSONUtil.getJsonVal(obj, "codeSource", "")
        , JSONUtil.getJsonVal(obj, "geo_tag", "")
        , JSONUtil.getJsonVal(obj, "gis_aoiid", "")
        , JSONUtil.getJsonVal(obj, "province", "")
        , JSONUtil.getJsonVal(obj, "city", "")
        , JSONUtil.getJsonVal(obj, "county", "")
        , JSONUtil.getJsonVal(obj, "town", "")
        , JSONUtil.getJsonVal(obj, "citycode", "")
        , JSONUtil.getJsonVal(obj, "acreage", "")
        , JSONUtil.getJsonVal(obj, "msg", "")
        , JSONUtil.getJsonVal(obj, "eds_inc_day", "")
        , JSONUtil.getJsonVal(obj, "rslt_tag", "")
        , JSONUtil.getJsonVal(obj, "city_map", "")
        , JSONUtil.getJsonVal(obj, "citycode_map", "")
        , JSONUtil.getJsonVal(obj, "splitRet", "")
        , JSONUtil.getJsonVal(obj, "ewb_tag", "")

      )
    }).toDF().repartition(20).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("入库的数据量：" + finalRdd.count())

    finalRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })

    val tableName = "dm_gis.ods_gis_ass_eds_sx_log_jx"
    finalRdd.repartition(20).withColumn("partition_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("解析数据入库完毕")
  }
}
