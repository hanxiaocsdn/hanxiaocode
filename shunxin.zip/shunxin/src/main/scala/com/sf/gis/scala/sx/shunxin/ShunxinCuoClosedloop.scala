package com.sf.gis.scala.sx.shunxin

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.java.sx.constant.util.{FileUtil, Utils}
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.sx.util.{DateUtil, JSONUtil, SparkUtils, Util}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util
import java.util.Date
import scala.collection.JavaConversions._
import scala.util.control.Breaks

/**
  * 顺心错分闭环
  * Created by 01412406
  * 邓蔼娟 01427169
  * 任务id：905229
  */
object ShunxinCuoClosedloop {

  @transient lazy val logger: Logger = Logger.getLogger(ShunxinCuoClosedloop.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 2.0
  println("=============>"+version)
  val sql_partition = 20

  val file_prop = FileUtil.getFileProperties("conf/shunxin_sta.properties")
  val shunxin_dept_url_v3 = file_prop.getProperty("shunxin_dept_url_v4")
  val gd_url_v5 = file_prop.getProperty("gd_url_v5")
  val ts_url_v2 = file_prop.getProperty("ts_url_v2")
  val sx_dept_v2 = file_prop.getProperty("sx_dept_v2")
  val splitUrl = file_prop.getProperty("splitUrl")
  val dgssUrl = file_prop.getProperty("dgssUrl")
  println(shunxin_dept_url_v3)
  println(gd_url_v5)
  println(ts_url_v2)
  println(sx_dept_v2)
  println(splitUrl)
  println(dgssUrl)

  val  close_loop_table="dm_gis.shunxin_wrong_close_loop_detaid"
  val  push_table="dm_gis.shunxin_business_push_detail"
  val  abn_wrong_table="dm_gis.shunxin_abn_wrong_adress"
  val  abn_wrong_detail_table="dm_gis.shunxin_cuo_closed_loop_detail_di"
  val  shunxin_geo_gdss_adress_import="dm_gis.shunxin_geo_gdss_adress_import"



  case class AbnRe(
                   sign_address:String
                  ,wrong_num_month:String
                  ,wrong_ewb_num_month:String
                  ,desc_add_wrong_month:String
                  ,total_month:String
                  ,wrong_top_month:String
                  ,data_time:String

  )



  case class PushRe(
                     ewb_no:String
                    ,order_time:String
                    ,sign_time:String
                    ,last_gis_sn:String
                    ,order_zc:String
                    ,sign_address:String
                    ,sign_zc:String
                    ,final_zc:String
                    ,final_zc_name:String
                    ,final_src:String
                    ,final_province:String
                    ,final_city:String
                    ,final_county:String
                    ,final_town:String
                    ,final_citycode:String
                    ,final_area_src:String
                    ,final_aoiid:String
                    ,aoi_geotype:String
                    ,business_tag_b1:String
                    ,business_tag_b2:String
                    ,business_tag_b3:String
                    ,business_tag_b4:String
                    ,business_tag_b5:String
                    ,business_tag_b6:String
                    ,business_tag_b:String
                    ,business_tag_c1:String
                    ,business_tag_c2:String
                    ,shunxin_business_push:String
  )


  case class ClReq(
                       ewb_no:String
                      ,order_time:String
                      ,modify_time:String
                      ,sign_time:String
                      ,last_gis_sn:String
                      ,order_zc:String
                      ,order_address:String
                      ,order_gis_zc:String
                      ,sign_address:String
                      ,sign_zc:String
                      ,sign_province:String
                      ,sign_city:String
                      ,sign_county:String
                      ,sign_town:String
                      ,final_zc:String
                      ,final_zc_name:String
                      ,final_src:String
                      ,final_province:String
                      ,final_city:String
                      ,final_county:String
                      ,final_town:String
                      ,final_citycode:String
                      ,final_area_src:String
                      ,final_aoiid:String
                      ,report_tag:String
                      ,optional_site_flag:String
                      ,return_ewb_no:String
                      ,order_source:String
                      ,sign_flag_name:String
                      ,aoi_tag:String
                      ,aoi_geotype:String
                      ,split_result:String
                      ,exist_3:String
                      ,exist_4:String
                      ,exist_5:String
                      ,exist_6:String
                      ,exist_9:String
                      ,exist_10:String
                      ,exist_11:String
                      ,exist_13:String
                      ,exist_613:String
                      ,exist_14:String
                      ,level_word_1:String
                      ,level_word_2:String
                      ,level_word_3:String
                      ,level_word_4:String
                      ,level_word_5:String
                      ,level_word_6:String
                      ,level_word_9:String
                      ,level_word_10:String
                      ,level_word_11:String
                      ,level_word_13:String
                      ,level_word_613:String
                      ,level_word_14:String
                      ,is_return:String
                      ,exist_town:String
                      ,exist_1314:String
                      ,exist_9111314:String
                      ,zc_source_type:String
                      ,area_source_type:String
                      ,order_zc_citycode:String
                      ,sign_zc_citycode:String
                      ,final_zc_citycode:String
                      ,cross_city_order_sign:String
                      ,cross_city_order_final:String
                      ,final_town_clear:String
                      ,combine_address_town:String
                      ,combine_address_road:String
                      ,address_town_equal:String
                      ,combine_zc_source:String
                      ,combine_area_source:String
                      ,combine_x:String
                      ,combine_y:String
                      ,combine_zc:String
                      ,combine_province:String
                      ,combine_city:String
                      ,combine_county:String
                      ,combine_town:String
                      ,combine_zc_road_source:String
                      ,combine_area_road_source:String
                      ,combine_x_road:String
                      ,combine_y_road:String
                      ,combine_zc_road:String
                      ,combine_province_road:String
                      ,combine_city_road:String
                      ,combine_county_road:String
                      ,combine_town_road:String
                      ,combine_town_equal:String
                      ,combine_town_equal_road:String
                      ,combine_zc_equal:String
                      ,combine_zc_road_equal:String
                      ,combine_zc_sign_equal:String
                      ,combine_zc_sign_equal_road:String
                      ,sign_zc_diff_num:String
                      ,sign_num:String
                      ,sign_waybill_num:String
                      ,wrong_num_month:String
                      ,wrong_ewb_num_month:String
                      ,desc_add_wrong_month:String
                      ,total_month:String
                      ,wrong_top_month:String
                      ,x_first_gdv5:String
                      ,y_first_gdv5:String
                      ,x_second_gdv5:String
                      ,y_second_gdv5:String
                      ,x_bd1:String
                      ,y_bd1:String
                      ,x_gd1:String
                      ,y_gd1:String
                      ,zc_bd1:String
                      ,zc_gd1:String
                      ,zc_first_gdv5:String
                      ,zc_second_gdv5:String
                      ,bd1_sign_zc_equal:String
                      ,bd1_sf_zc_equal:String
                      ,gd1_sign_zc_equal:String
                      ,gd1_sf_zc_equal:String
                      ,gdv5_sign_zc_equal:String
                      ,gdv5_sf_zc_equal:String
                      ,zc_front_gdv5:String
                      ,zc_union_gdv5:String
                      ,gdv5_front_sign_zc_equal:String
                      ,gdv5_front_sf_zc_equal:String
                      ,gdv5_union_sign_zc_equal:String
                      ,gdv5_union_sf_zc_equal:String
                      ,bd1_gd1_zc_equal:String
                      ,bd1_gdv5_first_zc_equal:String
                      ,bd1_union_zc_equal:String
                      ,bd1_front_zc_equal:String
                      ,gd1_gdv5_first_zc_equal:String
                      ,sf_map_inequal_num:String
                      ,sign_map_inequal_num:String
                      ,sf_sign_map_diff_num:String
                      ,sf_inequal_num:String
                      ,sign_inequal_num:String
                      ,sf_sign_diff_num:String
                      ,unreliable_poi1:String
                      ,unreliable_poi2:String
                      ,aoi_cross_street:String
                      ,exist_911_not13:String
                      ,business_tag_a:String
                      ,business_tag_b1:String
                      ,business_tag_b2:String
                      ,business_tag_b3:String
                      ,business_tag_b4:String
                      ,business_tag_b5:String
                      ,business_tag_b6:String
                      ,business_tag_b:String
                      ,business_tag_c1:String
                      ,business_tag_c2:String
                      ,wrong_tag_a:String
                      ,gdss_x:String
                      ,gdss_y:String
                      ,geo_gdss_import:String
                      ,business_tag:String
                      ,shunxin_business_push:String
                      ,aoi_arss_task_puss:String
                      ,business_tag_c:String
                      ,exist_911:String
                      ,aoi_cross_zc:String
                      ,aoi_cross_zc_num:String
                      ,aoi_cross_zc_area:String
                      ,address_change:String
                      ,no_business_tag_a:String
                      ,business_tag_d1:String
                      ,business_tag_d2:String
                      ,business_tag_d3:String
                      ,business_tag_d4:String
                      ,business_tag_d:String
                      ,level_word_18:String
                      ,word_18_mix:String
                      ,end_word:String
                      ,unreliable_poi3:String
                      ,aoi_cross_zc_area_ratio:String
                      ,bus_hall:String
                      ,wrong_tag_b:String

                   )




  case class gdss(
                   ewb_no:String
                  ,sign_address:String
                  ,final_citycode:String
                  ,sign_zc:String
                  ,combine_address_town:String
                  ,combine_address_road:String
                  ,address_town_equal:String
                  ,combine_zc:String
                  ,combine_town:String
                  ,combine_town_road:String
                  ,combine_town_equal:String
                  ,combine_zc_equal:String
                  ,combine_zc_sign_equal:String
                  ,combine_zc_sign_equal_road:String
                  ,wrong_tag_a:String
                  ,gdss_x:String
                  ,gdss_y:String
                  ,geo_gdss_import:String
                  ,gdss_status:String
                  ,gdss_zc:String
                  ,check_result_code:String
                  ,check_result:String
                  ,check_src:String
                  ,shunxin_src:String
                  ,check_shunxin_src:String
                  ,import_succeed:String
                  ,resp_time:String
//                  ,code:String
//                  ,subCode:String
//                  ,success:String
//                  ,message:String
//                  ,time:String
  )


  def savexy(param: JSONObject) = {
    var x = ""
    var y = ""
    Breaks.breakable {
      Array("combine_zc_sign_equal", "combine_zc_sign_equal_road", "bd1_sign_zc_equal", "gd1_sign_zc_equal", "gdv5_sign_zc_equal", "gdv5_second_sign_zc_equal").foreach(o => {

        val v = JSONUtil.getJsonVal(param, o, "")
        val tag = try{v.split("_")(0)}catch {case exception: Exception=>""}
        if (tag.nonEmpty && v.nonEmpty &&  v.split("_")(0).equals("true")) {
          x = try {
            v.split("_")(1)
          } catch {
            case exception: Exception => ""
          }
          y = try {
            v.split("_")(2)
          } catch {
            case exception: Exception => ""
          }
        }
        if (x.nonEmpty) Breaks.break()
      }
      )
    }
    (x, y)
  }


  def queryCfAddr(spark: SparkSession,incDay:String)= {
    logger.error("查询最近一个月的错分地址高频")

    val day93 = DateUtil.getDateStr(incDay, -92, "")
    val day31 = DateUtil.getDateStr(incDay, -30, "")

    val baseSql =
      s"""
        |select
        |ewb_sign_address as sign_address,
        |count(ewb_no) as wrong_num_month,
        |count(distinct ewb_no) as wrong_ewb_num_month
        |from
        |dm_gis.shunxin_detail_di_jx_new a
        |left join (
        |select
        |waybill_no,
        |case
        |when data_source = 'openWaybill' then '普通开单'
        |when data_source = 'oneKey' then '回单一键开单'
        |when data_source = 'returnOpenWaybill' then '新单返货'
        |when data_source = 'originalWaybillReturn' then '原单返货'
        |when data_source = 'copyOpenWaybill' then '复制开单'
        |when data_source = 'ediOpenWaybill' then 'EDI开单'
        |when data_source = 'orderTransferWaybill' then '订单转运单'
        |when return_waybill_no <> ''
        |and return_waybill_no <> 'null' then '新单返货'
        |when special_address_service_type_name <> ''
        |and special_address_service_type_name <> 'null' then '特殊运单'
        |else data_source
        |end as `data_source_name`
        |from
        |ky.ods_sx_abws_waybill.wb_waybill1
        |where
        |inc_day between '${day93}' and '${incDay}' and rd_status <> '0'
        |and (data_source in ('originalWaybillReturn','oneKey','returnOpenWaybill')
        |or (return_waybill_no <> '' and return_waybill_no <> 'null'))) b on a.ewb_no = b.waybill_no
        |where
        |a.inc_day between '${day31}'
        |and '${incDay}'
        |and a.tag = 'wrong'
        |and a.ewb_sign_address <> ''
        |and b.waybill_no is null
        |group by
        |a.ewb_sign_address
        |""".stripMargin

    logger.error("baseTable===>"+baseSql)
    val dataMap = spark.sql(baseSql).createOrReplaceTempView("baseTable")


    val sql =
      """
        |select
        |*
        |,desc_add_wrong_month/total_month as wrong_top_month
        |from (
        |select
        |sign_address,
        |wrong_num_month,
        |wrong_ewb_num_month,
        |max(wrong_num_month) over() as desc_add_wrong_month,
        |sum(wrong_num_month) over() as total_month
        |from baseTable a
        |)a
        |""".stripMargin
    logger.error(sql)
    val addrRdd = SparkUtils.getRowToJson(spark,sql).map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),o)).filter(_._1.nonEmpty)
    logger.error("错分地址高频数量:" + addrRdd.count())
    addrRdd
  }





  def queryabnRdd(spark: SparkSession,incDay:String)= {
    logger.error("查询历史黑名单的数据")
    val sql =
      s"""
        |select sign_address
        |--from ${abn_wrong_table}
        |from dm_gis.shunxin_abn_wrong_adress
        |where sign_address <> '' and  sign_address is not null and inc_day < '${incDay}'
        |group by sign_address
        |""".stripMargin
    logger.error(sql)
    val abnRdd = SparkUtils.getRowToJson(spark,sql).map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),"true"))
    logger.error("历史黑名单数量:" + abnRdd.count())
    abnRdd
  }






  //查询最近三个月内签收网点量
  def queryqsRdd(spark: SparkSession,incDay:String)= {

    val day93 = DateUtil.getDateStr(incDay, -92, "")


    logger.error("查询最近三个月内签收网点量")
    val sql =
      s"""
        |select
        |a.ewb_sign_address as sign_address,
        |count(distinct a.ewb_sign_site_code) as sign_zc_diff_num,
        |count(a.ewb_no) as sign_num,
        |count(distinct a.ewb_no) as sign_waybill_num
        |from
        |(
        |select
        |ewb_no,
        |ewb_sign_site_code,
        |ewb_sign_address
        |from dm_gis.shunxin_detail_di_jx_new
        |where
        |inc_day between '${day93}'
        |and '${incDay}'
        |and tag in ('wrong', 'same', 'same_new')
        |and ewb_sign_address <> ''
        |) a
        |left join (
        |select
        |waybill_no
        |from
        |ky.ods_sx_abws_waybill.wb_waybill1
        |where
        |inc_day between '${day93}' and '${incDay}' and rd_status <> '0'
        |and (data_source in ('originalWaybillReturn','oneKey','returnOpenWaybill')
        |or (return_waybill_no <> ''and return_waybill_no <> 'null'))
        |group by waybill_no
        |) b on a.ewb_no = b.waybill_no
        |where
        |b.waybill_no is null
        |group by
        |a.ewb_sign_address
        |""".stripMargin
    logger.error(sql)
    val qsRdd = SparkUtils.getRowToJson(spark,sql).map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),o)).persist(StorageLevel.MEMORY_ONLY)
    logger.error("查询最近三个月内签收网点量的数据量:" + qsRdd.count())
    qsRdd
  }




  //调取顺心网点接口获取网点
  def runDeptInter(x:String,y:String) = {
    var dept =""
    var reqStr = ""
    var level = ""
    if(x.nonEmpty && y.nonEmpty){
      val formatUrl = sx_dept_v2.format(x,y)
      val req = HttpClientUtil.getJsonByGet(formatUrl)
      if (req != null) {
      reqStr = req.toJSONString
      val list = JSONUtil.getJsonArrayFromObject(req,"result.map_data",new JSONArray())
        Breaks.breakable {
          for(i<- 0 until list.size()){
            val js = list.getJSONObject(i)
             level = JSONUtil.getJsonVal(js,"level","")
            if(level.equals("17"))dept = JSONUtil.getJsonVal(js,"code","")
            if(dept.nonEmpty)Breaks.break()
          }
        }
      }
    }
    (dept,reqStr)
  }

//调取图商接口获取经纬度
  def runTsInter(o:JSONObject) = {
    val sign_address = JSONUtil.getJsonVal(o,"sign_address","")
    val final_citycode = JSONUtil.getJsonVal(o,"final_citycode","")
    if(sign_address.nonEmpty && final_citycode.nonEmpty){
      Array("bd1","gd1").foreach(opt=>{
        val formatUrl = ts_url_v2.format(URLEncoder.encode(sign_address, "utf-8"), final_citycode, opt)
        val req = HttpClientUtil.getJsonByGet(formatUrl)
        if (req != null) {
          o.put(s"${opt}_req", req.toJSONString)
          val xcoord = JSONUtil.getJsonVal(req,"result.xcoord","")
          val ycoord = JSONUtil.getJsonVal(req,"result.ycoord","")
          o.put(s"x_${opt}", xcoord)
          o.put(s"y_${opt}", ycoord)
          val (dept,reqStr) = runDeptInter(xcoord,ycoord)
          o.put(s"zc_${opt}",dept)
          o.put(s"zcReq_${opt}",reqStr)
        }
      })
    }
    o
  }



  def checkyw(spark: SparkSession, cfRdd: RDD[JSONObject],incDay:String) ={
    val addrRdd = queryCfAddr(spark,incDay)
    val abnRdd = queryabnRdd(spark,incDay)
   val joinRdd =  cfRdd.map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),o)).leftOuterJoin(addrRdd).map(o=>{
      val left  = o._2._1
      val right  = o._2._2
      if(right.nonEmpty){
        left.put("wrong_num_month",JSONUtil.getJsonVal(right.get,"wrong_num_month",""))
        left.put("wrong_ewb_num_month",JSONUtil.getJsonVal(right.get,"wrong_ewb_num_month",""))
        left.put("desc_add_wrong_month",JSONUtil.getJsonVal(right.get,"desc_add_wrong_month",""))
        left.put("total_month",JSONUtil.getJsonVal(right.get,"total_month",""))
        left.put("wrong_top_month",JSONUtil.getJsonVal(right.get,"wrong_top_month",""))
      }
      left
    }).persist(StorageLevel.MEMORY_ONLY)
    logger.error("关联完的数据量:"+joinRdd.count())
    cfRdd.unpersist()
    logger.error("调高德v5,图商接口")
    val reNum = joinRdd.count().toInt
    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "905229", "顺心错分闭环_ShunxinCuoClosedloop", "顺心错分闭环_ShunxinCuoClosedloop", gd_url_v5, "8cb19f422db34736922479ba0bc848f4", reNum, 5)
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "905229", "顺心错分闭环_ShunxinCuoClosedloop", "顺心错分闭环_ShunxinCuoClosedloop", ts_url_v2, "8bb09e5e110845f39a000391668e3e80", reNum, 5)
    val httpInvokeId3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "905229", "顺心错分闭环_ShunxinCuoClosedloop", "顺心错分闭环_ShunxinCuoClosedloop", sx_dept_v2, "8cb19f422db34736922479ba0bc848f4", reNum, 5)
    val gdTsRdd = joinRdd.repartition(5).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {

        val sign_address = JSONUtil.getJsonVal(o, "sign_address", "")
        if(sign_address.nonEmpty){
          val formatUrl = gd_url_v5.format(URLEncoder.encode(sign_address, "utf-8"))
          SparkUtils.limitAkUse(startTime, cnt, index, 2000 / 5, logger)
          val req = getJsonByGet(formatUrl)
          if (req != null) {
            o.put("gdv5_req", req.toJSONString)
            val pois = try{JSONUtil.getJsonArrayFromObject(req,"result.pois",new JSONArray()).getJSONObject(0)}catch { case exception: Exception => new JSONObject()}
            val pois2 = try{JSONUtil.getJsonArrayFromObject(req,"result.pois",new JSONArray()).getJSONObject(1)}catch { case exception: Exception => new JSONObject()}
            val location1 = JSONUtil.getJsonVal(pois,"location","").split(",")
            val location2 = JSONUtil.getJsonVal(pois2,"location","").split(",")
            val x_first_gdv5 = try{location1(0)}catch {case exception: Exception =>""}
            val y_first_gdv5 =try{location1(1)}catch {case exception: Exception =>""}
            val x_second_gdv5 =try{location2(0)}catch {case exception: Exception =>""}
            val y_second_gdv5 =try{location2(1)}catch {case exception: Exception =>""}
            o.put("x_first_gdv5",x_first_gdv5)
            o.put("y_first_gdv5",y_first_gdv5)
            o.put("x_second_gdv5",x_second_gdv5)
            o.put("y_second_gdv5",y_second_gdv5)
            val (zc_first_gdv5,zc_first_gdv5_reqStr) = runDeptInter(x_first_gdv5,y_first_gdv5)
            val (zc_second_gdv5,zc_second_gdv5_reqStr) = runDeptInter(x_second_gdv5,y_second_gdv5)
            o.put("zc_first_gdv5",zc_first_gdv5)
            o.put("zc_second_gdv5",zc_second_gdv5)
            o.put("zc_first_gdv5_reqStr",zc_first_gdv5_reqStr)
            o.put("zc_second_gdv5_reqStr",zc_second_gdv5_reqStr)
          }
          runTsInter(o)
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId1)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId3)
    logger.error("调完高德v5,图商接口的数据量："+gdTsRdd.count())
    logger.error("业务标识打标签")
    val preTagRdd =gdTsRdd.map(o=>{
      val sign_zc = JSONUtil.getJsonVal(o,"sign_zc","")
      val cross_zc_num = try{JSONUtil.getJsonVal(o,"aoi_cross_zc_num","").toInt}catch {case exception: Exception=>0}
      val zc_source_type = JSONUtil.getJsonVal(o,"zc_source_type","")
      val order_address = JSONUtil.getJsonVal(o,"order_address","")
      val level_word_18 = JSONUtil.getJsonVal(o,"level_word_18","")
      val sign_address = JSONUtil.getJsonVal(o,"sign_address","")
//      val combine_zc_equal = JSONUtil.getJsonVal(o,"combine_zc_equal","")
//      val combine_zc_road_equal = JSONUtil.getJsonVal(o,"combine_zc_road_equal","")
      val combine_zc_sign_equal = JSONUtil.getJsonVal(o,"combine_zc_sign_equal","")
      val combine_zc_sign_equal_road = JSONUtil.getJsonVal(o,"combine_zc_sign_equal_road","")
      val zc_bd1 = JSONUtil.getJsonVal(o,"zc_bd1","")
      val final_zc = JSONUtil.getJsonVal(o,"final_zc","")
      val zc_gd1 = JSONUtil.getJsonVal(o,"zc_gd1","")
      val zc_first_gdv5 = JSONUtil.getJsonVal(o,"zc_first_gdv5","")
      val zc_second_gdv5 = JSONUtil.getJsonVal(o,"zc_second_gdv5","")
      val exist_13 = JSONUtil.getJsonVal(o, "exist_13", "")
      val exist_14 = JSONUtil.getJsonVal(o, "exist_14", "")
      val exist_613 = JSONUtil.getJsonVal(o, "exist_613", "")
      val level_word_13 = JSONUtil.getJsonVal(o, "level_word_13", "")
      val aoi_geotype = JSONUtil.getJsonVal(o, "aoi_geotype", "")
      val exist_911 = JSONUtil.getJsonVal(o, "exist_911", "")
      val zc_front_gdv5 = if(checktf(zc_first_gdv5,zc_second_gdv5).equals("true")) zc_first_gdv5 else ""
      //获取高德v5唯一网点，zc_first_gdv5 不为空，且 zc_second_gdv5为空。或zc_first_gdv5 为空且 zc_second_gdv5不为空


      val zc_union_gdv5 = if (zc_first_gdv5.nonEmpty && zc_second_gdv5.isEmpty) zc_first_gdv5 else if(zc_second_gdv5.nonEmpty && zc_first_gdv5.isEmpty) zc_second_gdv5 else ""
      o.put("bd1_sign_zc_equal",checktf(sign_zc,zc_bd1))
      o.put("bd1_sf_zc_equal",checktf(final_zc,zc_bd1))
      o.put("gd1_sign_zc_equal",checktf(sign_zc,zc_gd1))
      o.put("gd1_sf_zc_equal",checktf(final_zc,zc_gd1))
      o.put("gdv5_sign_zc_equal",checktf(sign_zc,zc_first_gdv5))
      o.put("gdv5_sf_zc_equal",checktf(final_zc,zc_first_gdv5))
      o.put("zc_front_gdv5",zc_front_gdv5)
      o.put("zc_union_gdv5",zc_union_gdv5)
      o.put("gdv5_front_sign_zc_equal",checktf(zc_front_gdv5,sign_zc))
      o.put("gdv5_front_sf_zc_equal",checktf(zc_front_gdv5,final_zc))
      o.put("gdv5_union_sign_zc_equal",checktf(zc_union_gdv5,sign_zc))
      o.put("gdv5_union_sf_zc_equal",checktf(zc_union_gdv5,final_zc))
      o.put("bd1_gd1_zc_equal",checktf(zc_bd1,zc_gd1))
      o.put("bd1_gdv5_first_zc_equal",checktf(zc_bd1,zc_first_gdv5))
      o.put("bd1_union_zc_equal",checktf(zc_bd1,zc_union_gdv5))
      o.put("bd1_front_zc_equal",checktf(zc_bd1,zc_front_gdv5))
      o.put("gd1_gdv5_first_zc_equal",checktf(zc_gd1,zc_first_gdv5))

      val sf_map_inequal_num = new util.HashSet[String]()
      sf_map_inequal_num.add(zc_first_gdv5)
      sf_map_inequal_num.add(zc_gd1)
      sf_map_inequal_num.add(zc_bd1)
      sf_map_inequal_num.add(final_zc)
      //高德v5、高德1、百度1、最终识别网点中唯一值的数量？zc_first_gdv5、zc_gd1、zc_bd1、final_zc去重后数量（忽略空值）
      o.put("sf_map_inequal_num",sf_map_inequal_num.filter(_.nonEmpty).size())
      //高德v5、高德1、百度1、签收网点中唯一值的数量？zc_first_gdv5、zc_gd1、zc_bd1、sign_zc去重后数量（忽略空值）
      val sign_map_inequal_num = new util.HashSet[String]()
      sign_map_inequal_num.add(zc_first_gdv5)
      sign_map_inequal_num.add(zc_gd1)
      sign_map_inequal_num.add(zc_bd1)
      sign_map_inequal_num.add(sign_zc)

      val sf_sign_map_diff_num = sign_map_inequal_num.filter(_.nonEmpty).size() - sf_map_inequal_num.filter(_.nonEmpty).size()
      o.put("sign_map_inequal_num",sign_map_inequal_num.filter(_.nonEmpty).size())
      o.put("sf_sign_map_diff_num",sf_sign_map_diff_num)

      //最终识别网点和高德v5、高德1、百度1网点不一致的数量？final_zc 和以下网点不一致则+1（zc_first_gdv5、zc_gd1、zc_bd1、final_zc）（忽略空值）
      var sf_inequal_num = 0
      Array(zc_first_gdv5,zc_gd1,zc_bd1,final_zc).foreach(key=>if(key.nonEmpty && !key.equals(final_zc)) sf_inequal_num = sf_inequal_num+1 )
      o.put("sf_inequal_num",sf_inequal_num)
      //签收网点和高德v5、高德1、百度1网点不一致的数量？sign_zc 和以下网点不一致则+1（zc_first_gdv5、zc_gd1、zc_bd1、final_zc）（忽略空值）
      var sign_inequal_num = 0
      Array(zc_first_gdv5,zc_gd1,zc_bd1,final_zc).foreach(key=>if(key.nonEmpty && !key.equals(sign_zc)) sign_inequal_num = sign_inequal_num +1 )
      o.put("sign_inequal_num",sign_inequal_num)
      o.put("sf_sign_diff_num",sign_inequal_num-sf_inequal_num)
      //地址是否只存在613不存在其他13？exist_13 == False and exist_613 == True
      if(exist_13.equals("false") && exist_613.equals("true")) o.put("unreliable_poi1","true") else o.put("unreliable_poi1","false")
      //13级文本Level_word_13是否包含(公交站/地铁站/工业区/工业园/村/快递/驿站/大桥/立交桥)，或者包含”仓”且13级文本字数<5？
      val lw13 = level_word_13.replaceAll("_","").replaceAll("公交站|地铁站|工业区|工业园|村|快递|驿站|大桥|立交桥|仓库|酒店|超市|市场|快递|仓库|库房|公寓|物流园","_")
      val lw132 = level_word_13.replaceAll("_","").replaceAll("仓","_")
      if(lw13.contains("_") || (lw132.contains("_") && level_word_13.size<5)) o.put("unreliable_poi2","true") else o.put("unreliable_poi2","false")
      //aoi是否跨街道？
      if(aoi_geotype.toUpperCase().equals("KUA")) o.put("aoi_cross_street","true") else o.put("aoi_cross_street","false")
      //是否存在9+11无13？
      if(exist_911.equals("true") && exist_13.equals("false")) o.put("exist_911_not13","true") else o.put("exist_911_not13","false")


      //aoi是否跨网点？ cross_zc_num > 1




      if(cross_zc_num.toInt > 1) o.put("aoi_cross_zc","true") else o.put("aoi_cross_zc","false")
      //签收网点是否和村镇路一致？ zc_source_type = False and (combine_zc_equal = True or  combine_zc_road_equal = True)
      if(zc_source_type.equals("false") && (combine_zc_sign_equal_road.equals("true") || combine_zc_sign_equal.equals("true"))) o.put("no_business_tag_a","true") else o.put("no_business_tag_a","false")
      if(order_address.nonEmpty && order_address.equals(sign_address))o.put("address_change","true") else o.put("address_change","false")
      if(level_word_18.nonEmpty && level_word_18.size >=8 ) o.put("word_18_mix","true") else o.put("word_18_mix","false")
      //Sign_address 最后两个字是否为 对面/旁边/附近/侧面/仓库/库房/路口/路旁，或最后一个字为仓，或最后三个字为交叉口?
      if(sign_address.nonEmpty && sign_address.matches(".*(对面|旁边|附近|侧面|仓库|库房|路口|路旁|仓|交叉口)"))o.put("end_word","true") else o.put("end_word","false")
      //地址是否只存在14不存在其他13？ exist_13 == False and exist_14 == True
      if(exist_13.equals("false") && exist_14.equals("true"))o.put("unreliable_poi3","true") else o.put("unreliable_poi3","false")




      //打标业务标识A: 开单和签收网点城市不一致+最终识别和开单网点城市不一致+aoi不跨镇
      val cross_city_order_sign = JSONUtil.getJsonVal(o,"cross_city_order_sign","")
      val cross_city_order_final = JSONUtil.getJsonVal(o,"cross_city_order_final","")
      val area_source_type = JSONUtil.getJsonVal(o,"area_source_type","")
      val bd1_gd1_zc_equal = JSONUtil.getJsonVal(o,"bd1_gd1_zc_equal","")
      val bd1_sf_zc_equal = JSONUtil.getJsonVal(o,"bd1_sf_zc_equal","")
      val bd1_sign_zc_equal = JSONUtil.getJsonVal(o,"bd1_sign_zc_equal","")
      val gdv5_union_sf_zc_equal = JSONUtil.getJsonVal(o,"gdv5_union_sf_zc_equal","")
      val bd1_union_zc_equal = JSONUtil.getJsonVal(o,"bd1_union_zc_equal","")
      val gdv5_front_sf_zc_equal = JSONUtil.getJsonVal(o,"gdv5_front_sf_zc_equal","")
      val gdv5_front_sign_zc_equal = JSONUtil.getJsonVal(o,"gdv5_front_sign_zc_equal","")
      val gd1_sf_zc_equal = JSONUtil.getJsonVal(o,"gd1_sf_zc_equal","")
      val gdv5_sf_zc_equal = JSONUtil.getJsonVal(o,"gdv5_sf_zc_equal","")
      val gd1_gdv5_first_zc_equal = JSONUtil.getJsonVal(o,"gd1_gdv5_first_zc_equal","")
      val gd1_sign_zc_equal = JSONUtil.getJsonVal(o,"gd1_sign_zc_equal","")
      val gdv5_sign_zc_equal = JSONUtil.getJsonVal(o,"gdv5_sign_zc_equal","")


      if(cross_city_order_sign.equals("true") && cross_city_order_final.equals("true") && area_source_type.equals("true")) o.put("business_tag_a","true") else o.put("business_tag_a","false")
//打标业务标识B1:
      //百度1+高德1识别网点一致,且和丰图识别一致，或签收网点不一致
      //(bd1_gd1_zc_equal == true  and bd1_sf_zc_equal == true ) or (bd1_gd1_zc_equal == true  and  and  bd1_sign_zc_equal  == false)
      if(bd1_gd1_zc_equal.equals("true") && bd1_sf_zc_equal.equals("true")) o.put("business_tag_b1","true") else o.put("business_tag_b1","false")
//打标业务标识B2:高德唯一网点一致，且丰图识别网点一致
      // gdv5_union_sf_zc_equal  == True
      if(gdv5_union_sf_zc_equal.equals("true")) o.put("business_tag_b2","true") else o.put("business_tag_b2","false")
      //打标业务标识B3:
      //百度1+高德唯一网点一致,且丰图识别网点一致,或签收网点不一致
      //(bd1_sf_zc_equal == True  and
      // gdv5_union_sf_zc_equal  == True) or (bd1_gdv5_union_zc_equal== True and  bd1_sign_zc_equal == False ) Business_Tag_B3 = False
      if(gdv5_union_sf_zc_equal.equals("true") && bd1_sf_zc_equal.equals("true")) o.put("business_tag_b3","true") else o.put("business_tag_b3","false")
      //打标业务标识B4:高德前两一致，且丰图识别网点一致，或签收网点不一致
      //gdv5_front_sf_zc_equal  == True or gdv5_front_sign_zc_equal  == False
      if( gdv5_front_sf_zc_equal.equals("true")) o.put("business_tag_b4","true") else o.put("business_tag_b4","false")
      //打标业务标识B5://高德1和高德v5第一个一致，且丰图识别网点一致，或签收网点不一致//(gd1_sf_zc_equal  == True and gdv5_sf_zc_equal  == True) or (gd1_gdv5_first_zc_equal == True and gd1_sign_zc_equal  == False )
      if(gd1_sf_zc_equal.equals("true") && gdv5_sf_zc_equal.equals("true")
      ) o.put("business_tag_b5","true") else o.put("business_tag_b5","false")
      //打标业务标识B6: 百度1和高德v5第一个一致，且丰图识别网点一致，且签收网点不一致  bd1_sf_zc_equal  == True and gdv5_sf_zc_equal  == True and gdv5_first_sign_zc_equal  == False
      if(bd1_sf_zc_equal.equals("true") && gdv5_sf_zc_equal.equals("true") ) o.put("business_tag_b6","true") else o.put("business_tag_b6","false")

     val business_tag_b1 = JSONUtil.getJsonVal(o,"business_tag_b1","false")
     val business_tag_b2 = JSONUtil.getJsonVal(o,"business_tag_b2","false")
     val business_tag_b3 = JSONUtil.getJsonVal(o,"business_tag_b3","false")
     val business_tag_b4 = JSONUtil.getJsonVal(o,"business_tag_b4","false")
     val business_tag_b5 = JSONUtil.getJsonVal(o,"business_tag_b5","false")
     val business_tag_b6 = JSONUtil.getJsonVal(o,"business_tag_b6","false")


     val business_tag_b = if(business_tag_b1.equals("true") || business_tag_b2.equals("true")|| business_tag_b3.equals("true")|| business_tag_b4.equals("true")|| business_tag_b5.equals("true")|| business_tag_b6.equals("true") )"true" else "false"
     o.put("business_tag_b",business_tag_b)

      //打标业务标识D1:百度1+高德1识别网点一致,且和签收网点不一致 (bd1_gd1_zc_equal == True  and bd1_sign_zc_equal  == False)
      if(bd1_gd1_zc_equal.equals("true") && bd1_sign_zc_equal.equals("false")) o.put("business_tag_d1","true") else o.put("business_tag_d1","false")
      //打标业务标识D2:百度1+高德唯一网点一致,且签收网点不一致 (bd1_gdv5_union_zc_equal== True and  bd1_sign_zc_equal == False )
      if(bd1_union_zc_equal.equals("true") && bd1_sign_zc_equal.equals("false")) o.put("business_tag_d2","true") else o.put("business_tag_d2","false")
      //打标业务标识D3: 高德前两一致，且签收网点不一致  gdv5_front_sign_zc_equal  == False
      if(gdv5_front_sign_zc_equal.equals("false") ) o.put("business_tag_d3","true") else o.put("business_tag_d3","false")
     //打标业务标识D4:高德1和高德v5第一个一致，且签收网点不一致(gd1_gdv5_first_zc_equal == True and gd1_sign_zc_equal  == False )
      if(gd1_gdv5_first_zc_equal.equals("true") && gd1_sign_zc_equal.equals("false") ) o.put("business_tag_d4","true") else o.put("business_tag_d4","false")
      //
      val business_tag_d1 = JSONUtil.getJsonVal(o,"business_tag_d1","")
      val business_tag_d2 = JSONUtil.getJsonVal(o,"business_tag_d2","")
      val business_tag_d3 = JSONUtil.getJsonVal(o,"business_tag_d3","")
      val business_tag_d4 = JSONUtil.getJsonVal(o,"business_tag_d4","")
      if(business_tag_d1.equals("true") || business_tag_d2.equals("true") || business_tag_d3.equals("true") || business_tag_d4.equals("true"))o.put("business_tag_d","true") else o.put("business_tag_d","false")




      //打标业务标识C1:
      //地址错分月频次wrong_num_month>=15，错分占比wrong_top_month<=5%
      val wrong_num_month = try{JSONUtil.getJsonVal(o, "wrong_num_month", "").toDouble}catch { case exception: Exception =>0.0}
      val wrong_top_month = try{JSONUtil.getJsonVal(o, "wrong_top_month", "").toDouble}catch {case exception: Exception =>Double.MaxValue}
      if(wrong_num_month >= 15 && wrong_top_month *100 <= 5) o.put("business_tag_c1","true") else o.put("business_tag_c1","false")
      (sign_address,o)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("初步业务标识打标签的数据量："+preTagRdd.count())
    gdTsRdd.unpersist()
    logger.error("判断落黑名单")
    //地址错分月频次wrong_num_month>=50，错分占比wrong_top_month<=4%，且判断sign_address不存在在shunxin_abn_wrong_adress表中？
   val preAbnRdd =  preTagRdd.leftOuterJoin(abnRdd).map(o=>{
      var abnTag = false
      val right = o._2._2
      val left = o._2._1
      val wrong_num_month = try {JSONUtil.getJsonVal(left, "wrong_num_month", "").toDouble} catch {case exception: Exception => 0.0}
      val wrong_top_month = try {JSONUtil.getJsonVal(left, "wrong_top_month", "").toDouble} catch {case exception: Exception => Double.MaxValue}
     if(right.nonEmpty) left.put("checkAbnTag", right.get)
      if (wrong_num_month >= 50 && wrong_top_month * 100 <= 4 && right.isEmpty) abnTag = true
        left.put("abnTag", abnTag+"")
      (abnTag,left)
    })


    val saveAbnRdd = preAbnRdd.filter(_._1).map(_._2).persist(StorageLevel.MEMORY_ONLY)
    val nextRdd  = preAbnRdd.filter(!_._1).map(_._2).persist(StorageLevel.MEMORY_ONLY)

    logger.error("落入黑名单的数据量："+saveAbnRdd.count())
    logger.error("不落入黑名单的数据量："+nextRdd.count())
    preAbnRdd.unpersist()
    logger.error("继续打标签")
    val finaRdd =  nextRdd.map(o=>{
      //打标业务标识C2:  sign_address关联shunxin_abn_wrong_adress表，是否可关联？
      o.put("business_tag_c2",JSONUtil.getJsonVal(o,"checkAbnTag","false"))
      //business_tag_c = business_tag_c1 == true or business_tag_c2 == true
      val business_tag_c1 = JSONUtil.getJsonVal(o,"business_tag_c1","")
      val business_tag_c2 = JSONUtil.getJsonVal(o,"business_tag_c2","")
      if(business_tag_c1.equals("true") || business_tag_c2.equals("true")) o.put("business_tag_c","true") else o.put("business_tag_c","false")

//      wrong_tag_a
//      //打标错分标识a:非返单+非aoi源+非业务标识+镇冲突且识别不一致
//      is_return==false and area_source_type == false and business_tag_a == false and business_tag_c == false and  business_tag_b6  == false and exist_5  == true and exist_town == true and  exist_1314 == false and
//        exist_911  == false and  combine1_zc is not none and  address_town_equal == false and combine_town_equal  == false and
//        combine1_zc_equal == false and combine_sign_zc_equal  == true or  combine_zc_sign_equal_road  == true
      val is_return = JSONUtil.getJsonVal(o,"is_return","false")
      val area_source_type = JSONUtil.getJsonVal(o,"area_source_type","false")
      val business_tag_a = JSONUtil.getJsonVal(o,"business_tag_a","false")
      val business_tag_c = JSONUtil.getJsonVal(o,"business_tag_c","false")
      val business_tag_d = JSONUtil.getJsonVal(o,"business_tag_d","false")
      val business_tag_b6 = JSONUtil.getJsonVal(o,"business_tag_b6","false")
      val bus_hall = JSONUtil.getJsonVal(o,"bus_hall","false")
      val exist_5 = JSONUtil.getJsonVal(o,"exist_5","false")
      val exist_town = JSONUtil.getJsonVal(o,"exist_town","false")
      val exist_1314 = JSONUtil.getJsonVal(o,"exist_1314","false")
      val exist_911 = JSONUtil.getJsonVal(o,"exist_911","false")
      val combine_zc = JSONUtil.getJsonVal(o,"combine_zc","")
      val address_town_equal = JSONUtil.getJsonVal(o,"address_town_equal","false")
      val combine_town_equal = JSONUtil.getJsonVal(o,"combine_town_equal","false")
      val combine_zc_equal = JSONUtil.getJsonVal(o,"combine_zc_equal","false")
      val combine_zc_sign_equal = JSONUtil.getJsonVal(o,"combine_zc_sign_equal","false")
      val combine_zc_sign_equal_road = JSONUtil.getJsonVal(o,"combine_zc_sign_equal_road","false")

      val bd1_sign_zc_equal = JSONUtil.getJsonVal(o,"bd1_sign_zc_equal","false")
      val gdv5_sign_zc_equal = JSONUtil.getJsonVal(o,"gdv5_sign_zc_equal","false")
      val zc_second_gdv5 = JSONUtil.getJsonVal(o, "zc_second_gdv5", "")
      val gd1_sign_zc_equal = JSONUtil.getJsonVal(o, "gd1_sign_zc_equal", "false")
      val sign_zc = JSONUtil.getJsonVal(o, "sign_zc", "")
      var gdv5_second_sign_zc_equal  = checktf(zc_second_gdv5,sign_zc)
      o.put("gdv5_second_sign_zc_equal",gdv5_second_sign_zc_equal)
      val combine_x_road = JSONUtil.getJsonVal(o,"combine_x_road","")
      val combine_y_road = JSONUtil.getJsonVal(o,"combine_y_road","")
      val combine_x = JSONUtil.getJsonVal(o,"combine_x","")
      val combine_y = JSONUtil.getJsonVal(o,"combine_y","")
      val x_bd1 = JSONUtil.getJsonVal(o,"x_bd1","")
      val y_bd1 = JSONUtil.getJsonVal(o,"y_bd1","")
      val x_gd1 = JSONUtil.getJsonVal(o,"x_gd1","")
      val y_gd1 = JSONUtil.getJsonVal(o,"y_gd1","")
      val x_first_gdv5 = JSONUtil.getJsonVal(o,"x_first_gdv5","")
      val y_first_gdv5 = JSONUtil.getJsonVal(o,"y_first_gdv5","")
      val x_second_gdv5 = JSONUtil.getJsonVal(o,"x_second_gdv5","")
      val y_second_gdv5 = JSONUtil.getJsonVal(o,"y_second_gdv5","")
      val cross_city_order_final = JSONUtil.getJsonVal(o,"cross_city_order_final","")
      val zc_source_type = JSONUtil.getJsonVal(o,"zc_source_type","")
      val no_business_tag_a = JSONUtil.getJsonVal(o,"no_business_tag_a","")
      val address_change = JSONUtil.getJsonVal(o,"address_change","")
      val aoi_cross_zc = JSONUtil.getJsonVal(o,"aoi_cross_zc","")
      val word_18_mix = JSONUtil.getJsonVal(o,"word_18_mix","")
      val end_word = JSONUtil.getJsonVal(o,"end_word","")
      val unreliable_poi3 = JSONUtil.getJsonVal(o,"unreliable_poi3","")




      if(is_return.equals("false") && area_source_type.equals("false") && business_tag_a.equals("false") && business_tag_c.equals("false") && business_tag_b6.equals("false")
      && exist_5.equals("true") && exist_town.equals("true") && exist_1314.equals("false") && exist_911.equals("false") && combine_zc.nonEmpty && address_town_equal.equals("false")
        && combine_town_equal.equals("false") && combine_zc_equal.equals("false") && combine_zc_sign_equal.equals("true") && cross_city_order_final.equals("false") && zc_source_type.equals("false") || combine_zc_sign_equal_road.equals("true")
      )o.put("wrong_tag_a","true")else o.put("wrong_tag_a","false")


      //打标错分标识B:非返单+非AOI源+非业务标识+地址包含营业厅

      if(is_return.equals("false")  && business_tag_a.equals("false")
        && business_tag_c.equals("false") &&  business_tag_b6.equals("false") && cross_city_order_final.equals("false")  && bus_hall.equals("true")
      )o.put("wrong_tag_b","true")else o.put("wrong_tag_b","false")



      val param = new JSONObject()
      param.put("combine_zc_sign_equal",s"${combine_zc_sign_equal}_${combine_x}_${combine_y}")
      param.put("combine_zc_sign_equal_road",s"${combine_zc_sign_equal_road}_${combine_x_road}_${combine_y_road}")
      param.put("bd1_sign_zc_equal",s"${bd1_sign_zc_equal}_${x_bd1}_${y_bd1}")
      param.put("gd1_sign_zc_equal",s"${gd1_sign_zc_equal}_${x_gd1}_${y_gd1}")
      param.put("gdv5_sign_zc_equal",s"${gdv5_sign_zc_equal}_${x_first_gdv5}_${y_second_gdv5}")
      param.put("gdv5_second_sign_zc_equal",s"${gdv5_second_sign_zc_equal}_${x_second_gdv5}_${y_second_gdv5}")




      //if combine_zc_sign_equal  == true and combine_x is not none，
      // then gdss_x = combine_x
      // elif combine_zc_sign_equal_road  == true and combine_x_road is not none
      // then gdss_x = combine_x_road
      // elif  bd1_sign_zc_equal  == true and x_bd1 is not none
      // then gdss_x = x_bd1
      // (gd1_sign_zc_equal  == true、 gdv5_first_sign_zc_equal  == true、gdv5_second_sign_zc_equal  == true 以此类推，获取和签收网点一致的经纬度x_gd1、x_first_gdv5、x_second_gdv5)

      val (gdss_x,gdss_y) = savexy(param)
      o.put("gdss_x",gdss_x)
      o.put("gdss_y",gdss_y)
//是否压顺心审补库？  （wrong_Tag_A == True and sign_zc_diff_num <= 1） OR  （wrong_Tag_B = True and sign_zc_diff_num <= 1 and gdss_x 不为空and gdss_y 不为空）
    val wrong_tag_a =   JSONUtil.getJsonVal(o,"wrong_tag_a","false")
    val wrong_tag_b =   JSONUtil.getJsonVal(o,"wrong_tag_b","false")
    val business_tag_b =   JSONUtil.getJsonVal(o,"business_tag_b","false")
    val sign_zc_diff_num =   try{JSONUtil.getJsonVal(o,"sign_zc_diff_num","").toInt}catch {case exception: Exception=>0.0}
    if( (wrong_tag_a.equals("true")  && sign_zc_diff_num<=1 ) || (wrong_tag_b.equals("true") && sign_zc_diff_num<=1 && gdss_x.nonEmpty && gdss_y.nonEmpty )) o.put("geo_gdss_import","true") else o.put("geo_gdss_import","false")
 //是否存在业务问题？//( Business_Tag_A  == True  or  Business_Tag_B == True  or Business_Tag_C== True or is_return == False) and wrong_Tag_A == False
    if(
      (business_tag_a.equals("true") ||   business_tag_b.equals("true")  ||   business_tag_c.equals("true") ||   business_tag_d.equals("true")  || is_return.equals("true") )
        && wrong_tag_a.equals("false") ) o.put("business_tag","true") else o.put("business_tag","false")
//是否推送给顺心:  存在业务问题的数据  ( Business_Tag_B == True  or Business_Tag_C== True ) and is_return == False and wrong_Tag_A == False
if(( business_tag_b.equals("true")  ||   business_tag_c.equals("true") ) && is_return.equals("false") && wrong_tag_a.equals("false") && no_business_tag_a.equals("false") && address_change.equals("false")) o.put("shunxin_business_push","true") else o.put("shunxin_business_push","false")
      val final_src = JSONUtil.getJsonVal(o,"final_src","")
      val business_tag = JSONUtil.getJsonVal(o,"business_tag","false")
      val unreliable_poi1 = JSONUtil.getJsonVal(o,"unreliable_poi1","false")
      val unreliable_poi2 = JSONUtil.getJsonVal(o,"unreliable_poi2","false")
      val exist_911_not13 = JSONUtil.getJsonVal(o,"exist_911_not13","false")
      val aoi_cross_street = JSONUtil.getJsonVal(o,"aoi_cross_street","false")
//是否推送给补码作业？AOI源+非业务问题+非有613无13+非有9+11无13+13级为仓库等垃圾poi+非aoi跨街道
      //final_src = aoi and  business_tag == false  and unreliable_poi1==false and unreliable_poi2==false and  exist_911_not13=false and
      //aoi_cross_street==false
if(final_src.toUpperCase().equals("AOI")  &&  business_tag.equals("false")
  && unreliable_poi1.equals("false") && unreliable_poi2.equals("false")
  && exist_911_not13.equals("false") && aoi_cross_street.equals("false")
  && aoi_cross_zc.equals("false") && word_18_mix.equals("false") && end_word.equals("false") && unreliable_poi3.equals("false")  ) o.put("aoi_arss_task_puss","true") else o.put("aoi_arss_task_puss","false")
    o
    }).persist(StorageLevel.MEMORY_ONLY)
    logger.error("打完标签的数据："+finaRdd.count())





    val  gdssRdd= finaRdd.filter(o=>JSONUtil.getJsonVal(o,"geo_gdss_import","").equals("true"))
    logger.error("调取gdss压顺心网点的数据量：" + gdssRdd.count())
    val updateRdd = gdssRdd.repartition(20).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        SparkUtils.limitAkUse(startTime, cnt, index, 2000 / 20, logger)
        val waybillNo = JSONUtil.getJsonVal(o, "ewb_no", "")
        val sign_address = JSONUtil.getJsonVal(o, "sign_address", "")
        val sign_zc = JSONUtil.getJsonVal(o, "sign_zc", "")
        if (sign_address.nonEmpty && sign_zc.nonEmpty && waybillNo.nonEmpty) {
          val param = new JSONObject()
          param.put("waybillNo",waybillNo)
          param.put("address", sign_address)
          param.put("rightCode", sign_zc)
          o.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()))
          val dgssReq = HttpClientUtil.doPost(dgssUrl, param, logger)
          o.put("dgssReq", dgssReq)
          val js = try{JSON.parseObject(dgssReq)}catch {case exception: Exception=>new JSONObject()}
          if(js != null){
            val gdss_status = JSONUtil.getJsonVal(js,"code","")
            val gdss_zc =JSONUtil.getJsonVal(js,"data.rightCode","")
            val check_result_code = JSONUtil.getJsonVal(js,"data.checkTag","")
            val check_src = JSONUtil.getJsonVal(js,"data.checkSrc","")
            val shunxin_src = JSONUtil.getJsonVal(js,"data.sxCode","")
            val check_shunxin_src = JSONUtil.getJsonVal(js,"data.sxCodesource","")
            val import_succeed = JSONUtil.getJsonVal(js,"data.flag","")
            val resp_time = JSONUtil.getJsonVal(js,"data.updateDate","")

//            val code = JSONUtil.getJsonVal(js,"code","")
//            val subCode = JSONUtil.getJsonVal(js,"subCode","")
//            val success = JSONUtil.getJsonVal(js,"success","")
//            val message = JSONUtil.getJsonVal(js,"message","")
//            o.put("code",code)
//            o.put("subCode",subCode)
//            o.put("success",success)
//            o.put("message",message)
            val check_result =  if(check_result_code.equals("1")) "正确" else if(check_result_code.equals("2")) "失败（无法判断）" else if(check_result_code.equals("0")) "错误" else ""
            o.put("gdss_status",gdss_status)
            o.put("gdss_zc",gdss_zc)
            o.put("check_result_code",check_result_code)
            o.put("check_src",check_src)
            o.put("shunxin_src",shunxin_src)
            o.put("check_shunxin_src",check_shunxin_src)
            o.put("import_succeed",import_succeed)
            o.put("resp_time",resp_time)
            o.put("check_result",check_result)

          }
        }
        o
      }
    })
    logger.error("调完gdss压顺心网点的数据量：" + updateRdd.count())

    val allFinaRdd = updateRdd.union(finaRdd.filter(o=> ! JSONUtil.getJsonVal(o,"geo_gdss_import","").equals("true")))
    logger.error("汇总完的数据量：" + allFinaRdd.count())
    finaRdd.unpersist()

    val bPushRdd =  allFinaRdd.filter(o=>JSONUtil.getJsonVal(o,"shunxin_business_push","").equals("true")).persist(StorageLevel.MEMORY_ONLY)
    logger.error("推送给顺心:存在业务问题的数据的数据："+bPushRdd.count())

   val allRdd =  allFinaRdd.union(saveAbnRdd).persist(StorageLevel.MEMORY_ONLY)
    logger.error("总的数据："+allRdd.count())

    (saveAbnRdd,bPushRdd,allRdd,updateRdd)
  }

  def runV5inter(spark: SparkSession, runRdd: RDD[JSONObject], tag: String, key: String) = {

    val reNum = runRdd.count().toInt
    val httpInvokeId6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "905229", "顺心错分闭环_ShunxinCuoClosedloop", "顺心错分闭环_ShunxinCuoClosedloop", shunxin_dept_url_v3, "1245f89114fb4f5e896213904b4923a5", reNum, 5)
    val reqRdd = runRdd.repartition(5).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        SparkUtils.limitAkUse(startTime, cnt, index, 5000 / 5, logger)

        val sign_address = JSONUtil.getJsonVal(o, key, "")

        val formatUrl = shunxin_dept_url_v3.format(URLEncoder.encode(sign_address, "utf-8"))
        val req = HttpClientUtil.getJsonByGet(formatUrl)
        if (req != null) o.put(s"${tag}_req", req.toJSONString)
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId6)
    reqRdd
  }

  def checktf(str1: String, str2: String) = {
    var tag = ""
    if(str1.nonEmpty && str2.nonEmpty){
      if ( str1.equals(str2)) tag = "true"  else  tag = "false"
    }
    tag
  }

  def checkTag(spark: SparkSession,splitRdd: RDD[JSONObject],incDay:String) = {
    logger.error("查询最近三个月内签收网点量")
   val qsRdd =  queryqsRdd(spark,incDay)




    logger.error("地址词级判断")
    val preRdd = splitRdd.map(o => {
      val order_source = JSONUtil.getJsonVal(o, "order_source", "")
      val final_town = JSONUtil.getJsonVal(o, "final_town", "")
      val exist_13 = JSONUtil.getJsonVal(o, "exist_13", "")
      val exist_14 = JSONUtil.getJsonVal(o, "exist_14", "")
      val exist_9 = JSONUtil.getJsonVal(o, "exist_9", "")
      val exist_11 = JSONUtil.getJsonVal(o, "exist_11", "")
      val zc_source = JSONUtil.getJsonVal(o, "final_src", "")
      val area_source = JSONUtil.getJsonVal(o, "area_source", "")
      val order_zc = JSONUtil.getJsonVal(o, "order_zc", "")
      val sign_zc = JSONUtil.getJsonVal(o, "sign_zc", "")
      val final_zc = JSONUtil.getJsonVal(o, "final_zc", "")
      if (order_source.nonEmpty && Array("回单一键开单", "新单返货", "原单返货").contains(order_source)) o.put("is_return", "true") else o.put("is_return", "false")
      //是否识别镇
      if (final_town.nonEmpty) o.put("exist_town", "true") else o.put("exist_town", "false")
      //签收地址是否存在13和14级？
      if (exist_13.equals("true") && exist_14.equals("true")) o.put("exist_1314", "true") else o.put("exist_1314", "false")
      //签收地址是否存在9和11级？
      if (exist_9.equals("true") && exist_11.equals("true")) o.put("exist_911", "true") else o.put("exist_911", "false")
      //签收地址是否存在 9+11+13级或9+13+14级？（exist_9 == True and exist_11 == True and exist_13 == True）or （exist_9 == True and exist_13 == True and exist_14 == True）
      if ((exist_9.equals("true") && exist_11.equals("true") && exist_13.equals("true") || (exist_9.equals("true") && exist_14.equals("true") && exist_13.equals("true")))) o.put("exist_9111314", "true") else o.put("exist_9111314", "false")
      //网点识别来源是否为AOI或HIS或KEY？zc_source in (AOI,HIS,KEY)
      if (zc_source.nonEmpty && Array().contains(zc_source)) o.put("zc_source_type", "true") else o.put("zc_source_type", "false")
      //区域识别来源是否为AOI？
      if (area_source.nonEmpty && area_source.toUpperCase().equals("AOI")) o.put("area_source_type", "true") else o.put("area_source_type", "false")
      //提取开单网点order_zc、签收网点sign_zc、最终识别网点final_zc中的数字为order_zc_citycode、sign_zc_citycode、final_zc_citycode
      val order_zc_citycode = order_zc.replaceAll("[^0-9]", "")
      val sign_zc_citycode = sign_zc.replaceAll("[^0-9]", "")
      val final_zc_citycode = final_zc.replaceAll("[^0-9]", "")
      if (!order_zc_citycode.equals(sign_zc_citycode)) o.put("cross_city_order_sign", "true") else o.put("cross_city_order_sign", "false")
      if (!order_zc_citycode.equals(final_zc_citycode)) o.put("cross_city_order_final", "true") else o.put("cross_city_order_final", "false")
      o.put("order_zc_citycode", order_zc_citycode)
      o.put("sign_zc_citycode", sign_zc_citycode)
      o.put("final_zc_citycode", final_zc_citycode)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("地址词级判断完的数据量：" + preRdd.count())
    preRdd.take(2).foreach(o => logger.error(o))
    splitRdd.unpersist()
    logger.error("清洗拼接数据")
    val crealRdd = preRdd.map(o => {
      //清洗final_town为final_town_Clear,清洗掉文本中的（"街道","地区","镇","乡","街","区","科技园"）
      val final_town_clear = JSONUtil.getJsonVal(o, "final_town", "").replaceAll("街道|地区|镇|乡|街|区|科技园", "")

      //combine_address_town（level_word_1+level_word_2+level_word_3+level_word_4+level_word_5+level_word_6）

      val level_word_1 = JSONUtil.getJsonVal(o, "level_word_1", "")
      val level_word_2 = JSONUtil.getJsonVal(o, "level_word_2", "")
      val level_word_3 = JSONUtil.getJsonVal(o, "level_word_3", "")
      val level_word_4 = JSONUtil.getJsonVal(o, "level_word_4", "")
      val level_word_5 = JSONUtil.getJsonVal(o, "level_word_5", "")
      val level_word_6 = JSONUtil.getJsonVal(o, "level_word_6", "")
      val level_word_9 = JSONUtil.getJsonVal(o, "level_word_9", "")
      val combine_address_town = level_word_1 + level_word_2 + level_word_3 + level_word_4 + level_word_5 + level_word_6
      //拼接1-9级文本，获取组合地址combine_address_road（level_word_1+level_word_2+level_word_3+level_word_4+level_word_5+level_word_6+level_word_9）
      val combine_address_road = combine_address_town + level_word_9
      //final_town_Clear是否包含在Level_word_5 中
      if (final_town_clear.nonEmpty && level_word_5.contains(final_town_clear)) o.put("address_town_equal", "true") else o.put("address_town_equal", "false")
      o.put("final_town_clear", final_town_clear)
      o.put("combine_address_town", combine_address_town)
      o.put("combine_address_road", combine_address_road)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("清洗拼接完的数据：" + crealRdd.count())
    preRdd.unpersist()
    val nextRdd1 =  crealRdd.filter(o=>JSONUtil.getJsonVal(o,"exist_town","").equals("true") && JSONUtil.getJsonVal(o,"exist_5","").equals("true")).persist(StorageLevel.MEMORY_ONLY)
    val UnoinRdd1 =  crealRdd.filter(o=> !(JSONUtil.getJsonVal(o,"exist_town","").equals("true") && JSONUtil.getJsonVal(o,"exist_5","").equals("true"))).persist(StorageLevel.MEMORY_ONLY)
    logger.error("存在5级文本和town的数据：" + nextRdd1.count())
    logger.error("不存在5级文本和town数据：" + UnoinRdd1.count())
    crealRdd.unpersist()
   val level5Rdd =  runV5inter(spark,nextRdd1,"level5","combine_address_town").map(o=>{
       val level5_req = JSONUtil.getJsonVal(o,"level5_req","")
      val req = try{JSON.parseObject(level5_req)}catch {case exception: Exception=> null}
      if (req != null) {
      o.put("combine_province",JSONUtil.getJsonVal(req, "result.areaData.province", ""))
      o.put("combine_county",JSONUtil.getJsonVal(req, "result.areaData.county", ""))
      o.put("combine_city",JSONUtil.getJsonVal(req, "result.areaData.city", ""))
      o.put("combine_town",JSONUtil.getJsonVal(req, "result.areaData.town", ""))
      o.put("combine_zc",JSONUtil.getJsonVal(req, "result.sxData.code", ""))
      o.put("combine_x",JSONUtil.getJsonVal(req, "result.sxData.x", ""))
      o.put("combine_y",JSONUtil.getJsonVal(req, "result.sxData.y", ""))
      o.put("combine_area_source",JSONUtil.getJsonVal(req, "result.areaData.areaSource", ""))
      o.put("combine_zc_source",JSONUtil.getJsonVal(req, "result.sxData.codeSource", ""))
    }
    o
    }).union(UnoinRdd1).persist(StorageLevel.MEMORY_ONLY)
    logger.error("combine_address_town调取顺心分单获取网点以及四级地址的数据：" + level5Rdd.count())
    UnoinRdd1.unpersist()
    nextRdd1.unpersist()
    val nextRdd2 = level5Rdd.filter(o => JSONUtil.getJsonVal(o, "exist_town", "").equals("true") && JSONUtil.getJsonVal(o, "exist_9", "").equals("true")).persist(StorageLevel.MEMORY_ONLY)
    val UnoinRdd2 = level5Rdd.filter(o => !(JSONUtil.getJsonVal(o, "exist_town", "").equals("true") && JSONUtil.getJsonVal(o, "exist_9", "").equals("true"))).persist(StorageLevel.MEMORY_ONLY)
    logger.error("存在9级文本和town的数据：" + nextRdd2.count())
    logger.error("不存在9级文本和town数据：" + UnoinRdd2.count())
    level5Rdd.unpersist()
    val level9Rdd = runV5inter(spark, nextRdd2, "level9", "combine_address_road").map(o => {
      val level9_req = JSONUtil.getJsonVal(o, "level9_req", "")
      val req = try {
        JSON.parseObject(level9_req)
      } catch {
        case exception: Exception => null
      }
      if (req != null) {
        o.put("combine_province_road", JSONUtil.getJsonVal(req, "result.areaData.province", ""))
        o.put("combine_county_road", JSONUtil.getJsonVal(req, "result.areaData.county", ""))
        o.put("combine_city_road", JSONUtil.getJsonVal(req, "result.areaData.city", ""))
        o.put("combine_town_road", JSONUtil.getJsonVal(req, "result.areaData.town", ""))
        o.put("combine_zc_road", JSONUtil.getJsonVal(req, "result.areaData.adCode", ""))
        o.put("combine_x_road", JSONUtil.getJsonVal(req, "result.sxData.x", ""))
        o.put("combine_y_road", JSONUtil.getJsonVal(req, "result.sxData.y", ""))
        o.put("combine_area_road_source",JSONUtil.getJsonVal(req, "result.areaData.areaSource", ""))
        o.put("combine_zc_road_source",JSONUtil.getJsonVal(req, "result.sxData.codeSource", ""))

      }
      o
    }).union(UnoinRdd2).persist(StorageLevel.MEMORY_ONLY)
    logger.error("combine_address_road调取顺心分单获取网点以及四级地址的数据：" + level9Rdd.count())
    UnoinRdd2.unpersist()
    nextRdd2.unpersist()
   logger.error("判断是否一致")
   val sameRdd =  level9Rdd.map(o=>{
      val final_town = JSONUtil.getJsonVal(o,"final_town","")
      val combine_town = JSONUtil.getJsonVal(o,"combine_town","")
      val combine_town_road = JSONUtil.getJsonVal(o,"combine_town_road","")
      val combine_zc = JSONUtil.getJsonVal(o,"combine_zc","")
      val final_zc = JSONUtil.getJsonVal(o,"final_zc","")
      val combine_zc_road = JSONUtil.getJsonVal(o,"combine_zc_road","")
      val sign_zc = JSONUtil.getJsonVal(o,"sign_zc","")
      val sign_address = JSONUtil.getJsonVal(o,"sign_address","")
    //1-6组合识别镇和重跑识别镇是否一致？
    o.put("combine_town_equal",checktf(final_town,combine_town))
   //1-9组合识别镇和最终识别镇是否一致？
    o.put("combine_town_equal_road",checktf(final_town,combine_town_road))
  //1-6组合识别网点和最终识别网点是否一致？
    o.put("combine_zc_equal",checktf(combine_zc,final_zc))
   //1-9组合识别网点和最终识别网点是否一致？
   o.put("combine_zc_road_equal",checktf(combine_zc_road,final_zc))
   //1-6组合识别网点和签收网点是否一致？
   o.put("combine_zc_sign_equal",checktf(combine_zc,sign_zc))
  //1-9组合识别网点和签收网点是否一致？
   o.put("combine_zc_sign_equal_road",checktf(combine_zc_road,sign_zc))
  //sign_address签收地址是否包含”营业厅”？ "true"  else  tag = "false"
  if(sign_address.contains("营业厅"))   o.put("bus_hall","true") else o.put("bus_hall","false")
   o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断完一致的数据量:"+sameRdd.count())
    level9Rdd.unpersist()
    logger.error("关联签收数据")
    val finaRdd = sameRdd.map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),o)).leftOuterJoin(qsRdd).map(o=>{
      val left = o._2._1
      val right = o._2._2
      if(right.nonEmpty){
        val js = right.get
        left.put("sign_zc_diff_num",JSONUtil.getJsonVal(js,"sign_zc_diff_num",""))
        left.put("sign_num",JSONUtil.getJsonVal(js,"sign_num",""))
        left.put("sign_waybill_num",JSONUtil.getJsonVal(js,"sign_waybill_num",""))
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("关联完签收的数据量："+finaRdd.count())
    finaRdd
  }


  def querySignData(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val day90 = DateUtil.getDateStr(incDay, -92, "")
    val monthDay = incDay.substring(0, incDay.size - 2) + "15"
    val day15 = if (incDay.substring(incDay.size - 2).toInt > 15) monthDay else DateUtil.getMonthStr(monthDay, -1, "")

    val sql =
      s"""
         |select
         |ewb_no,
         |ewb_created_time as order_time,
         |modify_time,
         |sign_created_time as sign_time,
         |last_gis_sn,
         |ewb_dispatch_site as order_zc,
         |gis_identify_site_address as order_address,
         |gis_identify_site_code as order_gis_zc,
         |ewb_sign_address as sign_address,
         |ewb_sign_site_code as sign_zc,
         |sign_province_name as sign_province,
         |sign_city_name as sign_city,
         |sign_county_name as sign_county,
         |sign_town_name as sign_town,
         |codenew as final_zc,
         |chnamenew as final_zc_name,
         |codesourcenew as final_src,
         |provincenew as final_province,
         |citynew as final_city,
         |countynew as final_county,
         |townnew as final_town,
         |citycodenew as final_citycode,
         |areasourcenew as area_source,
         |uid as final_aoiid,
         |tag as report_tag,
         |optional_site_flag,
         |return_waybill_no as return_ewb_no,
         |b.order_source,
         |sign_flag_name,
         |aoi_tag,
         |aoi_geotype,
         |d.aoi_cross_zc_num,
         |d.aoi_cross_zc_area,
         |d.aoi_area,
         |cast(d.aoi_cross_zc_area as double)/cast(d.aoi_area as double) as aoi_cross_zc_area_ratio
         |from
         |(
         |select
         |*,
         |case
         |when matching_map_type = '1' then '丰图'
         |when matching_map_type = '2' then '高德'
         |when matching_map_type = '3' then '百度'
         |when matching_map_type = '4' then '腾讯'
         |when matching_map_type = '5' then '高德POI'
         |else matching_map_type
         |end as matching_map_type_name,
         |case
         |when special_ewb = '1' then '外发'
         |when special_ewb = '2' then '整车运单'
         |when special_ewb = '3' then '家装大件'
         |when special_ewb = '4' then '批量改单'
         |when special_ewb = '5' then 'D网'
         |when special_ewb = '6' then '空运运单'
         |when special_ewb = '7' then '跨境件'
         |else special_ewb
         |end as special_ewb_name
         |from
         |dm_gis.shunxin_detail_di_jx_new
         |where
         |inc_day = '${incDay}'
         |and tag = 'wrong'
         |) a
         |left join (
         |select
         |waybill_no,
         |case
         |when rd_status = '0' then '删除'
         |when rd_status = '1' then '正常'
         |else rd_status
         |end as rd_status,
         |consigned_time,
         |sign_time,
         |optional_site_flag,
         |case
         |when waybill_flag = '0' then '加盟 '
         |when waybill_flag = '1' then '直营'
         |else waybill_flag
         |end as waybill_flag,
         |special_address_service_type_name,
         |return_waybill_no,
         |case
         |when delay_send_flag = '0' then '否 '
         |when delay_send_flag = '1' then '是'
         |else delay_send_flag
         |end as delay_send_flag,
         |case
         |when batch_update_flag = '1' then '批量改单'
         |else batch_update_flag
         |end as batch_update_flag,
         |case
         |when data_source = 'oneKey' then '回单一键开单'
         |when data_source = 'returnOpenWaybill' then '新单返货'
         |when data_source = 'originalWaybillReturn' then '原单返货'
         |when (return_waybill_no <> '' and return_waybill_no <> 'null') then '新单返货'
         |when special_address_service_type_name = '特殊派送（禁行区）' then '禁行区'
         |when data_source = 'openWaybill' then '普通开单'
         |when data_source = 'copyOpenWaybill' then '复制开单'
         |when data_source = 'ediOpenWaybill' then 'EDI开单'
         |when data_source = 'orderTransferWaybill' then '订单转运单'
         |else data_source
         |end as order_source,
         |case
         |when sign_flag = '0' then '未签收'
         |when sign_flag = '1' then '已签收'
         |when sign_flag = '2' then '正常签收'
         |when sign_flag = '3' then '异常签收'
         |else sign_flag
         |end as sign_flag_name,
         |row_number() over(partition by waybill_no order by modify_time desc) as rn
         |from
         |ky.ods_sx_abws_waybill.wb_waybill1
         |where
         |inc_day between '${day90}'
         |and '${incDay}'
         |and rd_status <> '0'
         |and (data_source in ('oneKey','originalWaybillReturn','returnOpenWaybill')
         |or (return_waybill_no <> '' and return_waybill_no <> 'null'))
         |) b on a.ewb_no = b.waybill_no
         |left join (
         |select
         |aoi_id,
         |tag as aoi_tag,
         |geotype as aoi_geotype
         |from
         |dm_gis.optimize_aoi_xz_area_divide_data
         |where
         |inc_day = '${day15}'
         |and aoi_id <> ''
         |group by
         |aoi_id,
         |tag,
         |geotype
         |) c on c.aoi_id = a.uid
         |left join (
         |select
         |aoi_id
         |,aoi_area
         |,if(tc1 <>'',1,0)+if(tc2 <>'',1,0)+if(tc3 <>'',1,0)+if(tc4 <>'',1,0)+if(tc5 <>'',1,0) as aoi_cross_zc_num
         |,greatest(nvl(cast(tc1_area as double),0),nvl(cast(tc2_area as double),0),nvl(cast(tc3_area as double),0),nvl(cast(tc4_area as double),0),nvl(cast(tc5_area as double),0)) as aoi_cross_zc_area
         |from dm_gis.dm_sx_aoi_ints_report_dtl_df where inc_day = '${incDay}'
         |)d
         |on a.uid = d.aoi_id
        |""".stripMargin


    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sql_partition)
    val reNum = dataRdd.count().toInt
    logger.error("顺心签收单号总数量：" + reNum)
    logger.error("调分词接口")


    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "905229", "顺心错分闭环_ShunxinCuoClosedloop", "顺心错分闭环_ShunxinCuoClosedloop", splitUrl, "3bf251b77ec9e398c1d0cb25bdb78977", reNum, 5)

    val splitRdd = dataRdd.repartition(5).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val sign_address = JSONUtil.getJsonVal(o, "sign_address", "")
        val final_citycode = JSONUtil.getJsonVal(o, "final_citycode", "")
        var split_result = ""
        //判断是否split_result存在3/4/5/6/9/10/11/13/613/14，分别落表字段 exist_3/exist_4/exist_5/exist_6/exist_9/exist_10/exist_11/exist_13/exist_613/exist_14
        val map2: util.HashMap[String, String] = new util.HashMap[String, String]()
        //获取1/2/3/4/5/6/9/11/13/613/14级对应文本，如果存在两个及以上的同词级文本，去重后逗号分隔记录
        val map: util.HashMap[String, util.HashSet[String]] = new util.HashMap[String, util.HashSet[String]]()

        if (sign_address.nonEmpty && final_citycode.nonEmpty) {
          SparkUtils.limitAkUse(startTime, cnt, index, 2000 / 5, logger)
          val splitReq = String.format(splitUrl, URLEncoder.encode(sign_address), final_citycode)
          val splitResp = Utils.retryGet(splitReq)
          val splitArr = try {
            JSON.parseObject(splitResp).getJSONObject("result").getJSONObject("data").getJSONArray("info")
          } catch {
            case _ => null
          }
          //拼接split result
          if (splitArr != null && splitArr.size() > 0) {
            for (i <- Range(0, splitArr.size())) {
              val json = splitArr.getJSONObject(i)
              val prop = json.getString("prop")
              val level = json.getString("level")
              val name = json.getString("name")

              val key = if (level.equals("13") && prop.equals("6")) prop + level else level
              val set = map.getOrDefault(key, new util.HashSet[String])
              set.add(name)
              map2.put(key, "true")
              map.put(key, set)

              split_result += name + "^" + prop + level
              if (i == splitArr.size() - 1)
                split_result += ";" + prop + level
              else
                split_result += "|"
            }
          }

        }
        //3/4/5/6/9/10/11/13/613/14
        o.put("exist_3", map2.getOrDefault("3", "false"))
        o.put("exist_4", map2.getOrDefault("4", "false"))
        o.put("exist_5", map2.getOrDefault("5", "false"))
        o.put("exist_6", map2.getOrDefault("6", "false"))
        o.put("exist_9", map2.getOrDefault("9", "false"))
        o.put("exist_10", map2.getOrDefault("10", "false"))
        o.put("exist_11", map2.getOrDefault("11", "false"))
        o.put("exist_13", map2.getOrDefault("13", "false"))
        o.put("exist_613", map2.getOrDefault("613", "false"))
        o.put("exist_14", map2.getOrDefault("14", "false"))
        o.put("exist_18", map2.getOrDefault("18", "false"))

        o.put("level_word_1", map.getOrDefault("1", new util.HashSet[String]).mkString(","))
        o.put("level_word_2", map.getOrDefault("2", new util.HashSet[String]).mkString(","))
        o.put("level_word_3", map.getOrDefault("3", new util.HashSet[String]).mkString(","))
        o.put("level_word_4", map.getOrDefault("4", new util.HashSet[String]).mkString(","))
        o.put("level_word_5", map.getOrDefault("5", new util.HashSet[String]).mkString(","))
        o.put("level_word_6", map.getOrDefault("6", new util.HashSet[String]).mkString(","))
        o.put("level_word_9", map.getOrDefault("9", new util.HashSet[String]).mkString(","))
        o.put("level_word_10", map.getOrDefault("10", new util.HashSet[String]).mkString(","))
        o.put("level_word_11", map.getOrDefault("11", new util.HashSet[String]).mkString(","))
        o.put("level_word_13", map.getOrDefault("13", new util.HashSet[String]).mkString(","))
        o.put("level_word_613", map.getOrDefault("613", new util.HashSet[String]).mkString(","))
        o.put("level_word_14", map.getOrDefault("14", new util.HashSet[String]).mkString(","))
        o.put("level_word_18", map.getOrDefault("18", new util.HashSet[String]).mkString(","))

        o.put("split_result", split_result)
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完分词的数量：" + splitRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)

    splitRdd.take(3).foreach(o => logger.error(o))

    dataRdd.unpersist()
    splitRdd
  }



  def saveTable(spark: SparkSession, saveAbnRdd: RDD[JSONObject], bPushRdd: RDD[JSONObject], allRdd: RDD[JSONObject], gdssRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = allRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(abn_wrong_detail_table)

    val AbnRdd= saveAbnRdd.map(o=>(JSONUtil.getJsonVal(o,"sign_address",""),o)).reduceByKey((o1,o2)=>{
      o1
      })

    val reDf =  AbnRdd.map(js => {
      val o = js._2
       val mat = DateTimeFormatter.ofPattern("yyyyMMdd")
      AbnRe(
         JSONUtil.getJsonVal(o,"sign_address","")
        ,JSONUtil.getJsonVal(o,"wrong_num_month","")
        ,JSONUtil.getJsonVal(o,"wrong_ewb_num_month","")
        ,JSONUtil.getJsonVal(o,"desc_add_wrong_month","")
        ,JSONUtil.getJsonVal(o,"total_month","")
        ,JSONUtil.getJsonVal(o,"wrong_top_month","")
        ,mat.format(LocalDateTime.now)
      )
    }).toDF()

    //汇总表入库
    logger.error("入异常高频地址黑名单表数量：" + reDf.count())
    reDf.show(2,false)
    reDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(abn_wrong_table)

    val pushDf = bPushRdd.map(o => {
      PushRe(
         JSONUtil.getJsonVal(o,"ewb_no","")
        ,JSONUtil.getJsonVal(o,"order_time","")
        ,JSONUtil.getJsonVal(o,"sign_time","")
        ,JSONUtil.getJsonVal(o,"last_gis_sn","")
        ,JSONUtil.getJsonVal(o,"order_zc","")
        ,JSONUtil.getJsonVal(o,"sign_address","")
        ,JSONUtil.getJsonVal(o,"sign_zc","")
        ,JSONUtil.getJsonVal(o,"final_zc","")
        ,JSONUtil.getJsonVal(o,"final_zc_name","")
        ,JSONUtil.getJsonVal(o,"final_src","")
        ,JSONUtil.getJsonVal(o,"final_province","")
        ,JSONUtil.getJsonVal(o,"final_city","")
        ,JSONUtil.getJsonVal(o,"final_county","")
        ,JSONUtil.getJsonVal(o,"final_town","")
        ,JSONUtil.getJsonVal(o,"final_citycode","")
        ,JSONUtil.getJsonVal(o,"area_source","")
        ,JSONUtil.getJsonVal(o,"final_aoiid","")
        ,JSONUtil.getJsonVal(o,"aoi_geotype","")
        ,JSONUtil.getJsonVal(o,"business_tag_b1","")
        ,JSONUtil.getJsonVal(o,"business_tag_b2","")
        ,JSONUtil.getJsonVal(o,"business_tag_b3","")
        ,JSONUtil.getJsonVal(o,"business_tag_b4","")
        ,JSONUtil.getJsonVal(o,"business_tag_b5","")
        ,JSONUtil.getJsonVal(o,"business_tag_b6","")
        ,JSONUtil.getJsonVal(o,"business_tag_b","")
        ,JSONUtil.getJsonVal(o,"business_tag_c1","")
        ,JSONUtil.getJsonVal(o,"business_tag_c2","")
        ,JSONUtil.getJsonVal(o,"shunxin_business_push","")
      )
    }).toDF()
    //汇总表入库
    logger.error("入存在业务问题的数据表数量：" + pushDf.count())
    pushDf.show(2,false)
    pushDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(push_table)


    val finaDf = allRdd.map(o => {
      ClReq(
          JSONUtil.getJsonVal(o,"ewb_no","")
         ,JSONUtil.getJsonVal(o,"order_time","")
         ,JSONUtil.getJsonVal(o,"modify_time","")
         ,JSONUtil.getJsonVal(o,"sign_time","")
         ,JSONUtil.getJsonVal(o,"last_gis_sn","")
         ,JSONUtil.getJsonVal(o,"order_zc","")
         ,JSONUtil.getJsonVal(o,"order_address","")
         ,JSONUtil.getJsonVal(o,"order_gis_zc","")
         ,JSONUtil.getJsonVal(o,"sign_address","")
         ,JSONUtil.getJsonVal(o,"sign_zc","")
         ,JSONUtil.getJsonVal(o,"sign_province","")
         ,JSONUtil.getJsonVal(o,"sign_city","")
         ,JSONUtil.getJsonVal(o,"sign_county","")
         ,JSONUtil.getJsonVal(o,"sign_town","")
         ,JSONUtil.getJsonVal(o,"final_zc","")
         ,JSONUtil.getJsonVal(o,"final_zc_name","")
         ,JSONUtil.getJsonVal(o,"final_src","")
         ,JSONUtil.getJsonVal(o,"final_province","")
         ,JSONUtil.getJsonVal(o,"final_city","")
         ,JSONUtil.getJsonVal(o,"final_county","")
         ,JSONUtil.getJsonVal(o,"final_town","")
         ,JSONUtil.getJsonVal(o,"final_citycode","")
         ,JSONUtil.getJsonVal(o,"area_source","")
         ,JSONUtil.getJsonVal(o,"final_aoiid","")
         ,JSONUtil.getJsonVal(o,"report_tag","")
         ,JSONUtil.getJsonVal(o,"optional_site_flag","")
         ,JSONUtil.getJsonVal(o,"return_ewb_no","")
         ,JSONUtil.getJsonVal(o,"order_source","")
         ,JSONUtil.getJsonVal(o,"sign_flag_name","")
         ,JSONUtil.getJsonVal(o,"aoi_tag","")
         ,JSONUtil.getJsonVal(o,"aoi_geotype","")
         ,JSONUtil.getJsonVal(o,"split_result","")
         ,JSONUtil.getJsonVal(o,"exist_3","")
         ,JSONUtil.getJsonVal(o,"exist_4","")
         ,JSONUtil.getJsonVal(o,"exist_5","")
         ,JSONUtil.getJsonVal(o,"exist_6","")
         ,JSONUtil.getJsonVal(o,"exist_9","")
         ,JSONUtil.getJsonVal(o,"exist_10","")
         ,JSONUtil.getJsonVal(o,"exist_11","")
         ,JSONUtil.getJsonVal(o,"exist_13","")
         ,JSONUtil.getJsonVal(o,"exist_613","")
         ,JSONUtil.getJsonVal(o,"exist_14","")
         ,JSONUtil.getJsonVal(o,"level_word_1","")
         ,JSONUtil.getJsonVal(o,"level_word_2","")
         ,JSONUtil.getJsonVal(o,"level_word_3","")
         ,JSONUtil.getJsonVal(o,"level_word_4","")
         ,JSONUtil.getJsonVal(o,"level_word_5","")
         ,JSONUtil.getJsonVal(o,"level_word_6","")
         ,JSONUtil.getJsonVal(o,"level_word_9","")
         ,JSONUtil.getJsonVal(o,"level_word_10","")
         ,JSONUtil.getJsonVal(o,"level_word_11","")
         ,JSONUtil.getJsonVal(o,"level_word_13","")
         ,JSONUtil.getJsonVal(o,"level_word_613","")
         ,JSONUtil.getJsonVal(o,"level_word_14","")
         ,JSONUtil.getJsonVal(o,"is_return","")
         ,JSONUtil.getJsonVal(o,"exist_town","")
         ,JSONUtil.getJsonVal(o,"exist_1314","")
         ,JSONUtil.getJsonVal(o,"exist_9111314","")
         ,JSONUtil.getJsonVal(o,"zc_source_type","")
         ,JSONUtil.getJsonVal(o,"area_source_type","")
         ,JSONUtil.getJsonVal(o,"order_zc_citycode","")
         ,JSONUtil.getJsonVal(o,"sign_zc_citycode","")
         ,JSONUtil.getJsonVal(o,"final_zc_citycode","")
         ,JSONUtil.getJsonVal(o,"cross_city_order_sign","")
         ,JSONUtil.getJsonVal(o,"cross_city_order_final","")
         ,JSONUtil.getJsonVal(o,"final_town_clear","")
         ,JSONUtil.getJsonVal(o,"combine_address_town","")
         ,JSONUtil.getJsonVal(o,"combine_address_road","")
         ,JSONUtil.getJsonVal(o,"address_town_equal","")
         ,JSONUtil.getJsonVal(o,"combine_zc_source","")
         ,JSONUtil.getJsonVal(o,"combine_area_source","")
         ,JSONUtil.getJsonVal(o,"combine_x","")
         ,JSONUtil.getJsonVal(o,"combine_y","")
         ,JSONUtil.getJsonVal(o,"combine_zc","")
         ,JSONUtil.getJsonVal(o,"combine_province","")
         ,JSONUtil.getJsonVal(o,"combine_city","")
         ,JSONUtil.getJsonVal(o,"combine_county","")
         ,JSONUtil.getJsonVal(o,"combine_town","")
         ,JSONUtil.getJsonVal(o,"combine_zc_road_source","")
         ,JSONUtil.getJsonVal(o,"combine_area_road_source","")
         ,JSONUtil.getJsonVal(o,"combine_x_road","")
         ,JSONUtil.getJsonVal(o,"combine_y_road","")
         ,JSONUtil.getJsonVal(o,"combine_zc_road","")
         ,JSONUtil.getJsonVal(o,"combine_province_road","")
         ,JSONUtil.getJsonVal(o,"combine_city_road","")
         ,JSONUtil.getJsonVal(o,"combine_county_road","")
         ,JSONUtil.getJsonVal(o,"combine_town_road","")
         ,JSONUtil.getJsonVal(o,"combine_town_equal","")
         ,JSONUtil.getJsonVal(o,"combine_town_equal_road","")
         ,JSONUtil.getJsonVal(o,"combine_zc_equal","")
         ,JSONUtil.getJsonVal(o,"combine_zc_road_equal","")
         ,JSONUtil.getJsonVal(o,"combine_zc_sign_equal","")
         ,JSONUtil.getJsonVal(o,"combine_zc_sign_equal_road","")
         ,JSONUtil.getJsonVal(o,"sign_zc_diff_num","")
         ,JSONUtil.getJsonVal(o,"sign_num","")
         ,JSONUtil.getJsonVal(o,"sign_waybill_num","")
         ,JSONUtil.getJsonVal(o,"wrong_num_month","")
         ,JSONUtil.getJsonVal(o,"wrong_ewb_num_month","")
         ,JSONUtil.getJsonVal(o,"desc_add_wrong_month","")
         ,JSONUtil.getJsonVal(o,"total_month","")
         ,JSONUtil.getJsonVal(o,"wrong_top_month","")
         ,JSONUtil.getJsonVal(o,"x_first_gdv5","")
         ,JSONUtil.getJsonVal(o,"y_first_gdv5","")
         ,JSONUtil.getJsonVal(o,"x_second_gdv5","")
         ,JSONUtil.getJsonVal(o,"y_second_gdv5","")
         ,JSONUtil.getJsonVal(o,"x_bd1","")
         ,JSONUtil.getJsonVal(o,"y_bd1","")
         ,JSONUtil.getJsonVal(o,"x_gd1","")
         ,JSONUtil.getJsonVal(o,"y_gd1","")
         ,JSONUtil.getJsonVal(o,"zc_bd1","")
         ,JSONUtil.getJsonVal(o,"zc_gd1","")
         ,JSONUtil.getJsonVal(o,"zc_first_gdv5","")
         ,JSONUtil.getJsonVal(o,"zc_second_gdv5","")
         ,JSONUtil.getJsonVal(o,"bd1_sign_zc_equal","")
         ,JSONUtil.getJsonVal(o,"bd1_sf_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gd1_sign_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gd1_sf_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gdv5_sign_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gdv5_sf_zc_equal","")
         ,JSONUtil.getJsonVal(o,"zc_front_gdv5","")
         ,JSONUtil.getJsonVal(o,"zc_union_gdv5","")
         ,JSONUtil.getJsonVal(o,"gdv5_front_sign_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gdv5_front_sf_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gdv5_union_sign_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gdv5_union_sf_zc_equal","")
         ,JSONUtil.getJsonVal(o,"bd1_gd1_zc_equal","")
         ,JSONUtil.getJsonVal(o,"bd1_gdv5_first_zc_equal","")
         ,JSONUtil.getJsonVal(o,"bd1_union_zc_equal","")
         ,JSONUtil.getJsonVal(o,"bd1_front_zc_equal","")
         ,JSONUtil.getJsonVal(o,"gd1_gdv5_first_zc_equal","")
         ,JSONUtil.getJsonVal(o,"sf_map_inequal_num","")
         ,JSONUtil.getJsonVal(o,"sign_map_inequal_num","")
         ,JSONUtil.getJsonVal(o,"sf_sign_map_diff_num","")
         ,JSONUtil.getJsonVal(o,"sf_inequal_num","")
         ,JSONUtil.getJsonVal(o,"sign_inequal_num","")
         ,JSONUtil.getJsonVal(o,"sf_sign_diff_num","")
         ,JSONUtil.getJsonVal(o,"unreliable_poi1","")
         ,JSONUtil.getJsonVal(o,"unreliable_poi2","")
         ,JSONUtil.getJsonVal(o,"aoi_cross_street","")
         ,JSONUtil.getJsonVal(o,"exist_911_not13","")
         ,JSONUtil.getJsonVal(o,"business_tag_a","")
         ,JSONUtil.getJsonVal(o,"business_tag_b1","")
         ,JSONUtil.getJsonVal(o,"business_tag_b2","")
         ,JSONUtil.getJsonVal(o,"business_tag_b3","")
         ,JSONUtil.getJsonVal(o,"business_tag_b4","")
         ,JSONUtil.getJsonVal(o,"business_tag_b5","")
         ,JSONUtil.getJsonVal(o,"business_tag_b6","")
         ,JSONUtil.getJsonVal(o,"business_tag_b","")
         ,JSONUtil.getJsonVal(o,"business_tag_c1","")
         ,JSONUtil.getJsonVal(o,"business_tag_c2","")
         ,JSONUtil.getJsonVal(o,"wrong_tag_a","")
         ,JSONUtil.getJsonVal(o,"gdss_x","")
         ,JSONUtil.getJsonVal(o,"gdss_y","")
         ,JSONUtil.getJsonVal(o,"geo_gdss_import","")
         ,JSONUtil.getJsonVal(o,"business_tag","")
         ,JSONUtil.getJsonVal(o,"shunxin_business_push","")
         ,JSONUtil.getJsonVal(o,"aoi_arss_task_puss","")
         ,JSONUtil.getJsonVal(o,"business_tag_c","")
         ,JSONUtil.getJsonVal(o,"exist_911","")
         ,JSONUtil.getJsonVal(o,"aoi_cross_zc","")
         ,JSONUtil.getJsonVal(o,"aoi_cross_zc_num","")
         ,JSONUtil.getJsonVal(o,"aoi_cross_zc_area","")
         ,JSONUtil.getJsonVal(o,"address_change","")
         ,JSONUtil.getJsonVal(o,"no_business_tag_a","")
         ,JSONUtil.getJsonVal(o,"business_tag_d1","")
         ,JSONUtil.getJsonVal(o,"business_tag_d2","")
         ,JSONUtil.getJsonVal(o,"business_tag_d3","")
         ,JSONUtil.getJsonVal(o,"business_tag_d4","")
         ,JSONUtil.getJsonVal(o,"business_tag_d","")
         ,JSONUtil.getJsonVal(o,"level_word_18","")
         ,JSONUtil.getJsonVal(o,"word_18_mix","")
         ,JSONUtil.getJsonVal(o,"end_word","")
         ,JSONUtil.getJsonVal(o,"unreliable_poi3","")
         ,JSONUtil.getJsonVal(o,"aoi_cross_zc_area_ratio","")
         ,JSONUtil.getJsonVal(o,"bus_hall","")
         ,JSONUtil.getJsonVal(o,"wrong_tag_b","")
      )
    }).toDF()
    //汇总表入库
    logger.error("入最终表数量：" + finaDf.count())
    finaDf.show(2,false)
    finaDf.coalesce(100).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(close_loop_table)


    //压顺心审补结果入表
    val saveGdssDf= gdssRdd.map(o => {
      gdss(
          JSONUtil.getJsonVal(o, "ewb_no", "")
        , JSONUtil.getJsonVal(o, "sign_address", "")
        , JSONUtil.getJsonVal(o, "final_citycode", "")
        , JSONUtil.getJsonVal(o, "sign_zc", "")
        , JSONUtil.getJsonVal(o, "combine_address_town", "")
        , JSONUtil.getJsonVal(o, "combine_address_road", "")
        , JSONUtil.getJsonVal(o, "address_town_equal", "")
        , JSONUtil.getJsonVal(o, "combine_zc", "")
        , JSONUtil.getJsonVal(o, "combine_town", "")
        , JSONUtil.getJsonVal(o, "combine_town_road", "")
        , JSONUtil.getJsonVal(o, "combine_town_equal", "")
        , JSONUtil.getJsonVal(o, "combine_zc_equal", "")
        , JSONUtil.getJsonVal(o, "combine_zc_sign_equal", "")
        , JSONUtil.getJsonVal(o, "combine_zc_sign_equal_road", "")
        , JSONUtil.getJsonVal(o, "wrong_tag_a", "")
        , JSONUtil.getJsonVal(o, "gdss_x", "")
        , JSONUtil.getJsonVal(o, "gdss_y", "")
        , JSONUtil.getJsonVal(o, "geo_gdss_import", "")
        , JSONUtil.getJsonVal(o, "gdss_status", "")
        , JSONUtil.getJsonVal(o, "gdss_zc", "")
        , JSONUtil.getJsonVal(o, "check_result_code", "")
        , JSONUtil.getJsonVal(o, "check_result", "")
        , JSONUtil.getJsonVal(o, "check_src", "")
        , JSONUtil.getJsonVal(o, "shunxin_src", "")
        , JSONUtil.getJsonVal(o, "check_shunxin_src", "")
        , JSONUtil.getJsonVal(o, "import_succeed", "")
        , JSONUtil.getJsonVal(o, "resp_time", "")
//        , JSONUtil.getJsonVal(o, "code", "")
//        , JSONUtil.getJsonVal(o, "subCode", "")
//        , JSONUtil.getJsonVal(o, "success", "")
//        , JSONUtil.getJsonVal(o, "message", "")
//        , JSONUtil.getJsonVal(o, "time", "")
      )
    }).toDF()
    //汇总表入库
    logger.error("顺心审补结果入表数量：" + saveGdssDf.count())
    saveGdssDf.show(2, false)
    saveGdssDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(shunxin_geo_gdss_adress_import)

    logger.error("完成")

  }





  def startSta(incDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("获取顺心收派签收数据")
    val splitRdd = querySignData(spark, incDay)
    logger.error("错分标识工艺")
    val cfRdd = checkTag(spark,splitRdd,incDay)
    logger.error("业务标识工艺")
    val (saveAbnRdd,bPushRdd,allRdd,gdssRdd) = checkyw(spark,cfRdd,incDay)
    saveTable(spark,saveAbnRdd,bPushRdd,allRdd,gdssRdd,incDay)
    logger.error("处理结束")
  }

//  def start(startDay: String, days: Int, fromDay: String): Unit = {
//    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//    //    fromDay:跑数时间 yyyy-mm-dd
//    //    for (i <- 0 until days) {
//    val incDay = DateUtil.getDateStr(startDay, 0, "") //-7 yyyy-mm-dd
//    logger.error(s"开始计算：incDay:${incDay}")
//    startSta(spark, incDay)
//    logger.error("计算结束：" + incDay)
//    //    }
//    logger.error("统计完毕")
//  }

  def getJsonByGet(url: String): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = new JSONObject()
    try {
      var httpResponse: CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpGet.addHeader("ak", "8cb19f422db34736922479ba0bc848f4")
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity: HttpEntity = httpResponse.getEntity

        try {
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e: Exception =>
              jsonObj.put("Exception1", e)
              logger.error(">>>结果转换json独享异常：" + e)
          }
        }
        catch {
          case e: Exception =>
            jsonObj.put("Exception2", e)
            logger.error(">>>获取stringEntity异常：" + e)
        }
      }
      httpResponse.close()
    } catch {
      case e: Exception =>
        jsonObj.put("Exception3", e)
        logger.error(">>>获取httpResponse异常：" + e)
    }
    httpClient.close()
    jsonObj
  }


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val inc_day = DateUtil.getDateStr(startDay, -1, "")
    logger.error("起始时间:" + inc_day)
    startSta(inc_day)
    logger.error("结束所有运行")
  }



}
