package com.sf.gis.scala.sx.shunxin

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.java.sx.constant.util.FileUtil
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.sx.util.{DateUtil, JSONUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util.Calendar

/**
  * Created by 01412406
  *  01427169 邓蔼娟
  * 任务id：391395
  */
object ShunxinNew {

  @transient lazy val logger: Logger = Logger.getLogger(ShunxinNew.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.3
  println(version)
  val file_prop = FileUtil.getFileProperties("conf/shunxin_sta.properties")
  val seg_url = file_prop.getProperty("seg_url")
  val seg_partition = file_prop.getProperty("seg_partition").toInt
  val seg_ak_limit = (file_prop.getProperty("seg_ak_limit").toInt * 0.95) / seg_partition
  val common_partition = file_prop.getProperty("common_partition").toInt
  val mapa_url = file_prop.getProperty("mapa_url")
  val ts_url = file_prop.getProperty("ts_url")

  val sj_url = file_prop.getProperty("sj_url")
  val xy_dept_url = file_prop.getProperty("xy_dept_url")
  val shunxin_dept_url_v2 = file_prop.getProperty("shunxin_dept_url_v2")
  val shunxin_dept_url_v3 = file_prop.getProperty("shunxin_dept_url_v4")
  println(shunxin_dept_url_v3)
  val check_sx_dept_url = file_prop.getProperty("check_sx_dept_url")
  val split_url = file_prop.getProperty("split_url")
  val mapb_url = file_prop.getProperty("mapb_url")
  val bd_url = file_prop.getProperty("bd_url")
  val tx_url = file_prop.getProperty("tx_url")
  val signFormat = "code_eff_sign,banner_sign,extend_attrs_sign"
  val gisFormat = "code_eff_gis,banner_gis,extend_attrs_gis"

  val sql_partition = 2000

  val GL_LEVEL = "GL_VILLAGE,GL_ROAD_BRANCH,GL_ROADINTER,GL_POI,GL_STREETNO,GL_STREETNO_SUB,GL_BUILDINGNO,GL_BUILDING_UNIT,GL_INTER,GL_NEARBY"


  case class ShunxinCover(
                           cityCode: String
                           , city: String
                           , validCnt: Int
                           , gdsscnt: Int
                           , aoicnt: Int
                           , geowithouttscnt: Int
                           , geowithouttsgjcnt: Int
                           , geowithouttsdjcnt: Int
                           , tscnt: Int
                           , sxsecond: Int
                           , sxsecond_false: Int
                           , sxrejectcnt: Int
                           , sxrejectcnt_gdss: Int
                           , sxrejectcnt_aoi: Int
                           , sxrejectcnt_geo: Int
                           , sxrejectcnt_geo_high: Int
                           , sxrejectcnt_geo_low: Int
                           , sxrejectcnt_ts: Int
                           , finalwdcnt: Int
                           , finalwdgdsscnt: Int
                           , finalwdaoicnt: Int
                           , finalwdgeocnt: Int
                           , finalwdgeogjcnt: Int
                           , finalwdgeodjcnt: Int
                           , finalwdtscnt: Int
                           , artificiaChooseSit: Int
                           , signAddressKeyWordNumber: Int
                           , signTownKeyWord: Int
                           , signCodeKeyWord: Int
                           , specialEwbZc: Int
                           , blindSpot: Int
                           , splitLevelLess: Int
                           , townWrong: Int
                           , countyWrong: Int
                           , cityWrong: Int
                           , signCodeClose: Int
                           , gisCodeClose: Int
                           , signCodeInvalid: Int
                           , gisCodeInvalid: Int
                         )



  case class mult(
                     cityCode: String
                   , city: String
                   , validcnt: Int
                   , gdsscnt: Int
                   , aoicnt: Int
                   , mapa_model_mapbcnt: Int
                   , mapa_model_gdcnt: Int
                   , mapa_model_bdcnt: Int
                   , mapa_mapb_gdcnt: Int
                   , mapa_mapb_bdcnt: Int
                   , mapa_gd_bdcnt: Int
                   , mapa_modelcnt: Int
                   , mapa_mapbcnt: Int
                   , mapa_gdcnt: Int
                   , mapa_bdcnt: Int
                   , Mapacnt: Int
                   , gd_bdcnt: Int
                   , threecnt: Int
                   , twocnt: Int
                   , sxsecond: Int
                   , sxsecond_false: Int
                   , sxrejectcnt: Int
                   , sxrejectcnt_gdss: Int
                   , sxrejectcnt_aoi: Int
                   , sxrejectcnt_mapa_model_mapb: Int
                   , sxrejectcnt_mapa_model_gd: Int
                   , sxrejectcnt_mapa_model_bd: Int
                   , sxrejectcnt_mapa_mapb_gd: Int
                   , sxrejectcnt_mapa_mapb_bd: Int
                   , sxrejectcnt_mapa_gd_bd: Int
                   , sxrejectcnt_mapa_model: Int
                   , sxrejectcnt_mapa_mapb: Int
                   , sxrejectcnt_mapa_gd: Int
                   , sxrejectcnt_mapa_bd: Int
                   , sxrejectcnt_Mapa: Int
                   , sxrejectcnt_gd_bd: Int
                   , finalwdcnt: Int
                   , finalwdgdsscnt: Int
                   , finalwdaoicnt: Int
                   , finalwdcnt_mapa_model_mapb: Int
                   , finalwdcnt_mapa_model_gd: Int
                   , finalwdcnt_mapa_model_bd: Int
                   , finalwdcnt_mapa_mapb_gd: Int
                   , finalwdcnt_mapa_mapb_bd: Int
                   , finalwdcnt_mapa_gd_bd: Int
                   , finalwdcnt_mapa_model: Int
                   , finalwdcnt_mapa_mapb: Int
                   , finalwdcnt_mapa_gd: Int
                   , finalwdcnt_mapa_bd: Int
                   , finalwdcnt_Mapa: Int
                   , finalwdcnt_gd_bd: Int
                   , finalwdcnt_three: Int
                   , finalwdcnt_two: Int
                   , artificiaChooseSit: Int
                   , signAddressKeyWordNumber: Int
                   , signTownKeyWord: Int
                   , signCodeKeyWord: Int
                   , specialEwbZc: Int
                   , blindSpot: Int
                   , splitLevelLess: Int
                   , townWrong: Int
                   , countyWrong: Int
                   , cityWrong: Int
                   , signCodeClose: Int
                   , gisCodeClose: Int
                   , signCodeInvalid: Int
                   , gisCodeInvalid: Int

                 )








  case class detail(
                     waybill_no: String
                     , gis_identify_site_code: String
                     , ewb_sign_site_code: String
                     , ewb_dispatch_site: String
                     , sign_province_name: String
                     , sign_city_name: String
                     , sign_county_name: String
                     , sign_town_name: String
                     , ewb_created_time: String
                     , sign_created_time: String
                     , artificial_choose_site: String
                     , artificial_province_name: String
                     , artificial_city_name: String
                     , artificial_county_name: String
                     , artificial_town_name: String
                     , special_ewb: String
                     , gd_latitude_and_longitude: String
                     , create_time: String
                     , modify_time: String
                     , matching_map_type: String
                     , last_gis_sn: String
                     , gis_back_province_name: String
                     , gis_back_city_name: String
                     , gis_back_county_name: String
                     , gis_back_town_name: String
                     , gis_identify_site_address: String
                     , ewb_sign_address: String
                     , inc_day: String
                     , sn: String
                     , req_type: String
                     , url_time: String
                     , appName: String
                     , req_time: String
                     , req_src: String
                     , log_topics: String
                     , req_address: String
                     , code: String
                     , codesorce: String
                     , tag_geo: String
                     , gis_aoiid: String
                     , province: String
                     , city: String
                     , county: String
                     , town: String
                     , citycode: String
                     , acreage: String
                     , msg: String
                     , eds_inc_day: String
                     , codeNew: String
                     , ChnameNew: String
                     , codeSourceNew: String
                     , provinceNew: String
                     , cityNew: String
                     , countyNew: String
                     , townNew: String
                     , cityCodeNew: String
                     , areaSourceNew: String
                     , uid: String
                     , code_eff_sign: String
                     , banner_sign: String
                     , extend_attrs_sign: String
                     , sxType: String
                     , sxDistrict: String
                     , sxOrgStatus: String
                     , sxDispThingStatus: String
                     , sxOrgMainStatus: String
                     , code_eff_gis: String
                     , banner_gis: String
                     , extend_attrs_gis: String
                     , sxTypeGis: String
                     , sxDistrictGis: String
                     , sxOrgStatusGis: String
                     , sxDispThingStatusGis: String
                     , sxOrgMainStatusGis: String
                     , tag:String
                     , req_x:String
                     , req_y:String
                     , code_name:String
                     , areaSource:String
                     , wb_waybill1_no:String
                     , return_ewb_no:String
                     , order_source:String
                   )


  def querySignData(spark: SparkSession, incDay: String, shunxinCityMapBc: Broadcast[collection.Map[String, String]], v3CityCodeArrayBc: Broadcast[Array[String]]): RDD[JSONObject] = {
    val sepDay = DateUtil.changeDateSep(incDay, "", "-")
    val day93 = DateUtil.getDateStr(incDay, -92, "")
    val beginTime = DateUtil.getDateStr(sepDay, -20, "-") + " 00:00:00"
    val endTime = DateUtil.getDateStr(sepDay, 20, "-") + " 23:59:59"


    val sql =
      s"""
        |select
        |a.*
        |,b.waybill_no as wb_waybill1_no
        |,b.return_ewb_no
        |,b.order_source
        |from (
        |select * from (
        |select
        |waybill_no
        |,gis_identify_site_code
        |,ewb_sign_site_code
        |,ewb_dispatch_site
        |,sign_province_name
        |,sign_city_name
        |,sign_county_name
        |,sign_town_name
        |,ewb_created_time
        |,sign_created_time
        |,artificial_choose_site
        |,artificial_province_name
        |,artificial_city_name
        |,artificial_county_name
        |,artificial_town_name
        |,cast (special_ewb as string) special_ewb
        |,gd_latitude_and_longitude
        |,create_time
        |,modify_time
        |,matching_map_type
        |,last_gis_sn
        |,gis_back_province_name
        |,gis_back_city_name
        |,gis_back_county_name
        |,gis_back_town_name
        |,gis_identify_site_address
        |,ewb_sign_address
        |,inc_day as feedback_inc_day
        |,row_number() over(partition by waybill_no order by sign_created_time desc) as rank
        |from dm_gis.sx_sign_jm
        |where inc_day ='$incDay'
        |) a where a.rank=1
        |)a
        |left join (
        |select
        |waybill_no
        |,return_ewb_no
        |,order_source
        |from (
        |select
        |waybill_no ,
        |return_waybill_no as return_ewb_no,
        |case when data_source = 'oneKey' then '回单一键开单'
        |when data_source = 'returnOpenWaybill' then '新单返货'
        |when data_source = 'originalWaybillReturn' then '原单返货'
        |when (
        |return_waybill_no <> ''
        |and return_waybill_no <> 'null'
        |) then '新单返货'
        |when special_address_service_type_name = '特殊派送（禁行区）' then '禁行区'
        |when data_source = 'openWaybill' then '普通开单'
        |when data_source = 'copyOpenWaybill' then '复制开单'
        |when data_source = 'ediOpenWaybill' then 'EDI开单'
        |when data_source = 'orderTransferWaybill' then '订单转运单'
        |else data_source
        |end as `order_source`
        |from
        |ky.ods_sx_abws_waybill.wb_waybill1
        |where inc_day between '${day93}' and '$incDay'
        |and rd_status <> '0'
        |and (data_source in ('oneKey','originalWaybillReturn','returnOpenWaybill')or (return_waybill_no <> ''and return_waybill_no <> 'null'))
        |
        |)a
        |group by waybill_no
        |,return_ewb_no
        |,order_source
        |)b
        |on a.waybill_no = b.waybill_no
        |""".stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sql_partition).map(o => {
      var signCityCode = ""
      val ewb_sign_address = JSONUtil.getJsonVal(o, "ewb_sign_address", "")
      val gis_back_city_name = JSONUtil.getJsonVal(o, "gis_back_city_name", "")
      val shunxinMap = shunxinCityMapBc.value
      if (shunxinMap.contains(ewb_sign_address)) {
        signCityCode = shunxinMap.apply(ewb_sign_address)
      }
      val v3CityCodeArray = v3CityCodeArrayBc.value
      var urlVersion = "v2"
      if (!signCityCode.isEmpty && v3CityCodeArray.contains(signCityCode)) {
        urlVersion = "v3"
      }
      var gisCityCode = ""
      if (shunxinMap.contains(gis_back_city_name)) {
        gisCityCode = shunxinMap.apply(gis_back_city_name)
      }
      o.put("gisCityCode", gisCityCode)
      o.put("urlVersion", urlVersion)
      o.put("signCityCode", signCityCode)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("顺心签收单号总数量：" + dataRdd.count())
    dataRdd
  }


  def joinOriginData(originReqRdd: RDD[(String, JSONObject)], signCheckRdd: RDD[(String, JSONObject)], compareDataRdd: RDD[(String, Int)]): RDD[JSONObject] = {
    val joinDataRdd = originReqRdd.leftOuterJoin(signCheckRdd).map(obj => {
      val left = obj._2._1
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        val rightBody = rightOp.get
        left.put("signBody", rightBody)
        (obj._1, left)
      } else {
        (null: String, null: JSONObject)
      }
    }).filter(obj => obj._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("关联签收的数量:" + joinDataRdd.count())
    originReqRdd.unpersist()
    signCheckRdd.unpersist()
    logger.error("关联前三后三比较的数据")
    val joinCompareDataRdd = joinDataRdd.leftOuterJoin(compareDataRdd).map(obj => {
      val left = obj._2._1
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        left.put("multiReq", "1")
      } else {
        left.put("multiReq", "0")
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("关联前三后三比较数据:" + joinCompareDataRdd.count())
    joinDataRdd.unpersist()
    joinCompareDataRdd
  }

  def queryCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql = "select max(city),citycode from dm_gis.city_name_map group by citycode "
    logger.error(sql)
    val cityMap = spark.sql(sql).rdd.map(obj => {
      (obj.getString(1), obj.getString(0))
    }).collectAsMap()
    logger.error("城市映射表数量:" + cityMap.size)
    spark.sparkContext.broadcast(cityMap)
  }


  def staCoverData(obj: JSONObject, cityNameMap: collection.Map[String, String]) = {

    val tag = JSONUtil.getJsonVal(obj, "tag", "")
    val codesorce = JSONUtil.getJsonVal(obj, "codesorce", "").toUpperCase()
    val tag_geo = JSONUtil.getJsonVal(obj, "tag_geo", "")
    val cityCode = obj.getString("gisCityCode")
    val city: String = cityNameMap.applyOrElse(cityCode, { num: String => "" })


    var gdsscnt
    , aoicnt
    , geowithouttscnt
    , geowithouttsgjcnt
    , geowithouttsdjcnt
    , tscnt
    , sxsecond
    , sxsecond_false
    , sxrejectcnt
    , sxrejectcnt_gdss
    , sxrejectcnt_aoi
    , sxrejectcnt_geo
    , sxrejectcnt_geo_high
    , sxrejectcnt_geo_low
    , sxrejectcnt_ts
    , finalwdcnt
    , finalwdgdsscnt
    , finalwdaoicnt
    , finalwdgeocnt
    , finalwdgeogjcnt
    , finalwdgeodjcnt
    , finalwdtscnt
    , artificiaChooseSit
    , signAddressKeyWordNumber
    , signTownKeyWord
    , signCodeKeyWord
    , specialEwbZc
    , blindSpot
    , splitLevelLess
    , townWrong
    , countyWrong
    , cityWrong
    , signCodeClose
    , gisCodeClose
    , signCodeInvalid
    , gisCodeInvalid = 0
    //区域维度
    val validcnt = 1

    var mapa_model_mapbcnt
    , mapa_model_gdcnt
    , mapa_model_bdcnt
    , mapa_mapb_gdcnt
    , mapa_mapb_bdcnt
    , mapa_gd_bdcnt
    , mapa_modelcnt
    , mapa_mapbcnt
    , mapa_gdcnt
    , mapa_bdcnt
    , Mapacnt
    , gd_bdcnt
    , threecnt
    , twocnt
    , sxrejectcnt_mapa_model_mapb
    , sxrejectcnt_mapa_model_gd
    , sxrejectcnt_mapa_model_bd
    , sxrejectcnt_mapa_mapb_gd
    , sxrejectcnt_mapa_mapb_bd
    , sxrejectcnt_mapa_gd_bd
    , sxrejectcnt_mapa_model
    , sxrejectcnt_mapa_mapb
    , sxrejectcnt_mapa_gd
    , sxrejectcnt_mapa_bd
    , sxrejectcnt_Mapa
    , sxrejectcnt_gd_bd
    , finalwdcnt_mapa_model_mapb
    , finalwdcnt_mapa_model_gd
    , finalwdcnt_mapa_model_bd
    , finalwdcnt_mapa_mapb_gd
    , finalwdcnt_mapa_mapb_bd
    , finalwdcnt_mapa_gd_bd
    , finalwdcnt_mapa_model
    , finalwdcnt_mapa_mapb
    , finalwdcnt_mapa_gd
    , finalwdcnt_mapa_bd
    , finalwdcnt_Mapa
    , finalwdcnt_gd_bd
    , finalwdcnt_three
    , finalwdcnt_two = 0



      codesorce match {
        case "HIS" => gdsscnt = 1
        case "AOI" => aoicnt = 1
        case "GEO|TS1" => tscnt = 1
        case "GEO|TS2" => tscnt = 1
        case _ => {
          if (codesorce.nonEmpty) {
            geowithouttscnt = 1
            if (!tag_geo.equals("0")) geowithouttsgjcnt = 1
            else if (tag_geo.equals("0")) geowithouttsdjcnt = 1

          }

        }
      }



    if (!tag.equals("same")) {
      //重跑量
      sxsecond = 1
      if (!tag.equals("same_new")) {
        sxsecond_false = 1
        if (!tag.equals("wrong")) {
          //顺心剔除项
          sxrejectcnt = 1
          codesorce match {
            case "HIS" => sxrejectcnt_gdss = 1
            case "AOI" => sxrejectcnt_aoi = 1
            case "GEO|TS1" => sxrejectcnt_ts = 1
            case "GEO|TS2" => sxrejectcnt_ts = 1
            case _ => {
              if (codesorce.nonEmpty) {
                sxrejectcnt_geo = 1
                if (!tag_geo.equals("0")) sxrejectcnt_geo_high = 1
                else if (tag_geo.equals("0")) sxrejectcnt_geo_low = 1
              }

            }
          }

        }
      }
    }




    //错分
    if (tag.equals("wrong")) {
      finalwdcnt = 1
      codesorce match {
        case "HIS" => finalwdgdsscnt = 1
        case "AOI" => finalwdaoicnt = 1
        case "GEO|TS1" => finalwdtscnt = 1
        case "GEO|TS2" => finalwdtscnt = 1
        case _ => {
          if (codesorce.nonEmpty) {
            finalwdgeocnt = 1
            if (!tag_geo.equals("0")) finalwdgeogjcnt = 1
            else if (tag_geo.equals("0")) finalwdgeodjcnt = 1
          }

        }
      }
    }


    //    tag=signAddressKeyWord|tag=addressNumber
    //    tag=signTownKeyWord
    //    Tag=signCodeKeyWord
    //    Tag=specialEwb|Tag=specialZc
    //    Tag=blindSpot
    //    Tag=splitLevelLess
    //    Tag=townWrong
    //    Tag=countyWrong
    //    Tag=cityWrong
    //    Tag=signCodeClose
    //    Tag=gisCodeClose
    //    Tag=signCodeInvalid
    //    Tag=gisCodeInvalid


    if (tag.equals("artificiaChooseSit")) artificiaChooseSit = 1
    if (tag.equals("signAddressKeyWord") || tag.equals("addressNumber")) signAddressKeyWordNumber = 1
    if (tag.equals("signTownKeyWord")) signTownKeyWord = 1
    if (tag.equals("signCodeKeyWord")) signCodeKeyWord = 1
    if (tag.equals("specialEwb") || tag.equals("specialZc")) specialEwbZc = 1
    if (tag.equals("blindSpot")) blindSpot = 1
    if (tag.equals("splitLevelLess")) splitLevelLess = 1
    if (tag.equals("townWrong")) townWrong = 1
    if (tag.equals("countyWrong")) countyWrong = 1
    if (tag.equals("cityWrong")) cityWrong = 1
    if (tag.equals("signCodeClose")) signCodeClose = 1
    if (tag.equals("gisCodeClose")) gisCodeClose = 1
    if (tag.equals("signCodeInvalid")) signCodeInvalid = 1
    if (tag.equals("gisCodeInvalid")) gisCodeInvalid = 1


    (ShunxinCover(
      cityCode
      , city
      , validcnt
      , gdsscnt
      , aoicnt
      , geowithouttscnt
      , geowithouttsgjcnt
      , geowithouttsdjcnt
      , tscnt
      , sxsecond
      , sxsecond_false
      , sxrejectcnt
      , sxrejectcnt_gdss
      , sxrejectcnt_aoi
      , sxrejectcnt_geo
      , sxrejectcnt_geo_high
      , sxrejectcnt_geo_low
      , sxrejectcnt_ts
      , finalwdcnt
      , finalwdgdsscnt
      , finalwdaoicnt
      , finalwdgeocnt
      , finalwdgeogjcnt
      , finalwdgeodjcnt
      , finalwdtscnt
      , artificiaChooseSit
      , signAddressKeyWordNumber
      , signTownKeyWord
      , signCodeKeyWord
      , specialEwbZc
      , blindSpot
      , splitLevelLess
      , townWrong
      , countyWrong
      , cityWrong
      , signCodeClose
      , gisCodeClose
      , signCodeInvalid
      , gisCodeInvalid
    ),
      mult(
        cityCode
        , city
        , validcnt
        , gdsscnt
        , aoicnt
        , mapa_model_mapbcnt
        , mapa_model_gdcnt
        , mapa_model_bdcnt
        , mapa_mapb_gdcnt
        , mapa_mapb_bdcnt
        , mapa_gd_bdcnt
        , mapa_modelcnt
        , mapa_mapbcnt
        , mapa_gdcnt
        , mapa_bdcnt
        , Mapacnt
        , gd_bdcnt
        , threecnt
        , twocnt
        , sxsecond
        , sxsecond_false
        , sxrejectcnt
        , sxrejectcnt_gdss
        , sxrejectcnt_aoi
        , sxrejectcnt_mapa_model_mapb
        , sxrejectcnt_mapa_model_gd
        , sxrejectcnt_mapa_model_bd
        , sxrejectcnt_mapa_mapb_gd
        , sxrejectcnt_mapa_mapb_bd
        , sxrejectcnt_mapa_gd_bd
        , sxrejectcnt_mapa_model
        , sxrejectcnt_mapa_mapb
        , sxrejectcnt_mapa_gd
        , sxrejectcnt_mapa_bd
        , sxrejectcnt_Mapa
        , sxrejectcnt_gd_bd
        , finalwdcnt
        , finalwdgdsscnt
        , finalwdaoicnt
        , finalwdcnt_mapa_model_mapb
        , finalwdcnt_mapa_model_gd
        , finalwdcnt_mapa_model_bd
        , finalwdcnt_mapa_mapb_gd
        , finalwdcnt_mapa_mapb_bd
        , finalwdcnt_mapa_gd_bd
        , finalwdcnt_mapa_model
        , finalwdcnt_mapa_mapb
        , finalwdcnt_mapa_gd
        , finalwdcnt_mapa_bd
        , finalwdcnt_Mapa
        , finalwdcnt_gd_bd
        , finalwdcnt_three
        , finalwdcnt_two
        , artificiaChooseSit
        , signAddressKeyWordNumber
        , signTownKeyWord
        , signCodeKeyWord
        , specialEwbZc
        , blindSpot
        , splitLevelLess
        , townWrong
        , countyWrong
        , cityWrong
        , signCodeClose
        , gisCodeClose
        , signCodeInvalid
        , gisCodeInvalid
      )
    )

  }


  def mergeShunxinCover(obj1: (ShunxinCover, mult), obj2: (ShunxinCover, mult)) = {
    val cityCode = obj1._1.cityCode
    val city = obj1._1.city
    val validCnt = obj1._1.validCnt + obj2._1.validCnt
    val gdsscnt = obj1._1.gdsscnt + obj2._1.gdsscnt
    val aoicnt = obj1._1.aoicnt + obj2._1.aoicnt
    val geowithouttscnt = obj1._1.geowithouttscnt + obj2._1.geowithouttscnt
    val geowithouttsgjcnt = obj1._1.geowithouttsgjcnt + obj2._1.geowithouttsgjcnt
    val geowithouttsdjcnt = obj1._1.geowithouttsdjcnt + obj2._1.geowithouttsdjcnt
    val tscnt = obj1._1.tscnt + obj2._1.tscnt
    val sxsecond = obj1._1.sxsecond + obj2._1.sxsecond
    val sxsecond_false = obj1._1.sxsecond_false + obj2._1.sxsecond_false
    val sxrejectcnt = obj1._1.sxrejectcnt + obj2._1.sxrejectcnt
    val sxrejectcnt_gdss = obj1._1.sxrejectcnt_gdss + obj2._1.sxrejectcnt_gdss
    val sxrejectcnt_aoi = obj1._1.sxrejectcnt_aoi + obj2._1.sxrejectcnt_aoi
    val sxrejectcnt_geo = obj1._1.sxrejectcnt_geo + obj2._1.sxrejectcnt_geo
    val sxrejectcnt_geo_high = obj1._1.sxrejectcnt_geo_high + obj2._1.sxrejectcnt_geo_high
    val sxrejectcnt_geo_low = obj1._1.sxrejectcnt_geo_low + obj2._1.sxrejectcnt_geo_low
    val sxrejectcnt_ts = obj1._1.sxrejectcnt_ts + obj2._1.sxrejectcnt_ts
    val finalwdcnt = obj1._1.finalwdcnt + obj2._1.finalwdcnt
    val finalwdgdsscnt = obj1._1.finalwdgdsscnt + obj2._1.finalwdgdsscnt
    val finalwdaoicnt = obj1._1.finalwdaoicnt + obj2._1.finalwdaoicnt
    val finalwdgeocnt = obj1._1.finalwdgeocnt + obj2._1.finalwdgeocnt
    val finalwdgeogjcnt = obj1._1.finalwdgeogjcnt + obj2._1.finalwdgeogjcnt
    val finalwdgeodjcnt = obj1._1.finalwdgeodjcnt + obj2._1.finalwdgeodjcnt
    val finalwdtscnt = obj1._1.finalwdtscnt + obj2._1.finalwdtscnt
    val artificiaChooseSit = obj1._1.artificiaChooseSit + obj2._1.artificiaChooseSit
    val signAddressKeyWordNumber = obj1._1.signAddressKeyWordNumber + obj2._1.signAddressKeyWordNumber
    val signTownKeyWord = obj1._1.signTownKeyWord + obj2._1.signTownKeyWord
    val signCodeKeyWord = obj1._1.signCodeKeyWord + obj2._1.signCodeKeyWord
    val specialEwbZc = obj1._1.specialEwbZc + obj2._1.specialEwbZc
    val blindSpot = obj1._1.blindSpot + obj2._1.blindSpot
    val splitLevelLess = obj1._1.splitLevelLess + obj2._1.splitLevelLess
    val townWrong = obj1._1.townWrong + obj2._1.townWrong
    val countyWrong = obj1._1.countyWrong + obj2._1.countyWrong
    val cityWrong = obj1._1.cityWrong + obj2._1.cityWrong
    val signCodeClose = obj1._1.signCodeClose + obj2._1.signCodeClose
    val gisCodeClose = obj1._1.gisCodeClose + obj2._1.gisCodeClose
    val signCodeInvalid = obj1._1.signCodeInvalid + obj2._1.signCodeInvalid
    val gisCodeInvalid = obj1._1.gisCodeInvalid + obj2._1.gisCodeInvalid


    val mulcityCode = obj1._2.cityCode
    val mulcity = obj1._2.city
    val multvalidcnt = obj1._2.validcnt + obj2._2.validcnt
    val multgdsscnt = obj1._2.gdsscnt + obj2._2.gdsscnt
    val multaoicnt = obj1._2.aoicnt + obj2._2.aoicnt
    val multmapa_model_mapbcnt = obj1._2.mapa_model_mapbcnt + obj2._2.mapa_model_mapbcnt
    val multmapa_model_gdcnt = obj1._2.mapa_model_gdcnt + obj2._2.mapa_model_gdcnt
    val multmapa_model_bdcnt = obj1._2.mapa_model_bdcnt + obj2._2.mapa_model_bdcnt
    val multmapa_mapb_gdcnt = obj1._2.mapa_mapb_gdcnt + obj2._2.mapa_mapb_gdcnt
    val multmapa_mapb_bdcnt = obj1._2.mapa_mapb_bdcnt + obj2._2.mapa_mapb_bdcnt
    val multmapa_gd_bdcnt = obj1._2.mapa_gd_bdcnt + obj2._2.mapa_gd_bdcnt
    val multmapa_modelcnt = obj1._2.mapa_modelcnt + obj2._2.mapa_modelcnt
    val multmapa_mapbcnt = obj1._2.mapa_mapbcnt + obj2._2.mapa_mapbcnt
    val multmapa_gdcnt = obj1._2.mapa_gdcnt + obj2._2.mapa_gdcnt
    val multmapa_bdcnt = obj1._2.mapa_bdcnt + obj2._2.mapa_bdcnt
    val multMapacnt = obj1._2.Mapacnt + obj2._2.Mapacnt
    val multgd_bdcnt = obj1._2.gd_bdcnt + obj2._2.gd_bdcnt
    val multthreecnt = obj1._2.threecnt + obj2._2.threecnt
    val multtwocnt = obj1._2.twocnt + obj2._2.twocnt
    val multsxsecond = obj1._2.sxsecond + obj2._2.sxsecond
    val multsxsecond_false = obj1._2.sxsecond_false + obj2._2.sxsecond_false
    val multsxrejectcnt = obj1._2.sxrejectcnt + obj2._2.sxrejectcnt
    val multsxrejectcnt_gdss = obj1._2.sxrejectcnt_gdss + obj2._2.sxrejectcnt_gdss
    val multsxrejectcnt_aoi = obj1._2.sxrejectcnt_aoi + obj2._2.sxrejectcnt_aoi
    val multsxrejectcnt_mapa_model_mapb = obj1._2.sxrejectcnt_mapa_model_mapb + obj2._2.sxrejectcnt_mapa_model_mapb
    val multsxrejectcnt_mapa_model_gd = obj1._2.sxrejectcnt_mapa_model_gd + obj2._2.sxrejectcnt_mapa_model_gd
    val multsxrejectcnt_mapa_model_bd = obj1._2.sxrejectcnt_mapa_model_bd + obj2._2.sxrejectcnt_mapa_model_bd
    val multsxrejectcnt_mapa_mapb_gd = obj1._2.sxrejectcnt_mapa_mapb_gd + obj2._2.sxrejectcnt_mapa_mapb_gd
    val multsxrejectcnt_mapa_mapb_bd = obj1._2.sxrejectcnt_mapa_mapb_bd + obj2._2.sxrejectcnt_mapa_mapb_bd
    val multsxrejectcnt_mapa_gd_bd = obj1._2.sxrejectcnt_mapa_gd_bd + obj2._2.sxrejectcnt_mapa_gd_bd
    val multsxrejectcnt_mapa_model = obj1._2.sxrejectcnt_mapa_model + obj2._2.sxrejectcnt_mapa_model
    val multsxrejectcnt_mapa_mapb = obj1._2.sxrejectcnt_mapa_mapb + obj2._2.sxrejectcnt_mapa_mapb
    val multsxrejectcnt_mapa_gd = obj1._2.sxrejectcnt_mapa_gd + obj2._2.sxrejectcnt_mapa_gd
    val multsxrejectcnt_mapa_bd = obj1._2.sxrejectcnt_mapa_bd + obj2._2.sxrejectcnt_mapa_bd
    val multsxrejectcnt_Mapa = obj1._2.sxrejectcnt_Mapa + obj2._2.sxrejectcnt_Mapa
    val multsxrejectcnt_gd_bd = obj1._2.sxrejectcnt_gd_bd + obj2._2.sxrejectcnt_gd_bd
    val multfinalwdcnt = obj1._2.finalwdcnt + obj2._2.finalwdcnt
    val multfinalwdgdsscnt = obj1._2.finalwdgdsscnt + obj2._2.finalwdgdsscnt
    val multfinalwdaoicnt = obj1._2.finalwdaoicnt + obj2._2.finalwdaoicnt
    val multfinalwdcnt_mapa_model_mapb = obj1._2.finalwdcnt_mapa_model_mapb + obj2._2.finalwdcnt_mapa_model_mapb
    val multfinalwdcnt_mapa_model_gd = obj1._2.finalwdcnt_mapa_model_gd + obj2._2.finalwdcnt_mapa_model_gd
    val multfinalwdcnt_mapa_model_bd = obj1._2.finalwdcnt_mapa_model_bd + obj2._2.finalwdcnt_mapa_model_bd
    val multfinalwdcnt_mapa_mapb_gd = obj1._2.finalwdcnt_mapa_mapb_gd + obj2._2.finalwdcnt_mapa_mapb_gd
    val multfinalwdcnt_mapa_mapb_bd = obj1._2.finalwdcnt_mapa_mapb_bd + obj2._2.finalwdcnt_mapa_mapb_bd
    val multfinalwdcnt_mapa_gd_bd = obj1._2.finalwdcnt_mapa_gd_bd + obj2._2.finalwdcnt_mapa_gd_bd
    val multfinalwdcnt_mapa_model = obj1._2.finalwdcnt_mapa_model + obj2._2.finalwdcnt_mapa_model
    val multfinalwdcnt_mapa_mapb = obj1._2.finalwdcnt_mapa_mapb + obj2._2.finalwdcnt_mapa_mapb
    val multfinalwdcnt_mapa_gd = obj1._2.finalwdcnt_mapa_gd + obj2._2.finalwdcnt_mapa_gd
    val multfinalwdcnt_mapa_bd = obj1._2.finalwdcnt_mapa_bd + obj2._2.finalwdcnt_mapa_bd
    val multfinalwdcnt_Mapa = obj1._2.finalwdcnt_Mapa + obj2._2.finalwdcnt_Mapa
    val multfinalwdcnt_gd_bd = obj1._2.finalwdcnt_gd_bd + obj2._2.finalwdcnt_gd_bd
    val multfinalwdcnt_three = obj1._2.finalwdcnt_three + obj2._2.finalwdcnt_three
    val multfinalwdcnt_two = obj1._2.finalwdcnt_two + obj2._2.finalwdcnt_two
    val multartificiaChooseSit = obj1._2.artificiaChooseSit + obj2._2.artificiaChooseSit
    val multsignAddressKeyWordNumber = obj1._2.signAddressKeyWordNumber + obj2._2.signAddressKeyWordNumber
    val multsignTownKeyWord = obj1._2.signTownKeyWord + obj2._2.signTownKeyWord
    val multsignCodeKeyWord = obj1._2.signCodeKeyWord + obj2._2.signCodeKeyWord
    val multspecialEwbZc = obj1._2.specialEwbZc + obj2._2.specialEwbZc
    val multblindSpot = obj1._2.blindSpot + obj2._2.blindSpot
    val multsplitLevelLess = obj1._2.splitLevelLess + obj2._2.splitLevelLess
    val multtownWrong = obj1._2.townWrong + obj2._2.townWrong
    val multcountyWrong = obj1._2.countyWrong + obj2._2.countyWrong
    val multcityWrong = obj1._2.cityWrong + obj2._2.cityWrong
    val multsignCodeClose = obj1._2.signCodeClose + obj2._2.signCodeClose
    val multgisCodeClose = obj1._2.gisCodeClose + obj2._2.gisCodeClose
    val multsignCodeInvalid = obj1._2.signCodeInvalid + obj2._2.signCodeInvalid
    val multgisCodeInvalid = obj1._2.gisCodeInvalid + obj2._2.gisCodeInvalid


    (ShunxinCover(
      cityCode
      , city
      , validCnt
      , gdsscnt
      , aoicnt
      , geowithouttscnt
      , geowithouttsgjcnt
      , geowithouttsdjcnt
      , tscnt
      , sxsecond
      , sxsecond_false
      , sxrejectcnt
      , sxrejectcnt_gdss
      , sxrejectcnt_aoi
      , sxrejectcnt_geo
      , sxrejectcnt_geo_high
      , sxrejectcnt_geo_low
      , sxrejectcnt_ts
      , finalwdcnt
      , finalwdgdsscnt
      , finalwdaoicnt
      , finalwdgeocnt
      , finalwdgeogjcnt
      , finalwdgeodjcnt
      , finalwdtscnt
      , artificiaChooseSit
      , signAddressKeyWordNumber
      , signTownKeyWord
      , signCodeKeyWord
      , specialEwbZc
      , blindSpot
      , splitLevelLess
      , townWrong
      , countyWrong
      , cityWrong
      , signCodeClose
      , gisCodeClose
      , signCodeInvalid
      , gisCodeInvalid
    ), mult(
      mulcityCode
      , mulcity
      , multvalidcnt
      , multgdsscnt
      , multaoicnt
      , multmapa_model_mapbcnt
      , multmapa_model_gdcnt
      , multmapa_model_bdcnt
      , multmapa_mapb_gdcnt
      , multmapa_mapb_bdcnt
      , multmapa_gd_bdcnt
      , multmapa_modelcnt
      , multmapa_mapbcnt
      , multmapa_gdcnt
      , multmapa_bdcnt
      , multMapacnt
      , multgd_bdcnt
      , multthreecnt
      , multtwocnt
      , multsxsecond
      , multsxsecond_false
      , multsxrejectcnt
      , multsxrejectcnt_gdss
      , multsxrejectcnt_aoi
      , multsxrejectcnt_mapa_model_mapb
      , multsxrejectcnt_mapa_model_gd
      , multsxrejectcnt_mapa_model_bd
      , multsxrejectcnt_mapa_mapb_gd
      , multsxrejectcnt_mapa_mapb_bd
      , multsxrejectcnt_mapa_gd_bd
      , multsxrejectcnt_mapa_model
      , multsxrejectcnt_mapa_mapb
      , multsxrejectcnt_mapa_gd
      , multsxrejectcnt_mapa_bd
      , multsxrejectcnt_Mapa
      , multsxrejectcnt_gd_bd
      , multfinalwdcnt
      , multfinalwdgdsscnt
      , multfinalwdaoicnt
      , multfinalwdcnt_mapa_model_mapb
      , multfinalwdcnt_mapa_model_gd
      , multfinalwdcnt_mapa_model_bd
      , multfinalwdcnt_mapa_mapb_gd
      , multfinalwdcnt_mapa_mapb_bd
      , multfinalwdcnt_mapa_gd_bd
      , multfinalwdcnt_mapa_model
      , multfinalwdcnt_mapa_mapb
      , multfinalwdcnt_mapa_gd
      , multfinalwdcnt_mapa_bd
      , multfinalwdcnt_Mapa
      , multfinalwdcnt_gd_bd
      , multfinalwdcnt_three
      , multfinalwdcnt_two
      , multartificiaChooseSit
      , multsignAddressKeyWordNumber
      , multsignTownKeyWord
      , multsignCodeKeyWord
      , multspecialEwbZc
      , multblindSpot
      , multsplitLevelLess
      , multtownWrong
      , multcountyWrong
      , multcityWrong
      , multsignCodeClose
      , multgisCodeClose
      , multsignCodeInvalid
      , multgisCodeInvalid
    ))
  }


  def staIndex(checkOverRdd: RDD[JSONObject], cityMapBc: Broadcast[collection.Map[String, String]]) = {

    val indexRdd = checkOverRdd.map(obj => {
      val staCoverObj: (ShunxinCover, mult) = staCoverData(obj, cityMapBc.value)
      ((staCoverObj._1.cityCode, staCoverObj._1.city), staCoverObj)
    }).reduceByKey((obj1, obj2) => {
      val staCoverObj = mergeShunxinCover(obj1, obj2)

      staCoverObj
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("聚合后数量:" + indexRdd.count())
    indexRdd
  }


  def saveStaIndex(spark: SparkSession, staIndexRdd: RDD[(ShunxinCover, mult)], incDay: String): Unit = {
    import spark.implicits._

    var ShunxinCoverDf = staIndexRdd.map(_._1).toDF()
    var multDf = staIndexRdd.map(_._2).toDF()
    val tableName = "dm_gis.shunxin_code_cnt_new"
    logger.error(s"入指标表的数据量：${tableName}" + ShunxinCoverDf.count())
    ShunxinCoverDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    val multTableName = "dm_gis.shunxin_detail_di_new_mult"
    logger.error(s"入指标表的数据量：${multTableName}" + ShunxinCoverDf.count())
    multDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(multTableName)

  }


  def checkWdDetail2(staRdd: RDD[JSONObject]) = {
    var reRdd = staRdd.repartition(sql_partition).map(o => {
      val townNew = JSONUtil.getJsonVal(o, "townNew", "")
//        .replaceAll("镇|街道", "")
      val sign_town_name = JSONUtil.getJsonVal(o, "sign_town_name", "")
      val sign_province_name = JSONUtil.getJsonVal(o, "sign_province_name", "")
//        .replaceAll("镇|街道", "")
      val ewb_sign_address = JSONUtil.getJsonVal(o, "ewb_sign_address", "")
      val countyNew = JSONUtil.getJsonVal(o, "countyNew", "").replaceAll("区|县", "")
      val sign_county_name = JSONUtil.getJsonVal(o, "sign_county_name", "").replaceAll("区|县", "")
      val cityNew = JSONUtil.getJsonVal(o, "cityNew", "")
      val sign_city_name = JSONUtil.getJsonVal(o, "sign_city_name", "")
      val code_eff_sign = JSONUtil.getJsonVal(o, "code_eff_sign", "")
      val code_eff_gis = JSONUtil.getJsonVal(o, "code_eff_sign", "")
      val extend_attrs_sign = JSONUtil.getJsonVal(o, "extend_attrs_sign", "")
      val extend_attrs_gis = JSONUtil.getJsonVal(o, "extend_attrs_gis", "")
      val signObject = try {
        JSON.parseObject(extend_attrs_sign)
      } catch {
        case _ => new JSONObject()
      }
      val gisObject = try {
        JSON.parseObject(extend_attrs_gis)
      } catch {
        case _ => new JSONObject()
      }
      val sxOrgStatus = JSONUtil.getJsonValInt(signObject, "sxOrgStatus", 999)
      val sxDispThingStatus = JSONUtil.getJsonValInt(gisObject, "sxDispThingStatus", 999)

      //打标签
      if (ewb_sign_address.nonEmpty && ewb_sign_address.contains(townNew) && !ewb_sign_address.contains(sign_town_name)) o.put("tag", "townWrong")
      else if (ewb_sign_address.nonEmpty && ewb_sign_address.contains(countyNew) && !ewb_sign_address.contains(sign_county_name)) o.put("tag", "countyWrong")
      else if (sign_city_name.nonEmpty && !sign_province_name.equals("海南省") && !sign_city_name.equals(cityNew) ) o.put("tag", "cityWrong")
      else if (code_eff_sign.isEmpty) o.put("tag", "signCodeInvalid")
      else if (code_eff_gis.isEmpty) o.put("tag", "gisCodeInvalid")
      else if (sxOrgStatus == 0 || sxOrgStatus == -1 || sxOrgStatus == -9999) o.put("tag", "signCodeClose")
      else if (sxDispThingStatus != 100) o.put("tag", "gisCodeClose")
      else o.put("tag", "wrong")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("打完标签的数据量" + reRdd.count())

    reRdd
  }


  def checkWdDetail(staRdd: RDD[JSONObject], sxDeptBc: Broadcast[collection.Map[String, String]]) = {
    val reRdd = staRdd.repartition(sql_partition).map(o => {
      val ewb_sign_site_code = JSONUtil.getJsonVal(o, "ewb_sign_site_code", "")
      val artificial_choose_site = JSONUtil.getJsonVal(o, "artificial_choose_site", "")
      val codeNew = JSONUtil.getJsonVal(o, "codeNew", "")
      val ewb_sign_address = JSONUtil.getJsonVal(o, "ewb_sign_address", "")
      val sign_town_name = JSONUtil.getJsonVal(o, "sign_town_name", "")
      val special_ewb = JSONUtil.getJsonVal(o, "special_ewb", "")
      val ewb_dispatch_site = JSONUtil.getJsonVal(o, "ewb_dispatch_site", "")
      val sxDeptMap = sxDeptBc.value

      val signInfo = sxDeptMap.getOrElse(ewb_sign_site_code, "").split("&&")
      val gisInfo = sxDeptMap.getOrElse(codeNew, "").split("&&")


      if (signInfo.size > 0) {
        val tagArray = signFormat.split(",")
        for (i <- 0 until signInfo.size) {
          o.put(tagArray(i), signInfo(i))
        }
      }

      if (gisInfo.size > 0) {
        val tagArray = gisFormat.split(",")
        for (i <- 0 until gisInfo.size) {
          o.put(tagArray(i), gisInfo(i))
        }
      }


      val regex = """^\d+$""".r
      val banner_sign = JSONUtil.getJsonVal(o, "banner_sign", "")
      val con = ".*自提.*|.*顺心捷达.*|.*自送.*|.*作废.*|.*取消发货.*|.*电话联系.*|.*电联.*|.*营业部.*|.*返回.*|.*内部带货.*|.*中转场.*|.*客户退款.*|.*拦截.*"
      val regexTown = """\d号|\(.*\)|仓库|公司|工厂|物流园|产业园|基地|中心|内部带货专用|平台入仓""".r
      val regexSign = """转场|集配站|枢纽|营业部""".r
      if (artificial_choose_site.nonEmpty) o.put("tag", "artificiaChooseSit")
      else if (ewb_sign_address.matches(con)) o.put("tag", "signAddressKeyWord")
      else if (regex.findFirstMatchIn(ewb_sign_address).nonEmpty) o.put("tag", "addressNumber")
      else if (regexTown.findFirstMatchIn(sign_town_name).nonEmpty) o.put("tag", "signTownKeyWord")
      else if (special_ewb.nonEmpty) o.put("tag", "specialEwb")
      else if (ewb_dispatch_site.equals("S020AAEL")) o.put("tag", "specialZc")
      else if (codeNew.isEmpty) o.put("tag", "blindSpot")
      else if (regexSign.findFirstMatchIn(banner_sign).nonEmpty) o.put("tag", "signCodeKeyWord")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("跑切词前，打tag的数据量：" + reRdd.count())
    reRdd
  }


  def runSegDetail(dataRdd: RDD[JSONObject]): RDD[JSONObject] = {
    dataRdd.repartition(seg_partition).mapPartitions(row => {
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      row.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= seg_ak_limit) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        val (segCityCode, ret, mark) = getSeg(seg_url, JSONUtil.getJsonVal(obj, "gisAddress", ""))
        obj.put("segCityCode", segCityCode)
        obj.put("segRet", ret)
        obj.put("segMark", mark)
        obj
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
  }

  def runGisDeptDetail(url: String, address: String): (JSONObject, String, String, String, String, String, String, String, String, String, String, Boolean) = {
    var ret: JSONObject = null
    try {
      if (address.isEmpty) {
        //地址为空，直接返回
        return (ret, "", "", "", "", "", "", "", "", "", "", false)
      }
      val finalUrl = url.format(URLEncoder.encode(address, "utf-8"))
      ret = HttpClientUtil.getJsonByGet(finalUrl, 3)
      if (ret != null && ret.getJSONObject("result") != null) {
        if (ret.getJSONObject("result").getInteger("err") == 109) {
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep(60 - second)
          return runGisDeptDetail(url, address)
        }


        val uid = JSONUtil.getJsonVal(ret, "result.uid", "")
        val codeNew = JSONUtil.getJsonVal(ret, "result.sxData.code", "")
        val chnameNew = JSONUtil.getJsonVal(ret, "result.sxData.chName", "")
        val codeSourceNew = JSONUtil.getJsonVal(ret, "result.sxData.codeSource", "")
        val provinceNew = JSONUtil.getJsonVal(ret, "result.areaData.province", "")
        val cityNew = JSONUtil.getJsonVal(ret, "result.areaData.city", "")
        val countyNew = JSONUtil.getJsonVal(ret, "result.areaData.county", "")
        val townNew = JSONUtil.getJsonVal(ret, "result.areaData.town", "")
        val areaSourceNew = JSONUtil.getJsonVal(ret, "result.areaData.areaSource", "")
        val cityCodeNew = JSONUtil.getJsonVal(ret, "result.areaData.cityCode", "")


        val deptNotCover = JSONUtil.getJsonVal(ret, "result.msg", "").equals("地址找不到顺心网点") || JSONUtil.getJsonVal(ret, "result.msg", "").equals("code的DispThingStatus不符合")
        return (ret, uid, codeNew, chnameNew, codeSourceNew, cityNew, provinceNew, countyNew, townNew, areaSourceNew, cityCodeNew, deptNotCover)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    return (ret, "", "", "", "", "", "", "", "", "", "", false)

  }


  def getSeg(url: String, address: String): (String, JSONObject, String) = {
    var ret: JSONObject = null
    try {
      val finalUrl = url.format(URLEncoder.encode(address, "utf-8"))
      ret = HttpClientUtil.getJsonByGet(finalUrl, 3)
      if (ret != null && ret.getJSONObject("result") != null) {
        if (ret.getJSONObject("result").getInteger("err") == 109) {
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep(60 - second)
          return getSeg(url, address)
        }
        val cityCode = JSONUtil.getJsonVal(ret, "result.data.citycode", "")
        val mark = JSONUtil.getJsonVal(ret, "result.mark", "")
        return (cityCode, ret, mark)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ("", ret, "")
  }


  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision, match_level = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getInteger("precision") != null) precision = result.getInteger("precision") + ""
            if (result.getInteger("match_level") != null) match_level = result.getInteger("match_level") + ""
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
          ret.put("match_level", match_level)
          ret.put("ret", xyObj)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }

  def xy2Dept(xyDeptUrl: String, lgt: String, lat: String): (String, JSONObject) = {
    var ret = null: JSONObject
    try {
      if (lgt != null && !lgt.isEmpty) {
        ret = HttpClientUtil.getJsonByGet(String.format(xyDeptUrl, lgt, lat))
        if (ret != null && ret.getJSONObject("result") != null) {
          if (ret.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return xy2Dept(xyDeptUrl, lgt, lat)
          }
          val mapArray = JSONUtil.getJsonArrayFromObject(ret, "result.map_data", null)
          if (mapArray != null && mapArray.size() > 0) {
            val code = JSONUtil.getJsonVal(mapArray.getJSONObject(0), "code", "")
            return (code, ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ("", ret)
  }


  def runSplit(url: String, address: String, citycode: String): (Int, JSONObject) = {
    var ret = null: JSONObject
    try {
      val encodeAddress = URLEncoder.encode(address, "utf-8")
      ret = HttpClientUtil.getJsonByGet(String.format(split_url, encodeAddress, citycode))
      if (ret != null && ret.getJSONObject("result") != null) {
        if (ret.getJSONObject("result").getInteger("err") == 109) {
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep(60 - second)
          return runSplit(url, address, citycode)
        }
        val levelArray = JSONUtil.getJsonArrayFromObject(ret, "result.data.info", new JSONArray())
        var maxLevel = -1
        for (i <- 0 until levelArray.size()) {
          val tmpLevel = JSONUtil.getJsonValInt(levelArray.getJSONObject(i), "level", -1)
          if (tmpLevel > maxLevel) {
            maxLevel = tmpLevel
          }
        }
        if (maxLevel == -1) {
          maxLevel = 10000
        }
        return (maxLevel, ret)

      }
    } catch {
      case e: Exception => logger.error(e)
    }
    (10000, ret)
  }

  /**
    * 切词服务
    *
    * @param needCheckTagRdd
    * @return
    */
  def splitData(needCheckTagRdd: RDD[JSONObject]): (RDD[JSONObject], RDD[JSONObject]) = {
    val splitDataRdd = needCheckTagRdd.repartition(common_partition).map(obj => {
      val (level, ret) = runSplit(split_url, JSONUtil.getJsonVal(obj, "ewb_sign_address", ""), JSONUtil.getJsonVal(obj, "cityCodeNew", ""))
      obj.put("splitLevel", level)
      obj.put("splitRet", ret)
      if (level <= 5) {
        obj.put("tag", "splitLevelLess")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val splitRejectRdd = splitDataRdd.filter(obj => JSONUtil.getJsonVal(obj, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("切词级别剔除数量：" + splitRejectRdd.count())
    splitRejectRdd.take(1).foreach(obj => obj.toJSONString)
    val splitOkRdd = splitDataRdd.filter(obj => JSONUtil.getJsonVal(obj, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("切词级别ok数量：" + splitOkRdd.count())
    splitOkRdd.take(1).foreach(obj => obj.toJSONString)
    needCheckTagRdd.unpersist()
    splitDataRdd.unpersist()
    (splitRejectRdd, splitOkRdd)
  }

  def checkWdData(spark:SparkSession,signCheckRunGis: RDD[JSONObject], netChangeRdd: RDD[((String, String), JSONObject)],
                  sxDeptBc: Broadcast[collection.Map[String, String]], logInfoRdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {
    logger.error("开始打标签")
    //网点签收网点是否为空
    val unionRdd = signCheckRunGis.filter(o => JSONUtil.getJsonVal(o, "ewb_sign_site_code", "").isEmpty).map(o => {
      o.put("tag", "code_empty")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val runRdd = signCheckRunGis.filter(o => JSONUtil.getJsonVal(o, "ewb_sign_site_code", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("ewb_sign_site_code是空的数据量：" + unionRdd.count())
    logger.error("ewb_sign_site_code非空的数据量：" + runRdd.count())
    //接口






    //ky.ods_sxne.hs_gis_feedback.last_gis_sn=dm_gis.ods_gis_ass_eds_sx.sn
    val nextRdd = runRdd.map(o => (JSONUtil.getJsonVal(o, "last_gis_sn", ""), o)).leftOuterJoin(logInfoRdd)
      .map(o => {
        val right = o._2._2
        val left = o._2._1
        if (right.nonEmpty) {
          val rightObejct = right.get
          left.put("codesorce", JSONUtil.getJsonVal(rightObejct, "codesorce", ""))
          left.put("tag_geo", JSONUtil.getJsonVal(rightObejct, "tag_geo", ""))
          left.put("req_x", JSONUtil.getJsonVal(rightObejct, "req_x", ""))
          left.put("req_y", JSONUtil.getJsonVal(rightObejct, "req_y", ""))
          left.put("code_name", JSONUtil.getJsonVal(rightObejct, "code_name", ""))
          left.put("areaSource", JSONUtil.getJsonVal(rightObejct, "areaSource", ""))
          left.put("edsBody", rightObejct)
        }
        val ewb_sign_site_code = JSONUtil.getJsonVal(left, "ewb_sign_site_code", "")
        val order_source = JSONUtil.getJsonVal(left, "order_source", "")
        val gis_identify_site_code = JSONUtil.getJsonVal(left, "gis_identify_site_code", "")
        if (ewb_sign_site_code.nonEmpty && gis_identify_site_code.equals(ewb_sign_site_code)) left.put("tag", "same")
        else if(Array("回单一键开单","新单返货","原单返货").contains(order_source))left.put("tag", "special_order")



        left
      }).persist(StorageLevel.MEMORY_AND_DISK)

    val nextRdd1 = nextRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd1 = nextRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("ewb_sign_site_code跟gis_identify_site_code相等的数据量:" + unionRdd1.count())
    logger.error("ewb_sign_site_code跟gis_identify_site_code不相等的数据量:" + nextRdd1.count())
    nextRdd.unpersist()
    logger.error("顺心收派签收数据")

    val reNum2 =nextRdd1.count().toInt
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "391395", "顺心准确率统计_ShunxinNew", "顺心准确率统计", shunxin_dept_url_v3, "", reNum2,common_partition)
    val gisRdd: RDD[JSONObject] = runGisDept(nextRdd1).map(o => {
      val ewb_sign_site_code = JSONUtil.getJsonVal(o, "ewb_sign_site_code", "")
      val codeNew = JSONUtil.getJsonVal(o, "codeNew", "")
      if (codeNew.nonEmpty && ewb_sign_site_code.equals(codeNew)) o.put("tag", "same_new")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    BdpTaskRecordUtil.endNetworkInterface("01412406",httpInvokeId2)



    val nextRdd2 = gisRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd2 = gisRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("codeNew跟ewb_sign_site_code相等的数据量:" + unionRdd2.count())
    logger.error("codeNew跟ewb_sign_site_code不相等的数据量:" + nextRdd2.count())
    gisRdd.unpersist()

    val next3 = checkWdDetail(nextRdd2, sxDeptBc)

    val nextRdd3 = next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd3 = next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("artificiaChooseSit的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("artificiaChooseSit")).count())
    logger.error("signAddressKeyWord的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("signAddressKeyWord")).count())
    logger.error("addressNumber的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("addressNumber")).count())
    logger.error("signTownKeyWord的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("signTownKeyWord")).count())
    logger.error("specialEwb的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("specialEwb")).count())
    logger.error("specialZc的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("specialZc")).count())
    logger.error("blindSpot的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("blindSpot")).count())
    logger.error("signCodeKeyWord的数据量" + next3.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("signCodeKeyWord")).count())

    logger.error("不需要调用切词服务的数据量:" + unionRdd3.count())
    logger.error("调用切词服务的数据量:" + nextRdd3.count())
    next3.unpersist()
    val reNum = nextRdd3.count().toInt
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01412406", "391395", "顺心准确率统计_ShunxinNew", "顺心准确率统计", split_url, "", reNum,common_partition)
    val (unionRdd4, nextRdd4) = splitData(nextRdd3)
    BdpTaskRecordUtil.endNetworkInterface("01412406",httpInvokeId)
    val checkRdd = checkWdDetail2(nextRdd4)

    val reRdd = checkRdd.union(unionRdd4).union(unionRdd3).union(unionRdd2).union(unionRdd1).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("打完标签的数据量" + reRdd.count())

    logger.error("tag标签有值的数据量" + reRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).count())
    logger.error("未打tag的数据量" + reRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).count())
    reRdd

  }

  def queryShunXinCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql = "select name, regcode from dm_gis.city_adcode_map_shunxin "
    val dataMap = spark.sql(sql).rdd.map(obj => {
      (obj.getString(0), obj.getString(1))
    }).collectAsMap()
    logger.error("顺心城市表数量:" + dataMap.size)
    val shunxinCityMapBc = spark.sparkContext.broadcast(dataMap)
    shunxinCityMapBc
  }


  def saveDetail(spark: SparkSession, checkOverRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    val rowDf = checkOverRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("数量：" + rowDf.count())
    val tableName = "dm_gis.shunxin_detail_di_new" //生产
    logger.error("明细表表名" + tableName)
    rowDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
  }


  def runGisDept(signCheckRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val gisDeptRdd = signCheckRdd.repartition(seg_partition).mapPartitions(row => {
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      row.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }


        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= seg_ak_limit) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
       val (ret, uid, codeNew, chnameNew, codeSourceNew, cityNew, provinceNew, countyNew, townNew, areaSourceNew, cityCodeNew, deptNotCover) = runGisDeptDetail(shunxin_dept_url_v3, JSONUtil.getJsonVal(obj, "ewb_sign_address", ""))

        obj.put("codeNew", codeNew.trim)
        obj.put("ChnameNew", chnameNew)
        obj.put("codeSourceNew", codeSourceNew)
        obj.put("cityNew", cityNew)
        obj.put("countyNew", countyNew)
        obj.put("townNew", townNew)
        obj.put("areaSourceNew", areaSourceNew)
        obj.put("cityCodeNew", cityCodeNew)
        obj.put("gisDeptBody", ret)
        obj.put("provinceNew", provinceNew)
        obj.put("uid", uid)
        obj.put("sxDeptNotCover", deptNotCover.toString)
        obj
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("网点")
    gisDeptRdd
  }


  def querySxDept(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql =
      """
        |select code_eff_sign,banner_sign,extend_attrs_sign from (
        |select code as code_eff_sign
        |,banner as banner_sign
        |,extend_attrs as extend_attrs_sign
        |,row_number()over(distribute by code sort by update_date desc) rn
        |from dm_gis.emap_layer_feature
        |where layer_id='17'
        |)a where rn = 1

      """.stripMargin
    logger.error(sql)
    val SxDeptRdd = SparkUtils.getRowToJson(spark, sql).repartition(sql_partition).persist(StorageLevel.MEMORY_AND_DISK)

    val data = SxDeptRdd.map(o => {
      val code_eff_sign = JSONUtil.getJsonVal(o, "code_eff_sign", "")
      val banner_sign = JSONUtil.getJsonVal(o, "banner_sign", "")
      val extend_attrs_sign = JSONUtil.getJsonVal(o, "extend_attrs_sign", "")

      (code_eff_sign,s"""${code_eff_sign}&&${banner_sign}&&${extend_attrs_sign}""")
    }).collectAsMap()
    val dataMap = spark.sparkContext.broadcast(data)
    dataMap
  }


  def querySxLoginfo(spark: SparkSession, incDay: String) = {

    val startDay = incDay.replaceAll("-", "") //20210823
    val endDay = DateUtil.getDateStr(startDay, -50, "") //2021-08-24
    val s = "$"
    val sql =
      s"""
        |select
        |get_json_object(get_json_object(log, '${s}.message'), '${s}.sn') sn,
        |get_json_object(get_json_object(log, '${s}.message'), '${s}.type') req_type,
        |get_json_object(get_json_object(log, '${s}.message'), '${s}.time') url_time,
        |get_json_object(get_json_object(log, '${s}.message'), '${s}.appName') appName,
        |get_json_object(get_json_object(log, '${s}.message'), '${s}.dateTime') req_time,
        |get_json_object(get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),'${s}.src') req_src,
        |get_json_object(get_json_object(log, '${s}.fields'), '${s}.log_topics') log_topics,
        |regexp_replace(get_json_object(  get_json_object(log, '${s}.message'),  '${s}.url.address'),'[\r\n\t]+',''   ) req_address,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.sxData.code'   ) code,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.sxData.codeSource'   ) codesorce,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.sxData.tag'   ) tag_geo,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.uid'   ) gis_aoiid,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.province'   ) province,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.city'   ) city,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.county'   ) county,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.town'   ) town,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.cityCode'   ) citycode,
        |get_json_object(get_json_object(  get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),  '${s}.result'),'${s}.areaData.acreage'   ) acreage,
        |get_json_object(get_json_object(get_json_object(get_json_object(log, '${s}.message'), '${s}.data'),'${s}.result'),'${s}.msg') msg,
        |get_json_object(get_json_object(get_json_object(get_json_object(log,'${s}.message'),'${s}.data'),'${s}.result'),'${s}.sxData.x') as req_x,
        |get_json_object(get_json_object(get_json_object(get_json_object(log,'${s}.message'),'${s}.data'),'${s}.result'),'${s}.sxData.y') as req_y,
        |get_json_object(get_json_object(get_json_object(get_json_object(log,'${s}.message'),'${s}.data'),'${s}.result'),'${s}.sxData.chName') as code_name,
        |get_json_object(get_json_object(get_json_object(get_json_object(log,'${s}.message'),'${s}.data'),'${s}.result'),'${s}.areaData.areaSource') as areaSource,
        |inc_day as eds_inc_day
        |from
        |dm_gis.ods_gis_ass_eds_sx
        |where inc_day between  '${endDay}'   and  '${startDay}'
        |--and get_json_object(get_json_object(log, '${s}.message'), '${s}.type') = 'url_e'
        |and get_json_object( get_json_object(get_json_object(log,'${s}.message'),'${s}.url'), '${s}.ak' )in( 'c4066396181d4041bbe63bf5f1607d5f', 'b4efd075905f4dfe9e3624884c0a70b6' )
        |and get_json_object(get_json_object(log,'${s}.message'),'${s}.type')='url_e'
        |and get_json_object(get_json_object(get_json_object(log,'${s}.message'),'${s}.url'),'${s}.url') not like'%sx/vas/%'
      """.stripMargin
//    val foematSql = String.format(sql, endDay, startDay)
    logger.error(sql)
    val logInfoRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJson(spark, sql).repartition(2000)
      .map(o => (JSONUtil.getJsonVal(o, "sn", ""), o)).filter(_._1.nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("日志表的数据量:" + logInfoRdd.count())
    logger.error(logInfoRdd.take(3).foreach(println(_)))
    logInfoRdd
  }


  def startSta(spark: SparkSession, incDay: String, v3CityCodeArrayBc: Broadcast[Array[String]]): Unit = {
    logger.error("获取城市映射")
    val shunxinCityMapBc = queryShunXinCityMap(spark)
    logger.error("获取顺心收派签收数据")
    val signCheckRdd = querySignData(spark, incDay, shunxinCityMapBc, v3CityCodeArrayBc)
    logger.error("获取顺心网点数据")
    val sxDeptBc = querySxDept(spark)
    //    logger.error("顺心收派签收数据")
    //    val signCheckRunGis = runGisDept(signCheckRdd)

    logger.error("获取顺心日志表")
    val logInfoRdd: RDD[(String, JSONObject)] = querySxLoginfo(spark, incDay)


    logger.error("获取网点变更表数据")
    val netChangeRdd = getNetChangeRdd(spark, incDay).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("网点变更表数据量" + netChangeRdd.count())
    netChangeRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })


    logger.error("开始错分判断流程")
    val checkOverRdd = checkWdData(spark,signCheckRdd, netChangeRdd, sxDeptBc, logInfoRdd)
    logger.error("错分判断流程结束")

    logger.error("获取城市映射表")
    val cityMapBc = queryCityMap(spark)
    logger.error("获取城市映射表结束")
    logger.error("开始统计")
    val staIndexRdd: RDD[(ShunxinCover, mult)] = staIndex(checkOverRdd, cityMapBc)
    logger.error("统计完毕")

    logger.error("入库指标数据")
    saveStaIndex(spark, staIndexRdd, incDay)
    logger.error("入库指标完毕")
    logger.error("入库明细开始")
    saveDetail(spark, checkOverRdd, incDay)
    logger.error("入库明细完毕")
    logger.error("开始解析")
    analysisRdd(spark, checkOverRdd, incDay)
    logger.error("处理结束")


  }


  //取网点变更表数据
  def getNetChangeRdd(spark: SparkSession, incDay: String) = {

    val dataSql =
      s"""
         |	select
         |	       old_codes,
         |        new_codes,
         |        type,
         |        update_date
         |from
         |(
         |    select
         |        old_codes,
         |        new_codes,
         |        type,
         |        update_date,
         |        row_number() over(partition by old_codes, new_codes order by update_date desc) as row_cnt
         |    from dm_gis.emap_feature_change_record
         |    where layer_id = 17
         |    and status = 6
         |    and type in (2)
         |    and update_date between
         |        from_unixtime(unix_timestamp(date_add(current_date, -7), 'yyyyMMdd'), 'yyyy-MM-dd 00:00:00')
         |        and from_unixtime(unix_timestamp(current_date), 'yyyy-MM-dd 00:00:00')
         |        and  inc_day = '${incDay}'
         |) a
         |where row_cnt = 1
      """.stripMargin
    logger.error(dataSql)

    val NetChange = SparkUtils.getRowToJson(spark, dataSql).map(obj => {
      val new_codes = JSONUtil.getJsonVal(obj, "new_codes", "")
      val old_codes = JSONUtil.getJsonVal(obj, "old_codes", "")
      ((new_codes, old_codes), obj)
    })
    NetChange

  }

  def start(startDay: String, days: Int, v3CityCodeArray: Array[String], fromDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    val v3CityCodeArrayBc = spark.sparkContext.broadcast(v3CityCodeArray)
    spark.sparkContext.setLogLevel("ERROR")

    //    fromDay:跑数时间 yyyy-mm-dd

    //    for (i <- 0 until days) {
    val incDay = DateUtil.getDateStr(startDay, 0, "") //-7 yyyy-mm-dd

    logger.error(s"开始计算：incDay:${incDay}")
    startSta(spark, incDay, v3CityCodeArrayBc)
    logger.error("计算结束：" + incDay)
    //    }
    logger.error("统计完毕")
  }

  //日志解析
  def analysisRdd(spark: SparkSession, dataRdd: RDD[JSONObject], incDay: String) = {


    import spark.implicits._

    logger.error("解析的数据量" + dataRdd.count())

    val finalRdd = dataRdd.map(obj => {
      var extend_attrs_sign = JSONUtil.getJsonVal(obj, "extend_attrs_sign", "")
      var extend_attrs_gis = JSONUtil.getJsonVal(obj, "extend_attrs_gis", "")
      val signObject = JSONUtil.parseJSONObject(extend_attrs_sign)
      val gisObject = JSONUtil.parseJSONObject(extend_attrs_gis)

      detail(
        JSONUtil.getJsonVal(obj, "waybill_no", "")
        , JSONUtil.getJsonVal(obj, "gis_identify_site_code", "")
        , JSONUtil.getJsonVal(obj, "ewb_sign_site_code", "")
        , JSONUtil.getJsonVal(obj, "ewb_dispatch_site", "")
        , JSONUtil.getJsonVal(obj, "sign_province_name", "")
        , JSONUtil.getJsonVal(obj, "sign_city_name", "")
        , JSONUtil.getJsonVal(obj, "sign_county_name", "")
        , JSONUtil.getJsonVal(obj, "sign_town_name", "")
        , JSONUtil.getJsonVal(obj, "ewb_created_time", "")
        , JSONUtil.getJsonVal(obj, "sign_created_time", "")
        , JSONUtil.getJsonVal(obj, "artificial_choose_site", "")
        , JSONUtil.getJsonVal(obj, "artificial_province_name", "")
        , JSONUtil.getJsonVal(obj, "artificial_city_name", "")
        , JSONUtil.getJsonVal(obj, "artificial_county_name", "")
        , JSONUtil.getJsonVal(obj, "artificial_town_name", "")
        , JSONUtil.getJsonVal(obj, "special_ewb", "")
        , JSONUtil.getJsonVal(obj, "gd_latitude_and_longitude", "")
        , JSONUtil.getJsonVal(obj, "created_time", "")
        , JSONUtil.getJsonVal(obj, "modify_time", "")
        , JSONUtil.getJsonVal(obj, "matching_map_type", "")
        , JSONUtil.getJsonVal(obj, "last_gis_sn", "")
        , JSONUtil.getJsonVal(obj, "gis_back_province_name", "")
        , JSONUtil.getJsonVal(obj, "gis_back_city_name", "")
        , JSONUtil.getJsonVal(obj, "gis_back_county_name", "")
        , JSONUtil.getJsonVal(obj, "gis_back_town_name", "")
        , JSONUtil.getJsonVal(obj, "gis_identify_site_address", "")
        , JSONUtil.getJsonVal(obj, "ewb_sign_address", "")
        , JSONUtil.getJsonVal(obj, "feedback_inc_day", "")
        , JSONUtil.getJsonVal(obj, "edsBody.sn", "")
        , JSONUtil.getJsonVal(obj, "edsBody.req_type", "")
        , JSONUtil.getJsonVal(obj, "edsBody.url_time", "")
        , JSONUtil.getJsonVal(obj, "edsBody.appName", "")
        , JSONUtil.getJsonVal(obj, "edsBody.req_time", "")
        , JSONUtil.getJsonVal(obj, "edsBody.req_src", "")
        , JSONUtil.getJsonVal(obj, "edsBody.log_topics", "")
        , JSONUtil.getJsonVal(obj, "edsBody.req_address", "")
        , JSONUtil.getJsonVal(obj, "edsBody.code", "")
        , JSONUtil.getJsonVal(obj, "edsBody.codesorce", "")
        , JSONUtil.getJsonVal(obj, "edsBody.tag_geo", "")
        , JSONUtil.getJsonVal(obj, "edsBody.gis_aoiid", "")
        , JSONUtil.getJsonVal(obj, "edsBody.province", "")
        , JSONUtil.getJsonVal(obj, "edsBody.city", "")
        , JSONUtil.getJsonVal(obj, "edsBody.county", "")
        , JSONUtil.getJsonVal(obj, "edsBody.town", "")
        , JSONUtil.getJsonVal(obj, "edsBody.citycode", "")
        , JSONUtil.getJsonVal(obj, "edsBody.acreage", "")
        , JSONUtil.getJsonVal(obj, "edsBody.msg", "")
        , JSONUtil.getJsonVal(obj, "edsBody.eds_inc_day", "")
        , JSONUtil.getJsonVal(obj, "codeNew", "")
        , JSONUtil.getJsonVal(obj, "ChnameNew", "")
        , JSONUtil.getJsonVal(obj, "codeSourceNew", "")
        , JSONUtil.getJsonVal(obj, "provinceNew", "")
        , JSONUtil.getJsonVal(obj, "cityNew", "")
        , JSONUtil.getJsonVal(obj, "countyNew", "")
        , JSONUtil.getJsonVal(obj, "townNew", "")
        , JSONUtil.getJsonVal(obj, "cityCodeNew", "")
        , JSONUtil.getJsonVal(obj, "areaSourceNew", "")
        , JSONUtil.getJsonVal(obj, "uid", "")
        , JSONUtil.getJsonVal(obj, "code_eff_sign", "")
        , JSONUtil.getJsonVal(obj, "banner_sign", "")
        , JSONUtil.getJsonVal(obj, "extend_attrs_sign", "")
        , JSONUtil.getJsonVal(signObject, "sxType", "")
        , JSONUtil.getJsonVal(signObject, "sxDistrict", "")
        , JSONUtil.getJsonVal(signObject, "sxOrgStatus", "")
        , JSONUtil.getJsonVal(signObject, "sxDispThingStatus", "")
        , JSONUtil.getJsonVal(signObject, "sxOrgMainStatus", "")
        , JSONUtil.getJsonVal(obj, "code_eff_gis", "")
        , JSONUtil.getJsonVal(obj, "banner_gis", "")
        , JSONUtil.getJsonVal(obj, "extend_attrs_gis", "")
        , JSONUtil.getJsonVal(gisObject, "sxType", "")
        , JSONUtil.getJsonVal(gisObject, "sxDistrict", "")
        , JSONUtil.getJsonVal(gisObject, "sxOrgStatus", "")
        , JSONUtil.getJsonVal(gisObject, "sxDispThingStatus", "")
        , JSONUtil.getJsonVal(gisObject, "sxOrgMainStatus", "")
        , JSONUtil.getJsonVal(obj, "tag", "")
        , JSONUtil.getJsonVal(obj, "req_x", "")
        , JSONUtil.getJsonVal(obj, "req_y", "")
        , JSONUtil.getJsonVal(obj, "code_name", "")
        , JSONUtil.getJsonVal(obj, "areaSource", "")
        , JSONUtil.getJsonVal(obj, "wb_waybill1_no", "")
        , JSONUtil.getJsonVal(obj, "return_ewb_no", "")
        , JSONUtil.getJsonVal(obj, "order_source", "")
      )
    }).toDF().repartition(20).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("入库的数据量：" + finalRdd.count())

    finalRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })

    val tableName = "dm_gis.shunxin_detail_di_jx_new"
//    val tableName = "dm_gis.shunxin_detail_di_jx_new_tmp"
    finalRdd.withColumn("partition_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("解析数据入库完毕")
  }

  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val days = args.apply(1).toInt
    val fromDay = args.apply(3)
    val v3CityCodeArray = args.apply(2).split(",")
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days, v3CityCodeArray, fromDay)
    logger.error("结束所有运行")
  }


}
