package com.sf.gis.scala.sx.shunxin

import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.sx.util.{SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._




object tcAoiInit {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
//  val limitMin = 40
  val Url = "http://10.119.72.206:8086/data/aoiSdk/getWktAreaNew"
  //新表数据
  case class dataNew(geomWkt:String,code:String,req:String,aoiList:String)
  def main(args: Array[String]): Unit = {

    //获取
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val incDay = args(0)
    logger.error("开始执行")

    run(spark,incDay)
    logger.error("开始结束")

//    //入库
//    reDf.write.mode(SaveMode.Overwrite).saveAsTable("tmp_dm_gis.tmp_res2")
////    spark.table("tmp_dm_gis.deppon_address_remove_conf_new").write.mode(SaveMode.Overwrite).insertInto("tmp_dm_gis.tmp_res3")
////    spark.table("tmp_dm_gis.tmp_res2").write.mode(SaveMode.Overwrite).insertInto("tmp_dm_gis.deppon_address_remove_conf_new2")
//    spark.table("tmp_dm_gis.tmp_res2").write.mode(SaveMode.Overwrite).insertInto("deppon_address_remove_conf_new")
//    logger.error("压数完成")

  }
  //获取新的Tc
  def getDataNew(spark :SparkSession) ={

    //获取现有tc关联aoi表

    var count = 1
    val dataNewSql =
      """
        |select geom_wkt
        |,code
        |from dm_gis.emap_layer_feature where  layer_id ='3'
        |group by geom_wkt,code
      """.stripMargin

    logger.error(dataNewSql)

    val dataNew = SparkUtils.getRowToJson(spark,dataNewSql)

    logger.error("获取new表数据量："+dataNew.count())
    //调取接口获取数据
    val res = dataNew.repartition(1).map(obj=>{
      var httpData: util.Map[String, AnyRef] = null
      val wkt = JSONUtil.getJsonVal(obj,"geom_wkt","")
      if(!wkt.isEmpty){
        val param = new JSONObject()
        param.put("score","75")
        param.put("wkt",wkt)
        val startTime = new StratTime(System.currentTimeMillis())
        val cnt = new Cnt(0)
        httpData =  HttpConnection.sendPost(Url, param.toJSONString)
//        SparkUtils.limitAkUse(startTime, cnt,1, limitMin, logger)

        while (!httpData.getOrDefault("code","").equals("1") && count < 3){
          count=count+1
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep(60 - second)
          httpData =  HttpConnection.sendPost(Url, param.toJSONString)

        }


        if (httpData.get("content") != null ) {
          val content = httpData.get("content").toString
          val  req = JSON.parseObject(content)

          obj.put("req",req)

          val reqJsonArray = try{
            req.getJSONArray("data").getJSONObject(0).getJSONArray("aois")
          }catch {
            case _=> null
          }



          if(reqJsonArray != null && reqJsonArray.size() > 0 ){
            var res = ""

            for(i <- Range(0,reqJsonArray.size())) yield{
              val s = try{ reqJsonArray.getJSONObject(i).getString("id") }catch {case _ => "" }
              if(i == reqJsonArray.size()-1){
                res = res+s
              }else{
                res =  res+s+"|"
              }
            }
            obj.put("aoiList",res)




          }
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("调取接口获取到aoi的数据量："+res.filter(obj=>{!JSONUtil.getJsonVal(obj,"aoiList","").isEmpty()}).count())
    res.take(5).foreach(obj=>{logger.error(obj.toJSONString)})
    res
  }


  def run(spark:SparkSession,incDay:String) ={
    //获取现有tc关联aoi表
    val beginDf = spark.read.option("inferschema", "true")
      .option("head", "true")
      .option("delimiter", ",")
      .option("encoding", "UTF-8")
      .csv("/user/01412406/upload/debangtc.csv")
      .toDF("id","tc","type","aoilist","city_code","statu","createuser","createtime","modifyuser","modifytime")
      .select("tc","aoilist").repartition(100).persist(StorageLevel.MEMORY_AND_DISK)



    //获取最新aoi与tc关系data_new
    import spark.implicits._
    val dataNewDf1 = getDataNew(spark).map(obj=>{
      //geom_wkt,code,req,aoiList
      val geomWkt = JSONUtil.getJsonVal(obj,"geom_wkt","")
      val code = JSONUtil.getJsonVal(obj,"code","")
      val req = JSONUtil.getJsonVal(obj,"req","")
      val aoiList = JSONUtil.getJsonVal(obj,"aoiList","")
      dataNew(geomWkt,code,req,aoiList)
    }).repartition(100).toDF("geomWkt","code","req","aoiList")




    //获取aoi
    val bgDf = beginDf.withColumn("aoi",explode(split('aoilist,"\\|"))).persist(StorageLevel.MEMORY_AND_DISK)


    val dataNewDf= dataNewDf1
      .withColumn("aoi",explode(split('aoiList,"\\|")))
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(bgDf.show(10,false))
    bgDf.createOrReplaceTempView("data_old")
    dataNewDf.createOrReplaceTempView("data_new")


    //取出接口新数据不在旧表的部分
//    val cfSql =
//      """
//        |select
//        | a.aoi
//        |,a.code as tccode
//        |from data_new a
//        |left join data_old b
//        |on a.aoi = b.aoi
//        |where b.aoi is null and a.aoi is not null
//        |group by a.aoi
//        |,a.code
//      """.stripMargin


    val disDataOldSql =
      """
        |select
        |a.aoi
        |from data_old a
        |group by
        |a.aoi
      """.stripMargin
    val DataOld  = spark.sql(disDataOldSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("data_old的数量："+DataOld.count())
    logger.error(DataOld.show(10,false))


    val disDataNewSql =
      """
        |select
        |a.aoi
        |,a.code
        |from data_new a
        |group by
        |a.aoi
        |,a.code
      """.stripMargin
    val DataNew  = spark.sql(disDataNewSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(DataNew.show(10,false))
    logger.error("data_new的数量："+DataNew.count())


    DataOld.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.tcAoi_relationship_init_old_di")
    DataNew.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.tcAoi_relationship_init_new_di")



    DataOld.createOrReplaceTempView("DataOld")
    DataNew.createOrReplaceTempView("DataNew")




    val cfSql =
      """
        |select
        |  a.aoi
        |,a.code as tccode
        |from DataNew a
        |left join DataOld b
        |on a.aoi = b.aoi
        |where b.aoi is null
      """.stripMargin

    val resultDf  = spark.sql(cfSql).persist(StorageLevel.MEMORY_AND_DISK)

    //跑更新接口 8.5号
    logger.error(s"获取文件数：${resultDf.count()}:"+resultDf.show(2,false))


    logger.error("开始入库："+incDay)
    resultDf.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.tcAoi_relationship_init_di")
    logger.error("入库完成："+incDay)
  }

}
