package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.sx.constant.util.HttpConnection
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.sx.util.{DateUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object ShunxinShenbu {
  @transient lazy val logger: Logger = Logger.getLogger(ShunxinShenbu.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200


  val xy_dept_url = "http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?ak=1245f89114fb4f5e896213904b4923a5&lng=%s&lat=%s&sys_type=SX"
  //  val mapUrl = "http://10.220.13.63:1080/atdispatch/api?ak=c274bbf7007c411c8e21a6abe31a9886&opt=norm&city=%s&address=%s"
  val sxUrl = "http://gis-ass-dqs.sf-express.com/emap/api/efs/getEfsBusiFeatureByAoiMaxOne?aoiId=%s&layerAbbr=SX"
  //  val rzUrl = "http://10.220.13.63:1080/atdispatch/api?ak=dec044d089524419b371bc94555c539d&opt=normdetail&city=%s&address=%s"
  //  val rzUrl = "http://10.220.21.90:1080/atdispatch/api?address=%s&city=%s&ak=c274bbf7007c411c8e21a6abe31a9886&opt=norm&company="
  //  val rzUrl ="http://10.220.21.90:1080/atdispatch/api?address=%s&city=%s&ak=c274bbf7007c411c8e21a6abe31a9886&opt=Zh&company="
  val rzUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&geom=0&ak=e6b53e609c2440c8b20b14552bab4e09&opt=aoi"
  val mapa_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=1245f89114fb4f5e896213904b4923a5"
  val mapb_url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=c274bbf7007c411c8e21a6abe31a9886&opt=normdetail&company="
  //更新接口
  val updateUrl = "http://gdssexpress-gis-ass-gdss.dcn.k8s.sf-express.com/dispatch/api/edit"


  //  点落面服务接口：http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=113.936683&lat=22.532681&ak=8cb19f422db34736922479ba0bc848f4
  //  【入参】：【gd_x】和【mapa_x】传入【lng】，【gd_y】和【mapa_y】传入【lat】
  //  【出参】：【level】=3下的【code】记为【gd_tc】和【mapa_tc】
  //  val mapa_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=1245f89114fb4f5e896213904b4923a5"


  //  http://gis-int.intsit.sfdc.com.cn:1080/geo/api?ak=f14167603f8c48acbb31655a2f987578&opt=gd2&address={address}&city={city}
  val ts_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=gd2&ak=1245f89114fb4f5e896213904b4923a5"

  //  #地理编码测试接口 图商
  //  #sj_ts_url =http://gis-int.intsit.sfdc.com.cn:1080/geo/api?ak=f14167603f8c48acbb31655a2f987578&opt=gd2&address=%s&city=%s

  case class result(
                     city_code: String
                     , address: String
                     , check_x: String
                     , check_y: String
                     , zno_code: String
                     , check_date: String
                     , incday: String
                     , detail: String
                   )

  case class resultWorld(
                           city_code: String
                            , zno_code: String
                            , address: String
                            , inc_day: String
                        )


  case class recovery(
                       address: String,
                       city_code: String,
                       tag: String,
                       aoi_sxcode: String,
                       ts_sxcode: String,
                       precision_gd: String,
                       sx_code: String,
                       check_date_cgcs: String,
                       check_date: String,
                       check_x: String,
                       check_y: String,
                       detail: String
                     )



  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")


  }

  //  startDay 取t-1
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }

  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val incDay1 = DateUtil.getDateStr(incDay, -7, "")
    val (dataRdd, joinRdd) = getDataDf(spark, incDay,incDay1)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("打tag标签")

    //打tag
    val tagRdd = checkTag(dataRdd)
    logger.error(tagRdd.take(10).foreach(println(_)))

    //update的数据更新接口
    logger.error("調接口更新數據")
    val finRdd = upData(tagRdd)
    finRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })

    val resRdd=
      finRdd.repartition(sqlpartition).map(obj => ((JSONUtil.getJsonVal(obj, "address", ""), obj)))
        .leftOuterJoin(joinRdd)
        .map(obj => {
          if (obj._2._2.isEmpty) {
            (obj._2._1, true)
          } else {
            obj._2._1.put("joinData", obj._2._2.get)
            (obj._2._1, false)
          }

        }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("开始入库")
    //入库
    saveTable(spark, resRdd, incDay)

    saveWorldTable(spark,resRdd,incDay)
    logger.error("结束所有运行")

  }


  def checkTag(dataRdd: RDD[JSONObject]) = {
    logger.error("打tag的数据量：" + dataRdd.count())


    val artificialRdd = dataRdd.filter(JSONUtil.getJsonVal(_,"tag","").equals("artificial")).persist(StorageLevel.MEMORY_AND_DISK)
    val notArtificialRdd = dataRdd.filter(!JSONUtil.getJsonVal(_,"tag","").equals("artificial")).persist(StorageLevel.MEMORY_AND_DISK)


    val nextRdd = notArtificialRdd.coalesce(5).map(obj => {
      //审补xy获取网点
      val sbx = JSONUtil.getJsonVal(obj, "check_x", "")
      val sby = JSONUtil.getJsonVal(obj, "check_y", "")
      val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val (sxCode, sxret) = xy2Dept(xy_dept_url, sbx, sby)
      obj.put("sx_code", sxCode)
      obj.put("sx_ret", sxret)

      //geo返回aoi,获取aoicode
      val (geoAoi, mapbRet, dept, geoAoiRet, aoiSxCode, aoiSxRet) = getAoiCode(sbx, sby, cityCode, address)


      obj.put("aoi_id", geoAoi)
      obj.put("mapb_ret", mapbRet)
      obj.put("geoaoiret", geoAoiRet)
      obj.put("aoi_sxcode", aoiSxCode)
      obj.put("aoi_sxret", aoiSxRet)
      obj.put("zno_code", dept)

      if (geoAoi != null && geoAoi.nonEmpty && sxCode.equals(aoiSxCode)) obj.put("tag", "correct")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val nextrdd1 = nextRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val UnionRdd1 = nextRdd.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("Sx_code=aoi_sxcode的数量：" + UnionRdd1.count())
    logger.error("precision_gd = 2.0的数量：" + nextrdd1.count())


    val resultRdd1 = nextrdd1.map(obj => {

      val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val sxCode = JSONUtil.getJsonVal(obj, "sx_code", "")
      val gdxyRet = runMapXyInteface(ts_url, cityCode, address)
      var gd_x = ""
      var gd_y = ""
      var precision_gd = ""
      var tsSxCode = ""
      var tsSxRet = ""

      //     ret.put("deptCode", deptCode)
      //     ret.put("deptRet", deptRet)

      if (gdxyRet != null) {
        gd_x = JSONUtil.getJsonVal(gdxyRet, "x", "")
        gd_y = JSONUtil.getJsonVal(gdxyRet, "y", "")
        precision_gd = JSONUtil.getJsonVal(gdxyRet, "precision", "")
        tsSxCode = JSONUtil.getJsonVal(gdxyRet, "deptCode", "")
        tsSxRet = JSONUtil.getJsonVal(gdxyRet, "deptRet", "")
      }

      obj.put("gd_x", gd_x)
      obj.put("gd_y", gd_y)
      obj.put("precision_gd", precision_gd)
      //      val (tsSxCode, tsSxRet) = xy2Dept(xy_dept_url, gd_x, gd_y)
      obj.put("ts_sxcode", tsSxCode)
      obj.put("ts_sxret", tsSxRet)
      obj.put("ts_sxxyret", gdxyRet)

      if (!sxCode.isEmpty && sxCode.equals(tsSxCode)) obj.put("tag", "correct")

      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)


    val nextRdd2 = resultRdd1.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val UnoinRdd2 = resultRdd1.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("precision_gd = 2.0的数量：" + UnoinRdd2.count())
    logger.error("调mapa获取点落面的数量：" + nextRdd2.count())


    //调mapa点落面
    val resultRdd2 = nextRdd2.map(
      obj => {
        val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
        val address = JSONUtil.getJsonVal(obj, "address", "")
        val precisionGd = JSONUtil.getJsonVal(obj, "precision_gd", "")
        val tsSxCode = JSONUtil.getJsonVal(obj, "ts_sxcode", "")
        val aoiSxCode = JSONUtil.getJsonVal(obj, "aoi_sxcode", "")


        val mapaXyRet = runMapXyInteface(mapa_url, cityCode, address)
        var mapax = ""
        var mapay = ""
        var precisionMapa = ""
        var mapaSxCode = ""
        var mapaSxRet = ""

        if (mapaXyRet != null) {
          mapax = JSONUtil.getJsonVal(mapaXyRet, "x", "")
          mapay = JSONUtil.getJsonVal(mapaXyRet, "y", "")
          precisionMapa = JSONUtil.getJsonVal(mapaXyRet, "precision", "")
          mapaSxCode = JSONUtil.getJsonVal(mapaXyRet, "deptCode", "")
          mapaSxRet = JSONUtil.getJsonVal(mapaXyRet, "deptRet", "")
        }

        obj.put("mapa_x", mapax)
        obj.put("mapa_y", mapay)
        obj.put("precision_mapa", precisionMapa)
        //      val (tsSxCode, tsSxRet) = xy2Dept(xy_dept_url, gd_x, gd_y)
        obj.put("mapa_sxcode", mapaSxCode)
        obj.put("mapa_sxret", mapaSxRet)
        obj.put("mapa_sxxyret", mapaXyRet)


        if ((mapaSxCode.nonEmpty && mapaSxCode.equals(tsSxCode) && precisionMapa.equals("2") && precisionGd.equals("2"))) {
          obj.put("tag", "update")
          obj.put("tag2", "mt")
        } else if (mapaSxCode.nonEmpty && mapaSxCode.equals(aoiSxCode) && precisionMapa.equals("2")) {
          obj.put("tag", "update")
          obj.put("tag2", "ma")
        } else if (tsSxCode.nonEmpty && tsSxCode.equals(aoiSxCode) && precisionGd.equals("2")) {
          obj.put("tag", "update")
          obj.put("tag2", "ta")
        }

        obj
      }
    ).persist(StorageLevel.MEMORY_AND_DISK)

    val nextRdd3 = resultRdd2.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val UnoinRdd3 = resultRdd2.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("update的数量：" + nextRdd3.count())
    logger.error("调sch_code的数量：" + UnoinRdd3.count())


    val finallRdd = nextRdd3.repartition(sqlpartition).map(obj => {
      if (JSONUtil.getJsonVal(obj, "zno_code", "").isEmpty) obj.put("tag", "sch_empty")
      else obj.put("tag", "work")
      obj
    }
    )


    val fRdd = finallRdd.union(UnoinRdd3).union(UnoinRdd2).union(UnionRdd1).union(artificialRdd).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("finallRdd：" + finallRdd.count())
    logger.error("UnoinRdd3总数据：" + UnoinRdd3.count())
    logger.error("UnoinRdd2总数据：" + UnoinRdd2.count())
    logger.error("UnionRdd1总数据：" + UnionRdd1.count())
    logger.error("总数据：" + fRdd.count())

    fRdd
  }


  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep((60 - second))
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""
            //点落面接口
            val (deptCode, deptRet) = xy2Dept(xy_dept_url, x, y)
            ret.put("deptCode", deptCode)
            ret.put("deptRet", deptRet)
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  def saveTable(spark: SparkSession, resRdd: RDD[(JSONObject, Boolean)] , incDay: String): Unit = {
    import spark.implicits._

    val tableName = "dm_gis.shunxinshenbu_detail_di" //生产数据表
    val recoveryTableName = "dm_gis.shunxinshenbu_detail_tmp_di" //关联下发数据回收表


    val detailRdd = resRdd.map(obj => {
      result(
        JSONUtil.getJsonVal(obj._1, "city_code", ""),
        JSONUtil.getJsonVal(obj._1, "address", ""),
        JSONUtil.getJsonVal(obj._1, "check_x", ""),
        JSONUtil.getJsonVal(obj._1, "check_y", ""),
        JSONUtil.getJsonVal(obj._1, "zno_code", ""),
        JSONUtil.getJsonVal(obj._1, "check_date", ""),
        JSONUtil.getJsonVal(obj._1, "inc_day", ""),
        obj._1.toJSONString.replaceAll("[\\r\\n\\t]", "")
      )
    }
    ).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("入明细表数量：" + detailRdd.count())
    detailRdd.withColumn("inc_day",lit(DateUtil.getDateStr(incDay, 1, ""))).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("明细表入库完成")


    val recoveryDF = resRdd.filter(obj=>{JSONUtil.getJsonVal(obj._1,"tag","").equals("work")}).filter(!_._2)
      .map(obj => {
        recovery(
          JSONUtil.getJsonVal(obj._1, "address", ""),
          JSONUtil.getJsonVal(obj._1, "city_code", ""),
          JSONUtil.getJsonVal(obj._1, "tag", ""),
          JSONUtil.getJsonVal(obj._1, "aoi_sxcode", ""),
          JSONUtil.getJsonVal(obj._1, "ts_sxcode", ""),
          JSONUtil.getJsonVal(obj._1, "precision_gd", ""),
          JSONUtil.getJsonVal(obj._1, "sx_code", ""),
          JSONUtil.getJsonVal(obj._1, "joinData.check_date_cgcs", ""),
          JSONUtil.getJsonVal(obj._1, "check_date", ""),
          JSONUtil.getJsonVal(obj._1, "joinData.check_x", ""),
          JSONUtil.getJsonVal(obj._1, "joinData.check_y", ""),
          obj._1.toJSONString.replaceAll("[\\r\\n\\t]", "")
        )
      }).toDF().persist(StorageLevel.MEMORY_AND_DISK)
      logger.error("下发数据入回收备份表：" + recoveryDF.count())
    recoveryDF.withColumn("inc_day", lit(DateUtil.getDateStr(incDay, 1, ""))).write.mode(SaveMode.Overwrite).insertInto(recoveryTableName)
    logger.error("回收备份表入库完成")


//    val workRdd = resRdd.filter(_._2)
//      .map(obj => {
//        resultWorld(
//          JSONUtil.getJsonVal(obj._1, "city_code", ""),
//          JSONUtil.getJsonVal(obj._1, "address", "").replaceAll("快运|顺心|ky|sx", "**"),
//          JSONUtil.getJsonVal(obj._1, "check_x", ""),
//          JSONUtil.getJsonVal(obj._1, "check_y", ""),
//          JSONUtil.getJsonVal(obj._1, "zno_code", ""),
//          JSONUtil.getJsonVal(obj._1, "check_date", ""),
//          JSONUtil.getJsonVal(obj._1, "inc_day", ""),
//          obj._1.toJSONString.replaceAll("[\\r\\n\\t]", "")
//        )
//      }
//      ).toDF()

  }



  def saveWorldTable(spark: SparkSession, resRdd: RDD[(JSONObject, Boolean)] , incDay: String): Unit = {



    //剔除joinRdd的数据落world表
    val bufferRdd = resRdd.filter(obj=>{
      //增量数据 --cxg
//      JSONUtil.getJsonVal(obj._1,"tag","").equals("work")
      //初始要剔除手动下发部分数据：tag = Y
      JSONUtil.getJsonVal(obj._1,"tag","").equals("work") &&  JSONUtil.getJsonVal(obj._1,"address_tag","").equals("Y")
    }).filter(_._2).persist(StorageLevel.MEMORY_AND_DISK)
    //按zno_code从多到少排序
//    val sortMap =  bufferRdd.map(obj => (JSONUtil.getJsonVal(obj._1, "zno_code", ""),1)).reduceByKey(_+_).collectAsMap()

     val buffer= bufferRdd.map(obj =>{
       val  zno_code= JSONUtil.getJsonVal(obj._1, "zno_code", "")
       (zno_code,obj._1)
     }).collect().toList.toBuffer

    //分区
    val objects = reCut(buffer, incDay)

    import spark.implicits._


//  val workRdd =   spark.sparkContext.makeRDD(objects)
//      .map(obj => {
//        resultWorld(
//          JSONUtil.getJsonVal(obj, "city_code", ""),
//          JSONUtil.getJsonVal(obj, "address", "").replaceAll("快运|顺心|ky|sx", "**"),
//          JSONUtil.getJsonVal(obj, "check_x", ""),
//          JSONUtil.getJsonVal(obj, "check_y", ""),
//          JSONUtil.getJsonVal(obj, "zno_code", ""),
//          JSONUtil.getJsonVal(obj, "check_date", ""),
//          JSONUtil.getJsonVal(obj, "inc_day", ""),
//          obj.toJSONString.replaceAll("[\\r\\n\\t]", ""),
//          JSONUtil.getJsonVal(obj, "patitionDay", "")
//        )
//      }
//      ).toDF().persist(StorageLevel.MEMORY_AND_DISK)
//



    val workRdd =   spark.sparkContext.makeRDD(objects)
      .map(obj => {
        resultWorld(
          JSONUtil.getJsonVal(obj, "city_code", ""),
          JSONUtil.getJsonVal(obj, "zno_code", ""),
          JSONUtil.getJsonVal(obj, "address", "").replaceAll("快运|顺心|ky|sx", "**"),
          JSONUtil.getJsonVal(obj, "patitionDay", "")
        )
      }
      ).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //   city_code	string
//      zno_code	string
//      address	string
//      inc_day	string

    logger.error("入库下发人工作业明细表数据" + workRdd.count())
    workRdd.take(10).foreach(obj=>{logger.error(println(obj.toString()))})
//    val workTableName = "dm_gis.shunxinshenbu_work_di" //生产表
//    val workTableName = "dm_gis.shunxinshenbu_sxky_task_to_cgcs" //生产表
    val workTableName = "dm_gis.sxky_task_to_cgcs" //生产表
    workRdd.write.mode(SaveMode.Overwrite).insertInto(workTableName)
    logger.error("入库下发人工作业表入库完成")
  }

  //数据分配到不同分区
  def reCut(listBuffer:mutable.Seq[(String, JSONObject)], inc_day: String) = {
    //时间周期
    var runtag = 1
    logger.error(s"总数据=====》${listBuffer.take(20).toString()}《=====")

    var copyBuffer = listBuffer.clone()
    //均分数据
    var num = listBuffer.size/7


    val resList = new ListBuffer[JSONObject]

    while (copyBuffer.size > 0) {
      logger.error(s"copyBuffer的数量：${copyBuffer.size}")
      var count = 0
      //key集合
      val keyMap = new util.HashMap[String,Int]
      //剩下数据
      var resList2 = new ListBuffer[(String, JSONObject)]

      if (runtag < 7) {
        for (i <- 0 until copyBuffer.size) {
          //每个网点不超过十条
          val zone_code = copyBuffer(i)._1
          //网点计数
          var cv = 1

          if(keyMap.containsKey(zone_code)){
            cv =  keyMap.get(zone_code)+1
          }
          keyMap.put(zone_code,cv)
          logger.error(s"for的第${i}次")



          //每个分区总数小于60
          if (count < num && cv <= 10) {
//            val day = DateUtil.getDateStr(inc_day, 1*runtag, "")
            val day = DateUtil.getDateStr("20211017", -1*runtag, "")
            //设置时间分区
            val obj = copyBuffer(i)._2
            obj.put("patitionDay", day)
            resList.append(obj)
            count += 1
            logger.error(s"if里=====》第${i}次： keyMap：${keyMap.size()}  keyList:${keyMap.toString}  count的值：${count} inc_day的值 ${day} runtag的值 ${runtag} zone_code：${zone_code} cv: ${cv}")
          } else resList2.append(copyBuffer(i))
        }
        runtag += 1
      } else {
        for (i <- 0 until copyBuffer.size) {
//          val day = DateUtil.getDateStr(inc_day, 7, "")
          val day = DateUtil.getDateStr("20211017", -6, "")

          val obj = copyBuffer(i)._2
          val zone_code =copyBuffer(i)._1
          logger.error(s"else里=====》第${i}次： keyMap：${keyMap.size()}  keyList:${keyMap.toString}  count的值：${count} inc_day的值 ${day} runtag的值 ${runtag} zone_code：${zone_code}")
          obj.put("patitionDay", day)
          resList.append(obj)
        }
      }
      copyBuffer = resList2.clone()
    }
    logger.error(s"最终结果数量：${resList.size}")
    resList
  }


  def getDataDf(spark: SparkSession, incDay: String,incDay1: String) = {

    //数据源剔除下发表数据，取近7天增量数据 增量数据源--cxg
//    val dataSql =
//      s"""
//         |select
//         |city_code
//         |,address
//         |,check_x
//         |,check_y
//         |,check_date
//         |,address_md5
//         |,inc_day
//         |from (
//         |select
//         |a.check_city_code as city_code
//         |,a.address
//         |,a.check_x
//         |,a.check_y
//         |,a.check_date
//         |,a.inc_day
//         |,a.address_md5
//         |,row_number()over(distribute by a.address_md5 sort by a.check_date desc) rn
//         |from dm_gis.sx_work_detail_his a
//         |left join
//         |(
//         |select
//         |address_md5
//         |from
//         |dm_gis.sx_work_detail_his b
//         |where b.inc_day = '${incDay1}'
//         |group by address_md5
//         |)b
//         |on a.address_md5 = b.address_md5
//         |--left join
//         |--dm_gis.cgcss_misclassification_data_shunt b
//         |--on a.address = b.address
//         |--and b.operate_date = '20210926'
//         |where a.inc_day = '${incDay}'
//         |and (b.address_md5 is null or (b.address_md5 is not null and '${incDay1}' < a.check_date))
//         |--and b.address is null
//         |)a
//         |where rn = 1
//      """.stripMargin


    //全量数据
    val dataSql =
      s"""
        |
        |
        |select
        |city_code
        |,address
        |,check_x
        |,check_y
        |,check_date
        |,address_md5
        |,address_tag
        |,tag
        |,inc_day
        |from (
        |select
        |a.check_city_code as city_code
        |,a.address
        |,a.check_x
        |,a.check_y
        |,a.check_date
        |,a.inc_day
        |,a.address_md5
        |--剔除已下发的数据
        |,if(b.address is null ,"Y","N") as address_tag
        |--剔除手工下发
        |,if(c.checkaddress is not null,'artificial','') as tag
        |,row_number()over(distribute by a.address_md5 sort by a.check_date desc) rn
        |from dm_gis.sx_work_detail_his a
        |--剔除已下发的数据
        |left join
        |(
        |select
        |address
        |from default.qhz_net_0928
        |group by address
        |)b
        |on a.address = b.address
        |--剔除手工下发
        |left join
        |(
        |select  checkaddress
        |from default.shenbu_0926
        |group by checkaddress
        |
        |)c
        |on a.address = c.checkaddress
        |where a.inc_day = '${incDay}'
        |)a
        |where rn = 1
      """.stripMargin





    logger.error(dataSql)
    val totalRdd = SparkUtils.getRowToJson(spark, dataSql).repartition(sqlpartition)
    logger.error(totalRdd.take(10).foreach(println(_)))



    //下发表关联回收表入库
    val JoinSql =
      s"""
        |select
        | a.address
        |,c.check_date as check_date_cgcs
        |,c.check_x
        |,c.check_y
        |,row_number()over(partition by a.address order by a.inc_day desc) rn
        |from dm_gis.cgcss_misclassification_data_shunt a
        |left join
        |(
        |select
        |address
        |,check_date
        |,check_x
        |,check_y
        |from dm_gis.cghs_result_data c
        |where  c.source in ('chkn_WRONG_AOI_PN','norm_WRONG_AOI_SAME','norm_WRONG_AOI_PN') and inc_day = '${incDay}'
        |) c
        |on a.address = c.address
        |where a.operate_date = '${incDay}'
      """.stripMargin
    logger.error(JoinSql)
    val JoinRdd = SparkUtils.getRowToJson(spark, JoinSql).map(obj => {
      (JSONUtil.getJsonVal(obj, "address", ""), obj)
    }).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(JoinRdd.take(10).foreach(println(_)))

    (totalRdd, JoinRdd)
  }

  //点落面接口
  def xy2Dept(xyDeptUrl: String, lgt: String, lat: String): (String, JSONObject) = {
    var ret = null: JSONObject
    try {
      if (lgt != null && !lgt.isEmpty) {
        ret = HttpClientUtil.getJsonByGet(String.format(xyDeptUrl, lgt, lat))
        if (ret != null && ret.getJSONObject("result") != null) {
          if (ret.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return xy2Dept(xyDeptUrl, lgt, lat)
          }
          val mapArray = JSONUtil.getJsonArrayFromObject(ret, "result.map_data", null)
          if (mapArray != null && mapArray.size() > 0) {
            val code = JSONUtil.getJsonVal(mapArray.getJSONObject(0), "code", "")
            return (code, ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ("", ret)
  }

  //调mapb接口获取x,y
  def getmapBxy(mapb_url: String, cityCode: String, address: String) = {

    var x = ""
    var y = ""
    var gl_level = ""

    val obj = new JSONObject()
    var array: JSONArray = new JSONArray()

    //    mapb_url = http://10.220.13.63:1080/atdispatch/api?ak=8cb19f422db34736922479ba0bc848f4&opt=zh&city=&address=%s
    val reqObejct = HttpClientUtil.getJsonByGet(String.format(mapb_url, cityCode, URLEncoder.encode(address, "utf-8")), 3)
    if (reqObejct != null) {
      array = try {
        reqObejct.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder")
      }
      catch {
        case e: Exception => null
      }
      if (array != null && array.size() > 0) {
        val result = array.getJSONObject(0)
        x = JSONUtil.getJsonVal(result, "x", "")
        y = JSONUtil.getJsonVal(result, "y", "")
        gl_level = JSONUtil.getJsonVal(result, "level", "")
      }
      obj.put("mapbx", x)
      obj.put("mapby", y)
      obj.put("mapb_gl_level", gl_level)
      obj.put("mapbReq", reqObejct)
      obj
    }


    obj
  }


  //根据aoi获取aoicode
  def getAoiCode(x: String, y: String, cityCode: String, address: String) = {

    //    var city:Int = 0
    //    if(fomatCity.nonEmpty) city = fomatCity.toInt


    var sxAoiCode = ""
    var geoAoi = ""
    var dept = ""
    var ret: JSONObject = null

    val mapbRet = HttpClientUtil.getJsonByGet(String.format(mapb_url, URLEncoder.encode(address, "utf-8"), cityCode), 3)
    val geoAoiRet = HttpClientUtil.getJsonByGet(String.format(rzUrl, x, y), 3)






    //获取mapbaoi
    if (mapbRet != null) {


      geoAoi = try {
        mapbRet.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid")
      }
      catch {
        case e: Exception => ""

      }
    }




    //取zone_code
    if (geoAoiRet != null) {
      dept = try {
        geoAoiRet.getJSONObject("result").getJSONArray("data").getJSONObject(0).getString("zno_code")
      }
      catch {
        case exception: Exception => ""
      }

    }





    //获取顺心Aoicode
    if (geoAoi != null && !geoAoi.isEmpty) {
      //    mapb_url = http://10.220.13.63:1080/atdispatch/api?ak=8cb19f422db34736922479ba0bc848f4&opt=zh&city=&address=%s
      ret = HttpClientUtil.getJsonByGet(String.format(sxUrl, geoAoi))
      if (ret != null) sxAoiCode = JSONUtil.getJsonVal(ret, "data.code", "")
    }
    (geoAoi, mapbRet, dept, geoAoiRet, sxAoiCode, ret)
  }


  //调更新接口
  def upData(tagRdd: RDD[JSONObject]) = {

    val reqRdd = tagRdd.repartition(10).map(obj => {

      val tag = JSONUtil.getJsonVal(obj, "tag", "")
      val tag2 = JSONUtil.getJsonVal(obj, "tag2", "")
      val mapaX = JSONUtil.getJsonVal(obj, "mapa_x", "")
      val mapaY = JSONUtil.getJsonVal(obj, "mapa_y", "")
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val gdx = JSONUtil.getJsonVal(obj, "gd_x", "")
      val gdy = JSONUtil.getJsonVal(obj, "gd_y", "")
      val parm = new JSONObject()

      if (tag.equals("update") && (tag2.equals("mt") || tag2.equals("ma"))) {
        parm.put("checkAddress", address)
        parm.put("checkX", mapaX)
        parm.put("checkY", mapaY)
      } else if (tag.equals("update") && tag2.equals("ta")) {
        parm.put("checkAddress", address)
        parm.put("checkX", gdx)
        parm.put("checkY", gdy)
      }


      val httpData = HttpConnection.sendPost(updateUrl, parm.toJSONString)


      //          if (ret != null && ret.getJSONObject("result").getInteger("code") != 200) {
      //            val second = Calendar.getInstance().get(Calendar.SECOND)
      //            Thread.sleep(60 - second)
      //           httpData = HttpConnection.sendPost(updateUrl, parm.toJSONString)
      //          }
      obj.put("updataReq", httpData.getOrDefault("content", ""))
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    reqRdd
  }


}
