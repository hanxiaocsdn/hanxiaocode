package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.sx.constant.util.FileUtil
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.sx.util.{DateUtil, JSONUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01412406
  */
object ShunxinServiceInterLogInfo {

  @transient lazy val logger: Logger = Logger.getLogger(ShunxinServiceInterLogInfo.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.3
  println(version)




  case class mult(
                     cityCode: String
                   , city: String
                   , validcnt: Int
                   , gdsscnt: Int
                   , aoicnt: Int
                   , mapa_model_mapbcnt: Int
                   , mapa_model_gdcnt: Int
                   , mapa_model_bdcnt: Int
                   , mapa_mapb_gdcnt: Int
                   , mapa_mapb_bdcnt: Int
                   , mapa_gd_bdcnt: Int
                   , mapa_modelcnt: Int
                   , mapa_mapbcnt: Int
                   , mapa_gdcnt: Int
                   , mapa_bdcnt: Int
                   , Mapacnt: Int
                   , gd_bdcnt: Int
                   , threecnt: Int
                   , twocnt: Int
                   , sxsecond: Int
                   , sxsecond_false: Int
                   , sxrejectcnt: Int
                   , sxrejectcnt_gdss: Int
                   , sxrejectcnt_aoi: Int
                   , sxrejectcnt_mapa_model_mapb: Int
                   , sxrejectcnt_mapa_model_gd: Int
                   , sxrejectcnt_mapa_model_bd: Int
                   , sxrejectcnt_mapa_mapb_gd: Int
                   , sxrejectcnt_mapa_mapb_bd: Int
                   , sxrejectcnt_mapa_gd_bd: Int
                   , sxrejectcnt_mapa_model: Int
                   , sxrejectcnt_mapa_mapb: Int
                   , sxrejectcnt_mapa_gd: Int
                   , sxrejectcnt_mapa_bd: Int
                   , sxrejectcnt_Mapa: Int
                   , sxrejectcnt_gd_bd: Int
                   , finalwdcnt: Int
                   , finalwdgdsscnt: Int
                   , finalwdaoicnt: Int
                   , finalwdcnt_mapa_model_mapb: Int
                   , finalwdcnt_mapa_model_gd: Int
                   , finalwdcnt_mapa_model_bd: Int
                   , finalwdcnt_mapa_mapb_gd: Int
                   , finalwdcnt_mapa_mapb_bd: Int
                   , finalwdcnt_mapa_gd_bd: Int
                   , finalwdcnt_mapa_model: Int
                   , finalwdcnt_mapa_mapb: Int
                   , finalwdcnt_mapa_gd: Int
                   , finalwdcnt_mapa_bd: Int
                   , finalwdcnt_Mapa: Int
                   , finalwdcnt_gd_bd: Int
                   , finalwdcnt_three: Int
                   , finalwdcnt_two: Int
                   , artificiaChooseSit: Int
                   , signAddressKeyWordNumber: Int
                   , signTownKeyWord: Int
                   , signCodeKeyWord: Int
                   , specialEwbZc: Int
                   , blindSpot: Int
                   , splitLevelLess: Int
                   , townWrong: Int
                   , countyWrong: Int
                   , cityWrong: Int
                   , signCodeClose: Int
                   , gisCodeClose: Int
                   , signCodeInvalid: Int
                   , gisCodeInvalid: Int

                 )



//  address:运单地址
//  costTime:接口整体耗时
//  normalCostTime:规范化耗时
//  reqTime:请求日期（时间）
//  type:接口名称（区分v4和v5）
//  xyAreaCostTime:经纬度查四级地址切片耗时
//  xyCutCostTime:经纬度查顺心切片耗时
//  adCodeServerCostTime:adcodesever耗时
//  geoCostTime:geo耗时
//  atCostTime:AT派耗时
//  keywordCostTime:提关键词耗时（v5才有）
//  aoiCutCostTime:aoi查顺心切片的耗时
//  aoiAreaCostTime:aoi查四级地址切片耗时
//  requestId:sn





  def startSta(spark: SparkSession, incDay: String): Unit = {
    logger.error("数据解析")
    val sql =
      """
        |insert overwrite table dm_gis.shunxin_service_log_info_di partition(inc_day='%s')
        |select
        | get_json_object(get_json_object(log,'$.message'),'$.requestId') as sn
        |,get_json_object(get_json_object(log,'$.message'),'$.address') as address
        |,get_json_object(get_json_object(log,'$.message'),'$.costTime') as costTime
        |,get_json_object(get_json_object(log,'$.message'),'$.normalCostTime') as normalCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.reqTime') as reqTime
        |,get_json_object(get_json_object(log,'$.message'),'$.type') as type
        |,get_json_object(get_json_object(log,'$.message'),'$.xyAreaCostTime') as xyAreaCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.xyCutCostTime') as xyCutCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.adCodeServerCostTime') as adCodeServerCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.geoCostTime') as geoCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.atCostTime') as atCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.keywordCostTime') as keywordCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.aoiCutCostTime') as aoiCutCostTime
        |,get_json_object(get_json_object(log,'$.message'),'$.aoiAreaCostTime') as aoiAreaCostTime
        |from dm_gis.shunxin_service_interface_log_info_di
        |where inc_day = '%s'
      """.stripMargin

    val formatSql = String.format(sql,incDay,incDay)
    logger.error(formatSql)
    spark.sql(formatSql)
    logger.error("处理结束")
  }


  //取网点变更表数据

  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //    fromDay:跑数时间 yyyy-mm-dd

    //    for (i <- 0 until days) {
    val incDay = DateUtil.getDateStr(startDay, 0, "") //-7 yyyy-mm-dd

    logger.error(s"开始计算：incDay:${incDay}")
    startSta(spark, incDay)
    logger.error("计算结束：" + incDay)
    //    }
    logger.error("统计完毕")
  }



  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    logger.error("起始时间:" + startDay )
    start(startDay)
    logger.error("结束所有运行")
  }


}
