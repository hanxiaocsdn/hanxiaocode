package com.sf.gis.scala.sx.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2018/2/6.
  */
object JSONUtil extends Serializable{
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonVal(obj: JSONObject, keys: String): Object = {
    var `val` : Object = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.get(keyArr(i))
      }
    } catch {
      case e: Exception =>
        logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    `val`
  }

  /**
    * 判断是否是正常json
    */

  def isValidJSON(jsonStr: String): Boolean = {
    var boolean: Boolean = true
    try {
      JSON.parseObject(jsonStr)
    } catch {
      case e: Exception => boolean = false
    }
    boolean
  }




  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val` : String = null
    var tempObj = obj
//    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case _: Exception =>
        //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
//    `val` = `val`.replaceAll("\\n","")
//    `val` = `val`.replaceAll("\\r","")
    `val`
  }
  def getJsonArrayFromObject(obj: JSONObject, keys: String, defaultValue: JSONArray): JSONArray = {
    var `val` : JSONArray = null
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getJSONArray(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }
  /**
    * 获取json里面的json对象
    * @param obj
    * @param key
    * @param defaultValue
    * @return
    */
  def getJsonObj(obj: JSONObject, key: String, defaultValue: String): String ={
    var returnStr : String = defaultValue
    try{

      val returnObj:JSONObject = obj.getJSONObject(key)
//      if(returnObj!=null) returnStr = JSON.toJSONString(returnObj).replaceAll("[\\r\\n\\t]", "")
      if(returnObj!=null) returnStr = returnObj.toJSONString.replaceAll("[\\r\\n\\t]", "")
    }catch{
      case e:Exception =>logger.error("获取json数据项" + key + "出错:" + obj, e)
    }
    returnStr
  }
  /**
    * 获取json里面的json数组字符串
    * @param obj
    * @param key
    * @param defaultValue
    * @return
    */
  def getJsonArray(obj: JSONObject, key: String, defaultValue: String): String ={
    var returnStr : String = defaultValue
    try{

      val returnObj:JSONArray = obj.getJSONArray(key)
      //      if(returnObj!=null) returnStr = JSON.toJSONString(returnObj).replaceAll("[\\r\\n\\t]", "")
      if(returnObj!=null) returnStr = returnObj.toJSONString.replaceAll("[\\r\\n\\t]", "")
    }catch{
      case e:Exception =>logger.error("获取json数据项" + key + "出错:" + obj, e)
    }
    returnStr
  }
  def parseJSONObject(str:String): JSONObject ={
    if(!StringUtils.nonEmpty(str)){
      return null
    }
    var jObj:JSONObject = null
    try{
        jObj = JSON.parseObject(str)
    }catch {
      case e:Exception=>logger.error(str,e)
    }
    jObj
  }
  /**
    * 获取多层json的值
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonValInt(obj: JSONObject, keys: String, defaultValue: Int): Int = {
    var `val` : Int = defaultValue
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getInteger(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }
}
