package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.KeyInfo
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.util._
import com.sf.gis.scala.sx.util.{DateTimeUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/*
*快运标准库 - 01412406     01374443 20231025标注
* 名称：顺心AOI初始化
* 描述：疑似一次性任务,结果表已为空,先注释，等待删除
*
*/
object ShunxinNorm {

//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val logger: Logger = Logger.getLogger(appName)
//  //关闭fastjson引用检测
//  JSON.DEFAULT_GENERATE_FEATURE |= SerializerFeature.DisableCircularReferenceDetect.getMask
//  val calPartition = 2000
//  val limitMin = 1000
//  val splitUrl = "http://gis-int.int.sfdc.com.cn:1080/atdispatchlite/api?address=%s&province=&cityName=&district=&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=norm"
//  val mapb_url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?city=%s&address=%s&ak=c274bbf7007c411c8e21a6abe31a9886&opt=zh"
//  val xy_url = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=fb63772b6bd542ddb3d94c9b25deef6b"
//
//  val teamCode_Url = "http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=SX&ak=8cb19f422db34736922479ba0bc848f4&lng=%s&lat=%s"
//
//
//  case class re(
//                 cityCode: String,
//                 keyInfo: String,
//                 aoiCode: String,
//                 x: String,
//                 y: String,
//                 detail:String
//               )
//
//
//  def main(args: Array[String]) = {
//
//
////    val spark = SparkSession.builder()
////      .appName("SparkDecode")
////      .master("yarn")
////      .enableHiveSupport()
////      .config("hive.exec.dynamic.partition", true)
////      .config("hive.exec.dynamic.partition.mode", "nonstrict")
////      .getOrCreate()
//
//
//    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
//
//    spark.sparkContext.setLogLevel("ERROR")
//
//
//
//
//
//
//
//    val incDay = args(0)
//    val beforeDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", incDay, -30)
//    logger.error(incDay + "-" + beforeDay)
//    logger.error("begin")
//    run(spark, incDay, beforeDay)
//
//    logger.error("end")
//  }
//
//
//
//
//
//  def run(spark: SparkSession, incDay: String, beforeDay: String) = {
//
//    logger.error("获取数据源数据")
//
//    //获取数据源
//    val dataRdd = getDataRdd(spark, incDay)
//
//    logger.error("获取到的数据量："+dataRdd.count()+dataRdd.take(5).foreach(println(_)))
//
//    logger.error("获取keytag")
//    //获取keytag,keyworld
//    val infoRdd = getKeyInfo(dataRdd)
//    logger.error("获取到的数据量："+infoRdd.count()+infoRdd.take(5).foreach(println(_)))
//    logger.error("审补坐标落AOI面")
//    //审补坐标落AOI面，aoiid是否为空
//    val aoiRdd = infoRdd.coalesce(1).mapPartitionsWithIndex((index, iter) => {
//
//      val startTime = new StratTime(System.currentTimeMillis())
//      val cnt = new Cnt(0)
//
//      for (obj <- iter) yield {
//        //限制ak使用
//        SparkUtils.limitAkUse(startTime, cnt, index, limitMin, logger)
//        val x = JSONUtil.getJsonVal(obj, "check_x", "")
//        val y = JSONUtil.getJsonVal(obj, "check_y", "")
//        val reqObject = getAoi(x, y)
//        val aoi = JSONUtil.getJsonVal(reqObject, "SbAoiid", "")
//        val req = JSONUtil.getJsonVal(reqObject, "SbReq", "")
//        obj.put("SbAoiid", aoi)
//        obj.put("SbReq", reqObject)
//        //aoi不为空，调坐标挂顺心网点
//        if (aoi.isEmpty) {
//          val Sxreq = getSxCode(x, y)
//          val code = JSONUtil.getJsonVal(Sxreq, "SxCode", "")
//          obj.put("aoiEmpty", "true")
//          obj.put("SxReq", Sxreq)
//          obj.put("SxCode", code)
//        }
//        obj
//      }
//
//
//    }).persist(StorageLevel.MEMORY_AND_DISK_2)
//
//
//
//
//
//
//
//
//
//    logger.error("获取到的数据量："+aoiRdd.count()+aoiRdd.take(5).foreach(println(_)))
//    import spark.implicits._
//
//    logger.error("区分aoi是否为空")
//    val aoiDf = aoiRdd.repartition(200).filter(obj => {
//      JSONUtil.getJsonVal(obj, "SbAoiid", "").nonEmpty
//    }).map(obj => {
//      val cityCode = JSONUtil.getJsonVal(obj, "check_city_code", "")
//      val keyTag = JSONUtil.getJsonVal(obj, "key_tag", "")
//      val keyWord = JSONUtil.getJsonVal(obj, "key_word", "")
//      val x = JSONUtil.getJsonVal(obj, "check_x", "")
//      val y = JSONUtil.getJsonVal(obj, "check_y", "")
//      val aoiid = JSONUtil.getJsonVal(obj, "SbAoiid", "")
//      val keyInfo = JSONUtil.getJsonVal(obj, "keyInfo", "")
//      val detail= obj.toJSONString
//      re(cityCode, keyInfo, aoiid, x, y,detail)
//    }
//    ).toDF()
//
//    logger.error("aoi不否为空的数据量："+aoiDf.count())
//    aoiDf.show(10,false)
//
//
//
//    aoiDf.createOrReplaceTempView("aoiTable")
//
//    val codeDf = aoiRdd.repartition(200).filter(obj => {
//      JSONUtil.getJsonVal(obj, "SbAoiid", "").isEmpty
//    }).map(obj => {
//      val cityCode = JSONUtil.getJsonVal(obj, "check_city_code", "")
//      val keyTag = JSONUtil.getJsonVal(obj, "key_tag", "")
//      val keyWord = JSONUtil.getJsonVal(obj, "key_word", "")
//      val x = JSONUtil.getJsonVal(obj, "check_x", "")
//      val y = JSONUtil.getJsonVal(obj, "check_y", "")
//      val code = JSONUtil.getJsonVal(obj, "SxCode", "")
//      val keyInfo = JSONUtil.getJsonVal(obj, "keyInfo", "")
//      val detail= obj.toJSONString
//      re(cityCode, keyInfo, code, x, y,detail)
//    }
//    ).toDF()
//    logger.error("aoi为空的数据量："+codeDf.count())
//    codeDf.show(10,false)
//
//    codeDf.createOrReplaceTempView("codeTable")
//
//
//    val totalSql =
//      s"""
//    |			select
//    |			 md5(concat('${incDay}',cityCode,rand())) as id
//    |     ,cityCode
//    |			,keyInfo
//    |			,aoixy
//    |			,if(rn>1,'无效','有效') as tag
//    |     ,detail
//    |			from (
//    |			select
//    |			 cityCode
//    |			,keyInfo
//    |			,aoiCode as aoixy
//    |			,count(aoiCode)over(partition by keyInfo,cityCode) rn
//    |     ,detail
//    |			from
//    |			aoiTable
//    |			)a
//    |			union all
//    |			select
//    |     md5(concat('${incDay}',cityCode,rand())) as id
//    |			,cityCode
//    |			,keyInfo
//    |			,aoixy
//    |			,if(rn>1,'无效','有效') as tag
//    |     ,detail
//    |			from (
//    |			select
//    |			 cityCode
//    |			,keyInfo
//    |			,concat(x,";",y) as aoixy
//    |			,count(aoiCode)over(partition by keyInfo,cityCode) rn
//    |    ,detail
//    |			from
//    |			codeTable
//    |			)a
//
//  """.stripMargin
//
//
//    val saveDf = spark.sql(totalSql)
//
//
//    logger.error("入库的数据量："+saveDf.count())
//    saveDf.show(10,false)
//
//
//    logger.error("明细数据入库")
//    saveDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.Shunxin_norm_di")
//    logger.error("入库完毕")
//
//
//  }
//
//
//  def getDataRdd(spark: SparkSession, incDay: String) = {
//
//    val sql =
//      s"""
//         |select
//         |check_city_code
//         |,address
//         |,create_date
//         |,check_date
//         |,check_x
//         |,check_y
//         | from (
//         |select
//         |check_city_code
//         |,address
//         |,create_date
//         |,check_date
//         |,check_x
//         |,check_y
//         |,row_number()over(distribute by address sort by check_date desc ) rn
//         |from dm_gis.sx_work_detail_his
//         |where inc_day = '${incDay}'
//         |) where rn=1
//      """.stripMargin
//
//    val reRdd = SparkUtils.getRowToJson(spark, sql)
//
//    reRdd
//  }
//
//  def getKeyInfo(dataRdd: RDD[JSONObject]) = {
//
//    val rerdd = dataRdd.repartition(200).map(obj => {
//      val cityCode = JSONUtil.getJsonVal(obj, "check_city_code", "")
//      val address = JSONUtil.getJsonVal(obj, "address", "")
//      val reqJson = getmapB(mapb_url, cityCode, address)
//      val aoiid = JSONUtil.getJsonVal(reqJson, "aoiid", "")
//      val splitResult = JSONUtil.getJsonVal(reqJson, "splitResult", "")
//
//      obj.put("MapReq", reqJson)
//      obj.put("MapAoiid", aoiid)
//      obj.put("MapSplitResult", splitResult)
//
//
//      //获取tag，word
//      val key = new KeyInfo(splitResult)
//      key.x_move_2_getKey();
//      key.pickey();
//
//
//
//      val key_tag = key.exportKeyInfo().getOrElse("key_tag", "")
//      val key_word = key.exportKeyInfo().getOrElse("key_word", "")
//      obj.put("key_tag", key_tag)
//      obj.put("key_word", key_word)
//      if(!key_tag.isEmpty || !key_word.isEmpty)  obj.put("keyInfo", key_word + "@" + key_tag)
//      obj
//    })
//    rerdd
//
//  }
//
//  //调mapb接口获取x,y
//  def getmapB(mapb_url: String, cityCode: String, address: String) = {
//
//    var aoiid = ""
//    var splitResult = ""
//
//    val obj = new JSONObject()
//    var array: JSONArray = new JSONArray()
//    val reqObejct = HttpClientUtil.getJsonByGet(String.format(mapb_url, cityCode, URLEncoder.encode(address, "utf-8")), 3)
//
//
//    if (reqObejct != null) {
//
//      //获取分词 浙江省^11,杭州市^12,阿里巴巴^113;13 =>浙江省^11,杭州市^12,阿里巴巴^113
//      splitResult = try {
//        reqObejct.getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult")
//          .split(";")(0)
//      }
//      catch {
//        case e: Exception => null
//      }
//
//      //获取aoiId
//      array = try {
//        reqObejct.getJSONObject("result").getJSONArray("tcs")
//      }
//      catch {
//        case e: Exception => null
//      }
//
//
//      if (array != null && array.size() > 0) {
//        val result = array.getJSONObject(0)
//        aoiid = JSONUtil.getJsonVal(result, "aoiid", "")
//      }
//      obj.put("aoiid", aoiid)
//      obj.put("splitResult", splitResult)
//      obj.put("mapbReq", reqObejct)
//      obj
//    }
//
//
//    obj
//  }
//
//
//  //调接口获取aoi
//  def getAoi(x: String, y: String) = {
//    val obj = new JSONObject()
//
//    if (x.nonEmpty && y.nonEmpty) {
//      var aoiid = ""
//      val reqObejct = HttpClientUtil.getJsonByGet(String.format(xy_url, x, y), 3)
//
////      println(String.format("%.2f , %.2f", Double.box(a), Double.box(b)))
//
//
//
//      if (reqObejct != null) {
//        //获取aoiid
//        aoiid = try {
//          reqObejct.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id")
//        }
//        catch {
//          case e: Exception => null
//        }
//        obj.put("SbAoiid", aoiid)
//        obj.put("SbReq", reqObejct)
//        obj
//      }
//    }
//    obj
//  }
//
//
//  //
//  def getSxCode(x: String, y: String) = {
//    val obj = new JSONObject()
//    var code = ""
//    val reqObejct = HttpClientUtil.getJsonByGet(String.format(teamCode_Url, x, y), 3)
//    if (reqObejct != null) {
//      //获取aoiid
//      code = try {
//        reqObejct.getJSONObject("result").getJSONArray("map_data").getJSONObject(0).getString("code")
//      }
//      catch {
//        case e: Exception => null
//      }
//      obj.put("SxAoiid", code)
//      obj.put("SxReq", reqObejct)
//      obj
//    }
//    obj
//  }

}
