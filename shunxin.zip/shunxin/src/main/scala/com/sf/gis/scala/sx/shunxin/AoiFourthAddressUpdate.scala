package com.sf.gis.scala.sx.shunxin

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil}
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.custom_module.{SfNetIntefaceCms, SfNetIntefaceRds}
import com.sf.gis.scala.base.spark.{Spark, SparkNetBase, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * 顺心四级地址更新
 * 业务:张剑佩
 * 开发:黄鸿锦
 * 任务名称:顺心四级地址更新映射cms多四级地址
 * 任务id:364388
 */
object AoiFourthAddressUpdate {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  var calPartitions = 100

  //shunxing调取接口获取AOI_id、signtownname
  def runRdsGroup(spark: SparkSession, dfFilter: RDD[JSONObject]): RDD[(String, Array[String])] = {
    val ak = "c274bbf7007c411c8e21a6abe31a9886"
    val id = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01374443","364388","顺心四级地址更新映射cms多四级地址","",CommonUrl.rdsRzPaiZhUrl,ak,dfFilter.count(),100)
    val rdsRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(spark, dfFilter, SfNetIntefaceRds.rdsRzPaiZh,
      Map("address" -> "signAddress", "citycode" -> "signCityCode"), 100, ak, 20000, 5000)
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("数据量：" + rdsRdd.count())
    rdsRdd.take(10).foreach(obj => logger.error(obj.toJSONString))
    dfFilter.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01374443",id)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val shunxingWaybillAoiRdd = rdsRdd.repartition(excutors * cores * 4).map(obj => {
      val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "rdsRzPaiZh.result.tcs")
      val AOI_id: String = JSONUtil.getJsonValSingle(tcs, "aoiid")
      val signtownname: String = JSONUtil.getJsonValSingle(obj, "signTownName")
      (AOI_id, signtownname)
    }).filter(obj => !obj._1.isEmpty).distinct().groupByKey().map(obj => {
      (obj._1, obj._2.toArray)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("====>>>运行调取接口并去重聚合后数据量:" + shunxingWaybillAoiRdd.count())
    shunxingWaybillAoiRdd
  }

  //tmp_dm_gis.tmp_shunxin_wyabill_detail 中 signtownname==town 且都不为空
  def shunxingWaybill(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val mark = "$"
    val DayBefore0 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val DayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val shunxingsql =
      s"""
         |select
         |	signTownName
         |	,signCityCode
         |	,signAddress
         |from
         |(
         |	select
         |	ewb_sign_address as signAddress,
         |	citycode as signCityCode,
         |	sign_town_name as signTownName
         |	from  dm_gis.shunxin_detail_di_jx_new a
         |  where partition_day>='$DayBefore1' and partition_day<='$DayBefore0'
         |) t1 where signTownName is not null and signTownName<>''
         |""".stripMargin
    logger.error(shunxingsql)
    val shunxinOriginRdd = spark.sql(shunxingsql).rdd.map(obj => {
      val json = new JSONObject();
      json.put("signTownName", obj.getString(0))
      json.put("signCityCode", obj.getString(1))
      json.put("signAddress", obj.getString(2))
      json
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("====>>>signtownname不为空数据量:" + shunxinOriginRdd.count())
    shunxinOriginRdd
  }

  def joinShunxin(cmsTownOverTwoRdd: RDD[(String, JSONObject)], shunxinAoiIdTownRdd: RDD[(String, Array[String])]): (RDD[(String, JSONObject)], RDD[(String, JSONObject)]) = {
    val joinShunxinRdd = cmsTownOverTwoRdd.leftOuterJoin(shunxinAoiIdTownRdd).map(obj => {
      val leftBody = obj._2._1
      val townNow = leftBody.getJSONArray("town")
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        val rightBody = rightOp.get
        val townInsect = new JSONArray()
        for (i <- 0 until townNow.size) {
          val item = townNow.getString(i)
          if (rightBody.contains(item)) {
            townInsect.add(item)
          }
        }
        if (townInsect.size() > 0) {
          leftBody.put("town", townInsect)
          leftBody.put("status", "1")
        }
      }
      if (leftBody.containsKey("status")) {
        (true, (obj._1, leftBody))
      } else {
        (false, (obj._1, leftBody))
      }
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val sucRdd = joinShunxinRdd.filter(obj => obj._1).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("状态为1的数量：" + sucRdd.count())
    val failRdd = joinShunxinRdd.filter(obj => !obj._1).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("状态为0的数量：" + failRdd.count())
    joinShunxinRdd.unpersist()
    (sucRdd, failRdd)
  }

  def queryTotalAoiTownData(spark: SparkSession): RDD[(String, JSONObject)] = {
    val aoiFourthAddressSplitSql = "select get_json_object(detail,'$.AOI_id') as AOI_id,get_json_object(detail,'$.town') as town," +
      "get_json_object(detail,'$.status') as status from dm_gis.aoi_fourth_address_split where inc_day='all' "
    logger.error("获取全量的aoi四级地址映射数据：" + aoiFourthAddressSplitSql)
    val aoiFourthAddressSplitRdd = spark.sql(aoiFourthAddressSplitSql).rdd.repartition(calPartitions).map(obj => {
      val jsonObject = new JSONObject()
      val aoiId = obj.getString(0)
      jsonObject.put("aoiId", aoiId)
      jsonObject.put("town", obj.getString(1))
      jsonObject.put("status", obj.getString(2))
      (aoiId, jsonObject)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>获取全量的aoi四级地址映射数据：" + aoiFourthAddressSplitRdd.count())
    aoiFourthAddressSplitRdd
  }

  def queryCmsChangeData(spark: SparkSession, incDay: String): (RDD[JSONObject], Broadcast[Array[String]]) = {
    val DayBefore15: String = DateUtil.getDayBefore(incDay, "yyyyMMdd", 15)
    val DayBefore0: String = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val cmsAoiSchSql =
      s"""
         |select
         |aoi_id
         |from dm_gis.cms_aoi_change
         |where inc_day='$DayBefore0'
         |and (change_type=1 or oper_type='I') group by aoi_id
         |""".stripMargin
    logger.error("aoi变更：" + cmsAoiSchSql)
    val cmsAoiSchChangeRdd = spark.sql(cmsAoiSchSql).rdd.map(obj => {
      val jsonObject = new JSONObject()
      jsonObject.put("aoiId", obj.getString(0))
      jsonObject.put("isChange", true)
      //      jsonObject.put("status","1")
      jsonObject
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("cms_aoi_change数据量:" + cmsAoiSchChangeRdd.count())
    val cmsChangeAoiList = cmsAoiSchChangeRdd.map(obj => obj.getString("aoiId")).collect()
    val cmsChangeAoiBc = spark.sparkContext.broadcast(cmsChangeAoiList)
    (cmsAoiSchChangeRdd, cmsChangeAoiBc)
  }

  def runForthLevelAddr(spark: SparkSession, cmsChangeDataRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val id = BdpTaskRecordUtil.startRunNetworkInterface(spark,"01374443","364388","顺心四级地址更新映射cms多四级地址","",CommonUrl.cmsAoiTown,"",cmsChangeDataRdd.count(),2)

    val cmsTownRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(spark, cmsChangeDataRdd, SfNetIntefaceCms.cmsAoiTown,
      Map("aoiId" -> "aoiId"), 2, "", 4000, 5000)
      .map(obj => {
        val data: JSONArray = JSONUtil.getJsonArrayMulti(obj, "cmsAoiTown.data")
        val myException = JSONUtil.getJsonVal(obj, "cmsAoiTown.myException", "")
        if (myException.isEmpty) {
          var town = ""
          val townArray = new JSONArray()
          for (i <- 0 until data.size()) {
            val data_i = data.getJSONObject(i)
            town = JSONUtil.getJsonValSingle(data_i, "name")
            if (!townArray.contains(town)) {
              townArray.add(town)
            }

          }
          obj.put("town", townArray)
        }
        obj
      })
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("运行四级地址获取接口:" + cmsTownRdd.count())
    cmsTownRdd.take(10).foreach(obj => logger.error(obj.toJSONString))
    BdpTaskRecordUtil.endNetworkInterface("01374443",id)
    cmsTownRdd
  }

  def queryMultiForthLevelAddr(spark: SparkSession): RDD[(String, JSONObject)] = {
    val sql = "select aoi_id,town from dm_gis.cms_aoi_sch_multi_town where inc_day='all'"
    logger.error(sql)
    val multiTownRdd = spark.sql(sql).rdd.map(obj => {
      val json = new JSONObject()
      json.put("aoiId", obj.getString(0))
      val town = JSON.parseArray(obj.getString(1))
      val townGroup = new JSONArray()
      for (i <- 0 until town.size()) {
        val item = town.getString(i)
        if (!townGroup.contains(item)) {
          townGroup.add(item)
        }
      }
      json.put("town", townGroup)
      (obj.getString(0), json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("四级地址映射总数据量:" + multiTownRdd.count())
    multiTownRdd
  }

  def joinChangeMultiForthAddr(forthLevelAddrRdd: RDD[JSONObject], multiForthLevelAddrRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val multiForthAddrRdd = forthLevelAddrRdd.map(obj => (obj.getString("aoiId"), obj)).union(multiForthLevelAddrRdd)
      .reduceByKey((obj1, obj2) => {
        var objChange = obj1
        var objMulti = obj2
        if (obj2.containsKey("isChange")) {
          objChange = obj2
          objMulti = obj1
        }
        val townChange = objChange.getJSONArray("town")
        if (townChange == null) {
          objMulti
        } else {
          objChange
        }
      }).filter(obj => {
      val townChange = obj._2.getJSONArray("town")
      townChange != null && townChange.size() > 1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("剩余多四级地址数据量:" + multiForthAddrRdd.count())
    forthLevelAddrRdd.unpersist()
    multiForthLevelAddrRdd.unpersist()
    multiForthAddrRdd
  }

  def dealChangeData(spark: SparkSession, incDay: String): (Broadcast[Array[String]], RDD[(String, JSONObject)]) = {
    logger.error("获取aoi变更数据")
    val (cmsAoiSchChangeRdd, cmsChangeAoiBc) = queryCmsChangeData(spark, incDay)
    logger.error("跑四级地址接口")
    val forthLevelAddrRdd = runForthLevelAddr(spark, cmsAoiSchChangeRdd)
    logger.error("获取历史四级地址大于二的aoi")
    val multiForthLevelAddrRdd = queryMultiForthLevelAddr(spark)
    logger.error("关联多四级地址和变更数据")
    val joinChangeMultiForthAddrRdd = joinChangeMultiForthAddr(forthLevelAddrRdd, multiForthLevelAddrRdd)
    (cmsChangeAoiBc, joinChangeMultiForthAddrRdd)
  }

  def mergeHistoryNow(sucRdd: RDD[(String, JSONObject)], aoiTownTotalRdd: RDD[(String, JSONObject)],
                      cmsChangeAoiBc: Broadcast[Array[String]]): RDD[JSONObject] = {
    val retRdd = aoiTownTotalRdd.map(obj => {
      val cmsChangeAoiList = cmsChangeAoiBc.value
      if (cmsChangeAoiList.contains(obj._1)) {
        obj._2.put("town", new JSONArray())
        obj._2.put("status", "0")
      }
      obj
    }).union(sucRdd).reduceByKey((obj1, obj2) => {
      val status1 = obj1.getString("status")
      val status2 = obj2.getString("status")
      val town1 = obj1.getJSONArray("town")
      val town2 = obj2.getJSONArray("town")
      if (status2.toInt > status1.toInt) {
        obj1.put("status", status2)
      }
      for (i <- 0 until town2.size()) {
        val item = town2.getString(i)
        if (!town1.contains(item)) {
          town1.add(item)
        }
      }
      obj1.put("town", town1)
      obj1
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("最终结果量:" + retRdd.count())
    retRdd
  }

  def saveTotalMap(spark: SparkSession, finalTotalMapRdd: RDD[JSONObject], incDay: String): Unit = {
    val retRdd = finalTotalMapRdd.map(obj => {
      val json = new JSONObject()
      json.put("AOI_id", obj.get("aoiId"))
      json.put("town", obj.getJSONArray("town"))
      json.put("status", obj.get("status"))
      json
    }).repartition(1)
    SparkWrite.save2HiveStaticSingleColumn(spark, retRdd, "dm_gis.aoi_fourth_address_split", Array(("inc_day", incDay)))
    SparkWrite.save2HiveStaticSingleColumn(spark, retRdd, "dm_gis.aoi_fourth_address_split", Array(("inc_day", "all")))
  }

  def saveMultiForthAddr(spark: SparkSession, cmsTownOverTwoRdd: RDD[(String, JSONObject)], incDay: String): Unit = {
    val retRdd = cmsTownOverTwoRdd.values.map(obj => {
      obj.put("town", obj.getJSONArray("town"))
      obj
    }).repartition(1)
    SparkWrite.save2HiveStatic(spark, retRdd, Array("aoiId", "town"), "dm_gis.cms_aoi_sch_multi_town",
      Array(("inc_day", incDay)))
    SparkWrite.save2HiveStatic(spark, retRdd, Array("aoiId", "town"), "dm_gis.cms_aoi_sch_multi_town",
      Array(("inc_day", "all")))
  }

  def csmMultiAddr(spark: SparkSession): Unit = {
    val cmsAoiScHsql =
      s"""
         |select
         |aoi_id
         |from dm_gis.cms_aoi_sch group by aoi_id
         |""".stripMargin
    logger.error("获取全量的aoi_id数据:" + cmsAoiScHsql)

    val cmsAoiSchRdd = spark.sql(cmsAoiScHsql).rdd.map(obj => {
      val json = new JSONObject()
      json.put("aoiId", obj.getString(0))
      json
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取全量的aoi_id数据量:" + cmsAoiSchRdd.count())
    val rddData = runForthLevelAddr(spark, cmsAoiSchRdd)
    val rddFilterMulti = rddData.filter(obj => {
      val town = obj.getJSONArray("town")
      town != null && town.size() > 1
    }).map(obj => {
      obj.put("town", obj.getJSONArray("town").toJSONString)
      obj
    })

    SparkWrite.save2HiveStatic(spark, rddFilterMulti, Array("aoiId", "town"), "dm_gis.cms_aoi_sch_multi_town", Array(("inc_day", "init")))
  }

  //spark入口
  def execute(incDay: String): Unit = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    spark.sparkContext.setLogLevel(FixedConstant.LOG_LEVEL_ERROR)


    val (excutors, cores) = Spark.getExcutorInfo(spark)
    calPartitions = excutors * cores * 4
    logger.error("获取顺心数据")
    val shunxinOriginRdd = shunxingWaybill(spark, incDay)
    logger.error("跑rds容灾接口")
    val shunxinAoiIdTownRdd = runRdsGroup(spark, shunxinOriginRdd)
    logger.error("获取历史aoi四级地址映射总数据分区")
    val aoiTownTotalRdd = queryTotalAoiTownData(spark)
    logger.error("处理变更数据")
    val (cmsChangeAoiBc, cmsTownOverTwoRdd) = dealChangeData(spark, incDay)

    logger.error("开始关联顺心aoi")
    val (sucRdd, failRdd) = joinShunxin(cmsTownOverTwoRdd, shunxinAoiIdTownRdd)
    logger.error("合并到总映射表")
    val finalTotalMapRdd = mergeHistoryNow(sucRdd, aoiTownTotalRdd, cmsChangeAoiBc)
    logger.error("保存到总数据表,保存一份到all、一份到对应时间")
    saveTotalMap(spark, finalTotalMapRdd, incDay)
    logger.error("保存到多四级地址表,保存一份到all、一份到对应时间")
    saveMultiForthAddr(spark, cmsTownOverTwoRdd, incDay)
  }


  def main(args: Array[String]): Unit = {
    var incDay = args(0)
    execute(incDay)
    logger.error("======>>>>>>aoiFourthAddressModifyTest Execute Ok")
  }
}


