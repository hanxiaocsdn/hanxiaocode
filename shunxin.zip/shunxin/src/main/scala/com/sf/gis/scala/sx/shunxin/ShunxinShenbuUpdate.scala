package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.sx.util.{SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.util

import org.apache.spark.sql.functions.lit
/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object ShunxinShenbuUpdate {
  @transient lazy val logger: Logger = Logger.getLogger(ShunxinShenbuRecovery.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val updateUrl = "http://gdssexpress-gis-ass-gdss.dcn.k8s.sf-express.com/dispatch/api/add"
  val updateDel = "http://gdssexpress-gis-ass-gdss.dcn.k8s.sf-express.com/dispatch/api/del"
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")


  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {

    logger.error("获取数据源")
    //取数据源,
    val dataRdd = getDataDf(spark, incDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("更新数据")
//    val reRdd = delData(dataRdd)
    val reRdd = upData(dataRdd)
    import spark.implicits._
    val tableName = "dm_gis.shunxinshenbu_updata_detail_di"
//    val tableName = "dm_gis.shunxinshenbu_deldata_detail_di"
    reRdd.map(_.toJSONString).toDF().withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error(s"更新完毕:${tableName}:分区${incDay}")

//    //打tag
//    val tagRdd = checkTag(dataRdd)
//    logger.error(tagRdd.take(10).foreach(println(_)))
//
//    logger.error("开始入库")
//    //入库
//    saveTable(spark, tagRdd, incDay)
//    logger.error("结束所有运行")

  }




  def getDataDf(spark: SparkSession, incDay: String) = {


    val dataSql =
      """
        |select checkaddress
        |,checkx
        |,checky
        |from default.shenbu_1015
      """.stripMargin
//    val dataSql =
//      """
//        |select
//        |checkaddress as checkAddress
//        |,checkcitycode as checkCityCode
//        |from default.delete_0926_2
//      """.stripMargin


    logger.error(dataSql)
    val totalRdd = SparkUtils.getRowToJson(spark, dataSql).repartition(sqlpartition)
    logger.error(totalRdd.take(10).foreach(println(_)))

    totalRdd
  }

  //调更新接口
  def upData(tagRdd: RDD[JSONObject]) ={
    val reqRdd = tagRdd.repartition(10).map(obj=>{
        val address = JSONUtil.getJsonVal(obj,"checkaddress","")
        val checkx = JSONUtil.getJsonVal(obj,"checkx","")
        val checky = JSONUtil.getJsonVal(obj,"checky","")
        val parm = new JSONObject()
        parm.put("checkAddress",address)
        parm.put("checkX",checkx)
        parm.put("checkY",checky)
        val  httpData  = HttpConnection.sendPost(updateUrl, parm.toJSONString)
        obj.put("updataReq",httpData.getOrDefault("content",""))
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    reqRdd
  }
  def delData(tagRdd: RDD[JSONObject]) ={
    val reqRdd = tagRdd.repartition(10).map(obj=>{
      val address = JSONUtil.getJsonVal(obj,"checkAddress","")
      val checkCityCode = JSONUtil.getJsonVal(obj,"checkCityCode","")

      val parm = new JSONObject()
      parm.put("checkAddress",address)
      parm.put("checkCityCode",checkCityCode)

      val  httpData  = HttpConnection.sendPost(updateDel, parm.toJSONString)
      obj.put("deldataReq",httpData.getOrDefault("content",""))
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    reqRdd
  }
}
