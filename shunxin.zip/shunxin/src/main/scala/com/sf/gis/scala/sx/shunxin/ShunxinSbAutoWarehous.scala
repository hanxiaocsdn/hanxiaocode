package com.sf.gis.scala.sx.shunxin

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.graph.aoi.common.util.KeyWordUtil
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpConnection}
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil, Util}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import scala.util.control.Breaks

/**
  * 顺心审补自动入库工艺
  * 需求方：刘桓-01422529
  * 开发：01412406
 * id :871636
  */
object ShunxinSbAutoWarehous {

  @transient lazy val logger: Logger = Logger.getLogger(ShunxinSbAutoWarehous.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.3
  println(version)

  val account = "01412406"
  val taskId = "909685"
  val taskName = "补码作业平台未吸收数据兜底_AoiAccuracyShouBottomDataNew"
  val taskDesc = "补码作业平台未吸收数据兜底_AoiAccuracyShouBottomDataNew"


  val atUrl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=e9106d80834e483189c3439938bac5d2&opt=zh&showserver=true"
  val aoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=3eb300d2e06947f7945cd02530a32fd2&x=%s&y=%s&opt=aoi&geom=0"
  val geoAoiUrl = "http://sds-core-datarun.sf-express.com/datarun/aoi/getGeomAoiBase?aoiId=%s&radius=50"
  val gdUrl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s"
  val splitUrl= "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%S&citycode=%s&ak=3eb300d2e06947f7945cd02530a32fd2"
  val pushUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/aoiAddress/pushCheckAddress"
  val updateMd5Url = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck"
  val updataUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiId"
  val updataAoiUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
  val addSbUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd"



  val aoiDetailTableName = "dm_gis.dm_aoi_address_data_detail_di" //生产
  val aoiTableName = "dm_gis.dm_aoi_address_data_di" //生产
  val tableName = "dm_gis.shunxin_auto_warehous_detail_di" //生产
  val allTableName = "dm_gis.shunxin_auto_warehous_di" //生产
  case class Result(
                           check_address:String
                          ,waybill_no:String
                          ,check_city_code:String
                          ,check_x:String
                          ,check_y:String
                          ,split_result:String
                          ,group_id:String
                          ,current_aoi_name:String
                          ,current_aoi_id:String
                          ,new_aoi_id:String
                          ,new_aoi_name:String
                          ,result:String
                          ,tag:String
                          ,adjust_aoi_id:String
                          ,name:String
                          ,guid:String
                          ,area_code:String
                          ,atAoiSrc:String
                          ,standardization:String
                          ,status:String

  )
  case class Result2(
                       ity_code:String
                      ,ddress_id:String
                      ,ddress:String
                      ,heck_dept_code:String
                      ,heck_sch_code:String
                      ,heck_aoi_code:String
                      ,heck_aoi_id:String
                      ,heck_aoi_name:String
                      ,heck_x:String
                      ,heck_y:String
                      ,tAoiSrc:String
                      ,oiid:String
                      ,roupid:String
                      ,tatus:String


  )


  def queryAoiData(spark: SparkSession, incDay: String) = {

    val day4 = DateUtil.getDateStr(incDay, -3, "")

    val sql =
      s"""
        | select
        |  aoi_id
        | ,class_code
        | from dm_gis.emap_district_village_aoi a
        | where inc_day = '${day4}' and aoi_id <> ''
        | group by aoi_id
        | ,class_code
      """.stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).map(o=>(JSONUtil.getJsonVal(o,"aoi_id",""),JSONUtil.getJsonVal(o,"class_code",""))).persist(StorageLevel.MEMORY_AND_DISK)
   logger.error("取到偏远乡村aoi的数据量："+dataRdd.count())
    dataRdd.take(2).foreach(o=>logger.error(o))
    dataRdd
  }

  def doAddrData(spark: SparkSession, incDay: String) = {

    logger.error("取dm_gis.aoi_address_data的数据")
    val sql =
      s"""
         | select
         |  city_code
         | ,address
         | ,address_id
         | ,check_dept_code
         | ,check_sch_code
         | ,check_aoi_code
         | ,check_aoi_id
         | ,check_aoi_name
         | ,check_x
         | ,check_y
         | ,'CGCS' as tag
         | ,check_aoi_id
         | from dm_gis.aoi_address_data a
         | where inc_day = '${incDay}'
         | and (address_id like 'sx_norm_%' or address_id like 'sx_shenbu_%')
         |and check_data_type=1
         |and done_flag=1
         |and del_flag=0
    """.stripMargin
    logger.error(sql)
    val dataRddTmp =  SparkUtils.getRowToJson(spark,sql)
    dataRddTmp.take(2).foreach(o => logger.error(o))

    logger.error("调at接口")
    val reNum = dataRddTmp.count().toInt
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, atUrl, "e9106d80834e483189c3439938bac5d2", reNum, 20)
    val dataRdd = dataRddTmp.repartition(20).map(o => {

      val check_address = JSONUtil.getJsonVal(o, "address", "")
      val check_city_code = JSONUtil.getJsonVal(o, "city_code", "")
      val formatStanUrl = String.format(atUrl, URLEncoder.encode(check_address, "utf-8"), check_city_code)
      val stanObj: JSONObject = HttpClientUtil.getJsonByGet(formatStanUrl)
      o.put("stanObj", stanObj)
      var aoiid = ""
      if (stanObj != null) {

        val tcs = try {
          JSONUtil.getJsonArrayMulti(stanObj, "result.tcs").getJSONObject(0)
        } catch {
          case exception: Exception => new JSONObject()
        }

        val groupid = JSONUtil.getJsonVal(tcs, "groupid", "")
        aoiid = JSONUtil.getJsonVal(tcs, "aoiid", "")
        val atAoiSrc = JSONUtil.getJsonVal(tcs, "atAoiSrc", "")
        o.put("aoiid", aoiid)
        o.put("group_id", groupid)
        o.put("atAoiSrc", atAoiSrc)
      }
    o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("调完at接口的数量：" + dataRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    logger.error("判断是否入审补")

    val  sbRdd  = dataRdd.filter(o=> !JSONUtil.getJsonVal(o,"aoiid","").equals(JSONUtil.getJsonVal(o,"check_aoi_id",""))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val  sbUnionRdd= dataRdd.filter(o=> JSONUtil.getJsonVal(o,"aoiid","").equals(JSONUtil.getJsonVal(o,"check_aoi_id",""))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

  logger.error("调sb的数据量："+sbRdd.count())
  logger.error("不用调sb的数据量："+sbUnionRdd.count())
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updataUrl, "", reNum, 20)
    val httpInvokeId3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updataAoiUrl, "", reNum, 20)
    val httpInvokeId4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, addSbUrl, "", reNum, 20)
    val httpInvokeId5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updateMd5Url, "", reNum, 20)
  val runRdd = sbRdd.repartition(20).map(o=>updataSb(o)).persist(StorageLevel.MEMORY_AND_DISK)
  logger.error("调完sb的数据量："+runRdd.count())
  runRdd.take(2).foreach(o=>logger.error(o))
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId3)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId4)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId5)
  val saveRdd = runRdd.union(sbUnionRdd).persist(StorageLevel.MEMORY_AND_DISK)
  logger.error("落表的数据量："+saveRdd.count())
  saveAoiDetail(spark,saveRdd,incDay)
  }



  def querySignData(spark: SparkSession, incDay: String) = {
    val sepDay = DateUtil.changeDateSep(incDay, "", "-")
    val day2 = DateUtil.getDateStr(incDay, -1, "")
    val day4 = DateUtil.getDateStr(incDay, -3, "")

    val sql =
      s"""
         | select
         |  a.check_address
         | ,a.check_city_code
         | ,a.waybill_no
         | ,a.check_x
         | ,a.check_y
         | from dm_gis.sx_work_detail_his a
         | left join(
         | select check_address
         | from dm_gis.sx_work_detail_his
         | where inc_day = '${day2}'
         | group by check_address
         | )b on a.check_address = b.check_address
         | where a.inc_day = '${incDay}' and b.check_address is null and a.check_address <> ''
      """.stripMargin
    logger.error(sql)


    val dataRddTmp = SparkUtils.getRowToJson(spark, sql)


    val reNum = dataRddTmp.count().toInt
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, atUrl, "e9106d80834e483189c3439938bac5d2", reNum, 20)
    val dataRdd = dataRddTmp.repartition(20).map(o => {

      val check_address = JSONUtil.getJsonVal(o, "check_address", "")
      val check_city_code = JSONUtil.getJsonVal(o, "check_city_code", "")
      val formatStanUrl = String.format(atUrl, URLEncoder.encode(check_address, "utf-8"), check_city_code)
      val stanObj: JSONObject = HttpClientUtil.getJsonByGet(formatStanUrl)
      o.put("stanObj", stanObj)
      var current_aoi_id = ""
      if (stanObj != null) {
        val splitResult = JSONUtil.getJsonVal(stanObj, "result.other.normresp.result.splitResult", "")

        val geocoder = try {
          JSONUtil.getJsonArrayMulti(stanObj, "result.other.normresp.result.geocoder").getJSONObject(0)
        } catch {
          case exception: Exception => new JSONObject()
        }

        val standardization = JSONUtil.getJsonVal(geocoder, "standardization", "")


        val tcs = try {
          JSONUtil.getJsonArrayMulti(stanObj, "result.tcs").getJSONObject(0)
        } catch {
          case exception: Exception => new JSONObject()
        }

        val groupid = JSONUtil.getJsonVal(tcs, "groupid", "")
        current_aoi_id = JSONUtil.getJsonVal(tcs, "aoiid", "")
        val atAoiSrc = JSONUtil.getJsonVal(tcs, "atAoiSrc", "")

        o.put("current_aoi_id", current_aoi_id)
        o.put("group_id", groupid)
        o.put("standardization", standardization)
        o.put("atAoiSrc", atAoiSrc)
        o.put("splitResult", splitResult)
      }

      (current_aoi_id, o)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("顺心签收单号总数量：" + dataRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    dataRdd.take(20).foreach(o => logger.error(o))
    logger.error("关联获取aoi_name")

    val nameSql =
      s"""
         |select
         |aoi_id
         |,aoi_name
         |from dm_gis.cms_aoi
         |where inc_day = '${incDay}'
         |group by
         |aoi_id
         |,aoi_name
  """.stripMargin
    logger.error(nameSql)
    val aoiJoin = SparkUtils.getRowToJson(spark, nameSql).map(o => (JSONUtil.getJsonVal(o, "aoi_id", ""), JSONUtil.getJsonVal(o, "aoi_name", "")))

    aoiJoin.take(2).foreach("aoi映射" + logger.error(_))

    val allRdd = dataRdd.leftOuterJoin(aoiJoin).map(o => {
      val left = o._2._1
      val right = o._2._2
      if (right.nonEmpty) left.put("current_aoi_name", right.get)
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("关联完的数据量：" + allRdd.count())
    allRdd.take(2).foreach(o => logger.error(o.toJSONString))
    dataRdd.unpersist()

    val villSql =
      s"""
         |select
         |aoi_id
         |,name
         |,guid
         |,area_code
         |from dm_gis.emap_district_village_aoi
         |where inc_day = '${day4}' and aoi_id <>''
         |group by
         |aoi_id
         |,name
         |,guid
         |,area_code
      """.stripMargin
    logger.error(villSql)
    val villJoin = SparkUtils.getRowToJson(spark, villSql).map(o => (JSONUtil.getJsonVal(o, "aoi_id", ""), o))

    (allRdd, villJoin)
  }


  def runInter(spark: SparkSession,sourceRdd: RDD[JSONObject],villRdd: RDD[(String,JSONObject)]): RDD[JSONObject] = {
    logger.error("atAoisrc==norm,调分词接口获取分词")

val num2 = sourceRdd.count().toInt
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, splitUrl, "3eb300d2e06947f7945cd02530a32fd2", num2, 10)
    val splitRdd = sourceRdd.repartition(10).map(o=>{

      val check_address = JSONUtil.getJsonVal(o,"check_address","")
      val check_city_code = JSONUtil.getJsonVal(o,"check_city_code","")
      var splitResult = JSONUtil.getJsonVal(o,"splitResult","")
      val atAoiSrc = JSONUtil.getJsonVal(o,"atAoiSrc","")
      val standardization = JSONUtil.getJsonVal(o,"standardization","")

      var level14 = false


      var name6 = ""
      var name13 = ""
      var name5 = ""
      var name9 = ""
      var name11 = ""
      var name613 = ""

      if(atAoiSrc.toLowerCase.equals("norm")){
        val splitResp =  HttpClientUtil.getJsonByGet(String.format(splitUrl,URLEncoder.encode(standardization,"utf-8"),check_city_code))
        o.put("splitReq",splitResp)
        if(splitResp != null ){
          var splitStr = ""
          val splitArr = try {splitResp.getJSONObject("result").getJSONObject("data").getJSONArray("info") } catch { case _ => null}
          //拼接split result
          if( splitArr != null && splitArr.size() > 0 ) {
            for ( i <- Range( 0,splitArr.size() ) ) {
              val json = splitArr.getJSONObject(i)

              //第一个level=13时的【name】as name13；
              if(json.getString("level").equals("13") && name13.isEmpty) name13 = json.getString("name")
              if(json.getString("level").equals("6") && name6.isEmpty) name6 = json.getString("name")
              if(json.getString("level").equals("5") && name5.isEmpty) name5 = json.getString("name")
              //取第一个9+11的值
              if(json.getString("level").equals("9") && name9.isEmpty) name9 = json.getString("name")
              if(name9.nonEmpty && json.getString("level").equals("11") && name11.isEmpty) name11 = json.getString("name")
              splitStr += json.getString("name") + "^" + json.getString("prop") + json.getString("level")
              if( i == splitArr.size()-1 )
                splitStr += ";" + json.getString("level")
              else
                splitStr +=  ","
            }
          }
          splitResult = splitStr
          o.put("splitResult",splitStr)
        }
      }



 if(splitResult.nonEmpty){
   val splitStr = try {
     splitResult.substring(0, splitResult.lastIndexOf(";"))
   } catch {
     case exception: Exception => ""
   }


   splitStr.split(",").map(so => {
     val name = try {
       so.split("\\^")(0)
     } catch {
       case exception: Exception => ""
     }
     var level = try {
       so.split("\\^")(1)
     } catch {
       case exception: Exception => ""
     }

     val tag = try{level.substring(0,1)}catch {case exception: Exception=>""}



     if (level.size > 1) level = level.substring(1, level.size)
     if (level.equals("13") && !tag.equals("6")) name13 = name
     if (level.equals("6") && name6.isEmpty) name6 = name
     if (level.equals("5") && name5.isEmpty) name5 = name
     if (level.equals("9") && name9.isEmpty) name9 = name
     if (name9.nonEmpty && level.equals("11") && name11.isEmpty) name11 = name
     if (level.equals("13") && tag.equals("6")) name613 = name


   })
 }
      o.put("name6",name6)
      o.put("name13",name13+name613)
      o.put("name5",name5)
      o.put("name9",name9)
      o.put("name11",name11)
      o.put("name911",name9+name11)
      o.put("name613",name613)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("判断完分词的数据量：" + splitRdd.count())
    splitRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
    sourceRdd.unpersist()
    //调接口，通过check_x,check_y坐标获取新AOIID,aoi名称,命名为new_
    // http://gis-int.int.sfdc.com.cn:1080/dept2/byxy&ak=3eb300d2e06947f7945cd02530a32fd2&x={}&y={}&opt=aoi&geom=0
    logger.error("获取新的aoiid")
    val reNum = splitRdd.count().toInt
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, aoiUrl, "3eb300d2e06947f7945cd02530a32fd2", reNum, 20)
    val aoiRdd = splitRdd.map(o=>{
      val check_x = JSONUtil.getJsonVal(o,"check_x","")
      val check_y = JSONUtil.getJsonVal(o,"check_y","")
      val current_aoi_id = JSONUtil.getJsonVal(o,"current_aoi_id","")
      val aoiResp =  HttpClientUtil.getJsonByGet(String.format(aoiUrl,check_x,check_y))
      o.put("aoiResp",aoiResp)
      if(aoiResp != null){
      val aoi_data =  try{JSONUtil.getJsonArrayMulti(aoiResp,"result.aoi_data").getJSONObject(0)}catch {case exception: Exception=>new JSONObject()}
      val aoi_id = JSONUtil.getJsonVal(aoi_data,"aoi_id","")
      val aoi_name = JSONUtil.getJsonVal(aoi_data,"aoi_name","")
        o.put("new_aoi_id",aoi_id)
        o.put("new_aoi_name",aoi_name)
        if(current_aoi_id.nonEmpty && current_aoi_id.equals(aoi_id)){
          o.put("result","无需修改")
          o.put("tag","新旧AOI一致")
          o.put("adjust_aoi_id","")
        }
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取完aoiid的数据量：" + aoiRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    aoiRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    splitRdd.unpersist()


    val   nextRdd = aoiRdd.filter(o=>JSONUtil.getJsonVal(o,"tag","").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val  unionRdd = aoiRdd.filter(o=>JSONUtil.getJsonVal(o,"tag","").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("new_aoi_id==current_aoi_id的数据量：" + unionRdd.count())
    logger.error("new_aoi_id != current_aoi_id的数据量：" + nextRdd.count())
    aoiRdd.unpersist()

    val nextRdd1 = nextRdd.filter(o=>{JSONUtil.getJsonVal(o,"name13","").isEmpty}).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val unionRdd1 = nextRdd.filter(o=>{JSONUtil.getJsonVal(o,"name13","").nonEmpty}).map(o=>{
      val name13 = JSONUtil.getJsonVal(o,"name13","")
      val new_aoi_name = JSONUtil.getJsonVal(o,"new_aoi_name","")
      val new_aoi_id = JSONUtil.getJsonVal(o,"new_aoi_id","")
      val current_aoi_name = JSONUtil.getJsonVal(o,"current_aoi_name","")

      var similarityCur13 =  KeyWordUtil.similarity(name13, current_aoi_name)
      o.put("similarityCur13",similarityCur13)
      if(similarityCur13>=0.8){
        o.put("result", "流入审补")
        o.put("tag", "13级与原AOI相似")
        o.put("adjust_aoi_id","")
      }else {
        var similarity13 = KeyWordUtil.similarity(name13, new_aoi_name)
        o.put("similarity13", similarity13)
        if (similarity13 >= 0.8) {
          o.put("result", "可以修改")
          o.put("tag", "13级与AOI相似")
          o.put("adjust_aoi_id", new_aoi_id)
        } else if (new_aoi_id.nonEmpty) {
          //调接口，通过new_aoi_id获取周边50m范围内AOI http://sds-core-datarun.sit.sf-express.com/datarun/aoi/getGeomAoiBase
          val geoAoiResp = HttpClientUtil.getJsonByGet(String.format(geoAoiUrl, new_aoi_id))
          o.put("geoAoiResp", geoAoiResp)
          if (geoAoiResp != null) {
            val data = JSONUtil.getJsonArrayMulti(geoAoiResp, "data")
            Breaks.breakable {
              for (i <- 0 until data.size()) {
                val js = data.getJSONObject(i)
                val name = JSONUtil.getJsonVal(js, "name", "")
                val id = JSONUtil.getJsonVal(js, "id", "")
                var similarity13zb = KeyWordUtil.similarity(name13, name)
                if (similarity13zb >= 0.8) {
                  o.put("result", "流入审补")
                  o.put("tag", "13级与周边AOI相似")
                  o.put("adjust_aoi_id", id)
                  o.put("similarity13zb", similarity13zb)
                  Breaks.break()
                }
              }
            }
          }
        }
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("分词有13级的数据量：" + unionRdd1.count())
    logger.error("分词没有13级的数据量的数据量：" + nextRdd1.count())
    aoiRdd.unpersist()

    val unionRdd2 = unionRdd1.filter(o=>JSONUtil.getJsonVal(o,"tag","").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val nextRdd2 = unionRdd1.filter(o=>JSONUtil.getJsonVal(o,"tag","").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    unionRdd1.unpersist()

    logger.error("判断完13级分词打上tag的数据量：" + unionRdd2.count())
    logger.error("判断完13级分词没打上tag的数据量：" + nextRdd2.count())
    unionRdd1.unpersist()

    val num = nextRdd1.count().toInt
    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, gdUrl, "", num, 5)
    val nextRdd3 = nextRdd1.filter(o=>JSONUtil.getJsonVal(o,"name911","").nonEmpty).repartition(5).map(o=>{
      //调高德pois接口，获取9+11的坐标
      // http://gis-ass-mg.sf-express.com/ScriptTool2023/extension/forward?url=
      // http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api&address={}&city={}&ak=e9106d80834e483189c3439938bac5d2&opt=zh&showserver=true
      val check_address = JSONUtil.getJsonVal(o,"check_address","")
      val new_aoi_id = JSONUtil.getJsonVal(o,"new_aoi_id","")
      val formatStanUrl = String.format(gdUrl, URLEncoder.encode(check_address, "utf-8"))
      val gdObj: JSONObject = getJsonByGet(formatStanUrl)
      o.put("gdObj",gdObj)

      var result = "无法判断"
      var tag = "坐标获取AOI不一致"
      var adjust_aoi_id = ""

      if (gdObj != null) {
        val location = try {JSONUtil.getJsonArrayMulti(gdObj, "pois").getJSONObject(0).getString("location") } catch { case exception: Exception => "" }

      if(location != null && location.nonEmpty){

        val x = try{location.split(",")(0)}catch {case exception: Exception=>"0.0"}
        val y = try{location.split(",")(1)}catch {case exception: Exception=>"0.0"}
        val aoiGdResp =  HttpClientUtil.getJsonByGet(String.format(aoiUrl,x,y))
        o.put("aoiGdResp",aoiGdResp)
        if(aoiGdResp != null){
          val aoi_data =  try{JSONUtil.getJsonArrayMulti(aoiGdResp,"result.aoi_data").getJSONObject(0)}catch {case exception: Exception=>new JSONObject()}
          val aoi_id = JSONUtil.getJsonVal(aoi_data,"aoi_id","")
          val aoi_name = JSONUtil.getJsonVal(aoi_data,"aoi_name","")
          o.put("new_gdaoi_id",aoi_id)
          o.put("new_gdaoi_name",aoi_name)

          if(new_aoi_id.nonEmpty && new_aoi_id.equals(aoi_id)){
            result="流入审补"
            tag="坐标获取AOI一致"
            adjust_aoi_id= aoi_id

          }
        }
      }
      }
     o.put("result",result)
     o.put("tag",tag)
     o.put("adjust_aoi_id",adjust_aoi_id)
    o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val unionRdd3 = nextRdd1.filter(o=>JSONUtil.getJsonVal(o,"name911","").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("存在9+11分词的数据量：" + nextRdd3.count())
    logger.error("不存在9+11分词的数据量：" + unionRdd3.count())
    nextRdd1.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId1)

   val nextRdd4 =  unionRdd3.union(nextRdd2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("判断分词6的数据量" + nextRdd4.count())


    val union5 = nextRdd4.filter(o=>JSONUtil.getJsonVal(o,"name6","").nonEmpty).map(o=>{
      (JSONUtil.getJsonVal(o,"new_aoi_id",""),o)
    }).leftOuterJoin(villRdd).map(o=>{
      val left = o._2._1
      val right = o._2._2

      var result = "无法判断"
      var tag = "6级与行政村不相似"
      var adjust_aoi_id = ""

      if(right.nonEmpty) {
        val js = right.get
        left.put("villName", JSONUtil.getJsonVal(js,"name",""))
        left.put("guid", JSONUtil.getJsonVal(js,"guid",""))
        left.put("area_code", JSONUtil.getJsonVal(js,"area_code",""))
        val name6 = JSONUtil.getJsonVal(left, "name6", "")
        val new_aoi_id = JSONUtil.getJsonVal(left, "new_aoi_id", "")
        var similarity6 = 0.0
        if (name6.nonEmpty) similarity6 = KeyWordUtil.similarity(name6, JSONUtil.getJsonVal(js,"name",""))
        if (similarity6 >= 0.8) {
           result = "流入审补"
           tag = "6级与行政村相似"
           adjust_aoi_id = new_aoi_id
        }
      }

       left.put("result",result)
       left.put("tag",tag)
       left.put("adjust_aoi_id",adjust_aoi_id)


    left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val union6 = nextRdd4.filter(o=>JSONUtil.getJsonVal(o,"name6","").isEmpty).map(o=>{
      val name5 = JSONUtil.getJsonVal(o,"name5","")
      val new_aoi_name = JSONUtil.getJsonVal(o,"new_aoi_name","")
      val new_aoi_id = JSONUtil.getJsonVal(o,"new_aoi_id","")

      var result = "无法判断"
      var tag = "无5级"
      var adjust_aoi_id = ""

      if(name5.nonEmpty){
        var similarity5 = 0.0
        if(name5.nonEmpty)  similarity5 = KeyWordUtil.similarity(name5, new_aoi_name)
        if(similarity5 >= 0.8){
          result = "流入审补"
          tag = "5级与AOI相似"
          adjust_aoi_id = new_aoi_id

        }else{
          result = "无法判断"
          tag = "5级与AOI不相似"
          adjust_aoi_id = ""
        }
      }
      o.put("result",result )
      o.put("tag",tag )
      o.put("adjust_aoi_id",adjust_aoi_id )
      o
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("判断完6级的数据量" + union5.count())
    logger.error("判断完5级的数据量" + union6.count())
    nextRdd4.unpersist()
    val  allRdd = nextRdd3.union(unionRdd).union(unionRdd2).union(union5).union(union6).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("判断完总的数据量" + allRdd.count())
    allRdd
  }

  def getJsonByGet(url: String): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    try {
      var httpResponse: CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpGet.addHeader("ak", "87106f6380af4df0845a693eee58843c")
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity: HttpEntity = httpResponse.getEntity

        try {
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e: Exception => logger.error(">>>结果转换json独享异常：" + e)
          }
        }
        catch {
          case e: Exception => logger.error(">>>获取stringEntity异常：" + e)
        }
      }
      httpResponse.close()
    } catch {
      case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
    }
    httpClient.close()
    jsonObj
  }

  def phSb(js: JSONObject) = {

    var cityCode = JSONUtil.getJsonVal(js, "check_city_code", "")
    var addressId = ""
    var address = ""
    val atAoiSrc = JSONUtil.getJsonVal(js, "atAoiSrc", "")
    val index = System.currentTimeMillis()
    atAoiSrc match {
      case "norm" => {
        addressId = s"sx_norm_${index}"
        address = JSONUtil.getJsonVal(js, "standardization", "")
      }
      case _ => {
        addressId = s"sx_shenbu_${index}"
        address = JSONUtil.getJsonVal(js, "check_address", "")
      }
    }

    if (addressId.nonEmpty && address.nonEmpty) {
      val reqJson = new JSONObject()
      reqJson.put("cityCode", cityCode)
      reqJson.put("addressId", addressId)
      reqJson.put("address", address)
      reqJson.put("priority","0")
      val param = new JSONArray()
      param.add(reqJson)
      //        val req = HttpClientUtil.doPost(pushUrl, reqJson, logger)
      val req = HttpConnection.sendPost(pushUrl, param.toJSONString)
      js.put("pushReq", req)

      val content = try{req.getOrDefault("content","").toString}catch {case exception: Exception=>""}
      val suc = try {JSONUtil.getJsonVal(JSON.parseObject(content), "success", "")} catch { case exception: Exception => "" }
      js.put("status", suc)
      //       val content =  req.getOrDefault("content","")
      //        JSON.parseObject(content)
    }
    js
  }

  def updataSb(o: JSONObject) = {
    var cityCode = JSONUtil.getJsonVal(o,"check_city_code","")
    if(cityCode.isEmpty)  cityCode = JSONUtil.getJsonVal(o,"city_code","")
    var aoiId = JSONUtil.getJsonVal(o,"new_aoi_id","")
    if(aoiId.isEmpty)  aoiId = JSONUtil.getJsonVal(o,"check_aoi_id","")
    var address = JSONUtil.getJsonVal(o, "check_address", "")
    if (address.isEmpty) address = JSONUtil.getJsonVal(o, "address", "")
    var addressId=  JSONUtil.getJsonVal(o,"group_id","")
    var checkZnoCode=  1
    var operUserName=  "01422529"
    var aoiCheckTag=  10
    var addressIds=  JSONUtil.getJsonVal(o,"group_id","")
    val zcCheck = 1
    val atAoiSrc = JSONUtil.getJsonVal(o, "atAoiSrc", "")
    atAoiSrc match {
      case "norm" => {
        val js  = new JSONObject()
        js.put("cityCode",cityCode)
        js.put("addressId",addressId)
        js.put("aoiId",aoiId)
        js.put("checkZnoCode",checkZnoCode)
        js.put("operSource","顺心标准审核")
        js.put("operUserName",operUserName)
        js.put("aoiSource", "S99")

        val updataReq = HttpConnection.sendPost(updataUrl, js.toJSONString)
        val js2 = new JSONObject()
        val list = new JSONArray()
        list.add(addressIds)
        js2.put("cityCode",cityCode)
        js2.put("aoiCheckTag",aoiCheckTag)
        js2.put("addressIds",list)
        val updataAoiReq = HttpConnection.sendPost(updataAoiUrl, js2.toJSONString)
      o.put("updataReq",updataReq)
      o.put("updataAoiReq",updataAoiReq)

        val content = try{updataReq.getOrDefault("content","").toString}catch {case exception: Exception=>""}
        val content2 = try{updataAoiReq.getOrDefault("content","").toString}catch {case exception: Exception=>""}

        val bzSuc = try {JSONUtil.getJsonVal(JSON.parseObject(content), "success", "")} catch { case exception: Exception => "" }
        val suc = try {JSONUtil.getJsonVal(JSON.parseObject(content2), "success", "")} catch { case exception: Exception => "" }

        //更新标准库
//        o.put("bzUpdataTag", bzSuc)
        //地址AOI判错更新(通过addressId更新)
        o.put("status", suc)

      }
      case _ => {
        val js = new JSONObject()
        js.put("operSource", "顺心审补审核")
        js.put("ak", operUserName)
        js.put("operUserName", operUserName)
        val param = new JSONObject()
        param.put("cityCode", cityCode)
        param.put("address", address)
        param.put("aoiId", aoiId)
        param.put("zcCheck", zcCheck)
        param.put("src", 1)
        js.put("addressSave", param)
        val addSbReq = HttpClientUtil.doPost(addSbUrl, js, logger)
        val sbJs = try{JSON.parseObject(addSbReq)}catch {case exception: Exception =>new JSONObject()}
        o.put("addSbReq",addSbReq)
        if(sbJs != null){
       val addressMd5 = JSONUtil.getJsonVal(sbJs,"data.addressMd5","")
          val js2 = new JSONObject()
          val list = new JSONArray()
          list.add(addressMd5)
          js2.put("cityCode", cityCode)
          js2.put("aoiCheckTag", aoiCheckTag)
          js2.put("addressMd5s", list)
          val addSbReq = HttpClientUtil.doPost(updateMd5Url, js2, logger)
          o.put("addSbMd5Req",addSbReq)
          val suc = try{JSONUtil.getJsonVal(JSON.parseObject(addSbReq),"success","")}catch {case exception: Exception=>""}
          //地址AOI判错更新(通过addressMd5更新)
          o.put("status",suc)
        }
      }
    }
    o
  }

  def saveDetail(spark: SparkSession, checkOverRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    val rowDf = checkOverRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("数量：" + rowDf.count())

    logger.error("明细表表名" + tableName)
    rowDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    //    val saveDf= saveRdd.map(o=>{
    val saveDf= checkOverRdd.map(o=>{
      val check_address= JSONUtil.getJsonVal(o,"check_address","")
      val waybill_no= JSONUtil.getJsonVal(o,"waybill_no","")
      val check_city_code= JSONUtil.getJsonVal(o,"check_city_code","")
      val check_x= JSONUtil.getJsonVal(o,"check_x","")
      val check_y= JSONUtil.getJsonVal(o,"check_y","")
      val splitResult= JSONUtil.getJsonVal(o,"splitResult","")
      val group_id= JSONUtil.getJsonVal(o,"group_id","")
      val current_aoi_name= JSONUtil.getJsonVal(o,"current_aoi_name","")
      val current_aoi_id= JSONUtil.getJsonVal(o,"current_aoi_id","")
      val new_aoi_id= JSONUtil.getJsonVal(o,"new_aoi_id","")
      val new_aoi_name= JSONUtil.getJsonVal(o,"new_aoi_name","")
      val result= JSONUtil.getJsonVal(o,"result","")
      val tag= JSONUtil.getJsonVal(o,"tag","")
      val adjust_aoi_id= JSONUtil.getJsonVal(o,"adjust_aoi_id","")
      val villName= JSONUtil.getJsonVal(o,"villName","")
      val guid= JSONUtil.getJsonVal(o,"guid","")
      val area_code= JSONUtil.getJsonVal(o,"area_code","")
      val atAoiSrc= JSONUtil.getJsonVal(o,"atAoiSrc","")
      val standardization= JSONUtil.getJsonVal(o,"standardization","")
      val status= JSONUtil.getJsonVal(o,"status","")

      Result(
        check_address
        ,waybill_no
        ,check_city_code
        ,check_x
        ,check_y
        ,splitResult
        ,group_id
        ,current_aoi_name
        ,current_aoi_id
        ,new_aoi_id
        ,new_aoi_name
        ,result
        ,tag
        ,adjust_aoi_id
        ,villName
        ,guid
        ,area_code
        ,atAoiSrc
        ,standardization

        ,status
      )
    }).toDF()

    logger.error("最终表表名" + allTableName)
    saveDf.coalesce(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(allTableName)

  }
  def saveAoiDetail(spark: SparkSession, checkOverRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    val rowDf = checkOverRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("数量：" + rowDf.count())

    logger.error("明细表表名" + aoiDetailTableName)
    rowDf.repartition(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(aoiDetailTableName)


    val saveDf= checkOverRdd.map(o=>{
      val city_code= JSONUtil.getJsonVal(o,"city_code","")
      val address= JSONUtil.getJsonVal(o,"address","")
      val check_aoi_id= JSONUtil.getJsonVal(o,"check_aoi_id","")
      val groupid= JSONUtil.getJsonVal(o,"groupid","")
      val aoiid= JSONUtil.getJsonVal(o,"aoiid","")
      val atAoiSrc= JSONUtil.getJsonVal(o,"atAoiSrc","")
      val status= JSONUtil.getJsonVal(o,"status","")
      val address_id= JSONUtil.getJsonVal(o,"address_id","")
      val check_dept_code= JSONUtil.getJsonVal(o,"check_dept_code","")
      val check_sch_code= JSONUtil.getJsonVal(o,"check_sch_code","")
      val check_aoi_code= JSONUtil.getJsonVal(o,"check_aoi_code","")
      val check_aoi_name= JSONUtil.getJsonVal(o,"check_aoi_name","")
      val check_x= JSONUtil.getJsonVal(o,"check_x","")
      val check_y= JSONUtil.getJsonVal(o,"check_y","")
      Result2(
         city_code
        ,address_id
        ,address
        ,check_dept_code
        ,check_sch_code
        ,check_aoi_code
        ,check_aoi_id
        ,check_aoi_name
        ,check_x
        ,check_y
        ,atAoiSrc
        ,aoiid
        ,groupid
        ,status
      )
    }).toDF()
    logger.error("最终表表名" + aoiTableName)
    saveDf.coalesce(20).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(aoiTableName)

  }


  def runSbInter(spark: SparkSession,sourceRdd: RDD[JSONObject], aoiRdd: RDD[(String, String)]) = {



    val xgRdd = sourceRdd.filter(o => !JSONUtil.getJsonVal(o, "result", "").equals("无需修改")).persist(StorageLevel.MEMORY_AND_DISK)
    val sbRdd = xgRdd.filter(o => JSONUtil.getJsonVal(o, "result", "").equals("可以修改")).persist(StorageLevel.MEMORY_AND_DISK)
    val sbRdd2 = xgRdd.filter(o => !JSONUtil.getJsonVal(o, "result", "").equals("可以修改")).persist(StorageLevel.MEMORY_AND_DISK)
    val sbUnionRdd = sourceRdd.filter(o => JSONUtil.getJsonVal(o, "result", "").equals("无需修改")).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断审补的数据量：" + sbRdd.count())
    logger.error("不需要审补的数据量：" + sbUnionRdd.count())




    sourceRdd.unpersist()
    val codeRdd = sbRdd.map(o => (JSONUtil.getJsonVal(o, "current_aoi_id", ""), o)).leftOuterJoin(aoiRdd).map(o => {
      val left = o._2._1
      val right = o._2._2
      if (right.nonEmpty) {
        left.put("class_code", right.get)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("取到偏远乡村编码的数据量：" + codeRdd.count())
    sbRdd.unpersist()
    val updateRdd = codeRdd.filter(o => Array("210", "220", "").contains(JSONUtil.getJsonVal(o, "class_code", "")))
    val updateUinonRdd = codeRdd.filter(o => !Array("210", "220", "").contains(JSONUtil.getJsonVal(o, "class_code", "")))
    logger.error("class_code是210 or 220 or 空的数据量：" + updateRdd.count())
    logger.error("class_code不是210 or 220 or 空的数据量：" + updateUinonRdd.count())
    val pushRdd = sbRdd2.union(updateUinonRdd)
    val reNum = updateUinonRdd.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, pushUrl, "e9106d80834e483189c3439938bac5d2", reNum, 20)
    val finPushRdd = pushRdd.repartition(20).map(o => phSb(o)).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("推送审补的数据量：" + finPushRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    logger.error("更新或新增标准库")
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updataUrl, "", reNum, 20)
    val httpInvokeId3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updataAoiUrl, "", reNum, 20)
    val httpInvokeId4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, addSbUrl, "", reNum, 20)
    val httpInvokeId5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, updateMd5Url, "", reNum, 20)
    val finUpateRdd = updateRdd.repartition(20).map(o=>updataSb(o))
      .persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("更新或新增标准库的数据量：" + finUpateRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId3)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId4)
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId5)
   val allRdd =  finUpateRdd.union(finPushRdd).union(sbUnionRdd) .persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完的数据量："+allRdd.count())
    allRdd
  }
















  def startSta(spark: SparkSession, incDay: String): Unit = {
    logger.error("获取顺心运营数据")
    val   (signCheckRdd,villRdd)= querySignData(spark, incDay)
    logger.error("接口处理原始数据")
    val finRdd = runInter(spark,signCheckRdd,villRdd)
    logger.error("获取偏远乡村aoi数据")
    val aoiRdd = queryAoiData(spark, incDay)
    logger.error("推送审核平台")
    val allRdd = runSbInter(spark,finRdd,aoiRdd)

    logger.error("入库指标完毕")
    logger.error("入库明细开始")
    saveDetail(spark, allRdd, incDay)
    logger.error("入库明细完毕")

    logger.error("处理CGCS日常任务数据")
    doAddrData(spark, incDay)
    logger.error("处理结束")
  }



  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //    fromDay:跑数时间 yyyy-mm-dd

    //    for (i <- 0 until days) {
    val incDay = DateUtil.getDateStr(startDay, 0, "") //-7 yyyy-mm-dd

    logger.error(s"开始计算：incDay:${incDay}")
    startSta(spark, incDay)
    logger.error("计算结束：" + incDay)
    //    }
    logger.error("统计完毕")
  }


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")
  }


}
