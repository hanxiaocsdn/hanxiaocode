package com.sf.gis.scala.sx.shunxin

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.sx.util.{SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object ShunxinShenbuRecovery {
  @transient lazy val logger: Logger = Logger.getLogger(ShunxinShenbuRecovery.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val xy_dept_url = "http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?ak=1245f89114fb4f5e896213904b4923a5&lng=%s&lat=%s&sys_type=SX"
  val updateUrl = "http://gdssexpress-gis-ass-gdss.dcn.k8s.sf-express.com/dispatch/api/edit"

  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")


  }

  case class result(
                     city_code: String
                     , address: String
                     , check_x: String
                     , check_y: String
                     , zno_code: String
                     , check_date: String
                     , incday: String
                     , detail: String
                     , inc_day: String
                   )


  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val seqDay = startDay.replaceAll("-", "") //t-2

    logger.error(s"开始计算：startDay：${startDay},seqDay:${seqDay}")
    val starRdd = startSta(spark, startDay, seqDay)
    logger.error("计算结束：" + startDay)

    logger.error("统计完毕")
  }

  //  incDay 取T-1
  def startSta(spark: SparkSession, incDay: String, seqDay: String) = {

    logger.error("获取数据源")
    //取数据源,
    val (dataRdd, hisRdd, shenbuRdd) = getDataDf(spark, incDay, seqDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("打tag标签")


    //打tag
    val tagRdd = checkTag(dataRdd, hisRdd)
    logger.error(tagRdd.take(10).foreach(println(_)))
    logger.error("打完标签")
    logger.error("更新接口")
    val finalRdd = upData(tagRdd)
    logger.error("更新接口完毕")

    //


    //更新tag
    val reRdd = uptag(finalRdd, shenbuRdd)
    logger.error("开始入库")
    //入库
    saveTable(spark, reRdd, incDay)
    logger.error("结束所有运行")

  }


  def checkTag(dataRdd: RDD[JSONObject], hisRdd: RDD[(String, JSONObject)]) = {

    logger.error("打标签的数据量:"+dataRdd.count())


    val next = dataRdd.coalesce(seg_partition).map(
      obj => {
        val tag = JSONUtil.getJsonVal(obj, "tag", "")
        if (tag.equals("work")) {
          //获取坐标点落面,坐标改
          val x = JSONUtil.getJsonVal(obj, "check_x", "")
          val y = JSONUtil.getJsonVal(obj, "check_y", "")
          val sxCode = JSONUtil.getJsonVal(obj, "sx_code", "")
          val aoiSxCode = JSONUtil.getJsonVal(obj, "aoi_sxcode", "")
          val tsSxCode = JSONUtil.getJsonVal(obj, "ts_sxcode", "")
          val precisionGd = JSONUtil.getJsonVal(obj, "precision_gd", "")
          val (manCode, manRet) = xy2Dept(xy_dept_url, x, y)
          obj.put("man_code", manCode)
          obj.put("man_ret", manRet)

          if (manCode.nonEmpty && manCode.equals(sxCode)) obj.put("tag", "correct")
          else if (manCode.nonEmpty && (manCode.equals(aoiSxCode) || ((manCode.equals(tsSxCode) && precisionGd.equals("2"))))) obj.put("tag", "update")
        }

        obj
      }
    ).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)

    val unionRdd1 = next.filter(obj => {
      "correct,update".split(",").contains(JSONUtil.getJsonVal(obj, "tag", ""))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val nextRdd1 = next.filter(obj => {
      !"correct,update".split(",").contains(JSONUtil.getJsonVal(obj, "tag", ""))
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("work tag为correct，update的数据量:" + unionRdd1.count())
    logger.error("排除的数据量:" + nextRdd1.count())


    //    gis_identify_site_address
    //    ,sign_created_time
    //    ,ewb_sign_site_code
    //    ,ewb_created_time
    //    from Ky.ods_sxne.hs_gis_feedback
    //    where  datediff(sign_created_time,ewb_created_time) <= 7


    val next2 = nextRdd1.map(obj => {
      (JSONUtil.getJsonVal(obj, "address", ""), obj)
    }).leftOuterJoin(hisRdd)
      .map(obj => {
        val left = obj._2._1
        val right = obj._2._2
        left.put("cnt", 0)
        if (right.nonEmpty) {
          val incDay = JSONUtil.getJsonVal(right.get, "sign_created_time", "")
          val ewb_created_time = JSONUtil.getJsonVal(right.get, "ewb_created_time", "")
          val checkDate = JSONUtil.getJsonVal(left, "check_date_cgcs", "")
          val deptCode = JSONUtil.getJsonVal(right.get, "ewb_sign_site_code", "")
          val timediff = JSONUtil.getJsonVal(right.get, "timediff", "")
          val sxCode = JSONUtil.getJsonVal(left, "sx_code", "")
          left.put("sign_created_time", incDay)
          left.put("ewb_created_time", ewb_created_time)

          //关联匹配到赋值
          if (checkDate.nonEmpty && timediff.nonEmpty && incDay.nonEmpty && timediff.toInt <= 7 && checkDate < incDay) {
            left.put("ewb_sign_site_code", deptCode)
            left.put("cnt", 1)
            //deptcode=sx_code?
            if (deptCode.nonEmpty && deptCode.equals(sxCode)) left.put("tag", "correct")

          }
        }
        (obj._1, left)
      }
      ).reduceByKey((obj1, obj2) => {
      val tag1 = JSONUtil.getJsonVal(obj1, "tag", "")
      val tag2 = JSONUtil.getJsonVal(obj2, "tag", "")
      obj1.put("cnt", obj1.getInteger("cnt") + obj2.getInteger("cnt"))
      //tag只要有correct，将标签打为correct
      if (tag2.equals("correct")) {
        obj1.put("tag", tag2)
      }

      obj1
    }).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)

    val unionRdd2 = next2.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").equals("correct")
    })
    val nextRdd2 = next2.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").equals("correct")
    })

    logger.error("deptcode=sx_code的数据量:" + unionRdd2.count())
    logger.error("排除的数据量:" + nextRdd2.count())

    //用地址关联历史签收表获取check_date<sign_created_time时address的频次c1
    val finalRdd = nextRdd2.map(obj => {
      if (obj.getInteger("cnt") <= 1) obj.put("tag", "remain")
      else obj.put("tag", "wrong")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val resRdd = finalRdd.union(unionRdd2).union(unionRdd1)

    logger.error("打完标签的数据量:"+ resRdd.count())


    resRdd
  }


  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""
            //点落面接口
            val (deptCode, deptRet) = xy2Dept(xy_dept_url, x, y)
            ret.put("deptCode", deptCode)
            ret.put("deptRet", deptRet)
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  //  def saveTable(spark: SparkSession, staRdd: RDD[JSONObject], incDay: String): Unit = {
  //    import spark.implicits._
  //
  //    val tableName = "dm_gis.shunxinshenbu_detail_di" //生产数据表
  //    val detailRdd = staRdd.map(obj => {
  //      result(
  //        JSONUtil.getJsonVal(obj, "city_code", ""),
  //        JSONUtil.getJsonVal(obj, "address", ""),
  //        JSONUtil.getJsonVal(obj, "check_x", ""),
  //        JSONUtil.getJsonVal(obj, "check_y", ""),
  //        JSONUtil.getJsonVal(obj, "zno_code", ""),
  //        JSONUtil.getJsonVal(obj, "check_date", ""),
  //        JSONUtil.getJsonVal(obj, "inc_day", ""),
  //        obj.toJSONString.replaceAll("[\\r\\n\\t]", "")
  //      )
  //    }
  //    ).toDF()
  //
  //    logger.error("入明细表数量：" + detailRdd.count())
  //    detailRdd.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
  //    logger.error("明细表入库完成")
  //
  //
  //   val workRdd =  staRdd.filter(obj => {
  //      JSONUtil.getJsonVal(obj, "tag", "").eq("work")
  //    }).map(obj => {
  //      result(
  //        JSONUtil.getJsonVal(obj, "city_code", ""),
  //        JSONUtil.getJsonVal(obj, "address", ""),
  //        JSONUtil.getJsonVal(obj, "check_x", ""),
  //        JSONUtil.getJsonVal(obj, "check_y", ""),
  //        JSONUtil.getJsonVal(obj, "zno_code", ""),
  //        JSONUtil.getJsonVal(obj, "check_date", ""),
  //        JSONUtil.getJsonVal(obj, "inc_day", ""),
  //        obj.toJSONString.replaceAll("[\\r\\n\\t]", "")
  //      )
  //    }
  //    ).toDF()
  //    logger.error("入库下发人工作业明细表数据"+workRdd.count())
  //
  //    val workTableName = "dm_gis.shunxinshenbu_work_di" //生产表
  //     workRdd.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(workTableName)
  //    logger.error("入库下发人工作业表入库完成")
  //  }


  def getDataDf(spark: SparkSession, incDay: String, seqDay: String) = {

//    //    获取作业结果表   增量数据--cxg
//    val dataSql =
//      """
//        | select
//        |   a.check_date_cgcs
//        |  ,a.city_code
//        |  ,a.address
//        |  ,a.check_x
//        |  ,a.check_y
//        |  ,a.tag
//        |  ,a.aoi_sxcode
//        |  ,a.ts_sxcode
//        |  ,a.precision_gd
//        |  ,a.sx_code
//        |  ,a.check_date
//        | from (
//        |     select
//        |    a.check_date as check_date_cgcs
//        |   ,a.city_code
//        |   ,a.address
//        |   ,a.check_x
//        |   ,a.check_y
//        |  ,get_json_object(b.detail,'$.tag') as tag
//        |  ,get_json_object(b.detail,'$.aoi_sxcode') as aoi_sxcode
//        |  ,get_json_object(b.detail,'$.ts_sxcode') as ts_sxcode
//        |  ,get_json_object(b.detail,'$.precision_gd') as precision_gd
//        |  ,get_json_object(b.detail,'$.sx_code') as sx_code
//        |  ,b.check_date
//        |  ,row_number()over(partition by a.address order by a.check_date desc ) rn
//        |  from
//        |  dm_gis.sxky_result_from_cgcs a
//        |  inner join
//        |  dm_gis.shunxinshenbu_detail_di b
//        |  on a.address = b.address
//        |  and get_json_object(b.detail,'$.tag') in ('work','sch_empty')
//        |  and b.inc_day =   date_format(date_sub('%s',pmod(datediff('%s','1900-01-08'),7)),'yyyyMMdd')
//        |  where a.inc_day = '%s'
//        | ) a
//        |where rn = 1
//        |union all
//        |--之前下发剔除的审补数据
//        |select
//        |check_date_cgcs
//        |,city_code
//        |,address
//        |,check_x
//        |,check_y
//        |,tag
//        |,aoi_sxcode
//        |,ts_sxcode
//        |,precision_gd
//        |,sx_code
//        |,check_date
//        |from dm_gis.shunxinshenbu_detail_tmp_di
//        |where inc_day =  date_format(date_sub('%s',pmod(datediff('%s','1900-01-08'),7)),'yyyyMMdd')
//      """.stripMargin


        val dataSql =
          """
                 select
          |    b.check_date as check_date_cgcs
          |   ,b.city_code
          |   ,b.address
          |   ,b.check_x
          |   ,b.check_y
          |   ,case when c.address is not null and b.address is not null then 'work'
          |	 when c.address is not null and b.address is  null then 'empty'
          |	end as tag
          |  --,get_json_object(a.detail,'$.tag') as tag
          |  ,get_json_object(a.detail,'$.aoi_sxcode') as aoi_sxcode
          |  ,get_json_object(a.detail,'$.ts_sxcode') as ts_sxcode
          |  ,get_json_object(a.detail,'$.precision_gd') as precision_gd
          |  ,get_json_object(a.detail,'$.sx_code') as sx_code
          |  ,a.check_date
          |
          |  from dm_gis.shunxinshenbu_detail_di a
          |  left join
          |  (
          |  select
          |    check_date
          |   ,city_code
          |   ,address
          |   ,check_x
          |   ,check_y
          |  from default.qhz_net_0926 b
          |  group by
          |    check_date
          |   ,city_code
          |   ,address
          |   ,check_x
          |   ,check_y
          |  ) b
          |  on a.address = b.address
          |  --手工下发审补
          |  left join
          |  (
          |  select
          |  address
          |  from default.qhz_net_0928 c
          |  group by address
          |  ) c
          | on a.address = c.address
          |where a.inc_day =  '%s' and ((c.address is not null and b.address is not null) or (c.address is not null and b.address is  null))
          |union all
          |--之前下发剔除的审补数据
          |select
          |check_date_cgcs
          |,city_code
          |,address
          |,check_x
          |,check_y
          |,tag
          |,aoi_sxcode
          |,ts_sxcode
          |,precision_gd
          |,sx_code
          |,check_date
          |from dm_gis.shunxinshenbu_detail_tmp_di
          |where inc_day =  '%s'
          """.stripMargin


    val formatSql = String.format(dataSql, incDay, incDay)
//    val formatSql = String.format(dataSql, incDay, incDay, seqDay, incDay, incDay)
    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition)
    logger.error(totalRdd.take(10).foreach(println(_)))


    //获取历史签收表
    //    val hisSql =
    //      """
    //        |  select
    //        |  get_json_object(detail,'$.signAddress') as signAddress
    //        |  ,get_json_object(detail,'$.deptcode') as deptcode
    //        |  ,substring(inc_day,0,6) as inc_day
    //        |  from
    //        |  tmp_dm_gis.tmp_shunxin_wyabill_detail
    //        |  where '202105'<=substring(inc_day,0,6) and  substring(inc_day,0,6) <='202107' and get_json_object(detail,'$.signAddress') <> ''
    //        |  union all
    //        |  select
    //        |  get_json_object(detail,'$.signAddress') as signAddress
    //        |  ,get_json_object(detail,'$.deptcode') as deptcode
    //        |  ,substring(inc_day,0,6) as inc_day
    //        |  from
    //        |  tmp_dm_gis.tmp_shunxin_wyabill_detail_di
    //        |  where '202108'<=substring(inc_day,0,6) and get_json_object(detail,'$.signAddress') <> ''
    //      """.stripMargin
    //
    //
    val hisSql =
    """
      |select
      |gis_identify_site_address as signAddress
      |,sign_created_time
      |,ewb_sign_site_code
      |,ewb_created_time
      |,datediff(sign_created_time,ewb_created_time) as timediff
      |from Ky.ods_sxne.hs_gis_feedback
    """.stripMargin


    logger.error(hisSql)
    val hisRdd = SparkUtils.getRowToJson(spark, hisSql).map(obj => {
      (JSONUtil.getJsonVal(obj, "signAddress", ""), obj)
    }).repartition(sqlpartition)
    logger.error(hisRdd.take(10).foreach(println(_)))

    //获取

//    val shenbuSql =
//      s"""
//         |  select
//         |city_code
//         |,address
//         |,check_x
//         |,check_y
//         |,zno_code
//         |,check_date
//         |,incday
//         |,detail
//         |,inc_day
//         |from
//         |dm_gis.shunxinshenbu_detail_di
//         |where inc_day = date_format(date_sub('${incDay}',pmod(datediff('${incDay}','1900-01-08'),7)),'yyyyMMdd')
//   """.stripMargin


//全量数据
    val shenbuSql =
      s"""
         |  select
         |city_code
         |,address
         |,check_x
         |,check_y
         |,zno_code
         |,check_date
         |,incday
         |,detail
         |,inc_day
         |from
         |dm_gis.shunxinshenbu_detail_di
         |where inc_day = ${incDay}
   """.stripMargin







    logger.error(shenbuSql)
    val shenbuRdd = SparkUtils.getRowToJson(spark, shenbuSql).map(obj => {
      (JSONUtil.getJsonVal(obj, "address", ""), obj)
    }).repartition(sqlpartition)


    (totalRdd, hisRdd, shenbuRdd)
  }

  //点落面接口
  def xy2Dept(xyDeptUrl: String, lgt: String, lat: String): (String, JSONObject) = {
    var ret = null: JSONObject
    try {
      if (lgt != null && !lgt.isEmpty) {
        ret = HttpClientUtil.getJsonByGet(String.format(xyDeptUrl, lgt, lat))
        if (ret != null && ret.getJSONObject("result") != null) {
          if (ret.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return xy2Dept(xyDeptUrl, lgt, lat)
          }
          val mapArray = JSONUtil.getJsonArrayFromObject(ret, "result.map_data", null)
          if (mapArray != null && mapArray.size() > 0) {
            val code = JSONUtil.getJsonVal(mapArray.getJSONObject(0), "code", "")
            return (code, ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ("", ret)
  }

  //  //根据aoi获取aoicode
  //  def getAoiCode(aoi: String, fomatCity: String, address: String) = {
  //
  //
  //
  //    var sxAoiCode = ""
  //    var geoAoi = ""
  //    var dept = ""
  //    var ret: JSONObject = null
  //
  //    val geoAoiRet = HttpClientUtil.getJsonByGet(String.format(rzUrl, URLEncoder.encode(address, "utf-8"),fomatCity ), 3)
  //
  //
  //
  //
  //
  //
  //    //获取geoaoi
  //    if (geoAoiRet != null) {
  //
  //
  //      geoAoi = try {
  //        geoAoiRet.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid")
  //      }
  //      catch {
  //        case e: Exception => ""
  //
  //      }
  //
  //
  //      dept = try {
  //       geoAoiRet.getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept")
  //      }
  //      catch {
  //        case exception: Exception => ""
  //      }
  //
  //    }
  //
  //    //获取顺心Aoicode
  //    if (geoAoi != null && !geoAoi.isEmpty  ) {
  //      //    mapb_url = http://10.220.13.63:1080/atdispatch/api?ak=8cb19f422db34736922479ba0bc848f4&opt=zh&city=&address=%s
  //      ret = HttpClientUtil.getJsonByGet(String.format(sxUrl, geoAoi))
  //      if (ret != null) sxAoiCode = JSONUtil.getJsonVal(ret, "data.code", "")
  //    }
  //    (geoAoi, dept, geoAoiRet, sxAoiCode, ret)
  //  }
  //
  //调更新接口
  def upData(tagRdd: RDD[JSONObject]) = {

    val reqRdd = tagRdd.repartition(10).map(obj => {
      val tag = JSONUtil.getJsonVal(obj, "tag", "")
      val check_x = JSONUtil.getJsonVal(obj, "check_x", "")
      val check_y = JSONUtil.getJsonVal(obj, "check_y", "")
      val address = JSONUtil.getJsonVal(obj, "address", "")


      val parm = new JSONObject()
      if (tag.equals("update")) {
        parm.put("checkAddress", address)
        parm.put("checkX", check_x)
        parm.put("checkY", check_y)

      }


      val httpData = HttpConnection.sendPost(updateUrl, parm.toJSONString)

      obj.put("updataReq", httpData.getOrDefault("content", ""))
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    reqRdd
  }

  //更新源表数据
  def uptag(dataRdd: RDD[JSONObject], joinRdd: RDD[(String, JSONObject)]) = {
    val formatDataRdd = dataRdd.map(obj => {
      (JSONUtil.getJsonVal(obj, "address", ""), obj)
    })
    val reRdd = joinRdd.leftOuterJoin(formatDataRdd).map(obj => {
      val left = obj._2._1
      val right = obj._2._2
      val detail = JSONUtil.getJsonVal(left, "detail", "")
      val detailObject = try {
        JSON.parseObject(detail)
      } catch {
        case e: Exception => new JSONObject()
      }

      if (right.nonEmpty) {
        val recoveryObject = right.get
        detailObject.put("recovery_data", recoveryObject)
        //更新tag
        detailObject.put("tag", JSONUtil.getJsonVal(recoveryObject, "tag", ""))
      }

      detailObject.put("detail_old", detail)
      left.put("detail", detailObject.toString.replaceAll("[\\r\\n\\t]", ""))
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("更tag的数据量：" + reRdd.count())
    reRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })
    reRdd
  }


  def saveTable(spark: SparkSession, staRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._

    val tableName = "dm_gis.shunxinshenbu_detail_di_tmp" //生产数据表
    val detailRdd = staRdd.map(obj => {

      result(
        JSONUtil.getJsonVal(obj, "city_code", ""),
        JSONUtil.getJsonVal(obj, "address", ""),
        JSONUtil.getJsonVal(obj, "check_x", ""),
        JSONUtil.getJsonVal(obj, "check_y", ""),
        JSONUtil.getJsonVal(obj, "zno_code", ""),
        JSONUtil.getJsonVal(obj, "check_date", ""),
        JSONUtil.getJsonVal(obj, "incday", ""),
        JSONUtil.getJsonVal(obj, "detail", ""),
        JSONUtil.getJsonVal(obj, "inc_day", "")
      )
    }
    ).toDF()

    logger.error("入明细表数量：" + detailRdd.count())
    detailRdd.write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("明细表入库完成")

  }


}
