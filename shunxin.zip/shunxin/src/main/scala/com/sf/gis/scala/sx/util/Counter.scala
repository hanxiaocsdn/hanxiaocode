package com.sf.gis.scala.sx.util

import java.util.Date

object Counter {
    var overRate = 0.985
    var c = 0l  //总量计数
    var d = 0l  //1000次内计数
    var tm100 = 0l   //耗时<=100毫秒计数
    var tm500 = 0l   //耗时>100,<=500毫秒计数
    var tm1000 = 0l   //耗时>500,<=1000毫秒计数
    var tm1000gt = 0l   //耗时>1000毫秒计数

    var costA = 0l
    var costB = 0l

    var sleep = 200
    var minSleep = 0
    var tm = new Date().getTime

    var lastState = ""
    var overSpeed = false
    var speedLimit = 0

    var speedInited = false
    def initSpeed(akSpeedPerMin:Int,numExecutors:Int,executorCores:Int): Unit ={
        this.synchronized{
            if(!speedInited){
                sleep = Math.ceil(1000 / (akSpeedPerMin / numExecutors / executorCores / 60)).toInt
                speedLimit = Math.ceil(akSpeedPerMin / numExecutors).toInt
                speedInited = true
            }
        }
    }



    def count(t0:Long,tp:String="",userMark:String=""): Unit ={
        //println(Counter.sleep)
        val cost = new Date().getTime - t0
        addTm(cost,tp)

        if(cost<Counter.sleep) {
            if(lastState!="."){
                lastState = "."
            }
            val slp = Counter.sleep-cost
            if(slp>0) {
                //println(Counter.sleep + "\t" + slp)
                Thread.sleep(slp)
            }
        }
        else {
            if(lastState!="|"){
                lastState = "|"
            }
        }
        Counter.add()
        if(Counter.c % 10 == 0){
            if(userMark!="")
                print(userMark)
            else
                print(lastState)
        }

        if(Counter.c % 100 == 0){
            val speed = Counter.getSpeedPerMinute()
            if(Counter.c % 1000 == 0)
                println("\t"+Counter.c + "\tspeed: "+ speed + "\tsleep: "+Counter.sleep + "\tcost 0~100,101~500,501~1000,1000+: "+Counter.tm100+","+Counter.tm500+","+Counter.tm1000+","+Counter.tm1000gt)

            if((!overSpeed) && speed < speedLimit * overRate ){
                var t = Math.ceil(sleep * (1 - speed.toDouble / speedLimit.toDouble) / 20.0).toInt
                if(t<3) t = 3
                if(t>5) t = 5
                if(Counter.sleep >= t)
                    Counter.sleep -= t
            }
            if(overSpeed){//speed > speedLimit
                Counter.sleep += 1
            }
            if(Counter.c % 1000 == 0)
                Counter.reset()
        }
    }

    def add(): Unit ={
        this.synchronized({
            c += 1
            d += 1
        })
    }
    def addTm(tm:Long,tp:String): Unit ={
        this.synchronized({
            if(tm <= 100)
                tm100 += 1
            else if(tm<=500)
                tm500 += 1
            else if(tm<=1000)
                tm1000 += 1
            else
                tm1000gt += 1

            if(tp == "A")
                costA += tm
            else if(tp == "B")
                costB += tm
        })
    }

    def getIPWeight() ={
        this.synchronized({
            val sum = costA + costB
            if(sum>0) 1 - costA.toDouble/sum else 0.5
        })
    }

    def getSeconds()={
        (new Date().getTime - tm)/1000
    }

    def getSpeedPerSecond() ={
        val sec = getSeconds()
        Math.floor(d.toDouble / (if(sec==0)0.00000001 else sec)).toInt
    }
    def getSpeedPerMinute() ={
        val sec = getSeconds()
        Math.floor(d.toDouble / (if(sec==0)0.00000001 else sec) * 60).toInt
    }

    def reset(): Unit ={
        tm = new Date().getTime
        d = 0
        tm100 = 0
        tm500 = 0
        tm1000 = 0
        tm1000gt = 0
        costA = 0l
        costB = 0l
        overSpeed = false
    }
}


