package com.sf.gis.scala.sx.util

import java.sql.DriverManager
import java.util.{Map, Properties}

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.java.sx.constant.util.{JavaUtil, Utils}
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.commons.lang.StringUtils

object SparkUtils {
  //aggregateByKey的柯里化函数,将JSONObject聚合成List[JSONObject]
  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  val seqOpRow = (a: List[Row], b: Row) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOpRow = (a: List[Row], b: List[Row]) => {
    a ::: b
  }

  //进行post请求，失败后重试一次
  def doPost(url:String,reqJson:JSONObject,logger:Logger) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = Utils.post(url, reqJson, "utf-8")
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
        try {
          resbonseBody = Utils.post(url, reqJson, "utf-8")
        } catch {
          case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
            resbonseBody = "发送post请求失败:" + e.toString
        }
    }
    resbonseBody
  }

  //进行post表单请求，失败后重试一次
  def doPostForm(url: String, map: Map[String, String], logger: Logger) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = Utils.postForm(url, map, "utf-8")
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n${map.toString}")
        try {
          resbonseBody = Utils.postForm(url, map, "utf-8")
        } catch {
          case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n${map.toString}")
            resbonseBody = "发送post请求失败:" + e.toString
        }
    }

    resbonseBody
  }

  def df2Mysql(spark: SparkSession,rdd: RDD[Row],schema: StructType,user:String,password:String,
               saveMode:String,jdbcUrl:String,tblName:String,incDay: String, logger: Logger,statdate:String = "statdate"): Unit = {

    val delSql = String.format(s"delete from $tblName where %s='%s'",statdate,incDay)
    logger.error(">>>保存之前,删除当天的数据:" + delSql)
    Class.forName("com.mysql.jdbc.Driver");
    val conn = DriverManager.getConnection(jdbcUrl,user,password)
    DbUtils.executeSql(conn, delSql)
    //conn.close()

    //创建临时表
    val tmpTbl = spark.sqlContext.createDataFrame(rdd,schema).persist()

    //创建Properties存储数据库相关属性
    val prop = new Properties()
    prop.setProperty("user", user)
    prop.setProperty("password", password)

    logger.error(s"正在写入mysql：${tblName}")

    //将数据追加到数据库
    tmpTbl.write.mode(SaveMode.Append).jdbc(jdbcUrl,tblName, prop)

    DbUtils.querySql(conn,  String.format(s"select count(1) from $tblName where %s='%s'",statdate,incDay))
    conn.close()
    tmpTbl.unpersist()
  }


  def df2Hive(spark:SparkSession,rdd: RDD[Row],schema:StructType,saveMode:String,descTable:String,partitionSchm:String,incDay:String,logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd,schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${incDay}成功")
  }

  def df2HivePs(spark:SparkSession,rdd: RDD[Row],schema:StructType,saveMode:String,descTable:String,incDay:String,region:String,logger: Logger,partitionDay:String,partitionRegion:String): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd,schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($incDay='$partitionDay',$region='$partitionRegion')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(incDay,region).saveAsTable(descTable)

    logger.error(s"写入分区 $partitionDay,$partitionRegion 成功")
  }

  def df2Hive(spark:SparkSession, df:DataFrame,saveMode:String,descTable:String,partitionSchm:String,incDay:String,logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")

    //写入前删除分区数据
    val dropSql = s"alter table ${descTable} drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${partitionSchm}成功")
  }

  def getRowToJson( spark:SparkSession,querySql:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.DISK_ONLY)

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.DISK_ONLY)

    println(s"共获取数据:${sourRdd.count()}")

    sourDf.unpersist()

    sourRdd
  }

  def getRowToJsonTurp( spark:SparkSession,querySql:String,key:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.DISK_ONLY)

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      (jsonObj.getString(key),jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    sourRdd
  }

  //获取大区地区城市网点映射
  def getCityMap(logger:Logger)={
    val javaUtil = new JavaUtil()
    javaUtil.setFlag(6)

    val cityMap = CityInfoUtils.getCityMap(javaUtil).map(obj => {
      if (obj._2.length == 0) (obj._1,("","",""))
      else (obj._1,(obj._2(0)(4),obj._2(0)(0),obj._2(0)(1)))
    })

    logger.error(s">>>获取地址大区映射共：${cityMap.size}<<<")
    cityMap
  }

  //用于rds模块按不同维度统计指标
  def getOtherAggrRDD6D(doReduce:(JSONObject,JSONObject)=>JSONObject,indexArr:Array[String],logger:Logger,
                      aggrRDD: RDD[((String, String,String,String, String,String), JSONObject)],
                      statType:String,statTypeComent:String,tur: Seq[String],str:String,incDay:String) = {
    val otherAggrRDD = aggrRDD.map(obj => {
      val arr = Array("areaName", "regionName", "citycode", "cityName","deptcode","empCode")

      for (elem <- arr)
        if (StringUtils.isNotBlank(tur(arr.indexOf(elem))))
          obj._2.put(elem, tur(arr.indexOf(elem)))

      val statTypeComentRes = if (arr.contains(statTypeComent)) obj._2.getString(statTypeComent) else statTypeComent

      ((statType, statTypeComentRes, obj._2.getString("areaName"), obj._2.getString("regionName"), obj._2.getString("citycode"),
        obj._2.getString("cityName"), obj._2.getString("deptcode"),obj._2.getString("empCode"))
        , obj._2)
    }).reduceByKey( (obj1,obj2) => { doReduce(obj1,obj2) } )
      .map(obj => {
        val (statType,statTypeComentRes,areaName,regionName,citycode,cityName,deptcode,empCode) = obj._1
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance,Array(incDay,statType,statTypeComentRes,areaName,regionName,citycode,cityName,deptcode,empCode).mkString("_"))

        val row = Row(id, statType, statTypeComentRes, incDay, areaName, regionName, citycode, cityName, deptcode,empCode)
        var arr = scala.collection.mutable.ArrayBuffer[Double]()

        for (elem <- indexArr) {
          arr += obj._2.getDouble(elem)
        }

        Row.merge(row, Row.fromSeq(arr))
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"按${str}统计指标共:${otherAggrRDD.count()}")

    otherAggrRDD
  }



  /**
    * 限制spark分区中ak使用数量
    * @param stratTime
    * @param cnt
    * @param index
    * @param limitMin
    * @param logger
    */
  def limitAkUse( stratTime:StratTime,cnt:Cnt,index:Int,limitMin:Int,logger:Logger ) ={
    cnt.cnt += 1

    if ( cnt.cnt == limitMin  ) {
      val endTime = System.currentTimeMillis() - stratTime.stratTime

      if( endTime <= 60 * 1000 ){
        logger.error( s"分区$index,每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime } ms中" )
        Thread.sleep(60*1000 - endTime )
      }

      stratTime.stratTime = System.currentTimeMillis()
      cnt.cnt = 0
    }
  }




  //用于rds模块按不同维度统计指标
  def getOtherAggrRDD(doReduce:(JSONObject,JSONObject)=>JSONObject,indexArr:Array[String],logger:Logger,
                        aggrRDD: RDD[((String, String,String,String, String), JSONObject)],
                        statType:String,statTypeComent:String,tur: Seq[String],str:String,incDay:String) = {
    val otherAggrRDD = aggrRDD.map(obj => {
      val arr = Array("areaName", "regionName", "citycode", "cityName", "deptcode","empCode")

      for (elem <- arr)
        if (StringUtils.isNotBlank(tur(arr.indexOf(elem))))
          obj._2.put(elem, tur(arr.indexOf(elem)))

      val statTypeComentRes = if (arr.contains(statTypeComent)) obj._2.getString(statTypeComent) else statTypeComent

      ((statType, statTypeComentRes, obj._2.getString("areaName"), obj._2.getString("regionName"), obj._2.getString("citycode"),
        obj._2.getString("cityName"), obj._2.getString("deptcode")), obj._2)
    }).reduceByKey( (obj1,obj2) => { doReduce(obj1,obj2) } )
      .map(obj => {
        val (statType, statTypeComentRes, areaName, regionName, citycode, cityName, deptcode) = obj._1
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay, statType, statTypeComentRes, areaName, regionName, citycode, cityName, deptcode).mkString("_"))

        val row = Row(id, statType, statTypeComentRes, incDay, areaName, regionName, citycode, cityName, deptcode)
        var arr = scala.collection.mutable.ArrayBuffer[Int]()

        for (elem <- indexArr) {
          arr += obj._2.getInteger(elem)
        }

        Row.merge(row, Row.fromSeq(arr))
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"按${str}统计指标共:${otherAggrRDD.count()}")

    otherAggrRDD
  }


  //用于rds模块合并到网点维度所有指标
  def mergeIndex (doReduce:(JSONObject,JSONObject)=>JSONObject,indexArr:Array[String],logger:Logger
                  ,aggrRDD: RDD[((String, String,String,String, String), JSONObject)],incDay:String) = {
    //按天聚合指标
    val dayRdd = SparkUtils.getOtherAggrRDD(doReduce,indexArr,logger,aggrRDD,
      "ALL","ALL", Seq("ALL","ALL","ALL","ALL","ALL"),"天",incDay)

    //按地区聚合指标
    val areaRdd = SparkUtils.getOtherAggrRDD(doReduce,indexArr,logger,aggrRDD,
      "AREA","areaName",Seq("","ALL","ALL","ALL","ALL"),"地区",incDay)

    //按大区聚合指标
    val regionRdd = SparkUtils.getOtherAggrRDD(doReduce,indexArr,logger,aggrRDD,
      "REGION","regionName",Seq("","","ALL","ALL","ALL"),"大区",incDay)

    //按城市聚合指标
    val cityRdd = SparkUtils.getOtherAggrRDD(doReduce,indexArr,logger,aggrRDD,
      "CITY","cityName",Seq("","","","","ALL"),"城市",incDay)

    val allRdd = aggrRDD.map( obj => {
      val (areaName,regionName,citycode,cityName,deptcode) = obj._1
      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,"ZC",deptcode,areaName,regionName,citycode,cityName,deptcode).mkString("_"))

      val row = Row(id,"ZC",deptcode,incDay,areaName,regionName,citycode,cityName,deptcode)
      var arr = scala.collection.mutable.ArrayBuffer[Int]()

      for (elem <- indexArr) {
        arr += obj._2.getInteger(elem)
      }

      Row.merge(row,Row.fromSeq(arr))
    }).union(dayRdd).union(areaRdd).union(regionRdd).union(cityRdd)
      .persist(StorageLevel.DISK_ONLY)

    aggrRDD.unpersist()
    dayRdd.unpersist()
    areaRdd.unpersist()
    regionRdd.unpersist()
    cityRdd.unpersist()

    allRdd
  }

  //用于rds模块合并到小哥维度所有指标
  def mergeIndex6d (doReduce:(JSONObject,JSONObject)=>JSONObject,indexArr:Array[String],logger:Logger
                  ,aggrRDD:RDD[((String, String,String,String, String,String),JSONObject)],incDay:String) = {
    //按天聚合指标
    val dayRdd = SparkUtils.getOtherAggrRDD6D(doReduce,indexArr,logger,aggrRDD,
      "ALL","ALL", Seq("ALL","ALL","ALL","ALL","ALL","ALL"),"天",incDay)

    //按地区聚合指标
    val areaRdd = SparkUtils.getOtherAggrRDD6D(doReduce,indexArr,logger,aggrRDD,
      "AREA","areaName",Seq("","ALL","ALL","ALL","ALL","ALL"),"地区",incDay)

    //按大区聚合指标
    val regionRdd = SparkUtils.getOtherAggrRDD6D(doReduce,indexArr,logger,aggrRDD,
      "REGION","regionName",Seq("","","ALL","ALL","ALL","ALL"),"大区",incDay)

    //按城市聚合指标
    val cityRdd = SparkUtils.getOtherAggrRDD6D(doReduce,indexArr,logger,aggrRDD,
      "CITY","cityName",Seq("","","","","ALL","ALL"),"城市",incDay)

    //按网点聚合指标
    val zcRdd = SparkUtils.getOtherAggrRDD6D(doReduce,indexArr,logger,aggrRDD,
      "ZC","deptcode",Seq("","","","","","ALL"),"网点",incDay)

    val allRdd = aggrRDD.map( obj => {
      val (areaName,regionName,citycode,cityName,deptcode,empCode) = obj._1
      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,"EMP",empCode,areaName,regionName,citycode,cityName,deptcode,empCode).mkString("_"))

      val row = Row(id,"EMP",empCode,incDay,areaName,regionName,citycode,cityName,deptcode,empCode)
      var arr = scala.collection.mutable.ArrayBuffer[Double]()

      for (elem <- indexArr) {
        arr += obj._2.getDouble(elem)
      }

      Row.merge(row,Row.fromSeq(arr))
    }).union(dayRdd).union(areaRdd).union(regionRdd).union(cityRdd).union(zcRdd)
      .persist(StorageLevel.DISK_ONLY)

    aggrRDD.unpersist()
    dayRdd.unpersist()
    areaRdd.unpersist()
    regionRdd.unpersist()
    cityRdd.unpersist()

    allRdd
  }
}
