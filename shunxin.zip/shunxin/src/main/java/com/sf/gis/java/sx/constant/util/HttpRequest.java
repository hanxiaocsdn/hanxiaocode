package com.sf.gis.java.sx.constant.util;

/**
 * Created by 01366807 on 2017/5/10.
 */

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.zip.Deflater;
import java.util.zip.GZIPOutputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HttpRequest {

    //private static Logger logger  = Logger.getLogger(HttpRequest.class);

    public static int timeout = 5000;
    public static boolean keepAlive = false;

    public static String sendGetEncode(String url,String encode) throws Exception{
        return _sendGet(url,encode);
    }

    public static String sendGet(String url)throws Exception{
        return _sendGet(url,"utf8");
    }

    public static String _sendGet(String url,String encode) throws Exception{
        String rtn = "";
        HttpURLConnection connection=null;
        BufferedReader in = null;

        try {
            URL realUrl = new URL(url);

            // 打开和URL之间的连接
            connection = (HttpURLConnection)realUrl.openConnection();
            connection.setConnectTimeout(timeout);
            connection.setReadTimeout(timeout);

            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
            if(keepAlive){
                connection.setRequestProperty("connection", "Keep-Alive");
            }

            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");

            // 建立实际的连接
            connection.connect();

            // 定义 BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(connection.getInputStream(), encode));
            String line;
            while ((line = in.readLine()) != null) {
                rtn += line;
            }

        } catch (Exception e) {
            //System.err.println("Util.sendGet 调用失败: "+url);
            //System.err.println(e.getMessage()+"\t"+e.getCause());
            try {
                if (in != null) {
                    in.close();
                    in = null;
                }
            } catch (Exception e2) {
                //e2.printStackTrace();
            }

            try{
                if(connection!=null) {
                    connection.disconnect();
                    connection = null;
                }
            }catch (Exception ex){

            }

            throw e;
            //e.printStackTrace();
        }
        // 使用finally块来关闭输入流
        finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (Exception e2) {
                //e2.printStackTrace();
            }
            try{
                if(connection!=null) {
                    connection.disconnect();
                    connection = null;
                }
            }catch (Exception ex){

            }
        }
        return rtn;
    }

    /**
     * 向指定URL发送GET方法的请求
     *
     * @param url
     *            发送请求的URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return URL 所代表远程资源的响应结果
     */
    public static String sendGet(String url, String param) throws Exception {
        return sendGet(url + "?" + param);
    }

    /**
     * 向指定 URL 发送POST方法的请求
     *
     * @param url
     *            发送请求的 URL
     * @param param
     *            请求参数，请求参数应该是 name1=value1&name2=value2 的形式。
     * @return 所代表远程资源的响应结果
     */
    public static String sendPost(String url, String param) throws Exception {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // 打开和URL之间的连接
            URLConnection conn = realUrl.openConnection();
            // 设置通用的请求属性
            conn.setRequestProperty("accept", "*/*");
//            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            conn.setRequestProperty("Accept-Charset", "utf-8");
            conn.setRequestProperty("Content-Type", "application/json");

            // 发送POST请求必须设置如下两行
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setConnectTimeout(60 * 1000);
            conn.setReadTimeout(60 * 1000);
            // 获取URLConnection对象对应的输出流
            out = new PrintWriter(conn.getOutputStream());
            // 发送请求参数
            out.print(param);
            // flush输出流的缓冲
            out.flush();
            // 定义BufferedReader输入流来读取URL的响应
            in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            //System.err.println("\n"+e.getMessage()+"\n"+url);
            throw e;
        }
        // 使用finally块来关闭输出流、输入流
        finally {
            try {
                if (out != null) {
                    out.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                //System.err.println(ex.getMessage());
                throw ex;
            }
        }
        return result;
    }

    public static byte[] sendGetStream(String url) {
        try {
            URL realUrl = new URL(url);

            // 打开和URL之间的连接
            URLConnection connection = realUrl.openConnection();
            // 设置通用的请求属性
            connection.setRequestProperty("accept", "*/*");
//            connection.setRequestProperty("connection", "Keep-Alive");
            connection.setRequestProperty("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
            // 建立实际的连接
            connection.connect();

            InputStream input = connection.getInputStream();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            try {
                byte[] buffer = new byte[1024];
                int len = 0;
                while ((len = input.read(buffer)) != -1) {
                    output.write(buffer, 0, len);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return output.toByteArray();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    private static String t(String url, String params) {
        URL u = null;
        HttpURLConnection con = null;
        InputStream inputStream = null;
        BufferedOutputStream bos = null;
        BufferedReader bin = null;
        // 尝试发送请求
        try {
            u = new URL(url);
            con = (HttpURLConnection) u.openConnection();
            con.setRequestMethod("POST");
            // 发送POST请求必须设置如下两行
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setUseCaches(false);
            con.setRequestProperty("Content-Encoding", "deflate");
            con.setConnectTimeout(30000);
            con.setReadTimeout(30000);
            bos = new BufferedOutputStream(con.getOutputStream());
            bos.write(compressDef(new String(params.getBytes(), "UTF-8")));
            bos.flush();

            bin = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line;
            while ((line = bin.readLine()) != null) {
                // resultBuffer.append(line);
                System.out.println(line);
            }
            // bin.close();
            // OutputStream outStream = con.getOutputStream();
            // outStream.write(compressDef(new String(params.getBytes(),
            // "UTF-8")));
            // outStream.flush();
            // outStream.close();
            // PrintWriter out = null;
            // out = new PrintWriter(con.getOutputStream());
            // // 发送请求参数
            // out.print(compressDef(new String(params.getBytes(), "UTF-8")));
            // // flush输出流的缓冲
            // out.flush();
            // out.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != bos) {
                    bos.close();
                }
                if (null != bin) {
                    bin.close();
                }
                if (null != con) {
                    con.disconnect();
                }
            } catch (IOException e) {

                e.printStackTrace();
            }
        }

        return "";
    }

    public static String sendPostByDef(String url, String param) {
        // if(!url.isEmpty()){
        // return t(url,param);
        // }
        HttpPost postMethod = new HttpPost(url);
        // postMethod.setContentChunked(true);
        // postMethod.addRequestHeader("Accept", "text/plain");
        // postMethod.setRequestHeader("Content-Encoding", "gzip");
        // postMethod.setRequestHeader("Transfer-Encoding", "chunked");
        // postMethod.setHeader("Content-Type", "application/json");
        // postMethod.setHeader("Content-Type", "text/plain");
        postMethod.setHeader("Content-Encoding", "deflate");
        // postMethod.setHeader("Connection", "Close");
        // postMethod.setHeader("Connection", "Keep-Alive");
        // postMethod.setHeader("Transfer-Encoding", "chunked");
        // postMethod.setch

        String strContent = "";
        try {

            // String str = URLEncoder.encode(param,"UTF-8");

            postMethod.setEntity(new ByteArrayEntity(compressDef(new String(param.getBytes(), "UTF-8"))));

            // {{
            // UrlEncodedFormEntity uefEntity;
            // List<NameValuePair> paramList = new ArrayList<NameValuePair>();
            // String args = param.substring(39);
            // paramList.add(new BasicNameValuePair("requestArgs", args));
            // uefEntity = new UrlEncodedFormEntity(paramList,"UTF-8");
            // postMethod.setEntity(uefEntity);
            // }}

            long s = System.currentTimeMillis();
            // HttpClientBuilder.create().build();
//            System.setProperty("http.keepAlive", "true");
            // HttpClient httpClient = new DefaultHttpClient();
            HttpClientBuilder hb = HttpClientBuilder.create();

            PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
            hb.setConnectionManager(connManager);
            CloseableHttpClient httpClient = hb.build();//

            HttpResponse httpresponse = httpClient.execute(postMethod);

            HttpEntity entity = httpresponse.getEntity();
            strContent = EntityUtils.toString(entity);
            EntityUtils.consume(entity);
            // httpClient.getConnectionManager().shutdown();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return strContent;
    }

    public static String sendPostByGzip(String url, String param) {
        HttpPost postMethod = new HttpPost(url);
        // postMethod.setContentChunked(true);
        // postMethod.addRequestHeader("Accept", "text/plain");
        // postMethod.setRequestHeader("Content-Encoding", "gzip");
        // postMethod.setRequestHeader("Transfer-Encoding", "chunked");
        // postMethod.setHeader("Content-Type", "application/json");
        // postMethod.setHeader("Content-Type", "text/plain");
        postMethod.setHeader("Content-Encoding", "gzip");
        // postMethod.setHeader("Transfer-Encoding", "chunked");
        // postMethod.setch

        String strContent = "";
        try {
            ByteArrayOutputStream originalContent = new ByteArrayOutputStream();
            originalContent.write(param.getBytes(Charset.forName("UTF-8")));

            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            GZIPOutputStream gzipOut = new GZIPOutputStream(baos);
            originalContent.writeTo(gzipOut);
            gzipOut.finish();

            // postMethod.setRequestEntity(new ByteArrayRequestEntity(baos
            // .toByteArray(), "text/plain; charset=utf-8"));

            postMethod.setEntity(new ByteArrayEntity(baos.toByteArray()));

            baos.close();

            HttpClient httpClient = new DefaultHttpClient();
            HttpResponse httpresponse = httpClient.execute(postMethod);

            HttpEntity entity = httpresponse.getEntity();
            strContent = EntityUtils.toString(entity);

        } catch (Exception e) {

            e.printStackTrace();
        }

        return strContent;
    }

    public static byte[] compressDef(String strContent) throws IOException {

        byte[] out = null;
        ByteArrayOutputStream bos = null;

        if (null == strContent || strContent.isEmpty()) {
            return out;
        }

        try {
            int len = 0;
            byte[] outputByte = new byte[1024];
            Deflater defl = new Deflater();
            defl.setLevel(1);
            defl.setInput(strContent.getBytes("UTF-8"));
            defl.finish();

            bos = new ByteArrayOutputStream();
            while (!defl.finished()) {
                len = defl.deflate(outputByte);
                bos.write(outputByte, 0, len);
            }
            defl.end();

            out = bos.toByteArray();
        } catch (Exception e) {

        } finally {
            if (null != bos) {
                bos.close();
            }
        }

        return out;
    }

    public static void main(String[] args) {
//        String url = "http://m5.amap.com/ws/mapapi/navigation/auto/?ent=2&csid=clsid&sloc_precision=0.0&div=ANDH070602&diu=225080027624477&spm=1074113665042530270173&v_type=0&end_poiid=&dip=10880&carplate=&stepid=71&policy2=1&tid=&invoker=plan&BID_F=&start_poiid=&end_typecode=991400&dic=C3060&appstartid=162660359&usepoiquery=false&dib=a&client_network_class=4&sloc_speed=0&contentoptions=65536&dibv=1030&v_load=0.0&v_height=2.5&sdk_version=3.6.3.1.1.20160129.20551.1374&route_version=2.5.3&sign=C317190B6A300E1BC8439C647A8D7F4D&start_types=2&end_types=2&fromX=114.39546&fromY=30.458589&toX=114.398456&toY=30.451439&session=162660359&off=0&start_typecode=190302&diu3=341b0a990c5946338d3f74b9bbe1c929-cb69ece397c5e4846e991a83353f9143&diu2=881193d8fff7ffffffe8&output=bin&channel=amap7a&threeD=1";
//        byte[] pRtn = sendGetStream(url);
//        System.out.println("pRtn.length=" + pRtn == null ? 0 : pRtn.length);



        String url = "http://10.202.15.115:7178/rectifytracks";
        String para = "{"+
                "	\"branch\":\"755AQ\","+
                "	\"vehicle\":0,"+
                "	\"tracks\":["+
        "        {"+
                "		  	\"type\":1,"+
                "			\"x\":113.87609,"+
                "			\"y\":22.576584,"+
                "			\"accuracy\":8,"+
                "			\"speed\":4.56,"+
                "			\"azimuth\":120.5,"+
                "			\"time\": 1494210995"+
                "        },"+
                "        {"+
                "		  	\"type\":1,"+
                "			\"x\":113.89609,"+
                "			\"y\":22.596584,"+
                "			\"accuracy\":8,"+
                "			\"speed\":4.56,"+
                "			\"azimuth\":120.5,"+
                "			\"time\": 1494210997"+
                "        }";
        for(int i=0;i<1;i++){
            para+="        ,{"+
                    "		  	\"type\":1,"+
                    "			\"x\":113.87609,"+
                    "			\"y\":22.576584,"+
                    "			\"accuracy\":8,"+
                    "			\"speed\":4.56,"+
                    "			\"azimuth\":120.5,"+
                    "			\"time\": 1494210995"+
                    "        },"+
                    "        {"+
                    "		  	\"type\":1,"+
                    "			\"x\":113.89609,"+
                    "			\"y\":22.596584,"+
                    "			\"accuracy\":8,"+
                    "			\"speed\":4.56,"+
                    "			\"azimuth\":120.5,"+
                    "			\"time\": 1494210997"+
                    "        }";
        }
                para +=
                "	]"+
                "}";
        String result = null;
        for(int i=0;i<1;i++){
            try {
                //para = "{\"branch\":null,\"vehicle\":1,\"tracks\":[{\"type\":1,\"x\":121.319909,\"y\":31.283395,\"accuracy\":12,\"speed\":1.7,\"azimuth\":219.8,\"time\":1493265601}]}";
                result = sendPost(url,para.replaceAll(" ",""));
                System.err.println(result);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}