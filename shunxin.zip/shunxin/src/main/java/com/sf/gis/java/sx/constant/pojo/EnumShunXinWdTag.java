package com.sf.gis.java.sx.constant.pojo;

/**
 * Created by 01374443 on 2021/3/18.
 */
public enum  EnumShunXinWdTag {
    gisEmpty, //gis网点为空
    same, //网点正确
    drop, //弃件
    destAddressModify, //寄件地址修改
    signNotLocalCity, //签收城市不在本城市
    allDeptSame,  //坐标跑出的网点相同,签收错误
    allAoiSame,//坐标跑出的aoi相同
    addressUnknown,//地址为空
    addressNoCity,// 地址无城市
    addressUnkonwnWd,//错分地址不祥
    addressNumber,//地址为数字
    townInvalid,//town非法
    specialEwb,//特殊件
    specialZc,//特殊网点
    gisZcGuanTing,//关停
    dispatchAddrChange,//寄件地址更改
    signNotAddrCity,//签收非本市
    signCityNotEqOpCity,//签收城市非人工输入城市
    signTownNotEqOpCity,//签收乡镇非人工输入乡镇
    sxDeptNotExist,//顺心网点不存在
    splitLevelLess,//切词词级不行
    sxDeptIntefaceStop, //顺心网点接口停止
    sxDeptNotCover,// 顺心网点未覆盖
    gisempty_1

}
