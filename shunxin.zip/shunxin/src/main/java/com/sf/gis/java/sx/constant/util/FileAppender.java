package com.sf.gis.java.sx.constant.util;

import java.io.*;

public class FileAppender {
    FileWriter fw = null;
    PrintWriter pw = null;
    int batchSize = 100;
    public FileAppender(String path, Boolean overwrite, int batchSize) throws Exception{
        if(batchSize>0)
            this.batchSize = batchSize;
        if(overwrite){
            File f = new File(path);
            if(f.exists())
                f.delete();
        }
        FileUtil.save(path,"");
        int trys = 0;
        while(fw == null){
            try {
                File f = new File(path);
                fw = new FileWriter(f, true);
            } catch (IOException e) {
                e.printStackTrace();
                try{
                    trys++;
                    Thread.currentThread().sleep(1000);
                    System.err.println("fw is null, retry: "+trys);
                }catch(Exception ex){
                }
            }
        }

        pw = new PrintWriter(fw);

    }

    private long c = 0l;
    public void append(String txt){
        c+=1;
        pw.print(txt);

        if(c % batchSize == 0)
            pw.flush();
    }

    public void close(){
        try {
            pw.flush();
            fw.flush();
            pw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void copyFrom(String fileName,boolean skipEmptyLine){
        File file = new File(fileName);
        if(!file.exists()) return ;
        BufferedReader reader = null;
        try {
            //System.out.println("以行为单位读取文件内容，一次读一整行：");
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                tempString = tempString.replaceAll("\r\n","").replaceAll("\r","").replaceAll("\n","").trim();
                if(skipEmptyLine && tempString.length()==0){
                    continue;
                }
                append(tempString+"\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
            }
        }
    }
}
