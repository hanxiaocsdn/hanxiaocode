package com.sf.gis.java.sx.constant.util;


import org.apache.commons.httpclient.HttpStatus;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.lf5.util.StreamUtils;

import java.io.*;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;

import org.apache.http.message.BasicNameValuePair;

import java.util.Map.Entry;

public class HttpConnection {
    private static Logger logger = Logger.getLogger(HttpConnection.class);
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;

    private static void initConnectionManager() {
        synchronized (HttpConnection.class){
            //noinspection SingleStatementInBlock
            if(!isInitConnection){
                try {
                    connManager.setMaxTotal(500); // 设置整个连接池最大连接数 根据自己的场景决定
                    // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
                    connManager.setDefaultMaxPerRoute(500);// （目前只有一个路由，因此让他等于最大值）
                    SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(10000).setTcpNoDelay(true).build();
                    connManager.setDefaultSocketConfig(socketConfig);

                    RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(3000).setConnectTimeout(3000).setSocketTimeout(3000).build();
                    httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
                } catch (Exception e) {
                    logger.error("initConnectionManager error. ", e);
                }
            }
        }
    }

    public static Map<String, String> sendGet(String url) {
        Map<String, String> re = new HashMap<>();
        String content;

        HttpGet get = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            get = new HttpGet(url);
            response = httpClient.execute(get);
            entity = response.getEntity();
            content = EntityUtils.toString(entity, "utf-8");
            re.put("code", "1");
            re.put("content", content);
        } catch (ConnectTimeoutException | SocketTimeoutException e) {
            re.put("code", "2");
            logger.info("GET请求超时！", e);
        } catch (Exception e) {
            re.put("code", "3");
            logger.info("发送GET请求出现异常！", e);
        } finally {  	// 使用finally块来关闭输入流
            try {
                if (get != null) {
                    EntityUtils.consume(entity);
                    get.releaseConnection();
                }
                if (response != null) {
                    response.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return re;
    }

    public static Map<String, Object> sendPost(String url, String param) {
        String content;
        Map<String, Object> re = new HashMap<>();
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");
            HttpEntity result = new StringEntity(param, "UTF-8");
            post.setEntity(result);

            response = httpClient.execute(post);
            entity = response.getEntity();
            content = EntityUtils.toString(entity, "utf-8");
            re.put("code", "1");
            re.put("content", content);
        } catch (ConnectTimeoutException | SocketTimeoutException e) {
            re.put("code", "2");
            logger.info("GET请求超时！", e);
        } catch (Exception e) {
            re.put("code", "3");
            logger.info("发送GET请求出现异常！", e);
        } finally {
            try {
                if (post != null) {
                    EntityUtils.consume(entity);
                    post.releaseConnection();
                }
                if (response != null) {
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return re;
    }
    public static String downloadFile(String url, String dest_file,String fileName) throws Throwable {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpGet httpget = new HttpGet(url);
            httpget.setConfig(RequestConfig.custom() //
                    .setConnectionRequestTimeout(3*1000) //
                    .setConnectTimeout(3*1000) //
                    .setSocketTimeout(10*1000) //
                    .build());
            try (CloseableHttpResponse response = httpclient.execute(httpget)) {
                HttpEntity entity = response.getEntity();
                File desc = new File(dest_file+File.separator+fileName);
                File folder = desc.getParentFile();
                folder.mkdirs();
                try (InputStream is = entity.getContent(); //
                     OutputStream os = new FileOutputStream(desc)) {
                    StreamUtils.copy(is, os);
                }
            }catch(Throwable e){
                throw new Throwable("文件下载失败......", e);
            }
        }
        return dest_file+File.separator+fileName;
    }
    public static String httpPost(int tryCount, String url, String json) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setEntity(new StringEntity(json, Charset.forName("UTF-8")));
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    // LogUtil.e(result);
                    return result;
                }
            } catch (Exception e) {
                logger.error(e);
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }
    public static String httpPost(int tryCount, String url, Map<String, String> parameters) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/x-www-form-urlencoded; charset=utf-8");
            httpPost.setHeader("Accept", "application/xhtml+xml");
            List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            for (Entry<String, String> entry : parameters.entrySet()) {
                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            httpPost.setEntity(new UrlEncodedFormEntity(nvps, Charset.forName("UTF-8")));
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    // LogUtil.e(result);
                    return result;
                }
            } catch (Exception e) {
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }
}

