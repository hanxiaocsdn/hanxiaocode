package com.sf.gis.scala.lss.lineUpdate

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.row2Json
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.{AddResult, UpdateResult}
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.sf.gis.scala.lss.utils.StringUtils.stdCoordsToPoints
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：823728
 * 任务名称：更新入库返回结果
 */
object EtaLineUpdateResult {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  val updateLineFiledUrl = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/operate/updateLineFiled"
  val updateLineFiledAk = "5e86b3e45f664ecea1d59e6c591aa006"
  val addLineUrl = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/addLine"
  val addLineAk = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 4000

  // 解析 标准线路更新返回值
  def parseUpdateLineHttpData1(ret: JSONObject): JSONObject = {
    val obj = new JSONObject()
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        var err = ""
        var msg = ""
        try{
          err = ret.getJSONObject("result").getString("err")
          msg = ret.getJSONObject("result").getString("msg")
        }catch {
          case e: Exception => logger.error(e)
        }
        obj.put("repair_status",codeStatue)
        obj.put("repair_err",err)
        obj.put("repair_msg",msg)
        logger.error("获取接口数据失败: " + msg)

        return obj
      } else {
        var code = ""
        var info = ""
        var stdId = ""
        try{
          code = ret.getJSONObject("result").getString("code")
          info = ret.getJSONObject("result").getString("info")
          stdId = ret.getJSONObject("result").getString("stdId")
        }catch {
          case e: Exception => logger.error(e)
        }
        obj.put("repair_status",codeStatue)
        obj.put("repair_code",code)
        obj.put("repair_info",info)
        obj.put("repair_stdid",stdId)

        return obj
      }
    }
    obj
  }

  // 调用标准线路线路更新接口（新增）
  def runUpdateInteface2(ak:String, obj: JSONObject): JSONObject = {
    // 获取参数字段
    val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
    val reason = JSONUtil.getJsonVal(obj,"reason","")
    val t_coords = JSONUtil.getJsonVal(obj,"t_coords","")
    val t_distance = JSONUtil.getJsonDouble(obj,"t_distance",0.0).toInt
    val t_duration = JSONUtil.getJsonDouble(obj,"t_duration",0.0).toInt
    val dist = JSONUtil.getJsonDouble(obj,"dist",0.0).toInt
    val line_time = JSONUtil.getJsonDouble(obj,"time",0.0).toInt
    val label = JSONUtil.getJsonVal(obj,"label","")
    val score_rank = JSONUtil.getJsonDouble(obj,"score_rank",-1.0).toInt
    val t_highspeed_distance = JSONUtil.getJsonDouble(obj, "t_highspeed_distance", 0.0).toInt
    val t_toll_distance = JSONUtil.getJsonDouble(obj, "t_toll_distance", 0.0).toInt
    val roadfee = JSONUtil.getJsonDouble(obj,"roadfee",0.0).toInt
    val oil_fee = JSONUtil.getJsonDouble(obj,"oil_fee",0.0)
    val src_dist = JSONUtil.getJsonVal(obj, "src_dist", "")
    val dest_dist = JSONUtil.getJsonVal(obj, "dest_dist", "")
    val freq = JSONUtil.getJsonVal(obj, "freq", "")
    val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")

    val arr = linevehicle.split("_")
    val lineCode = arr(0)
    val srcDeptcode = arr(1)
    val destDeptcode = arr(2)
    val vehicle = arr(3)
    val jyTrack2 = stdCoordsToPoints(t_coords)
    val time = (t_duration + ((t_duration / 14400) * 1200)).toString

    // 评分字段汇总
    val factorScore = new JSONObject()
    factorScore.put("里程",t_distance)
    factorScore.put("时间",time)
    factorScore.put("路桥费",roadfee)
    factorScore.put("油耗费",oil_fee)
    factorScore.put("起点距离",src_dist)
    factorScore.put("终点距离",dest_dist)
    factorScore.put("执行次数",freq)

    val param = new JSONObject()
    param.put("ak", ak)
    param.put("optUserId", "80006476")
    param.put("addReason", reason)
    param.put("srcDeptcode", srcDeptcode)
    param.put("destDeptcode", destDeptcode)
    param.put("lineCode", lineCode)
    param.put("planTime", plan_time)
    param.put("vehicle", vehicle)
    param.put("isEcon", 7)
    param.put("jyTrack2", jyTrack2)
    param.put("rtDistance", t_distance)
    param.put("rtTime", t_duration)
    param.put("lineDistance", dist)
    param.put("lineTime", line_time)
    param.put("label", label)
    param.put("factorOrder", score_rank)
    param.put("factorScore", factorScore)
    param.put("highway", t_highspeed_distance)
    param.put("tolls", roadfee)
    param.put("tollsDistance", t_toll_distance)
    param.put("oilConsumption", oil_fee)


    var suc = 0
    var routeInde = 1901
    var info = ""
    var retJSONObject_2 = new JSONObject()
    while(suc < 500){   // 循环调用接口，更新成功或者不再报错“插入失败，数据库已存在该线路，请先删除”，或者循环次数大于100次时退出
      param.put("routeIndex", routeInde)

      try {
        val retStr: String = HttpInvokeUtil.sendPost(addLineUrl,param.toJSONString,3)
        retJSONObject_2 = JSON.parseObject(retStr)
        val result = JSONUtil.getJSONObject(retJSONObject_2, "result")
        info = JSONUtil.getJsonVal(result, "info", "")
      } catch {
        case e: Exception => logger.error(e)
      }

      if(info.equals("插入失败，数据库已存在该线路，请先删除")){
        suc += 1
        routeInde += 1
      }else{
        suc = 1000 // 退出循环
      }

    }

    //解析线路更新接口返回值
    val httpData_2: JSONObject = parseUpdateLineHttpData1(retJSONObject_2)
    val repair_status = JSONUtil.getJsonVal(httpData_2,"repair_status","")
    val repair_code = JSONUtil.getJsonVal(httpData_2,"repair_code","")
    val repair_info = JSONUtil.getJsonVal(httpData_2,"repair_info","")
    val repair_err = JSONUtil.getJsonVal(httpData_2,"repair_err","")
    val repair_msg = JSONUtil.getJsonVal(httpData_2,"repair_msg","")
    val repair_stdid = JSONUtil.getJsonVal(httpData_2,"repair_stdid","")

    // 线路更新接口新增字段
    obj.put("repair_status",repair_status)
    obj.put("repair_code",repair_code)
    obj.put("repair_info",repair_info)
    obj.put("repair_err",repair_err)
    obj.put("repair_msg",repair_msg)
    obj.put("repair_stdid",repair_stdid)

    obj
  }

  // 调用标准线路线路更新接口
  def runUpdateInteface1(ak:String, obj: JSONObject): JSONObject = {
    // 获取参数字段
    val std_id = JSONUtil.getJsonVal(obj,"std_id","")
    val t_distance = JSONUtil.getJsonDouble(obj,"t_distance",0.0)
    val t_duration = JSONUtil.getJsonDouble(obj,"t_duration",0.0)
    val roadfee = JSONUtil.getJsonDouble(obj,"roadfee",0.0)
    val oil_fee = JSONUtil.getJsonDouble(obj,"oil_fee",0.0)
    val start_dist = JSONUtil.getJsonDouble(obj,"start_dist",0.0)
    val end_dist = JSONUtil.getJsonDouble(obj,"end_dist",0.0)
    val freq = JSONUtil.getJsonDouble(obj,"freq",0.0)
    val label = JSONUtil.getJsonVal(obj,"label","")
    val score_rank = JSONUtil.getJsonDouble(obj,"score_rank",-1.0).toInt
    val new_rank1 = JSONUtil.getJsonDouble(obj,"new_rank1",-1111.0).toInt
    val reason = JSONUtil.getJsonVal(obj,"reason","")
    val param_type = JSONUtil.getJsonVal(obj,"param_type","")

    // 第一次调更新接口用score_rank，第二次调更新接口用字段new_rank1
    var factorOrder = -1
    if(new_rank1 == -1111){
      factorOrder = score_rank
    }else{
      factorOrder = new_rank1
    }

    val param = new JSONObject()
    param.put("optUserId", "80006476")
    param.put("stdId", std_id)
    param.put("ak", ak)
    param.put("updateReason", reason)
    param.put("factorOrder",factorOrder)

    if(param_type.equals("异常更新")){  // 如果为异常更新，则新增两个入参
      // 评分字段汇总
      val factorScore = new JSONObject()
      factorScore.put("里程",t_distance)
      factorScore.put("时间",t_duration)
      factorScore.put("路桥费",roadfee)
      factorScore.put("油耗费",oil_fee)
      factorScore.put("起点距离",start_dist)
      factorScore.put("终点距离",end_dist)
      factorScore.put("执行次数",freq)

      param.put("label",label)
      param.put("factorScore",factorScore)
    }

    var retJSONObject_2 = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(updateLineFiledUrl,param.toJSONString,3)
      retJSONObject_2 = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析线路更新接口返回值
    val httpData_2: JSONObject = parseUpdateLineHttpData1(retJSONObject_2)
    val repair_status = JSONUtil.getJsonVal(httpData_2,"repair_status","")
    val repair_code = JSONUtil.getJsonVal(httpData_2,"repair_code","")
    val repair_info = JSONUtil.getJsonVal(httpData_2,"repair_info","")
    val repair_err = JSONUtil.getJsonVal(httpData_2,"repair_err","")
    val repair_msg = JSONUtil.getJsonVal(httpData_2,"repair_msg","")
    val repair_stdid = JSONUtil.getJsonVal(httpData_2,"repair_stdid","")

    // 线路更新接口新增字段
    obj.put("repair_status",repair_status)
    obj.put("repair_code",repair_code)
    obj.put("repair_info",repair_info)
    obj.put("repair_err",repair_err)
    obj.put("repair_msg",repair_msg)
    obj.put("repair_stdid",repair_stdid)

    obj
  }

  // 固定线路新增入库
  def runAddLineInteface(spark: SparkSession, dayBefore1: String) = {

    import spark.implicits._
    // 固定线路新增入库数据 表89
    val add_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  line_id,
         |  t_distance,
         |  t_duration,
         |  roadfee,
         |  t_coords,
         |  time,
         |  dist,
         |  line_optimal_type as label,
         |  score_rank,
         |  t_toll_distance,
         |  oil_fee,
         |  '' as src_dist,
         |  '' as dest_dist,
         |  freq,
         |  t_highspeed_distance
         |from
         |  dm_gis.eta_line_add_change_detail
         |where
         |  inc_day = '$dayBefore1'
         |  and line_type = '固定线路'
         |""".stripMargin
    println("固定线路新增入库数据取数sql：")
    println(add_sql)

    val df_add = spark.sql(add_sql)
      .withColumn("reason",concat_ws("_",'task_area_code,lit("区固定线路入库"),lit(dayBefore1)))
      .withColumn("plan_time",substring(split('linevehicle,"_")(0),-4,4)) // 截取后四位
      .withColumn("inc_day",lit(dayBefore1))

//    // 待更新数据(验数使用的临时表)
//    val cols_12 = spark.sql("""select * from dm_gis.eta_line_need_add limit 0""").schema.map(_.name).map(col)
//    writeToHive(spark, df_add.coalesce(50).select(cols_12: _*), Seq("inc_day"), "dm_gis.eta_line_need_add")

    val invokeCnt = df_add.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "823728", "更新入库返回结果", "标准线路更新入库返回结果", addLineUrl, addLineAk, invokeCnt, parallelism)
    // 调线路新增接口
    val rdd_add = SparkNet.runInterfaceWithAkLimit(spark, df_add.rdd.map(row2Json), runUpdateInteface2, parallelism, addLineAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "  invokeCnt = " + invokeCnt)

    val df_add_result = rdd_add.map(obj=>{
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val line_id = JSONUtil.getJsonVal(obj, "line_id", "")
      val reason = JSONUtil.getJsonVal(obj,"reason","")
      val t_coords = JSONUtil.getJsonVal(obj,"t_coords","")
      val t_distance = JSONUtil.getJsonVal(obj,"t_distance","")
      val t_duration = JSONUtil.getJsonVal(obj,"t_duration","")
      val dist = JSONUtil.getJsonVal(obj,"dist","")
      val line_time = JSONUtil.getJsonVal(obj,"time","")
      val label = JSONUtil.getJsonVal(obj,"label","")
      val score_rank = JSONUtil.getJsonVal(obj,"score_rank","")
      val t_highspeed_distance = JSONUtil.getJsonVal(obj, "t_highspeed_distance", "")
      val t_toll_distance = JSONUtil.getJsonVal(obj, "t_toll_distance", "")
      val roadfee = JSONUtil.getJsonVal(obj,"roadfee","")
      val oil_fee = JSONUtil.getJsonVal(obj,"oil_fee","")
      val src_dist = JSONUtil.getJsonVal(obj, "src_dist", "")
      val dest_dist = JSONUtil.getJsonVal(obj, "dest_dist", "")
      val freq = JSONUtil.getJsonVal(obj, "freq", "")
      val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")

      // 接口返回值
      val repair_status = JSONUtil.getJsonVal(obj,"repair_status","")
      val repair_code = JSONUtil.getJsonVal(obj,"repair_code","")
      val repair_info = JSONUtil.getJsonVal(obj,"repair_info","")
      val repair_err = JSONUtil.getJsonVal(obj,"repair_err","")
      val repair_msg = JSONUtil.getJsonVal(obj,"repair_msg","")
      val repair_stdid = JSONUtil.getJsonVal(obj,"repair_stdid","")

      AddResult(linevehicle,task_area_code,line_id,reason,t_coords,t_distance,t_duration,dist,line_time,label,score_rank,t_highspeed_distance,t_toll_distance,roadfee,
        oil_fee,src_dist,dest_dist,freq,plan_time,repair_status,repair_code,repair_info,repair_err,repair_msg,repair_stdid)
    }).toDF()
      .withColumn("inc_day",lit(dayBefore1))

    // 更新结果
    val cols_13 = spark.sql("""select * from dm_gis.eta_line_add_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_add_result.coalesce(50).select(cols_13: _*), Seq("inc_day"), "dm_gis.eta_line_add_result")

  }

  // 标准线路打标
  def runUpdateLineFiledInteface(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    // 需清除排序的标准线路
    val delete_rank_sql =
      s"""
         |select
         |  line_id as std_id,
         |  task_area_code,
         |  linevehicle,
         |  '' as t_distance,
         |  '' as t_duration,
         |  '' as roadfee,
         |  '' as oil_fee,
         |  '' as start_dist,
         |  '' as end_dist,
         |  '' as freq,
         |  '' as label,
         |  -1 as score_rank,
         |  line_type_list,
         |  line_type,
         |  time,
         |  num
         |from
         |  dm_gis.eta_line_group_label2
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("需清除排序的标准线路取数sql：")
    println(delete_rank_sql)

    // 需清除排序数据
    val df_update_1 = spark.sql(delete_rank_sql)
      .withColumn("line_type_tag",when('line_type_list.contains("标准线路") and 'line_type_list.contains("固定线路"),1).otherwise(0))
      .filter('line_type === "标准线路" and 'num =!= "1")
      .withColumn("rn", row_number().over(Window.partitionBy('std_id).orderBy(desc("time"))))
      .filter('rn === 1) // 按 std_id 去重
      .withColumn("reason",concat_ws("_",'task_area_code,lit("相似标准线路置空打标"),lit(dayBefore1)))
      .withColumn("param_type",lit("排序置空"))
      .select("linevehicle","std_id","task_area_code","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","score_rank","reason","param_type")

    // 表3 距离异常数据
    val distance_sql =
      s"""
         |select
         |  stdid as std_id,
         |  linevehicle,
         |  task_area_code,
         |  '' as t_distance,
         |  '' as t_duration,
         |  '' as roadfee,
         |  '' as oil_fee,
         |  start_dist,
         |  end_dist,
         |  '' as freq,
         |  '距离异常' as label,
         |  inc_day
         |from
         |  dm_gis.eta_line_distance_abnormal
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("距离异常表取数sql：")
    println(distance_sql)
    val df_distance = spark.sql(distance_sql)
      .select("std_id","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","task_area_code","linevehicle")

    // 表4 5 6 收费异常,匹配中断,准点率差 数据
    val roadfee_sql =
      s"""
         |select
         |  line_id as std_id,
         |  task_area_code,
         |  linevehicle,
         |  t_distance,
         |  t_duration,
         |  roadfee,
         |  oil_fee,
         |  '' as start_dist,
         |  '' as end_dist,
         |  freq,
         |  error_type as label,
         |  inc_day
         |from
         |  dm_gis.eta_line_roadfee_break_ontime_abnormal
         |where
         |  inc_day = '$dayBefore1'
         |  and line_type = '标准线路'
         |  and error_type in ('收费异常','匹配中断','准点率差')
         |""".stripMargin
    println("收费、中断、准点率差异常表取数sql：")
    println(roadfee_sql)

    val df_roadfee = spark.sql(roadfee_sql)
      .select("std_id","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","task_area_code","linevehicle")

    // 表9 标准线路需打标更新数据
    val change_sql =
      s"""
         |select
         |  line_id as std_id,
         |  task_area_code,
         |  linevehicle,
         |  t_distance,
         |  t_duration,
         |  roadfee,
         |  oil_fee,
         |  score_rank,
         |  score_rank_max,
         |  '' as start_dist,
         |  '' as end_dist,
         |  freq,
         |  line_optimal_type as label,
         |  inc_day
         |from
         |  dm_gis.eta_line_add_change_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("结果表89表取数sql：")
    println(change_sql)
    val df_change = spark.sql(change_sql)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val df_rank_max = df_change
      .groupBy("linevehicle")
      .agg(max('score_rank_max) as "score_rank_max")

    // 异常数据重新排序
    val df_update_2 = df_distance
      .union(df_roadfee)
      .withColumn("label_num",when('label === "收费异常",9)
        .when('label === "匹配中断",8)
        .when('label === "距离异常",7)
        .when('label === "准点率差",6)
        .otherwise(1))
      .withColumn("order_tag",concat_ws("",'label_num,'std_id))
      .withColumn("score_rank_1", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("order_tag"))))
      .join(df_rank_max,Seq("linevehicle"),"left")
      .withColumn("score_rank_max",when('score_rank_max.isNull,0).otherwise('score_rank_max))
      .withColumn("score_rank",('score_rank_1 + 'score_rank_max).cast("int"))
      .select("std_id","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","score_rank","task_area_code","linevehicle")

    // 异常更新数据和标准线路打标数据合并
    val df_update_3 = df_change
      .filter('line_type === "标准线路")
      .select("std_id","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","score_rank","task_area_code","linevehicle")
      .union(df_update_2)
      .withColumn("reason",concat_ws("_",'task_area_code,lit("区标准线路打标"),lit(dayBefore1)))
      .withColumn("param_type",lit("异常更新"))
      .select("linevehicle","std_id","task_area_code","t_distance","t_duration","roadfee","oil_fee","start_dist","end_dist","freq","label","score_rank","reason","param_type")

    // 清除排序数据合并
    val df_update = df_update_1.union(df_update_3)
      .withColumn("plan_time",substring(split('linevehicle,"_")(0),-4,4)) // 截取后四位
      .withColumn("inc_day",lit(dayBefore1))

//    // 待更新数据(验数使用的临时表)
//    val cols_14 = spark.sql("""select * from dm_gis.eta_line_need_update limit 0""").schema.map(_.name).map(col)
//    writeToHive(spark, df_update.coalesce(50).select(cols_14: _*), Seq("inc_day"), "dm_gis.eta_line_need_update")

    val invokeCnt = df_update.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "823728", "更新入库返回结果", "标准线路更新入库返回结果", updateLineFiledUrl, updateLineFiledAk, invokeCnt, parallelism)
    // 调线路更新接口
    val rdd_update = SparkNet.runInterfaceWithAkLimit(spark, df_update.rdd.map(row2Json), runUpdateInteface1, parallelism, updateLineFiledAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "  invokeCnt = " + invokeCnt)

    val df_update_result = rdd_update.map(obj=>{
      val linevehicle = JSONUtil.getJsonVal(obj,"linevehicle","")
      val task_area_code = JSONUtil.getJsonVal(obj,"task_area_code","")
      val std_id = JSONUtil.getJsonVal(obj,"std_id","")
      val plan_time = JSONUtil.getJsonVal(obj,"plan_time","")
      val t_distance = JSONUtil.getJsonDouble(obj,"t_distance",0.0)
      val t_duration = JSONUtil.getJsonDouble(obj,"t_duration",0.0)
      val roadfee = JSONUtil.getJsonDouble(obj,"roadfee",0.0)
      val oil_fee = JSONUtil.getJsonDouble(obj,"oil_fee",0.0)
      val start_dist = JSONUtil.getJsonDouble(obj,"start_dist",0.0)
      val end_dist = JSONUtil.getJsonDouble(obj,"end_dist",0.0)
      val freq = JSONUtil.getJsonDouble(obj,"freq",0.0)
      val label = JSONUtil.getJsonVal(obj,"label","")
      val score_rank = JSONUtil.getJsonDouble(obj,"score_rank",-1.0).toInt
      val reason = JSONUtil.getJsonVal(obj,"reason","")
      val param_type = JSONUtil.getJsonVal(obj,"param_type","")

      // 接口返回值
      val repair_status = JSONUtil.getJsonVal(obj,"repair_status","")
      val repair_code = JSONUtil.getJsonVal(obj,"repair_code","")
      val repair_info = JSONUtil.getJsonVal(obj,"repair_info","")
      val repair_err = JSONUtil.getJsonVal(obj,"repair_err","")
      val repair_msg = JSONUtil.getJsonVal(obj,"repair_msg","")
      val repair_stdid = JSONUtil.getJsonVal(obj,"repair_stdid","")
      val inc_day = JSONUtil.getJsonVal(obj,"inc_day","")

      UpdateResult(linevehicle,task_area_code,std_id,plan_time,t_distance,t_duration,roadfee,oil_fee,start_dist,end_dist,freq,label,score_rank,reason,param_type,repair_status,repair_code,
        repair_info,repair_err,repair_msg,repair_stdid,inc_day)
    }).toDF()

    // 更新结果
    val cols_15 = spark.sql("""select * from dm_gis.eta_line_update_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_update_result.coalesce(50).select(cols_15: _*), Seq("inc_day"), "dm_gis.eta_line_update_result")

  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231020  ++++")
    // 固定线路新增入库
    runAddLineInteface(spark, dayBefore1)
    // 标准线路打标
    runUpdateLineFiledInteface(spark, dayBefore1)
    logger.error("++++++++  任务结束 20231020 ++++")

    spark.stop()
  }


}
