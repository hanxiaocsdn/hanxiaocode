package com.sf.gis.scala.lss.application

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.JavaConversions._

/**
 * @Description:ERP平台设备信息表同步
 * 需求人员：01422522 黄晓冰
 * @Author: lixiangzhi 01405644
 * @Date:20240119
 * 任务id:985326
 * 任务名称：ERP平台设备信息表
 * 依赖任务：无
 * 数据源：dm_gis.erp_log
 * 调用服务地址：无
 * 数据结果：dm_mms_erp_platform_equipment_info_di
 */
object ErpPlatformEquipmentInfo {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSourceData(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val jsonObj="$"
    val erpLogSql=
      s"""
        |select data
        |FROM
        |(
        |select  get_json_object(log,'$jsonObj.data') as data,get_json_object(log,'$jsonObj.type') as type
        |from dm_gis.erp_log where inc_day='${incDay}'
        |) t
        |where type='99'
        |""".stripMargin
    val erpPlatformEquipmentInfoDf: DataFrame = SparkUtils.getRowToJsonClear(spark, erpLogSql).flatMap(obj => {
      val data: String = obj.getString("data")
      val dataArray: JSONArray = JSON.parseArray(data)
      val dataNewArray = new util.ArrayList[JSONObject]()
      for (i <- 0 until (dataArray.size())) {
        val dataObj: JSONObject = dataArray.getJSONObject(i)
        dataNewArray.append(dataObj)
      }
      obj.remove("data")
      dataNewArray.iterator()
    }).map(obj => {
      CaseErpPlatformEquipmentInfo(
        obj.getString("projectName"),
        obj.getString("imei"),
        obj.getString("sn"),
        obj.getString("productType"),
        obj.getString("orgCode"),
        obj.getString("orgName"),
        obj.getString("createDate"),
        obj.getString("updateDate"),
        obj.getString("installDate"),
        obj.getString("vin"),
        obj.getString("carNo"),
        obj.getString("carColor"),
        obj.getString("tlMac"),
        obj.getString("cameraChannel"),
        obj.getString("insuranceOrgName"),
        obj.getString("insuranceOrgFleetName"),
        obj.getString("vmsStatus"),
        obj.getString("vmsType"),
        obj.getString("vmsFailReason"),
        obj.getString("vmsUpdateTime"),
        obj.getString("vlEngineNo"),
        obj.getString("vlRegisterDate"),
        obj.getString("vlVehicleType"),
        obj.getString("registerTypeDesc"),
        obj.getString("accessName"),
        obj.getString("tag")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,erpPlatformEquipmentInfoDf,"inc_day",incDay,"dm_gis.dm_mms_erp_platform_equipment_info_di")

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表erp_log,并解析字段
    readSourceData(spark, incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    logger.error("incDay:"+incDay)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseErpPlatformEquipmentInfo(
                                          projectName:String,
                                          imei:String,
                                          sn:String,
                                          productType:String,
                                          orgCode:String,
                                          orgName:String,
                                          createDate:String,
                                          updateDate:String,
                                          installDate:String,
                                          vin:String,
                                          carNo:String,
                                          carColor:String,
                                          tlMac:String,
                                          cameraChannel:String,
                                          insuranceOrgName:String,
                                          insuranceOrgFleetName:String,
                                          vmsStatus:String,
                                          vmsType:String,
                                          vmsFailReason:String,
                                          vmsUpdateTime:String,
                                          vlEngineNo:String,
                                          vlRegisterDate:String,
                                          vlVehicleType:String,
                                          registerTypeDesc:String,
                                          accessName:String,
                                          tag:String
                                             )

}
