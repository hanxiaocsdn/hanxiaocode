package com.sf.gis.scala.lss.lineUpdate

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.isEmptyOrNull
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：800430
 * 任务名称：需运营线路明细表_1
 */
object EtaLineNeedOperate {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def run(spark: SparkSession, inc_day: String) = {

    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)                 // 20230907
    val dayBefore14 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 14)               // 20230825
    val MouthBefore1 = DateUtil.getMouthBefore(inc_day, 1)                                          // 20230808
    val inc_day_start = DateUtil.getDayBefore(MouthBefore1, "yyyyMMdd", 3)        // 20230805
    val inc_day_end = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)               // 20230907
    val task_inc_day_start = DateUtil.getDayBefore(MouthBefore1, "yyyyMMdd", 2)   // 20230806
    val task_inc_day_end = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 2)          // 20230906

    // 获取已运营线路表数据
    import spark.implicits._
    val already_sql =
      s"""
         |select
         |  linevehicle,
         |  update_time,
         |  type,
         |  area_type,
         |  line_count
         |from
         |  dm_gis.eta_line_already_operate
         |where
         |  update_time < '$dayBefore1'
         |""".stripMargin

    println("已运营线路表取数sql：")
    println(already_sql)
    val df_already = spark.sql(already_sql)
      .withColumn("join_tag",lit(1))
      .withColumn("rn", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("update_time"))))
      .filter('rn === 1) // 按 linevehicle 去重
      .drop("rn")

    // 获取recall表数据
    val line_recall_sql =
      s"""
         |select
         |  line_code,
         |  start_dept,
         |  end_dept,
         |  vehicle_type,
         |  carrier_type,
         |  task_area_code,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  actual_capacity_load,
         |  axls_number,
         |  start_type,
         |  end_type,
         |  conduct_type,
         |  task_subid,
         |  std_id,
         |  ac_is_run_ontime,
         |  actual_depart_tm,
         |  rt_coords,
         |  line_require_id,
         |  plan_depart_tm,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  vehicle_serial,
         |  task_inc_day,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$inc_day_start'
         |  and inc_day <= '$inc_day_end'
         |  and task_inc_day >= '$task_inc_day_start'
         |  and task_inc_day <= '$task_inc_day_end'
         |  and error_type = '0'
         |  and task_area_code in ('010Y','571Y','536Y','027Y','024Y','023Y','577Y','311Y','791Y','769Y','371Y',
         |  '316Y','871Y','517Y','531Y','431Y','029Y','512Y','510Y','022Y','851Y','551Y',
         |  '532Y','025Y','021Y','755Y','513Y','579Y','757Y','028Y','020Y','760Y','351Y',
         |  '991Y','731Y','595Y','574Y','752Y','471Y','591Y','771Y','931Y','898Y','451Y',
         |  '592Y','555Y','999Y','888Y','666Y','333Y','300Y','700Y','777Y','222Y','111Y')
         |""".stripMargin

    println("recall表取数sql：")
    println(line_recall_sql)

    val isEmptyOrNull_udf = udf(isEmptyOrNull _)
    val df_line_recall = spark.sql(line_recall_sql)
      .filter(!(('start_type === "1" and isEmptyOrNull_udf('start_outer_add_code)) or ('end_type === "1" and isEmptyOrNull_udf('end_outer_add_code))))
      .withColumn("start_dept",when('start_type === "1",'start_outer_add_code).otherwise('start_dept))
      .withColumn("end_dept",when('end_type === "1",'end_outer_add_code).otherwise('end_dept))
      .withColumn("linevehicle",concat_ws("_",'line_code,'start_dept,'end_dept,'vehicle_type))
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 中间表11 任务详情表
    val cols_11 = spark.sql("""select * from dm_gis.eta_line_table_tmp11 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_line_recall.coalesce(50).select(cols_11: _*), Seq("inc_day"), "dm_gis.eta_line_table_tmp11")

    val df_need_operate = df_line_recall
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid).orderBy(desc("inc_day"))))
      .filter('rn === 1) // 按 task_subid 去重
      .drop("rn")
      .withColumn("linevehicle",concat_ws("_",'line_code,'start_dept,'end_dept,'vehicle_type))
      .groupBy("linevehicle")
      .agg(
        count(when('task_inc_day >= dayBefore14 and 'task_inc_day <= dayBefore1,'task_subid).otherwise(null)) as "total_num",
        count(when('conduct_type === "1" and 'task_inc_day >= dayBefore14 and 'task_inc_day <= dayBefore1,'task_subid).otherwise(null)) as "exe_num"
      )
      .withColumn("exe_ratio",'exe_num / 'total_num)
      .join(df_already,Seq("linevehicle"),"left")
      .withColumn("line_type",when('join_tag.isNull,"增量线路")  // 未运营过的线路
        .when('join_tag === 1 and 'total_num > 0 and 'exe_ratio < 0.6,"执行率低线路").otherwise(""))  // 运营过的线路，近14天有执行，执行率低于0.6
      //.filter('line_type === "增量线路" or 'line_type === "执行率低线路")  // 筛选执行率低线路和增量线路  移至使用时过滤
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表1 需运营线路明细表
    val cols_1 = spark.sql("""select * from dm_gis.eta_line_need_operate limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_need_operate.coalesce(50).select(cols_1: _*), Seq("inc_day"), "dm_gis.eta_line_need_operate")

    df_line_recall.unpersist()
  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, inc_day)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
