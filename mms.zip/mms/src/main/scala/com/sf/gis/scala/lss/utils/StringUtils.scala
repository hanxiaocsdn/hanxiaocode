package com.sf.gis.scala.lss.utils

import com.alibaba.fastjson.{JSON, JSONArray}

import java.text.SimpleDateFormat
import java.util.regex.Pattern
import java.util.{Date, Objects}
import scala.collection.mutable.ArrayBuffer


/**
  * Created by 01374443 on 2020/3/25.
  */
object StringUtils {
  def nonEmpty(str:String):Boolean={
    str!=null && !str.isEmpty
  }
  def nonEmptyEq(str1:String,str2:String):Boolean={
    if(str1==null || str2 == null){
      return false
    }
    str1.equals(str2)
  }
  def pickGroup1Str(str: String, regex: String): String = {
    val pattern = Pattern.compile(regex)
    val matcher = pattern.matcher(str)
    if (matcher.find) matcher.group(1)
    else ""
  }

  def isBlank(str: String): Boolean = {
    var strLen = 0
    if (str != null && (strLen = str.length) != 0) {
      var i = 0
      while ( {
        i < strLen
      }) {
        if (!Character.isWhitespace(str.charAt(i))) return false

        {
          i += 1; i
        }
      }
      true
    }
    else true
  }


  def pickGroup0Str(str: String, regex: String): String = {
    val pattern = Pattern.compile(regex)
    val matcher = pattern.matcher(str)
    if (matcher.find) matcher.group(0)
    else ""
  }

  def isNotBlank(str: String): Boolean = !isBlank(str)
  /**
   * @note   Null转为空字符串
   * @param src
   * */
  def convertString(src:String): String ={
    var str = src
    if(Objects.equals(src,null))
      str = ""
    str.trim
  }

  val REGEX = "[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]"
  val EMO_JI = Pattern.compile(REGEX, Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE)
  val replacement = "*"

  /**
   * @note   替换字符串中包含特殊表情包的字符
   * @param src
   * */
  def replacementEmoJi(src: String): String = {
    var replacementSource = src
    if (StringUtils.nonEmpty(src)) {
      val matcher = EMO_JI.matcher(src)
      if (matcher.find) {
        replacementSource = matcher.replaceAll(replacement)
      }
    }
    replacementSource
  }

  val EXTENDED_REGEX = "\\s*|\t|\r|\n"
  val EXTENDED_REGEX_PATTERN = Pattern.compile(EXTENDED_REGEX, Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE)
  /**
   * @note   替换字符串中包含的 多空格 \r \n \t etc
   * @param src
   * */
  def replacementExtended(src: String): String = {
    var replacementSource = src
    if (StringUtils.nonEmpty(src)) {
      val matcher = EXTENDED_REGEX_PATTERN.matcher(src)
      if (matcher.find) {
        replacementSource = matcher.replaceAll("")
      }
    }
    replacementSource
  }

  /**
   * 将字符串转换成JSONArray再转成特定格式
   * [[108.66265,34.209589],[108.66265,34.209589],[108.66248,34.20997]] 转成 108.66265,34.209589|108.66265,34.209589|108.66248,34.20997
   * @param str
   * @return
   */
  def stdCoordsToPoints(str: String)  = {

    var obj = new JSONArray()
    val arr = new ArrayBuffer[String]()
    try{
      obj = JSON.parseArray(str)
      for (i <- 0 until obj.size()){
        val x = obj.getJSONArray(i).getString(0)
        val y = obj.getJSONArray(i).getString(1)
        val sss = s"""${x},${y}"""
        arr.append(sss)
      }
    }catch {
      case e: Exception => println(">>>轨迹转换异常"+e)
    }
    val points = arr.mkString("|")
    points
  }

  /**
   * 两种不同格式时间字符串相互转换
   * @param time
   * @param format
   * @param newFormat
   * @throws
   * @return
   */
  def timeToCustomTime(time: String, format1: String, format2: String) = {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  }

}
