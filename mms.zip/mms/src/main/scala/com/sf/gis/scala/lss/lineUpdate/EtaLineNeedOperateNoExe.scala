package com.sf.gis.scala.lss.lineUpdate

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.DouglasPeuckerAlgorithm.dpCoords
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.{getGrp2, isEmptyOrNull}
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.OperateUnexe
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：800687
 * 任务名称：外包需运营线路未执行轨迹明细表_2
 */
object EtaLineNeedOperateNoExe {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def run(spark: SparkSession, inc_day: String) = {

    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)           // 20230907
    val MouthBefore1 = DateUtil.getMouthBefore(inc_day, 1)                                    // 20230808
    val inc_day_start = DateUtil.getDayBefore(MouthBefore1, "yyyyMMdd", 3)   // 20230805
    val inc_day_end = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)          // 20230907
    val task_inc_day_start = DateUtil.getDayBefore(MouthBefore1, "yyyyMMdd", 2)   // 20230806
    val task_inc_day_end = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 2)          // 20230906

    // 获取recall表数据
    import spark.implicits._
    val line_recall_sql =
      s"""
         |select
         |  line_code,
         |  task_area_code,
         |  start_dept,
         |  end_dept,
         |  vehicle_type,
         |  carrier_type,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  actual_capacity_load,
         |  axls_number,
         |  start_type,
         |  end_type,
         |  conduct_type,
         |  task_subid,
         |  std_id,
         |  ac_is_run_ontime,
         |  actual_depart_tm,
         |  rt_coords,
         |  line_require_id,
         |  plan_depart_tm,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  vehicle_serial,
         |  task_inc_day,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$inc_day_start'
         |  and inc_day <= '$inc_day_end'
         |  and task_inc_day >= '$task_inc_day_start'
         |  and task_inc_day <= '$task_inc_day_end'
         |  and error_type = '0'
         |  and conduct_type != '1'
         |  and carrier_type != '0'
         |  and task_area_code in ('010Y','571Y','536Y','027Y','024Y','023Y','577Y','311Y','791Y','769Y','371Y',
         |  '316Y','871Y','517Y','531Y','431Y','029Y','512Y','510Y','022Y','851Y','551Y',
         |  '532Y','025Y','021Y','755Y','513Y','579Y','757Y','028Y','020Y','760Y','351Y',
         |  '991Y','731Y','595Y','574Y','752Y','471Y','591Y','771Y','931Y','898Y','451Y',
         |  '592Y','555Y','999Y','888Y','666Y','333Y','300Y','700Y','777Y','222Y','111Y')
         |""".stripMargin
    println("recall表取数sql：")
    println(line_recall_sql)

    val need_operate_sql =
      s"""
         |select
         |  linevehicle,
         |  exe_ratio,
         |  line_type
         |from
         |  dm_gis.eta_line_need_operate
         |where
         |  inc_day = '$dayBefore1'
         |  and (line_type = '增量线路' or line_type = '执行率低线路')
         |""".stripMargin
    println("需要运营线路表取数sql：")
    println(need_operate_sql)

    val isEmptyOrNull_udf = udf(isEmptyOrNull _)
    val df_need_operate = spark.sql(need_operate_sql)

    val df_un = spark.sql(line_recall_sql)
      .filter(!(('start_type === "1" and isEmptyOrNull_udf('start_outer_add_code)) or ('end_type === "1" and isEmptyOrNull_udf('end_outer_add_code))))
      .withColumn("start_dept",when('start_type === "1",'start_outer_add_code).otherwise('start_dept))
      .withColumn("end_dept",when('end_type === "1",'end_outer_add_code).otherwise('end_dept))
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid).orderBy(desc("inc_day"))))
      .filter('rn === 1) // 按 task_subid 去重
      .drop("rn")
      .withColumn("linevehicle",concat_ws("_",'line_code,'start_dept,'end_dept,'vehicle_type))
      .join(df_need_operate,Seq("linevehicle"),"inner")
      .withColumnRenamed("linevehicle","check_lineid") // 分组字段
      .withColumn("time",'actual_depart_tm) // 排序字段
      // 轨迹优化
      .withColumn("rt_coords_old", 'rt_coords)
      .withColumn("rt_coords", when(!isEmptyOrNull_udf('rt_coords),dpCoords('rt_coords,lit(0.00001))).otherwise('rt_coords))

    // 轨迹聚合流程
    val df_grp2 = getGrp2(spark,df_un,0.95)
      .map(obj=>{
        val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
        val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
        val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
        val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
        val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
        val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
        val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
        val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
        val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
        val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
        val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
        val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
        val ac_is_run_ontime = JSONUtil.getJsonVal(obj, "ac_is_run_ontime", "")
        val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords_old", "")
        val grp22 = JSONUtil.getJsonVal(obj, "grp2", "")
        val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
        val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")
        val start_outer_add_code = JSONUtil.getJsonVal(obj, "start_outer_add_code", "")
        val end_outer_add_code = JSONUtil.getJsonVal(obj, "end_outer_add_code", "")
        val actual_capacity_load = JSONUtil.getJsonVal(obj, "actual_capacity_load", "")
        val axls_number = JSONUtil.getJsonVal(obj, "axls_number", "")
        val start_type = JSONUtil.getJsonVal(obj, "start_type", "")
        val end_type = JSONUtil.getJsonVal(obj, "end_type", "")
        val line_require_id = JSONUtil.getJsonVal(obj, "line_require_id", "")
        val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
        val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
        val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
        val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
        val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")
        val task_inc_day = JSONUtil.getJsonVal(obj, "task_inc_day", "")
        val line_type = JSONUtil.getJsonVal(obj, "line_type", "")
        val exe_ratio = JSONUtil.getJsonVal(obj, "exe_ratio", "")

        OperateUnexe(line_code,task_area_code,check_lineid,start_dept,end_dept,vehicle_type,carrier_type,start_outer_add_code,end_outer_add_code,actual_capacity_load,axls_number,
          start_type,end_type,conduct_type,task_subid,std_id,actual_depart_tm,ac_is_run_ontime,rt_coords,line_require_id,plan_depart_tm,start_longitude,
          start_latitude,end_longitude,end_latitude,vehicle_serial,task_inc_day,line_type,exe_ratio,grp22,sim1,sim5)
      }).toDF()
      .withColumn("group_label",'grp22)
      .withColumnRenamed("check_lineid","linevehicle")
      .withColumn("group_cnt", count('linevehicle).over(Window.partitionBy('group_label)))
      .withColumn("cdct_ontime_cnt", count(when('ac_is_run_ontime.cast("double") === 1.0,1).otherwise(null)).over(Window.partitionBy('group_label)))
      .withColumn("rn", row_number().over(Window.partitionBy('group_label).orderBy(desc("group_cnt"),desc("actual_depart_tm"))))
      .filter('rn === 1) // 按 group_label 去重
      .drop("rn")
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表2 外包需运营线路未执行轨迹明细表
    val cols_2 = spark.sql("""select * from dm_gis.eta_line_need_operate_unexe limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_grp2.coalesce(50).select(cols_2: _*), Seq("inc_day"), "dm_gis.eta_line_need_operate_unexe")
  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, inc_day)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }

}
