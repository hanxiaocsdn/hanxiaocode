package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONArray}
import com.vividsolutions.jts.geom.{Coordinate, LineSegment}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.udf

import scala.collection.mutable.ArrayBuffer


/**
 * 道格拉斯算法压缩轨迹——简易版
 * 有损压缩
 */
object DouglasPeuckerAlgorithm {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  // 创建一个Point类
  case class Point(x: Double, y: Double)

  // 道格拉斯方法实现
  def dp(pts1: Seq[Point], tolerance: Double): Seq[Point] = {

    var pts = pts1

    val arrBuffer = new ArrayBuffer[Point]()
    arrBuffer.append(pts.head)
    def dpRunner(pts: Seq[Point], tolerance: Double): Unit = {

      val head = pts.head
      val last = pts.last

      // 首尾点连成的线段
      val lineSegment: LineSegment = new LineSegment(head.x,head.y,last.x,last.y)
      //求曲线上所有点到直线的垂直距离，并找出最大距离dmax
      //最大距离的点
      val maxDistancePoint = pts.maxBy(opt=>{
        val x = opt.x
        val y = opt.y
        val d1 = lineSegment.distance(new Coordinate(x, y))
        d1
      })
      // 最大距离
      val maxDistance: Double = lineSegment.distance(new Coordinate(maxDistancePoint.x,maxDistancePoint.y))
      //最大距离点的索引
      val maxPointIndex = pts.indexOf(maxDistancePoint)
      // 如果最大距离小于给定的阈值，则将曲线中间的所有点舍去
      if (maxDistance < tolerance) {
        arrBuffer.append(last)
      } else {
        // 如果最大距离大于给定的阈值，则以该点为界将曲线划分为两部分，重复以上步骤
        dpRunner(pts.slice(0, maxPointIndex + 1), tolerance)
        dpRunner(pts.slice(maxPointIndex, pts.size), tolerance)
      }
    }

    dpRunner(pts, tolerance)
    pts = arrBuffer

    pts
  }

  // 道格拉斯算法压缩轨迹点，udf函数
  def dpCoords = udf((rt_coords: String,tolerance: Double) => {
    var ret = rt_coords

    if (rt_coords != null && rt_coords.trim != "" && tolerance != null && tolerance != 0) {

      // 将轨迹点转换成Point格式
      var obj = new JSONArray()
      val points = new ArrayBuffer[Point]()
      try{
        obj = JSON.parseArray(rt_coords)
        for (i <- 0 until obj.size()){
          val x = obj.getJSONArray(i).getDouble(0)
          val y = obj.getJSONArray(i).getDouble(1)
          points.append(Point.apply(x,y))
        }
      }catch {
        case e: Exception => println(">>>轨迹转换异常"+e)
      }

      logger.error("开始压缩轨迹")
      var i = 0
      var tolerance_i = tolerance  // 阈值
      while(ret.length >= 100000 && i < 1000){  // 判断压缩后轨迹长度，如果还是太大则修改阈值重新压缩，直到满足长度或者循环次数达到1000次
        tolerance_i = tolerance*(i/10+1)
        val points_new = dp(points, tolerance_i) // 道格拉斯算法压缩轨迹点
        val obj1 = new JSONArray()

        for (elem <- points_new) {
          val x = elem.x
          val y = elem.y
          val obj2 = new JSONArray()
          obj2.add(x)
          obj2.add(y)

          obj1.add(obj2)
        }
        ret = obj1.toJSONString
        i = i + 1
      }

      logger.error("轨迹压缩完成,压缩次数：" + i+ "  阈值为："+tolerance_i)
    }

    ret
  })

}
