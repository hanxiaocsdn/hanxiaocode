package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.base.util.StringUtils.nonEmpty
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.row2Json
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.sf.gis.scala.lss.utils.StringUtils.stdCoordsToPoints
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 承运商维度执行、准点、成本统计
 * 需求方：张翠霞（01369612）
 * @author 徐游飞（01417347）
 * 任务ID：765660
 * 任务名称：任务成本明细表和成本统计表 grd1&grd2
 */
object GisEtaStdLineRecallCost {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val QM_URL: String = "http://rp-c-gd.int.sfcloud.local:1090/qm_point?"
  val QM_AK: String = ""
  //val QM_URL: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
  //val QM_AK: String = "d6a1f9b11d2441fc8fc1ffb5eb3e61d6"
  val parallelism = 10
  val akMinuLimit = 4000

  // 获取hive源数据
  def getDataSource(spark: SparkSession, dayBefore1: String, dayBefore7: String) = {
    import spark.implicits._
    val recall_sql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  start_type,
         |  end_type,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  is_stop,
         |  stop_over_zone_code,
         |  transoport_level,
         |  if(child_carrier_name is not null and child_carrier_name <> '',child_carrier_name,carrier_name) as carrier_name,
         |  carrier_type,
         |  vehicle_type,
         |  axls_number,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  conduct_type,
         |  biz_type,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  std_id,
         |  sf_outer_vehicle_from,
         |  if (start_type = 1 and start_outer_add_code is not null and start_outer_add_code <> '', start_outer_add_code, start_dept) as src_zone_code,
         |  if (end_type = 1 and end_outer_add_code is not null and end_outer_add_code <> '', end_outer_add_code, end_dept) as dest_zone_code,
         |  rt_coords,
         |  task_inc_day,
         |  inc_day,
         |  (
         |    case
         |      when actual_capacity_load < 1.5 then 0.84
         |      when actual_capacity_load >= 1.5
         |      and actual_capacity_load < 3 then 0.84
         |      when actual_capacity_load >= 3
         |      and actual_capacity_load < 5 then 0.88
         |      when actual_capacity_load >= 5
         |      and actual_capacity_load < 7 then 1.07
         |      when actual_capacity_load >= 7
         |      and actual_capacity_load < 14 then 1.36
         |      when actual_capacity_load >= 14
         |      and actual_capacity_load < 20 then 1.51
         |      when actual_capacity_load >= 20
         |      and actual_capacity_load < 30 then 1.88
         |      when actual_capacity_load >= 30 then 1.99
         |    end
         |  ) as unitprice
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '$dayBefore1'
         |  and error_type = '0'
         |  and halfway_integrate_rate >= '0.9'
         |  and carrier_type != '0'
         |""".stripMargin
    println(recall_sql)
    val df_recall = spark.sql(recall_sql)
      // 根据grd1去重，保留inc_day最新的一条
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid).orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .drop("rn")

    val fule_prices_sql =
      s"""
         |select
         |  fuel_prices,
         |  inc_day
         |from
         |  dm_gis.gis_fule_prices
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    val df_fule_prices = spark.sql(fule_prices_sql)

    (df_recall,df_fule_prices)
  }

  /**
   * 解析QM匹配接口,获取收费字段
   * @param ret
   * @return
   */
  def parseQMData(ret: JSONObject) : (String,String,String,String,String,String) = {

    var t_status = ""
    var t_distance = ""
    var t_tolls = ""
    var t_etc_toll = ""
    var t_highspeed_distance = ""
    var t_toll_distance = ""

    if (ret != null ) {
      //获取接口返回状态
      t_status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(t_status)) {
        logger.error("获取接口数据失败: " + ret.getString("info"))
        return (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
      } else {
        var paths = new JSONArray()
        try {
          paths = ret.getJSONObject("route").getJSONArray("paths")
          t_distance = paths.getJSONObject(0).getString("distance")
          t_tolls = paths.getJSONObject(0).getString("tolls")
          t_etc_toll = paths.getJSONObject(0).getString("etc_toll")
          t_highspeed_distance = paths.getJSONObject(0).getString("highspeed_distance")
          t_toll_distance = paths.getJSONObject(0).getString("toll_distance")
        } catch {
          case _ =>
        }
        return (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
      }
    }
    (t_status,t_distance,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance)
  }

  // 调qm接口
  def runQMInteface4(ak:String, obj: JSONObject): JSONObject = {

    val test = 0
    val stype = 0
    val etype = 0
    val plate = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val Mload = JSONUtil.getJsonVal(obj, "actual_capacity_load", "")
    val axlenumber = JSONUtil.getJsonVal(obj, "axls_number", "")
    val mode = 2
    val speed = 1
    val No = JSONUtil.getJsonVal(obj, "task_subid", "")
    val Toll = 1
    val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
    val points = stdCoordsToPoints(rt_coords)

    //初始化接口请求参数
    val param = s"test=$test&stype=$stype&etype=$etype&plate=$plate&vehicle=$vehicle&Mload=$Mload&axlenumber=$axlenumber&mode=$mode&speed=$speed&No=$No&Toll=$Toll&points=$points"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析qm接口返回值
    val httpData =  parseQMData(retJSONObject)
    obj.put("t_status",httpData._1)
    obj.put("t_distance",httpData._2)
    obj.put("t_tolls",httpData._3)
    obj.put("t_etc_toll",httpData._4)
    obj.put("t_highspeed_distance",httpData._5)
    obj.put("t_toll_distance",httpData._6)
    obj
  }

  def getEtaStdLineRecallCostGrd(spark: SparkSession, df_recall_cost: DataFrame, dayBefore1: String, group: String) = {
    import spark.implicits._

    val df_grd = df_recall_cost
      .groupBy(s"$group")
      .agg(
        max("task_area_code") as "task_area_code",
        max("carrier_name") as "carrier_name",
        max("vehicle_type") as "vehicle_type",
        max("start_dept") as "start_dept",
        max("end_dept") as "end_dept",
        max("src_zone_code") as "src_zone_code",
        max("dest_zone_code") as "dest_zone_code",
        max("sf_outer_vehicle_from") as "sf_outer_vehicle_from",
        max("actual_capacity_load") as "actual_capacity_load",
        max("axls_number") as "axls_number",
        max("grd2") as "grd2_tmp",
        max("inc_day") as "inc_day",
        max("line_code") as "line_code",
        max("vehicle_serial") as "vehicle_serial",
        // 整体任务
        countDistinct("task_subid") as "num",
        avg("miles") as "miles_ave",
        avg("road_fee") as "road_fee_ave",
        avg("fuel_cost") as "fuel_cost_ave",
        avg("sum_cost") as "sum_cost_ave",
        //执行任务
        countDistinct(when('conduct_type === 1,'task_subid).otherwise(null)) as "exe_num",
        avg(when('conduct_type === 1,'miles).otherwise(null)) as "exe_miles_ave",
        avg(when('conduct_type === 1,'road_fee).otherwise(null)) as "exe_road_fee_ave",
        avg(when('conduct_type === 1,'fuel_cost).otherwise(null)) as "exe_fuel_cost_ave",
        avg(when('conduct_type === 1,'sum_cost).otherwise(null)) as "exe_sum_cost_ave",
        //未执行任务
        countDistinct(when('conduct_type === 3,'task_subid).otherwise(null)) as "unexe_num",
        avg(when('conduct_type === 3,'miles).otherwise(null)) as "unexe_miles_ave",
        avg(when('conduct_type === 3,'road_fee).otherwise(null)) as "unexe_road_fee_ave",
        avg(when('conduct_type === 3,'fuel_cost).otherwise(null)) as "unexe_fuel_cost_ave",
        avg(when('conduct_type === 3,'sum_cost).otherwise(null)) as "unexe_sum_cost_ave"
      )
      // 计算成本差值
      .withColumn("diff_miles",when('exe_miles_ave < 'unexe_miles_ave,'exe_miles_ave - 'unexe_miles_ave).otherwise(0))
      .withColumn("diff_road_fee",when('exe_road_fee_ave < 'unexe_road_fee_ave,'exe_road_fee_ave - 'unexe_road_fee_ave).otherwise(0))
      .withColumn("diff_fuel_cost",when('exe_fuel_cost_ave < 'unexe_fuel_cost_ave,'exe_fuel_cost_ave - 'unexe_fuel_cost_ave).otherwise(0))
      .withColumn("diff_sum_cost",when('exe_sum_cost_ave < 'unexe_sum_cost_ave,'exe_sum_cost_ave - 'unexe_sum_cost_ave).otherwise(0))
      .withColumn("cost_save",'diff_sum_cost * 'exe_num)
      .withColumn("cost_waste",abs('diff_sum_cost * 'unexe_num))

    df_grd
  }

  // 总油费和总成本计算（空值情况特殊处理，保持为空）
  def getfuelCostNew(fuel_prices: String,update_uint_fuel: String,miles_new: Double,road_fee_new: Double) = {

    var fuel_cost_new = ""
    var sum_cost_new = ""

    if(nonEmpty(fuel_prices) && nonEmpty(update_uint_fuel)){
      val fuel_cost_new_tmp = fuel_prices.toDouble * update_uint_fuel.toDouble * miles_new / 100
      fuel_cost_new = fuel_cost_new_tmp.toString
      sum_cost_new = (road_fee_new + fuel_cost_new_tmp).toString
    }

    (fuel_cost_new,sum_cost_new)
  }

  // 计算任务成本明细表 dim_gis.eta_std_line_recall_cost
  def getEtaStdLineRecallCost(spark: SparkSession, dayBefore1: String, dayBefore7: String) = {
    import spark.implicits._

    // 获取hive源数据
    val (df_recall,df_fule_prices) = getDataSource(spark, dayBefore1, dayBefore7)

    val df_recall_fule_prices = df_recall
      .join(df_fule_prices,Seq("inc_day"),"left")
      .withColumn("uint_fuel",'unitprice / 7 * 100)
      .withColumn("grd1",concat_ws("_",'task_area_code,'carrier_name,'vehicle_type,'src_zone_code,'dest_zone_code,'sf_outer_vehicle_from,'task_inc_day,'actual_capacity_load,'axls_number))
      .withColumn("grd2",concat_ws("_",'task_area_code,'carrier_name,'sf_outer_vehicle_from,'task_inc_day,'line_code,'vehicle_serial))

    val invokeCnt = df_recall_fule_prices.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "765660", "任务成本明细表和成本统计表 grd1&grd2", "获取收费字段", QM_URL, QM_AK, invokeCnt, parallelism)
    // 调QM匹配接口,获取收费字段
    val rdd_recall_fule_prices = SparkNet.runInterfaceWithAkLimit(spark, df_recall_fule_prices.rdd.map(row2Json), runQMInteface4, parallelism, QM_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)

    val df_recall_cost = rdd_recall_fule_prices.map(obj => {
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val start_outer_add_code = JSONUtil.getJsonVal(obj, "start_outer_add_code", "")
      val end_outer_add_code = JSONUtil.getJsonVal(obj, "end_outer_add_code", "")
      val start_type = JSONUtil.getJsonVal(obj, "start_type", "")
      val end_type = JSONUtil.getJsonVal(obj, "end_type", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val unitprice = JSONUtil.getJsonVal(obj, "unitprice", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val actual_capacity_load = JSONUtil.getJsonVal(obj, "actual_capacity_load", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val line_time = JSONUtil.getJsonVal(obj, "line_time", "")
      val line_distance = JSONUtil.getJsonVal(obj, "line_distance", "")
      val actual_run_time = JSONUtil.getJsonVal(obj, "actual_run_time", "")
      val is_stop = JSONUtil.getJsonVal(obj, "is_stop", "")
      val stop_over_zone_code = JSONUtil.getJsonVal(obj, "stop_over_zone_code", "")
      val transoport_level = JSONUtil.getJsonVal(obj, "transoport_level", "")
      val carrier_name = JSONUtil.getJsonVal(obj, "carrier_name", "")
      val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val axls_number = JSONUtil.getJsonVal(obj, "axls_number", "")
      val time = JSONUtil.getJsonVal(obj, "time", "")
      val rt_dist = JSONUtil.getJsonDouble(obj, "rt_dist", 0.0)
      val highwaymileage = JSONUtil.getJsonVal(obj, "highwaymileage", "")
      val toll_charge = JSONUtil.getJsonVal(obj, "toll_charge", "")
      val error_type = JSONUtil.getJsonVal(obj, "error_type", "")
      val pns_dist = JSONUtil.getJsonVal(obj, "pns_dist", "")
      val pns_time = JSONUtil.getJsonVal(obj, "pns_time", "")
      val src = JSONUtil.getJsonVal(obj, "src", "")
      val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
      val biz_type = JSONUtil.getJsonVal(obj, "biz_type", "")
      val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
      val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
      val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
      val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val sf_outer_vehicle_from = JSONUtil.getJsonVal(obj, "sf_outer_vehicle_from", "")
      val src_zone_code = JSONUtil.getJsonVal(obj, "src_zone_code", "")
      val dest_zone_code = JSONUtil.getJsonVal(obj, "dest_zone_code", "")
      val uint_fuel = JSONUtil.getJsonVal(obj, "uint_fuel", "")
      val fuel_prices = JSONUtil.getJsonVal(obj, "fuel_prices", "")
      val grd1 = JSONUtil.getJsonVal(obj, "grd1", "")
      val grd2 = JSONUtil.getJsonVal(obj, "grd2", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")

      // qm接口返回字段
      val t_status = JSONUtil.getJsonValInt(obj, "t_status", 404)
      val t_highspeed_distance = JSONUtil.getJsonDouble(obj, "t_highspeed_distance", 0.0)
      val t_tolls = JSONUtil.getJsonDouble(obj, "t_tolls", 0.0)
      val t_toll_distance = JSONUtil.getJsonDouble(obj, "t_toll_distance", 0.0)
      val t_distance = JSONUtil.getJsonDouble(obj, "t_distance", 0.0)


      val miles = t_distance / 1000
      val road_fee = t_tolls

      // 打标用于后续过滤接口返回异常的数据
      var roadfee_flag = 1
      if ((t_status == 0 && t_tolls >= 0.0) || (t_status == 0 && t_tolls == 0.0 && t_highspeed_distance == 0.0 && t_toll_distance == 0.0)) roadfee_flag = 0
      // 总油费和总成本计算（空值情况特殊处理，保持为空）
      val (fuel_cost, sum_cost) = getfuelCostNew(fuel_prices, uint_fuel, miles, road_fee)

      RecallCost(task_area_code,task_id,task_subid,start_dept,end_dept,start_outer_add_code,end_outer_add_code,start_type,end_type,line_code,unitprice,vehicle_serial,
        actual_capacity_load,actual_depart_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,is_stop,stop_over_zone_code,transoport_level,carrier_name,carrier_type,
        vehicle_type,axls_number,time,rt_dist,highwaymileage,toll_charge,error_type,pns_dist,pns_time,src,conduct_type,biz_type,start_longitude,start_latitude,end_longitude,
        end_latitude,std_id,sf_outer_vehicle_from,src_zone_code,dest_zone_code,uint_fuel,fuel_prices,miles,road_fee,fuel_cost,sum_cost,grd1,grd2,inc_day)
    }).toDF()
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 任务成本明细表 保存至hive
    val cols_recall_cost = spark.sql("""select * from dm_gis.eta_std_line_recall_cost limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_recall_cost.select(cols_recall_cost: _*), Seq("inc_day"), "dm_gis.eta_std_line_recall_cost")

    //计算 成本统计表grd1 和 成本统计表grd2
    val df_grd1 = getEtaStdLineRecallCostGrd(spark, df_recall_cost, dayBefore1,"grd1").withColumnRenamed("grd2_tmp","grd2")
    val df_grd2 = getEtaStdLineRecallCostGrd(spark, df_recall_cost, dayBefore1,"grd2")

    // 成本统计表grd1 保存至hive
    val cols_grd1 = spark.sql("""select * from dm_gis.eta_std_line_recall_cost_grd1 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_grd1.select(cols_grd1: _*), Seq("inc_day"), "dm_gis.eta_std_line_recall_cost_grd1")
    // 成本统计表grd2 保存至hive
    val cols_grd2 = spark.sql("""select * from dm_gis.eta_std_line_recall_cost_grd2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_grd2.select(cols_grd2: _*), Seq("inc_day"), "dm_gis.eta_std_line_recall_cost_grd2")

    df_recall_cost.unpersist()
  }

  case class RecallCost(
                         task_area_code: String,
                         task_id: String,
                         task_subid: String,
                         start_dept: String,
                         end_dept: String,
                         start_outer_add_code: String,
                         end_outer_add_code: String,
                         start_type: String,
                         end_type: String,
                         line_code: String,
                         unitprice: String,
                         vehicle_serial: String,
                         actual_capacity_load: String,
                         actual_depart_tm: String,
                         actual_arrive_tm: String,
                         line_time: String,
                         line_distance: String,
                         actual_run_time: String,
                         is_stop: String,
                         stop_over_zone_code: String,
                         transoport_level: String,
                         carrier_name: String,
                         carrier_type: String,
                         vehicle_type: String,
                         axls_number: String,
                         time: String,
                         rt_dist: Double,
                         highwaymileage: String,
                         toll_charge: String,
                         error_type: String,
                         pns_dist: String,
                         pns_time: String,
                         src: String,
                         conduct_type: String,
                         biz_type: String,
                         start_longitude: String,
                         start_latitude: String,
                         end_longitude: String,
                         end_latitude: String,
                         std_id: String,
                         sf_outer_vehicle_from: String,
                         src_zone_code: String,
                         dest_zone_code: String,
                         uint_fuel: String,
                         fuel_prices: String,
                         miles: Double,
                         road_fee: Double,
                         fuel_cost: String,
                         sum_cost: String,
                         grd1: String,
                         grd2: String,
                         inc_day: String
                       )

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    // 计算任务成本明细表 dim_gis.eta_std_line_recall_cost 和 成本统计表 grd1、grd2
    getEtaStdLineRecallCost(spark, dayBefore1, dayBefore7)

    logger.error("++++++++  任务完成20231016  ++++")

    spark.stop()
  }

}
