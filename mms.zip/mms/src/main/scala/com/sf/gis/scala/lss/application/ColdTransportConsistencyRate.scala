package com.sf.gis.scala.lss.application

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.lss.utils.CommonTools.tranTimeToStrings
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, col, collect_list, concat_ws, count, desc, get_json_object, lit, round, row_number, sort_array, udf, when}
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：冷运一致率指标监控需求V1.0
 *需求描述：冷运收派端丰小冷目前只有收派无路径规划功能，且收派先后顺序受人为等主观因素影响，导致作业时间长、效率低等问题，
 *        现基于AI智能算法以时效为前提为司机规划合理的收派路径，以此达到提时效、降成本的目的，现对效果进行评估，评估指标为一致率。
 *需求方：杨汶铭(ft80006323)
 *开发: 周勇(01390943)
 *任务创建时间：20230508
 *任务id：741464
 **/

object ColdTransportConsistencyRate {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String]) {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取日期
    val dayvar=args(0)
    logger.error("获取计算日期："+dayvar)

    //获取冷运导航串联记录
    val cold_his_org=spark.sql(
      s"""
         |select * from dm_gis.navi_tsp_tw_record
         |where inc_day= '$dayvar'
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)


    //过滤等于3的
    val cold_his=cold_his_org.filter($"status" ===0)
      .withColumn("rank", row_number().over(Window.partitionBy("task_id").orderBy(asc("complete_order"))))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val cold_his3=cold_his_org.filter($"status" =!=0)
      .withColumn("type", lit(""))

      .withColumn("task_id_ct", lit(""))
      .withColumn("tmp_fromto", lit(""))
      .withColumn("from_name_list", lit(""))
      .withColumn("task_group_ct", lit(""))
      .withColumn("group_max", lit(""))
      .withColumn("to_name_cp", lit(""))
      .withColumn("from_name_tmp", lit(""))
      .withColumn("destination0", lit(""))

    //定义时间转换函数
    val tranTimeToStrings_udf=udf(tranTimeToStrings _)

    //kafka数据
    val navi_res=spark.sql(
      s"""
        |select data from dm_gis.gis_eta_navi_query_hive
        |where inc_day= '$dayvar' and data like '%tspTwLog%'
        |""".stripMargin)
      .withColumn("task_id",get_json_object($"data","$.data.tspTwArg.taskId"))
      .withColumn("reqtime",tranTimeToStrings_udf(get_json_object($"data","$.data.tspTwArg.reqTime")))
      .withColumn("destination0",get_json_object($"data","$.data.tspTwResult.path[0].destination"))
      .drop("data")
      .withColumn("rank1", row_number().over(Window.partitionBy("task_id").orderBy(asc("reqtime"))))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //complete_order = 0部分的数据
    val cold_his0=cold_his.filter($"complete_order"===0)
      .join(navi_res,Seq("task_id"),"left")
      .filter($"complete_time">$"reqtime")
      .select("task_id","complete_order","from_name","reqtime","destination0","rank1")
      .withColumn("rank2", row_number().over(Window.partitionBy("task_id","from_name").orderBy(desc("rank1"))))
      .filter($"rank2"===1)
      .withColumn("from_name_tmp",$"from_name")
      .select("task_id","from_name_tmp","destination0")

    //计算task_id数量
    val task_id_ct_df=cold_his.groupBy("task_id")
      .agg(count($"task_id" ) as "task_id_ct")

    //计算task、group数量
    val task_group_ct_df=cold_his.groupBy("task_id","group")
      .agg(count($"inc_day" ) as "task_group_ct",
        concat_ws("|",collect_list($"from_name")) as "from_name_list")

    //取complete_order最大值的记录
    val cold_his_max=cold_his.withColumn("rankmx", row_number().over(Window.partitionBy("task_id").orderBy(desc("complete_order"))))
      .filter($"rankmx"===1)
      .withColumn("group_max",$"group")
      .withColumn("to_name_max",$"to_name")
      .select("task_id","group_max","to_name_max")

    //n-1数据集匹配
    val cold_his_cp=cold_his.withColumn("complete_order",$"complete_order"+1)
      .withColumn("to_name_cp",$"to_name")
      .select("task_id","complete_order","to_name_cp")

    //添加-1行
    val cold_his_cp2=cold_his_cp.filter($"complete_order"===1)
      .withColumn("complete_order",lit(0))
      .join(cold_his0,Seq("task_id"),"left")
      .withColumn("to_name_cp",$"destination0")
      .select("task_id","complete_order","to_name_cp")

    val cold_his_cp3=cold_his_cp2.union(cold_his_cp)

   //结果判断
    val cold_his_res=cold_his.join(task_id_ct_df,Seq("task_id"),"left")
      .join(task_group_ct_df,Seq("task_id","group"),"left")
      .join(cold_his_max,Seq("task_id"),"left")
      .join(cold_his_cp3,Seq("task_id","complete_order"),"left")
      .join(cold_his0,Seq("task_id"),"left")
      //添加辅助列
      .withColumn("tmp_fromto",from_contain_to_udf($"from_name_list",$"to_name_cp"))
      //判断type
      .withColumn("type",
         //task去重等于1
         when($"task_id_ct"===1,"是")
         //complete_order为0特殊情况
        .when($"complete_order"===0 && $"from_name"===$"destination0","是")
        .when($"complete_order"===0 ,"否")
         //task去重大于等于2
           //同一taskid+group下，计数大于1
        .when($"task_group_ct">1 && $"tmp_fromto"==="是" &&  $"to_name_cp"=!="depot","是")
        .when($"task_group_ct">1  &&  $"to_name_cp"==="depot" && $"to_name_max"==="depot"&& $"group"===$"group_max","是")
        .when($"task_group_ct">1  &&  $"to_name_cp"==="depot" ,"否")
        .when($"task_group_ct">1 ,"否")
           //同一taskid+group下，计数为1
           //complete_order不为0
        .when($"complete_order">0 && $"from_name"===$"to_name_cp","是")
        .when($"complete_order">0 ,"否")
           //complete_order为0
        //.when($"complete_order"===0 && $"from_name_tmp"===$"destination0","是")
        //.when($"complete_order"===0 ,"否")
      ) .persist(StorageLevel.MEMORY_AND_DISK)


    //存储表
    val tb_cols = spark.sql("""select * from dm_gis.navi_tsp_tw_record_new limit 0""").schema.map(_.name).map(col)
    val cold_his_res2= cold_his_res.select(tb_cols:_*).union(cold_his3.select(tb_cols:_*))
    writeToHive(spark, cold_his_res2.select(tb_cols:_*), Seq("inc_day"), "dm_gis.navi_tsp_tw_record_new")


    //结果汇总计算
    val cold_his_res_hz=cold_his_res.groupBy("driver_type")
      .agg(count($"type") as "cnt_all",
        count(when($"type"==="是",1).otherwise(null)) as "cnt"
      )
      .withColumn("rate",round($"cnt"/$"cnt_all",6))
      .withColumn("inc_day",lit(dayvar))

    //存储表
    val tb_cols2 = spark.sql("""select * from dm_gis.dm_navi_tsp_tw_record_df limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, cold_his_res_hz.select(tb_cols2:_*), Seq("inc_day"), "dm_gis.dm_navi_tsp_tw_record_df")

    spark.close()
  }

  //判断是否包含to_name
def from_contain_to(x:String,y:String): String ={
    if(x ==null || x.trim =="" || y ==null || y.trim ==""){
      return "否"
    }
    else {
      val x_arr=x.split("[|]")
      if(x_arr.contains(y)){return "是"}
      else{return "否"}
    }
}
   //注册udf函数
  val from_contain_to_udf=udf(from_contain_to _)

}
