package com.sf.gis.scala.lss.lineUpdate

import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.row2Json
import com.sf.gis.scala.lss.lineUpdate.EtaLineAddChangeDetail.runQueryInteface
import com.sf.gis.scala.lss.lineUpdate.EtaLineUpdateResult.runUpdateInteface1
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.NewRankResult
import com.sf.gis.scala.lss.utils.SparkUtils.{writeToHive, writeToHiveNoP}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：826280
 * 任务名称：标准线路打标_10
 */
object EtaLineScoreRank {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  val queryUrl: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"
  val queryAk: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val updateLineFiledUrl = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/operate/updateLineFiled"
  val updateLineFiledAk = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 4000

  def run(spark: SparkSession, dayBefore1: String) = {

    import spark.implicits._
    val add_result_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  repair_stdid as std_id,
         |  plan_time,
         |  score_rank,
         |  reason,
         |  label
         |from
         |  dm_gis.eta_line_add_result
         |where
         |  inc_day = '$dayBefore1'
         |  and repair_status = '0'
         |""".stripMargin
    println("新增线路返回结果表取数sql：")
    println(add_result_sql)
    val df_add_result = spark.sql(add_result_sql).select("linevehicle","task_area_code","std_id","plan_time","score_rank","reason","label")

    val update_result_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  std_id,
         |  plan_time,
         |  score_rank,
         |  reason,
         |  label
         |from
         |  dm_gis.eta_line_update_result
         |where
         |  inc_day = '$dayBefore1'
         |  and repair_status = '0'
         |""".stripMargin
    println("更新线路返回结果表取数sql：")
    println(update_result_sql)
    val df_add_change = spark.sql(update_result_sql).select("linevehicle","task_area_code","std_id","plan_time","score_rank","reason","label")

    // 需运营但未执行线路
    val unexe_sql =
      s"""
         |select
         |  linevehicle,
         |  actual_depart_tm,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude
         |from
         |  dm_gis.eta_line_need_operate_unexe
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("结果表2取数sql：")
    println(unexe_sql)
    val df_unexe = spark.sql(unexe_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("actual_depart_tm"))))
      .filter('rn === 1) // 按 linevehicle 去重
      .drop("rn","actual_depart_tm")

    val df_query = df_add_change
      .union(df_add_result)
      .join(df_unexe,Seq("linevehicle"),"inner")
      .withColumn("coords_tag",lit("2")) // 调Query接口时的入参区分标识

    val invokeCnt = df_query.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "826280", "标准线路打标_10", "对标准线路库的线路重新排序打标", queryUrl, queryAk, invokeCnt, parallelism)
    // 调 QUERY 接口
    val rdd_query = SparkNet.runInterfaceWithAkLimit(spark, df_query.rdd.map(row2Json), runQueryInteface, parallelism, queryAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "  invokeCnt = " + invokeCnt)

    val df_new_rank = rdd_query
      .map(obj=>{
        // 原始字段
        val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
        val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
        val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
        val reason = JSONUtil.getJsonVal(obj, "reason", "")
        val label = JSONUtil.getJsonVal(obj, "label", "")
        val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
        val score_rank = JSONUtil.getJsonVal(obj, "score_rank", "")
        val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
        val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
        val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
        val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")

        // Query 接口返回值
        val std_id_query = JSONUtil.getJsonVal(obj, "std_id_query", "")
        val query_statue = JSONUtil.getJsonVal(obj, "query_statue", "")
        val query_msg = JSONUtil.getJsonVal(obj, "query_msg", "")

        var new_rank1_tag = 99
        if(std_id == std_id_query && std_id_query != "") new_rank1_tag = 11

        (linevehicle,task_area_code,std_id,reason,label,score_rank,plan_time,start_longitude,start_latitude,end_longitude,end_latitude,std_id_query,new_rank1_tag,query_statue,query_msg)
      }).toDF("linevehicle","task_area_code","std_id","reason","label","score_rank","plan_time","start_longitude","start_latitude","end_longitude","end_latitude","std_id_query",
      "new_rank1_tag","query_statue","query_msg")
      // 重新排序生成new_rank1字段
      .withColumn("score_rank",when('score_rank === "-1","999999").otherwise('score_rank))
      .withColumn("order_tag",concat_ws("",'new_rank1_tag,'score_rank))
      .withColumn("new_rank1", row_number().over(Window.partitionBy('linevehicle).orderBy(asc("order_tag"))))
      .withColumn("new_rank1",when('score_rank === "999999",-1).otherwise('new_rank1))
      .withColumn("inc_day",lit(dayBefore1))

    // 待更新数据
    val cols_new_rank = spark.sql("""select * from dm_gis.eta_line_new_rank limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_new_rank.coalesce(50).select(cols_new_rank: _*), Seq("inc_day"), "dm_gis.eta_line_new_rank")

    val invokeCnt_2 = df_new_rank.count()
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "826280", "标准线路打标_10", "对标准线路库的线路重新排序打标", updateLineFiledUrl, updateLineFiledAk, invokeCnt_2, parallelism)
    // 调线路更新接口
    val rdd_update = SparkNet.runInterfaceWithAkLimit(spark, df_new_rank.rdd.map(row2Json), runUpdateInteface1, parallelism, updateLineFiledAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)
    logger.error("httpInvokeId = " + httpInvokeId_2 + "  invokeCnt = " + invokeCnt_2)

    val df_rank_result = rdd_update.map(obj=>{
      val linevehicle = JSONUtil.getJsonVal(obj,"linevehicle","")
      val task_area_code = JSONUtil.getJsonVal(obj,"task_area_code","")
      val std_id = JSONUtil.getJsonVal(obj,"std_id","")
      val std_id_query = JSONUtil.getJsonVal(obj,"std_id_query","")
      val plan_time = JSONUtil.getJsonVal(obj,"plan_time","")
      val label = JSONUtil.getJsonVal(obj,"label","")
      val score_rank = JSONUtil.getJsonVal(obj,"score_rank","")
      val new_rank1 = JSONUtil.getJsonVal(obj,"new_rank1","")
      val reason = JSONUtil.getJsonVal(obj,"reason","")

      // 接口返回值
      val repair_status = JSONUtil.getJsonVal(obj,"repair_status","")
      val repair_code = JSONUtil.getJsonVal(obj,"repair_code","")
      val repair_info = JSONUtil.getJsonVal(obj,"repair_info","")
      val repair_err = JSONUtil.getJsonVal(obj,"repair_err","")
      val repair_msg = JSONUtil.getJsonVal(obj,"repair_msg","")
      val repair_stdid = JSONUtil.getJsonVal(obj,"repair_stdid","")
      val inc_day = JSONUtil.getJsonVal(obj,"inc_day","")

      NewRankResult(linevehicle,task_area_code,std_id,plan_time,std_id_query,label,score_rank,new_rank1,reason,repair_status,repair_code,
        repair_info,repair_err,repair_msg,repair_stdid,inc_day)
    }).toDF()

    // 更新结果
    val cols_rank_result = spark.sql("""select * from dm_gis.eta_line_new_rank_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_rank_result.coalesce(50).select(cols_rank_result: _*), Seq("inc_day"), "dm_gis.eta_line_new_rank_result")
  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
