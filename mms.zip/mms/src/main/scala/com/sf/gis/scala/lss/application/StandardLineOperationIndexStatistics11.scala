package com.sf.gis.scala.lss.application

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.lss.utils.Functions.getDateDiff
import com.sf.gis.scala.lss.utils.SparkUtils.{df2HiveByOverwrite, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, IntegerType}
import org.apache.spark.storage.StorageLevel

import java.security.MessageDigest
import scala.collection.mutable.ArrayBuffer


/**
 * 标准线路运营指标体系搭建，标准线路运营报表部分
 * 需求方：周思毅（01399920）
 * @author 徐游飞（01417347）
 * 任务信息：451447（标准线路运营指标体系搭建v1.0，天任务，每天10:00执行）
 * 上游依赖：366280,429725,372536,398430,表3,表4,471560,表8,自依赖
 */
object StandardLineOperationIndexStatistics11 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {
    // incDay 为业务时间，即跑数当天时间
    val incDay = args(0)
    val DayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val DayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val DayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)
    val DayBefore30 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 30)
    val MouthBefore1 = DateUtil.getMouthBefore(DayBefore1, 1)

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    spark.udf.register("MD5UDF",(input:String)=>{
      // 指定MD5加密算法
      val md5 = MessageDigest.getInstance("MD5")
      //进行随机哈希
      val encoded = md5.digest(input.getBytes)
      //转十六进制
      encoded.map("%02x".format(_)).mkString
    })

    // 此表于20230103确认下线
//    logger.error("++++++++  开始计算标准线路业务调用情况每日统计表  ++++  表1  ++++")
//    gisEtaStdlineResultDaily(spark,DayBefore1)

    logger.error("++++++++  开始计算线路运营模式表  ++++  表3  ++++")
    etaGrdLineidCarrierType(spark,incDay,DayBefore1,MouthBefore1)

    logger.error("++++++++  开始计算里程提报基础明细表  ++++  表4  ++++")
    exceptionReportDetail(spark,DayBefore1)

    logger.error("++++++++  开始计算里程提报统计表  ++++  表5  ++++")
    exceptionReportDetailDaily(spark,incDay,DayBefore1)

    logger.error("++++++++  开始计算准点情况统计表  ++++  表6  ++++")
    lineRecallDaily(spark,DayBefore1,DayBefore7)

    logger.error("++++++++  开始计算调用记录统计表  ++++  表8  ++++")
    lineStdidInfo(spark,incDay,DayBefore1,DayBefore7,DayBefore30)

    logger.error("++++++++  开始计算历史累计使用情况统计表  ++++  表9  ++++")
    lineStdidInfoSum(spark,incDay,DayBefore1,DayBefore2)

    logger.error("++++++++  开始计算标准线路标签统计表  ++++  表10  ++++")
    etaStdLineStdidLableInfo(spark,DayBefore1,DayBefore7,incDay)

    logger.error("++++++++  开始计算历史标准线路标签统计表  ++++  表11 && 表12  ++++")
    etaStdLineStdidLableInfo1(spark,DayBefore1,incDay)

    spark.stop()
  }

  /**
   * (表1)
   * 标准线路业务调用情况每日统计表 dm_gis.gis_eta_stdline_result_daily
   * @param spark
   * @param DayBefore1
   */
  def gisEtaStdlineResultDaily(spark: SparkSession, DayBefore1: String) = {
    val stdline_querySql =
      s"""
         |insert overwrite table dm_gis.gis_eta_stdline_result_daily partition (inc_day='$DayBefore1')
         |select
         |  MD5UDF(CONCAT(nvl(t1.line_code,rand(5)),$DayBefore1,rand(10))) as md5_id,
         |  t1.line_code,
         |  t1.src_zonecode as start_dept,
         |  t1.dest_zonecode as end_dept,
         |  t1.req_num,
         |  t1.return_num,
         |  t1.non_std_num,
         |  t1.econ0_num,
         |  t1.econ1_num,
         |  t1.econ2_num,
         |  t1.econ3_num,
         |  t1.econ4_num,
         |  t1.econ5_num,
         |  t1.econ6_num,
         |  t1.econ7_num,
         |  t1.use_num,
         |  t1.add_num,
         |  t2.all_std_num
         |from(
         |    select
         |	    "a" as mark,
         |      line_code,
         |      src_zonecode,
         |      dest_zonecode,
         |      count(1) as req_num,
         |      count(if(pns_dist <> '', 1, null)) as return_num,
         |      count(if(pns_dist <> '' and std_id = '',1,null)) as non_std_num,
         |      count(if(src = '0', 1, null)) as econ0_num,
         |      count(if(src = '1', 1, null)) as econ1_num,
         |      count(if(src = '2', 1, null)) as econ2_num,
         |      count(if(src = '3', 1, null)) as econ3_num,
         |      count(if(src = '4', 1, null)) as econ4_num,
         |      count(if(src = '5', 1, null)) as econ5_num,
         |      count(if(src = '6', 1, null)) as econ6_num,
         |      count(if(src = '7', 1, null)) as econ7_num,
         |      count(distinct if(std_id <> '', std_id, null)) as use_num,
         |      count(if(abs(unix_timestamp(regexp_replace(date_time, '-', ''),'yyyyMMdd HH:mm:ss') - unix_timestamp(regexp_replace(line_creattime, '-', ''),'yyyyMMdd HH:mm:ss')) < 600,1,null)) as add_num
         |    from
         |      dm_gis.gis_eta_stdline_result_parse
         |    where
         |      inc_day = '$DayBefore1'
         |      and ak = '01b136b4864ae489be25c900c2c4c871'
         |      and opt = 'std2'
         |      and x1 <> ''
         |      and y1 <> ''
         |      and x2 <> ''
         |      and y2 <> ''
         |      and src_zonecode <> ''
         |      and dest_zonecode <> ''
         |    group by
         |      line_code,
         |      src_zonecode,
         |      dest_zonecode
         |  ) t1
         |  left join(
         |    select
         |      "a" as mark,
         |      count(1) as all_std_num
         |    from
         |      dm_gis.eta_std_line_conf
         |    where
         |      delete_flag = '0'
         |  ) t2 on t1.mark = t2.mark
         |""".stripMargin

    println(stdline_querySql)
    spark.sql(stdline_querySql)
    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表1数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表3)
   * 线路运营模式表  dm_gis.eta_grd_lineid_carrier_type
   * @param spark
   * @param incDay
   * @param DayBefore1
   * @param MouthBefore1
   * @return
   */
  def etaGrdLineidCarrierType(spark: SparkSession, incDay: String, DayBefore1: String, MouthBefore1: String) = {
    val carrier_querySql =
      s"""
         |insert overwrite table dm_gis.eta_grd_lineid_carrier_type partition (inc_day='$incDay')
         |select
         |  MD5UDF(CONCAT(nvl(line_code,rand(5)),$DayBefore1,rand(8))) as md5_id,
         |  line_code,
         |  start_dept,
         |  end_dept,
         |  date_range,
         |  zy_num,
         |  wb_num,
         |  case
         |    when zy_num > '0' and wb_num = '0' then '0'
         |    when zy_num = '0' and wb_num > '0' then '1'
         |    when zy_num > '0' and wb_num > '0' then '2'
         |    else '3'
         |  end new_carrier_type
         |from(
         |    select
         |      line_code,
         |      start_dept,
         |      end_dept,
         |      concat_ws("-", '$MouthBefore1', '$DayBefore1') as date_range,
         |      count(if(carrier_type = '0', 1, null)) as zy_num,
         |      count(if(carrier_type <> '0', 1, null)) as wb_num
         |    from
         |      dm_gis.eta_std_line_recall_result
         |    where
         |      inc_day >= '$MouthBefore1'
         |      and inc_day <= '$DayBefore1'
         |    group by
         |      line_code,
         |      start_dept,
         |      end_dept
         |  ) t1
         |""".stripMargin

    println(carrier_querySql)
    spark.sql(carrier_querySql)
    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表3数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表4)
   * 里程提报基础明细表 dm_gis.exception_report_detail
   * @param spark
   * @param DayBefore1
   * @return
   */
  def exceptionReportDetail(spark: SparkSession, DayBefore1: String) = {
    val report_querySql =
      s"""
         |insert overwrite table dm_gis.exception_report_detail partition (inc_day='$DayBefore1')
         |select
         |  MD5UDF(CONCAT(nvl(t1.id,rand(5)),$DayBefore1,rand(7))) as md5_id,
         |  substr(t1.id,0,30) as id,
         |  t1.report_login_name,
         |  t1.report_time,
         |  t1.start_dept,
         |  t1.end_dept,
         |  t1.line_code,
         |  t1.plan_depart_tm,
         |  t1.operation_reason,
         |  t1.detail_reason,
         |  t1.supplement,
         |  t1.state,
         |  t1.task_area_code,
         |  t1.sys_verify_result,
         |  t1.is_userable,
         |  t1.line_type,
         |  t1.src,
         |  t1.vehicle,
         |  t1.mark,
         |  t2.audit_result,
         |  t2.audit_login_name,
         |  t2.audit_time,
         |  t2.confirm_login_name,
         |  t2.confirm_result,
         |  t2.confirm_time,
         |  t2.loc_qt_result,
         |  t2.qt_login_name,
         |  t2.qt_time,
         |  t2.is_push,
         |  t2.push_type,
         |  t3.new_carrier_type as carrier_type
         |from(
         |    select
         |      id,
         |      report_login_name,
         |      report_time,
         |      start_dept,
         |      end_dept,
         |      line_code,
         |      plan_depart_tm,
         |      operation_reason,
         |      detail_reason,
         |      supplement,
         |      state,
         |      task_area_code,
         |      sys_verify_result,
         |      is_userable,
         |      line_type,
         |      src,
         |      vehicle,
         |      mark
         |    from
         |      dm_gis.exception_report_trail
         |    where
         |      inc_day = '$DayBefore1'
         |      and state in(1,2,3,4,5,6,7,21)
         |  ) t1
         |  left join(
         |    select
         |      report_id,
         |      audit_result,
         |      audit_login_name,
         |      audit_time,
         |      confirm_login_name,
         |      confirm_result,
         |      confirm_time,
         |      loc_qt_result,
         |      qt_login_name,
         |      qt_time,
         |      is_push,
         |      push_type
         |    from
         |      dm_gis.exception_report_line_result
         |    where
         |      inc_day = '$DayBefore1'
         |  ) t2 on t1.id = t2.report_id
         |  left join(
         |    select
         |      line_code,
         |      start_dept,
         |      end_dept,
         |      new_carrier_type
         |    from
         |      dm_gis.eta_grd_lineid_carrier_type
         |    where
         |      inc_day = '$DayBefore1'
         |  ) t3 on t1.line_code = t3.line_code
         |  and t1.start_dept = t3.start_dept
         |  and t1.end_dept = t3.end_dept
         |""".stripMargin

    println(report_querySql)
    spark.sql(report_querySql)
    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表4数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表5)
   * 里程提报统计表  dm_gis.exception_report_detail_daily
   * @param spark
   * @param incDay
   * @param DayBefore1
   */
  def exceptionReportDetailDaily(spark: SparkSession, incDay: String, DayBefore1: String) = {
    val daily_querySql =
      s"""
         |insert overwrite table dm_gis.exception_report_detail_daily partition (inc_day='$DayBefore1')
         |select
         |  MD5UDF(CONCAT(nvl(line_code,rand(5)),$DayBefore1,rand(6))) as md5_id,
         |  task_area_code,
         |  task_area_name,
         |  line_code,
         |  start_dept,
         |  end_dept,
         |  vehicle,
         |  report_date,
         |  carrier_type,
         |  state,
         |  report_type,
         |  count(1) as report_num,
         |  count(if(state = '6', 1, null)) as report_finished,
         |  count(if(push_type = '1' or push_type = '3', 1, null)) as report_pass,
         |  count(if(state <> '6', 1, null)) as report_stay,
         |  count(if(sys_verify_result = '1' or sys_verify_result = '2', 1, null)) as sys_verify_num,
         |  count(if(sys_verify_result = '1', 1, null)) as sys_verify_pass_num,
         |  count(if(state = '1', 1, null)) as limit_verify_stay_num,
         |  count(if(audit_result = '1' or audit_result = '2', 1, null)) as limit_verify_num,
         |  count(if(audit_result = '1', 1, null)) as limit_verify_pass_num,
         |  count(if(mark = '1' or mark = '2', 1, null)) as au_confirm_num,
         |  count(if(mark = '1', 1, null)) as au_confirm_pass_num,
         |  count(if(confirm_result = '1' or confirm_result = '2', 1, null)) as confirm_num,
         |  count(if(confirm_result = '1', 1, null)) as confirm_pass_num,
         |  count(if(state = '21', 1, null)) as confirm_stay_num,
         |  count(if(loc_qt_result = '1' or loc_qt_result = '2', 1, null)) as loc_qt_num,
         |  count(if(state = '4', 1, null)) as loc_qt_stay_num,
         |  count(if(loc_qt_result = '1', 1, null)) as loc_qt_pass_num,
         |  count(if(operation_reason = '1', 1, null)) as ope_reason1,
         |  count(if(operation_reason = '2', 1, null)) as ope_reason2,
         |  count(if(operation_reason = '3', 1, null)) as ope_reason3,
         |  count(if(operation_reason = '4', 1, null)) as ope_reason4,
         |  count(if(operation_reason = '5', 1, null)) as ope_reason5,
         |  count(if(operation_reason = '6', 1, null)) as ope_reason6,
         |  count(if(operation_reason = '7', 1, null)) as ope_reason7,
         |  count(if(operation_reason = '8', 1, null)) as ope_reason8,
         |  count(if(operation_reason = '9', 1, null)) as ope_reason9,
         |  count(if(operation_reason = '10', 1, null)) as ope_reason10
         |from
         |  (
         |    select
         |      task_area_code,
         |      line_code,
         |      start_dept,
         |      end_dept,
         |      vehicle,
         |      from_unixtime(unix_timestamp(regexp_replace(report_time, '-', ''),'yyyyMMdd HH:mm:ss'),'yyyyMMdd') as report_date,
         |      carrier_type,
         |      state,
         |      push_type,
         |	    sys_verify_result,
         |	    audit_result,
         |	    mark,
         |	    confirm_result,
         |	    loc_qt_result,
         |	    operation_reason,
         |	    case
         |        operation_reason
         |        when '5' then '里程问题'
         |        else '线路问题'
         |      end as report_type
         |    from
         |      dm_gis.exception_report_detail
         |    where
         |      inc_day = '$DayBefore1'
         |  ) t1
         |  left join (
         |    select
         |      area_code as code,
         |      area_name as task_area_name
         |    from
         |      dm_gis.dim_area_code_mapping
         |    union all
         |    select
         |      express_code as code,
         |      area_name as task_area_name
         |    from
         |      dm_gis.dim_area_code_mapping
         |  ) t2 on t1.task_area_code = t2.code
         |group by
         |  task_area_code,
         |  task_area_name,
         |  line_code,
         |  start_dept,
         |  end_dept,
         |  vehicle,
         |  report_date,
         |  carrier_type,
         |  state,
         |  report_type
         |""".stripMargin

    println(daily_querySql)
    spark.sql(daily_querySql)
    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表5数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表6)
   * 准点情况统计统计表 dm_gis.eta_std_line_task_ontime
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   */
  def lineRecallDaily(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {
    // 获取任务明细表数据
    val querySql =
      s"""
         |select
         |  task_id,
         |  last_update_tm,
         |  task_area_code,
         |  if(actual_run_time - 1 <= line_time, 1, 0) as ac_is_run_ontime,
         |  transoport_level,
         |  carrier_type,
         |  inc_day as inc_day2
         |from
         |  dm_gis.eta_std_line_recall_result2
         |where
         |  inc_day >= '$DayBefore7'
         |  and inc_day <= '$DayBefore1'
         |  and if_evaluate_time = 1
         |""".stripMargin

    println(querySql)

    import spark.implicits._
    val taskOntimeDF = spark.sql(querySql)
      .withColumn("rn",row_number().over(Window.partitionBy("task_id").orderBy(desc("last_update_tm"))))
      .filter('rn === 1)
      .groupBy("task_area_code","inc_day2")
      .agg(
        count("task_id") as "task_num",
        count(when('ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num",

        count(when('transoport_level === 1, 1).otherwise(null)) as "task_num_level1",
        count(when('transoport_level === 2, 1).otherwise(null)) as "task_num_level2",
        count(when('transoport_level === 3, 1).otherwise(null)) as "task_num_level3",
        count(when('transoport_level === 1 or 'transoport_level === 2, 1).otherwise(null)) as "task_num_trunk",

        count(when('transoport_level === 1 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_level1",
        count(when('transoport_level === 2 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_level2",
        count(when('transoport_level === 3 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_level3",
        count(when(('transoport_level === 1 or 'transoport_level === 2) and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_trunk",

        count(when('carrier_type === 0, 1).otherwise(null)) as "task_num_zy",
        count(when('carrier_type === 0 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_zy",
        count(when('carrier_type =!= 0, 1).otherwise(null)) as "task_num_wb",
        count(when('carrier_type =!= 0 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num_wb"
      )
      .withColumn("ontime_rate", round('ontime_num / 'task_num,4))
      .withColumn("ontime_rate_level1", round('ontime_num_level1 / 'task_num_level1,4))
      .withColumn("ontime_rate_level2", round('ontime_num_level2 / 'task_num_level2,4))
      .withColumn("ontime_rate_level3", round('ontime_num_level3 / 'task_num_level3,4))
      .withColumn("ontime_rate_trunk", round('ontime_num_trunk / 'task_num_trunk,4))

      .withColumn("ontime_rate_zy", round('ontime_num_zy / 'task_num_zy,4))
      .withColumn("ontime_rate_wb", round('ontime_num_wb / 'task_num_wb,4))
      .withColumn("md5_id",md5(concat(rand(10),'task_area_code,'inc_day2)))
      .withColumn("inc_day",'inc_day2)
      .drop("inc_day2")

    taskOntimeDF.printSchema()
    df2HiveByOverwrite(logger,taskOntimeDF,"dm_gis.eta_std_line_task_ontime")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表6数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表8)
   * 调用记录统计表 dm_gis.eta_std_line_stdid_info
   * @param spark
   * @param incDay
   * @param DayBefore1
   * @param DayBefore7
   * @param DayBefore30
   */
  def lineStdidInfo(spark: SparkSession,incDay: String,DayBefore1: String,DayBefore7: String,DayBefore30: String) = {
    // 获取全量配置表数据
    val line_conf_Sql =
      s"""
         |select
         |  std_id,
         |  delete_flag,
         |  create_time,
         |  update_time,
         |  opt_user,
         |  add_reason,
         |  delete_reason,
         |  is_econ
         |from
         |  dm_gis.eta_std_line_conf
         |""".stripMargin

    val line_vms_Sql =
      s"""
         |select
         |  std_id,
         |  conduct_type,
         |  actual_depart_tm,
         |  inc_day,
         |  ac_is_run_ontime,
         |  actual_run_time,
         |  error_type,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  carrier_type
         |from
         |  dm_gis.eta_std_line_recall_vms
         |where
         |  inc_day >= '$DayBefore30'
         |  and inc_day <= '$DayBefore1'
         |  and error_type = '0'
         |""".stripMargin

    println(line_conf_Sql)
    println(line_vms_Sql)
    val line_conf_df = spark.sql(line_conf_Sql)
    val line_vms_df = spark.sql(line_vms_Sql)

    import spark.implicits._
    val info_tmp_df = line_vms_df
      .groupBy("std_id")
      .agg(
        max(when('conduct_type === 1,'actual_depart_tm).otherwise(null)) as "last_execute_time",
        max('actual_depart_tm) as "last_use_time",
        count(when('inc_day >= DayBefore7 and 'conduct_type === 1,1).otherwise(null)) as "last_week_execute_num",
        count(when('inc_day >= DayBefore7,1).otherwise(null)) as "last_week_use_num",
        count(when('inc_day >= DayBefore7 and 'ac_is_run_ontime === 1,1).otherwise(null)) as "ontime_num7",
        count(when('inc_day >= DayBefore7 and 'conduct_type === 1 and 'ac_is_run_ontime === 1,1).otherwise(null)) as "execute_ontime_num7",
        count(when('inc_day >= DayBefore7 and 'conduct_type =!= 1 and 'ac_is_run_ontime === 1,1).otherwise(null)) as "unexecute_ontime_num7",
        count(when('conduct_type === 1,1).otherwise(null)) as "execute_num",
        count('std_id) as "use_num",
        count(when('ac_is_run_ontime === 1,1).otherwise(null)) as "ontime_num",
        count(when('conduct_type === 1 and 'ac_is_run_ontime === 1,1).otherwise(null)) as "execute_ontime_num",
        avg(when('actual_run_time.isNotNull and 'actual_run_time =!= 0 and 'conduct_type === 1,'actual_run_time).otherwise(null)) as "execute_time_avg",
        avg(when('actual_run_time.isNotNull and 'actual_run_time =!= 0 and 'conduct_type =!= 1,'actual_run_time).otherwise(null)) as "unexecute_time_avg",
        avg(when('error_type === 0 and 'conduct_type === 1,'rt_dist).otherwise(null)) as "execute_dist_avg",
        avg(when('error_type === 0 and 'conduct_type =!= 1,'rt_dist).otherwise(null)) as "unexecute_dist_avg",
        avg(when('conduct_type === 1,'highwaymileage).otherwise(null)) as "execute_highway_avg",
        avg(when('conduct_type =!= 1,'highwaymileage).otherwise(null)) as "unexecute_highway_avg",
        avg(when('conduct_type === 1,'toll_charge).otherwise(null)) as "execute_road_fee_avg",
        avg(when('conduct_type =!= 1,'toll_charge).otherwise(null)) as "unexecute_road_fee_avg",

        avg(when('conduct_type === 1 and 'toll_charge.isNotNull and 'toll_charge =!= "",'toll_charge).otherwise(null)) as "roadfee_std",
        avg(when('conduct_type === 1 and 'actual_run_time.isNotNull and 'actual_run_time =!= "" and 'actual_run_time =!= 0,'actual_run_time).otherwise(null)) as "time_std",
        avg(when('conduct_type === 1 and 'rt_dist.isNotNull and 'rt_dist =!= "" and 'rt_dist =!= 0,'rt_dist).otherwise(null)) as "dist_std",

        // v2.6新增字段 20230814
        concat_ws("|",collect_set('carrier_type)) as "carrier_type"
      )
      .withColumn("time_diff",when('execute_time_avg.isNull or 'unexecute_time_avg.isNull,"").otherwise(round('execute_time_avg - 'unexecute_time_avg,4)))
      .withColumn("dist_diff",when('execute_dist_avg.isNull or 'unexecute_dist_avg.isNull,"").otherwise(round('execute_dist_avg - 'unexecute_dist_avg,4)))
      .withColumn("highway_diff",round('execute_highway_avg - 'unexecute_highway_avg,4))
      .withColumn("roadfee_diff",round('execute_road_fee_avg - 'unexecute_road_fee_avg,4))
      .withColumn("ontime_diff",when('use_num === 'execute_num or 'execute_num === 0,"").otherwise(round(('execute_ontime_num / 'execute_num) - (('ontime_num - 'execute_ontime_num) / ('use_num - 'execute_num)),4)))
      .withColumn("carrier_type",when('carrier_type === "0","自营").when(!'carrier_type.contains("0"),"外包").otherwise("自营&外包"))

    val stdid_info_tmp = info_tmp_df
      .join(line_conf_df,Seq("std_id"),"left")
      .na.fill("")
      .withColumn("keep_time",when('delete_flag === 0,"").otherwise(getDateDiff('update_time,'create_time,lit("yyyy-MM-dd HH:mm:ss"),lit(2))))
      // 以下为需求V1.8新增字段
      .withColumn("label_ontime_rate",('execute_ontime_num / 'execute_num).cast(DoubleType))
      .withColumn("roadfee_diff_abs",round(abs('roadfee_diff),2))
      .withColumn("time_diff_abs",round(abs('time_diff.cast(DoubleType)),2))
      .withColumn("dist_diff_abs",round(abs('dist_diff.cast(DoubleType))/1000,2))
      .withColumn("label_exe_rate",('execute_num / 'use_num).cast(DoubleType))
      .withColumn("label_ontime",when(('use_num > 5 and 'label_ontime_rate >= 0.9) or ('use_num >= 3 and 'use_num <= 5 and 'label_ontime_rate === 1.0),concatField(lit("准点率高"),'label_ontime_rate))
        .when(('use_num > 5 and 'label_ontime_rate >= 0.5 and 'label_ontime_rate < 0.9) or ('use_num >= 3 and 'use_num <= 5 and 'label_ontime_rate >= 0.6 and 'label_ontime_rate < 1.0),concatField(lit("无准点标签"),'label_ontime_rate))
        .when(('use_num > 5 and 'label_ontime_rate < 0.5) or ('use_num >= 3 and 'use_num <= 5 and 'label_ontime_rate < 0.6),concatField(lit("准点率低"),'label_ontime_rate)))
      .withColumn("label_fee",when('use_num >= 3 and ('roadfee_diff > 2 and ('roadfee_diff / 'roadfee_std) > 0.05),concat_ws("_",lit("路桥费高"),'roadfee_diff_abs,lit("-1")))
        .when('use_num >= 3 and ('roadfee_diff < -2 and ('roadfee_diff / 'roadfee_std) < -0.05),concat_ws("_",lit("路桥费低"),'roadfee_diff_abs,lit("1")))
        .otherwise("null_null_0"))
      .withColumn("label_time",when('use_num >= 3 and ('time_diff.isNull or 'time_diff === "" or ('time_diff.cast(DoubleType) >= -5 and 'time_diff.cast(DoubleType) <= 5) or (('time_diff.cast(DoubleType) / 'time_std) >= -0.05 and ('time_diff.cast(DoubleType) / 'time_std) <= 0.05)),"null_null_0")
        .when('use_num >= 3 and (('time_diff.cast(DoubleType) / 'time_std) > 0.05 and 'time_diff.cast(DoubleType) > 5),concat_ws("_",lit("时长长"),'time_diff_abs,lit("-1")))
        .when('use_num >= 3 and (('time_diff.cast(DoubleType) / 'time_std) < -0.05 and 'time_diff.cast(DoubleType) < -5),concat_ws("_",lit("时长短"),'time_diff_abs,lit("1")))
        .otherwise("null_null_0"))
      .withColumn("label_dist",when('use_num >= 3 and ('dist_diff.isNull or 'dist_diff === "" or (('dist_diff.cast(DoubleType) >= -5000 and 'dist_diff.cast(DoubleType) <= 5000) and (('dist_diff.cast(DoubleType) / 'dist_std) >= -0.05 and ('dist_diff.cast(DoubleType) / 'dist_std) <= 0.05))),"null_null_0")
        .when('use_num >= 3 and (('dist_diff.cast(DoubleType) / 'dist_std) > 0.05 or 'dist_diff > 5000),concat_ws("_",lit("里程长"),'dist_diff_abs,lit("-1")))
        .when('use_num >= 3 and (('dist_diff.cast(DoubleType) / 'dist_std) < -0.05 or 'dist_diff < -5000),concat_ws("_",lit("里程短"),'dist_diff_abs,lit("1")))
        .otherwise("null_null_0"))
      .withColumn("label_exe",when(('use_num > 5 and 'label_exe_rate >= 0.8) or ('use_num >= 3 and 'use_num <= 5 and 'label_exe_rate === 1.0),concatField(lit("高执行率"),'label_exe_rate))
        .when(('use_num > 5 and 'label_exe_rate >= 0.5 and 'label_exe_rate < 0.8) or ('use_num >= 3 and 'use_num <= 5 and 'label_exe_rate >= 0.6 and 'label_exe_rate < 1.0),concatField(lit("无执行率"),'label_exe_rate))
        .when(('use_num > 5 and 'label_exe_rate < 0.5) or ('use_num >= 3 and 'use_num <= 5 and 'label_exe_rate < 0.6),concatField(lit("低执行率"),'label_exe_rate)))
      .withColumn("label_lamp",lit(""))
      .withColumn("label_pos",collectLabels('label_ontime,'label_fee,'label_time,'label_dist,'label_exe,lit("pos")))
      .withColumn("lable_neg",collectLabels('label_ontime,'label_fee,'label_time,'label_dist,'label_exe,lit("neg")))
      .persist(StorageLevel.MEMORY_AND_DISK)

    stdid_info_tmp.show(2,true)

      // V2.1新增字段8个
    val stdid_info_df = stdid_info_tmp
      .withColumn("exe_point",when('use_num === 0 or 'label_exe.isNull, 0).otherwise('execute_num / 'use_num * 40))
      .withColumn("ontime_point", when('execute_num === 0 or 'label_ontime.isNull, 0).otherwise('execute_ontime_num / 'execute_num * 30))
      .withColumn("dist_point",when('label_dist.contains("里程长"),0)
        .when('label_dist.contains("null_null_0"),7.5)
        .when('label_dist.contains("里程短"),15))
      .withColumn("time_point",when('label_time.contains("时长长"),0)
        .when('label_time.contains("null_null_0"),7.5)
        .when('label_time.contains("时长短"),15))
      .withColumn("sum_point",'exe_point + 'ontime_point + 'dist_point + 'time_point)
      .withColumn("quality_type",when('use_num < 3,"任务数不足线路")
        .when('sum_point <= 50,"低质量线路")
        .when('sum_point > 50 and 'sum_point <= 70,"普通线路")
        .when('sum_point > 70,"高质量线路"))
      .withColumn("md5_id", md5(concat('std_id,lit(incDay),rand(10))))
      .withColumn("inc_day",lit(incDay))

    val res_cols = spark.sql("select * from dm_gis.eta_std_line_stdid_info limit 0").schema.map(_.name).map(col)
    df2HiveByOverwrite(logger, stdid_info_df.select(res_cols: _*), "dm_gis.eta_std_line_stdid_info")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表8数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表9)
   * 历史累计使用情况统计表  dm_gis.eta_std_line_stdid_info_sum
   * @param spark
   * @param incDay
   * @param DayBefore1
   * @param DayBefore2
   */
  def lineStdidInfoSum(spark: SparkSession, incDay: String, DayBefore1: String, DayBefore2: String) = {
    val line_vms_Sql =
      s"""
         |select
         |  std_id,
         |  conduct_type,
         |  actual_depart_tm,
         |  inc_day,
         |  ac_is_run_ontime,
         |  actual_run_time,
         |  error_type,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge
         |from
         |  dm_gis.eta_std_line_recall_vms
         |where
         |  inc_day = '$DayBefore1'
         |""".stripMargin

    val info_sum_Sql =
      s"""
         |select
         |  std_id,
         |  his_execute_num,
         |  his_use_num
         |from
         |  dm_gis.eta_std_line_stdid_info_sum
         |where
         |  inc_day = '$DayBefore1'
         |""".stripMargin

    println(line_vms_Sql)
    println(info_sum_Sql)
    val line_vms_df = spark.sql(line_vms_Sql)
    val info_sum_df = spark.sql(info_sum_Sql)

    import spark.implicits._
    val info_tmp_df = line_vms_df
      .groupBy("std_id")
      .agg(
        count(when('conduct_type === 1,1).otherwise(null)) as "daily_execute_num",
        count('std_id) as "daily_use_num"
      )
    val info_sum_result_df = info_tmp_df
      .join(info_sum_df,Seq("std_id"),"full")
      .withColumn("daily_execute_num",when('daily_execute_num.isNotNull,'daily_execute_num).otherwise(0))
      .withColumn("daily_use_num",when('daily_use_num.isNotNull,'daily_use_num).otherwise(0))
      .withColumn("his_execute_num",when('his_execute_num.isNotNull,('his_execute_num + 'daily_execute_num).cast(IntegerType)).otherwise('daily_execute_num))
      .withColumn("his_use_num",when('his_use_num.isNotNull,('his_use_num + 'daily_use_num).cast(IntegerType)).otherwise('daily_use_num))
      .withColumn("md5_id", md5(concat('std_id,lit(incDay),rand(10))))
      .withColumn("inc_day",lit(incDay))

    info_sum_result_df.printSchema()
    val res_cols = spark.sql("select * from dm_gis.eta_std_line_stdid_info_sum limit 0").schema.map(_.name).map(col)
    df2HiveByOverwrite(logger, info_sum_result_df.select(res_cols: _*), "dm_gis.eta_std_line_stdid_info_sum")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表9数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表10)
   * 标准线路标签统计表  dm_gis.eta_std_line_stdid_lable_info
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   * @param MouthBefore1
   */
  def etaStdLineStdidLableInfo(spark: SparkSession, DayBefore1: String, DayBefore7: String, incDay: String) = {
    val line_conf_querySql =
      s"""
         |select
         |  $incDay as inc_day,
         |  count(distinct std_id) as std_sum,
         |  count(distinct(if(delete_flag = '0', std_id, null))) as std_sum_valid
         |from
         |  dm_gis.eta_std_line_conf
         |""".stripMargin

    println(line_conf_querySql)
    val df_line_conf = spark.sql(line_conf_querySql)

    val stdid_info_querySql =
      s"""
         |select
         |  $incDay as inc_day,
         |  count(distinct(if(substr(label_exe,1,4) = '高执行率',std_id,null))) as label_exe,
         |  count(distinct(if(substr(label_exe,1,4) = '低执行率',std_id,null))) as label_exe_lows,
         |  count(distinct(if(label_exe = '高执行率_100.00%',std_id,null))) as label_exe_100,
         |  count(distinct(if(label_exe = '低执行率_0.00%',std_id,null))) as label_exe_0,
         |  count(distinct(if(substr(label_ontime,1,4) = '准点率高',std_id,null))) as label_ontime,
         |  count(distinct(if(substr(label_ontime,1,4) = '准点率低',std_id,null))) as label_ontime_lows,
         |  count(distinct(if(substr(label_time,1,3) = '时长短',std_id,null))) as time_std,
         |  count(distinct(if(substr(label_time,1,3) = '时长长',std_id,null))) as time_long_std,
         |  count(distinct(if(substr(label_fee,1,4) = '路桥费低',std_id,null))) as label_fee,
         |  count(distinct(if(substr(label_fee,1,4) = '路桥费高',std_id,null))) as label_fee_high,
         |  count(distinct(if(substr(label_dist,1,3) = '里程短',std_id,null))) as label_dist,
         |  count(distinct(if(substr(label_dist,1,3) = '里程长',std_id,null))) as label_dist_long,
         |  count(distinct(if(use_num > 2,std_id,null))) as month_num,
         |  count(distinct(if(use_num > 2 and last_week_use_num > 0,std_id,null))) as week_num,
         |  count(distinct std_id) as month_num_1,
         |  count(distinct(if(last_week_use_num > 0,std_id,null))) as week_num_1,
         |  count(distinct(if(quality_type = '高质量线路',std_id,null))) as line_high,
         |  count(distinct(if(quality_type = '普通线路',std_id,null))) as line_general,
         |  count(distinct(if(quality_type = '低质量线路',std_id,null))) as line_low
         |from
         |  dm_gis.eta_std_line_stdid_info
         |where
         |  inc_day = '$incDay'
         |""".stripMargin

    println(stdid_info_querySql)
    val df_stdid_info = spark.sql(stdid_info_querySql)

    import spark.implicits._
    val df_lable = df_line_conf
      .join(df_stdid_info, Seq("inc_day"), "left")
      .withColumn("std_sum_valid_p",doubleToPercent('std_sum_valid / 'std_sum))
      .withColumn("month_num_p",doubleToPercent('month_num / 'std_sum_valid))
      .withColumn("week_num_p",doubleToPercent('week_num / 'std_sum_valid))
      .withColumn("label_exe_p",doubleToPercent('label_exe / 'month_num))
      .withColumn("label_exe_lows_p",doubleToPercent('label_exe_lows / 'month_num))
      .withColumn("label_exe_100_p",doubleToPercent('label_exe_100 / 'month_num))
      .withColumn("label_exe_0_p",doubleToPercent('label_exe_0 / 'month_num))
      .withColumn("label_ontime_p",doubleToPercent('label_ontime / 'month_num))
      .withColumn("label_ontime_lows_p",doubleToPercent('label_ontime_lows / 'month_num))
      .withColumn("time_std_p",doubleToPercent('time_std / 'month_num))
      .withColumn("time_long_std_p",doubleToPercent('time_long_std / 'month_num))
      .withColumn("label_fee_p",doubleToPercent('label_fee / 'month_num))
      .withColumn("label_fee_high_p",doubleToPercent('label_fee_high / 'month_num))
      .withColumn("label_dist_p",doubleToPercent('label_dist / 'month_num))
      .withColumn("label_dist_long_p",doubleToPercent('label_dist_long / 'month_num))
      .withColumn("month_num_p_1",doubleToPercent('month_num_1 / 'std_sum_valid))
      .withColumn("week_num_p_1",doubleToPercent('week_num_1 / 'std_sum_valid))
      .withColumn("quality_all_num",'line_high + 'line_general + 'line_low)
      .withColumn("line_high_p",'line_high / 'quality_all_num)
      .withColumn("line_general_p",'line_general / 'quality_all_num)
      .withColumn("line_low_p",'line_low / 'quality_all_num)
      .withColumn("md5_id", md5(concat('inc_day, rand(10))))

    val label_cols = spark.sql("""select * from dm_gis.eta_std_line_stdid_lable_info limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_lable.coalesce(1).select(label_cols: _*),Seq("inc_day"),"dm_gis.eta_std_line_stdid_lable_info")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表10数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表11 表12)
   * 历史标准线路标签统计表  dm_gis.eta_std_line_stdid_info1  eta_std_line_stdid_lable_info1
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   * @param MouthBefore1
   */
  def etaStdLineStdidLableInfo1(spark: SparkSession, DayBefore1: String, incDay: String) = {
    val stdid_info_querySql =
      s"""
         |select
         |  std_id
         |  ,last_execute_time
         |  ,last_use_time
         |  ,last_week_execute_num
         |  ,last_week_use_num
         |  ,ontime_num7
         |  ,execute_ontime_num7
         |  ,unexecute_ontime_num7
         |  ,execute_num
         |  ,use_num
         |  ,ontime_num
         |  ,execute_ontime_num
         |  ,time_diff
         |  ,dist_diff
         |  ,highway_diff
         |  ,roadfee_diff
         |  ,ontime_diff
         |  ,is_econ
         |  ,delete_flag
         |  ,create_time
         |  ,update_time
         |  ,opt_user
         |  ,add_reason
         |  ,delete_reason
         |  ,keep_time
         |  ,roadfee_std
         |  ,time_std
         |  ,dist_std
         |  ,label_ontime
         |  ,label_fee
         |  ,label_time
         |  ,label_dist
         |  ,label_exe
         |  ,label_lamp
         |  ,label_pos
         |  ,lable_neg
         |  ,inc_day
         |from
         |  dm_gis.eta_std_line_stdid_info
         |where
         |  inc_day = '$incDay'
         |  and use_num >= 3
         |""".stripMargin

    println(stdid_info_querySql)
    val df_stdid_info = spark.sql(stdid_info_querySql)
//      .drop("md5_id","exe_point","ontime_point","dist_point","time_point","sum_point","quality_type","carrier_type")

    val info1_before1_querySql =
      s"""
         |select
         |  std_id
         |  ,last_execute_time
         |  ,last_use_time
         |  ,last_week_execute_num
         |  ,last_week_use_num
         |  ,ontime_num7
         |  ,execute_ontime_num7
         |  ,unexecute_ontime_num7
         |  ,execute_num
         |  ,use_num
         |  ,ontime_num
         |  ,execute_ontime_num
         |  ,time_diff
         |  ,dist_diff
         |  ,highway_diff
         |  ,roadfee_diff
         |  ,ontime_diff
         |  ,is_econ
         |  ,delete_flag
         |  ,create_time
         |  ,update_time
         |  ,opt_user
         |  ,add_reason
         |  ,delete_reason
         |  ,keep_time
         |  ,roadfee_std
         |  ,time_std
         |  ,dist_std
         |  ,label_ontime
         |  ,label_fee
         |  ,label_time
         |  ,label_dist
         |  ,label_exe
         |  ,label_lamp
         |  ,label_pos
         |  ,lable_neg
         |  ,inc_day
         |from
         |  dm_gis.eta_std_line_stdid_info1
         |where
         |  inc_day = '$DayBefore1'
         |""".stripMargin

    println(info1_before1_querySql)
    val df_info1_before1 = spark.sql(info1_before1_querySql)
//      .drop("md5_id")

    val line_conf_querySql =
      s"""
         |select
         |  std_id,
         |  delete_flag as delete_flag_new
         |from
         |  dm_gis.eta_std_line_conf
         |""".stripMargin
    println(line_conf_querySql)
    val df_line_conf = spark.sql(line_conf_querySql)

    import spark.implicits._
    val df_info1 = df_stdid_info
      .union(df_info1_before1)
      .withColumn("rn", row_number().over(Window.partitionBy('std_id).orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .join(df_line_conf, Seq("std_id"), "left")
      .filter('delete_flag_new === 0)
      .withColumn("delete_flag", 'delete_flag_new)
      .withColumn("inc_day", lit(incDay))
      .withColumn("md5_id", md5(concat('inc_day, rand(10))))
      .drop("rn","delete_flag_new")

    val info1_cols = spark.sql("""select * from dm_gis.eta_std_line_stdid_info1 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_info1.select(info1_cols: _*),Seq("inc_day"),"dm_gis.eta_std_line_stdid_info1")

    val res1_querySql =
      s"""
         |select
         |  $incDay as inc_day,
         |  count(distinct std_id) as std_sum,
         |  count(distinct(if(substr(label_exe,1,4) = '高执行率',std_id,null))) as label_exe,
         |  count(distinct(if(substr(label_exe,1,4) = '低执行率',std_id,null))) as label_exe_lows,
         |  count(distinct(if(substr(label_ontime,1,4) = '准点率高',std_id,null))) as label_ontime,
         |  count(distinct(if(substr(label_ontime,1,4) = '准点率低',std_id,null))) as label_ontime_lows,
         |  count(distinct(if(substr(label_time,1,3) = '时长短',std_id,null))) as time_std,
         |  count(distinct(if(substr(label_time,1,3) = '时长长',std_id,null))) as time_long_std,
         |  count(distinct(if(substr(label_fee,1,4) = '路桥费低',std_id,null))) as label_fee,
         |  count(distinct(if(substr(label_fee,1,4) = '路桥费高',std_id,null))) as label_fee_high,
         |  count(distinct(if(substr(label_dist,1,3) = '里程短',std_id,null))) as label_dist,
         |  count(distinct(if(substr(label_dist,1,3) = '里程长',std_id,null))) as label_dist_long
         |from
         |  dm_gis.eta_std_line_stdid_info1
         |where
         |  inc_day = '$incDay'
         |""".stripMargin

    import spark.implicits._
    val df_lable = spark.sql(res1_querySql)
      .withColumn("label_exe_p",doubleToPercent('label_exe / 'std_sum))
      .withColumn("label_exe_lows_p",doubleToPercent('label_exe_lows / 'std_sum))
      .withColumn("label_ontime_p",doubleToPercent('label_ontime / 'std_sum))
      .withColumn("label_ontime_lows_p",doubleToPercent('label_ontime_lows / 'std_sum))
      .withColumn("time_std_p",doubleToPercent('time_std / 'std_sum))
      .withColumn("time_long_std_p",doubleToPercent('time_long_std / 'std_sum))
      .withColumn("label_fee_p",doubleToPercent('label_fee / 'std_sum))
      .withColumn("label_fee_high_p",doubleToPercent('label_fee_high / 'std_sum))
      .withColumn("label_dist_p",doubleToPercent('label_dist / 'std_sum))
      .withColumn("label_dist_long_p",doubleToPercent('label_dist_long / 'std_sum))
      .withColumn("md5_id", md5(concat('inc_day, rand(10))))

    val label1_cols = spark.sql("""select * from dm_gis.eta_std_line_stdid_lable_info1 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_lable.coalesce(1).select(label1_cols: _*),Seq("inc_day"),"dm_gis.eta_std_line_stdid_lable_info1")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表11 12 数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }



  /**
   * 表8的标签字段拼接函数
   * @return
   */
  def concatField = udf((col1: String,col2: String) => {
    var percent = ""
    if(col1 != null && col1.trim != "" && col2 != null && col2.trim != ""){
      try{
        percent = f"${col2.toDouble*100}%.2f%%"
      }catch {
        case e: Exception => println(">>>小数转换成百分数异常："+e)
      }
    }
    val res = s"${col1}_${percent}"
    res
  })

  /**
   * 表8的小数转化成百分数函数，保留两位
   * @return
   */
  def doubleToPercent = udf((col1: String) => {
    var percent = "0.0%"
    if(col1 != null && col1.trim != ""){
      try{
        percent = f"${col1.toDouble*100}%.2f%%"
      }catch {
        case e: Exception => println(">>>小数转换成百分数异常："+e)
      }
    }
    percent
  })

  /**
   * 表8的获取正逆向标签函数
   * @return
   */
  def collectLabels = udf((col1:String,col2:String,col3:String,col4:String,col5:String,falg:String) => {
    val res_arr = new ArrayBuffer[String]()
    if(col1 != null && col1.trim != "" && col2 != null && col2.trim != ""
      && col3 != null && col3.trim != "" && col4 != null && col4.trim != "" && col5 != null && col5.trim != ""){
      if(falg.equals("pos")){
        if(col1.contains("准点率高")) res_arr.append(col1)
        if(col2.contains("路桥费低")) res_arr.append(col2)
        if(col3.contains("时长短")) res_arr.append(col3)
        if(col4.contains("里程短")) res_arr.append(col4)
        if(col5.contains("高执行率")) res_arr.append(col5)
      }else if(falg.equals("neg")){
        if(col1.contains("准点率低")) res_arr.append(col1)
        if(col2.contains("路桥费高")) res_arr.append(col2)
        if(col3.contains("时长长")) res_arr.append(col3)
        if(col4.contains("里程长")) res_arr.append(col4)
        if(col5.contains("低执行率")) res_arr.append(col5)
      }
    }
    val res = res_arr.mkString("|")
    res
  })

}
