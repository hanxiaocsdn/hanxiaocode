package com.sf.gis.scala.lss.lineUpdate

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.lss.utils.SparkUtils.{logger, writeToHive, writeToHiveNoP}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：827458
 * 任务名称：已运营线路汇总_11
 */
object EtaLineAlreadyOperate {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def run(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    // 大区维表
    val mapping2_sql =
      s"""
         |select
         |  area_code,
         |  area_type
         |from
         |  dm_gis.dim_area_code_mapping2
         |""".stripMargin
    println("大区维表取数sql：")
    println(mapping2_sql)
    val df_mapping2 = spark.sql(mapping2_sql)

    val update_result_sql =
      s"""
         |select
         |   linevehicle,
         |   std_id as line_id,
         |   task_area_code,
         |   plan_time,
         |  '修改' as type
         |from
         |  dm_gis.eta_line_update_result
         |where
         |  inc_day = '$dayBefore1'
         |  and repair_status = '0'
         |""".stripMargin

    println("线路更新数据取数sql：")
    println(update_result_sql)
    val df_update_result = spark.sql(update_result_sql)

    val add_result_sql =
      s"""
         |select
         |   linevehicle,
         |   line_id,
         |   task_area_code,
         |   plan_time,
         |  '新增' as type
         |from
         |  dm_gis.eta_line_add_result
         |where
         |  inc_day = '$dayBefore1'
         |  and repair_status = '0'
         |""".stripMargin

    println("线路新增数据取数sql：")
    println(add_result_sql)
    val df_add_result = spark.sql(add_result_sql)

    // 新增线路和更新线路合并统计
    val df_already_operate = df_update_result.union(df_add_result)
      .withColumn("num", row_number().over(Window.partitionBy('linevehicle,'type).orderBy(desc("plan_time"))))
      .groupBy("linevehicle","type")
      .agg(
        max(when('num === 1,'task_area_code).otherwise(null)) as "area_code",
        count('line_id) as "line_count"
      )
      .join(df_mapping2,Seq("area_code"),"left")

    // 更新数据追加写入已运营线路表
    df_already_operate.createOrReplaceTempView("tmpTableName")
    val insert_sql =
      s"""
         |insert into table dm_gis.eta_line_already_operate
         |select
         |  linevehicle,
         |  '$dayBefore1' as update_time,
         |  type,
         |  area_type,
         |  line_count
         |from
         |  tmpTableName
         |""".stripMargin
    println(insert_sql)
    spark.sql(insert_sql)
    spark.catalog.dropTempView("tmpTableName")

  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1)
    logger.error("++++++++  任务结束 20231009  ++++")

    spark.stop()
  }
}
