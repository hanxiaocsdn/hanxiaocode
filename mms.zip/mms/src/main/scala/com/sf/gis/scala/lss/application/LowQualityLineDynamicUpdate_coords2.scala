package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.row2Json
import com.sf.gis.scala.lss.constant.OperationIndexObj.SameLineId
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.sf.gis.scala.lss.utils.StringUtils.stdCoordsToPoints
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer


/**
 * GIS_LSS_MMS:【标准线路】低质量线路动态更新，，处理好后数据推送接口部分
 * 需求方：刘诺文（80006476）
 * @author 徐游飞（01417347）
 * 任务ID：675854
 * 任务名称：低质量线路推送至接口
 */
object LowQualityLineDynamicUpdate_coords2 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val GET_LINE: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val GET_LINE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val UPDATE_LINE: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/updateLine"
  val UPDATE_LINE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 4000

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    UpdateLine(spark,incDay)
    logger.error("++++++++  任务完成 20231016 ++++")

    spark.stop()
  }

  // 向标准线路接口推送数据
  def UpdateLine(spark: SparkSession,incDay: String) = {
    import spark.implicits._

    val df_table_e2 = spark.sql(
      s"""
         |select
         |  std_id
         |  ,paths_num
         |  ,check_lineid
         |  ,median_time
         |  ,rt_coords
         |  ,rt_dist
         |  ,time
         |  ,new_coords
         |  ,new_distance
         |  ,new_duration
         |  ,new_highspeed_distance
         |  ,new_tolls
         |  ,new_toll_distance
         |  ,check_line_code
         |  ,check_srcDeptcode
         |  ,check_destDeptcode
         |  ,check_vehicle
         |  ,pp_break
         |  ,new_status
         |  ,new_msg
         |  ,new_param
         |  ,rn_flag
         |  ,same_lineid
         |  ,inc_day
         |from
         |   dm_gis.low_quality_qm_point
         |where
         |  inc_day = '$incDay'
         |""".stripMargin)

    //    // 获取线下std_id数据
    //    val df_stdid: DataFrame = spark.read
    //      .format("csv")
    //      .option("sep", ",")
    //      .option("header", "true")
    //      .option("inferSchema", "true")
    //      .load("/user/01417347/upload/data/stdid.csv")
    //
    //    val df_table_e222 = df_stdid.join(df_table_e2,Seq("std_id"),"left")

    //    println("df_stdid数据量:"+df_stdid.count())
    //    println("df_table_e2数据量:"+df_table_e2.count())
    //    println("df_table_e222数据量:"+df_table_e222.count())
    //    println("same_lineid为空的数据量:"+df_table_e222.filter('same_lineid === "空").count())
    //    println("same_lineid为空的数据量aa:"+df_table_e2.filter('same_lineid === "空").count())

    val invokeCnt_1 = df_table_e2.filter('same_lineid === "空").count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "675854", "低质量线路推送至接口", "获取标准线路", GET_LINE, GET_LINE_AK, invokeCnt_1, parallelism)
    // 调标准线路查询接口
    val getLineRDD = SparkNet.runInterfaceWithAkLimit(spark, df_table_e2.filter('same_lineid === "空").rdd.map(row2Json), runGetLineInteface2, parallelism, GET_LINE_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)

    val rdd_table_f = getLineRDD.repartition(800).flatMap(obj => {

      val dataArray = new ArrayBuffer[(JSONObject,JSONObject)]()
      val list_arr = JSONUtil.getJsonArrayMulti(obj, "list_arr")

      for(i <- 0 until list_arr.size()){
        val ret_obj = new JSONObject()

        val check_stdid = list_arr.getJSONObject(i).getString("stdId")
        val check_start_time = list_arr.getJSONObject(i).getString("planTime")
        val check_routeIndex = list_arr.getJSONObject(i).getString("routeIndex")
        val check_line_distance = list_arr.getJSONObject(i).getString("lineDistance")
        val check_line_time = list_arr.getJSONObject(i).getString("lineTime")
        val check_isEcon = list_arr.getJSONObject(i).getString("isEcon")
        val check_createTime = list_arr.getJSONObject(i).getString("createTime")
        val check_deleteFlag = list_arr.getJSONObject(i).getString("deleteFlag")
        val check_updateTime = list_arr.getJSONObject(i).getString("updateTime")

        ret_obj.put("check_stdid",check_stdid)
        ret_obj.put("check_line_distance",check_line_distance)
        ret_obj.put("check_line_time",check_line_time)
        ret_obj.put("check_start_time",check_start_time)
        ret_obj.put("check_isEcon",check_isEcon)
        ret_obj.put("check_createTime",check_createTime)
        ret_obj.put("check_routeIndex",check_routeIndex)
        ret_obj.put("check_deleteFlag",check_deleteFlag)
        ret_obj.put("check_updateTime",check_updateTime)
        dataArray.append((obj,ret_obj))
      }
      dataArray.iterator
    }).map(obj=>{
      val obj_1 = obj._1
      val obj_2 = obj._2
      val check_stdid = JSONUtil.getJsonVal(obj_2, "check_stdid", "")
      val check_line_distance = JSONUtil.getJsonVal(obj_2, "check_line_distance", "")
      val check_line_time = JSONUtil.getJsonVal(obj_2, "check_line_time", "")
      val check_start_time = JSONUtil.getJsonVal(obj_2, "check_start_time", "")
      val check_isEcon = JSONUtil.getJsonVal(obj_2, "check_isEcon", "")
      val check_createTime = JSONUtil.getJsonVal(obj_2, "check_createTime", "")
      val check_routeIndex = JSONUtil.getJsonVal(obj_2, "check_routeIndex", "")
      val check_deleteFlag = JSONUtil.getJsonVal(obj_2, "check_deleteFlag", "")
      val check_updateTime = JSONUtil.getJsonVal(obj_2, "check_updateTime", "")

      obj_1.put("check_stdid",check_stdid)
      obj_1.put("check_line_distance",check_line_distance)
      obj_1.put("check_line_time",check_line_time)
      obj_1.put("check_start_time",check_start_time)
      obj_1.put("check_isEcon",check_isEcon)
      obj_1.put("check_createTime",check_createTime)
      obj_1.put("check_routeIndex",check_routeIndex)
      obj_1.put("check_deleteFlag",check_deleteFlag)
      obj_1.put("check_updateTime",check_updateTime)

      obj_1
    })
      .filter(obj=>{
        val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
        val check_stdid = JSONUtil.getJsonVal(obj, "check_stdid", "")
        val check_isEcon = JSONUtil.getJsonVal(obj, "check_isEcon", "")
        val check_routeIndex = JSONUtil.getJsonVal(obj, "check_routeIndex", "")

        (std_id.equals(check_stdid) || (check_isEcon.equals("3") && check_routeIndex.equals("0")))
      })

    val invokeCnt_2 = rdd_table_f.count()
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "675854", "低质量线路推送至接口", "线路推送至接口", UPDATE_LINE, UPDATE_LINE_AK, invokeCnt_2, parallelism)
    // 调用标准线路线路更新接口
    val updateLineRDD = SparkNet.runInterfaceWithAkLimit(spark, rdd_table_f, runUpdateLineInteface, parallelism, UPDATE_LINE_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df_table_f = updateLineRDD.map(obj => {
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val paths_num = JSONUtil.getJsonVal(obj, "paths_num", "")
      val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
      val median_time = JSONUtil.getJsonVal(obj, "median_time", "")
      val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
      val rt_dist = JSONUtil.getJsonVal(obj, "rt_dist", "")
      val time = JSONUtil.getJsonVal(obj, "time", "")
      val new_coords = JSONUtil.getJsonVal(obj, "new_coords", "")
      val new_distance = JSONUtil.getJsonVal(obj, "new_distance", "")
      val new_duration = JSONUtil.getJsonVal(obj, "new_duration", "")
      val new_highspeed_distance = JSONUtil.getJsonVal(obj, "new_highspeed_distance", "")
      val new_tolls = JSONUtil.getJsonVal(obj, "new_tolls", "")
      val new_toll_distance = JSONUtil.getJsonVal(obj, "new_toll_distance", "")
      val check_line_code = JSONUtil.getJsonVal(obj, "check_line_code", "")
      val check_srcDeptcode = JSONUtil.getJsonVal(obj, "check_srcDeptcode", "")
      val check_destDeptcode = JSONUtil.getJsonVal(obj, "check_destDeptcode", "")
      val check_vehicle = JSONUtil.getJsonVal(obj, "check_vehicle", "")
      val pp_break = JSONUtil.getJsonVal(obj, "pp_break", "")

      val check_status = JSONUtil.getJsonVal(obj, "check_status", "")
      val check_stdid = JSONUtil.getJsonVal(obj, "check_stdid", "")
      val check_line_distance = JSONUtil.getJsonVal(obj, "check_line_distance", "")
      val check_line_time = JSONUtil.getJsonVal(obj, "check_line_time", "")
      val check_start_time = JSONUtil.getJsonVal(obj, "check_start_time", "")
      val check_isEcon = JSONUtil.getJsonVal(obj, "check_isEcon", "")
      val check_createTime = JSONUtil.getJsonVal(obj, "check_createTime", "")
      val check_routeIndex = JSONUtil.getJsonVal(obj, "check_routeIndex", "")
      val check_deleteFlag = JSONUtil.getJsonVal(obj, "check_deleteFlag", "")
      val check_updateTime = JSONUtil.getJsonVal(obj, "check_updateTime", "")

      val repair_status = JSONUtil.getJsonVal(obj, "repair_status", "")
      val repair_code = JSONUtil.getJsonVal(obj, "repair_code", "")
      val repair_info = JSONUtil.getJsonVal(obj, "repair_info", "")
      val repair_err = JSONUtil.getJsonVal(obj, "repair_err", "")
      val repair_msg = JSONUtil.getJsonVal(obj, "repair_msg", "")
      val repair_stdid = JSONUtil.getJsonVal(obj, "repair_stdid", "")

      SameLineId(std_id,paths_num,check_lineid,median_time,rt_coords,rt_dist,time,new_highspeed_distance,new_tolls,new_toll_distance,check_line_code,
        check_srcDeptcode,check_destDeptcode,check_vehicle,pp_break,check_status,check_stdid,check_line_distance,check_line_time,check_start_time,
        check_isEcon,check_createTime,check_routeIndex,check_deleteFlag,check_updateTime,repair_status,repair_code,repair_info,repair_err,repair_msg,
        repair_stdid,new_coords,new_distance,new_duration)
    }).toDF()
      .withColumn("inc_day",lit(incDay))
      .coalesce(50)

    val cols_f = spark.sql("""select * from dm_gis.low_quality_update_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_table_f.select(cols_f: _*),Seq("inc_day"),"dm_gis.low_quality_update_detail")

    // 表b和线路更新结果返回数据关联
    val df_result1 = spark.sql(
      s"""
         |select
         |  std_id,
         |  sum_point,
         |  quality_type,
         |  check_deleteflag,
         |  check_isecon,
         |  eliminate_std,
         |  grp_sum_point,
         |  grp_quality_type,
         |  same_lineid,
         |  pp_break,
         |  eliminate_grp
         |from
         |  dm_gis.low_quality_result1
         |where
         |  inc_day = '$incDay'
         |""".stripMargin)

    val std_result = df_result1
      .join(df_table_f.select("std_id","repair_stdid","repair_status").distinct(),Seq("std_id"),"left")
      .withColumn("inc_day",lit(incDay))

    val result_cols = spark.sql("""select * from dm_gis.eta_std_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,std_result.select(result_cols: _*),Seq("inc_day"),"dm_gis.eta_std_result")

  }

  /**
   * 解析 标准线路配置查询接口返回值
   * @param ret
   * @return
   */
  def parseGetLineHttpData(ret: JSONObject): (String, String, JSONArray, JSONObject) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, "请求失败", null, null)
      } else {
        var list_obj = new JSONObject()
        var list_arr = new JSONArray()
        try{
          list_arr = ret.getJSONObject("result").getJSONArray("list")
          list_obj = ret.getJSONObject("result").getJSONArray("list").getJSONObject(0)

        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", list_arr, list_obj)
      }
    }
    ("22", "请求失败", null, null)
  }


  /**
   * 解析 标准线路更新返回值
   * @param ret
   * @return
   */
  def parseUpdateLineHttpData(ret: JSONObject): JSONObject = {
    val obj = new JSONObject()
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        var err = ""
        var msg = ""
        try{
          err = ret.getJSONObject("result").getString("err")
          msg = ret.getJSONObject("result").getString("msg")
        }catch {
          case e: Exception => logger.error(e)
        }
        obj.put("repair_status",codeStatue)
        obj.put("repair_err",err)
        obj.put("repair_msg",msg)
        logger.error("获取接口数据失败: " + msg)

        return obj
      } else {
        var code = ""
        var info = ""
        var stdId = ""
        try{
          code = ret.getJSONObject("result").getString("code")
          info = ret.getJSONObject("result").getString("info")
          stdId = ret.getJSONObject("result").getString("stdId")
        }catch {
          case e: Exception => logger.error(e)
        }
        obj.put("repair_status",codeStatue)
        obj.put("repair_code",code)
        obj.put("repair_info",info)
        obj.put("repair_stdid",stdId)

        return obj
      }
    }
    obj
  }

  /**
   * 第二次调用标准线路配置查询接口
   * @param spark
   * @param dataDF
   */
  def runGetLineInteface2(ak:String, obj: JSONObject): JSONObject = {
    val check_vehicle = JSONUtil.getJsonVal(obj, "check_vehicle", "")
    val check_line_code = JSONUtil.getJsonVal(obj, "check_line_code", "")
    val check_srcDeptcode = JSONUtil.getJsonVal(obj, "check_srcDeptcode", "")
    val check_destDeptcode = JSONUtil.getJsonVal(obj, "check_destDeptcode", "")
    // 先调线路查询接口
    //初始化线路查询接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "01413751")
    param.put("vehicle", check_vehicle)
    param.put("lineCode", check_line_code)
    param.put("srcDeptcode",check_srcDeptcode)
    param.put("destDeptcode",check_destDeptcode)
    param.put("containDeleted","False")
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(GET_LINE,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析线路查询接口返回值
    val httpData: (String, String, JSONArray, JSONObject) = parseGetLineHttpData(retJSONObject)
    val list_arr = httpData._3

    // 查询线路接口新增字段
    obj.put("check_status",httpData._1)
    obj.put("list_arr",list_arr)

    obj
  }

  /**
   * 调用标准线路线路更新接口
   * @param spark
   * @param dataDF
   */
  def runUpdateLineInteface(ak:String, obj: JSONObject): JSONObject = {
    // 获取参数字段
    val check_stdid = JSONUtil.getJsonVal(obj,"check_stdid","")
    val check_srcDeptcode = JSONUtil.getJsonVal(obj,"check_srcDeptcode","")
    val check_destDeptcode = JSONUtil.getJsonVal(obj,"check_destDeptcode","")
    val check_line_code = JSONUtil.getJsonVal(obj,"check_line_code","")
    val check_start_time = JSONUtil.getJsonVal(obj,"check_start_time","")
    val check_vehicle = JSONUtil.getJsonVal(obj,"check_vehicle","")
    val check_routeIndex = JSONUtil.getJsonVal(obj,"check_routeIndex","")
    val check_line_distance = JSONUtil.getJsonVal(obj,"check_line_distance","")
    val check_line_time = JSONUtil.getJsonVal(obj,"check_line_time","")
    val inc_day = JSONUtil.getJsonVal(obj,"inc_day","")
    val rt_coords = JSONUtil.getJsonVal(obj,"rt_coords","")
    val time = JSONUtil.getJsonVal(obj,"time","")
    val new_highspeed_distance = JSONUtil.getJsonVal(obj,"new_highspeed_distance","")
    val new_tolls = JSONUtil.getJsonVal(obj,"new_tolls","")
    val new_toll_distance = JSONUtil.getJsonVal(obj,"new_toll_distance","")
    val rt_dist = JSONUtil.getJsonDouble(obj,"rt_dist",0.0).toInt
    val new_coords = JSONUtil.getJsonVal(obj, "new_coords", "")
    val new_distance = JSONUtil.getJsonDouble(obj, "new_distance", 0.0).toInt
    val new_duration = JSONUtil.getJsonDouble(obj, "new_duration", 0.0).toInt

    val jyTrack2 = stdCoordsToPoints(new_coords)
    val updateReason = s"$inc_day-低质量线路优化"

    //初始化线路更新接口请求参数
    val deleteLine = new JSONObject()
    deleteLine.put("stdId",check_stdid)

    val addLine = new JSONObject()
    addLine.put("srcDeptcode",check_srcDeptcode)
    addLine.put("destDeptcode",check_destDeptcode)
    addLine.put("lineCode",check_line_code)
    addLine.put("planTime",check_start_time)
    addLine.put("vehicle",check_vehicle)
    addLine.put("isEcon",3)
    addLine.put("routeIndex",0)
    addLine.put("jyTrack2",jyTrack2)
    addLine.put("rtDistance",new_distance)
    addLine.put("rtTime",new_duration)
    addLine.put("lineDistance",check_line_distance)
    addLine.put("lineTime",check_line_time)
    addLine.put("highway",new_highspeed_distance)
    addLine.put("tolls",new_tolls)
    addLine.put("tollsDistance",new_toll_distance)
    addLine.put("confSrc",3)

    val param_2 = new JSONObject()
    param_2.put("ak", ak)
    param_2.put("updateReason", updateReason)
    param_2.put("optUserId", "80006476")
    param_2.put("deleteLine",deleteLine)
    param_2.put("addLine",addLine)

    var retJSONObject_2 = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(UPDATE_LINE,param_2.toJSONString,3)
      retJSONObject_2 = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析线路更新接口返回值
    val httpData_2: JSONObject = parseUpdateLineHttpData(retJSONObject_2)
    val repair_status = JSONUtil.getJsonVal(httpData_2,"repair_status","")
    val repair_code = JSONUtil.getJsonVal(httpData_2,"repair_code","")
    val repair_info = JSONUtil.getJsonVal(httpData_2,"repair_info","")
    val repair_err = JSONUtil.getJsonVal(httpData_2,"repair_err","")
    val repair_msg = JSONUtil.getJsonVal(httpData_2,"repair_msg","")
    val repair_stdid = JSONUtil.getJsonVal(httpData_2,"repair_stdid","")

    // 线路更新接口新增字段
    obj.put("repair_status",repair_status)
    obj.put("repair_code",repair_code)
    obj.put("repair_info",repair_info)
    obj.put("repair_err",repair_err)
    obj.put("repair_msg",repair_msg)
    obj.put("repair_stdid",repair_stdid)

    obj
  }


}
