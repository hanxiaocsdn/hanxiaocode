package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.Functions.getDist
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.constant.OperationIndexObj.RecallDF
import com.sf.gis.scala.lss.utils.Functions.getDateDiff
import com.sf.gis.scala.lss.utils.SparkUtils.{df2HiveByOverwrite, writeToHive}
import com.sf.gis.scala.lss.utils.StringUtils.{nonEmpty, stdCoordsToPoints, timeToCustomTime}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

/**
 * 标准线路运营指标体系搭建，获取路况信息部分
 * 需求方：马晶玲（01423372）
 * @author 徐游飞（01417347）
 * 任务信息：630337（标准线路第二部分表2和表7，天任务，每天10:00执行）
 * 上游依赖：表8,429725,371318,85843
 */
object StandardLineOperationIndexStatistics22 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val QM_URL: String = "http://gis-int.int.sfdc.com.cn:1080/rp/qm_point/sf"
  val QM_URL_AK: String = "d6a1f9b11d2441fc8fc1ffb5eb3e61d6"
  val GET_LINE: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val GET_LINE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 6000

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val DayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val DayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  开始计算标准线路执行情况每日统计表（拆经停）  ++++  表2 & 表7 ++++")
    etaStdLineRecallDaily(spark,DayBefore1,DayBefore7)

    logger.error("++++++++  任务完成20230712  ++++")
    spark.stop()
  }

  /**
   * (表2)
   * 标准线路执行情况每日统计表（拆经停） dm_gis.eta_std_line_recall_daily
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   */
  def etaStdLineRecallDaily(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {

    import spark.implicits._
    // 计算得到路况异常信息表
    stdlineAbnormalDaily(spark, DayBefore1, DayBefore7)
    // 获取eta标准线路表数据
    val recallResultDF = getRecallResultData(spark, DayBefore1, DayBefore7) //a
    // 获取路况异常数据
    val stdlineDF = getStdlineData(spark, DayBefore1, DayBefore7)  //b
    // 获取配置详情表数据
    val stdlineConfDF = getStdlineConfData(spark) //c

    val nonEmpty_udf = udf(nonEmpty _)
    // 统计任务数
    val recallDailyDF = recallResultDF
      .withColumn("distances", getDist($"start_longitude", $"start_latitude", $"end_longitude", $"end_latitude"))
      .withColumn("mileage_type", when('distances.cast("double") <= 0.4, "是").otherwise("否"))
      .join(stdlineDF, Seq("task_subid", "inc_day"), "left")
      .join(stdlineConfDF,Seq("std_id"),"left")
      .withColumn("rn", row_number().over(Window.partitionBy("task_subid").orderBy(desc("last_update_tm"))))
      .filter('rn === 1)
      .withColumn("add_src",when('src =!= 0,"标准")
        .when('src === 0 and 'add_reason.contains("融合"),"融合")
        .when('src === 0 and !'add_reason.contains("融合") and 'add_reason.contains("新方案"),"标准新方案")
        .otherwise("标准"))
      .withColumn("create_date",substring('create_time,0,10))
      // 类型转换，方便后续判断
      .withColumn("sim1",'sim1.cast("double"))
      .withColumn("sim5",'sim5.cast("double"))
      .withColumn("if_evaluate_time",'if_evaluate_time.cast("double"))
      .withColumn("ac_is_run_ontime",'ac_is_run_ontime.cast("double"))
      .withColumn("transoport_level",'transoport_level.cast("double"))
      .withColumn("conduct_type",'conduct_type.cast("double"))
      .withColumn("require_category",'require_category.cast("double"))
      // 分组统计
      .groupBy("task_area_code","task_area_name","carrier_name","carrier_type","line_code","start_dept","end_dept","driver_name","main_driver_account","vehicle_type","src","src_name","inc_day","add_src","create_date")
      .agg(
        count(when('error_type =!= "0", 1).otherwise(null)) as "err_num",
        count(when('sim1.isNull or 'sim1 === -1 or 'sim5.isNull or 'sim5 === -1, 1).otherwise(null)) as "sim_error_num",
        count(when('if_evaluate_time === 1, 1).otherwise(null)) as "eval_task_num",
        count(when('if_evaluate_time === 1 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num",
        count(when('if_evaluate_time === 1 and ('transoport_level === 1 or 'transoport_level === 2), 1).otherwise(null)) as "eval_task_num_trunk",
        count(when('if_evaluate_time === 1 and ('transoport_level === 1 or 'transoport_level === 2) and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num_trunk",
        count(when('if_evaluate_time === 1 and 'transoport_level === 3, 1).otherwise(null)) as "eval_task_num_branch",
        count(when('if_evaluate_time === 1 and 'transoport_level === 3 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num_branch",
        count(when('mileage_type === "是", 1).otherwise(null)) as "near_area_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and 'conduct_type === 3 and 'error_type === "0", 1).otherwise(null)) as "unexecuted_num_tmp",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and ('conduct_type === 1 or 'conduct_type === 2) and 'error_type === "0", 1).otherwise(null)) as "execute_num",
        count('task_subid) as "all_task_num",
        count(when('ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and ('conduct_type === 1 or 'conduct_type === 2) and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "execute_ontime_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "unexecuted_ontime_num_tmp",
        count(when('roadcdt_type =!= "0" and ('type === "7" or 'type === "8" or 'type === "16") and 'conduct_type === 3 and 'error_type === "0", 1).otherwise(null)) as "roaderr_num",
        count(when('roadcdt_type =!= "0" and ('type === "7" or 'type === "8" or 'type === "16") and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_roaderr_num",
        count(when('require_category === 5 and 'conduct_type === 3 and 'error_type === "0",1).otherwise(null)) as "require_del_num",
        count(when('require_category === 5 and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1,1).otherwise(null)) as "ontime_require_del_num"
      )
      .withColumn("unexecuted_num", 'unexecuted_num_tmp - 'roaderr_num - 'require_del_num)
      .withColumn("unexecuted_ontime_num",'unexecuted_ontime_num_tmp - 'ontime_roaderr_num - 'ontime_require_del_num)
      .withColumn("md5_id", md5(concat('task_area_code, 'line_code, 'inc_day, rand(10))))

    recallDailyDF.printSchema()
    val res_cols = spark.sql("select * from dm_gis.eta_std_line_recall_daily limit 0").schema.map(_.name).map(col)
    df2HiveByOverwrite(logger,recallDailyDF.select(res_cols: _*),"dm_gis.eta_std_line_recall_daily")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表2数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * (表7)
   * 计算得到路况异常信息表  dm_gis.gis_eta_stdline_abnormal_daily_result
   * @param spark
   * @param DayBefore1
   */
  def stdlineAbnormalDaily(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {

    // 获取数据源
    var recallRDD = getLineRecallData(spark, DayBefore1)
    val abnormityDF = getAbnormityData(spark, DayBefore1, DayBefore7)

    val invokeCnt = recallRDD.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "630337", "标准线路第二部分表2和表7", "获取路况数据", QM_URL, QM_URL_AK, invokeCnt, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "630337", "标准线路第二部分表2和表7", "获取标准线路更新数据", GET_LINE, GET_LINE_AK, invokeCnt, parallelism)
    // 调用qm_point接口 和 标准线路配置查询接口
    recallRDD = SparkNet.runInterfaceWithAkLimit(spark, recallRDD, runQMPointInteface, parallelism, QM_URL_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    import spark.implicits._
    val stdlineDF = recallRDD.repartition(100).map(obj => {
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val carrier_name = JSONUtil.getJsonVal(obj, "carrier_name", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
      val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val src = JSONUtil.getJsonVal(obj, "src", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val log_dist = JSONUtil.getJsonVal(obj, "log_dist", "")
      val pns_dist = JSONUtil.getJsonVal(obj, "pns_dist", "")
      val rt_dist = JSONUtil.getJsonVal(obj, "rt_dist", "")
      val accrual_dist = JSONUtil.getJsonVal(obj, "accrual_dist", "")
      val accrual_dist_type = JSONUtil.getJsonVal(obj, "accrual_dist_type", "")
      val driver_id = JSONUtil.getJsonVal(obj, "driver_id", "")
      val driver_name = JSONUtil.getJsonVal(obj, "driver_name", "")
      val task_inc_day = JSONUtil.getJsonVal(obj, "task_inc_day", "")
      val roadcdt_type = JSONUtil.getJsonVal(obj, "roadcdt_type", "")
      val error_type = JSONUtil.getJsonVal(obj, "error_type", "")
      val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
      val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")
      val require_category = JSONUtil.getJsonVal(obj, "require_category", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val main_driver_account = JSONUtil.getJsonVal(obj, "main_driver_account", "")
      val updateTime = JSONUtil.getJsonVal(obj, "updateTime", "")
      val get_line_param = JSONUtil.getJsonVal(obj, "get_line_param", "")
      val std_id_update = timeToCustomTime(updateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMdd")
      val msg = JSONUtil.getJsonVal(obj, "msg", "")
      val result = JSONUtil.getJsonVal(obj, "result", "")
      val codeStatue = JSONUtil.getJsonVal(obj, "codeStatue", "")

      RecallDF(task_area_code,carrier_name,task_id,task_subid,conduct_type,line_code,carrier_type,vehicle_type,src,start_dept,end_dept,log_dist,
        pns_dist,rt_dist,accrual_dist,accrual_dist_type,driver_id,driver_name,task_inc_day,roadcdt_type,error_type,sim1,sim5,require_category,
        vehicle_serial,main_driver_account,std_id_update,get_line_param,updateTime,codeStatue,result,msg)
    }).toDF()
      .join(abnormityDF, Seq("task_id"), "left")
      .withColumn("del_type",when(!'error_type.contains("0"),1)
        .when(!'roadcdt_type.contains("0") and ('type === 7 or 'type === 8 or 'type === 16) and 'conduct_type === 3 and 'error_type.contains("0"),2)
        .when('require_category === 5 and 'conduct_type === 3 and 'error_type.contains("0"),3)
        .when(('sim1.isNull or 'sim5.isNull or 'sim1 === "" or 'sim5 === "" or 'sim1 === -1 or 'sim5 === -1) and 'error_type.contains("0"),4)
        .when(('type === 7 or 'type === 8 or 'type === 16) and 'conduct_type === 3 and 'error_type.contains("0"),5)
        .otherwise(0)
      )
      .withColumn("datediff",getDateDiff('task_inc_day,'std_id_update,lit("yyyyMMdd"),lit(0)))
      .withColumn("buffer_type",when('datediff.isNotNull and 'datediff <= 2 and 'src === 0,1).otherwise(0))
      .withColumn("rn_type",when('type === 7,7).when('type === 8,8).when('type === 16,16).otherwise(99))
      .withColumn("rn",row_number().over(Window.partitionBy("task_subid").orderBy('rn_type)))
      .filter('rn === 1)
      .withColumn("md5_id",md5(concat(rand(10),'task_id,'line_code,'task_inc_day,lit(DayBefore1))))
      .withColumn("inc_day", lit(DayBefore1))

//    stdlineDF.printSchema()
//    val stdlineDF_cols = spark.sql("select * from dm_gis.stdline_xyf_tmp limit 0").schema.map(_.name).map(col)
//    writeToHive(spark,stdlineDF.select(stdlineDF_cols: _*),Seq("inc_day"),"dm_gis.stdline_xyf_tmp")
    val res_cols = spark.sql("select * from dm_gis.gis_eta_stdline_abnormal_daily_result limit 0").schema.map(_.name).map(col)
    df2HiveByOverwrite(logger, stdlineDF.select(res_cols: _*), "dm_gis.gis_eta_stdline_abnormal_daily_result")

    println("++++++++++++++*++++++++++++++++++++++++")
    println("++++++++    结果表7数据落表完成    ++++++++")
    println("++++++++++++++*++++++++++++++++++++++++")
  }

  /**
   * 获取路况异常数据
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   * @return
   */
  def getStdlineData(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {
    // 标准线路执行情况直线距离中间表
    val stdline_querySql =
      s"""
         |select
         |  task_subid,
         |  roadcdt_type,
         |  type,
         |  require_category,
         |  inc_day
         |from
         |  dm_gis.gis_eta_stdline_abnormal_daily_result
         |where
         |  inc_day >= '$DayBefore7'
         |  and inc_day <= '$DayBefore1'
         |""".stripMargin

    println(stdline_querySql)
    val stdlineDF = spark.sql(stdline_querySql)
    stdlineDF
  }

  /**
   * 获取eta标准线路表数据
   * @param spark
   * @param DayBefore1
   * @param DayBefore7
   * @return
   */
  def getRecallResultData(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {
    val recall_querySql =
      s"""
         |select
         |  t1.task_area_code,
         |  t2.area_name as task_area_name,
         |  t1.carrier_name,
         |  t1.sf_outer_vehicle_from,
         |  t1.carrier_type,
         |  t1.line_code,
         |  t1.vehicle_type,
         |  t1.vehicle_serial,
         |  t1.src,
         |  t1.src_name,
         |  t1.start_dept,
         |  t1.end_dept,
         |  t1.driver_name,
         |  t1.main_driver_account,
         |  t1.error_type,
         |  t1.conduct_type,
         |  t1.ac_is_run_ontime,
         |  t1.sim1,
         |  t1.sim5,
         |  t1.if_evaluate_time,
         |  t1.transoport_level,
         |  t1.last_update_tm,
         |  t1.task_subid,
         |  t1.start_longitude,
         |  t1.start_latitude,
         |  t1.end_longitude,
         |  t1.end_latitude,
         |  t1.std_id,
         |  t1.inc_day
         |from(
         |    select
         |      task_subid,
         |      task_area_code,
         |      if(child_carrier_name is not null and child_carrier_name <> '',child_carrier_name,carrier_name) as carrier_name,
         |      sf_outer_vehicle_from,
         |      inc_day,
         |      carrier_type,
         |      line_code,
         |      start_dept,
         |      end_dept,
         |      driver_name,
         |      main_driver_account,
         |      start_longitude,
         |      start_latitude,
         |      end_longitude,
         |      end_latitude,
         |      error_type,
         |      conduct_type,
         |      ac_is_run_ontime,
         |	  vehicle_type,
         |   	vehicle_serial,
         |	  src,
         |	  case src
         |       when '0' then '价值线路'
         |       when '1' then '省钱线路'
         |       when '2' then '省里程线路'
         |       when '3' then 'GIS推送'
         |       when '4' then 'pns_经验'
         |       when '5' then 'pns_传统'
         |       when '6' then 'pns_高德'
         |       when '7' then '自选线路'
         |       else '未知'
         |       end as  src_name,
         |    sim1,
         |    sim5,
         |    if_evaluate_time,
         |    transoport_level,
         |    last_update_tm,
         |    std_id
         |    from
         |      dm_gis.eta_std_line_recall_result
         |    where
         |      inc_day >= '$DayBefore7'
         |      and inc_day <= '$DayBefore1'
         |  ) t1
         |  left join (
         |    select
         |      area_code as code,
         |      area_name
         |    from
         |      dm_gis.dim_area_code_mapping
         |    union all
         |    select
         |      express_code as code,
         |      area_name
         |    from
         |      dm_gis.dim_area_code_mapping
         |  ) t2 on t1.task_area_code = t2.code
         |""".stripMargin

    println(recall_querySql)
    val recallResultDF = spark.sql(recall_querySql)
    recallResultDF
  }

  /**
   *  从 dm_gis.eta_std_line_conf 取数，获取配置详情表全量数据
   * @param spark
   */
  def getStdlineConfData(spark: SparkSession) = {
    val conf_querySql =
      s"""
         |select
         |  std_id,
         |  add_reason,
         |  create_time
         |from
         |  dm_gis.eta_std_line_conf
         |where
         |  is_econ = 0
         |""".stripMargin

    println(conf_querySql)
    val recallResultDF = spark.sql(conf_querySql)
    recallResultDF
  }

  /**
   * 从表 dm_gis.eta_std_line_recall 取数
   * @param spark
   * @param DayBefore1
   * @return
   */
  def getLineRecallData(spark: SparkSession, DayBefore1: String) = {
    val recall_querySql =
      s"""
         |select
         |  task_area_code
         |  ,carrier_name
         |  ,task_id
         |  ,task_subid
         |  ,conduct_type
         |  ,line_code
         |  ,carrier_type
         |  ,vehicle_type
         |  ,src
         |  ,start_dept
         |  ,end_dept
         |  ,log_dist
         |  ,pns_dist
         |  ,rt_dist
         |  ,accrual_dist
         |  ,accrual_dist_type
         |  ,driver_id
         |  ,driver_name
         |  ,task_inc_day
         |  ,actual_depart_tm
         |  ,std_coords
         |  ,error_type
         |  ,sim1
         |  ,sim5
         |  ,require_category
         |  ,vehicle_serial
         |  ,main_driver_account
         |  ,std_id
         |  ,inc_day
         |from(
         |    select
         |      task_area_code
         |      ,carrier_name
         |      ,task_id
         |      ,task_subid
         |      ,conduct_type
         |      ,line_code
         |      ,carrier_type
         |      ,vehicle_type
         |      ,src
         |      ,start_dept
         |      ,end_dept
         |      ,log_dist
         |      ,pns_dist
         |      ,rt_dist
         |      ,accrual_dist
         |      ,accrual_dist_type
         |      ,driver_id
         |      ,driver_name
         |      ,task_inc_day
         |      ,actual_depart_tm
         |      ,std_coords
         |      ,error_type
         |      ,sim1
         |      ,sim5
         |      ,require_category
         |      ,vehicle_serial
         |      ,main_driver_account
         |      ,std_id
         |      ,inc_day
         |      ,row_number() over(partition by task_subid order by last_update_tm desc) rn
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day = '$DayBefore1'
         |  ) t1
         |where
         |  rn = 1
         |""".stripMargin

    println(recall_querySql)
    val recallRDD: RDD[JSONObject] = SparkUtils.getRowToJson(spark, recall_querySql)
    recallRDD
  }

  /**
   * 根据接口返回的json结果content拼接字段处理，获取路况异常类型 roadcdt_type
   * @param content
   * @return
   */
  def getRoadcdtType(content: String) = {

    val roadcdt_type_arr = new ArrayBuffer[String]()
    if(content.contains("施工")){
      roadcdt_type_arr.append("1")
    }
    if(content.contains("封路")){
      roadcdt_type_arr.append("2")
    }
    if(content.contains("疫情")){
      roadcdt_type_arr.append("3")
    }
    if(roadcdt_type_arr.isEmpty){
      roadcdt_type_arr.append("0")
    }
    val roadcdt_type = roadcdt_type_arr.mkString("|")
    roadcdt_type
  }

  /**
   * 解析 qm_point接口返回值
   * @param ret
   * @return
   */
  def parseQMPointHttpData(ret: JSONObject): (String, String, String, String) = {

    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        logger.error("获取接口数据失败: " + ret.getString("info"))
        return (codeStatue, "请求失败", ret.getString("info"), null)
      } else {

        //依次遍历paths、steps、links、rtic_event数组，取出 content 字段拼接
        val content_arr = new ArrayBuffer[String]()
        try{
          val paths_arr = ret.getJSONObject("route").getJSONArray("paths")
          for(i <- 0 until paths_arr.size){
            val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")

            for(j <- 0 until steps_arr.size){
              val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")

              for(k <- 0 until links_arr.size){
                val event_arr = links_arr.getJSONObject(k).getJSONArray("rtic_event")

                for(n <- 0 until event_arr.size){
                  val content = event_arr.getJSONObject(n).getString("content")
                  content_arr.append(content)
                }
              }
            }
          }
        }catch {
          case e: Exception => logger.error(e)
        }
        val content = content_arr.mkString(",")

        // 对获取返回的json结果content拼接字段处理,得到roadcdt_type
        val roadcdt_type = getRoadcdtType(content)

        return (codeStatue, "成功", content, roadcdt_type)
      }
    }
    ("2", "请求失败", null, null)
  }

  /**
   * 调 qm_point接口
   * @param spark
   * @param dataDF
   */
  def runQMPointInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val std_coords = JSONUtil.getJsonVal(obj, "std_coords", "")
    //将数据转换成接口需要的样式
    val date = timeToCustomTime(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
    val points = stdCoordsToPoints(std_coords)

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("opt", "sf4")
    param.put("strategy", "4")
    param.put("vehicle", vehicle_type)
    param.put("plandate", date)
    param.put("points", points)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值,获取roadcdt_type
    val httpData: (String, String, String, String) = parseQMPointHttpData(retJSONObject)
    obj.put("roadcdt_type",httpData._4)

    // 调用标准线路配置查询接口
    val get_line_obj = runGetLineInteface(GET_LINE_AK, obj)

    get_line_obj
  }

  /**
   * 解析 标准线路配置查询接口返回值
   * @param ret
   * @return
   */
  def parseGetLineHttpData(ret: JSONObject): (String, String, String, String) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, "请求失败", msg, null)
      } else {
        var updateTime = ""
        try{
          updateTime = ret.getJSONObject("result").getJSONArray("list").getJSONObject(0).getString("updateTime")
          //          std_id_update = timeToCustomTime(updateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMdd")
        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", null, updateTime)
      }
    }
    ("2", "请求失败", null, null)
  }

  /**
   * 调用标准线路配置查询接口
   * @param spark
   * @param dataDF
   */
  def runGetLineInteface(ak:String, obj: JSONObject): JSONObject = {
    val std_id = JSONUtil.getJsonVal(obj, "std_id", "")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "80006349")
    param.put("stdId", std_id)
    param.put("containDeleted", "true")
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(GET_LINE,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String, String) = parseGetLineHttpData(retJSONObject)
    obj.put("updateTime",httpData._4)
    obj.put("msg",httpData._3)
    obj.put("result",httpData._2)
    obj.put("codeStatue",httpData._1)
    obj.put("get_line_param",param.toJSONString)
    obj
  }

  /**
   * 从表 ods_shiva_ground.tm_abnormity_report 取数
   * @param spark
   * @param DayBefore1
   * @return
   */
  def getAbnormityData(spark: SparkSession, DayBefore1: String, DayBefore7: String) = {
    val abnormity_querySql =
      s"""
         |select
         |  type
         |  ,description
         |  ,city_name
         |  ,address
         |  ,create_time
         |  ,concat(own_dept_code,driver_task_id) as task_id
         |from ods_shiva_ground.tm_abnormity_report
         |where inc_day >= '$DayBefore7' and inc_day <= '$DayBefore1'
         |""".stripMargin

    println(abnormity_querySql)
    val abnormityDF = spark.sql(abnormity_querySql)
    abnormityDF
  }


}
