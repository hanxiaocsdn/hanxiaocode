package com.sf.gis.scala.lss.application

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.lss.application.StandardLineOperationIndexStatistics22.{getRecallResultData, getStdlineConfData, getStdlineData}
import com.sf.gis.scala.lss.utils.Functions.getDist
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
 * 承运商维度执行、准点、成本统计
 * 需求方：张翠霞（01369612）
 * @author 徐游飞（01417347）
 * 任务ID：765023
 * 任务名称：标准线路承运商维度执行准点成本统计
 */
object GisEtaStdLineRrecallExeOntiemeCost {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  // 计算标准线路执行情况每日统计表（拆经停）
  def etaStdLineRecallDaily(spark: SparkSession, dayBefore1: String, dayBefore7: String) = {

    import spark.implicits._
    // 获取eta标准线路表数据
    val recallResultDF = getRecallResultData(spark, dayBefore1, dayBefore7)
    // 获取路况异常数据
    val stdlineDF = getStdlineData(spark, dayBefore1, dayBefore7)
    // 获取配置详情表数据
    val stdlineConfDF = getStdlineConfData(spark)

    // 统计任务数
    val df_recall_daily = recallResultDF
      .withColumn("distances", getDist($"start_longitude", $"start_latitude", $"end_longitude", $"end_latitude"))
      .withColumn("mileage_type", when('distances.cast("double") <= 0.4, "是").otherwise("否"))
      .join(stdlineDF, Seq("task_subid", "inc_day"), "left")
      .join(stdlineConfDF,Seq("std_id"),"left")
      .withColumn("rn", row_number().over(Window.partitionBy("task_subid").orderBy(desc("last_update_tm"))))
      .filter('rn === 1)
      .withColumn("add_src",when('src =!= 0,"标准")
        .when('src === 0 and 'add_reason.contains("融合"),"融合")
        .when('src === 0 and !'add_reason.contains("融合") and 'add_reason.contains("新方案"),"标准新方案")
        .otherwise("标准"))
      .withColumn("create_date",substring('create_time,0,10))
      // 类型转换，方便后续判断
      .withColumn("sim1",'sim1.cast("double"))
      .withColumn("sim5",'sim5.cast("double"))
      .withColumn("if_evaluate_time",'if_evaluate_time.cast("double"))
      .withColumn("ac_is_run_ontime",'ac_is_run_ontime.cast("double"))
      .withColumn("transoport_level",'transoport_level.cast("double"))
      .withColumn("conduct_type",'conduct_type.cast("double"))
      .withColumn("require_category",'require_category.cast("double"))
      // 分组统计
      .groupBy("task_area_code","task_area_name","carrier_name","carrier_type","line_code","start_dept","end_dept","driver_name",
        "main_driver_account","vehicle_type","src","src_name","inc_day","add_src","create_date","sf_outer_vehicle_from","vehicle_serial")
      .agg(
        count(when('error_type =!= "0", 1).otherwise(null)) as "err_num",
        count(when('sim1.isNull or 'sim1 === -1 or 'sim5.isNull or 'sim5 === -1, 1).otherwise(null)) as "sim_error_num",
        count(when('if_evaluate_time === 1, 1).otherwise(null)) as "eval_task_num",
        count(when('if_evaluate_time === 1 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num",
        count(when('if_evaluate_time === 1 and ('transoport_level === 1 or 'transoport_level === 2), 1).otherwise(null)) as "eval_task_num_trunk",
        count(when('if_evaluate_time === 1 and ('transoport_level === 1 or 'transoport_level === 2) and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num_trunk",
        count(when('if_evaluate_time === 1 and 'transoport_level === 3, 1).otherwise(null)) as "eval_task_num_branch",
        count(when('if_evaluate_time === 1 and 'transoport_level === 3 and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "eval_ontime_num_branch",
        count(when('mileage_type === "是", 1).otherwise(null)) as "near_area_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and 'conduct_type === 3 and 'error_type === "0", 1).otherwise(null)) as "unexecuted_num_tmp",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and ('conduct_type === 1 or 'conduct_type === 2) and 'error_type === "0", 1).otherwise(null)) as "execute_num",
        count('task_subid) as "all_task_num",
        count(when('ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and ('conduct_type === 1 or 'conduct_type === 2) and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "execute_ontime_num",
        count(when('sim1.isNotNull and 'sim1 =!= -1 and 'sim5.isNotNull and 'sim5 =!= -1 and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "unexecuted_ontime_num_tmp",
        count(when('roadcdt_type =!= "0" and ('type === "7" or 'type === "8" or 'type === "16") and 'conduct_type === 3 and 'error_type === "0", 1).otherwise(null)) as "roaderr_num",
        count(when('roadcdt_type =!= "0" and ('type === "7" or 'type === "8" or 'type === "16") and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1, 1).otherwise(null)) as "ontime_roaderr_num",
        count(when('require_category === 5 and 'conduct_type === 3 and 'error_type === "0",1).otherwise(null)) as "require_del_num",
        count(when('require_category === 5 and 'conduct_type === 3 and 'error_type === "0" and 'ac_is_run_ontime === 1,1).otherwise(null)) as "ontime_require_del_num"
      )
      .withColumn("unexecuted_num", 'unexecuted_num_tmp - 'roaderr_num - 'require_del_num)
      .withColumn("unexecuted_ontime_num",'unexecuted_ontime_num_tmp - 'ontime_roaderr_num - 'ontime_require_del_num)
      .withColumn("grd2",concat_ws("_",'task_area_code,'carrier_name,'sf_outer_vehicle_from,'inc_day,'line_code,'vehicle_serial))

    // 标准线路执行情况每日统计表（拆经停,车牌运营商维度） 保存至hive
    val cols_recall_daily = spark.sql("""select * from dm_gis.eta_std_line_recall_daily_cys limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_recall_daily.select(cols_recall_daily: _*), Seq("inc_day"), "dm_gis.eta_std_line_recall_daily_cys")

    df_recall_daily
  }

  def getEtaStdLineRecallCostGrd2(spark: SparkSession, dayBefore1: String, dayBefore7: String) = {

    import spark.implicits._
    val grd2_sql =
      s"""
         |select
         |  grd2,
         |  num,
         |  miles_ave,
         |  road_fee_ave,
         |  fuel_cost_ave,
         |  sum_cost_ave,
         |  exe_num,
         |  exe_miles_ave,
         |  exe_road_fee_ave,
         |  exe_fuel_cost_ave,
         |  exe_sum_cost_ave,
         |  unexe_num,
         |  unexe_miles_ave,
         |  unexe_road_fee_ave,
         |  unexe_fuel_cost_ave,
         |  unexe_sum_cost_ave,
         |  diff_miles,
         |  diff_road_fee,
         |  diff_fuel_cost,
         |  diff_sum_cost,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall_cost_grd2
         |where
         |  inc_day >= '$dayBefore7'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    val df_grd2 = spark.sql(grd2_sql)
      // 根据grd2去重，保留inc_day最新的一条
      .withColumn("rn", row_number().over(Window.partitionBy('grd2).orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .drop("rn","inc_day")

    df_grd2
  }

  // 计算执行&准点&成本统计表
  def getEtaStdLineRecallExeOntiemeCost(spark: SparkSession, dayBefore1: String, dayBefore7: String) = {
    import spark.implicits._
    // 获取成本统计表grd2
    val df_grd2 = getEtaStdLineRecallCostGrd2(spark,dayBefore1,dayBefore7)
    // 计算标准线路执行情况每日统计表（拆经停）
    val df_recall_daily = etaStdLineRecallDaily(spark,dayBefore1,dayBefore7)

    val df_exe_ontieme_cost = df_recall_daily
      .filter('carrier_type =!= 0)  //过滤仅统计外包车辆
      .groupBy("grd2")
      .agg(
        max("task_area_code") as "task_area_code",
        max("carrier_name") as "carrier_name",
        max("sf_outer_vehicle_from") as "sf_outer_vehicle_from",
        max("inc_day") as "inc_day",
        max("line_code") as "line_code",
        max("vehicle_serial") as "vehicle_serial",
        countDistinct("line_code") as "line_num",
        countDistinct("vehicle_serial") as "car_num",
        sum("all_task_num") as "all_task_num",
        sum("ontime_num") as "ontime_num",
        sum("execute_num") as "execute_num",
        sum("unexecuted_num") as "unexecuted_num",
        sum("execute_ontime_num") as "execute_ontime_num",
        sum("unexecuted_ontime_num") as "unexecuted_ontime_num",
        sum("err_num") as "err_num",
        sum("roaderr_num") as "roaderr_num",
        sum("sim_error_num") as "sim_error_num",
        sum("eval_task_num") as "eval_task_num",
        sum("eval_ontime_num") as "eval_ontime_num",
        sum("near_area_num") as "near_area_num"
      )
      .join(df_grd2,Seq("grd2"),"left")
      .withColumn("ontime_rate",round('ontime_num / 'all_task_num,2))
      .withColumn("exe_rate",round('execute_num / ('execute_num + 'unexecuted_num),2))
      .withColumn("exe_ontime_rate",round('execute_ontime_num / 'execute_num,2))
      .withColumn("unexe_ontime_rate",round('unexecuted_ontime_num / 'unexecuted_num,2))
      .withColumn("cost_save",'diff_sum_cost * 'execute_num)
      .withColumn("cost_waste",abs('diff_sum_cost * 'unexecuted_num))

    // 执行&准点&成本统计表 保存至hive
    val cols_all = spark.sql("""select * from dm_gis.eta_std_line_recall_exe_ontieme_cost limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_exe_ontieme_cost.select(cols_all: _*), Seq("inc_day"), "dm_gis.eta_std_line_recall_exe_ontieme_cost")

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    // 计算执行&准点&成本统计表
    getEtaStdLineRecallExeOntiemeCost(spark,dayBefore1,dayBefore7)

    logger.error("++++++++  任务完成 20231016  ++++")

    spark.stop()
  }

}
