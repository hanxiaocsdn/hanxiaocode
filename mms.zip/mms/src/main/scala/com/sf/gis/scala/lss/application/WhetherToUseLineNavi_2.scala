package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK

/**
 * GIS_LSS_MMS:【导航标准线路服务】任务导航全流程表需求_V1.0
 * 需求方：陈俏秀（80006160）
 * @author 徐游飞（01417347）
 * 任务ID：486208
 * 任务名称：全程是否使用导航执行判断_2
 */
object WhetherToUseLineNavi_2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |    start_time
          |    end_time
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val start_time = args(0)
    val end_time = args(1)

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231024  ++++")

    run(spark, start_time, end_time)

    logger.error("++++++++  任务结束 20231024  ++++")
    spark.stop()
  }

  /**
   * 获取导航结果表1数据
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getLineTaskData(spark: SparkSession, end_time: String) = {

    import spark.implicits._
    val querySql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  plan_depart_tm,
         |  line_distance,
         |  actual_run_time,
         |  line_time,
         |  if(actual_run_time - 1 <= line_time, 1, 0) as ac_is_run_ontime,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  line_require_id,
         |  end_sortnum,
         |  start_outer_add_code,
         |  end_outer_add_code,
         |  if_evaluate_time,
         |  coalesce(start_outer_add_code, start_dept) as src_deptcode,
         |  coalesce(end_outer_add_code, end_dept) as dest_deptcode,
         |  last_update_tm
         |from
         |  dm_gis.eta_std_line_task
         |where
         |  inc_day = '$end_time'
         |""".stripMargin
    println(querySql)
    val lineTaskDF = spark.sql(querySql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id, 'start_outer_add_code, 'start_dept, 'end_outer_add_code, 'end_dept).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)

    val mergeSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.merge_navi_daily_log
         |where
         |  inc_day = '$end_time'
         |""".stripMargin
    println(mergeSql)
    val naviDF = spark.sql(mergeSql)

    (lineTaskDF,naviDF)
  }


  /**
   * 统计任务全程使用导航判断表（拆经停任务）
   * @param spark
   * @param resultDF
   * @param end_time
   */
  def taskNaviResult(spark: SparkSession, resultDF: DataFrame, end_time: String) = {

    import spark.implicits._
    val naviResultDF = resultDF
      .groupBy("task_id", "start_dept", "end_dept", "start_outer_add_code", "end_outer_add_code", "actual_run_time", "ac_is_run_ontime", "pull_navitype", "task_subid", "task_area_code")
      .agg(
        //        min("navi_starttime") as "navi_starttime",  // v1.0 逻辑
        //        max("navi_endtime") as "navi_endtime",      // v1.0 逻辑
        concat_ws(",", collect_list(when('req_type === "top3", 'navi_starttime))) as "navi_starttime", // v1.1 逻辑
        concat_ws(",", collect_list(when('req_type === "top3", 'navi_endtime))) as "navi_endtime", // v1.1 逻辑
        sum(when('req_type === "top3", 'navi_time).otherwise(0)) / 60 as "navi_time",
        sum(when('req_type === "top3", 'navi_distance).otherwise(0)) as "navi_distance",
        max("line_distance") as "line_distance",
        countDistinct(when('type === 1 or 'type === 9, 'navi_id).otherwise(null)) as "navi_count",
        count(when('req_type === "yaw", 'navi_id).otherwise(null)) as "yaw_count"
      )
      .withColumn("is_navi", when('line_distance >= 0 and 'line_distance <= 50.0 and 'navi_time / 'actual_run_time > 0.75, 1)
        .when('line_distance > 50.0 and 'line_distance <= 100.0 and 'navi_time / 'actual_run_time > 0.8, 1)
        .when('line_distance > 100.0 and 'line_distance <= 500.0 and 'navi_time / 'actual_run_time > 0.85, 1)
        .when('line_distance > 500.0 and 'navi_time / 'actual_run_time > 0.9, 1)
        .otherwise(0))
      .withColumn("inc_day", lit(s"$end_time"))
      .coalesce(20)

    val cols_2 = spark.sql("""select * from dm_gis.gis_std_line_task_navi_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, naviResultDF.select(cols_2: _*), Seq("inc_day"), "dm_gis.gis_std_line_task_navi_result")

  }

  /**
   * 统计任务全程使用导航判断表（不拆经停任务）
   * @param spark
   * @param resultDF
   * @param end_time
   */
  def taskNaviResultTotal(spark: SparkSession, resultDF: DataFrame, end_time: String) = {

    import spark.implicits._
    val naviResultTotalDF = resultDF
      .withColumn("rn", row_number().over(Window.partitionBy("task_subid").orderBy(desc("line_distance"))))
      .groupBy("task_id", "task_area_code")
      .agg(
        sum(when('rn === 1, 'line_distance).otherwise(0)) as "task_line_distance",
        sum(when('rn === 1, 'line_time).otherwise(0)) as "task_line_time",
        sum(when('rn === 1, 'actual_run_time).otherwise(0)) as "task_actual_run_time",
        max(when('pull_navitype === 1, 1).when('pull_navitype === 0, 0).otherwise(-1)) as "task_pull_navitype",
        concat_ws(",", collect_list(when('req_type === "top3", 'navi_starttime))) as "task_navi_starttime",
        concat_ws(",", collect_list(when('req_type === "top3", 'navi_endtime))) as "task_navi_endtime",
        sum(when('req_type === "top3", 'navi_time).otherwise(0)) / 60 as "task_navi_time",
        sum(when('req_type === "top3", 'navi_distance).otherwise(0)) as "task_navi_distance",
        countDistinct(when('type === 1 or 'type === 9, 'navi_id).otherwise(null)) as "task_navi_count",
        count(when('req_type === "yaw", 'navi_id).otherwise(null)) as "task_yaw_count"
      )
      .withColumn("task_is_run_ontime", when('task_actual_run_time - 'task_line_time <= 1, 1).otherwise(0))
      .withColumn("task_is_navi", when('task_line_distance >= 0 and 'task_line_distance <= 50.0 and 'task_navi_time / 'task_actual_run_time > 0.75, 1)
        .when('task_line_distance > 50.0 and 'task_line_distance <= 100.0 and 'task_navi_time / 'task_actual_run_time > 0.8, 1)
        .when('task_line_distance > 100.0 and 'task_line_distance <= 500.0 and 'task_navi_time / 'task_actual_run_time > 0.85, 1)
        .when('task_line_distance > 500.0 and 'task_navi_time / 'task_actual_run_time > 0.9, 1)
        .otherwise(0))
      .drop("rn")
      .withColumn("inc_day", lit(s"$end_time"))
      .coalesce(20)

    val cols_3 = spark.sql("""select * from dm_gis.gis_std_line_task_navi_result_total limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, naviResultTotalDF.select(cols_3: _*), Seq("inc_day"), "dm_gis.gis_std_line_task_navi_result_total")

  }


  def run(spark: SparkSession, start_time: String, end_time: String) = {

    // 获取导航结果表1数据
    val (lineTaskDF,naviDF) = getLineTaskData(spark, end_time)

    import spark.implicits._
    val resultDF = lineTaskDF
      .join(naviDF, Seq("task_id", "src_deptcode", "dest_deptcode"), "left")
      .withColumn("pull_navitype", max(when('pull_navitype === 1, 1).when('pull_navitype === 0, 0).otherwise(-1))
        .over(Window.partitionBy("task_id", "start_outer_add_code", "start_dept", "end_outer_add_code", "end_dept", "actual_run_time")))
      .withColumn("inc_day", lit(end_time))
      .persist(MEMORY_AND_DISK)

    val cols_1 = spark.sql("""select * from dm_gis.gis_std_line_task_navi_daily limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, resultDF.coalesce(100).select(cols_1: _*), Seq("inc_day"), "dm_gis.gis_std_line_task_navi_daily")

    // 统计任务全程使用导航判断表（拆经停任务）
    taskNaviResult(spark, resultDF, end_time)
    // 统计任务全程使用导航判断表（不拆经停任务）
    taskNaviResultTotal(spark, resultDF, end_time)

    resultDF.unpersist()
  }

}
