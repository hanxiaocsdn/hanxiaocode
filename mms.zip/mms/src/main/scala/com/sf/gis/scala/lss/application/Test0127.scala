package com.sf.gis.scala.lss.application

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession


/**
 * (临时任务，需修改)
 */
object Test0127 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)

    spark.udf.register("getPenaltyTag", getExceptionPenaltyTag _)
    val sql =
      s"""
         |insert overwrite table dm_gis.dwd_operation_task_statistic_di partition (inc_day=$dayBefore1)
         |select
         |  task_end_date,
         |  task_area_code,
         |  carrier_name,
         |  require_category,
         |  transport_level,
         |  in_service,
         |  vehicle_source,
         |  capacity_reource_type,
         |  carrier_type,
         |  sum(if(is_run_ontime in (1, 2), 1, 0)) as  ontime_num,
         |  sum(if(is_run_ontime in (0, 3), 1, 0)) as  not_ontime_num,
         |  sum(if(is_run_ontime = -1, 1, 0)) as  not_check_num,
         |  sum(if(exception_type like '%轨迹%', 1, 0)) as  track_penalty_num,
         |  sum(if(exception_type like '%时效%', 1, 0)) as  timing_penalty_num,
         |  sum(if(getPenaltyTag(exception_type, '轨迹', exception_penalty, '免责'), 1, 0)) as  track_penalty_exemp_num,
         |  sum(if(getPenaltyTag(exception_type, '轨迹', exception_penalty, '不免责'), 1, 0)) as  track_penalty_no_exemp_num,
         |  sum(if(getPenaltyTag(exception_type, '轨迹', exception_penalty, '不确定'), 1, 0)) as  track_penalty_uncertain_num,
         |  sum(if(getPenaltyTag(exception_type, '时效', exception_penalty, '免责'), 1, 0)) as  timing_penalty_exemp_num,
         |  sum(if(getPenaltyTag(exception_type, '时效', exception_penalty, '不免责'), 1, 0)) as  timing_penalty_no_exemp_num,
         |  sum(if(getPenaltyTag(exception_type, '时效', exception_penalty, '不确定'), 1, 0)) as  timing_penalty_uncertain_num,
         |
         |  sum(if(exceptioni_penalty_labor_system like '%审核免责%', 1, 0)) as  labor_exemption_num,
         |  sum(if(exceptioni_penalty_labor_system like '%自动免责%', 1, 0)) as  auto_exemption_num,
         |  sum(max_continueTm_1h) as  max_continueTm_1h_num,
         |  sum(track_penalty_amount) as  track_penalty_amount_num,
         |  sum(if(timing_penalty_responsibility = '主观', 1, 0)) as  timing_responsibility_sub_num,
         |  sum(if(timing_penalty_responsibility = '客观', 1, 0)) as  timing_responsibility_ob_num,
         |  sum(if(timing_penalty_responsibility = '不能判断', 1, 0)) as  timing_responsibility_jud_num,
         |  sum(if(responsibility_reason_conduct like '%未执行标准线路%', 1, 0)) as  responsibility_conduct_num,
         |  sum(if(responsibility_reason_conduct like '%主观停留%', 1, 0)) as  responsibility_stay_num,
         |  sum(if(responsibility_reason_conduct like '%服务区超时休息%', 1, 0)) as  responsibility_service_num,
         |  sum(if(responsibility_reason_conduct like '%拥堵%', 1, 0)) as  responsibility_jam_num,
         |  sum(if(responsibility_reason_conduct like '%封路%', 1, 0)) as  responsibilityroad_num,
         |  sum(emergent_need_deal_count) as  emergent_need_deal_total,
         |  sum(emergent_deal_count) as  emergent_deal_total,
         |  sum(emergent_timely_response_count) as  emergent_timely_response_total,
         |  sum(emergent_response_tm_sum) as  emergent_response_tm_total,
         |  sum(emergent_close_tm_sum) as  emergent_close_tm_total,
         |  sum(emergent_success_count) as  emergent_success_total,
         |  sum(timing_need_deal_count) as  timing_need_deal_total,
         |  sum(timing_deal_count) as  timing_dea_total,
         |  sum(timing_timely_response_count) as  timing_timely_response_total,
         |  sum(timing_response_tm_sum) as  timing_response_tm_total,
         |  sum(timing_close_tm_sum) as  timing_close_tm_total,
         |  sum(timing_success_count) as  timing_success_total,
         |  sum(timing_eliminate_count) as  timing_eliminate_total,
         |  sum(timing_neliminate_count) as  timing_neliminate_total,
         |  sum(track_need_deal_count) as  track_need_deal_total,
         |  sum(track_deal_count) as  track_deal_total,
         |  sum(track_timely_response_count) as  track_timely_response_total,
         |  sum(track_response_tm_sum) as  track_response_tm_total,
         |  sum(track_close_tm_sum) as  track_close_tm_total,
         |  sum(track_success_count) as  track_success_total,
         |  sum(track_eliminate_count) as  track_eliminate_total,
         |  sum(track_neliminate_count) as  track_neliminate_total,
         |  sum(major_alarm_anomaly) as  major_alarm_total,
         |  count(distinct task_id) as task_num
         |from(
         |    select
         |      actual_arrive_date as task_end_date,
         |      task_area_code,
         |      actual_carrier_name as carrier_name,
         |      require_category,
         |      transport_level,
         |      if(((carrier_type = '0' and imei = '1') or (carrier_type = '1' and in_service = '1')),1,0) as in_service,
         |      vehicle_source,
         |      capacity_reource_type,
         |      carrier_type,
         |      task_id,
         |      is_run_ontime,
         |      exception_type,
         |      exception_penalty,
         |      exceptioni_penalty_labor_system,
         |      max_continueTm_1h,
         |      track_penalty_amount,
         |      timing_penalty_responsibility,
         |      responsibility_reason_conduct,
         |      emergent_need_deal_count,
         |      emergent_deal_count,
         |      emergent_timely_response_count,
         |      emergent_response_tm_sum,
         |      emergent_close_tm_sum,
         |      emergent_success_count,
         |      timing_need_deal_count,
         |      timing_deal_count,
         |      timing_timely_response_count,
         |      timing_response_tm_sum,
         |      timing_close_tm_sum,
         |      timing_success_count,
         |      timing_eliminate_count,
         |      timing_neliminate_count,
         |      track_need_deal_count,
         |      track_deal_count,
         |      track_timely_response_count,
         |      track_response_tm_sum,
         |      track_close_tm_sum,
         |      track_success_count,
         |      track_eliminate_count,
         |      track_neliminate_count,
         |      major_alarm_anomaly,
         |      row_number() over(partition by task_id order by actual_arrive_tm desc) as rank
         |    from
         |      dm_gis.dwd_operation_task_day_di
         |    where
         |      inc_day = '$dayBefore1'
         |      and state = '6'
         |  ) t1
         |where
         |  t1.rank = 1
         |group by
         |  task_end_date,
         |  task_area_code,
         |  carrier_name,
         |  require_category,
         |  transport_level,
         |  in_service,
         |  vehicle_source,
         |  capacity_reource_type,
         |  carrier_type
         |""".stripMargin
    println(sql)
    spark.sql(sql)
    println("dm_gis.dwd_operation_task_statistic_di 表数据写入完成")

  }

  /**
   * udf: 计算 exception_penalty 是否包含免责
   *
   * @return
   */
  def getExceptionPenaltyTag(exception_type:String, type_tag: String, exception_penalty: String, penalty_tag: String): Boolean = {
    var ret = false
    if (StringUtils.isEmpty(exception_type) || StringUtils.isEmpty(exception_penalty)) {
      return ret
    }

    val type_splits = exception_type.split(",")
    val penalty_splits = exception_penalty.split(",")

    for(i <- 0 until type_splits.size){
      val type1 = type_splits(i)
      val penalty = penalty_splits(i)
      if (type1.equals(type_tag) && penalty.equals(penalty_tag)) {
        ret = true
      }
    }

    ret
  }


  def main(args: Array[String]): Unit = {

    val inc_day = DateUtil.getDayBefore(args(0), "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++20240131  任务开始 inc_day=$inc_day  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
