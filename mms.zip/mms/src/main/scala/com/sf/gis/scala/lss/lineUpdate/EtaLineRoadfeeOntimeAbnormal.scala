package com.sf.gis.scala.lss.lineUpdate

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.{parseQMPointHttpData, row2Json}
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.Abnormal
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.sf.gis.scala.lss.utils.StringUtils.stdCoordsToPoints
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：806717
 * 任务名称：异常数据标记明细表_456
 */
object EtaLineRoadfeeOntimeAbnormal {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val qmUrl: String = "http://rp-c-gd.int.sfcloud.local:1090/qm_point?"
  val qmAk: String = ""
  val parallelism = 10
  val akMinuLimit = 4000


  // 调qm接口
  def runQMInteface(ak:String, obj: JSONObject): JSONObject = {

    val axle_num = JSONUtil.getJsonVal(obj, "axle_num", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val points = JSONUtil.getJsonVal(obj, "rt_coords", "")
    val mload = JSONUtil.getJsonDouble(obj, "mload", 0.0)

    val test = 0
    val stype = 0
    val etype = 0
    val Mload = mload
    val axlenumber = axle_num
    val mode = 2
    val speed = 1
    val Toll = 1
    val retry_flag = 13

    //初始化接口请求参数
    val param = s"test=$test&stype=$stype&etype=$etype&Mload=$Mload&retry_flag=$retry_flag&vehicle=$vehicle&axlenumber=$axlenumber&mode=$mode&speed=$speed&Toll=$Toll&points=$points"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(qmUrl,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析qm接口返回值
    val newData: JSONObject =  parseQMPointHttpData(retJSONObject)
    obj.put("newData",newData)
    obj
  }

  // 获取单位油耗成本
  def getUniprice: UserDefinedFunction = udf((mload: String) => {
    var uniprice: Double = 0.0
    try {
      val mload_d = mload.toDouble
      if (mload_d < 3) uniprice = 0.84
      else if(mload_d >= 3 && mload_d < 5) uniprice = 0.88
      else if(mload_d >= 5 && mload_d < 7) uniprice = 1.07
      else if(mload_d >= 7 && mload_d < 14) uniprice = 1.36
      else if(mload_d >= 14 && mload_d < 20) uniprice = 1.51
      else if(mload_d >= 20 && mload_d < 30) uniprice = 1.88
      else if(mload_d >= 30) uniprice = 1.99
    } catch {
      case e: Exception => println("载重转换异常" + e.getMessage)
    }
    uniprice
  })

  def run(spark: SparkSession, dayBefore1: String, dayBefore31: String) = {

    // 获取需运营数据
    import spark.implicits._
    val operate_sql =
      s"""
         |select
         |  linevehicle,
         |  line_type,
         |  exe_ratio
         |from
         |  dm_gis.eta_line_need_operate
         |where
         |  inc_day = '$dayBefore1'
         |  and (line_type = '增量线路' or line_type = '执行率低线路')
         |""".stripMargin
    println("需运营明细表取数sql：")
    println(operate_sql)

    val tmp11_sql =
      s"""
         |select
         |  std_id,
         |  linevehicle,
         |  carrier_type,
         |  conduct_type,
         |  actual_depart_tm,
         |  ac_is_run_ontime,
         |  actual_capacity_load as mload
         |from
         |  dm_gis.eta_line_table_tmp11
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("tmp11明细表取数sql：")
    println(tmp11_sql)

    val distance_all_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  plan_depart_tm,
         |  line_code,
         |  stdid as std_id,
         |  jy_track2,
         |  axls_number,
         |  plan_time,
         |  vehicle_serial,
         |  actual_capacity_load as mload,
         |  vehicle_type,
         |  start_dist,
         |  end_dist
         |from
         |  dm_gis.eta_line_distance_detail_all
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("中间表33取数sql：")
    println(distance_all_sql)

    val operate_unexe_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  plan_depart_tm,
         |  line_code,
         |  group_label,
         |  axls_number,
         |  group_cnt,
         |  cdct_ontime_cnt,
         |  rt_coords,
         |  actual_capacity_load as mload,
         |  vehicle_serial,
         |  vehicle_type
         |from
         |  dm_gis.eta_line_need_operate_unexe
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("外包需运营线路未执行轨迹明细表（结果表2）取数sql：")
    println(operate_unexe_sql)

    val prices_sql =
      s"""
         |select
         |  fuel_prices,
         |  '$dayBefore1' as inc_day
         |from
         |  dm_gis.gis_fule_prices
         |where
         |  inc_day in (
         |    select
         |      t1.inc_day
         |    from
         |      dm_gis.gis_fule_prices t1
         |    where
         |      inc_day >= '$dayBefore31'
         |      and inc_day <= '$dayBefore1'
         |    group by
         |      inc_day
         |    order by
         |      inc_day desc
         |    limit 1
         |  )
         |""".stripMargin
    println("油价表取数sql：")
    println(prices_sql)
    val df_prices = spark.sql(prices_sql)

    // 司机线路数据
    val stdCoordsToPoints_udf = udf(stdCoordsToPoints _)
    val df_driver = spark.sql(operate_unexe_sql)  // df_driver
      .withColumn("rt_coords",stdCoordsToPoints_udf('rt_coords))  //将数据转换成接口需要的样式
      .withColumn("plan_time",substring('line_code,-4,4)) // 截取后四位
      .withColumn("line_type",lit("固定线路"))
      .withColumnRenamed("group_label","line_id")
      .withColumnRenamed("axls_number","axle_num")
      .withColumnRenamed("group_cnt","freq")
      .withColumnRenamed("cdct_ontime_cnt","ontime_cnt")
      .select("linevehicle","task_area_code","plan_depart_tm","line_code","line_id","rt_coords","plan_time","line_type","vehicle_serial","vehicle_type","axle_num","freq","ontime_cnt","mload")

    // 标准线路数据
    val df_operate = spark.sql(operate_sql)
    val df_std_id = spark.sql(tmp11_sql)
      .join(df_operate,Seq("linevehicle"),"inner")
      .withColumn("carrier_type_list", concat_ws("|",collect_list('carrier_type).over(Window.partitionBy('linevehicle))))
      .filter(!'carrier_type_list.contains("0") and 'conduct_type === "1")  // 获取纯外包任务(不包含0)
      .groupBy("std_id")
      .agg(
        count('std_id) as "freq",
        count(when('ac_is_run_ontime.cast("double") === 1.0,'std_id).otherwise(null)) as "ontime_cnt"
      )

    // 司机和标准线路数据合并 记做数据解df_line
    val df_line = spark.sql(distance_all_sql).filter('error_type === "0")  // 筛选距离正常数据
      .withColumn("line_id",'std_id)
      .withColumnRenamed("jy_track2","rt_coords")
      .withColumnRenamed("axls_number","axle_num")
      .withColumn("line_type",lit("标准线路"))
      .join(df_std_id,Seq("std_id"),"left")
      .select("linevehicle","task_area_code","plan_depart_tm","line_code","line_id","rt_coords","plan_time","line_type","vehicle_serial","vehicle_type","axle_num","freq","ontime_cnt","mload")
      .union(df_driver)

    val invokeCnt = df_line.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "806717", "异常数据标记明细表_456", "获取异常标记数据", qmUrl, qmAk, invokeCnt, parallelism)
    // 调 qm_point 接口
    val rdd_line = SparkNet.runInterfaceWithAkLimit(spark, df_line.rdd.map(row2Json), runQMInteface, parallelism, qmAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "  invokeCnt = " + invokeCnt)


    val df_roadfee_break_ontime = rdd_line.map(obj => {
      // 原始字段
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle","")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code","")
      val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm","")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val line_id = JSONUtil.getJsonVal(obj, "line_id", "")
      val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
      val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
      val line_type = JSONUtil.getJsonVal(obj, "line_type", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val axle_num = JSONUtil.getJsonVal(obj, "axle_num", "")
      val mload = JSONUtil.getJsonVal(obj, "mload", "")
      val freq = JSONUtil.getJsonDouble(obj, "freq", 0.0)
      val ontime_cnt = JSONUtil.getJsonDouble(obj, "ontime_cnt", 0.0)

      // qm 接口返回值
      val newData_obj = JSONUtil.getJsonObjectMulti(obj, "newData")
      val t_status = JSONUtil.getJsonDouble(newData_obj, "new_status", -99)
      val t_distance = JSONUtil.getJsonVal(newData_obj, "new_distance", "")
      val t_duration = JSONUtil.getJsonVal(newData_obj, "new_duration", "")
      val t_tolls = JSONUtil.getJsonDouble(newData_obj, "new_tolls", -99)
      val t_etc_toll = JSONUtil.getJsonVal(newData_obj, "new_etc_toll", "")
      val t_highspeed_distance = JSONUtil.getJsonDouble(newData_obj, "new_highspeed_distance", -99)
      val t_toll_distance = JSONUtil.getJsonDouble(newData_obj, "new_toll_distance", -99)
      val t_coords = JSONUtil.getJsonVal(newData_obj, "new_coords", "")
      val t_len_path = JSONUtil.getJsonDouble(newData_obj, "paths_num", 0.0).toInt
      val t_toll_name = JSONUtil.getJsonVal(newData_obj, "new_toll_name", "")

      var roadfee_flag = "no"
      if(t_status == 0 && t_tolls > 0){
        roadfee_flag = "yes"
      }else if(t_status == 0 && t_tolls == 0 && t_highspeed_distance == 0 && t_toll_distance == 0){
        roadfee_flag = "yes"
      }else if(t_status == 0 && t_tolls == 0 && t_toll_name.isEmpty){
        roadfee_flag = "yes"
      }

      // 测试字段
      val new_msg = JSONUtil.getJsonVal(newData_obj, "new_status", "")
      val new_param = JSONUtil.getJsonVal(newData_obj, "new_msg", "")

      Abnormal(linevehicle,task_area_code,plan_depart_tm,line_code,line_id,rt_coords,plan_time,line_type,vehicle_serial,vehicle_type,axle_num,freq,mload,ontime_cnt,t_status,
        t_distance,t_duration,t_tolls,t_etc_toll,t_highspeed_distance,t_toll_distance,t_coords,t_len_path,t_toll_name,roadfee_flag,new_msg,new_param)
    }).toDF()
      .withColumn("ontime_rate",when('freq === 0,1.0).otherwise('ontime_cnt / 'freq))
      .withColumn("error_type",when('roadfee_flag =!= "yes","收费异常")
        .when('t_len_path =!= 1,"匹配中断")
        .when('ontime_rate < 0.85 and 'line_type =!= "固定线路","准点率差")
        .otherwise("0"))
      .withColumn("inc_day",lit(dayBefore1))
      .join(df_prices,Seq("inc_day"),"left")
      .withColumn("uniprice",getUniprice('mload))
      .withColumn("jy_hundred_oil",'uniprice / 7 * 100)
      .withColumn("roadfee",'t_tolls.cast("double"))
      .withColumn("fuel_cost",'t_distance.cast("double")/1000/100 * 'jy_hundred_oil * 'fuel_prices.cast("double"))
      .withColumn("oil_fee",'t_distance.cast("double")/1000/100 * 'jy_hundred_oil)
      .withColumn("sum_cost",'roadfee + 'fuel_cost)


    // 中间表66 异常表（all）
    val cols_66 = spark.sql("""select * from dm_gis.eta_line_roadfee_break_ontime_abnormal limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_roadfee_break_ontime.coalesce(50).select(cols_66: _*), Seq("inc_day"), "dm_gis.eta_line_roadfee_break_ontime_abnormal")

  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore31 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 31)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1, dayBefore31)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
