package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK

/**
 * GIS_LSS_MMS:【导航标准线路服务】任务导航全流程表需求_V1.0
 * 需求方：陈俏秀（80006160）
 * @author 徐游飞（01417347）
 * 任务ID：875549
 * 任务名称：全程是否使用导航执行判断_1
 */
object WhetherToUseLineNavi_1 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |    start_time
          |    end_time
          |""".stripMargin)
      sys.exit(-1)
    }

    // 接收外部传递进来的变量
    val start_time = args(0)
    val end_time = args(1)

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231024  ++++")

    run(spark, start_time, end_time)

    logger.error("++++++++  任务结束 20231024  ++++")
    spark.stop()
  }


  /**
   * 获取top3入参表数据
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getTop3Parse(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  task_id,
         |  src_deptcode,
         |  dest_deptcode,
         |  navi_id,
         |  startx,
         |  starty,
         |  endx,
         |  endy,
         |  req_time,
         |  ft_url,
         |  request_id,
         |  econ_id,
         |  app_ver as sdk_ver
         |from
         |  dm_gis.gis_navi_top3_parse
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |  and service_id = 'SL'
         |""".stripMargin

    println(querySql)
    val top3ParseDF = spark.sql(querySql)
    top3ParseDF
  }

  /**
   * 获取top3出参表数据
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getTop3YawResult(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  request_id,
         |  strategy
         |from
         |  dm_gis.gis_navi_top3_yaw_result_parse
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |  and subtype = 'naviTop3V2LogResult'
         |  and route_index = 0
         |""".stripMargin

    println(querySql)
    val top3YawResultDF = spark.sql(querySql)
    top3YawResultDF
  }

  /**
   * 获取导航线路筛选表数据
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getPnsNavi(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  data
         |from
         |  dm_gis.gis_rss_pns_navi_select
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |""".stripMargin

    println(querySql)
    val pnsNaviRDD = SparkUtils.getRowToJson(spark, querySql)

    import spark.implicits._
    val pnsNaviDF = pnsNaviRDD.repartition(6000).map(obj => {
      val data = JSONUtil.getJsonVal(obj, "data", "")

      var dataObj = new JSONObject()
      try {
        dataObj = JSON.parseObject(data)
      } catch {
        case e: Exception => println(">>>导航线路数据转换异常：" + e)
      }

      val request_id = JSONUtil.getJsonVal(dataObj, "requestId", "")
      val noStdReasonType = JSONUtil.getJsonVal(dataObj, "noStdReasonType", "")
      val noStdReasonDetail = JSONUtil.getJsonVal(dataObj, "noStdReasonDetail", "")
      (request_id, noStdReasonType, noStdReasonDetail)
    }).toDF("request_id", "noStdReasonType", "noStdReasonDetail")
      .withColumn("rn", row_number().over(Window.partitionBy('request_id,'noStdReasonType,'noStdReasonDetail).orderBy(desc("request_id"))))
      .filter('rn === 1) // 去重
      .drop("rn")

    pnsNaviDF
  }

  /**
   * 获取客户端日志记录表数据
   *
   * @param spark
   * @param start_time
   * @param end_time
   */
  def getSDKNaviParse(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  navi_id,
         |  navi_type,
         |  navi_strategy,
         |  content,
         |  type,
         |  count(navi_id) as cn
         |from
         |  dm_gis.gis_navi_sdk_navi_parse
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |  and type in ('1','9')
         |group by
         |  navi_id,
         |  navi_type,
         |  navi_strategy,
         |  content,
         |  type
         |""".stripMargin

    println(querySql)
    val sdkNaviParseDF = spark.sql(querySql).drop("cn")
    sdkNaviParseDF
  }

  /**
   * 获取客户端日志记录表(全量数据计算得到pull_navitype)
   *
   * @param spark
   * @param start_time
   * @param end_time
   */
  def getSDKNaviParseTotal(spark: SparkSession, start_time: String, end_time: String) = {
    import spark.implicits._
    val querySql =
      s"""
         |select
         |  navi_id,
         |  pull_navitype
         |from
         |  dm_gis.gis_navi_sdk_navi_parse
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |""".stripMargin

    println(querySql)
    val sdkNaviParseTotalDF = spark.sql(querySql)
      .withColumn("pull_navitype", max(when('pull_navitype === 1, 1).when('pull_navitype === 0, 0).otherwise(-1)).over(Window.partitionBy("navi_id")))
      .withColumn("rn", row_number().over(Window.partitionBy("navi_id").orderBy(desc("pull_navitype"))))
      .filter('rn === 1)
      .drop("rn")
    sdkNaviParseTotalDF
  }

  /**
   * 获取navi之ETA结果汇总表1
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getEtaResult1Data(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  id,
         |  navi_starttime,
         |  navi_endtime,
         |  navi_time,
         |  src,
         |  strategy2,
         |  route_index,
         |  req_type,
         |  inc_day,
         |  count(id) as cn
         |from
         |  dm_gis.gis_navi_eta_result1
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |group by
         |  id,
         |  navi_starttime,
         |  navi_endtime,
         |  navi_time,
         |  src,
         |  strategy2,
         |  route_index,
         |  req_type,
         |  inc_day
         |""".stripMargin

    println(querySql)
    val etaResult1DF = spark.sql(querySql).drop("cn")
    etaResult1DF
  }

  /**
   * 获取navi之ETA结果汇总表2
   *
   * @param spark
   * @param start_time
   * @param end_time
   * @return
   */
  def getEtaResult2Data(spark: SparkSession, start_time: String, end_time: String) = {

    val querySql =
      s"""
         |select
         |  id,
         |  navi_id,
         |  navi_distance,
         |  similarity1,
         |  similarity5,
         |  inc_day,
         |  count(id) as cn
         |from
         |  dm_gis.gis_navi_eta_result2
         |where
         |  inc_day >= '$start_time'
         |  and inc_day <= '$end_time'
         |group by
         |  id,
         |  navi_id,
         |  navi_distance,
         |  similarity1,
         |  similarity5,
         |  inc_day
         |""".stripMargin

    println(querySql)
    val etaResult2DF = spark.sql(querySql).drop("cn")
    etaResult2DF
  }

  def run(spark: SparkSession, start_time: String, end_time: String) = {
//    // 获取导航结果表1数据
//    val lineTaskDF = getLineTaskData(spark, end_time)
    // 获取top3入参表数据
    val top3ParseDF = getTop3Parse(spark, start_time, end_time)  //2654400
    // 获取top3出参表数据
    val top3YawResultDF = getTop3YawResult(spark, start_time, end_time)  //1042597   可播
    // 获取导航线路筛选表数据
    val pnsNaviDF = getPnsNavi(spark, start_time, end_time)  //3890512  可播
    // 获取客户端日志记录表数据
    val sdkNaviParseDF = getSDKNaviParse(spark, start_time, end_time) // 370318
    // 获取客户端日志记录表(全量数据计算得到pull_navitype)
    val sdkNaviParseTotalDF = getSDKNaviParseTotal(spark, start_time, end_time) //2333990
    // 获取navi之ETA结果汇总表1数据
    val etaResult1DF = getEtaResult1Data(spark, start_time, end_time)  //1408203
    // 获取navi之ETA结果汇总表2数据
    val etaResult2DF = getEtaResult2Data(spark, start_time, end_time)  //1408205

    import spark.implicits._
    // 七张数据表关联得到任务导航明细汇总表（宽表）
    val etaResultDF = etaResult1DF.join(etaResult2DF, Seq("id", "inc_day"), "inner")
    val naviDF = top3ParseDF
      .join(broadcast(top3YawResultDF), Seq("request_id"), "left")
      .join(broadcast(pnsNaviDF), Seq("request_id"), "left")
      .join(broadcast(sdkNaviParseDF), Seq("navi_id"), "left")
      .join(broadcast(sdkNaviParseTotalDF), Seq("navi_id"), "left")
      .join(etaResultDF, Seq("navi_id"), "left")
      .withColumn("inc_day", lit(end_time))

    val cols_1 = spark.sql("""select * from dm_gis.merge_navi_daily_log limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, naviDF.coalesce(100).select(cols_1: _*), Seq("inc_day"), "dm_gis.merge_navi_daily_log")

  }

}
