package com.sf.gis.scala.lss.lineUpdate

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.Functions.getDist
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.{getGrp2, row2Json}
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.StartEndDist
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：801460
 * 任务名称：距离异常明细表_3
 */
object EtaLineDistanceAbnormal {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  val getLineUrl: String = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val getLineAk: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 4000

  // 解析标准线路查询接口返回值
  def parseGetLineData(ret: JSONObject): String = {

    val list_str = new StringBuilder
    var status = ""
    var cnt = ""
    var stdId = ""
    var isEcon = ""
    var routeIndex = ""
    var trackStartX = ""
    var trackStartY = ""
    var trackEndX = ""
    var trackEndY = ""
    var updateTime = ""
    var vehicle = ""
    var jyTrack2 = ""
    var lineDistance = ""
    var lineTime = ""
    var planTime = ""

    if (ret != null ) {
      //获取接口返回状态
      status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(status)) {
        logger.error("获取接口数据失败: " + ret.getJSONObject("result").getString("msg"))
        list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2##$lineDistance##$lineTime##$planTime##$routeIndex")

        return list_str.toString()
      } else {
        var list = new JSONArray()
        try {
          list = ret.getJSONObject("result").getJSONArray("list")
          cnt = ret.getJSONObject("result").getString("cnt")
        } catch {
          case _ =>
        }
        if(list.isEmpty){
          list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2##$lineDistance##$lineTime##$planTime##$routeIndex")
        }else{
          for(i <- 0 until  list.size()){
            stdId = list.getJSONObject(i).getString("stdId")
            isEcon = list.getJSONObject(i).getString("isEcon")
            trackStartX = list.getJSONObject(i).getString("trackStartX")
            trackStartY = list.getJSONObject(i).getString("trackStartY")
            trackEndX = list.getJSONObject(i).getString("trackEndX")
            trackEndY = list.getJSONObject(i).getString("trackEndY")
            updateTime = list.getJSONObject(i).getString("updateTime")
            vehicle = list.getJSONObject(i).getString("vehicle")
            jyTrack2 = list.getJSONObject(i).getString("jyTrack2")
            lineDistance = list.getJSONObject(i).getString("lineDistance")
            lineTime = list.getJSONObject(i).getString("lineTime")
            planTime = list.getJSONObject(i).getString("planTime")
            routeIndex = list.getJSONObject(i).getString("routeIndex")

            if(i.equals(list.size()-1)){
              // 最后一条数据结尾不加 @@ 分隔符
              list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2##$lineDistance##$lineTime##$planTime##$routeIndex")
            }else{
              list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2##$lineDistance##$lineTime##$planTime##$routeIndex@@")
            }
          }
        }
        return list_str.toString()
      }
    }
    list_str.append(s"$status##$cnt##$stdId##$isEcon##$trackStartX##$trackStartY##$trackEndX##$trackEndY##$updateTime##$vehicle##$jyTrack2##$lineDistance##$lineTime##$planTime##$routeIndex")
    list_str.toString()
  }

  // 调用标准线路查询接口
  def runGetLineInteface(ak:String, obj: JSONObject): JSONObject = {

    val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
    val arr = linevehicle.split("_")
    val lineCode = arr(0)
    val srcDeptcode = arr(1)
    val destDeptcode = arr(2)
    val vehicle = arr(3)

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "01369612")
    param.put("ak", ak)
    param.put("lineCode", lineCode)
    param.put("srcDeptcode", srcDeptcode)
    param.put("destDeptcode", destDeptcode)
    param.put("containDeleted","False")
    param.put("vehicle",vehicle)

    var retJSONObject = new JSONObject()
    if(!lineCode.isEmpty){  // 调接口前对主要参数过滤
      try {
        val retStr: String = HttpInvokeUtil.sendPost(getLineUrl,param.toJSONString,3)
        retJSONObject = JSON.parseObject(retStr)
      } catch {
        case e: Exception => logger.error(e)
      }
    }

    //解析接口返回值
    val httpData =  parseGetLineData(retJSONObject)
    obj.put("httpData",httpData)
    obj
  }

  def run(spark: SparkSession, dayBefore1: String) = {
    // 获取外包需运营线路未执行轨迹明细表数据(表2)
    import spark.implicits._
    val unexe_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_line_need_operate_unexe
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("结果表2取数sql：")
    println(unexe_sql)

    var rdd_unexe = spark.sql(unexe_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("plan_depart_tm"))))
      .filter('rn === 1) // 按 linevehicle 去重
      .drop("rn")
      .rdd.map(row2Json)

    val invokeCnt = rdd_unexe.count()
    // 调 GETLINE 接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "801460", "距离异常明细表_3", "距离异常任务获取", getLineUrl, getLineAk, invokeCnt, parallelism);
    rdd_unexe = SparkNet.runInterfaceWithAkLimit(spark, rdd_unexe, runGetLineInteface, parallelism, getLineAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "  invokeCnt = " + invokeCnt)

    val df_linevehicle = rdd_unexe.map(obj => {
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
      val start_outer_add_code = JSONUtil.getJsonVal(obj, "start_outer_add_code", "")
      val end_outer_add_code = JSONUtil.getJsonVal(obj, "end_outer_add_code", "")
      val actual_capacity_load = JSONUtil.getJsonVal(obj, "actual_capacity_load", "")
      val axls_number = JSONUtil.getJsonVal(obj, "axls_number", "")
      val start_type = JSONUtil.getJsonVal(obj, "start_type", "")
      val end_type = JSONUtil.getJsonVal(obj, "end_type", "")
      val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val ac_is_run_ontime = JSONUtil.getJsonVal(obj, "ac_is_run_ontime", "")
      val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
      val line_require_id = JSONUtil.getJsonVal(obj, "line_require_id", "")
      val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
      val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
      val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
      val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
      val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val task_inc_day = JSONUtil.getJsonVal(obj, "task_inc_day", "")
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val line_type = JSONUtil.getJsonVal(obj, "line_type", "")
      val exe_ratio = JSONUtil.getJsonVal(obj, "exe_ratio", "")
      val group_label = JSONUtil.getJsonVal(obj, "group_label", "")
      val httpData = JSONUtil.getJsonVal(obj, "httpData", "")
      val httpData_arr = httpData.split("@@")

      StartEndDist(line_code,task_area_code,start_dept,end_dept,vehicle_type,carrier_type,start_outer_add_code,end_outer_add_code,actual_capacity_load,axls_number,
        start_type,end_type,conduct_type,task_subid,std_id,ac_is_run_ontime,rt_coords,line_require_id,plan_depart_tm,start_longitude,start_latitude,
        end_longitude,end_latitude,vehicle_serial,task_inc_day,linevehicle,line_type,exe_ratio,group_label,httpData_arr)
    }).toDF()

    // 数据集df_distance
    val df_distance = df_linevehicle
      .withColumn("httpData", explode('httpData_arr))
      .withColumn("status", split('httpData, "##")(0))
      .withColumn("cnt", split('httpData, "##")(1))
      .withColumn("stdid", split('httpData, "##")(2))
      .withColumn("econ", split('httpData, "##")(3))
      .withColumn("track_start_x", split('httpData, "##")(4))
      .withColumn("track_start_y", split('httpData, "##")(5))
      .withColumn("track_end_x", split('httpData, "##")(6))
      .withColumn("track_end_y", split('httpData, "##")(7))
      .withColumn("update_time", split('httpData, "##")(8))
      .withColumn("vehicle", split('httpData, "##")(9))
      .withColumn("jy_track2", split('httpData, "##")(10))
      .withColumn("line_distance", split('httpData, "##")(11))
      .withColumn("line_time", split('httpData, "##")(12))
      .withColumn("plan_time", split('httpData, "##")(13))
      .withColumn("route_index", split('httpData, "##")(14))

      .withColumn("start_dist", getDist('track_start_x, 'track_start_y,'start_longitude, 'start_latitude))
      .withColumn("end_dist", getDist('track_end_x, 'track_end_y,'end_longitude,'end_latitude))
      .withColumn("error_type", when('start_dist <= 500 and 'end_dist <= 500, "0").otherwise("距离异常"))
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表3 距离异常数据表
    val cols_3 = spark.sql("""select * from dm_gis.eta_line_distance_abnormal limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_distance.filter('error_type === "距离异常").coalesce(50).select(cols_3: _*), Seq("inc_day"), "dm_gis.eta_line_distance_abnormal")

    // 中间表33 距离数据明细表（all）
    val cols_33 = spark.sql("""select * from dm_gis.eta_line_distance_detail_all limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_distance.coalesce(50).select(cols_33: _*), Seq("inc_day"), "dm_gis.eta_line_distance_detail_all")

    df_distance.unpersist()
  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
