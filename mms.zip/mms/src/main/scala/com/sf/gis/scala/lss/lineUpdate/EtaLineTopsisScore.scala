package com.sf.gis.scala.lss.lineUpdate

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.DouglasPeuckerAlgorithm.dpCoords
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.{getGrp2, isEmptyOrNull, row2Json, transformTrack}
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.{GroupLabel2, TopSIS}
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：807651
 * 任务名称：模型打分表_7
 */
object EtaLineTopsisScore {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def runTOPSIS(spark: SparkSession, df_grp2: DataFrame) = {
    import spark.implicits._
    val df_ret = df_grp2
      .na.fill(0.0,Seq("t_distance","t_duration","t_highspeed_distance","roadfee","fuel_cost","freq","sum_cost"))
      .rdd.map(row2Json)
      .groupBy(_.getString("linevehicle"))
      .flatMap(obj=>{
        val score = obj._2

        var t_distance_max = Double.MinValue
        var t_duration_max = Double.MinValue
        var t_highspeed_distance_max = Double.MinValue
        var freq_min = Double.MaxValue
        var roadfee_max = Double.MinValue
        var fuel_cost_max = Double.MinValue
        var sum_cost_max = Double.MinValue

        // 获取 linevehicle 打分数据集下的各打分字段的最大值
        for (elem <- score) {
          val t_distance = JSONUtil.getJsonDouble(elem, "t_distance",0.0)
          val t_duration = JSONUtil.getJsonDouble(elem, "t_duration",0.0)
          val t_highspeed_distance = JSONUtil.getJsonDouble(elem, "t_highspeed_distance",0.0)
          val freq = JSONUtil.getJsonDouble(elem, "freq",0.0)
          val roadfee = JSONUtil.getJsonDouble(elem, "roadfee",0.0)
          val fuel_cost = JSONUtil.getJsonDouble(elem, "fuel_cost",0.0)
          val sum_cost = JSONUtil.getJsonDouble(elem, "sum_cost",0.0)

          // 组内最大值
          if(t_distance >= t_distance_max) t_distance_max = t_distance
          if(t_duration >= t_duration_max) t_duration_max = t_duration
          if(t_highspeed_distance >= t_highspeed_distance_max) t_highspeed_distance_max = t_highspeed_distance
          if(roadfee >= roadfee_max) roadfee_max = roadfee
          if(fuel_cost >= fuel_cost_max) fuel_cost_max = fuel_cost
          if(sum_cost >= sum_cost_max) sum_cost_max = sum_cost

          // 组内最小值
          if(freq <= freq_min) freq_min = freq
        }

        var t_distance_vf_sum = 0.0
        var t_duration_vf_sum = 0.0
        var t_highspeed_distance_vf_sum = 0.0
        var freq_vf_sum = 0.0
        var roadfee_vf_sum = 0.0
        var fuel_cost_vf_sum = 0.0
        var sum_cost_vf_sum = 0.0

        // 将打分数据集标准化得到新集合 t_distance_std ，并计算新数据集下的各打分字段的最大值、最小值
        for (elem <- score) {
          val t_distance = JSONUtil.getJsonDouble(elem, "t_distance",0.0)
          val t_duration = JSONUtil.getJsonDouble(elem, "t_duration",0.0)
          val t_highspeed_distance = JSONUtil.getJsonDouble(elem, "t_highspeed_distance",0.0)
          val freq = JSONUtil.getJsonDouble(elem, "freq",0.0)
          val roadfee = JSONUtil.getJsonDouble(elem, "roadfee",0.0)
          val fuel_cost = JSONUtil.getJsonDouble(elem, "fuel_cost",0.0)
          val sum_cost = JSONUtil.getJsonDouble(elem, "sum_cost",0.0)

          val freq_vf = freq // 极大型指标正向化
          val t_distance_vf = t_distance_max - t_distance  // 极小型指标正向化
          val t_duration_vf = t_duration_max - t_duration
          val t_highspeed_distance_vf = t_highspeed_distance_max - t_highspeed_distance
          val roadfee_vf = roadfee_max - roadfee
          val fuel_cost_vf = fuel_cost_max - fuel_cost
          val sum_cost_vf = sum_cost_max - sum_cost

          // 正向化后组内值求平方和
          t_distance_vf_sum += Math.pow(t_distance_vf,2)
          t_duration_vf_sum += Math.pow(t_duration_vf,2)
          t_highspeed_distance_vf_sum += Math.pow(t_highspeed_distance_vf,2)
          freq_vf_sum += Math.pow(freq_vf,2)
          roadfee_vf_sum += Math.pow(roadfee_vf,2)
          fuel_cost_vf_sum += Math.pow(fuel_cost_vf,2)
          sum_cost_vf_sum += Math.pow(sum_cost_vf,2)

          elem.put("freq_vf",freq_vf)
          elem.put("t_distance_vf",t_distance_vf)
          elem.put("t_duration_vf",t_duration_vf)
          elem.put("t_highspeed_distance_vf",t_highspeed_distance_vf)
          elem.put("roadfee_vf",roadfee_vf)
          elem.put("fuel_cost_vf",fuel_cost_vf)
          elem.put("sum_cost_vf",sum_cost_vf)
        }

        var t_distance_std_max = Double.MinValue
        var t_duration_std_max = Double.MinValue
        var t_highspeed_distance_std_max = Double.MinValue
        var freq_std_max = Double.MinValue
        var roadfee_std_max = Double.MinValue
        var fuel_cost_std_max = Double.MinValue
        var sum_cost_std_max = Double.MinValue

        var t_distance_std_min = Double.MaxValue
        var t_duration_std_min = Double.MaxValue
        var t_highspeed_distance_std_min = Double.MaxValue
        var freq_std_min = Double.MaxValue
        var roadfee_std_min = Double.MaxValue
        var fuel_cost_std_min = Double.MaxValue
        var sum_cost_std_min = Double.MaxValue

        // 对标准化后的新数据集 t_distance_std 评分
        for (elem <- score) {
          val t_distance_vf = JSONUtil.getJsonDouble(elem, "t_distance_vf",0.0)
          val t_duration_vf = JSONUtil.getJsonDouble(elem, "t_duration_vf",0.0)
          val t_highspeed_distance_vf = JSONUtil.getJsonDouble(elem, "t_highspeed_distance_vf",0.0)
          val freq_vf = JSONUtil.getJsonDouble(elem, "freq_vf",0.0)
          val roadfee_vf = JSONUtil.getJsonDouble(elem, "roadfee_vf",0.0)
          val fuel_cost_vf = JSONUtil.getJsonDouble(elem, "fuel_cost_vf",0.0)
          val sum_cost_vf = JSONUtil.getJsonDouble(elem, "sum_cost_vf",0.0)

          var t_distance_std = Double.MaxValue
          var t_duration_std = Double.MaxValue
          var t_highspeed_distance_std =Double.MaxValue
          var freq_std = Double.MinValue
          var roadfee_std = Double.MaxValue
          var fuel_cost_std = Double.MaxValue
          var sum_cost_std = Double.MaxValue
          if (t_distance_vf_sum != 0) t_distance_std = t_distance_vf / Math.sqrt(t_distance_vf_sum)
          if (t_duration_vf_sum != 0) t_duration_std = t_duration_vf / Math.sqrt(t_duration_vf_sum)
          if (t_highspeed_distance_vf_sum != 0) t_highspeed_distance_std = t_highspeed_distance_vf / Math.sqrt(t_highspeed_distance_vf_sum)
          if (freq_vf_sum != 0) freq_std = freq_vf / Math.sqrt(freq_vf_sum)
          if (roadfee_vf_sum != 0) roadfee_std = roadfee_vf / Math.sqrt(roadfee_vf_sum)
          if (fuel_cost_vf_sum != 0) fuel_cost_std = fuel_cost_vf / Math.sqrt(fuel_cost_vf_sum)
          if (sum_cost_vf_sum != 0) sum_cost_std = sum_cost_vf / Math.sqrt(sum_cost_vf_sum)

          // 组内最大值
          if(t_distance_std >= t_distance_std_max) t_distance_std_max = t_distance_std
          if(t_duration_std >= t_duration_std_max) t_duration_std_max = t_duration_std
          if(t_highspeed_distance_std >= t_highspeed_distance_std_max) t_highspeed_distance_std_max = t_highspeed_distance_std
          if(freq_std >= freq_std_max) freq_std_max = freq_std
          if(roadfee_std >= roadfee_std_max) roadfee_std_max = roadfee_std
          if(fuel_cost_std >= fuel_cost_std_max) fuel_cost_std_max = fuel_cost_std
          if(sum_cost_std >= sum_cost_std_max) sum_cost_std_max = sum_cost_std
          // 组内最小值
          if(t_distance_std <= t_distance_std_min) t_distance_std_min = t_distance_std
          if(t_duration_std <= t_duration_std_min) t_duration_std_min = t_duration_std
          if(t_highspeed_distance_std <= t_highspeed_distance_std_min) t_highspeed_distance_std_min = t_highspeed_distance_std
          if(freq_std <= freq_std_min) freq_std_min = freq_std
          if(roadfee_std <= roadfee_std_min) roadfee_std_min = roadfee_std
          if(fuel_cost_std <= fuel_cost_std_min) fuel_cost_std_min = fuel_cost_std
          if(sum_cost_std <= sum_cost_std_min) sum_cost_std_min = sum_cost_std

          elem.put("freq_std",freq_std)
          elem.put("t_distance_std",t_distance_std)
          elem.put("t_duration_std",t_duration_std)
          elem.put("t_highspeed_distance_std",t_highspeed_distance_std)
          elem.put("roadfee_std",roadfee_std)
          elem.put("fuel_cost_std",fuel_cost_std)
          elem.put("sum_cost_std",sum_cost_std)
        }

        // 对标准化后的新数据集 t_distance_std 评分
        val ret_obj = new ArrayBuffer[JSONObject]()
        for (elem <- score) {
          val t_distance_std = JSONUtil.getJsonDouble(elem, "t_distance_std",0.0)
          val t_duration_std = JSONUtil.getJsonDouble(elem, "t_duration_std",0.0)
          val t_highspeed_distance_std = JSONUtil.getJsonDouble(elem, "t_highspeed_distance_std",0.0)
          val freq_std = JSONUtil.getJsonDouble(elem, "freq_std",0.0)
          val roadfee_std = JSONUtil.getJsonDouble(elem, "roadfee_std",0.0)
          val fuel_cost_std = JSONUtil.getJsonDouble(elem, "fuel_cost_std",0.0)
          val sum_cost_std = JSONUtil.getJsonDouble(elem, "sum_cost_std",0.0)

          val t_distance_pow_max = Math.pow(t_distance_std - t_distance_std_max,2) * 1.0
          val t_duration_pow_max = Math.pow(t_duration_std - t_duration_std_max,2) * 1.0
          val t_highspeed_distance_pow_max = Math.pow(t_highspeed_distance_std - t_highspeed_distance_std_max,2) * 0.0
          val freq_pow_max = Math.pow(freq_std - freq_std_max,2) * 1.0
          val roadfee_pow_max = Math.pow(roadfee_std - roadfee_std_max,2) * 0.0
          val fuel_cost_pow_max = Math.pow(fuel_cost_std - fuel_cost_std_max,2) * 0.0
          val sum_cost_pow_max = Math.pow(sum_cost_std - sum_cost_std_max,2) * 1.0

          val t_distance_pow_min = Math.pow(t_distance_std - t_distance_std_min,2) * 1.0
          val t_duration_pow_min = Math.pow(t_duration_std - t_duration_std_min,2) * 1.0
          val t_highspeed_distance_pow_min = Math.pow(t_highspeed_distance_std - t_highspeed_distance_std_min,2) * 0.0
          val freq_pow_min = Math.pow(freq_std - freq_std_min,2) * 1.0
          val roadfee_pow_min = Math.pow(roadfee_std - roadfee_std_min,2) * 0.0
          val fuel_cost_pow_min = Math.pow(fuel_cost_std - fuel_cost_std_min,2) * 0.0
          val sum_cost_pow_min = Math.pow(sum_cost_std - sum_cost_std_min,2) * 1.0

          // 计算得分
          val score_max = Math.sqrt(t_distance_pow_max+t_duration_pow_max+t_highspeed_distance_pow_max+freq_pow_max+roadfee_pow_max+fuel_cost_pow_max+sum_cost_pow_max)
          val score_min = Math.sqrt(t_distance_pow_min+t_duration_pow_min+t_highspeed_distance_pow_min+freq_pow_min+roadfee_pow_min+fuel_cost_pow_min+sum_cost_pow_min)
          var line_score = 0.0
          if(score_max+score_min != 0.0){
            line_score = score_min / (score_max + score_min)
          }

          elem.put("line_score",line_score)
          ret_obj.append(elem)
        }
        ret_obj.iterator
      }).map(obj=>{
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle","")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code","")
      val t_distance = JSONUtil.getJsonDouble(obj, "t_distance",0.0)
      val t_duration = JSONUtil.getJsonDouble(obj, "t_duration",0.0)
      val t_highspeed_distance = JSONUtil.getJsonDouble(obj, "t_highspeed_distance",0.0)
      val t_toll_distance = JSONUtil.getJsonDouble(obj, "t_toll_distance",0.0)
      val freq = JSONUtil.getJsonDouble(obj, "freq",0.0)
      val oil_fee = JSONUtil.getJsonDouble(obj, "oil_fee",0.0)
      val roadfee = JSONUtil.getJsonDouble(obj, "roadfee",0.0)
      val fuel_cost = JSONUtil.getJsonDouble(obj, "fuel_cost",0.0)
      val sum_cost = JSONUtil.getJsonDouble(obj, "sum_cost",0.0)
      val line_score = JSONUtil.getJsonDouble(obj, "line_score",0.0)
      val mload =  JSONUtil.getJsonVal(obj, "mload","")
      val line_type =  JSONUtil.getJsonVal(obj, "line_type","")
      val line_id =  JSONUtil.getJsonVal(obj, "line_id","")
      val line_code =  JSONUtil.getJsonVal(obj, "line_code","")
      val t_coords =  JSONUtil.getJsonVal(obj, "t_coords","")
      val time =  JSONUtil.getJsonVal(obj, "time","")
      val plan_depart_tm =  JSONUtil.getJsonVal(obj, "plan_depart_tm","")
      val actual_depart_tm =  JSONUtil.getJsonVal(obj, "actual_depart_tm","")
      val group_label2 =  JSONUtil.getJsonVal(obj, "group_label2","")
      val sim1 =  JSONUtil.getJsonVal(obj, "sim1","")
      val sim5 =  JSONUtil.getJsonVal(obj, "sim5","")
      val line_type_list =  JSONUtil.getJsonVal(obj, "line_type_list","")

      TopSIS(linevehicle,task_area_code,t_distance,t_duration,t_highspeed_distance,t_toll_distance,freq,oil_fee,roadfee,fuel_cost,sum_cost,line_score,
        mload,line_type,line_id,line_code,t_coords,time,plan_depart_tm,actual_depart_tm,group_label2,sim1,sim5,line_type_list)
    }).toDF()
      // 得分归一化处理
      .withColumn("line_sore_sum",sum('line_score).over(Window.partitionBy('linevehicle)))
      .withColumn("line_score",when('line_sore_sum =!= 0.0,'line_score / 'line_sore_sum).otherwise(0.0))

    df_ret
  }

  def run(spark: SparkSession, dayBefore1: String, dayBefore31: String) = {

    import spark.implicits._

    // 获取异常标记表中的正常数据
    val abnormal_sql =
      s"""
         |select
         |  linevehicle,
         |  task_area_code,
         |  plan_depart_tm,
         |  t_distance,
         |  t_duration,
         |  t_highspeed_distance,
         |  t_toll_distance,
         |  t_tolls,
         |  t_coords,
         |  mload,
         |  freq,
         |  oil_fee,
         |  roadfee,
         |  fuel_cost,
         |  sum_cost,
         |  line_type,
         |  line_id,
         |  line_code,
         |  inc_day
         |from
         |  dm_gis.eta_line_roadfee_break_ontime_abnormal
         |where
         |  inc_day = '$dayBefore1'
         |  and roadfee_flag = 'yes'  --距离正常
         |  and t_len_path = '1'      --匹配字段正常
         |  and cast(ontime_rate as double) >= 0.85  -- 执行率正常
         |""".stripMargin
    println("异常表取数sql：")
    println(abnormal_sql)
    val df_abnormal = spark.sql(abnormal_sql)

    val tmp11_sql =
      s"""
         |select
         |  std_id as line_id,
         |  actual_depart_tm,
         |  '1' as join_tag
         |from
         |  dm_gis.eta_line_table_tmp11
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("tmp11明细表取数sql：")
    println(tmp11_sql)

    val df_tmp11 = spark.sql(tmp11_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('line_id).orderBy(desc("actual_depart_tm"))))
      .filter('rn === 1)  // 按 line_id 去重
      .drop("rn")

    val isEmptyOrNull_udf = udf(isEmptyOrNull _)
    val df_cost = df_abnormal
      .join(df_tmp11,Seq("line_id"),"left")
      // 轨迹聚合前字段处理
      .withColumn("check_lineid",'linevehicle)
      .withColumn("time",concat_ws("",when('line_type === "标准线路","9").otherwise("1"),'t_distance))
      // 轨迹优化
      .withColumn("rt_coords", when(!isEmptyOrNull_udf('t_coords),dpCoords('t_coords,lit(0.00001))).otherwise('t_coords))

    // 轨迹聚合流程
    val df_grp2 = getGrp2(spark,df_cost,0.95)
      .map(obj=>{
        val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
        val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
        val t_distance = JSONUtil.getJsonDouble(obj, "t_distance", 0.0)
        val t_duration = JSONUtil.getJsonDouble(obj, "t_duration", 0.0)
        val t_highspeed_distance = JSONUtil.getJsonDouble(obj, "t_highspeed_distance", 0.0)
        val t_toll_distance = JSONUtil.getJsonDouble(obj, "t_toll_distance", 0.0)
        val roadfee = JSONUtil.getJsonDouble(obj, "roadfee", 0.0)
        val fuel_cost = JSONUtil.getJsonDouble(obj, "fuel_cost", 0.0)
        val freq = JSONUtil.getJsonDouble(obj, "freq", 0.0)
        val oil_fee = JSONUtil.getJsonDouble(obj, "oil_fee", 0.0)
        val mload = JSONUtil.getJsonVal(obj, "mload", "")
        val sum_cost = JSONUtil.getJsonDouble(obj, "sum_cost", 0.0)
        val line_type = JSONUtil.getJsonVal(obj, "line_type", "")
        val line_id = JSONUtil.getJsonVal(obj, "line_id", "")
        val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
        val t_coords = JSONUtil.getJsonVal(obj, "t_coords", "")
        val time = JSONUtil.getJsonVal(obj, "time", "")
        val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
        val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")

        val group_label2 = JSONUtil.getJsonVal(obj, "grp2", "")
        val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
        val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")
        val simil_cnt = JSONUtil.getJsonVal(obj, "simil_cnt", "")

        GroupLabel2(linevehicle,task_area_code,t_distance,t_duration,t_highspeed_distance,t_toll_distance,roadfee,fuel_cost,freq,oil_fee,mload,sum_cost,
          line_type,line_id,line_code,t_coords,time,plan_depart_tm,actual_depart_tm,group_label2,sim1,sim5,simil_cnt)
      }).toDF()
      .withColumn("line_type_list", concat_ws("|",collect_set('line_type).over(Window.partitionBy('group_label2))))
      .withColumn("freq_sum", sum('freq).over(Window.partitionBy('group_label2)))
      .withColumn("freq",when('line_type_list === "固定线路",'freq_sum).otherwise('freq))  // group_label2 组内全是固定线路，则将执行次数累加
      .withColumn("order_tag",concat_ws("",when('line_type === "标准线路","9").otherwise("1"),'actual_depart_tm))  // 排序字段，group_label2组内优先保留标准线路并且时间最新的一条
      .withColumn("num", row_number().over(Window.partitionBy('group_label2).orderBy(desc("order_tag"))))
      // 同一个 group_label2 下同时存在标准线路和固定线路为 1 否则为 0
      .withColumn("line_type_tag",when('line_type_list.contains("标准线路") and 'line_type_list.contains("固定线路"),1).otherwise(0))
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val filter_col = ('line_type === "标准线路") or ('line_std_cnt > 2 and 'line_type === "固定线路" and 'freq > 1) or ('line_std_cnt <= 2 and 'score_rank <= 3)
    // TOPSIS模型打分
    val df_topsis_tmp = runTOPSIS(spark,df_grp2.filter('num === 1))  // 每个 group_label2 下只保留一条数据参与打分
      .withColumn("score_rank", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("line_score"))))
      .withColumn("line_std_cnt", count(when('line_type === "标准线路",1).otherwise(null)).over(Window.partitionBy('linevehicle)))
      .filter(filter_col)
      .withColumn("filter_col",filter_col)
      .withColumn("score_rank", row_number().over(Window.partitionBy('linevehicle).orderBy(asc("score_rank")))) // 过滤数据后重新对 score_rank 排序
      .withColumn("score_rank_max", max('score_rank).over(Window.partitionBy('linevehicle))) // 过滤数据后重新对 score_rank 排序
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 获取linevehicle组内总成本最低，时间最短，执行次数最多
    val df_topsis_optimal = df_topsis_tmp
      .groupBy("linevehicle")
      .agg(
        min('sum_cost) as "sum_cost_min",
        min('t_duration) as "t_duration_min",
        max('freq) as "freq_max",
        count('linevehicle) as "linevehicle_cnt"
      )

    // 线路打标
    val df_topsis = df_topsis_tmp
      .join(df_topsis_optimal,Seq("linevehicle"),"left")
      .withColumn("line_optimal_type",when('linevehicle_cnt > 1 && 'sum_cost === 'sum_cost_min && 't_duration === 't_duration_min && 'freq === 'freq_max && 'freq =!= 0,"成本最优&时效最优&司机偏好")
        .when('linevehicle_cnt > 1 && 'sum_cost === 'sum_cost_min && 't_duration === 't_duration_min,"成本最优&时效最优")
        .when('linevehicle_cnt > 1 && 'sum_cost === 'sum_cost_min && 'freq === 'freq_max && 'freq =!= 0,"成本最优&司机偏好")
        .when('linevehicle_cnt > 1 && 't_duration === 't_duration_min && 'freq === 'freq_max && 'freq =!= 0,"时效最优&司机偏好")
        .when('linevehicle_cnt > 1 && 'sum_cost === 'sum_cost_min,"成本最优")
        .when('linevehicle_cnt > 1 && 't_duration === 't_duration_min,"时效最优")
        .when('linevehicle_cnt > 1 && 'freq === 'freq_max && 'freq =!= 0,"司机偏好"))
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表77 模型打分表
    val cols_77 = spark.sql("""select * from dm_gis.eta_line_group_label2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_grp2.coalesce(50).select(cols_77: _*), Seq("inc_day"), "dm_gis.eta_line_group_label2")

    // 结果表7 模型打分表
    val cols_1 = spark.sql("""select * from dm_gis.eta_line_topsis_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_topsis.coalesce(50).select(cols_1: _*), Seq("inc_day"), "dm_gis.eta_line_topsis_detail")

    df_topsis_tmp.unpersist()
    df_grp2.unpersist()
  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore31 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 31)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1, dayBefore31)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
