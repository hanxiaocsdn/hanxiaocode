package com.sf.gis.scala.lss.application

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * 标准线路运营指标体系搭建，路况异常信息表去重
 * 需求方：马晶玲（01423372）
 * @author 徐游飞（01417347）
 * 任务信息：666316（路况异常信息表去重，天任务，每天10:00执行）
 * 上游依赖：630337
 */
object StandardLineOperationIndexStatistics_distinct {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore31 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 31)

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    val query_sql =
      s"""
         |select
         | *
         |from
         |  dm_gis.gis_eta_stdline_abnormal_daily_result
         |where
         |  inc_day >= '$dayBefore31'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin

    println("获取gis_eta_stdline_abnormal_daily_result表数据 sql语句：")
    println(query_sql)

    import spark.implicits._
    val df_ret = spark.sql(query_sql)
      .withColumn("rn", row_number().over(Window.partitionBy("task_subid").orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .drop("rn")

    val res_cols = spark.sql("select * from dm_gis.gis_eta_stdline_abnormal_daily_result limit 0").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(res_cols: _*),Seq("inc_day"),"dm_gis.gis_eta_stdline_abnormal_daily_result")

    spark.stop()
  }

}
