package com.sf.gis.scala.lss.application

import com.sf.gis.scala.lss.utils.CommonTools.{getdaysBeforeOrAfter, tranTimeToStrings}
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.{col, explode, get_json_object, lit, split, trim, udf}



/**
 *需求名称：路况数据接入清洗
 *需求描述：需要清洗出道路id、道路方向、速度、预计通行时间等等，供算法端使用。
 *需求方：赵勇(01399071)
 *开发: 周勇(01390943)
 *任务创建时间：20230430
 *任务id：738135
 **/

object EtaRoadSituData {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val spark = SparkSession
      .builder()
      .appName(className)
      .config("spark.shuffle.useOldFetchProtocol", "true")
      .config("spark.dynamicAllocation.enabled", "false")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("spark.executor.memoryOverhead", "12G")
      .config("spark.storage.memoryFraction", "0.1")
      .enableHiveSupport()
      .getOrCreate()
    import spark.implicits._

    val dayvar = args(0)
    val dayvar1 = getdaysBeforeOrAfter(dayvar, 1)
    val dayvar2 =getdaysBeforeOrAfter(dayvar, -1)

    logger.error("接收输入变量dayvar:"+dayvar)
    logger.error("接收输入变量dayvar1:"+dayvar1)
    logger.error("接收输入变量dayvar2:"+dayvar2)


    val tranTimeToStrings_udf=udf(tranTimeToStrings _)

    val kafkadata=spark.sql(s"""
                              |select log from dm_gis.etaroadkfk_log
                              |where inc_day>='${dayvar2}' and inc_day<='${dayvar1}'
                              |""".stripMargin)
      .repartition(600)
      .withColumn("updatetime_tmp",get_json_object($"log","$.updateTime"))
      .filter($"updatetime_tmp".isNotNull && trim($"updatetime_tmp")=!="")
      //路况有效开始时间
      .withColumn("rt_time_from",formatuptm_udf(tranTimeToStrings_udf(functions.concat($"updatetime_tmp",lit("000")))))
      //日期
      .withColumn("inc_day",formatuptmday_udf(tranTimeToStrings_udf(functions.concat($"updatetime_tmp",lit("000")))))
      .filter($"inc_day"===dayvar)
      .withColumn("flowdata_tmp",get_json_object($"log","$.flowData"))
      .drop("log")
      //小时
      .withColumn("inc_hour",formatuptmhour_udf(tranTimeToStrings_udf(functions.concat($"updatetime_tmp",lit("000")))))
      .withColumn("flowdata",formatflowdata_udf($"flowdata_tmp"))
      .withColumn("flowdata_str",explode(split($"flowdata","[|]")))
      //道路id
      .withColumn("link_id",get_json_object($"flowdata_str","$.linkId"))
      //道路方向
      .withColumn("dir",get_json_object($"flowdata_str","$.dir"))
      //link速度
      .withColumn("speed",get_json_object($"flowdata_str","$.speed"))
      //link拥堵状态
      .withColumn("code",get_json_object($"flowdata_str","$.code"))
      //预计通行时间
      .withColumn("travel_time",get_json_object($"flowdata_str","$.travelTime"))
      //详细信息
      .withColumn("detail",get_json_object($"flowdata_str","$.details"))
      .drop("flowdata","flowdata_tmp")




    //存入正式表
    logger.error("存入正式表:")
    val need_cols = spark.sql("""select * from dm_gis.dm_etaroadkfk2hive_dtl limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, kafkadata.select(need_cols: _*), Seq("inc_day","inc_hour"), "dm_gis.dm_etaroadkfk2hive_dtl")
    logger.error("执行完毕！")

    spark.close()

  }

  // 格式化updatetime时分秒
  def formatuptm(strtm: String): String = {
    val strtm2= strtm
      .replaceAll("[-]", "")
      .replaceAll("[:]", "")
      .replaceAll(" ", "")
    strtm2
  }
  val formatuptm_udf=udf(formatuptm _)

  // 格式化updatetime天
  def formatuptmday(strtm: String): String = {
    val strtm2= strtm
      .replaceAll("[-]", "")
      .replaceAll("[:]", "")
      .replaceAll(" ", "")
      .substring(0,8)
    strtm2
  }
  val formatuptmday_udf=udf(formatuptmday _)

  // 格式化updatetime小时
  def formatuptmhour(strtm: String): String = {
    val strtm2= strtm
      .replaceAll("[-]", "")
      .replaceAll("[:]", "")
      .replaceAll(" ", "")
      .substring(0,10)
    strtm2
  }
  val formatuptmhour_udf=udf(formatuptmhour _)

  //清洗转换
  def formatflowdata(strtm: String): String = {
    val strtm2= strtm
      .substring(1,strtm.length-1)
      .replaceAll("\\}\\,\\{\"linkId\"", "\\}\\|\\{\"linkId\"")
    strtm2
  }
  val formatflowdata_udf=udf(formatflowdata _)


}
