package com.sf.gis.scala.lss.lineUpdate

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.LowQualityLineDynamicUpdate_coords.row2Json
import com.sf.gis.scala.lss.lineUpdate.lineUpdateObj.LineAdd
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS_LSS_MMS:【标准线路】外包线路标准路线运营_V1.0
 * 需求方：刘诺文（ft80006476）
 * @author 徐游飞（01417347）
 * 任务ID：809975
 * 任务名称：待更新入库明细表_89
 */
object EtaLineAddChangeDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val queryUrl: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"
  val queryAk: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 4000

  // 解析query接口返回值
  def parseQueryData(ret: JSONObject): (String,String,String,String,String)= {
    var dist = ""
    var time = ""
    var std_id_query = "未获取"
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, s"请求失败: $msg", dist, time,std_id_query)
      } else {
        try{
          dist = ret.getJSONObject("result").getString("dist")
          time = ret.getJSONObject("result").getString("time")
          std_id_query = ret.getJSONObject("result").getString("stdId")
        }catch {
          case e: Exception => logger.error(e)
        }

        return (codeStatue, "成功", dist, time,std_id_query)
      }
    }
    ("22", "请求失败,接口返回值为空", dist, time,std_id_query)
  }

  // 调 Query 接口
  def runQueryInteface(ak:String, obj: JSONObject): JSONObject = {

    val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
    val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
    val mload = JSONUtil.getJsonVal(obj, "mload", "")
    val coords_tag = JSONUtil.getJsonVal(obj, "coords_tag", "")
    var lineCode = ""
    var srcZoneCode = ""
    var destZoneCode = ""
    var vehicle = ""
    var x1 = ""
    var y1 = ""
    var x2 = ""
    var y2 = ""

    try {
      val arr = linevehicle.split("_")
      lineCode = arr(0)
      srcZoneCode = arr(1)
      destZoneCode = arr(2)
      vehicle = arr(3)
    } catch {
      case e: Exception => logger.error(e)
    }

    if(coords_tag == "1"){  // 第一次调 query 参数
      try {
        // 获取起点和终点经纬度
        val t_coords = JSONUtil.getJsonVal(obj, "t_coords", "")
        val coords_obj = JSON.parseArray(t_coords)
        x1 = coords_obj.getJSONArray(0).getString(0)
        y1 = coords_obj.getJSONArray(0).getString(1)
        x2 = coords_obj.getJSONArray(coords_obj.size()-1).getString(0)
        y2 = coords_obj.getJSONArray(coords_obj.size()-1).getString(1)
      } catch {
        case e: Exception => logger.error(e)
      }
    }else if(coords_tag == "2"){  // 第二次调 query 参数
      // 获取起点和终点经纬度
      val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
      val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
      val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
      val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")
      x1 = start_longitude
      x2 = end_longitude
      y1 = start_latitude
      y2 = end_latitude
    }

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("interfaceControl", 3)
    param.put("opt", "std2")
    param.put("ak", ak)
    param.put("lineCode", lineCode)
    param.put("srcZoneCode", srcZoneCode)
    param.put("destZoneCode", destZoneCode)
    param.put("vehicle",vehicle)
    param.put("planTime",plan_time)
    param.put("mLoad",mload)
    param.put("x1",x1)
    param.put("x2",x2)
    param.put("y1",y1)
    param.put("y2",y2)

    var retJSONObject = new JSONObject()
    if(x1 != "" && x2 != "" && y1 != "" && y2 != ""){  // 调接口前对主要参数过滤
      try {
        val retStr: String = HttpInvokeUtil.sendPost(queryUrl,param.toJSONString,3)
        retJSONObject = JSON.parseObject(retStr)
      } catch {
        case e: Exception => logger.error(e)
      }
    }

    //解析接口返回值
    val (codeStatue,msg,dist,time,std_id_query) =  parseQueryData(retJSONObject)
    obj.put("dist",dist)
    obj.put("time",time)
    obj.put("std_id_query",std_id_query)
    // 辅助字段
    obj.put("query_statue",codeStatue)
    obj.put("query_msg",msg)
    obj.put("param",param.toJSONString)

    obj
  }

  def run(spark: SparkSession, dayBefore1: String, dayBefore31: String) = {

    import spark.implicits._
    val topsis_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_line_topsis_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("模型打分表取数sql：")
    println(topsis_sql)

    val tmp33_sql =
      s"""
         |select
         |  linevehicle,
         |  line_distance,
         |  line_time,
         |  econ,
         |  route_index
         |from
         |  dm_gis.eta_line_distance_detail_all
         |where
         |  inc_day = '$dayBefore1'
         |  and error_type = "0"  -- 距离正常数据
         |""".stripMargin
    println("距离数据明细表（all）取数sql：")
    println(tmp33_sql)

    val df_tmp33 = spark.sql(tmp33_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('linevehicle).orderBy(asc("econ"),asc("route_index"))))
      .filter('rn === 1)  // 按 linevehicle 去重
      .drop("rn")

    val df_topsis = spark.sql(topsis_sql)
      .withColumn("plan_time",substring('line_code,-4,4)) // 截取后四位
      .withColumn("coords_tag",lit("1"))  // 调Query接口时的入参区分标识
      .persist(StorageLevel.MEMORY_AND_DISK)

    val df_line_change = df_topsis
      .filter('line_type === "标准线路")
      .withColumn("dist",lit(""))
      .withColumn("time",lit(""))
      .withColumn("query_msg",lit(""))
      .withColumn("param",lit(""))
      .withColumn("query_statue",lit("修改"))
      .withColumn("update_type",lit("修改"))
      .withColumn("inc_day",lit(dayBefore1))
      .select("linevehicle","task_area_code","plan_depart_tm","oil_fee","t_distance","t_duration","t_highspeed_distance","t_toll_distance","roadfee","fuel_cost","freq",
        "t_coords","sum_cost","line_score","line_optimal_type","line_type","line_id","score_rank","score_rank_max","line_code","dist","time","plan_time","query_statue","query_msg","param","update_type","inc_day")

    var rdd_line = df_topsis.filter('line_type === "固定线路").rdd.map(row2Json)
    val invokeCnt = rdd_line.count()
    // 调 QUERY 接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "809975", "待更新入库明细表_89", "获取标准线路需要更新数据", queryUrl, queryAk, invokeCnt, parallelism)
    rdd_line = SparkNet.runInterfaceWithAkLimit(spark, rdd_line, runQueryInteface, parallelism, queryAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId + "invokeCnt = " + invokeCnt)

    val df_line_add = rdd_line.map(obj => {
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
      val t_distance = JSONUtil.getJsonVal(obj, "t_distance", "")
      val t_duration = JSONUtil.getJsonVal(obj, "t_duration", "")
      val t_highspeed_distance = JSONUtil.getJsonVal(obj, "t_highspeed_distance", "")
      val t_toll_distance = JSONUtil.getJsonVal(obj, "t_toll_distance", "")
      val roadfee = JSONUtil.getJsonVal(obj, "roadfee", "")
      val fuel_cost = JSONUtil.getJsonVal(obj, "fuel_cost", "")
      val freq = JSONUtil.getJsonVal(obj, "freq", "")
      val oil_fee = JSONUtil.getJsonVal(obj, "oil_fee", "")
      val sum_cost = JSONUtil.getJsonVal(obj, "sum_cost", "")
      val line_score = JSONUtil.getJsonVal(obj, "line_score", "")
      val line_optimal_type = JSONUtil.getJsonVal(obj, "line_optimal_type", "")
      val line_type = JSONUtil.getJsonVal(obj, "line_type", "")
      val line_id = JSONUtil.getJsonVal(obj, "line_id", "")
      val score_rank = JSONUtil.getJsonVal(obj, "score_rank", "")
      val score_rank_max = JSONUtil.getJsonVal(obj, "score_rank_max", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val dist = JSONUtil.getJsonVal(obj, "dist", "")
      val time = JSONUtil.getJsonVal(obj, "time", "")
      val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
      val t_coords = JSONUtil.getJsonVal(obj, "t_coords", "")
      val query_statue = JSONUtil.getJsonVal(obj, "query_statue", "")

      // 测试字段
      val query_msg = JSONUtil.getJsonVal(obj, "query_msg", "")
      val param = JSONUtil.getJsonVal(obj, "param", "")

      LineAdd(linevehicle,task_area_code,plan_depart_tm,t_distance,t_duration,t_highspeed_distance,t_toll_distance,roadfee,fuel_cost,freq,oil_fee,sum_cost,line_score,line_optimal_type,
        line_type,line_id,t_coords,score_rank,score_rank_max,line_code,dist,time,plan_time,query_statue,query_msg,param)
    }).toDF()
      .join(df_tmp33,Seq("linevehicle"),"left")
      .withColumn("dist",when('query_statue === "0",'dist).otherwise('line_distance))
      .withColumn("time",when('query_statue === "0",'time).otherwise('line_time))
      .withColumn("update_type",lit("新增"))
      .withColumn("inc_day",lit(dayBefore1))
      .select("linevehicle","task_area_code","plan_depart_tm","oil_fee","t_distance","t_duration","t_highspeed_distance","t_toll_distance","roadfee","fuel_cost","freq",
        "t_coords","sum_cost","line_score","line_optimal_type","line_type","line_id","score_rank","score_rank_max","line_code","dist","time","plan_time","query_statue","query_msg","param","update_type","inc_day")

    df_topsis.unpersist()
    // 固定线路新增数据和标准线路修改数据合并
    val df_update = df_line_add.union(df_line_change)

    // 结果表8,9
    val cols_8 = spark.sql("""select * from dm_gis.eta_line_add_change_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_update.coalesce(50).select(cols_8: _*), Seq("inc_day"), "dm_gis.eta_line_add_change_detail")

  }

  def main(args: Array[String]): Unit = {
    // 任务运行日期
    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore31 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 31)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231009  ++++")
    run(spark, dayBefore1, dayBefore31)
    logger.error("++++++++  任务结束 20231009 ++++")

    spark.stop()
  }
}
