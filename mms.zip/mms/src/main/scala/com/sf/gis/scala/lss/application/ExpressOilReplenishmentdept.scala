package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DistanceTool, StringUtils}
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.vividsolutions.jts.geom.{Coordinate, GeometryFactory, Point, Polygon}
import com.vividsolutions.jts.io.WKTReader
import org.apache.log4j.Logger
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.{col, desc, row_number, sum, trim, when}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator
import org.geotools.geometry.jts.JTSFactoryFinder
import scala.collection.JavaConversions._
import java.util
import java.util.concurrent.atomic.LongAccumulator

/**
 * 快运小哥车油补信息表需求_V1.0
 * 需求方：王润泽（01422002），杨汶铭（ft80006323）
 * 需求描述：当前已通过获取小哥每日收派第一票/最后一票的时间和触碰集配站最早/最晚的时间，来判定小哥每日车油补计算的起止时间，并提供该时间段内的轨迹里程给业务方用于发放车油补。
 * 为提高车效、人效，目前业务上存在小哥执行城配任务、支线融通任务的情况，同时集团财务输出的效益点，指出小哥兼职城配、支线不应该重复发放油补，所以在计算油补里程的时候，
 * 要剔除对应小哥兼职城配、支线时间发生的里程。
 * @author 韩笑（01417629） update：周勇（01390943）
 * Created on Nov.29 2021 更新时间 ： 20230530
 * 旧任务信息：408514（快运小哥车油补信息表，每天16:00执行） 新任务：772620
 */


object ExpressOilReplenishmentdept {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val calPartition = 200
  val savePartition = 20
  //允许的最大距离范围
  val maxAllowDistance = 1500
  //调用路径规划接口获取车行距离L
  val xyGetDistUrl = "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?cc=1&opt=sf1&x1=%s&y1=%s&x2=%s&y2=%s&strategy=0&type=0&ak=94f884b45ad54519a282051e031c7d5b"

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar=args(0)
    //油补原数据
    val data_track=spark.sql(
      s"""
         |SELECT * FROM dm_gis.emp_mileage_daily_tracks
         |where inc_day='${dayvar}'
         |""".stripMargin)

    //网点对应多边形
    val polydata=spark.sql(
      s"""
         |select * from dm_gis.aoi_merge_zno_result
         |where inc_day='${dayvar}'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("zno_code").orderBy(desc("update_date"))))
      .filter($"rank"===1)
      .select("zno_code","wkt")
      .withColumnRenamed("zno_code","dept_code")

    //排班网点
    val scheduledata=spark.sql(
      s"""
         |select loginid,dept_code from dm_gis.schedule_width_data
         |where inc_day='${dayvar}'
         |group by loginid,dept_code
         |""".stripMargin)
      .withColumnRenamed("loginid","orig_emp_code")

    //服务网点
    val servicedata=spark.sql(
      s"""
         |select loginid,service_dept  from ods_rmds.tb_res_user
         |where inc_day='${dayvar}'
         |""".stripMargin)
      .withColumnRenamed("loginid","orig_emp_code")

    //数据合并
     val result=data_track.select("orig_emp_code","track")
       .join(scheduledata,Seq("orig_emp_code"),"left")
       .join(servicedata,Seq("orig_emp_code"),"left")
       .withColumn("dept_code",when($"dept_code".isNull || trim($"dept_code")==="",$"service_dept").otherwise($"dept_code"))
       .select("orig_emp_code","dept_code","track")
       .join(polydata,Seq("dept_code"),"left")


    val resultrdd=SparkUtils.getDfToJson(spark, result, 10).map(obj=>{

      val polygonJson = new JSONObject()
      val wkt=obj.getString("wkt")
      val dept_code_tmp=obj.getString("dept_code").concat("_aoi")
      polygonJson.put(dept_code_tmp,wkt)
      obj.put("polygonJson",polygonJson)

       obj

    })


    val calreuslt=Multi_calurl(spark,resultrdd,10)
      .map(
        obj=>{
          val orig_emp_code=obj.getString("orig_emp_code")
          val disall=obj.getString("disall")
          val disdept=obj.getString("disdept")
          val dept_code=obj.getString("dept_code")
          (orig_emp_code,disall,disdept,dept_code)
        }
      ).toDF("orig_emp_code","disall","disdept","dept_code")
      .persist(StorageLevel.MEMORY_AND_DISK)

//    println("输出calreuslt：")
//    calreuslt.show(1,false)

    //一个司机可能排班多个网点，所以要数据合并
    val calreuslta=calreuslt
      .withColumn("disall",when($"disall".isNull || trim($"disall")==="",0).otherwise($"disall"))
      .withColumn("disdept",when($"disdept".isNull || trim($"disdept")==="",0).otherwise($"disdept"))
      .groupBy("orig_emp_code")
      .agg(sum($"disall".cast("double")) as "distance_all",
        sum($"disdept".cast("double")) as "distance_in_dept"
      )
    //数据合并
    val  calreusltb=data_track.join(calreuslta,Seq("orig_emp_code"),"left")

    val tb_cols = spark.sql("""select * from dm_gis.emp_mileage_daily_tracks_aaa limit 0""").schema.map(_.name).map(col)
    logger.error("开始落表")
    writeToHive(spark, calreusltb.select(tb_cols:_*).coalesce(5), Seq("inc_day"), "dm_gis.emp_mileage_daily_tracks_aaa")

    spark.close()
  }

  def calDistanceRdd(spark:SparkSession, joinZcXyRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    logger.error("计算里程")

    val sc=spark.sparkContext

    //logger.error("joinZcXyRdd cnt:" + joinZcXyRdd.count())
    val big1500cntAcc = sc.longAccumulator("big1500cnt")
    val big3000cntAcc = sc.longAccumulator("big3000cnt")
    val big60VcntAcc = sc.longAccumulator("big60Vcnt")


    val disRdd = joinZcXyRdd.map(obj => {
      val (disAll, disDept, jsonObj)
      = calDistance(obj._2)
      jsonObj.put("disAll", disAll)
      jsonObj.put("disDept", disDept)
      (obj._1, jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error("计算完距离后的数据量:" + disRdd.count())
    logger.error("big1500cntAcc cnt:" + big1500cntAcc.value)
    logger.error("big3000cntAcc cnt:" + big3000cntAcc.value)
    logger.error("big60VcntAcc cnt:" + big60VcntAcc.value)

    joinZcXyRdd.unpersist()

    disRdd
  }


  //并发调取接口并发请求，由于每个ak单分钟限制8000，而每次的函数调用有多次，因此这里要限制到1000
  def Multi_calurl(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?"
    val httpAk="94f884b45ad54519a282051e031c7d5b"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "772620", "快运小哥车油补信息表需求",
      "当计算的距离大于3km时认为是错误数据，则取接口数据",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, calurl, 10, "94f884b45ad54519a282051e031c7d5b", 1000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }


  //构造一个并发执行函数
  def calurl(ak:String,obj:JSONObject): JSONObject ={

    val (disall,disdept,jsobj)=calDistance(obj: JSONObject)
    obj.put("disall",disall)
    obj.put("disdept",disdept)
    obj
  }

  //计算里程的函数
  def calDistance(obj: JSONObject): (String, String, JSONObject) = {

    val tracks = obj.getJSONArray("track")

    if (tracks == null || tracks.size() < 2) {
      logger.error("tracks non")
      return ("", "", obj)
    }

    var disAll: Double = 0
    var disDept: Double = 0

    val chkZcStr = new JSONArray()
    val errMsgJsonArr = new JSONArray()

    val geometryFactory = JTSFactoryFinder.getGeometryFactory(null)
    val wKTReader = new WKTReader(geometryFactory)

    var zcXyPolygon = new util.ArrayList[Polygon]()

    try {
      val zcXy = obj.getJSONObject("polygonJson")
      zcXyPolygon = fetchXyPolygon(obj, "polygonJson", zcXy, geometryFactory, wKTReader)
      obj.put("zcXyPolygon", zcXyPolygon.toString)
      //logger.error("zcXyPolygon:" + zcXyPolygon.toString)

      for (i <- 0 until tracks.size() - 1) {

        val track1 = tracks.getJSONObject(i)
        val time1 = track1.getLong("tm")
        val x1 = track1.getDouble("dx")
        val y1 = track1.getDouble("dy")
        val coord1 = new Coordinate(x1, y1)
        val point1 = geometryFactory.createPoint(coord1)
        val track2 = tracks.getJSONObject(i + 1)
        val time2 = track2.getLong("tm")
        val x2 = track2.getDouble("dx")
        val y2 = track2.getDouble("dy")
        val coord2 = new Coordinate(x2, y2)
        val point2 = geometryFactory.createPoint(coord2)
        val tmpDis = DistanceTool.getGreatCircleDistance(x1, y1, x2, y2)

        if (tmpDis <= maxAllowDistance) {
          //全量
          disAll += tmpDis

          val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
          chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
          //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

          //判断网点内及巴枪扫描里程内
          if (!zcXyPolygon.isEmpty && chkZc) {
            disDept += tmpDis

          }
        } else {
          //big1500cntAcc.add(1L)
          logger.error("no calcu88")
          val subTm = Math.abs(time2 - time1) / (60.0 * 60.0)
          val v = (tmpDis / 1000.0) / subTm
          //logger.error("v:" + v)
          if (v <= 60) {
            if (tmpDis > 3000) {
              //big3000cntAcc.add(1L)
              logger.error("no calcu66")
              val xyGetDistReq = String.format(xyGetDistUrl, x1, y1, x2, y2)
              //logger.error("xyGetDistReq:" + xyGetDistReq)
              //val byxyResp = HttpClientUtils.retryGet(xyGetDistReq)
              val byxyResp = HttpInvokeUtil.sendGet(xyGetDistReq, "UTF-8", 5)
              val jsonObj = JSON.parseObject(byxyResp)
              var dist = try {
                jsonObj.getJSONObject("result").getString("dist")
              } catch {
                case e: Exception => ""
              }
              //logger.error("dist:" + dist)
              if (StringUtils.nonEmpty(dist)) {
                if (dist.toDouble >= tmpDis * 2) {
                  dist = (tmpDis * 2).toString
                }
                //全量
                disAll += dist.toDouble

                val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
                chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
                //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

                //判断网点内及巴枪扫描里程内
                if (!zcXyPolygon.isEmpty && chkZc) {
                  disDept += dist.toDouble
                }
              } else {
                //全量
                disAll += tmpDis

                val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
                chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
                //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

                //判断网点内及巴枪扫描里程内
                if (!zcXyPolygon.isEmpty && chkZc) {
                  disDept += tmpDis

                }
              }
            } else {
              //全量
              disAll += tmpDis

              val chkZc = checkInZc(point1, point2, geometryFactory, zcXyPolygon)
              chkZcStr.add("chkZc_" + x1 + "_" + y1 + ":" + chkZc)
              //logger.error("chkZc_" + x1 + "_" + y1 + ":" + chkZc)

              //判断网点内及巴枪扫描里程内
              if (!zcXyPolygon.isEmpty && chkZc) {
                disDept += tmpDis

              }
            }
          } else {
            logger.error("no calcu")
            //big60VcntAcc.add(1L)
          }
        }
      }

    } catch {
      case e: Exception =>
        e.printStackTrace()
    }

    obj.put("calDistanceMsg", errMsgJsonArr)
    obj.put("chkZcStr", chkZcStr)

    var disDeptRet = disDept.toString

    if (zcXyPolygon.isEmpty) {
      disDeptRet = ""
    }

    (disAll.toString,  disDeptRet,  obj)
  }

  def fetchXyPolygon(obj: JSONObject, callMethod: String, zcXys: JSONObject, geometryFactory: GeometryFactory, wKTReader: WKTReader): util.ArrayList[Polygon] = {
    val polygonList = new util.ArrayList[Polygon]()
    if (zcXys == null || zcXys.isEmpty) {
      return polygonList
    }
    val zcXyArray = zcXys.keySet()

    for (zc <- zcXyArray) {
      try {
        val zcXy = zcXys.getString(zc)
        if (!zcXy.isEmpty) {
          val point = wKTReader.read(zcXy).asInstanceOf[Polygon]
          polygonList.add(point)
        }
      } catch {
        case e: Exception =>
          val errorMsg = s"method=>$callMethod,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchXyPolygon")
              && !elem.toString.contains("apply")).mkString(";")

          obj.put("fetchXyPolygonMsg", errorMsg)
      }
    }
    polygonList
  }

  def checkInTcZc(point1: Point, point2: Point, geometryFactory: GeometryFactory, tcXyPolygons: util.ArrayList[Polygon]): Boolean = {
    for (i <- 0 until tcXyPolygons.size()) {
      val tcXyPolygon = tcXyPolygons.get(i)
      try {
        if (point1.within(tcXyPolygon)
          && point2.within(tcXyPolygon)) {
          return true
        }
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>checkInTcZc,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("checkInTcZc") && !elem.toString.contains("apply")).mkString(";"))
      }
    }
    false
  }

  def checkInZc(point1: Point, point2: Point, geometryFactory: GeometryFactory, zcXyPolygons: util.ArrayList[Polygon]): Boolean = {
    for (i <- 0 until zcXyPolygons.size()) {
      val zcXyPolygon = zcXyPolygons.get(i)

      try {
        if ((point1.within(zcXyPolygon) || checkCircleIntersects(geometryFactory, point1, maxAllowDistance, zcXyPolygon))
          && (point2.within(zcXyPolygon) || checkCircleIntersects(geometryFactory, point2, maxAllowDistance, zcXyPolygon))) {
          return true
        }
      } catch {
        case e: Exception =>
          throw new RuntimeException("method=>checkInZc,message=>" + e.fillInStackTrace() + ",stack =>" + e.getStackTrace().filter(
            elem => elem.toString.contains("checkInZc") && !elem.toString.contains("apply")).mkString(";"))
      }
    }
    false
  }

  def checkCircleIntersects(geometryFactory: GeometryFactory, pointMid: Point, maxAllowDistance: Double, zcXyPolygon: Polygon): Boolean = {
    val circle = DistanceTool.createRingPolygon(geometryFactory, pointMid.getX, pointMid.getY, maxAllowDistance)
    circle.intersects(zcXyPolygon)
  }
}
