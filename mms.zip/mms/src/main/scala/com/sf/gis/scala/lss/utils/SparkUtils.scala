package com.sf.gis.scala.lss.utils

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}

object SparkUtils {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //aggregateByKey的柯里化函数,将JSONObject聚合成List[JSONObject]
  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  val seqOpRow = (a: List[Row], b: Row) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOpRow = (a: List[Row], b: List[Row]) => {
    a ::: b
  }

  // 把df数据覆盖写入到hive
  def df2HiveByOverwrite(logger: Logger, df: DataFrame, table: String): Unit = {
    logger.error(s"开始写入到 Hive：$table")
    df
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")
  }

  /**
   * 把df数据按分区覆盖写入到hive
   * @param spark
   * @param dataframe
   * @param partitionCol 分区字段
   * @param resTableName hive表名
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
    logger.error(s"写入 $resTableName 成功！")
  }

  /**
   * 把df数据覆盖写入到不分区hive表
   * @param spark
   * @param dataframe
   * @param resTableName hive表名
   */
  def writeToHiveNoP(spark: SparkSession, dataframe: DataFrame, resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert overwrite table %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


}
