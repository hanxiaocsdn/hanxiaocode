package com.sf.gis.scala.lss.application

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.pathSimilar
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.lss.application.DouglasPeuckerAlgorithm.dpCoords
import com.sf.gis.scala.lss.application.StandardLineOperationIndexStatistics11.concatField
import com.sf.gis.scala.lss.constant.OperationIndexObj.{EliminateGrp2, NewTolls}
import com.sf.gis.scala.lss.utils.Functions.getDateDiff
import com.sf.gis.scala.lss.utils.SparkUtils.writeToHive
import com.sf.gis.scala.lss.utils.StringUtils
import com.sf.gis.scala.lss.utils.StringUtils.{stdCoordsToPoints, timeToCustomTime}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.lang
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/**
 * GIS_LSS_MMS:【标准线路】低质量线路动态更新，逻辑处理部分
 * 需求方：刘诺文（80006476）
 * @author 徐游飞（01417347）
 * 任务ID：663440
 * 任务名称：低质量线路动态更新_优化轨迹点
 */
object LowQualityLineDynamicUpdate_coords {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //  val Simil_URL = "http://gis-int2.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"   // 相似度接口
  //  val Simil_AK = "b924ad13e89f4912b8cde16e10ef18b7"
  //  val QM_URL: String = "http://rp-c-gd-green.int.sfcloud.local:1090/qm_point"
  val QM_URL: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
  val QM_AK: String = "d6a1f9b11d2441fc8fc1ffb5eb3e61d6"
  val GET_LINE: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val GET_LINE_AK: String = "5e86b3e45f664ecea1d59e6c591aa006"
  val parallelism = 10
  val akMinuLimit = 2000

  // 获取 hive 数据
  def getDataSouse(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val mouthBefore1 = DateUtil.getMouthBefore(incDay, 1)
    val stdid_info_sql =
      s"""
         |select
         |  std_id,
         |  quality_type,
         |  execute_num,
         |  ontime_num,
         |  execute_ontime_num,
         |  sum_point,
         |  exe_point,
         |  execute_num / use_num as exe_ratio
         |from
         |  dm_gis.eta_std_line_stdid_info
         |where
         |  inc_day = '$incDay'
         |""".stripMargin
    println("表8取数sql：")
    println(stdid_info_sql)
    val df_stdid_info = spark.sql(stdid_info_sql)

    val report_trail_sql =
      s"""
         |select
         |  concat_ws('_',line_code,start_dept,end_dept,vehicle) as check_lineid,
         |  date_format(report_time,'yyyyMMdd') as report_time
         |from
         |  dm_gis.exception_report_trail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println("report_trail表取数sql：")
    println(report_trail_sql)
    val df_report_trail = spark.sql(report_trail_sql)
      .filter('report_time >= mouthBefore1 and 'report_time <= incDay)
      .withColumn("rn", row_number().over(Window.partitionBy('check_lineid).orderBy(desc("report_time"))))
      .filter('rn === 1)
      .drop("rn")

    val line_conf_sql =
      s"""
         |select
         |  std_id,
         |  '0' as check_status,
         |  std_id as check_stdid,
         |  is_econ as check_is_econ,
         |  line_distance as check_line_distance,
         |  line_time as check_line_time,
         |  plan_time as check_start_time,
         |  vehicle as check_vehicle,
         |  line_code as check_line_code,
         |  src_deptcode as check_src_deptcode,
         |  dest_deptcode as check_dest_deptcode,
         |  create_time as check_create_time,
         |  route_index as check_route_index,
         |  delete_flag as check_delete_flag,
         |  update_time as check_update_time
         |from
         |  dm_gis.eta_std_line_conf
         |""".stripMargin
    println("line_conf取数sql：")
    println(line_conf_sql)

    //注册udf函数
    val timeToCustomTime_udf = udf(timeToCustomTime _)
    val df_line_conf = spark.sql(line_conf_sql)
      .withColumn("check_create_time_1",timeToCustomTime_udf('check_create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd"))) //辅助字段

    val carrier_conf_sql =
      s"""
         |select
         |  std_id,
         |  count(id) as cn
         |from
         |  dm_gis.dm_eta_std_line_carrier_conf_dtl
         |group by
         |  std_id
         |""".stripMargin
    println("carrier_conf取数sql：")
    println(carrier_conf_sql)
    val df_carrier_conf = spark.sql(carrier_conf_sql).drop("cn")

    (df_stdid_info,df_report_trail,df_line_conf,df_carrier_conf)
  }

  // 获取recall表数据
  def getLineRecall(spark: SparkSession, incDay: String) = {
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore30 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 30)
    val dayBefore32 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 32)
    val line_recall_sql =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      std_id,
         |      task_subid,
         |      start_dept,
         |      end_dept,
         |      vehicle_serial,
         |      line_code,
         |      actual_depart_tm,
         |      actual_arrive_tm,
         |      actual_run_time,
         |      carrier_type,
         |      vehicle_type,
         |      conduct_type,
         |      ac_is_run_ontime,
         |      rt_coords,
         |      src,
         |      rt_dist,
         |      time,
         |      inc_day,
         |      concat(
         |        line_code,
         |        '_',
         |        case
         |          when start_type = 2 then start_dept
         |          when start_type = 1 and length(start_outer_add_code) > 0 then start_outer_add_code
         |          else 'false'
         |        end,
         |        '_',
         |        case
         |          when end_type = 2 then end_dept
         |          when end_type = 1 and length(end_outer_add_code) > 0 then end_outer_add_code
         |          else 'false'
         |        end,
         |        '_',
         |        vehicle_type
         |      ) check_lineid,
         |      row_number() over(PARTITION by task_subid ORDER by actual_arrive_tm desc) as rn
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day >= '$dayBefore32'
         |      and inc_day <= '$incDay'
         |      and task_inc_day >= '$dayBefore30'
         |      and task_inc_day <= '$dayBefore1'
         |      and error_type = 0
         |  ) a
         |where
         |  a.rn = 1
         |""".stripMargin

    println("recall表取数sql：")
    println(line_recall_sql)
    val df_line_recall = spark.sql(line_recall_sql)

    df_line_recall
  }

  // 将中间结果集字段汇总，得到最终结果表
  def getLowQualityResult2(spark: SparkSession, group_label_filter2: Dataset[Row], incDay: String) = {

    println("结果集6数据量："+group_label_filter2.count())
    group_label_filter2.printSchema()

//    // 将eliminate_grp聚合后便于管理至结果表b
//    val df_eliminate_grp = df_statistical_grp2.select("std_id","eliminate_grp","grp_sum_point","grp_quality_type")
//      .groupBy("std_id")
//      .agg(
//        concat_ws("|",collect_list('eliminate_grp)) as "eliminate_grp",
//        concat_ws("|",collect_list('grp_sum_point)) as "grp_sum_point",
//        concat_ws("|",collect_list('grp_quality_type)) as "grp_quality_type"
//      )
//
//    // 表b
//    // 新建数据集 std_result
//    val std_result = df_grp2.select("std_id","sum_point","quality_type","check_deleteFlag","check_isEcon","eliminate_std")
//      .distinct()
//      .join(df_eliminate_grp,Seq("std_id"),"left")
//      .join(df_table_e.select("std_id","pp_break").distinct(),Seq("std_id"),"left")
//      .join(df_table_e2.select("std_id","same_lineid").distinct(),Seq("std_id"),"left")
//      .withColumn("inc_day",lit(incDay))
//
//    val result_cols = spark.sql("""select * from dm_gis.low_quality_result1 limit 0""").schema.map(_.name).map(col)
//    writeToHive(spark,std_result.select(result_cols: _*),Seq("inc_day"),"dm_gis.low_quality_result1")
//
    group_label_filter2.unpersist()
  }

  // 低价值线路筛选明细数据
  def getGroupLabelFilter2(spark: SparkSession, df_qm_point2: DataFrame, incDay: String) = {

    import spark.implicits._
    val transformTrack_udf = udf(transformTrack _)
    val isEmptyOrNull_udf = udf(isEmptyOrNull _)
    val df_group_label1 = df_qm_point2
      .select("check_lineid","grp2","new_coords","new_distance","data_type")
      .filter('data_type === "0")  // 只选调getLine接口前的原始数据
      .withColumn("group_label",'grp2)
      .withColumnRenamed("new_distance","time")
      .withColumn("track_type",lit("司机线路"))
      // 轨迹优化
      .withColumn("rt_coords_old", 'new_coords)
      .withColumn("rt_coords", when(!isEmptyOrNull_udf('new_coords),dpCoords('new_coords,lit(0.00001))).otherwise('new_coords))
      .select("check_lineid","group_label","rt_coords","rt_coords_old","track_type","time")

    val df_group_label2 = df_qm_point2
      .select("check_lineid","group_label","rt_coords_2","track_type","new_distance")
      .withColumnRenamed("new_distance","time")
      // 轨迹格式转换
      .withColumn("rt_coords",transformTrack_udf('rt_coords_2,lit("\\|")))
      // 轨迹优化
      .withColumn("rt_coords_old", 'rt_coords)
      .withColumn("rt_coords", when(!isEmptyOrNull_udf('rt_coords),dpCoords('rt_coords,lit(0.00001))).otherwise('rt_coords))
      .select("check_lineid","group_label","rt_coords","rt_coords_old","track_type","time")

    val df_grp3 = getGrp2(spark,df_group_label1.union(df_group_label2),0.9)
      .map(obj=>{
        val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
        val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords_old", "")
        val group_label = JSONUtil.getJsonVal(obj, "group_label", "")
        val track_type = JSONUtil.getJsonVal(obj, "track_type", "")
        val grp1 = JSONUtil.getJsonVal(obj, "grp1", "")
        val grp22 = JSONUtil.getJsonVal(obj, "grp2", "")
        val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
        val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")

        (check_lineid,group_label,rt_coords,track_type,grp1,grp22,sim1,sim5)
      }).toDF("check_lineid","group_label","rt_coords","track_type","grp1","grp22","sim1","sim5")
      .withColumnRenamed("grp22","grp3")
      .withColumnRenamed("group_label","grp2")
      .withColumn("track_type_list", concat_ws("|",collect_set('track_type).over(Window.partitionBy('grp3))))
      .withColumn("filter_tag",when('track_type_list.contains("司机线路") && 'track_type_list.contains("标准线路"),false).otherwise(true))
      .filter('filter_tag)  // 剔除任务轨迹和配置标准线路分为一组的线路
      .withColumn("rn", row_number().over(Window.partitionBy('grp2).orderBy(desc("track_type"))))
      .filter('rn === 1)
      .select("grp2","track_type")

///////////////////////////////////////////////////////
    val df_tmp = getGrp2(spark,df_group_label1.union(df_group_label2),0.9)
      .map(obj=>{
        val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
        val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords_old", "")
        val group_label = JSONUtil.getJsonVal(obj, "group_label", "")
        val track_type = JSONUtil.getJsonVal(obj, "track_type", "")
        val grp1 = JSONUtil.getJsonVal(obj, "grp1", "")
        val grp22 = JSONUtil.getJsonVal(obj, "grp2", "")
        val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
        val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")

        (check_lineid,group_label,rt_coords,track_type,grp1,grp22,sim1,sim5)
      }).toDF("check_lineid","group_label","rt_coords","track_type","grp1","grp22","sim1","sim5")
      .withColumnRenamed("grp22","grp3")
      .withColumn("track_type_list", concat_ws("|",collect_set('track_type).over(Window.partitionBy('grp3))))
      .withColumn("filter_tag",when('track_type_list.contains("司机线路") && 'track_type_list.contains("标准线路"),false).otherwise(true))
      //.filter('filter_tag)  // 剔除任务轨迹和配置标准线路分为一组的线路
      .withColumn("rn", row_number().over(Window.partitionBy('group_label).orderBy(desc("track_type"))))
      //.filter('rn === 1)
      .withColumn("inc_day",lit(incDay))

    // 保存结果集66666666666666
    val cols_666 = spark.sql("""select * from dm_gis.xyf_tmp_20230904 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_tmp.coalesce(20).select(cols_666: _*),Seq("inc_day"),"dm_gis.xyf_tmp_20230904")
///////////////////////////////////////////////////////

    val group_label_filter2 = df_qm_point2
      .drop("track_type")
      .join(df_grp3,Seq("grp2"),"inner")
      .withColumn("rn", row_number().over(Window.partitionBy('check_lineid).orderBy(desc("grp_sum_point"),asc("check_create_time"))))
      .filter('rn === 1)  // 按check_lineid分组，grp_sum_point排序，仅保留最大组的数据
      .drop("rn")
      .withColumn("rn_num", row_number().over(Window.orderBy(asc("check_create_time"))))
      .withColumn("rn_num_max", max('rn_num).over())
      .filter('rn_num <= 'rn_num_max * 0.4)   // 按照check_create_time升序，只选取前40%条数据
    //      .filter('check_is_econ === "3" and 'check_route_index === "0")
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("结果集6数据量："+group_label_filter2.count())
    // 保存结果集6
    val cols_6 = spark.sql("""select * from dm_gis.group_label_filter2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,group_label_filter2.coalesce(20).select(cols_6: _*),Seq("inc_day"),"dm_gis.group_label_filter2")

    df_qm_point2.unpersist()
    getLowQualityResult2(spark,group_label_filter2,incDay)
  }

  // qm和getLine接口明细数据
  def getLowQualityQmPoint2(spark: SparkSession, df_grp2: DataFrame, df_statistical_grp2: DataFrame, incDay: String) = {
    // 路线选择
    // 计算time中位数,只保留中位数那条数据
    import spark.implicits._
    val df_median_time = df_grp2
      .rdd
      .groupBy(_.getAs[String]("grp2"))
      .repartition(1600)
      .flatMap(obj => {
        val grp2 = obj._1
        val arr: Array[JSONObject] = obj._2.toArray.sortBy(_.getAs[String]("time")).reverse.map(row2Json)
        val dataArray = new ArrayBuffer[(String, JSONObject)]()
        var median_time = ""
        if (arr.size % 2 == 0) {
          median_time = arr(arr.size/2 - 1).getString("time")
          arr(arr.size/2 - 1).put("median_time", median_time)
        } else {
          median_time = arr((arr.size - 1) / 2).getString("time")
          arr((arr.size - 1) / 2).put("median_time", median_time)
        }
        for (elem <- arr) {
          dataArray.append((grp2, elem))
        }
        dataArray.iterator
      }).map(obj => {
      val grp2 = obj._1
      val median_time = JSONUtil.getJsonVal(obj._2, "median_time", "")
      val rt_coords = JSONUtil.getJsonVal(obj._2, "rt_coords", "")
      val rt_dist = JSONUtil.getJsonVal(obj._2, "rt_dist", "")
      val time = JSONUtil.getJsonVal(obj._2, "time", "")
      (grp2,median_time,rt_coords,rt_dist,time)
    }).toDF("grp2", "median_time","rt_coords","rt_dist","time")
      .filter('median_time =!= "")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 取eliminate_grp = "其他" 的数据关联轨迹
    val df_ret_d = df_statistical_grp2.filter('eliminate_grp === "其他")
      .join(df_median_time,Seq("grp2"),"left")   // 关联获取轨迹 rt_coords

    val invokeCnt = df_ret_d.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "663440", "低质量线路动态更新_优化轨迹点", "获取收费字段", QM_URL, QM_AK, invokeCnt, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "663440", "低质量线路动态更新_优化轨迹点", "获取标准线路", GET_LINE, GET_LINE_AK, invokeCnt, parallelism)
    // 调qm接口 和 配置查询接口
    val tableRDD_e = SparkNet.runInterfaceWithAkLimit(spark, df_ret_d.rdd.map(row2Json), runQMPointInteface, parallelism, QM_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df_qm_point2 = tableRDD_e.repartition(1600)
      .flatMap(obj=>{
        val list_arr = JSONUtil.getJsonArrayMulti(obj, "list_arr")

        val list = new ArrayBuffer[JSONObject]()
        for(i <- 0 until list_arr.size()){
          val list_obj = JSON.parseObject(list_arr.get(i).toString)
          val group_label = JSONUtil.getJsonVal(list_obj, "stdId", "")
          val rt_coords = JSONUtil.getJsonVal(list_obj, "jyTrack2", "")
          val check_is_econ = JSONUtil.getJsonVal(list_obj, "isEcon", "")
          val check_route_index = JSONUtil.getJsonVal(list_obj, "routeIndex", "")
          val check_create_time = JSONUtil.getJsonVal(list_obj, "createTime", "")
          val track_type = "标准线路"

          val tmp_obj = new JSONObject()
          tmp_obj.put("grp2_obj",obj)
          tmp_obj.put("group_label",group_label)
          tmp_obj.put("rt_coords",rt_coords)
          tmp_obj.put("track_type",track_type)
          tmp_obj.put("data_type",i)
          tmp_obj.put("check_stdid",group_label)
          tmp_obj.put("check_is_econ",check_is_econ)
          tmp_obj.put("check_route_index",check_route_index)
          tmp_obj.put("check_create_time",check_create_time)

          list.append(tmp_obj)
        }
        list.iterator
      })
      .map(obj => {
        // 原始字段
        val grp2_obj = JSONUtil.getJsonObjectMulti(obj, "grp2_obj")
        val check_lineid = JSONUtil.getJsonVal(grp2_obj, "check_lineid", "")
        val low_std_id = JSONUtil.getJsonVal(grp2_obj, "low_std_id", "")
        val median_time = JSONUtil.getJsonVal(grp2_obj, "median_time", "")
        val rt_coords_1 = JSONUtil.getJsonVal(grp2_obj, "rt_coords", "")
        val rt_dist = JSONUtil.getJsonVal(grp2_obj, "rt_dist", "")
        val time = JSONUtil.getJsonVal(grp2_obj, "time", "")
        val grp_sum_point = JSONUtil.getJsonVal(grp2_obj, "grp_sum_point", "")
        val grp2 = JSONUtil.getJsonVal(grp2_obj, "grp2", "")
        // qm 接口返回值
        val newData_obj = JSONUtil.getJsonObjectMulti(grp2_obj, "newData")
        val paths_num = JSONUtil.getJsonVal(newData_obj, "paths_num", "")
        val new_highspeed_distance = JSONUtil.getJsonVal(newData_obj, "new_highspeed_distance", "")
        val new_tolls = JSONUtil.getJsonVal(newData_obj, "new_tolls", "")
        val new_toll_distance = JSONUtil.getJsonVal(newData_obj, "new_toll_distance", "")
        val pp_break = JSONUtil.getJsonVal(newData_obj, "paths_num", "")
        val new_coords = JSONUtil.getJsonVal(newData_obj, "new_coords", "")
        val new_distance = JSONUtil.getJsonVal(newData_obj, "new_distance", "")
        val new_duration = JSONUtil.getJsonVal(newData_obj, "new_duration", "")
        // getLine 接口返回值
        val group_label = JSONUtil.getJsonVal(obj, "group_label", "")
        val rt_coords_2 = JSONUtil.getJsonVal(obj, "rt_coords", "")
        val track_type = JSONUtil.getJsonVal(obj, "track_type", "")
        val data_type = JSONUtil.getJsonVal(obj, "data_type", "")
        val check_stdid = JSONUtil.getJsonVal(obj, "check_stdid", "")
        val check_is_econ = JSONUtil.getJsonVal(obj, "check_is_econ", "")
        val check_route_index = JSONUtil.getJsonVal(obj, "check_route_index", "")
        val check_create_time = JSONUtil.getJsonVal(obj, "check_create_time", "")

        val arr = check_lineid.split("_")
        val check_line_code = arr(0)
        val check_srcDeptcode = arr(1)
        val check_destDeptcode = arr(2)
        val check_vehicle = arr(3)
        // 测试字段
        val new_status = JSONUtil.getJsonVal(newData_obj, "new_status", "")
        val new_msg = ""
        val new_param = ""

        NewTolls(grp2,paths_num,check_lineid,low_std_id,median_time,rt_coords_1,rt_coords_2,rt_dist,time,new_highspeed_distance,new_tolls,new_toll_distance,
          check_line_code,check_srcDeptcode,check_destDeptcode,check_vehicle,pp_break,new_status,new_msg,new_param,new_coords,new_distance,new_duration,
          check_create_time,group_label,track_type,data_type,grp_sum_point,check_stdid,check_is_econ,check_route_index)
      }).toDF()
      .withColumn("inc_day",lit(incDay))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("结果集5数据量："+df_qm_point2.count())
    // 保存结果集5
    val cols_5 = spark.sql("""select * from dm_gis.low_quality_qm_point2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_qm_point2.coalesce(20).select(cols_5: _*),Seq("inc_day"),"dm_gis.low_quality_qm_point2")

    df_statistical_grp2.unpersist()
    df_median_time.unpersist()
    getGroupLabelFilter2(spark,df_qm_point2,incDay)
  }

  // grp2分组聚合数据
  def getLowQualityEliminateGrp2(spark: SparkSession, df_check_lineid_filter: DataFrame, incDay: String) = {
    import spark.implicits._
    val df_grp2 = getGrp2(spark,df_check_lineid_filter.filter('conduct_type =!= "1"),0.9)
      .map(obj=>{
        val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
        val low_std_id = JSONUtil.getJsonVal(obj, "low_std_id", "")
        val check_line_distance = JSONUtil.getJsonVal(obj, "check_line_distance", "")
        val check_line_time = JSONUtil.getJsonVal(obj, "check_line_time", "")
        val check_create_time = JSONUtil.getJsonVal(obj, "check_create_time", "")
        val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
        val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
        val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
        val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
        val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
        val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
        val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
        val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
        val actual_run_time = JSONUtil.getJsonVal(obj, "actual_run_time", "")
        val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
        val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
        val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
        val ac_is_run_ontime = JSONUtil.getJsonVal(obj, "ac_is_run_ontime", "")
        val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords_old", "")
        val src = JSONUtil.getJsonVal(obj, "src", "")
        val rt_dist = JSONUtil.getJsonVal(obj, "rt_dist", "")
        val time = JSONUtil.getJsonVal(obj, "time", "")
        val use_num = JSONUtil.getJsonVal(obj, "use_num", "")
        val group_label = JSONUtil.getJsonVal(obj, "group_label", "")
        val track_type = JSONUtil.getJsonVal(obj, "track_type", "")
        val grp1 = JSONUtil.getJsonVal(obj, "grp1", "")
        val grp22 = JSONUtil.getJsonVal(obj, "grp2", "")
        val sim1 = JSONUtil.getJsonVal(obj, "sim1", "")
        val sim5 = JSONUtil.getJsonVal(obj, "sim5", "")
        val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")

        EliminateGrp2(check_lineid,low_std_id,check_line_distance,check_line_time,check_create_time, std_id,task_subid,start_dept,end_dept,vehicle_serial,
          line_code,actual_depart_tm,actual_arrive_tm,actual_run_time,carrier_type,vehicle_type,conduct_type,ac_is_run_ontime,rt_coords,src,
          rt_dist,time,use_num,grp1,grp22,sim1,sim5,group_label,track_type,inc_day)
      }).toDF()
      .withColumnRenamed("grp22","grp2")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 计算同std_id下其他组的平均值 no_grp_mean_time 和 no_grp_mean_dist
    val df_no_grp_mean = getNoGrpMeanDistAndTime(spark, df_grp2)

    // 按grp2维度统计，存中间表 low_quality_grp_detail
    val df_statistical_grp2_tmp = df_grp2
      .join(df_no_grp_mean,Seq("grp2"),"left")
      .groupBy("grp2")
      .agg(
        count('std_id) as "grp_use_num",
        count(when('ac_is_run_ontime === 1,1).otherwise(null)) as "grp_ontime_num",
        avg('rt_dist) as "grp_mean_dist",
        avg('time) as "grp_mean_time",
        max('no_grp_mean_dist) as "no_grp_mean_dist",
        max('no_grp_mean_time) as "no_grp_mean_time",
        max('use_num) as "use_num",
        max('check_lineid) as "check_lineid",
        max('low_std_id) as "low_std_id",
        min('check_create_time) as "check_create_time"
      )
      .withColumn("grp_exe_ratio",'grp_use_num / 'use_num)
      .withColumn("grp_exe_ontime_ratio",'grp_ontime_num / 'grp_use_num)
      .withColumn("grp_dist_diff",'grp_mean_dist - 'no_grp_mean_dist)
      .withColumn("grp_time_diff",'grp_mean_time - 'no_grp_mean_time)
      .withColumn("grp_time_diff_abs",round(abs('grp_time_diff.cast(DoubleType)),2))
      .withColumn("grp_dist_diff_abs",round(abs('grp_dist_diff.cast(DoubleType)),2))
      .withColumn("grp_label_ontime",when(('use_num > 5 and 'grp_exe_ontime_ratio >= 0.9) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ontime_ratio === 1.0),concatField(lit("准点率高"),'grp_exe_ontime_ratio))
        .when(('use_num > 5 and 'grp_exe_ontime_ratio >= 0.5 and 'grp_exe_ontime_ratio < 0.9) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ontime_ratio >= 0.6 and 'grp_exe_ontime_ratio < 1.0),concatField(lit("无准点标签"),'grp_exe_ontime_ratio))
        .when(('use_num > 5 and 'grp_exe_ontime_ratio < 0.5) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ontime_ratio < 0.6),concatField(lit("准点率低"),'grp_exe_ontime_ratio))
        .otherwise("null_0"))
      .withColumn("grp_label_time",when('use_num >= 3 and ('grp_time_diff.isNull or 'grp_time_diff === "" or ('grp_time_diff.cast(DoubleType) >= -5 and 'grp_time_diff.cast(DoubleType) <= 5) or (('grp_time_diff.cast(DoubleType) / 'grp_mean_time) >= -0.05 and ('grp_time_diff.cast(DoubleType) / 'grp_mean_time) <= 0.05)),"null_null_0")
        .when('use_num >= 3 and (('grp_time_diff.cast(DoubleType) / 'grp_mean_time) > 0.05 and 'grp_time_diff.cast(DoubleType) > 5),concat_ws("_",lit("时长长"),'grp_time_diff_abs,lit("-1")))
        .when('use_num >= 3 and (('grp_time_diff.cast(DoubleType) / 'grp_mean_time) < -0.05 and 'grp_time_diff.cast(DoubleType) < -5),concat_ws("_",lit("时长短"),'grp_time_diff_abs,lit("1")))
        .otherwise("null_null_0"))
      .withColumn("grp_label_dist",when('use_num >= 3 and ('grp_dist_diff.isNull or 'grp_dist_diff === "" or ('grp_dist_diff.cast(DoubleType) >= -5 and 'grp_dist_diff.cast(DoubleType) <= 5) or (('grp_dist_diff.cast(DoubleType) / 'grp_mean_dist) >= -0.05 and ('grp_dist_diff.cast(DoubleType) / 'grp_mean_dist) <= 0.05)),"null_null_0")
        .when('use_num >= 3 and (('grp_dist_diff.cast(DoubleType) / 'grp_mean_dist) > 0.05 and 'grp_dist_diff.cast(DoubleType) > 5),concat_ws("_",lit("里程长"),'grp_dist_diff_abs,lit("-1")))
        .when('use_num >= 3 and (('grp_dist_diff.cast(DoubleType) / 'grp_mean_dist) < -0.05 and 'grp_dist_diff.cast(DoubleType) < -5),concat_ws("_",lit("里程短"),'grp_dist_diff_abs,lit("1")))
        .otherwise("null_null_0"))
      .withColumn("grp_label_exe",when(('use_num > 5 and 'grp_exe_ratio >= 0.8) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ratio === 1.0),concatField(lit("高执行率"),'grp_exe_ratio))
        .when(('use_num > 5 and 'grp_exe_ratio > 0.5 and 'grp_exe_ratio < 0.8) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ratio >= 0.6 and 'grp_exe_ratio < 1.0),concatField(lit("无执行率"),'grp_exe_ratio))
        .when(('use_num > 5 and 'grp_exe_ratio <= 0.5) or ('use_num >= 3 and 'use_num <= 5 and 'grp_exe_ratio < 0.6),concatField(lit("低执行率"),'grp_exe_ratio))
        .otherwise("null_0"))
      .persist(StorageLevel.MEMORY_AND_DISK)
    val df_statistical_grp2 = df_statistical_grp2_tmp
      .withColumn("grp_exe_point",'grp_exe_ratio * 40)
      .withColumn("grp_ontime_point",'grp_exe_ontime_ratio * 30)
      .withColumn("grp_dist_point",when('grp_label_dist.contains("里程长"),0)
        .when('grp_label_dist.contains("null_null_0"),7.5)
        .when('grp_label_dist.contains("里程短"),15))
      .withColumn("grp_time_point",when('grp_label_time.contains("时长长"),0)
        .when('grp_label_time.contains("null_null_0"),7.5)
        .when('grp_label_time.contains("时长短"),15))
      .withColumn("grp_sum_point",'grp_exe_point + 'grp_ontime_point + 'grp_dist_point + 'grp_time_point)
      .withColumn("grp_quality_type",when('use_num < 3,"任务数不足线路")
        .when('grp_sum_point.cast("double") <= 50,"低质量线路")
        .when('grp_sum_point.cast("double") > 50 and 'grp_sum_point.cast("double") <= 70,"普通线路")
        .when('grp_sum_point.cast("double") > 70,"高质量线路"))
      .withColumn("eliminate_grp",when('grp_sum_point <= 70,"没有评分高于70分的线路组")
        //        .when('grp_sum_point <= 'sum_point,"没有评分高于原线路评分的线路组")
        //        .when('grp_exe_ratio < 'exe_ratio,"没有线路执行率高于原线路执行率的线路组")
        .otherwise("其他"))
      .withColumn("inc_day",lit(incDay))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("结果集4数据量："+df_statistical_grp2.count())
    // 保存结果集4
    val cols_4 = spark.sql("""select * from dm_gis.low_quality_eliminate_grp2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_statistical_grp2.coalesce(20).select(cols_4: _*),Seq("inc_day"),"dm_gis.low_quality_eliminate_grp2")

    df_check_lineid_filter.unpersist()
    df_grp2.unpersist()
    df_statistical_grp2_tmp.unpersist()
    getLowQualityQmPoint2(spark,df_grp2,df_statistical_grp2,incDay)

  }

  // check_lineid分组维度下明细数据
  def getLowQualityCheckLineidGroup2(spark: SparkSession,df_detail: DataFrame,incDay: String) = {

    import spark.implicits._
    val isEmptyOrNull_udf = udf(isEmptyOrNull _)
    val df_line_recall = getLineRecall(spark, incDay)
    // 新增字段grp1 grp2
    // 过滤已剔除线路，并按check_lineid分组
    val df_check_lineid = df_detail.filter(isEmptyOrNull_udf('eliminate_std) && 'quality_type =!= "任务数不足线路")
      .withColumn("num", row_number().over(Window.partitionBy('check_lineid).orderBy(asc("check_create_time"))))
      .groupBy("check_lineid")
      .agg(
        concat_ws("|",collect_set(when('quality_type === "高质量线路",'std_id).otherwise(null))) as "high_std_id",
        concat_ws("|",collect_set(when('quality_type === "低质量线路",'std_id).otherwise(null))) as "low_std_id",
        concat_ws("|",collect_set(when('quality_type === "普通线路",'std_id).otherwise(null))) as "std_std_id",
        max(when('num === 1,'check_create_time).otherwise(null)) as "check_create_time",
        max(when('num === 1,'check_line_distance).otherwise(null)) as "check_line_distance",
        max(when('num === 1,'check_line_time).otherwise(null)) as "check_line_time"
      )
      .filter(!isEmptyOrNull_udf('low_std_id))
      .withColumn("filter_flag",when(!isEmptyOrNull_udf('high_std_id),"low").otherwise("high"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 将check_lineid组内既有高质量线路又有低质量线路的std拆分，后续调接口删除
    val df_low_std_id = df_check_lineid
      .filter('filter_flag === "low")
      .withColumn("low_std_id",explode(split('low_std_id,"\\|")))
      .select("low_std_id")

    val df_check_lineid_filter = df_check_lineid
      .filter('filter_flag === "high")
      .join(df_line_recall,Seq("check_lineid"),"inner") // 关联recall表
      .withColumn("use_num", count('task_subid).over(Window.partitionBy('check_lineid)))
      // 轨迹优化
      .withColumn("rt_coords_old", 'rt_coords)
      .withColumn("rt_coords", dpCoords('rt_coords,lit(0.00001)))
      .withColumn("inc_day",lit(incDay))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("结果集2数据量："+df_check_lineid_filter.count())
    // 保存结果集2
    val cols_2 = spark.sql("""select * from dm_gis.low_quality_check_lineid_group2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_check_lineid_filter.coalesce(20).select(cols_2: _*),Seq("inc_day"),"dm_gis.low_quality_check_lineid_group2")

    df_detail.unpersist()
    df_check_lineid.unpersist()
    getLowQualityEliminateGrp2(spark,df_check_lineid_filter,incDay)

  }

  def execute(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    // 获取hive表数据
    val (df_stdid_info,df_report_trail,df_line_conf,df_carrier_conf) = getDataSouse(spark, incDay)

    // hive原始数据关联
    val df_result_a1 = df_stdid_info
      .join(df_line_conf,Seq("std_id"),"inner") // 关联配置表
      .withColumn("check_lineid",concat_ws("_",'check_line_code,'check_src_deptcode,'check_dest_deptcode,'check_vehicle))
      .join(df_report_trail,Seq("check_lineid"),"left") // 关联异常提报表
      .withColumn("report_time",when('report_time.isNotNull,"false").otherwise("true"))
      .withColumn("time_diff",getDateDiff(lit(incDay),'check_create_time_1,lit("yyyyMMdd"),lit(0)).cast("double"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 获取承运商check_lineid
    val df_check_carrier = df_result_a1
      .select("std_id","check_lineid")
      .join(df_carrier_conf,Seq("std_id"),"inner") // 关联承运商配置表，用于剔除承运商操作线路
      .withColumn("carrier_del", row_number().over(Window.partitionBy('check_lineid).orderBy(desc("std_id"))))
      .filter('carrier_del === 1)  // 按check_lineid去重
      .drop("std_id")

    // 关联承运商check_lineid，给 eliminate_std 打标
    val df_detail = df_result_a1
      .join(df_check_carrier,Seq("check_lineid"),"left")
      .withColumn("eliminate_std",eliminateStdField('check_delete_flag,'check_is_econ,'report_time,'time_diff,'carrier_del))
      .withColumn("inc_day",lit(incDay))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("结果集1数据量："+df_detail.count())
    // 保存结果集1
    val cols_1 = spark.sql("""select * from dm_gis.low_quality_detail2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_detail.coalesce(20).select(cols_1: _*),Seq("inc_day"),"dm_gis.low_quality_detail2")

    df_result_a1.unpersist()
    getLowQualityCheckLineidGroup2(spark,df_detail,incDay)
  }

  // 计算 grp2
  def getGrp2(spark: SparkSession, df_result_a:DataFrame, similar_value: Double) = {

    val rdd_grp2 = df_result_a.rdd
      .groupBy(_.getAs[String]("check_lineid"))
      .repartition(3200)
      .flatMap(r => {
        val check_lineid_id: String = r._1
        val arr: Array[JSONObject] = r._2.toArray.sortBy(_.getAs[String]("time")).reverse.map(row2Json)
        arr.foreach(_.put("grp1", check_lineid_id + "_1"))

        // 按key打grp
        val arr2: ArrayBuffer[JSONObject] = groupRoute2(arr,similar_value)

        arr2.iterator
      })

    rdd_grp2
  }

  // 计算同std_id下其他组的平均值 no_grp_mean_time 和 no_grp_mean_dist 和 use_num
  def getNoGrpMeanDistAndTime(spark: SparkSession, df_grp2: DataFrame) = {
    import spark.implicits._

    val rdd_grp2: RDD[JSONObject] = df_grp2.rdd.map(row2Json)
    val df_no_grp_mean = rdd_grp2.repartition(1600).map(obj => {
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val grp2 = JSONUtil.getJsonVal(obj, "grp2", "")
      val rt_dist = JSONUtil.getJsonVal(obj, "rt_dist", "")
      val time = JSONUtil.getJsonVal(obj, "time", "")
      (std_id,(grp2,rt_dist,time))
    }).groupByKey()
      .flatMap(x=>{
        val arr = x._2.toArray
        val ret_arr = new ArrayBuffer[(String,Double,Double,Int)]()
        for (arr_1 <- arr) {
          // 计算 use_num
          val use_num = arr.size
          // dist
          var sum_dist = 0.0
          var cnt_dist = 0
          var no_grp_mean_dist = 0.0
          // time
          var sum_time = 0.0
          var cnt_time = 0
          var no_grp_mean_time = 0.0
          val grp2 = arr_1._1
          for (arr_2 <- arr) {
            if(!grp2.equals(arr_2._1)){
              // dist
              sum_dist = sum_dist + arr_2._2.toDouble
              cnt_dist += 1
              // time
              sum_time = sum_time + arr_2._3.toDouble
              cnt_time += 1
            }
          }
          if(cnt_dist != 0) no_grp_mean_dist = sum_dist / cnt_dist
          if(cnt_time != 0) no_grp_mean_time = sum_time / cnt_time

          ret_arr.append((grp2,no_grp_mean_dist,no_grp_mean_time,use_num))
        }
        ret_arr.iterator
      }).toDF("grp2","no_grp_mean_dist","no_grp_mean_time","use_num")
      .withColumn("rn", row_number().over(Window.partitionBy('grp2).orderBy(desc("no_grp_mean_dist"))))
      .filter('rn === 1)
      .drop("rn","use_num")

    df_no_grp_mean
  }


  // eliminate_std标签字段判断逻辑函数
  def eliminateStdField = udf((check_deleteFlag: String,check_isEcon: String,report_time: String,time_diff: Double,carrier_del: Int) => {
    var ret = ""
    val arr = new ArrayBuffer[String]()
    if(check_deleteFlag != null && check_deleteFlag.trim != "" && !check_deleteFlag.equals("0")) arr.append("已下线线路")
    if(check_isEcon != null && check_isEcon.trim != "" && check_isEcon.equals("0")) arr.append("价值线路")
    if(report_time != null && report_time.trim != "" && report_time.equals("false")) arr.append("近30天提报线路")
    if(time_diff != null && time_diff < 7.0) arr.append("新增7天内线路")
    if(carrier_del == 1) arr.append("承运商操作线路")

    if(!arr.isEmpty) ret = arr.mkString("|")
    ret
  })


  // 分组收集后的排序函数，保证分组收集的所有字段顺序一一对应
  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x, y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  // 将df的每一行数据转为json
  def row2Json(r: Row): JSONObject = {
    val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
    val rowMap: Map[String, String] = rowMap_tmp.map(v => {
      if (v._2 == null) (v._1, "") else v
    })

    val obj: JSONObject = new JSONObject()
    for (m <- rowMap) obj.put(m._1, m._2)
    obj
  }

  // 判断 某个字符串是否为空或者null
  def isEmptyOrNull(str: String): Boolean = {
    var flag: Boolean = false
    if (str == null) flag = true
    else if (str.isEmpty) flag = true
    flag
  }

  // 轨迹格式转换
  def transformTrack(str: String,split_str: String) = {
    var ret_polyline = ""
    if(StringUtils.nonEmpty(str)){
      val point_arr = str.split(split_str)
      val tarcks = new ArrayBuffer[String]()
      for(point <- point_arr){
        tarcks.append(s"[$point]")
      }
      val tarcks_tmp = tarcks.mkString(",")
      ret_polyline = s"[$tarcks_tmp]"
    }

    ret_polyline
  }

  // 解析getLine接口
  def parseGetLineHttpData(ret: JSONObject): (String, String, JSONArray, JSONObject) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        var list_obj = new JSONObject()
        var list_arr = new JSONArray()
        try{
          list_arr = ret.getJSONObject("result").getJSONArray("list")
          list_obj = ret.getJSONObject("result").getJSONArray("list").getJSONObject(0)

        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", list_arr, list_obj)
      }
    }
    ("22", "请求失败", null, null)
  }

  // 调getLine接口
  def runGetLineInteface(ak: String, obj: JSONObject) = {
    val check_lineid = JSONUtil.getJsonVal(obj, "check_lineid", "")
    val lineCode = check_lineid.split("_")(0)
    val srcDeptcode = check_lineid.split("_")(1)
    val destDeptcode = check_lineid.split("_")(2)
    val vehicle = check_lineid.split("_")(3)

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("optUserId", "80006476")
    param.put("vehicle", vehicle)
    param.put("lineCode", lineCode)
    param.put("srcDeptcode", srcDeptcode)
    param.put("destDeptcode", destDeptcode)
    param.put("containDeleted", "False")
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(GET_LINE,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, JSONArray, JSONObject) = parseGetLineHttpData(retJSONObject)
    obj.put("list_arr",httpData._3)

    // 测试字段
    obj.put("check_status",httpData._1)
    obj.put("check_msg",httpData._1)


    obj
  }


  // 解析 qm_point接口返回值
  def parseQMPointHttpData(ret: JSONObject): JSONObject = {
    val ret_obj = new JSONObject()
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getString("info")
        logger.error("获取接口数据失败: " + msg)
        ret_obj.put("new_status",codeStatue)
        ret_obj.put("new_msg",msg)
        return ret_obj
      } else {
        var new_distance = 0.0
        var new_duration = 0.0
        var new_highspeed_distance = 0
        var new_trafficlight_count = 0.0
        var new_tolls = 0
        var new_etc_toll = 0.0
        var new_toll_distance = 0
        val polyline_arr = new ArrayBuffer[String]()
        val toll_name_arr = new ArrayBuffer[String]()
        //依次遍历paths
        try{
          val paths_arr = ret.getJSONObject("route").getJSONArray("paths")
          for(i <- 0 until paths_arr.size){
            val paths_obj = paths_arr.getJSONObject(i)
            new_distance += paths_obj.getDouble("distance")
            new_duration += paths_obj.getDouble("duration")
            new_highspeed_distance += paths_obj.getInteger("highspeed_distance")
            new_trafficlight_count += paths_obj.getDouble("trafficlight_count")
            new_tolls += paths_obj.getInteger("tolls")
            new_etc_toll += paths_obj.getDouble("etc_toll")
            new_toll_distance += paths_obj.getInteger("toll_distance")

            // 循环获取收费站名称
            val steps_arr = paths_obj.getJSONArray("steps")
            for(j <- 0 until steps_arr.size){
              val steps_obj = steps_arr.getJSONObject(j)
              val links_arr = steps_obj.getJSONArray("links")

              for(n <- 0 until links_arr.size){
                val links_obj = links_arr.getJSONObject(n)
                val toll_name = JSONUtil.getJsonVal(links_obj, "toll_name", "")
                if(!toll_name.isEmpty) toll_name_arr.append(toll_name)
              }
            }

            // 轨迹格式转换
            val polyline_tmp = transformTrack(paths_obj.getString("polyline"),";")
            polyline_arr.append(polyline_tmp)
          }
        }catch {
          case e: Exception => logger.error(e)
        }
        val new_coords = polyline_arr.mkString("|")
        val new_toll_name = toll_name_arr.mkString("|")

        ret_obj.put("new_status",codeStatue)
        ret_obj.put("new_distance",new_distance)
        ret_obj.put("new_duration",new_duration)
        ret_obj.put("new_highspeed_distance",new_highspeed_distance)
        ret_obj.put("new_trafficlight_count",new_trafficlight_count)
        ret_obj.put("new_tolls",new_tolls)
        ret_obj.put("new_etc_toll",new_etc_toll)
        ret_obj.put("new_toll_distance",new_toll_distance)
        ret_obj.put("new_coords",new_coords)
        ret_obj.put("paths_num",polyline_arr.size.toString)
        ret_obj.put("new_toll_name",new_toll_name)

        return ret_obj
      }
    }
    ret_obj.put("new_status","22")
    ret_obj.put("new_msg","接口返回为空")
    ret_obj
  }


  // 调 qm_point接口
  def runQMPointInteface(ak:String, obj: JSONObject): JSONObject = {
    val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
    //将数据转换成接口需要的样式
    val points = stdCoordsToPoints(rt_coords)

    //初始化接口请求参数
    val param: String = s"points=$points&test=1&stype=0&etype=0&passport=100000&date=''&mode=2&speed=1&Toll=1&point_src=1&retry_flag=13&ak=$ak"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值,获取roadcdt_type
    val newData: JSONObject = parseQMPointHttpData(retJSONObject)
    obj.put("newData",newData)

    // 用line_id调用配置查询接口，查询出line_id下所有生效中的标准线路
    val obj2 = runGetLineInteface(GET_LINE_AK,obj)
    obj2
  }

  // 格式化 coords
  def formatCoords(coords: String): JSONArray = {

    val tracks2Arr: Array[String] = coords
      .replaceAll("\\[", "")
      .replaceAll("],", ";")
      .replaceAll("]]", "")
      .split(";")

    val tracksArr: JSONArray = new JSONArray()
    for (i <- tracks2Arr.indices) {
      val xy: Array[Double] = tracks2Arr(i).split(",").map(_.toDouble)
      val obj = new JSONObject()
      obj.put("x", xy(0))
      obj.put("y", xy(1))
      obj.put("type", 1)
      tracksArr.add(obj)
    }

    tracksArr
  }

  // 解析接口返回的json
  def parseSimiJson(jsonStr: String): Array[Double] = {
    val arr = new Array[Double](2)
    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("相似度接口调用成功，业务逻辑处理中……")
        val result: JSONObject = o2.getJSONObject("result")
        arr(0) = result.getDoubleValue("similarity1")
        arr(1) = result.getDoubleValue("similarity2")
      }
    } catch {
      case e: Exception => logger.error("相似度接口调用失败:" + e.getMessage)
    }
    arr
  }

//  // 获取2条轨迹的相似度
//  def gettrackSimilarity(ak: String, o1: JSONObject, o2: JSONObject): Array[Double] = {
//    val coord_list1: String = o1.getString("rt_coords")
//    val coord_list2: String = o2.getString("rt_coords")
//
//    val coordArr1: JSONArray = formatCoords(coord_list1)
//    val coordArr2: JSONArray = formatCoords(coord_list2)
//
//    val parm: JSONObject = new JSONObject()
//    parm.put("ak", ak)
//    parm.put("vehicle", 8)
//    parm.put("retflag", 5)
//    parm.put("tracktype", 0)
//    parm.put("tracks1", coordArr1)
//    parm.put("tracks2", coordArr2)
//
//    val jsonStr: String = HttpInvokeUtil.sendPost(Simil_URL,parm.toJSONString,3)
//    val similArr: Array[Double] = parseSimiJson(jsonStr)
//
//    similArr
//  }

  // 按key打grp
  def groupRoute2(arr: Array[JSONObject],similar_value: Double): ArrayBuffer[JSONObject] = {

    val ret_arr = new ArrayBuffer[JSONObject]()
    val groupArray2 = new ArrayBuffer[JSONObject]()
    var grp2_cnt = 0
    var sim1 = -99.0
    var sim5 = -98.0
    var simil_cnt = 0  // 相似度比较次数

    for (o <- arr) {
      var tag2: Int = 0
      if (grp2_cnt == 0) {
        grp2_cnt = grp2_cnt + 1
        o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
        o.put("sim1",sim1)
        o.put("sim5",sim5)
        o.put("simil_cnt",simil_cnt)

        val arr_tmp = new JSONObject()
        arr_tmp.put("rt_coords",o.getString("rt_coords"))
        arr_tmp.put("grp2",o.getString("grp2"))
        groupArray2.append(arr_tmp)
      } else {

        breakable {

          for (array2 <- groupArray2) {
            val rt_coords: String = o.getString("rt_coords")
            val rt_coords2: String = array2.getString("rt_coords")
            if (!isEmptyOrNull(rt_coords) && rt_coords.length > 3 && !isEmptyOrNull(rt_coords2) && rt_coords2.length > 3) {
              // 缩短轨迹点
              val obj_1 = new JSONObject()
              val obj_2 = new JSONObject()

              obj_1.put("rt_coords",rt_coords)
              obj_2.put("rt_coords",rt_coords2)
              logger.error("相似度对比中...")
              // 调用jar包计算相似度
              val simil: pathSimilar.Tuple2[lang.Double, lang.Double] = pathSimilar.PathSimilar.simProcess(obj_1, obj_2)
              sim1 = simil.first
              sim5 = simil.second

//              // 调线上接口计算相似度
//              val simil = gettrackSimilarity(Simil_AK, obj_1, obj_2)
//              sim1 = simil(0)
//              sim5 = simil(1)

              simil_cnt += 1
              logger.error("sim1:"+sim1+"   sim5:"+sim5)
              if (sim1 >= similar_value && sim5 >= similar_value) {
                val grp2: String = array2.getString("grp2")
                o.put("grp2", grp2)
                o.put("sim1", sim1)
                o.put("sim5", sim5)
                o.put("simil_cnt",simil_cnt)

                tag2 = 1
                break()
              }
            }
          }

          if (tag2 == 0) {
            grp2_cnt = grp2_cnt + 1
            o.put("grp2", o.getString("grp1") + "_" + grp2_cnt)
            o.put("sim1",sim1)
            o.put("sim5",sim5)
            o.put("simil_cnt",simil_cnt)
            //            o.put("delete_flag",delete_flag)

            val arr_tmp = new JSONObject()
            arr_tmp.put("rt_coords",o.getString("rt_coords"))
            arr_tmp.put("grp2",o.getString("grp2"))
            groupArray2.append(arr_tmp)
          }
        }

      }
      ret_arr.append(o)
    }

    ret_arr
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    execute(spark, incDay)

//    val df_check_lineid_filter = spark.sql(s"select * from dm_gis.low_quality_check_lineid_group2 where inc_day = '20230818'")
//    getLowQualityEliminateGrp2(spark,df_check_lineid_filter,incDay)
    logger.error("++++++++  任务完成 20231016  ++++")

    spark.stop()
  }

}
