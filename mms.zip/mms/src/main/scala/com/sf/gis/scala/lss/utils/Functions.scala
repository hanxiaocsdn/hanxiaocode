package com.sf.gis.scala.lss.utils

import com.sf.gis.java.base.util.DistanceUtils.getDistance
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

import java.text.SimpleDateFormat
import java.util.Date

object Functions {

  // 获取起点与终点的距离
  def getDist: UserDefinedFunction = udf((startx: String, starty: String, start_srcx_dept: String, start_srcy_dept: String) => {
    var dist: Double = 0.0
    try {
      dist = getDistance(startx.toDouble, starty.toDouble, start_srcx_dept.toDouble, start_srcy_dept.toDouble)
    } catch {
      case e: Exception => println("经纬度异常" + e.getMessage)
    }
    dist
  })

  /**
   * 计算两个日期的时间差，单位为天，保留指定位小数
   * date1: 时间字段1
   * date2: 时间字段2
   * dateFormat：时间格式
   * decimal：保留几位小数
   * @return 时间差 单位为天，保留指定位小数
   */
  def getDateDiff: UserDefinedFunction = udf((date1: String, date2: String, dateFormat: String, decimal: Int) => {
    var date1_time: Double = 0.0
    var date2_time: Double = 0.0
    var datediff = ""
    try {
      date1_time = new SimpleDateFormat(dateFormat).parse(date1).getTime
      date2_time = new SimpleDateFormat(dateFormat).parse(date2).getTime
    } catch {
      case e: Exception => println("date1时间格式错误：" + e.getMessage)
    }
    if(!date1_time.equals(0.0) && !date2_time.equals(0.0)){
      datediff = ((date1_time - date2_time) / (1000*60*60*24)).formatted(s"%.${decimal}f")
    }
    datediff
  })

  /**
   * 两种不同格式时间字符串相互转换
   * @param time
   * @param format
   * @param newFormat
   * @throws
   * @return
   */
  def date_format: UserDefinedFunction = udf((time: String, format1: String, format2: String) => {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  })

}
