package com.sf.gis.scala.lss.application

import java.net.URLEncoder
import java.util.{Calendar, Date}
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer
import com.sf.gis.scala.lss.utils.urlutils.sendPost

/**
 * 快运小哥车油补信息表需求_V1.0
 * 需求方：王润泽（01422002），杨汶铭（ft80006323）
 * 需求描述：当前已通过获取小哥每日收派第一票/最后一票的时间和触碰集配站最早/最晚的时间，来判定小哥每日车油补计算的起止时间，并提供该时间段内的轨迹里程给业务方用于发放车油补。
 * 为提高车效、人效，目前业务上存在小哥执行城配任务、支线融通任务的情况，同时集团财务输出的效益点，指出小哥兼职城配、支线不应该重复发放油补，所以在计算油补里程的时候，
 * 要剔除对应小哥兼职城配、支线时间发生的里程。
 * @author 韩笑（01417629） update：周勇（01390943）
 * Created on Nov.29 2021 更新时间 ： 20230530
 * 旧任务信息：408514（快运小哥车油补信息表，每天16:00执行） 新任务：772620
 */

object ExpressOilReplenishment {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import  spark.implicits._
    val parDay_1 = args(0)//t-1分区
    val parDay_2 = args(1)//t-31分区

    //数据取自：ky.dm_heavy_cargo.emp_mileage_daily_v2
    val sql_1 =
      s"""
         |SELECT
         | emp_code,emp_name,stell_txt,dept_code,dept_name,area_code,area_name,min_barscantm
         |,max_barscantm,mintouchtm,maxtouchtm,miles,piaoshu,jiebo,is_or_not,sy_area_name,sy_area_code
         |,barscantm_204,pis_miles,infer_miles,is_normal,energy_consume,orig_emp_code,vehicle_type,power_type
         |	,case when min_barscantm = '' or min_barscantm IS NULL then '9999-12-31 23:59:59' else min_barscantm end as min_barscantm_1
         |	,case when mintouchtm = '' or mintouchtm IS NULL then '9999-12-31 23:59:59' else mintouchtm end as mintouchtm_1
         |	,case when barscantm_204 = '' or barscantm_204 IS NULL then '9999-12-31 23:59:59' else barscantm_204 end as barscantm_204_1
         |FROM dm_gis.emp_mileage_daily_v2
         |WHERE inc_day = '$parDay_1'
         |""".stripMargin

    val sql_2 =
      s"""
         |SELECT
         |	 emp_code,emp_name,stell_txt,dept_code,dept_name,area_code,area_name
         |,min_barscantm,max_barscantm,mintouchtm,maxtouchtm,miles,piaoshu,jiebo
         |,is_or_not,sy_area_name,sy_area_code,barscantm_204,pis_miles,infer_miles
         |,is_normal,energy_consume,orig_emp_code,vehicle_type,power_type
         |	,CASE WHEN sort_array(array(min_barscantm_1,mintouchtm_1,barscantm_204_1))[0] = '9999-12-31 23:59:59' THEN ''
         |		  ELSE sort_array(array(min_barscantm_1,mintouchtm_1,barscantm_204_1))[0] END AS begintime
         |	,CASE WHEN (max_barscantm = '' OR max_barscantm IS NULL) AND (maxtouchtm = '' OR maxtouchtm IS NULL) THEN ''
         |		  WHEN (max_barscantm <> '' AND max_barscantm IS NOT NULL) AND (maxtouchtm = '' OR maxtouchtm IS NULL) THEN max_barscantm
         |		  WHEN (max_barscantm = '' OR max_barscantm IS NULL) AND (maxtouchtm <> '' AND maxtouchtm IS NOT NULL) THEN maxtouchtm
         |		  WHEN (max_barscantm <> '' AND max_barscantm IS NOT NULL) AND (maxtouchtm <> '' AND maxtouchtm IS NOT NULL) AND (cast(substring(maxtouchtm,12,2) as int) - cast(substring(max_barscantm,12,2) as int)) > 3 THEN max_barscantm
         |		  WHEN (max_barscantm <> '' AND max_barscantm IS NOT NULL) AND (maxtouchtm <> '' AND maxtouchtm IS NOT NULL) AND (cast(substring(maxtouchtm,12,2) as int) - cast(substring(max_barscantm,12,2) as int)) <= 3 THEN sort_array(array(max_barscantm,maxtouchtm))[1]
         |          ELSE '' end AS endtime
         |FROM tmp
         |""".stripMargin

    val resDF = spark.sql(sql_1)
      .withColumn("rank",row_number().over(Window.partitionBy("emp_code").orderBy(desc("barscantm_204_1"))))
      .filter($"rank"===1)
      .drop("rank")

    resDF.createOrReplaceTempView("tmp")

    //清洗网点维表
    val dept_info=spark.sql(
      s"""
         | select dept_code,longitude,latitude,modify_tm from dim.dim_dept_info_df
         | where inc_day = '$parDay_1'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("dept_code").orderBy(desc("modify_tm"))))
      .filter($"rank"===1)
      .select("dept_code","longitude","latitude")

    //获取v2表数据
    logger.error("开始执行Getoilfee_all")
    Getoilfee_all(spark,sql_2)
    val Getoilfee=spark.sql(
      """
        | select * from dm_gis.emp_mileage_daily_tracks_mid
        |""".stripMargin).repartition(600)

    logger.error("执行完成Getoilfee_all")

    logger.error("开始执行aoi_res2")
    aoi_res2(spark,parDay_1)

    val aoi_res2_res=spark.sql(
      s"""
         | select * from dm_gis.dm_track_mid_res_tmp
         |""".stripMargin)
      .coalesce(1)
    logger.error("已执行aoi_res2")

    //计算小哥始发和终止的前后5分钟是否在网点区域内
    val stend5=Getoilfee.select("emp_code","dept_code","track_x","track_y")
      .join(dept_info,Seq("dept_code"),"left")
      .select("emp_code","longitude","latitude","track_x","track_y")

    val stend5_res= SparkUtils.getDfToJson(spark, stend5, 10)
      .map(obj=>{
        val emp_code = obj.getString( "emp_code")
        val longitude = obj.getString( "longitude")
        val latitude = obj.getString( "latitude")
        val track_x= obj.getString( "track_x")
        val track_y= obj.getString( "track_y")
        logger.error("当前计算emp_code"+emp_code)
        //先判断起始时间
        val track_x_jsary=JSON.parseArray(track_x)
        var start_code_type1=""
        if(track_x_jsary !=null && track_x_jsary.size()>0 && longitude !=null && longitude.trim != "" && latitude !=null && latitude.trim != "") {
          start_code_type1 = "否"
          val track_x_size = track_x_jsary.size()
          var i = 0
          while (start_code_type1 == "否" && i < track_x_size) {
            val track_x_jsary_i_x = track_x_jsary.getJSONObject(i).getString("dx")
            val track_x_jsary_i_y = track_x_jsary.getJSONObject(i).getString("dy")
            //计算地图距离
            val distance = getDistance(track_x_jsary_i_x, track_x_jsary_i_y, longitude, latitude)
            if (distance < 300.0) {
              start_code_type1 = "是"
            }
            else {
              start_code_type1 = "否"
            }
            i=i+1
          }
        }

        //再判断结束时间
        val track_y_jsary=JSON.parseArray(track_y)
        var end_code_type1=""
        if(track_y_jsary !=null && track_y_jsary.size()>0 && longitude !=null && longitude.trim != "" && latitude !=null && latitude.trim != ""){
          end_code_type1="否"
          val track_y_size=track_y_jsary.size()
          var i=0
          while(end_code_type1=="否" && i<track_y_size){
            val track_y_jsary_i_x=track_y_jsary.getJSONObject(i).getString("dx")
            val track_y_jsary_i_y=track_y_jsary.getJSONObject(i).getString("dy")
            //计算地图距离
            val distance2=getDistance(track_y_jsary_i_x,track_y_jsary_i_y,longitude,latitude)
            if(distance2<300.0){
              end_code_type1="是"
            }
            else
            {end_code_type1="否"}
            i=i+1
          }
        }

        (emp_code,start_code_type1,end_code_type1)
      }).toDF("emp_code","start_code_type1","end_code_type1")

    stend5_res.createOrReplaceTempView("stend5_resmp_tb")
    //存入临时库表
    spark.sql(
      """
        |insert overwrite table dm_gis.dm_track_mid_res5_tmp
        |select emp_code,start_code_type1,end_code_type1
        |from stend5_resmp_tb
        |""".stripMargin)
    logger.error("存入临时库表dm_track_mid_res5_tmp")

    val stend5_res2=spark.sql(
      """
        |select emp_code,start_code_type1,end_code_type1
        |from dm_gis.dm_track_mid_res5_tmp
        |""".stripMargin)
      .coalesce(1)

    //计算城配任务是否在区域范围内
    logger.error("执行aoi_res")

    //计算城配数据
    logger.error("开始执行getcp")
    getcp(spark,parDay_1,parDay_2,sql_2)
    val Getcpfee=spark.sql(
      """
        | select * from dm_gis.emp_oilstendtime_tmp
        |""".stripMargin)
      .select("emp_code","fczy_order_len","fczy_order_list")
      .coalesce(1)
    logger.error("执行完成getcp")

    //计算支线数据
    logger.error("开始执行getgrdtask")
    getgrdtask(spark,parDay_1,sql_2)
    val Getslfee=spark.sql(
      """
        | select * from dm_gis.emp_oilstendtime_tmp_sl2
        |""".stripMargin)
      .select("emp_code","grd_task_len","grd_task_list")
      .coalesce(1)
    logger.error("执行完成getgrdtask")

    //数据合并
    val tb_cols = spark.sql("""select * from dm_gis.emp_mileage_daily_tracks limit 0""").schema.map(_.name).map(col)
    val resultdata=Getoilfee.join(Getcpfee,Seq("emp_code"),"left")
      .join(Getslfee,Seq("emp_code"),"left")
      .withColumnRenamed("len","original_len")
      .withColumn("original_len",when($"original_len".isNull || trim($"original_len")==="",0.0).otherwise($"original_len"))
      .withColumn("fczy_order_len",when($"fczy_order_len".isNull || trim($"fczy_order_len")==="",0.0).otherwise($"fczy_order_len"))
      .withColumn("grd_task_len",when($"grd_task_len".isNull || trim($"grd_task_len")==="",0.0).otherwise($"grd_task_len"))
      //特殊处理fczy_order_len和grd_task_len
      .withColumn("fczy_order_len",when($"fczy_order_len".cast("double")>$"original_len".cast("double"),$"original_len").otherwise($"fczy_order_len"))
      .withColumn("grd_task_len",when($"grd_task_len".cast("double")>$"original_len".cast("double"),$"original_len").otherwise($"grd_task_len"))
      .withColumn("len",$"original_len"-$"fczy_order_len"-$"grd_task_len")
      //当日删除里程数
      .withColumn("del_len",when($"fczy_order_len".cast("double")+$"grd_task_len".cast("double")>$"original_len".cast("double"),$"original_len").otherwise($"fczy_order_len".cast("double")+$"grd_task_len".cast("double")))
      .withColumn("len",when($"len".cast("double")<0,0).otherwise($"len"))

      //m转换为公里
      //.withColumn("len",$"len".cast("double"))
      //.withColumn("original_len",$"original_len".cast("double"))
      //.withColumn("fczy_order_len",$"fczy_order_len".cast("double"))
      //.withColumn("grd_task_len",$"grd_task_len".cast("double"))
      //.withColumn("del_len",$"del_len".cast("double"))
      .withColumn("inc_day",lit(parDay_1))
      .join(stend5_res2,Seq("emp_code"),"left")
      .join(aoi_res2_res,Seq("emp_code"),"left")
      .withColumn("start_code_type",when($"start_code_type1"==="是" || $"start_code_type2"==="是" ,"是")
        .when($"start_code_type1"==="否" || $"start_code_type2"==="否" ,"否").otherwise(""))
      .withColumn("end_code_type",when($"end_code_type1"==="是" || $"end_code_type2"==="是" ,"是")
        .when($"end_code_type1"==="否" || $"end_code_type2"==="否" ,"否").otherwise(""))
      .select(tb_cols:_*)

    //存储表
    logger.error("开始落表")
    writeToHive(spark, resultdata.coalesce(10), Seq("inc_day"), "dm_gis.emp_mileage_daily_tracks")


    logger.error("执行完毕！")

    spark.close()
  }

  //计算aoi是否符合
  def aoi_res2(spark: SparkSession,parDay_1:String): Unit ={
    import spark.implicits._

    //小哥当天排班所有aoi_id
    val aoi_id=spark.sql(
      s"""
         | select loginid,aoi_id from dm_gis.schedule_width_data
         | where inc_day = '$parDay_1'
         | group by loginid,aoi_id
         |""".stripMargin)
      .withColumn("emp_code",lpad($"loginid",8,"0"))
      .groupBy("emp_code")
      .agg(
        concat_ws(",",collect_list($"aoi_id")) as "aoi_id_list"
      )

    //获取小哥工号
    val track_mid=spark.sql(
      """
        | select emp_code,track_x,track_y from dm_gis.emp_mileage_daily_tracks_mid
        |""".stripMargin)
      .join(aoi_id,Seq("emp_code"),"left")

    logger.error("track_mid数据量"+track_mid.count())

    val track_mid_a=SparkUtils.getDfToJson(spark, track_mid, 5)
      .map(obj=>{
        val emp_code = obj.getString( "emp_code")
        val track_x = obj.getString( "track_x")
        val track_y = obj.getString( "track_y")
        val aoi_id_list = obj.getString( "aoi_id_list")
        logger.error("当前计算emp_code2"+emp_code)
        //计算上班时间
        val track_x_arr=JSON.parseArray(track_x)
        var start_code_type2=""
        var end_code_type2=""
        var err_msg1=""
        var err_msg2=""
        if(track_x_arr !=null && track_x_arr.size()>0){
          start_code_type2="否"
          val track_x_size=track_x_arr.size()
          var i=0
          while(start_code_type2=="否" && i<track_x_size){
            val track_x_arr_i_x=track_x_arr.getJSONObject(i).getString("dx")
            val track_x_arr_i_y=track_x_arr.getJSONObject(i).getString("dy")
            val x = track_x_arr_i_x.trim
            val y = track_x_arr_i_y.trim
            val ak = "7de625f357454715825cf094433c95ef"
            //获取接口数据
            val url = s"http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy2?x=$x&y=$y&ak=$ak"
            try{
              val aoi_id_list_arry=aoi_id_list.split(",")
              val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 20)

              val ret: JSONObject = JSON.parseObject(retStr)
              val aoi_code = ret.getJSONObject("result").getJSONObject("data").getJSONObject("aoi").getString("aoi_code")
              logger.error("当前获取接口成功"+emp_code)
              if(aoi_id_list_arry.contains(aoi_code)){start_code_type2="是"}
            }
            catch{
              case e: Exception => logger.error(e)
                obj.put("err_msg1",e.getMessage)
                err_msg1=e.getMessage
                logger.error("当前获取接口失败"+e.getMessage)
            }
            i=i+1
          }
          //计算下班时间
          val track_y_arr=JSON.parseArray(track_y)
          if(track_y_arr !=null && track_y_arr.size()>0){
            end_code_type2="否"
            val track_y_size=track_y_arr.size()
            var i=0
            while(end_code_type2=="否" && i<track_y_size){
              val track_y_arr_i_x=track_y_arr.getJSONObject(i).getString("dx")
              val track_y_arr_i_y=track_y_arr.getJSONObject(i).getString("dy")
              val x = track_y_arr_i_x.trim
              val y = track_y_arr_i_y.trim
              val ak = "7de625f357454715825cf094433c95ef"
              //获取接口数据
              val url = s"http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy2?x=$x&y=$y&ak=$ak"
              try{
                val aoi_id_list_arry=aoi_id_list.split(",")
                val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 20)
                val ret: JSONObject = JSON.parseObject(retStr)
                val aoi_code = ret.getJSONObject("result").getJSONObject("data").getJSONObject("aoi").getString("aoi_code")
                if(aoi_id_list_arry.contains(aoi_code)){end_code_type2="是"}
                logger.error("当前获取接口成功22"+emp_code)
              }
              catch{
                case e: Exception => logger.error(e)
                  obj.put("err_msg2",e.getMessage)
                  err_msg2=e.getMessage
                  logger.error("当前获取接口失败22"+e.getMessage)
              }
              i=i+1
            }
          }
        }
        (emp_code,start_code_type2,end_code_type2,err_msg1,err_msg2)}).toDF("emp_code","start_code_type2","end_code_type2","err_msg1","err_msg2")


    track_mid_a.createOrReplaceTempView("track_mid_atmp_tb")
    //存入临时库表
    spark.sql(
      """
        |insert overwrite table dm_gis.dm_track_mid_res_tmp
        |select emp_code,start_code_type2,end_code_type2,err_msg1,err_msg2
        |from track_mid_atmp_tb
        |""".stripMargin)
    logger.error("存入临时库表1！")

  }

  //计算aoi是否符合
  def aoi_res(spark: SparkSession): Unit ={
    import spark.implicits._
    //获取小哥工号
    val track_mid=spark.sql(
      """
        | select emp_code,track_x,track_y from dm_gis.emp_mileage_daily_tracks_mid
        |""".stripMargin).repartition(300)
      .withColumn("track_x_tmp",regexp_replace(regexp_replace($"track_x","\\[|\\]",""),"\\}\\,\\{","\\}\\|\\{"))
      .withColumn("track_y_tmp",regexp_replace(regexp_replace($"track_y","\\[|\\]",""),"\\}\\,\\{","\\}\\|\\{"))
      .select("emp_code","track_x_tmp","track_y_tmp")

    //列转行
    val track_mid_tmp=track_mid.select("emp_code","track_x_tmp")
      .withColumn("tmp",explode(split($"track_x_tmp","[|]")))
      .select("emp_code","tmp")
      .withColumn("dx",get_json_object($"tmp","$.dx"))
      .withColumn("dy",get_json_object($"tmp","$.dy"))

    logger.error("track_mid_tmp数据量"+track_mid_tmp.count())

    val (excutors, cores) = Spark.getExcutorInfo(spark)

    //计算并行数
    val calPartitions = excutors * cores * 3

    val sql_Rdd2: RDD[JSONObject] = SparkUtils.getDfToJson(spark, track_mid_tmp, calPartitions)
    //并发获取接口
    val track_mid_res=Multi_trackquery_aoi(spark,sql_Rdd2,calPartitions)

    val track_mid_res2=track_mid_res.map(obj=>{
      val emp_code = obj.getString( "emp_code")
      val x = obj.getString( "dx")
      val y = obj.getString( "dy")
      val aoi_code = obj.getString( "aoi_code")
      (emp_code,x,y,aoi_code)
    }).toDF("emp_code","x","y","aoi_code")

    track_mid_res2.createOrReplaceTempView("track_mid_res2_tb")
    //存入临时库表
    spark.sql(
      """
        |insert overwrite table dm_gis.dm_track_mid_res1
        |select emp_code,x,y,aoi_code
        |from track_mid_res2_tb
        |""".stripMargin)
    logger.error("存入临时库表1！")

    //列转行
    val track_mid_tmp2=track_mid.select("emp_code","track_y_tmp")
      .withColumn("tmp",explode(split($"track_y_tmp","[|]")))
      .select("emp_code","tmp")
      .withColumn("dx",get_json_object($"tmp","$.dx"))
      .withColumn("dy",get_json_object($"tmp","$.dy"))

    logger.error("track_mid_tmp2数据量"+track_mid_tmp2.count())

    val sql_Rdd3: RDD[JSONObject] = SparkUtils.getDfToJson(spark, track_mid_tmp2, calPartitions)
    //并发获取接口
    val track_mid_res3=Multi_trackquery_aoi(spark,sql_Rdd3,calPartitions)

    val track_mid_res4=track_mid_res3.map(obj=>{
      val emp_code = obj.getString( "emp_code")
      val x = obj.getString( "dx")
      val y = obj.getString( "dy")
      val aoi_code = obj.getString( "aoi_code")
      (emp_code,x,y,aoi_code)
    }).toDF("emp_code","x","y","aoi_code")

    track_mid_res4.createOrReplaceTempView("track_mid_res4_tb")
    //存入临时库表
    spark.sql(
      """
        |insert overwrite table dm_gis.dm_track_mid_res2
        |select emp_code,x,y,aoi_code
        |from track_mid_res4_tb
        |""".stripMargin)
    logger.error("存入临时库表1！")

  }

  //获取油补起始终止时间
  def Getoilfee_all(spark: SparkSession,sql_2:String):Unit={
    import spark.implicits._

    //原数据
    val data1=spark.sql(sql_2).repartition(600)
    //选取数据调取接口
    val data1_1=data1.select("orig_emp_code","begintime","endtime")
      .withColumn("emp_no",$"orig_emp_code")
      .withColumn("sttime2",$"begintime")
      .withColumn("endtime2",$"endtime")
      .withColumn("sttime2_a",when($"begintime".isNull || trim($"begintime")==="","").otherwise(getminisBeforeOrAfter_udf($"begintime",lit(-5))))
      .withColumn("sttime2_b",when($"begintime".isNull || trim($"begintime")==="","").otherwise(getminisBeforeOrAfter_udf($"begintime",lit(5))))
      .withColumn("endtime2_a",when($"endtime".isNull || trim($"endtime")==="","").otherwise(getminisBeforeOrAfter_udf($"endtime",lit(-5))))
      .withColumn("endtime2_b",when($"endtime".isNull || trim($"endtime")==="","").otherwise(getminisBeforeOrAfter_udf($"endtime",lit(5))))

    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3
    val sql_Rdd0: RDD[JSONObject] = SparkUtils.getDfToJson(spark, data1_1, calPartitions)
    //并发获取接口
    val OilRdd_result_all=Multi_trackquery_stend(spark,sql_Rdd0,calPartitions)

    val Oildf_result_all1=OilRdd_result_all.map(obj=>{
      val orig_emp_code = obj.getString( "orig_emp_code")
      val len = obj.getString( "order_len")
      val track = obj.getString( "track")
      val track_x= obj.getString( "track_x")
      val track_y= obj.getString( "track_y")
      (orig_emp_code,len,track,track_x,track_y)
    }).toDF("orig_emp_code","len","track","track_x","track_y")
      .withColumn("start_crood",when($"track_x".isNull || trim($"track_x")==="","否").otherwise("是"))
      .withColumn("end_crood",when($"track_y".isNull || trim($"track_y")==="","否").otherwise("是"))

    logger.error("接口跑完1！")
    val data2=data1.join(Oildf_result_all1,Seq("orig_emp_code"),"left").coalesce(20)

    data2.createOrReplaceTempView("data2_tb")
    //存入临时库表
    spark.sql(
      """
        |insert overwrite table dm_gis.emp_mileage_daily_tracks_mid
        |select emp_code,emp_name,stell_txt,dept_code,dept_name,area_code,area_name,min_barscantm,
        |max_barscantm,mintouchtm,maxtouchtm,miles,piaoshu,jiebo,is_or_not,sy_area_name,
        |sy_area_code,barscantm_204,pis_miles,infer_miles,is_normal,energy_consume,
        |orig_emp_code,vehicle_type,power_type,begintime,endtime,len,track,track_x,track_y,start_crood,end_crood
        |from data2_tb
        |""".stripMargin)
    logger.error("存入临时库表！")
  }

  //获取城配数据
  def getcp(spark:SparkSession,parDay_1:String,parDay_2:String,sql_2:String): Unit ={
    import spark.implicits._
    //城配订单，数据取自：dws_freight.dws_mkt_fczy_order_dtl_di
    val fczy_order=spark.sql(
      s"""
         |select case when length(emp_no)<=8 then lpad(emp_no,8,'0') else emp_no end emp_code,
         | order_no,car_order_no,emp_no,substr(depart_clock_time,0,19) depart_clock_time,substr(arrive_clock_time,0,19) arrive_clock_time,vehicle_number
         | from dm_gis.dws_mkt_fczy_order_dtl_di
         |where inc_day>='$parDay_2' and inc_day<='$parDay_1'
         |and regexp_replace(substr(arrive_clock_time,0,10),'-','')='$parDay_1'
         |and emp_no is not null and trim(emp_no) !=''
         |""".stripMargin)
      .withColumn("car_no",$"vehicle_number")

    //油补起始时间和结束时间
    val oilstendtime=spark.sql(sql_2).select("emp_code","orig_emp_code","begintime","endtime")
      .withColumn("emp_no",$"orig_emp_code")
      .repartition(300)
      .join(fczy_order.drop("emp_no"),Seq("emp_code"),"left")
      //是否剔除
      .withColumn("is_delete",when($"arrive_clock_time"<$"begintime","否")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime","是")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime","是")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time">$"endtime","是")
        .when($"depart_clock_time">$"endtime","否")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime","是")
      )
      //轨迹查询开始时间
      .withColumn("new_start_time",when($"arrive_clock_time"<$"begintime","")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime",$"begintime")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime",$"depart_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time">$"endtime",$"depart_clock_time")
        .when($"depart_clock_time">$"endtime","")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime",$"begintime")
      )
      //轨迹查询结束时间
      .withColumn("new_end_time",when($"arrive_clock_time"<$"begintime","")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime",$"arrive_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime",$"arrive_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time">$"endtime",$"endtime")
        .when($"depart_clock_time">$"endtime","")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime",$"endtime")
      )

    //按照新的起始时间端合并，"sttime2","endtime2"分别为新的需剔除的时间段
    val oilstendtime2=oilstendtime.filter($"is_delete"==="是")
      .withColumn("time_hebing",concat($"new_start_time",lit(","),$"new_end_time"))
      .groupBy("emp_code","emp_no")
      .agg(concat_ws(";",sort_array(collect_list($"time_hebing"))) as "time_list")
      .withColumn("time_list_arr",when($"time_list".isNull || trim($"time_list")==="","").otherwise(newtime_udf($"time_list")))
      .withColumn("time_str",explode(split($"time_list_arr","[|]")))
      .withColumn("sttime2",split($"time_str",",")(0))
      .withColumn("endtime2",split($"time_str",",")(1))
      .select("emp_code","emp_no","sttime2","endtime2")

    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, oilstendtime2, calPartitions)
    //并发获取接口
    val OilRdd_result=Multi_trackquery(spark,sql_Rdd,calPartitions)

    val Oildf_result1=OilRdd_result.map(obj=>{
      val emp_code = obj.getString( "emp_code")
      val emp_no = obj.getString( "emp_no")
      val sttime2 = obj.getString( "sttime2")
      val endtime2 = obj.getString( "endtime2")
      val order_len = obj.getString( "order_len")
      val ret = obj.getString( "ret")
      (emp_code,sttime2,endtime2,order_len,ret)
    }).toDF("emp_code","sttime2","endtime2","order_len","ret")
      .withColumn("order_len",when($"order_len".isNull || trim($"order_len")==="",0.0).otherwise($"order_len"))

    //  spark.sql("drop table if exists tmp_dm_gis.Oildf_result1")
    //  Oildf_result1.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.Oildf_result1")

    //将城配的剔除数据汇总
    val Oildf_result1_result=Oildf_result1.groupBy("emp_code")
      .agg(sum($"order_len".cast("double")) as "fczy_order_len")

    //  spark.sql("drop table if exists tmp_dm_gis.Oildf_result1_result")
    //  Oildf_result1_result.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.Oildf_result1_result")

    val Oildf_result=oilstendtime.join(Oildf_result1,Seq("emp_code"),"left")
      .withColumn("sttime2",when($"is_delete"==="是",$"sttime2").otherwise(""))
      .withColumn("endtime2",when($"is_delete"==="是",$"endtime2").otherwise(""))
      .filter(($"is_delete"==="是" && $"sttime2"<=$"new_start_time" && $"new_end_time"<=$"endtime2" )||$"is_delete"==="否")
      .withColumn("order_no_tmp",concat_ws("",lit("\"order_no\":"),concat(lit("\""),$"order_no",lit("\""))))
      .withColumn("car_order_no_tmp",concat_ws("",lit("\"car_order_no\":"),concat(lit("\""),$"car_order_no",lit("\""))))
      .withColumn("emp_no_tmp",concat_ws("",lit("\"emp_no\":"),concat(lit("\""),$"emp_no",lit("\""))))
      .withColumn("depart_clock_time_tmp",concat_ws("",lit("\"depart_clock_time\":"),concat(lit("\""),$"depart_clock_time",lit("\""))))
      .withColumn("arrive_clock_time_tmp",concat_ws("",lit("\"arrive_clock_time\":"),concat(lit("\""),$"arrive_clock_time",lit("\""))))
      .withColumn("vehicle_number_tmp",concat_ws("",lit("\"vehicle_number\":"),concat(lit("\""),$"vehicle_number",lit("\""))))
      .withColumn("is_delete_tmp",concat_ws("",lit("\"is_delete\":"),concat(lit("\""),$"is_delete",lit("\""))))
      .withColumn("new_start_time_tmp",concat_ws("",lit("\"new_start_time\":"),concat(lit("\""),$"new_start_time",lit("\""))))
      .withColumn("new_end_time_tmp",concat_ws("",lit("\"new_end_time\":"),concat(lit("\""),$"new_end_time",lit("\""))))
      .withColumn("len_tmp",concat_ws("",lit("\"len\":"),concat(lit("\""),$"order_len",lit("\""))))
      .withColumn("sttime2_tmp",concat_ws("",lit("\"sttime2\":"),concat(lit("\""),$"sttime2",lit("\""))))
      .withColumn("endtime2_tmp",concat_ws("",lit("\"endtime2\":"),concat(lit("\""),$"endtime2",lit("\""))))
      .withColumn("hebing",concat(lit("{"),concat_ws(",",$"order_no_tmp",$"car_order_no_tmp",$"emp_no_tmp",$"depart_clock_time_tmp",$"arrive_clock_time_tmp",
        $"vehicle_number_tmp", $"is_delete_tmp", $"new_start_time_tmp", $"new_end_time_tmp", $"len_tmp", $"sttime2_tmp", $"endtime2_tmp"),lit("}")))
      .groupBy("emp_code")
      .agg(
        concat_ws(",",collect_list($"hebing")) as "order_list"
      )
      .withColumn("fczy_order_list",concat(lit("{\"json\":["),$"order_list",lit("]}")))
      .join(Oildf_result1_result,Seq("emp_code"),"left")
      .withColumn("fczy_order_len",when($"fczy_order_len".isNull || trim($"fczy_order_len")==="",0.0).otherwise($"fczy_order_len"))
      .coalesce(20)

    Oildf_result.createOrReplaceTempView("Oildf_result_tb")
    spark.sql(
      """
        |insert overwrite table dm_gis.emp_oilstendtime_tmp
        |select emp_code,fczy_order_len,order_list, fczy_order_list from Oildf_result_tb
        |""".stripMargin)
  }

  //定义获取url数据
  def trackquery_url_aoi(ak:String,obj:JSONObject): JSONObject = {
    try {
      val x = obj.getString("dx").trim
      val y = obj.getString("dy").trim
      val ak = "7de625f357454715825cf094433c95ef"
      //获取接口数据
        val url = s"http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy2?x=$x&y=$y&ak=$ak"
      val retStr: String = HttpInvokeUtil.sendGet(url, "UTF-8", 10)
      val ret: JSONObject = JSON.parseObject(retStr)
      val aoi_code = ret.getJSONObject("result").getJSONObject("data").getJSONObject("aoi").getString("aoi_code")
      obj.put("aoi_code",aoi_code)
    }
    catch{
      case e: Exception => logger.error(e)
        obj.put("err_msg",e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制2500，而每次的函数调用有3次，因此这里要限制到700
  def Multi_trackquery_aoi(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl = s"http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy2"
    val httpAk="7de625f357454715825cf094433c95ef"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "772620", "快运小哥车油补信息表需求",
      "大件小哥会发放油补，但是小哥兼职城配、支线不应该重复发放油补，需要剔除",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, trackquery_url_aoi, 6, "7de625f357454715825cf094433c95ef", 4000)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

  //获取支线任务数据
  def getgrdtask(spark:SparkSession,parDay_1:String,sql_2:String): Unit ={
    import spark.implicits._
    //支线任务计算
    val grd_order=spark.sql(
      s"""
         |select
         | task_id,driver_id,main_driver_account as emp_no,actual_depart_tm,actual_arrive_tm,vehicle_serial,
         | case when length(main_driver_account)<=8 then lpad(main_driver_account,8,'0') else main_driver_account end emp_code
         | from dm_grd.grd_new_task_detail
         |where inc_day='$parDay_1' and state='6'
         |and transoport_level !='4' and transoport_level is not null
         |""".stripMargin)
      .withColumn("car_no",$"vehicle_serial")
      .withColumn("actual_arrive_day",when($"actual_arrive_tm".isNull || trim($"actual_arrive_tm")==="","")
        .otherwise(regexp_replace($"actual_arrive_tm".substr(1,10),"-","")))
      .withColumn("actual_depart_day",when($"actual_depart_tm".isNull || trim($"actual_depart_tm")==="","")
        .otherwise(regexp_replace($"actual_depart_tm".substr(1,10),"-","")))
      .filter($"actual_depart_day"===parDay_1 && $"actual_arrive_day"===parDay_1)
      .drop("actual_arrive_day","actual_depart_day")

    //人资表明文
    val emp_imfo=spark.sql(
      s"""
         |select
         | case when length(emp_code)<=8 then lpad(emp_code,8,'0') else emp_code end emp_code_org,
         | card_no
         | from tmp_dm_gis.tempzy20230627_driver
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("card_no").orderBy(desc("emp_code_org"))))
      .filter($"rank"===1)
      .drop("rank")

    //顺路员工表明文
    val shunluemp_imfo=spark.sql(
      s"""
         |select
         | user_name as emp_code,
         | card_no,modify_tm
         | from tmp_dm_gis.tempzy20230627_sl_driver
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("card_no").orderBy(desc("modify_tm"))))
      .filter($"rank"===1)
      .select("emp_code","card_no")

    //油补明细匹配顺路工号
    val drivers_sl_a=spark.sql(sql_2)
      .withColumn("emp_code_org",$"emp_code")
      .select("emp_code_org","orig_emp_code","begintime","endtime").repartition(300)
      //得到身份证号
      .join(emp_imfo,Seq("emp_code_org"),"left")
      //匹配顺路的工号
      .join(shunluemp_imfo,Seq("card_no"),"left")
      //emp_code_org为内部公号，emp_code为顺陆工号
      .select("emp_code_org","orig_emp_code","emp_code","begintime","endtime")

    //内部公号和顺陆工号都要匹配，最后汇总计算
    val drivers_sl_b=drivers_sl_a.withColumn("emp_code",$"emp_code_org")
      .select("emp_code_org","orig_emp_code","emp_code","begintime","endtime")

    val drivers_sl=drivers_sl_a.union(drivers_sl_b)

    //油补起始时间和结束时间
    val oilstendtime_sl=drivers_sl
      .join(grd_order,Seq("emp_code"),"left")
      .withColumn("depart_clock_time",$"actual_depart_tm")
      .withColumn("arrive_clock_time",$"actual_arrive_tm")
      //是否剔除
      .withColumn("is_delete",when($"arrive_clock_time"<$"begintime","否")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime","是")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime","是")
        .when($"depart_clock_time">=$"begintime" && $"depart_clock_time"<$"endtime" && $"arrive_clock_time">$"endtime","是")
        .when($"depart_clock_time">$"endtime","否")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime","是")
      )
      //轨迹查询开始时间
      .withColumn("new_start_time",when($"arrive_clock_time"<$"begintime","")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime",$"begintime")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime",$"depart_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"depart_clock_time"<$"endtime" && $"arrive_clock_time">$"endtime",$"depart_clock_time")
        .when($"depart_clock_time">$"endtime","")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime",$"begintime")
      )
      //轨迹查询结束时间
      .withColumn("new_end_time",when($"arrive_clock_time"<$"begintime","")
        .when($"depart_clock_time"<$"begintime" && $"arrive_clock_time"<$"endtime",$"arrive_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"arrive_clock_time"<=$"endtime",$"arrive_clock_time")
        .when($"depart_clock_time">=$"begintime" && $"depart_clock_time"<$"endtime" && $"arrive_clock_time">$"endtime",$"endtime")
        .when($"depart_clock_time">$"endtime","")
        .when($"depart_clock_time"<=$"begintime" && $"arrive_clock_time">=$"endtime",$"endtime")
      )
      .withColumn("emp_no",$"orig_emp_code")

    //按照新的起始时间端合并，"sttime2","endtime2"分别为新的需剔除的时间段
    val oilstendtime2_sl=oilstendtime_sl.filter($"is_delete"==="是")
      .withColumn("time_hebing",concat($"new_start_time",lit(","),$"new_end_time"))
      .groupBy("emp_code","emp_code_org","emp_no")
      .agg(concat_ws(";",sort_array(collect_list($"time_hebing"))) as "time_list")
      .withColumn("time_list_arr",when($"time_list".isNull || trim($"time_list")==="","").otherwise(newtime_udf($"time_list")))
      .withColumn("time_str",explode(split($"time_list_arr","[|]")))
      .withColumn("sttime2",split($"time_str",",")(0))
      .withColumn("endtime2",split($"time_str",",")(1))
      .select("emp_code","emp_code_org","emp_no","sttime2","endtime2")

    val (excutors, cores) = Spark.getExcutorInfo(spark)

    //计算并行数
    val calPartitions = excutors * cores * 3

    val sql_Rdd2: RDD[JSONObject] = SparkUtils.getDfToJson(spark, oilstendtime2_sl, calPartitions)
    //并发获取接口
    val OilRdd_result2_sl=Multi_trackquery(spark,sql_Rdd2,calPartitions)

    val Oildf_result1_sl=OilRdd_result2_sl.map(obj=>{
      val emp_code = obj.getString( "emp_code")
      val emp_code_org = obj.getString( "emp_code_org")
      val emp_no = obj.getString( "emp_no")
      val sttime2 = obj.getString( "sttime2")
      val endtime2 = obj.getString( "endtime2")
      val order_len = obj.getString( "order_len")
      val ret= obj.getString( "ret")
      (emp_code,emp_code_org,sttime2,endtime2,order_len,ret)
    }).toDF("emp_code","emp_code_org","sttime2","endtime2","order_len","ret")
      .withColumn("order_len",when($"order_len".isNull || trim($"order_len")==="",0.0).otherwise($"order_len"))

    //    spark.sql("drop table if exists tmp_dm_gis.Oildf_result1_sl")
    //    Oildf_result1_sl.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.Oildf_result1_sl")

    //将支线的剔除数据汇总，用内部公号汇总
    val Oildf_result1_result_sl=Oildf_result1_sl
      .select("emp_code_org","order_len")
      .withColumn("emp_code",$"emp_code_org")
      .groupBy("emp_code")
      .agg(sum($"order_len".cast("double")) as "fczy_order_len")

    //    spark.sql("drop table if exists tmp_dm_gis.Oildf_result1_result_sl")
    //    Oildf_result1_result_sl.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.Oildf_result1_result_sl")

    val Oildf_result_sl=oilstendtime_sl.join(Oildf_result1_sl.drop("emp_code").withColumn("emp_code",$"emp_code_org").drop("emp_code_org")
      ,Seq("emp_code"),"left")
      .withColumn("sttime2",when($"is_delete"==="是",$"sttime2").otherwise(""))
      .withColumn("endtime2",when($"is_delete"==="是",$"endtime2").otherwise(""))
      .filter(($"is_delete"==="是" && $"sttime2"<=$"new_start_time" && $"new_end_time"<=$"endtime2" )||$"is_delete"==="否")
      .withColumn("task_id_tmp",concat_ws("",lit("\"task_id\":"),concat(lit("\""),$"task_id",lit("\""))))
      .withColumn("driver_id_tmp",concat_ws("",lit("\"driver_id\":"),concat(lit("\""),$"driver_id",lit("\""))))
      .withColumn("main_driver_account_tmp",concat_ws("",lit("\"main_driver_account\":"),concat(lit("\""),$"emp_no",lit("\""))))
      .withColumn("actual_depart_tm_tmp",concat_ws("",lit("\"actual_depart_tm\":"),concat(lit("\""),$"actual_depart_tm",lit("\""))))
      .withColumn("actual_arrive_tm_tmp",concat_ws("",lit("\"actual_arrive_tm\":"),concat(lit("\""),$"actual_arrive_tm",lit("\""))))
      .withColumn("vehicle_serial_tmp",concat_ws("",lit("\"vehicle_serial\":"),concat(lit("\""),$"vehicle_serial",lit("\""))))
      .withColumn("is_delete_tmp",concat_ws("",lit("\"is_delete\":"),concat(lit("\""),$"is_delete",lit("\""))))
      .withColumn("len_tmp",concat_ws("",lit("\"len\":"),concat(lit("\""),$"order_len",lit("\""))))
      .withColumn("sttime2_tmp",concat_ws("",lit("\"sttime2\":"),concat(lit("\""),$"sttime2",lit("\""))))
      .withColumn("endtime2_tmp",concat_ws("",lit("\"endtime2\":"),concat(lit("\""),$"endtime2",lit("\""))))
      .withColumn("hebing",concat(lit("{"),concat_ws(",",$"task_id_tmp",$"driver_id_tmp",$"main_driver_account_tmp",$"actual_depart_tm_tmp",$"actual_arrive_tm_tmp",
        $"vehicle_serial_tmp", $"is_delete_tmp", $"len_tmp", $"sttime2_tmp", $"endtime2_tmp"),lit("}")))

    val Oildf_result_sl2= Oildf_result_sl
      .groupBy("emp_code_org")
      .agg(
        concat_ws(",",collect_list($"hebing")) as "order_list"
      )
      .withColumn("fczy_order_list",concat(lit("{\"json\":["),$"order_list",lit("]}")))
      .withColumnRenamed("emp_code_org","emp_code")
      .join(Oildf_result1_result_sl,Seq("emp_code"),"left")
      .withColumn("fczy_order_len",when($"fczy_order_len".isNull || trim($"fczy_order_len")==="",0.0).otherwise($"fczy_order_len"))
      .coalesce(20)

    Oildf_result_sl2.createOrReplaceTempView("Oildf_result_sl2_tb")
    spark.sql(
      """
        |insert overwrite table dm_gis.emp_oilstendtime_tmp_sl2
        |select emp_code,fczy_order_len as grd_task_len,order_list, fczy_order_list as grd_task_list from Oildf_result_sl2_tb
        |""".stripMargin)

  }

  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  //计算新的城配、支线的起始时间
  def newtime(x:String): String ={
    val x_list=x.split(";")
    val x_len=x_list.size
    val alltime_arry=new ArrayBuffer[String]()
    if(x_len>0){
      //初始化
      val list_i=x_list(0)
      var y_list_i_start=list_i.split(",")(0)
      var y_list_i_end=list_i.split(",")(1)
      var i=0
      //逐个遍历时间段
      while(i<=x_len-1){
        val x_list_i=x_list(i)
        val x_list_i_start=x_list_i.split(",")(0)
        val x_list_i_end=x_list_i.split(",")(1)
        //比较单个任务结束时间，取较大值
        if(x_list_i_start>=y_list_i_start && x_list_i_start<=y_list_i_end)
        {
          if(x_list_i_end>y_list_i_end)
          //重新赋值
          {y_list_i_end=x_list_i_end}
        }
        else{
          val newlistvalue=y_list_i_start.concat(",").concat(y_list_i_end)
          alltime_arry.append(newlistvalue)
          y_list_i_start=x_list_i_start
          y_list_i_end=x_list_i_end
        }
        i=i+1
      }
      //将最后一位判断结果存入
      alltime_arry.append(y_list_i_start.concat(",").concat(y_list_i_end))
    }
    alltime_arry.mkString("|")
  }

  val newtime_udf=udf(newtime _)

  //定义获取url数据
  def trackquery_url_stend(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    val url="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryDetail"
    //logger.error("当前obj："+obj)
    try {

      val emp_no = obj.getString("emp_no")
      val begintime =obj.getString("sttime2")
      val endtime =obj.getString("endtime2")
      val begin_time=begintime.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val end_time=endtime.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str=s"""{
                      |"addpoint": 1,
                      |"compensate": true,
                      |"type": "1",
                      |"un": "$emp_no",
                      |"ak": "93ec117f7f1b4226b4e537c4802319e9",
                      |"beginDateTime": $begin_time,
                      |"endDateTime": $end_time,
                      |"unType": "0"
                      |}
                      |""".stripMargin
      // logger.error("当前parm_str："+parm_str)

      val retStr: String = sendPost(url,parm_str,20)
      val ret: JSONObject = JSON.parseObject(retStr)
      //logger.error("当前ret："+ret)
      val status = ret.getString("status")
      if(status==0 || status=="0"){
        val order_len = ret.getJSONObject("result").getJSONObject("data").getDouble("len")
        val track = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        obj.put("order_len",order_len)
        obj.put("track",track)
      }
      obj.put("ret",ret)
      logger.error("返回正确数据，当前un："+emp_no)

      //调取油补开始时间的前后5分钟轨迹
      val begintime_x =obj.getString("sttime2_a")
      val endtime_x =obj.getString("sttime2_b")
      val begin_time_x=begintime_x.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val end_time_x=endtime_x.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str_x=s"""{
                        |"addpoint": 1,
                        |"compensate": true,
                        |"type": "1",
                        |"un": "$emp_no",
                        |"ak": "93ec117f7f1b4226b4e537c4802319e9",
                        |"beginDateTime": $begin_time_x,
                        |"endDateTime": $end_time_x,
                        |"unType": "0"
                        |}
                        |""".stripMargin
      // logger.error("当前parm_str："+parm_str)

      val retStr_x: String = sendPost(url,parm_str_x,20)
      val ret_x: JSONObject = JSON.parseObject(retStr_x)
      //logger.error("当前ret："+ret)
      val status_x = ret_x.getString("status")
      if(status_x==0 || status_x=="0"){
        val order_len_x = ret_x.getJSONObject("result").getJSONObject("data").getDouble("len")
        val track_x = ret_x.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        obj.put("order_len_x",order_len_x)
        obj.put("track_x",track_x)
      }
      logger.error("返回正确数据x，当前un："+emp_no)

      //调取油补结束时间的前后5分钟轨迹
      val begintime_y =obj.getString("endtime2_a")
      val endtime_y =obj.getString("endtime2_b")
      val begin_time_y=begintime_y.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val end_time_y=endtime_y.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str_y=s"""{
                        |"addpoint": 1,
                        |"compensate": true,
                        |"type": "1",
                        |"un": "$emp_no",
                        |"ak": "93ec117f7f1b4226b4e537c4802319e9",
                        |"beginDateTime": $begin_time_y,
                        |"endDateTime": $end_time_y,
                        |"unType": "0"
                        |}
                        |""".stripMargin
      // logger.error("当前parm_str："+parm_str)

      val retStr_y: String = sendPost(url,parm_str_y,20)
      val ret_y: JSONObject = JSON.parseObject(retStr_y)
      //logger.error("当前ret："+ret)
      val status_y = ret_y.getString("status")
      if(status_y==0 || status_y=="0"){
        val order_len_y = ret_y.getJSONObject("result").getJSONObject("data").getDouble("len")
        val track_y = ret_y.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        obj.put("order_len_y",order_len_y)
        obj.put("track_y",track_y)
      }
      logger.error("返回正确数据y，当前un："+emp_no)

    } catch {
      case e: Exception => logger.error(e)
        obj.put("errmsg",e.getMessage)
        val emp_no = obj.getString("emp_no")
        logger.error("返回错误数据，车牌号："+emp_no)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求，由于每个ak单分钟限制2500，而每次的函数调用有3次，因此这里要限制到700
  def Multi_trackquery_stend(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {

    //调用开始上报
    val httpUrl="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryDetail"
    val httpAk="93ec117f7f1b4226b4e537c4802319e9"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "772620", "快运小哥车油补信息表需求",
      "大件小哥会发放油补，但是小哥兼职城配、支线不应该重复发放油补，需要剔除",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, trackquery_url_stend, 6, "93ec117f7f1b4226b4e537c4802319e9", 700)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )

    returnAtRDD
  }

  // 推n分钟,负数是往前，正数是往后
  def getminisBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val dateFormat2: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.MINUTE, num)
    dateFormat2.format(cal.getTime)
  }

  val getminisBeforeOrAfter_udf=udf(getminisBeforeOrAfter _)

  //定义获取url数据
  def trackquery_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    val url="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryDetail"
    //logger.error("当前obj："+obj)
    try {

      val emp_no = obj.getString("emp_no")
      val begintime =obj.getString("sttime2")
      val endtime =obj.getString("endtime2")
      val begin_time=begintime.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val end_time=endtime.replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str=s"""{
                      |"addpoint": 1,
                      |"compensate": true,
                      |"type": "1",
                      |"un": "$emp_no",
                      |"ak": "93ec117f7f1b4226b4e537c4802319e9",
                      |"beginDateTime": $begin_time,
                      |"endDateTime": $end_time,
                      |"unType": "0"
                      |}
                      |""".stripMargin
      // logger.error("当前parm_str："+parm_str)

      val retStr: String = sendPost(url,parm_str,20)
      val ret: JSONObject = JSON.parseObject(retStr)
      //logger.error("当前ret："+ret)
      val status = ret.getString("status")
      if(status==0 || status=="0"){
        val order_len = ret.getJSONObject("result").getJSONObject("data").getDouble("len")
        val track = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        obj.put("order_len",order_len)
        obj.put("track",track)
      }
      obj.put("ret",ret)
      logger.error("返回正确数据，当前un："+emp_no)
    } catch {
      case e: Exception => logger.error(e)
        obj.put("errmsg",e.getMessage)
        val emp_no = obj.getString("emp_no")
        logger.error("返回错误数据，车牌号："+emp_no)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //并发调取接口并发请求
  def Multi_trackquery(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryDetail"
    val httpAk="93ec117f7f1b4226b4e537c4802319e9"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "772620", "快运小哥车油补信息表需求",
      "大件小哥会发放油补，但是小哥兼职城配、支线不应该重复发放油补，需要剔除",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, trackquery_url, 6, "93ec117f7f1b4226b4e537c4802319e9", 1500)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)

    logger.error("服务调用完成：" + httpInvokeId )
    returnAtRDD
  }

  //计算地图距离
  def rad(d: Double): Double = d * Math.PI / 180.0

  def getDistance(lng1x:String,lng1y:String,lng2x:String,lng2y:String): Double = {
    val lng1=lng1x.toDouble
    val lat1=lng1y.toDouble
    val lng2=lng2x.toDouble
    val lat2=lng2y.toDouble

    val EARTH_RADIUS: Double = 6378.137
    val radLat1: Double = rad(lat1)
    val radLat2: Double = rad(lat2)
    val a: Double = radLat1 - radLat2
    val b: Double = rad(lng1) - rad(lng2)
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)))
    s = s * EARTH_RADIUS
    s = s * 10000d.round / 10000d
    s = s * 1000
    s
  }

  val getDistance_udf=udf(getDistance _)

  //判断是否包含aoi
  def isin_aoi(x:String,y:String): String ={
    val y_arr=y.split(",")
    if(y_arr.contains(x)){
      "是"
    }
    else{"否"}
  }

  val isin_aoi_udf=udf(isin_aoi _)

}
