package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.realtime.pojo.FvpKafkaData;
import com.sf.gis.java.realtime.utils.DateUtil;
import org.apache.flink.api.common.functions.RichMapFunction;

import java.text.ParseException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FvpMapFunction extends RichMapFunction<String,String> {

    private String mapData(String t) throws ParseException {
        FvpKafkaData ret = JSON.parseObject(t, FvpKafkaData.class);

        if (!"0".equals(ret.getIsUnderCall())) {
            return null;
        }else{
            String curTime = DateUtil.longToTime(new Date().getTime(),"yyyyMMdd HH:mm:ss");
            String inc_day = curTime.substring(0, 8);
            ret.setIsUnderCall("1");
            ret.setInsert_hive_time(curTime);
            Pattern p = Pattern.compile("\\d+");
            Matcher m = p.matcher(ret.getSenderCityCode());
            if(m.find()){
                ret.setSenderCityCode(m.group());
            }
            ret.removeT();
        }
        return JSON.toJSONString(ret);
    }

    @Override
    public String map(String o) throws Exception {

        if(o==null){
            return null;
        }
        String ret = null;
        try{
            ret = mapData(o.toString());
        }catch (Exception e){

        }
        return ret;
    }
}
