package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.pojo.SegIndexMonitor;
import com.sf.gis.java.realtime.utils.CommonUtil;
import com.starrocks.connector.flink.StarRocksSink;
import com.starrocks.connector.flink.row.sink.StarRocksSinkRowBuilder;
import com.starrocks.connector.flink.table.sink.StarRocksSinkOptions;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessAllWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

/**
 * 任务id:30002554（SEG业务指标实时监控_数据侧）
 * 业务：01380164（程昆）
 * 研发：01399581（匡仁衡）
 */
public class GisRssSegKakfa2Sr {
    public static Logger logger = LoggerFactory.getLogger(GisRssSegKakfa2Sr.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("beelogsgisrsssegkafka2sr.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.parseInt(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.parseInt(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (CommonUtil.isConfAvailable(confInfo)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();
            //生成水位线默认间隔是200ms
            //env.getConfig().setAutoWatermarkInterval(100);


            logger.error("--------------启动source-------------------------");
            // source
            DataStream<SegIndexMonitor> dataStream = initKafakaSource(env, confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink
            dataStream.addSink(getSrSink()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(GisRssSegKakfa2Sr.class.getName());
        }
    }

    //生成sr sink
    private static SinkFunction<SegIndexMonitor> getSrSink() {
        String jdbc_url = "jdbc:mysql://10.216.162.10:9030";
        String db_name = "gis_oms_uimp_rds";
        String user = "gis_oms_rds";
        String password = "gis_oms_rds@123@";
        String table = "gis_seg_rec_cnt_real_time_monitor";
        String load_url = "http://10.119.82.211:8030";
        StarRocksSinkOptions options = StarRocksSinkOptions.builder()
                .withProperty("jdbc-url", jdbc_url)
                .withProperty("load-url", load_url)
                .withProperty("database-name", db_name)
                .withProperty("table-name", table)
                .withProperty("username", user)
                .withProperty("password", password)
                .withProperty("sink.buffer-flush.max-rows", "500000")
                .withProperty("sink.buffer-flush.max-bytes", "67108864")
                .withProperty("sink.buffer-flush.interval-ms", "2000")
                .withProperty("sink.max-retries", "3")
                .build();


        TableSchema schema = TableSchema.builder()
                .field("inc_day", DataTypes.STRING())
                .field("resp_cnt", DataTypes.INT())
                .field("province_rec_cnt", DataTypes.INT())
                .field("city_rec_cnt", DataTypes.INT())
                .field("county_rec_cnt", DataTypes.INT())
                .field("town_rec_cnt", DataTypes.INT())
                .field("city_rec_rev_cnt", DataTypes.INT())
                .field("citycode_rec_cnt", DataTypes.INT())
                .field("date_time", DataTypes.STRING())
                .build();

        //Transform the RowData to the Object[] according to the schema.
        GisRssSegKakfa2Sr.SegIndexMonitorTransformer transformer = new GisRssSegKakfa2Sr.SegIndexMonitorTransformer();
        //Create the sink with the schema, options, and transformer.
        return StarRocksSink.sink(schema, options, transformer);
    }

    public static class SegIndexMonitorTransformer implements StarRocksSinkRowBuilder<SegIndexMonitor> {

        /**
         * Set each element of the object array according to the input RowData.
         * The schema of the array matches that of the StarRocks table.
         */
        @Override
        public void accept(Object[] internalRow, SegIndexMonitor segIndexMonitor) {
            internalRow[0] = segIndexMonitor.getInc_day();
            internalRow[1] = segIndexMonitor.getResp_cnt();
            internalRow[2] = segIndexMonitor.getProvince_rec_cnt();
            internalRow[3] = segIndexMonitor.getCity_rec_cnt();
            internalRow[4] = segIndexMonitor.getCounty_rec_cnt();
            internalRow[5] = segIndexMonitor.getTown_rec_cnt();
            internalRow[6] = segIndexMonitor.getCity_rec_rev_cnt();
            internalRow[7] = segIndexMonitor.getCitycode_rec_cnt();
            internalRow[8] = segIndexMonitor.getDate_time();
            // When the StarRocks table is a Primary Key table, you need to set the last element to indicate whether the data loading is an UPSERT or DELETE operation.
//            internalRow[internalRow.length - 1] = StarRocksSinkOP.UPSERT.ordinal();
        }
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<SegIndexMonitor> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromLatest();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(GisRssSegKakfa2Sr::filter).setParallelism(srcParallelism).map(new MapFunction<String, JSONObject>() {
                    @Override
                    public JSONObject map(String value) throws Exception {
                        return JSON.parseObject(value);
                    }
                }).setParallelism(srcParallelism)
                //设置水位线生成策略
                .assignTimestampsAndWatermarks(WatermarkStrategy.<JSONObject>forBoundedOutOfOrderness(Duration.ofSeconds(10))
                        .withTimestampAssigner(new SerializableTimestampAssigner<JSONObject>() {
                            @Override
                            public long extractTimestamp(JSONObject element, long recordTimestamp) {
                                String dateTime = element.getJSONObject("message").getString("dateTime");
                                String tm = DateUtil.dateToStamp(dateTime);
                                return Long.parseLong(tm);
                            }
                        }))
                .windowAll(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                .allowedLateness(Time.minutes(5))
                .aggregate(new AggCntFunction(), new ResultProcessFunction()).setParallelism(1);

    }

    public static class ResultProcessFunction extends ProcessAllWindowFunction<SegIndexMonitor, SegIndexMonitor, TimeWindow> {
        @Override
        public void process(Context context, Iterable<SegIndexMonitor> elements, Collector<SegIndexMonitor> out) throws Exception {
            SegIndexMonitor next = elements.iterator().next();
            TimeWindow window = context.window();
            long start = window.getStart();
            long end = window.getEnd();
            String min = DateUtil.tmToDate(start + "", "yyyyMMddHHmm");
            next.setDate_time(min);
            next.setInc_day(min.substring(0, 8));
            out.collect(next);
        }
    }

    public static class AggCntFunction implements AggregateFunction<JSONObject, SegIndexMonitor, SegIndexMonitor> {

        @Override
        public SegIndexMonitor createAccumulator() {
            return SegIndexMonitor.init();
        }

        @Override
        public SegIndexMonitor add(JSONObject jsonObject, SegIndexMonitor accumulator) {
            accumulator.setResp_cnt(accumulator.getResp_cnt() + 1);
            String province = "";
            String city = "";
            String county = "";
            String town = "";
            String adcode = "";
            String citycode = "";
            try {
                province = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("province");
                city = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("city");
                county = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("county");
                town = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("town");
                adcode = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("adcode");
                citycode = jsonObject.getJSONObject("message").getJSONObject("data").getJSONObject("result").getJSONObject("data").getString("citycode");
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (StringUtils.isNotEmpty(province) && !"-".equals(province)) {
                accumulator.setProvince_rec_cnt(accumulator.getProvince_rec_cnt() + 1);
            }

            if (StringUtils.isNotEmpty(city) && !"-".equals(city)) {
                accumulator.setCity_rec_cnt(accumulator.getCity_rec_cnt() + 1);
            }

            if (StringUtils.isNotEmpty(county) && !"-".equals(county)) {
                accumulator.setCounty_rec_cnt(accumulator.getCounty_rec_cnt() + 1);
            }

            if (StringUtils.isNotEmpty(town) && !"-".equals(town)) {
                accumulator.setTown_rec_cnt(accumulator.getTown_rec_cnt() + 1);
            }

            if ((StringUtils.isNotEmpty(city) && !"-".equals(city)) || (StringUtils.isNotEmpty(adcode) && adcode.length() >= 2 && (Arrays.asList("81,82,71,11,12,31,50".split(",")).contains(adcode.substring(0, 2))))) {
                accumulator.setCity_rec_rev_cnt(accumulator.getCity_rec_rev_cnt() + 1);
            }

            if (StringUtils.isNotEmpty(citycode) && !"-".equals(citycode)) {
                accumulator.setCitycode_rec_cnt(accumulator.getCitycode_rec_cnt() + 1);
            }

            return accumulator;
        }

        @Override
        public SegIndexMonitor getResult(SegIndexMonitor accumulator) {
            return accumulator;
        }

        @Override
        public SegIndexMonitor merge(SegIndexMonitor a, SegIndexMonitor b) {
            return null;
        }
    }

    //只统计type为url_e的日志
    public static boolean filter(String line) {
        String type = "";
        try {
            type = JSON.parseObject(line).getJSONObject("message").getString("type");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "url_e".equals(type);
    }
}
