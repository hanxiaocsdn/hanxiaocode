package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.pojo.ChkPaiIndexMonitor;
import com.sf.gis.java.realtime.utils.CommonUtil;
import com.starrocks.connector.flink.StarRocksSink;
import com.starrocks.connector.flink.row.sink.StarRocksSinkOP;
import com.starrocks.connector.flink.row.sink.StarRocksSinkRowBuilder;
import com.starrocks.connector.flink.table.sink.StarRocksSinkOptions;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.connector.jdbc.JdbcStatementBuilder;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.*;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.util.Collector;
import org.apache.hadoop.hbase.protobuf.generated.HBaseProtos;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;


/**
 * 任务id:30002131(RDS业务指标实时监控-数据侧)
 * 研发：01399581（匡仁衡）
 * 业务：01380164（程昆）
 */
public class ChkPaiKakfa2Sr {
    public static Logger logger = LoggerFactory.getLogger(ChkPaiKakfa2Sr.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("chkpaikafka2Sr.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.parseInt(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.parseInt(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (CommonUtil.isConfAvailable(confInfo)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();
            //生成水位线默认间隔是200ms
            //env.getConfig().setAutoWatermarkInterval(100);


            logger.error("--------------启动source-------------------------");
            // source
            DataStream<ChkPaiIndexMonitor> dataStream = initKafakaSource(env, confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink
//            dataStream.addSink(new ChkPai2SrSinkFunction()).setParallelism(sinkParallelism);
            dataStream.addSink(getSrSink()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(ChkPaiKakfa2Sr.class.getName());
        }
    }

    //生成sr sink
    private static SinkFunction<ChkPaiIndexMonitor> getSrSink() {
        String jdbc_url = "jdbc:mysql://10.216.162.10:9030";
        String db_name = "gis_oms_uimp_rds";
        String user = "gis_oms_rds";
        String password = "gis_oms_rds@123@";
        String table = "gis_add_rds_zone_resp_cnt_real_time_monitor";
        String load_url = "http://10.119.82.211:8030";
        StarRocksSinkOptions options = StarRocksSinkOptions.builder()
                .withProperty("jdbc-url", jdbc_url)
                .withProperty("load-url", load_url)
                .withProperty("database-name", db_name)
                .withProperty("table-name", table)
                .withProperty("username", user)
                .withProperty("password", password)
                .withProperty("sink.buffer-flush.max-rows", "500000")
                .withProperty("sink.buffer-flush.max-bytes", "67108864")
                .withProperty("sink.buffer-flush.interval-ms", "2000")
                .withProperty("sink.max-retries", "3")
                .build();


        TableSchema schema = TableSchema.builder()
                .field("inc_day", DataTypes.STRING())
                .field("dept_code", DataTypes.STRING())
                .field("city_code", DataTypes.STRING())
                .field("resp_cnt", DataTypes.INT())
                .field("log_create_time", DataTypes.STRING())
                .build();

        //Transform the RowData to the Object[] according to the schema.
        ChkPaiIndexMonitorTransformer transformer = new ChkPaiIndexMonitorTransformer();
        //Create the sink with the schema, options, and transformer.
        return StarRocksSink.sink(schema, options, transformer);
    }

    public static class ChkPaiIndexMonitorTransformer implements StarRocksSinkRowBuilder<ChkPaiIndexMonitor> {

        /**
         * Set each element of the object array according to the input RowData.
         * The schema of the array matches that of the StarRocks table.
         */
        @Override
        public void accept(Object[] internalRow, ChkPaiIndexMonitor chkPaiIndexMonitor) {
            internalRow[0] = chkPaiIndexMonitor.getInc_day();
            internalRow[1] = chkPaiIndexMonitor.getDeptcode();
            internalRow[2] = chkPaiIndexMonitor.getCitycode();
            internalRow[3] = chkPaiIndexMonitor.getCnt();
            internalRow[4] = chkPaiIndexMonitor.getLog_create_time();
            // When the StarRocks table is a Primary Key table, you need to set the last element to indicate whether the data loading is an UPSERT or DELETE operation.
//            internalRow[internalRow.length - 1] = StarRocksSinkOP.UPSERT.ordinal();
        }
    }


    private static SinkFunction<ChkPaiIndexMonitor> getSink() {
        String insetIntoSql = "insert into gis_add_rds_zone_resp_cnt_real_time_monitor (inc_day,dept_code,city_code,resp_cnt,log_create_time) values (?,?,?,?,?)";
        JdbcStatementBuilder<ChkPaiIndexMonitor> builder = new JdbcStatementBuilder<ChkPaiIndexMonitor>() {
            @Override
            public void accept(PreparedStatement preparedStatement, ChkPaiIndexMonitor o) throws SQLException {
                preparedStatement.setString(1, o.getInc_day());
                preparedStatement.setString(2, o.getDeptcode());
                preparedStatement.setString(3, o.getCitycode());
                preparedStatement.setInt(4, o.getCnt());
                preparedStatement.setString(5, o.getLog_create_time());
            }
        };

        return JdbcSink.sink(
                insetIntoSql,
                builder,
                new JdbcExecutionOptions.Builder()
                        //设置每个批次写入的最大行数，默认值为5000
                        .withBatchSize(1000)
                        //设置批量写入的间隔时间，单位为毫秒，默认值为"无"
                        .withBatchIntervalMs(2000)
                        //设置写入失败后的最大重试次数，默认值为3
                        .withMaxRetries(3)
                        .build(),

                new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                        .withDriverName("com.mysql.jdbc.Driver")
                        .withUrl("jdbc:mysql://10.216.162.10:9030/gis_oms_uimp_rds")
                        .withUsername("gis_oms_rds")
                        .withPassword("gis_oms_rds@123@")
                        .build()
        );
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<ChkPaiIndexMonitor> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromLatest();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(ChkPaiKakfa2Sr::filter).setParallelism(srcParallelism).flatMap(new FlatMapFunction<String, JSONObject>() {
                    @Override
                    public void flatMap(String line, Collector<JSONObject> collector) throws Exception {
                        ArrayList<JSONObject> list = parseOmsToRe(line);
                        for (JSONObject jsonObject : list) {
                            collector.collect(jsonObject);
                        }
                    }
                }).setParallelism(srcParallelism)
                //设置水位线生成策略
                .assignTimestampsAndWatermarks(WatermarkStrategy.<JSONObject>forBoundedOutOfOrderness(Duration.ofSeconds(10))
                        .withTimestampAssigner(new SerializableTimestampAssigner<JSONObject>() {
                            @Override
                            public long extractTimestamp(JSONObject element, long recordTimestamp) {
                                String log_type = element.getString("log_type");
                                return element.getJSONObject(log_type).getLong("tm");
                            }
                        }))
                .keyBy(new KeySelector<JSONObject, String>() {
                    @Override
                    public String getKey(JSONObject jsonObject) throws Exception {
                        String log_type = jsonObject.getString("log_type");
                        return jsonObject.getJSONObject(log_type).getString("addresseeDeptCode");
                    }
                }).window(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                .allowedLateness(Time.minutes(5))
                .aggregate(new AggCntFunction(), new ResultProcessFunction()).setParallelism(srcParallelism);

    }

    public static class MyWaterStrategy implements WatermarkStrategy<JSONObject> {
        @Override
        public WatermarkGenerator<JSONObject> createWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
            return new WatermarkGenerator<JSONObject>() {
                private Long delayTime = 10000L;
                private Long maxTimestamp = Long.MIN_VALUE + delayTime + 1;

                @Override
                public void onEvent(JSONObject event, long eventTimestamp, WatermarkOutput output) {
                    //每条数据调用一次
                    maxTimestamp = Math.max(maxTimestamp, eventTimestamp);
                }

                @Override
                public void onPeriodicEmit(WatermarkOutput output) {
                    //周期生成水位线，默认200ms调用一次
                    output.emitWatermark(new Watermark(maxTimestamp - delayTime - 1L));
                }
            };
        }

        @Override
        public TimestampAssigner<JSONObject> createTimestampAssigner(TimestampAssignerSupplier.Context context) {
            return new SerializableTimestampAssigner<JSONObject>() {
                @Override
                public long extractTimestamp(JSONObject element, long recordTimestamp) {
                    String log_type = element.getString("log_type");
                    return element.getJSONObject(log_type).getLong("tm");
                }
            };
        }
    }

    public static class ResultProcessFunction extends ProcessWindowFunction<ChkPaiIndexMonitor, ChkPaiIndexMonitor, String, TimeWindow> {

        @Override
        public void process(String key, Context context, Iterable<ChkPaiIndexMonitor> elements, Collector<ChkPaiIndexMonitor> out) throws Exception {
            ChkPaiIndexMonitor next = elements.iterator().next();
            TimeWindow window = context.window();
            long start = window.getStart();
            long end = window.getEnd();
            String min = DateUtil.tmToDate(start + "", "yyyyMMddHHmm");
            next.setLog_create_time(min);
            next.setInc_day(min.substring(0, 8));
            out.collect(next);
        }
    }

    public static class AggCntFunction implements AggregateFunction<JSONObject, ChkPaiIndexMonitor, ChkPaiIndexMonitor> {

        @Override
        public ChkPaiIndexMonitor createAccumulator() {
            return ChkPaiIndexMonitor.init();
        }

        @Override
        public ChkPaiIndexMonitor add(JSONObject jsonObject, ChkPaiIndexMonitor accumulator) {
            String log_type = jsonObject.getString("log_type");
            String addresseeCityCode = jsonObject.getJSONObject(log_type).getString("addresseeCityCode");
            String addresseeDeptCode = jsonObject.getJSONObject(log_type).getString("addresseeDeptCode");
            accumulator.setCitycode(addresseeCityCode);
            accumulator.setDeptcode(addresseeDeptCode);
            accumulator.setCnt(accumulator.getCnt() + 1);
            return accumulator;
        }

        @Override
        public ChkPaiIndexMonitor getResult(ChkPaiIndexMonitor accumulator) {
            return accumulator;
        }

        @Override
        public ChkPaiIndexMonitor merge(ChkPaiIndexMonitor a, ChkPaiIndexMonitor b) {
            return null;
        }
    }

    public static ArrayList<JSONObject> parseOmsToRe(String line) {
        JSONObject jsonObject = parseMessageObject(line);
//        String waybillNo = jsonObject.getString("waybillNo");
//        String requestId = jsonObject.getString("requestId");
//        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");
        String tm = DateUtil.dateToStamp(createTime);
        String addresseeDeptCode = body.getString("addresseeDeptCode");
        String addresseeCityCode = body.getString("addresseeCityCode");
        if (StringUtils.isEmpty(addresseeDeptCode)) {
            if (StringUtils.isNotEmpty(addresseeCityCode)) {
                body.put("addresseeDeptCode", addresseeCityCode);
            } else {
                body.put("addresseeDeptCode", "empty");
            }
        }
        List<String> saveKey = Arrays.asList("addresseeCityCode", "addresseeDeptCode");
        Object[] objects = body.keySet().toArray();
        for (Object object : objects) {
            String key = (String) object;
            if (!saveKey.contains(key)) {
                body.remove(key);
            }
        }


        JSONObject re = new JSONObject();
//        re.put("waybillNo", waybillNo);
//        re.put("requestId", requestId);
//        re.put("nodeId", ip);
//        re.put("type", "omsto");

        body.put("tm", Long.parseLong(tm));
        body.put("datetime", createTime);
//        body.put("re_time", createTime);
//        body.put("async_time", createTime);
//        body.put("async_waybillNo", waybillNo);

        String log_type = "re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<JSONObject> list = new ArrayList<>();
        list.add(re);
        return list;
    }

    public static JSONObject parseMessageObject(String line) {
        JSONObject o = new JSONObject();
        JSONObject jObj = JSON.parseObject(line.trim());
        String createTime = jObj.getString("createTime");
        if (createTime != null) {
            createTime = createTime.replace(".", " ");
        }
        String ip = jObj.getString("ip");
        JSONObject message = JSON.parseObject(jObj.getString("message").trim());
        String requestId = message.getString("requestId");
        if (requestId != null) {
            requestId = requestId.trim();
        }
        String waybillNo = message.getString("waybillNo");
        if (waybillNo != null) {
            waybillNo = waybillNo.trim();
        }
        String chkDisLogType = message.getString("chkDisLogType").trim();
        JSONObject chkDisLogObj = null;
        JSONArray chkDisLogArray = null;
        String chkDisLogMsg = null;
        if (message.containsKey("chkDisLogArray")) {
            JSONArray tmpArray = message.getJSONArray("chkDisLogArray");
            if (tmpArray != null && tmpArray.size() != 0) {
                chkDisLogArray = new JSONArray();
                for (int i = 0; i < tmpArray.size(); i++) {
                    chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim()));
                }
            }
        } else if (message.containsKey("chkDisLogMsg")) {
            chkDisLogMsg = message.getString("chkDisLogMsg").trim();
        } else {
            chkDisLogObj = message;
        }
        o.put("waybillNo", waybillNo);
        o.put("requestId", requestId);
        o.put("createTime", createTime);
        o.put("ip", ip);
        o.put("chkDisLogType", chkDisLogType);
        o.put("chkDisLogMsg", chkDisLogMsg);
        o.put("chkDisLogObj", chkDisLogObj);
        o.put("chkDisLogArray", chkDisLogArray);
        return o;
    }

    public static boolean filter(String line) {
        if (StringUtils.isNotEmpty(line)) {
            return line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS");
        }
        return false;
    }
}
