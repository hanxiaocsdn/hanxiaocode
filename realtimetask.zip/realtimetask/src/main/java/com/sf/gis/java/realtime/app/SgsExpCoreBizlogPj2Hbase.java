package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.OperationWaybillHbaseSinkFunction;
import com.sf.gis.java.realtime.func.SgsExpCoreBizlogPjHbaseSinkFunction;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class SgsExpCoreBizlogPj2Hbase {
    public static Logger logger = LoggerFactory.getLogger(SgsExpCoreBizlogPj2Hbase.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("sgsexpcorebizlogpj.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        System.out.println("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (isConfAvailable()) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> dataStream = initKafakaSource(env);

            logger.error("--------------启动sink-------------------------");
            // sink
            dataStream.addSink(new SgsExpCoreBizlogPjHbaseSinkFunction()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(SgsExpCoreBizlogPj2Hbase.class.getName());
        }
    }

    public static boolean isConfAvailable() {
        boolean result = true;
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.bootstrap.servers"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.bootstrap.servers"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.topic"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.topic"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("hive.table.name"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("hive.table.name"));
        }
        return result;
    }

    public static Properties getProperties() {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", confInfo.getProperty("kafka.bootstrap.servers"));
        properties.setProperty("group.id", confInfo.getProperty("hive.table.name"));
        properties.setProperty("max.poll.interval.ms", String.valueOf(10 * 60 * 1000));
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("log => auto.offset.reset:" + offsetReset);
        if ("earliest".equals(offsetReset)) {
            properties.put("auto.offset.reset", "earliest");
        } else {
            properties.put("auto.offset.reset", "latest");
        }

        return properties;
    }


    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), getProperties());
        gisDataKafkaConsumer.setStartFromGroupOffsets();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism).filter(line -> {
            boolean flag = false;
            if (StringUtils.isNotEmpty(line)) {
                JSONObject jsonObject = JSON.parseObject(line);
                if (jsonObject != null) {
                    String eventType = jsonObject.getString("eventType");
                    if (StringUtils.isNotEmpty(eventType) && StringUtils.equals(eventType, "31124")) {
                        flag = true;
                    }
                }
            }
            return flag;
        }).setParallelism(srcParallelism).map(line -> {
            JSONObject o = new JSONObject();
            if (StringUtils.isNotEmpty(line)) {
                JSONObject jsonObject = JSON.parseObject(line);
                if (jsonObject != null) {
                    String waybillNo = jsonObject.getString("waybillNo");
                    String eventLng = jsonObject.getString("eventLng");
                    String eventLat = jsonObject.getString("eventLat");

                    o.put("waybill_no", waybillNo);
                    o.put("eventLng", eventLng);
                    o.put("eventLat", eventLat);
                }
            }
            return o.toJSONString();
        }).setParallelism(srcParallelism);
    }
}
