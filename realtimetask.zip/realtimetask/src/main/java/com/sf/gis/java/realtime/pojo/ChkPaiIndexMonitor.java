package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

public class ChkPaiIndexMonitor implements Serializable {
    private String log_create_time;
    private String deptcode;
    private String citycode;
    private int cnt;
    private String inc_day;

    public ChkPaiIndexMonitor() {
    }

    public static ChkPaiIndexMonitor init() {
        ChkPaiIndexMonitor monitor = new ChkPaiIndexMonitor();
        monitor.setCnt(0);
        return monitor;
    }

    public String getLog_create_time() {
        return log_create_time;
    }

    public void setLog_create_time(String log_create_time) {
        this.log_create_time = log_create_time;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
