package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.VMSTrackDeserializationSchema;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-11-22  16:25
 * @TaskId:
 * @TaskName:
 * @Description:
 */
public class JiaLiChkPai2Hive {
    public static Logger logger = LoggerFactory.getLogger(JiaLiChkPai2Hive.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {

        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("jialichkpai2hive.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        System.out.println("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (isConfAvailable()) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> dataStream = initKafakaSource(env,confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink bdp
            String outputPath = "hdfs://kex/user/hive/warehouse/kex/DM/dm_gis/" + confInfo.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(dataStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(JiaLiChkPai2Hive.class.getName());
        }
    }

    public static boolean isConfAvailable() {
        boolean result = true;
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.bootstrap.servers"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.bootstrap.servers"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.topic"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.topic"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("hive.table.name"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("hive.table.name"));
        }
        return result;
    }

    public static Properties getProperties() {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", confInfo.getProperty("kafka.bootstrap.servers"));
        properties.setProperty("group.id", confInfo.getProperty("hive.table.name"));
        properties.setProperty("max.poll.interval.ms", String.valueOf(10 * 60 * 1000));
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("log => auto.offset.reset:" + offsetReset);
        if ("earliest".equals(offsetReset)) {
            properties.put("auto.offset.reset", "earliest");
        } else {
            properties.put("auto.offset.reset", "latest");
        }

        return properties;
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env,Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("offsetReset:"+offsetReset);
        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                .setTopics(topic)
                .setGroupId(confInfo.getProperty("kafka.consumer.group"))
                .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                        OffsetsInitializer.committedOffsets()))
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        Map<String, Boolean> isPrintMap = new HashMap<>();
        isPrintMap.put("isPrint", true);

        String[] keyList = StringUtils.isEmpty(confInfo.getProperty("kafka.data.keys")) ? new String[]{} : confInfo.getProperty("kafka.data.keys").split(",");
        return env.fromSource(source, WatermarkStrategy.noWatermarks(), topic).name(topic).uid(topic).setParallelism(srcParallelism).filter((FilterFunction<String>) line -> {
            if (keyList.length == 0) {
                if (isPrintMap.get("isPrint")) {
                    logger.error("log => " + line);
                    isPrintMap.put("isPrint", false);
                }
                return true;
            } else {
                for (String item : keyList) {
                    if (line != null && line.contains(item)) {
                        if (isPrintMap.get("isPrint")) {
                            logger.error("log => " + line);
                            isPrintMap.put("isPrint", false);
                        }
                        return true;
                    }
                }
                return false;
            }
        }).setParallelism(srcParallelism);
    }
}
