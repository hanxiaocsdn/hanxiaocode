package com.sf.gis.java.realtime.utils;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class CommonUtil {
    private static final Logger logger = LoggerFactory.getLogger(CommonUtil.class);

    public static boolean isConfAvailable(Properties confInfo) {
        boolean result = true;
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.bootstrap.servers"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.bootstrap.servers"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.topic"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.topic"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("hive.table.name"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("hive.table.name"));
        }
        return result;
    }

    public static Properties getProperties(Properties confInfo) {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", confInfo.getProperty("kafka.bootstrap.servers"));
        properties.setProperty("group.id", confInfo.getProperty("hive.table.name"));
        properties.setProperty("max.poll.interval.ms", String.valueOf(10 * 60 * 1000));
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("log => auto.offset.reset:" + offsetReset);
        if ("earliest".equals(offsetReset)) {
            properties.put("auto.offset.reset", "earliest");
        } else {
            properties.put("auto.offset.reset", "latest");
        }
        return properties;
    }

}
