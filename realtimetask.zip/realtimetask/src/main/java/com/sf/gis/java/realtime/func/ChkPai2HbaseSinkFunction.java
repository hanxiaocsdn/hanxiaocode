package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import com.sf.gis.java.realtime.utils.MD5Util;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.BufferedMutator;
import org.apache.hadoop.hbase.client.BufferedMutatorParams;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Put;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Arrays;

public class ChkPai2HbaseSinkFunction extends RichSinkFunction<String> {
    public static Logger logger = LoggerFactory.getLogger(ChkPai2HbaseSinkFunction.class);
    private static final long serialVersionUID = 1L;

    private String zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw";
    private String zkPort = "2181";
    private String zkParent = "/hbase";
    private String tableName = "gis:chk_pai_kafka_to_hbase";
    private String cf = "info";
    private int batchSize = 100;
    private static Connection connection = null;
    private static BufferedMutator mutator;
    private static int count = 0;

    //    private static Table table;
    private static int cnt = 0;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);
        conf.set("hbase.client.retries.number", "11");
        connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);

        BufferedMutatorParams params = new BufferedMutatorParams(TableName.valueOf(tableName));
        params.writeBufferSize(2 * 1024 * 1024);
        mutator = connection.getBufferedMutator(params);
//        table = HbaseUtil.getTable(connection, tableName);
    }

    @Override
    public void invoke(String value) throws Exception {
        if (StringUtils.isNotEmpty(value)) {
            try {
                JSONObject jsonObject = JSON.parseObject(value);
                if (jsonObject != null) {
                    putList(jsonObject);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void putList(JSONObject o) throws IOException {
        try {
            String waybill_no = o.getString("waybillNo");
            if (StringUtils.isNotEmpty(waybill_no)) {
                String requestId = StringUtils.isNotEmpty(o.getString("requestId")) ? o.getString("requestId") : "";
                String fix = MD5Util.getMD5(requestId).substring(0, 6);
                String rowKey = HBaseUtil.getKeyStr(waybill_no, 30) + "_" + fix;
                Put put = new Put(rowKey.getBytes());
                String log_type = o.getString("log_type");
                String value = o.getJSONObject(log_type).toJSONString();
                put.addColumn(cf.getBytes(), log_type.getBytes(), value.getBytes());
                mutator.mutate(put);
                if (count >= batchSize) {
                    mutator.flush();
                    count = 0;
                }
                count = count + 1;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws IOException {
        if (mutator != null) {
            mutator.close();
        }
        if (connection != null) {
            connection.close();
        }
    }
}
