package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.OperationWaybillHbaseSinkFunction;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class OperationWaybill2Hbase {
    public static Logger logger = LoggerFactory.getLogger(OperationWaybill2Hbase.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("operationwaybill.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        System.out.println("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (isConfAvailable()) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> dataStream = initKafakaSource(env);

            logger.error("--------------启动sink-------------------------");
            // sink
            dataStream.addSink(new OperationWaybillHbaseSinkFunction()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(OperationWaybill2Hbase.class.getName());
        }
    }

    public static boolean isConfAvailable() {
        boolean result = true;
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.bootstrap.servers"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.bootstrap.servers"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("kafka.topic"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("kafka.topic"));
        }
        if (StringUtils.isEmpty(confInfo.getProperty("hive.table.name"))) {
            result = false;
            logger.error("parameter {} is null.", confInfo.getProperty("hive.table.name"));
        }
        return result;
    }

    public static Properties getProperties() {
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", confInfo.getProperty("kafka.bootstrap.servers"));
        properties.setProperty("group.id", confInfo.getProperty("hive.table.name"));
        properties.setProperty("max.poll.interval.ms", String.valueOf(10 * 60 * 1000));
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("log => auto.offset.reset:" + offsetReset);
        if ("earliest".equals(offsetReset)) {
            properties.put("auto.offset.reset", "earliest");
        } else {
            properties.put("auto.offset.reset", "latest");
        }

        return properties;
    }


    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), getProperties());
        gisDataKafkaConsumer.setStartFromGroupOffsets();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism).map(line -> {
            JSONObject o = new JSONObject();
            try {
                if (StringUtils.isNotEmpty(line)) {
                    JSONObject jsonObject = JSON.parseObject(line);
                    if (jsonObject != null) {
                        String waybillNo = jsonObject.getString("waybillNo");
                        String orderNo = jsonObject.getString("orderNo");
                        String consigneeEmpCode = jsonObject.getString("consigneeEmpCode");
                        o.put("waybill_no", waybillNo);
                        o.put("order_no", orderNo);
                        o.put("consignee_emp_code", consigneeEmpCode);
                        JSONObject operationWaybillAddrCons = jsonObject.getJSONObject("operationWaybillAddrCons");
                        if (operationWaybillAddrCons != null) {
                            String sender_comp_name = operationWaybillAddrCons.getString("consignorCompName");
                            String sender_addr = operationWaybillAddrCons.getString("senderAddr");
                            String sender_province = operationWaybillAddrCons.getString("senderProvince");
                            String sender_city = operationWaybillAddrCons.getString("senderCity");
                            String sender_city_code = operationWaybillAddrCons.getString("consignorCityCode");
                            String sender_area = operationWaybillAddrCons.getString("senderArea");
                            String sender_phone = operationWaybillAddrCons.getString("consignorPhone");
                            String sender_mobile = operationWaybillAddrCons.getString("consignorMobile");

                            o.put("sender_comp_name", sender_comp_name);
                            o.put("sender_addr", sender_addr);
                            o.put("sender_province", sender_province);
                            o.put("sender_city", sender_city);
                            o.put("sender_city_code", sender_city_code);
                            o.put("sender_area", sender_area);
                            o.put("sender_phone", sender_phone);
                            o.put("sender_mobile", sender_mobile);

                            String receiver_comp_name = operationWaybillAddrCons.getString("addresseeCompName");
                            String receiver_addr = operationWaybillAddrCons.getString("receiverAddr");
                            String receiver_province = operationWaybillAddrCons.getString("receiverProvince");
                            String receiver_city = operationWaybillAddrCons.getString("receiverCity");
                            String receiver_city_code = operationWaybillAddrCons.getString("addresseeCityCode");
                            String receiver_area = operationWaybillAddrCons.getString("receiverArea");
                            String receiver_phone = operationWaybillAddrCons.getString("addresseePhone");
                            String receiver_mobile = operationWaybillAddrCons.getString("addresseeMobile");
                            String addressee_addr = operationWaybillAddrCons.getString("addresseeAddr");

                            o.put("receiver_comp_name", receiver_comp_name);
                            o.put("receiver_addr", receiver_addr);
                            o.put("receiver_province", receiver_province);
                            o.put("receiver_city", receiver_city);
                            o.put("receiver_city_code", receiver_city_code);
                            o.put("receiver_area", receiver_area);
                            o.put("receiver_phone", receiver_phone);
                            o.put("receiver_mobile", receiver_mobile);
                            o.put("addressee_addr", addressee_addr);
                        }

                        JSONArray operationWaybillFeeList = jsonObject.getJSONArray("operationWaybillFeeList");
                        if (operationWaybillFeeList != null && operationWaybillFeeList.size() > 0) {
                            for (int i = 0; i < operationWaybillFeeList.size(); i++) {
                                JSONObject tempJs = operationWaybillFeeList.getJSONObject(i);
                                String settlementTypeCode = tempJs.getString("settlementTypeCode");
                                if (StringUtils.equals(settlementTypeCode, "2")) {
                                    String customerAcctCode = tempJs.getString("customerAcctCode");
                                    o.put("customer_acct_code", customerAcctCode);
                                    break;
                                }
                            }

                        }

                        JSONArray operationWaybillAdditionList = jsonObject.getJSONArray("operationWaybillAdditionList");
                        if (operationWaybillAdditionList != null && operationWaybillAdditionList.size() > 0) {
                            for (int i = 0; i < operationWaybillAdditionList.size(); i++) {
                                JSONObject tempJs = operationWaybillAdditionList.getJSONObject(i);
                                String additionalKey = tempJs.getString("additionalKey");
                                if (StringUtils.equals(additionalKey, "SOURCE_WAYBILL_NO")) {
                                    String source_waybill_no = tempJs.getString("additionalValues");
                                    o.put("source_waybill_no", source_waybill_no);
                                    break;
                                }
                            }
                        }
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return o.toJSONString();
        }).setParallelism(srcParallelism);
    }


}
