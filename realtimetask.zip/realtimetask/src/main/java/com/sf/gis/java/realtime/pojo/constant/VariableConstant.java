package com.sf.gis.java.realtime.pojo.constant;

@SuppressWarnings("unused")
public class VariableConstant {
    public static String CONF = "conf/oms_shou/config.properties";
    public static String MYSQL_RDS_CONF = "conf/oms_shou/mysql-rds-config.properties";
    public static String MYSQL_AOS_CONF = "conf/oms_shou/mysql-aos-config.properties";
    public static String MYSQL_PR_CONF = "conf/oms_shou/mysql-pr-config.properties";
    public static String DEFAULT_VALUE_STRING = "-";
    public static String TYPE_KEY = "type";
    public static String ERROR_KEY = "error";
    public static String DEFAULE_KEY = "default";
    public static String SYNC_REQ_BODY_KEY = "syncReqBody";
    public static String SYNC_RE_BODY_KEY = "syncReBody";
    public static String ASYNC_REQ_BODY_KEY = "asyncReqBody";
    public static String ASYNC_RE_BODY_KEY = "asyncReBody";
    public static String RDS_ARSS_REQ_BODY_KEY = "rdsArssReqBody";
    public static String ARSS_REQ_BODY_KEY = "arssReqBody";
    public static String ARSS_RE_BODY_KEY = "arssReBody";
    public static String KS_REQ_BODY_KEY = "chkKsReqBody";
    public static String KS_RE_BODY_KEY = "chkKsReBody";
    public static String OMS_RE_BODY_KEY = "chkOmsReBody";
    public static String BUILDING_BODY_KEY = "buildIngBody";
    public static String ERR_CALL_BODY_KEY = "errCallBody";
    public static String SYNC_REQ_SYS_ORDERNO_KEY = "orderInfo.sysOrderNo";
    public static String SYNC_RE_SYS_ORDERNO_KEY = "orderInfo.sysOrderNo";
    public static String ASYNC_REQ_SYS_ORDERNO_KEY = "orderInfo.sysOrderNo";
    public static String ASYNC_RE_SYS_ORDERNO_KEY = "orderInfo.sysOrderNo";
    public static String RDS_ARSS_REQ_SYS_ORDERNO_KEY = "producerArssInfo.sysOrderNo";
//    public static String ARSS_REQ_SYS_ORDERNO_KEY = "producerArssInfo.sysOrderNo";
//    public static String ARSS_RE_SYS_ORDERNO_KEY  = "data.sysOrderNo";

    public static String ERR_CALL_SYS_ORDERNO_KEY = "orderid";
    public static String SYNC_RE_STATUS_KEY = SYNC_RE_BODY_KEY + ".status";
    public static String SYNC_RE_SRC_KEY = SYNC_RE_BODY_KEY + ".ret.src";
    public static String SYNC_RE_TC_KEY = SYNC_RE_BODY_KEY + ".ret.team.teamCode";
    public static String ASYNC_RE_STATUS_KEY = ASYNC_RE_BODY_KEY + ".status";
    public static String ASYNC_RE_SRC_KEY = ASYNC_RE_BODY_KEY + ".ret.src";
    public static String ASYNC_RE_TC_KEY = ASYNC_RE_BODY_KEY + ".ret.team.teamCode";
    public static String ERR_CALL_TC_KEY = ERR_CALL_BODY_KEY + ".teamid";
    public static String ARSS_RE_TC_KEY = ARSS_RE_BODY_KEY + ".data.orderFrom.teamCode";
    public static String SYS_ORDERNO_KEY = "sysOrderNo";
    public static String ORDERNO_KEY = "orderNo";

    //日志标识
    public static String LOG_MARKER = "rds_pu_log:";
    public static String CHK_TO_KS_REQ_MARKER = "kafka topic GIS_ASS_RDS_CHKCON_KS,message:";
    public static String KS_TO_CHK_RE_MARKER = "---->KS return data:";
    public static String CHK_TO_OMS_MARKER = "=>kafka topic GIS_ASS_CORE_NORMAL,message:";


    public static String ORDERINFO_LIST_KEY = "orderInfo.orderFromToList";
    public static String TCS_KEY = "ret.atSrvRet.tcs";
    public static String CHKRESULT_KEY = "resultData.result";
    //    public static String SYNC_REQ_PARAM_PATH = SYNC_REQ_BODY_KEY + ".orderInfo.orderFromToList.orderFrom";
//    public static String ASYNC_REQ_PARAM_PATH = ASYNC_REQ_BODY_KEY + ".orderInfo.orderFromToList.orderFrom";
//    public static String RDS_ARSS_REQ_PARAM_PATH = RDS_ARSS_REQ_BODY_KEY + ".producerArssInfo";
//    public static String ARSS_REQ_PARAM_PATH = ARSS_REQ_BODY_KEY + ".data";
//    public static String ARSS_RE_PARAM_PATH = ARSS_RE_BODY_KEY + ".data.orderFrom";
    public static String ERR_CALL_PARAM_PATH = ERR_CALL_BODY_KEY;
    public static String SUCCESS_STATUS = "1";
    public static String ERROR_STATUS = "0";
    public static String UNMATCH_STATUS = "2";
    public static String TIMEOUT_STATUS = "3";
    public static String NOTC_STATUS = "4";
    public static String NOSHOU_STATUS = "5";
    public static String SRC_CHKE_CUR = "chke_cur";
    public static String CITYCODE_KEY = "cityCode";
    public static String PROVINCE_KEY = "province";
    public static String CITY_KEY = "city";
    public static String ADDRESS_KEY = "address";
    public static String ERRCALL_CITYCODE_KEY = "resno";
    public static String ERRCALL_PROVINCE_KEY = "province";
    public static String ERRCALL_CITY_KEY = "city";
    public static String ERRCALL_ADDRESS_KEY = "addrabb";
    public static String ERRCALL_TIME_KEY = "createTime";
}
