package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.realtime.utils.DateUtil;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import com.sf.gis.java.realtime.utils.MD5Util;
import com.sf.gis.java.realtime.utils.SaltUtil;
import com.sf.gis.scala.base.util.HttpClientUtil;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/*
*德邦识别兜底方案数据侧需求
* id:30002010
* 01427169 邓蔼娟
* create 01412406
*/
public class DebangChangeAoi2Redis extends RichSinkFunction<String> {

	public static Logger logger = LoggerFactory.getLogger(DebangChangeAoi2Redis.class);

	//生产
	private String delRedisUrl="http://gis-int.int.sfdc.com.cn:1080/eds/hisData/del?ak=0376a9aa84724dd2a995f858dd963346&aoiId=%s";


	@Override
	public void open(Configuration parameters) throws Exception {
		super.open(parameters);
	}

	/**
	 * @param value 从kafka接收aoi 删除redis
	 * @throws Exception
	 */
	@Override
	public void invoke(String value) throws Exception {
		if(!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
			try {
				JSONObject js = JSON.parseObject(value);
				//调接口更新redis
				if(js != null && !js.isEmpty()){
					savaRedis(js);
				};


			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void savaRedis( JSONObject js ) {
		try {

			String operType = JSONUtil.getJsonVal(js,"operType","");
			String changeWkt = JSONUtil.getJsonVal(js,"changeWkt","");
			String aoiid = JSONUtil.getJsonVal(js,"aoiId","");

			if((operType.equals("U") || operType.equals("D")) && changeWkt.equals("1") && !aoiid.isEmpty()){
			JSONObject req = HttpClientUtil.getJsonByGet(String.format(delRedisUrl, aoiid));
			logger.error("operType===>"+operType+"changeWkt===>"+changeWkt+"aoiid===>"+aoiid+"返参===>"+aoiid+req.toString());
			}

		} catch(Exception e) {
			e.printStackTrace();
			logger.info("e="+e);
		}
	}
}
