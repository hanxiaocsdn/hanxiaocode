package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 从kafka读取日志信息落地到hive表(大网日志)
 * @author 01370539 Created On: Aug.02 2021
 */
public class DwLogToHive {
	public static Logger logger = LoggerFactory.getLogger(DwLogToHive.class);

	public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("dwkafka2hive.properties", DwLogToHive.class.getName());
	}
}
