package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.pojo.ChkPaiIndexMonitor;
import com.sf.gis.java.realtime.pojo.IpsIndexMonitor;
import com.sf.gis.java.realtime.utils.CommonUtil;
import com.sf.gis.scala.base.util.JSONUtil;
import com.starrocks.connector.flink.StarRocksSink;
import com.starrocks.connector.flink.row.sink.StarRocksSinkRowBuilder;
import com.starrocks.connector.flink.table.sink.StarRocksSinkOptions;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.*;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.connector.jdbc.JdbcStatementBuilder;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.table.api.DataTypes;
import org.apache.flink.table.api.TableSchema;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Duration;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * @ProductManager:01380164
 * @Author: 01407499
 * @CreateTime: 2024-01-18  16:25
 * @TaskId:30002536
 * @TaskName:ips_index_realtime_monitor
 * @Description:
 */
public class GeoKakfa2Sr {
    public static Logger logger = LoggerFactory.getLogger(GeoKakfa2Sr.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("geokafka2Sr.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.parseInt(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.parseInt(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (CommonUtil.isConfAvailable(confInfo)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();
            //生成水位线默认间隔是200ms
            //env.getConfig().setAutoWatermarkInterval(100);


            logger.error("--------------启动source-------------------------");
            // source
            DataStream<IpsIndexMonitor> dataStream = initKafakaSource(env, confInfo);

//            DataStream<String> dataStream2 = initKafakaSource2(env, confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink
//            dataStream.addSink(new ChkPai2SrSinkFunction()).setParallelism(sinkParallelism);
            dataStream.addSink(getSrSink()).setParallelism(sinkParallelism);
//            String outputPath = "hdfs://sfbd/user/hive/warehouse/tmp_dm_gis.db/" + confInfo.getProperty("hive.table.name");
//            initHdfsSink(dataStream2,outputPath,sinkParallelism);

            // 开启计算
            env.execute(GeoKakfa2Sr.class.getName());
        }
    }


    public static void initHdfsSink(DataStream<String> dataStream, String outputPath,Integer sinkParallelism) {
        OutputFileConfig outputFileConfig = OutputFileConfig.builder()
                .build();
        StreamingFileSink<String> bucketingSink = StreamingFileSink
                .forRowFormat(new Path(outputPath), new SimpleStringEncoder<String>("UTF-8"))
                .withBucketAssigner(new DateTimeBucketAssigner("yyyyMMdd", ZoneId.of("Asia/Shanghai")))
                .withRollingPolicy(DefaultRollingPolicy.builder()
                        .withRolloverInterval(8 * 60 * 1000L)
                        .withMaxPartSize(1024 * 1024 * 128L)
                        .withInactivityInterval(8 * 60 * 1000L)
                        .build()).withOutputFileConfig(outputFileConfig).build();
        dataStream.addSink(bucketingSink).setParallelism(sinkParallelism);
    }

    //生成sr sink
    private static SinkFunction<IpsIndexMonitor> getSrSink() {
        String jdbc_url = "jdbc:mysql://10.216.162.10:9030";
        String db_name = "gis_oms_uimp_rds";
        String user = "gis_oms_rds";
        String password = "gis_oms_rds@123@";
        String table = "gis_geo_city_resp_cnt_real_time_monitor";
        String load_url = "http://10.119.82.211:8030";
        StarRocksSinkOptions options = StarRocksSinkOptions.builder()
                .withProperty("jdbc-url", jdbc_url)
                .withProperty("load-url", load_url)
                .withProperty("database-name", db_name)
                .withProperty("table-name", table)
                .withProperty("username", user)
                .withProperty("password", password)
                .withProperty("sink.buffer-flush.max-rows", "500000")
                .withProperty("sink.buffer-flush.max-bytes", "67108864")
                .withProperty("sink.buffer-flush.interval-ms", "2000")
                .withProperty("sink.max-retries", "3")
                .build();


        TableSchema schema = TableSchema.builder()
                .field("inc_day", DataTypes.STRING())
                .field("city_code", DataTypes.STRING())
                .field("resp_cnt", DataTypes.INT())
                .field("hp_rec_cnt", DataTypes.INT())
                .field("ft_hp_rec_cnt", DataTypes.INT())
                .field("date_time", DataTypes.STRING())
                .build();

        //Transform the RowData to the Object[] according to the schema.
        ChkPaiIndexMonitorTransformer transformer = new ChkPaiIndexMonitorTransformer();
        //Create the sink with the schema, options, and transformer.
        return StarRocksSink.sink(schema, options, transformer);
    }

    public static class ChkPaiIndexMonitorTransformer implements StarRocksSinkRowBuilder<IpsIndexMonitor> {

        /**
         * Set each element of the object array according to the input RowData.
         * The schema of the array matches that of the StarRocks table.
         */
        @Override
        public void accept(Object[] internalRow, IpsIndexMonitor chkPaiIndexMonitor) {
            internalRow[5] = chkPaiIndexMonitor.getLog_create_time();
            internalRow[1] = chkPaiIndexMonitor.getCitycode();
            internalRow[2] = chkPaiIndexMonitor.getReps_cnt();
            internalRow[3] = chkPaiIndexMonitor.getRec_cnt();
            internalRow[4] = chkPaiIndexMonitor.getFt_rec_cnt();
            internalRow[0] = chkPaiIndexMonitor.getInc_day();
            // When the StarRocks table is a Primary Key table, you need to set the last element to indicate whether the data loading is an UPSERT or DELETE operation.
//            internalRow[internalRow.length - 1] = StarRocksSinkOP.UPSERT.ordinal();
        }
    }


    private static SinkFunction<ChkPaiIndexMonitor> getSink() {
        String insetIntoSql = "insert into gis_add_rds_zone_resp_cnt_real_time_monitor (inc_day,dept_code,city_code,resp_cnt,log_create_time) values (?,?,?,?,?)";
        JdbcStatementBuilder<ChkPaiIndexMonitor> builder = new JdbcStatementBuilder<ChkPaiIndexMonitor>() {
            @Override
            public void accept(PreparedStatement preparedStatement, ChkPaiIndexMonitor o) throws SQLException {
                preparedStatement.setString(1, o.getInc_day());
                preparedStatement.setString(2, o.getDeptcode());
                preparedStatement.setString(3, o.getCitycode());
                preparedStatement.setInt(4, o.getCnt());
                preparedStatement.setString(5, o.getLog_create_time());
            }
        };

        return JdbcSink.sink(
                insetIntoSql,
                builder,
                new JdbcExecutionOptions.Builder()
                        //设置每个批次写入的最大行数，默认值为5000
                        .withBatchSize(1000)
                        //设置批量写入的间隔时间，单位为毫秒，默认值为"无"
                        .withBatchIntervalMs(2000)
                        //设置写入失败后的最大重试次数，默认值为3
                        .withMaxRetries(3)
                        .build(),

                new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                        .withDriverName("com.mysql.jdbc.Driver")
                        .withUrl("jdbc:mysql://10.216.162.10:9030/gis_oms_uimp_rds")
                        .withUsername("gis_oms_rds")
                        .withPassword("gis_oms_rds@123@")
                        .build()
        );
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<IpsIndexMonitor> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromLatest();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(GeoKakfa2Sr::filter).setParallelism(srcParallelism).flatMap(new FlatMapFunction<String, JSONObject>() {
                    @Override
                    public void flatMap(String line, Collector<JSONObject> collector) throws Exception {
                        ArrayList<JSONObject> list = parseOmsToRe(line);
                        for (JSONObject jsonObject : list) {
                            collector.collect(jsonObject);
                        }
                    }
                }).setParallelism(srcParallelism)
                //设置水位线生成策略
                .assignTimestampsAndWatermarks(WatermarkStrategy.<JSONObject>forBoundedOutOfOrderness(Duration.ofSeconds(10))
                        .withTimestampAssigner(new SerializableTimestampAssigner<JSONObject>() {
                            @Override
                            public long extractTimestamp(JSONObject element, long recordTimestamp) {
                                return element.getLong("tm");
                            }
                        }))
                .keyBy(new KeySelector<JSONObject, String>() {
                    @Override
                    public String getKey(JSONObject jsonObject) throws Exception {
                        return jsonObject.getString("regcode");
                    }
                }).window(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                .allowedLateness(Time.minutes(5))
                .aggregate(new AggCntFunction(), new ResultProcessFunction()).setParallelism(srcParallelism);

    }

    private static SingleOutputStreamOperator<String> initKafakaSource2(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromLatest();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(GeoKakfa2Sr::filter).setParallelism(srcParallelism).flatMap(new FlatMapFunction<String, JSONObject>() {
                    @Override
                    public void flatMap(String line, Collector<JSONObject> collector) throws Exception {
                        ArrayList<JSONObject> list = parseOmsToRe(line);
                        for (JSONObject jsonObject : list) {
                            collector.collect(jsonObject);
                        }
                    }
                }).setParallelism(srcParallelism)
                //设置水位线生成策略
                .assignTimestampsAndWatermarks(WatermarkStrategy.<JSONObject>forBoundedOutOfOrderness(Duration.ofSeconds(10))
                        .withTimestampAssigner(new SerializableTimestampAssigner<JSONObject>() {
                            @Override
                            public long extractTimestamp(JSONObject element, long recordTimestamp) {
                                return element.getLong("tm");
                            }
                        }))
                .keyBy(new KeySelector<JSONObject, String>() {
                    @Override
                    public String getKey(JSONObject jsonObject) throws Exception {
                        return jsonObject.getString("regcode");
                    }
                }).window(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                .allowedLateness(Time.minutes(5))
                .aggregate(new AggCntFunction(), new ResultProcessFunctionV2()).setParallelism(srcParallelism);

    }

    public static class ResultProcessFunctionV2 extends ProcessWindowFunction<IpsIndexMonitor, String, String, TimeWindow> {

        @Override
        public void process(String key, Context context, Iterable<IpsIndexMonitor> elements, Collector<String> out) throws Exception {
            IpsIndexMonitor next = elements.iterator().next();
            TimeWindow window = context.window();
            long start = window.getStart();
            long end = window.getEnd();
            String min = DateUtil.tmToDate(start + "", "yyyyMMddHHmm");
            next.setLog_create_time(min);
            next.setInc_day(min.substring(0, 8));
            out.collect(next.toString());
        }
    }

    public static class ResultProcessFunction extends ProcessWindowFunction<IpsIndexMonitor, IpsIndexMonitor, String, TimeWindow> {

        @Override
        public void process(String key, Context context, Iterable<IpsIndexMonitor> elements, Collector<IpsIndexMonitor> out) throws Exception {
            IpsIndexMonitor next = elements.iterator().next();
            TimeWindow window = context.window();
            long start = window.getStart();
            long end = window.getEnd();
            String min = DateUtil.tmToDate(start + "", "yyyyMMddHHmm");
            next.setLog_create_time(min);
            next.setInc_day(min.substring(0, 8));
            out.collect(next);
        }
    }

    public static class AggCntFunction implements AggregateFunction<JSONObject, IpsIndexMonitor, IpsIndexMonitor> {

        @Override
        public IpsIndexMonitor createAccumulator() {
            return IpsIndexMonitor.init();
        }

        @Override
        public IpsIndexMonitor add(JSONObject jsonObject, IpsIndexMonitor accumulator) {
            String regcode = jsonObject.getString("regcode");
            String src = jsonObject.getString("src");
            Long precision = jsonObject.getLong("precision");
            String type = jsonObject.getString("type");
//            String q = jsonObject.getString("q");
            Integer status = jsonObject.getInteger("status");

//             HashSet<String> srcSet = new HashSet();

            if((!type.isEmpty())&&type.equals("url_e")){
                if(StringUtils.isNotEmpty(regcode)&&regcode.length()>2){
                    accumulator.setCitycode(regcode);
                    accumulator.setReps_cnt(accumulator.getReps_cnt()+1);
                    if(status!=null&&status.intValue()==0&&(!regcode.isEmpty())&&!regcode.equals("null")){
                        if(precision!=null&&precision==2){
                            accumulator.setRec_cnt(accumulator.getRec_cnt()+1);
                        }
                        if(precision!=null&&precision==2&&src!=null&&(src.matches("(.*)(yy|sf|mc|su|w_jj)(.*)")||src.startsWith("rh"))){
                            accumulator.setFt_rec_cnt(accumulator.getFt_rec_cnt()+1);
                        }

                    }

                }else{
                    accumulator.setCitycode("");
                }


            }




            return accumulator;
        }

        @Override
        public IpsIndexMonitor getResult(IpsIndexMonitor accumulator) {
            return accumulator;
        }

        @Override
        public IpsIndexMonitor merge(IpsIndexMonitor a, IpsIndexMonitor b) {
            return null;
        }
    }

    public static ArrayList<JSONObject> parseOmsToRe(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        ArrayList<JSONObject> list = new ArrayList<>();
        list.add(jsonObject);
        return list;
    }

    public static JSONObject parseMessageObject(String line) {
        JSONObject o = new JSONObject();
        String createTime = "";
        String type= "";
        String tm = "";
        String regcode="";
        String src="";
        String q="";
        Integer status=1;
        Integer precision=0;
        try{

            JSONObject jObj = JSON.parseObject(line.trim());
            JSONObject message = JSON.parseObject(jObj.getString("message"));
            type= message.getString("type");
            createTime = message.getString("dateTime");
            if (createTime != null) {
                createTime = createTime.split("\\.")[0];
            }
            tm = DateUtil.dateToStamp(createTime);
            status=Integer.parseInt(JSONUtil.getJsonVal(message, "data.status", "1"));
            src=JSONUtil.getJsonVal(message, "data.result.src", "");
            regcode=JSONUtil.getJsonVal(message, "data.result.regcode", "");
            if(StringUtils.isEmpty(regcode)){
                regcode="";
            }
            precision = Integer.parseInt(JSONUtil.getJsonVal(message, "data.result.precision", ""));


        }catch (Exception e){
            logger.error(e.toString());
        }
        o.put("precision",precision);
        o.put("src",src);
        o.put("regcode",regcode);
        o.put("tm",Long.parseLong(tm));
        o.put("createTime",createTime);
        o.put("type",type);
        o.put("status",status);
//        o.put("q",q);
        return o;
    }

    public static boolean filter(String line) {
        if (StringUtils.isNotEmpty(line)) {
            return line.contains("BEE_LOGS_GIS_GEO_COLLECT");
        }
        return false;
    }
}
