package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.realtime.func.VMSTrackDeserializationSchema;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.HashMap;
import com.sf.plough.runtime.client.unp.NoticeConfig;
import com.sf.plough.runtime.client.unp.SfNoticeRuntimeSingleton;
import com.sf.plough.runtime.core.config.RuntimeCommonProperties;
import spec.sdk.runtime.v1.client.unp.SfNoticeRuntime;
import spec.sdk.runtime.v1.domain.unp.NoticeRequest;
import spec.sdk.runtime.v1.domain.unp.NoticeResponse;
import java.util.Map;

import static com.sf.gis.java.base.util.HttpInvokeUtil.postMultiHeader;
import static com.sf.gis.java.base.util.HttpInvokeUtil.sendPostByParam;
import static com.sf.gis.java.realtime.utils.MultiKafka2HiveUtil22.isConfAvailable;


/**
 * 【时效护航】 司机告警数据智能电话外呼
 * 需求方：
 * @author 徐游飞（01417347）
 * 任务ID： (实时任务)
 */

public class IntelligentOutboundCallData2Hive {
    public static Logger logger = LoggerFactory.getLogger(IntelligentOutboundCallData2Hive.class);
    public static String appName = IntelligentOutboundCallData2Hive.class.getName();
    private static String send_url = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/outer/notify/send";
    private static int srcParallelism = 5;
    private static int sinkParallelism = 5;

    public static void main(String[] args) throws Exception {

        ArrayList<String> properties = new ArrayList<>();
        properties.add("intelligentOutboundCallData2Hive.properties");   //

        // 消费kafka数据
        process(properties, appName);

    }

    public static void process(ArrayList<String> propertiesName,String appName) throws Exception {
        // 获取配置文件名称
        String fileName = propertiesName.get(0);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName);

        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");

        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> naviDataStream = initKafakaSource(env,confInfo1,zipType1);

            // 数据处理
            DataStream<String> sendDataStream = getSendDataStream(naviDataStream);

            // sink
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(sendDataStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(appName);
        }
    }
    private static DataStream<String> getSendDataStream(DataStream<String> gisDataStream) {
        DataStream<String> sendDataStream = gisDataStream.map(line -> {

            // 获取access_token
            String token_all = getToken();
            // 拨打电话
            JSONObject line_obj = JSONObject.parseObject(line);
            // 电话解密
            String alarmId = JSONUtil.getJsonVal(line_obj, "alarmId", "");
            String phoneNumber = JSONUtil.getJsonVal(line_obj, "phoneNumber", "");
            byte[] decodedBytes = Base64.getDecoder().decode(phoneNumber);
            String phoneDecode = new String(decodedBytes);

            Random random = new Random();
            int idx = random.nextInt(10);
            System.out.println(random.nextInt(10));
            // 接口入参
            JSONObject data = new JSONObject();
            data.put("content",idx+" 师傅您好，我是顺丰时效护航助手，监测到您在途任务有异常，稍后会有人工电话联系您，请注意接听!!!");

            long now = System.currentTimeMillis();
            JSONObject param = new JSONObject();
            param.put("platformCode", "GIS-LSS-MMS");
            param.put("currentTime", now);
            param.put("seqNo", alarmId);
            param.put("notifyType", "2");
            param.put("templateCode", "GROUND_DRIVER_WARNING");
            param.put("receiver", phoneDecode);
            param.put("data", data.toJSONString());
            // 接口请求头
            Map<String, String> headers = new HashMap<>();
            String value = String.format("Bearer %s", token_all);
            headers.put("Authorization", value);
            headers.put("Content-Type", "application/json");

            // 调电话外呼接口
            String retStr = HttpInvokeUtil.postMultiHeader(send_url, param.toString(), headers);
            line_obj.put("send_result",retStr);

//            // 拨打电话
//            JSONObject ret_obj = ringUp(line_obj);

            return line_obj.toJSONString();
        });

        return sendDataStream;
    }

    public static String getToken(){
        String tokenUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/common/token";
        Map<String, String> headerMap = new HashMap<>(1);
        headerMap.put("Content-Type", "application/json");
        JSONObject body = new JSONObject();
        body.put("accountNo","01417347");

        String retStr = postMultiHeader(tokenUrl, body.toJSONString(), headerMap);
        JSONObject retStr_obj = JSONObject.parseObject(retStr);

        return JSONUtil.getJsonVal(retStr_obj, "data", "error");
    }

    private static JSONObject ringUp(JSONObject line_obj) {
        NoticeConfig noticeConfig = new NoticeConfig();
        noticeConfig.setEscapeEnabled(true);
        //测试
//        noticeConfig.setUnpNoticeSingleUrl("https://notice-apis.sit.sf-express.com/unp/notice/single");
//        noticeConfig.setUnpNoticeMultiUrl("https://notice-apis.sit.sf-express.com/unp/notice/multi");
//        noticeConfig.setUnpNoticeExtranetSingleUrl("https://unp-mail-sit.sit.sf-express.com:40086/unp/notice/single");
//        noticeConfig.setUnpNoticeExtranetMultiUrl("https://unp-mail-sit.sit.sf-express.com:40086/unp/notice/multi");
//        noticeConfig.setAccessId("JXcsJtfJ");
//        noticeConfig.setAccessToken("2d24ca98169d4b2089459a2cc96f2527");
        //生产
        noticeConfig.setUnpNoticeSingleUrl("https://notice-apis.sf-express.com/unp/notice/single");
        noticeConfig.setUnpNoticeMultiUrl("https://notice-apis.sf-express.com/unp/notice/multi");
        noticeConfig.setUnpNoticeExtranetSingleUrl("https://unp-mail.sf-express.com/unp/notice/single");
        noticeConfig.setUnpNoticeExtranetMultiUrl("https://unp-mail.sf-express.com/unp/notice/multi");
        noticeConfig.setAccessId("yvlEaqZT");
        noticeConfig.setAccessToken("4395d0ae4a4c4350b6360a596804bece");

        RuntimeCommonProperties properties = new RuntimeCommonProperties();
        SfNoticeRuntime client = SfNoticeRuntimeSingleton.getInstance(noticeConfig, properties);

        // 电话解密
        String phone_number = JSONUtil.getJsonVal(line_obj, "phone_number", "");
        byte[] decodedBytes = Base64.getDecoder().decode(phone_number);
        String phone_decode = new String(decodedBytes);

        NoticeRequest noticeRequest = new NoticeRequest();
        //设置接收者
        //noticeRequest.setUserId(phone_decode);
        noticeRequest.setUserId("18162194707");
        //设置模板编码
        noticeRequest.setTemplateCode("GISBDP-TASK-WARNING");//TEST-EMAIL12
        //设置模板内容参数
        Map<String, String> param = new HashMap<>();
        param.put("content","   5 横度平台，任务名称：数据迁移，告警类型：失败，请及时处理！ 666");
        noticeRequest.setTemplateParam(param);

        //发起内网单发请求 外网单发使用postExtranetSingleNotice
        NoticeResponse noticeResponse = client.postIntranetSingleNotice(noticeRequest, 5000);
        if (noticeResponse.isSuccess()) {
            System.out.println("打印响应ID");
            //打印响应ID
            System.out.println(noticeResponse.getDate());
            System.out.println(noticeResponse.getRequestId());

            line_obj.put("date",noticeResponse.getDate());
            line_obj.put("requestId",noticeResponse.getRequestId());
        } else {
            System.out.println("打印错误信息");
            //打印错误信息
            System.out.println(noticeResponse.getObj());
            System.out.println(noticeResponse.getErrorMessage());

            line_obj.put("errorMessage",noticeResponse.getErrorMessage());
        }

        return line_obj;
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo, String zipType) {
        String topic = confInfo.getProperty("kafka.topic");
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("offsetReset:"+offsetReset);
        KafkaSource<String> source = null;
        if(zipType.equals("gzip")){
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setValueOnlyDeserializer(new VMSTrackDeserializationSchema())
                    .build();
        }else{
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setProperty("value.deserializer.encoding", "UTF-8")
                    .setValueOnlyDeserializer(new SimpleStringSchema())
                    .build();
        }

        return env.fromSource(source, WatermarkStrategy.noWatermarks(), topic).name(topic).uid(topic).setParallelism(srcParallelism);
    }

}
