package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.sf.gis.java.base.util.MD5Util;
import com.sf.gis.java.realtime.utils.DateUtil;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import com.sf.gis.java.realtime.utils.SaltUtil;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/*
* 嘉里vms轨迹数据对接hbase
* */
public class JiaLiVMSTrackHbaseSinkFunction extends RichSinkFunction<String> {
    public static Logger logger = LoggerFactory.getLogger(JiaLiVMSTrackHbaseSinkFunction.class);

    private static final long serialVersionUID = 1L;

    //嘉里生产
    private String zkQuorum = "10.234.160.101,10.234.160.102,10.234.160.103,10.234.160.104,10.234.160.105";

//    //嘉里测试
//    private String zkQuorum="10.233.68.62,10.233.69.24,10.233.69.92,10.233.68.44,10.233.69.133";

    private String zkPort = "2182";

    private String zkParent = "/hbase";

    private String dataTableName="gis:jiali_vms_device_history";

    private String hbase_columnFamily = "info";

    private int dataTbPartitionNum = 100;

    private int hbaseCommitBatchSize= 100 ;

    private transient Connection connection;

    private static int cnt = 0;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);

        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();

        conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);
        conf.set("hbase.client.retries.number", "11");
        connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);
    }

    /**
     * @param value 从kafka接收的每一条记录都是数组，数组中的每一个原始都是一条gps记录   [{},{},},{}...]
     * @throws Exception
     */
    @Override
    public  void invoke(String value)  {
        if(!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
            try {

//                logger.error(value);

                JSONArray jsonArray = JSON.parseArray(value);

                //将轨迹点写出到hbase
                if ( jsonArray != null && !jsonArray.isEmpty() ) {
                    putList(jsonArray);
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void putList(JSONArray jsonArray) {

        Table table_human = null;

        Map<String, Map<String, String>> valueHumanMap = new HashMap<String, Map<String, String>>();

        try {
            table_human = connection.getTable(TableName.valueOf(dataTableName));
            long index = 0;

            Iterator it = jsonArray.iterator();
            cnt++;
            if (cnt <= 5) {
                logger.error("logger cnt:" + cnt + " ==> " + jsonArray.toJSONString());
            }

            while(it.hasNext()) {
                Map<String, String> mapTemp = new HashMap<String, String>();

                try {
                    Map<String, Object> map = (Map)it.next();

                    Set<String> keySet = map.keySet();
                    Iterator<String> keySetIt = keySet.iterator();

                    while( keySetIt.hasNext() )  {
                        String key = keySetIt.next();
                        Object value = map.get( key );

                        if ( value != null) {
                            String valueTemp = value.toString().replace("\"", "");
                            mapTemp.put(key, valueTemp);
                        }
                    }

                    map.clear();

                    //时间戳
                    String un = mapTemp.get("un");
                    //用户工号
                    String ak = mapTemp.get("ak");
                    //tm
                    String tm = mapTemp.get("tm");

                    //传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
                    long tmTemp = Long.parseLong( tm ) * 1000;
                    String trunc = DateUtil.truncTime( tmTemp+"" );

                    //100个预分区
                    String md5Key = un + "_" + ak + "_" + trunc ;
                    String rowkey = SaltUtil.generateSaltNew(md5Key, dataTbPartitionNum) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;

//                    System.out.println("rowKey="+rowkey);

                    valueHumanMap.put(rowkey, mapTemp);

                    if ( index != 0 && index%hbaseCommitBatchSize == 0 ) {
                        if(!valueHumanMap.isEmpty()) {
                            HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
                            valueHumanMap.clear();
                        }
                        index = 0;
                    }

                    index = index + 1;
                } catch(Exception e) {
                    logger.info("===========================异常记录:" + mapTemp);
                }
            }

//            System.out.println("-------------------------------------data end---------------------"+DateUtil.getCurrDatetime());

            if( !valueHumanMap.isEmpty() ) {
                HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
                valueHumanMap.clear();
            }


        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            //保证关闭连接
            IOUtils.closeStream(table_human);
        }
    }

}
