package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 从kafka读取日结数据落地到hive表
 * @author 20230425 caiguofang
 */
public class VehicleToHive {
	public static Logger logger = LoggerFactory.getLogger(VehicleToHive.class);

	public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("vehiclekafka2hive.properties",
				VehicleToHive.class.getName(),"\t");
	}
}
