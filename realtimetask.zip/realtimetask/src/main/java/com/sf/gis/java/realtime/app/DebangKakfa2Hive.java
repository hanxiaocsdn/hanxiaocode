package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * debang 日志
 */
public class DebangKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(DebangKakfa2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("debangkafka2hive.properties", DebangKakfa2Hive.class.getName());
    }

}
