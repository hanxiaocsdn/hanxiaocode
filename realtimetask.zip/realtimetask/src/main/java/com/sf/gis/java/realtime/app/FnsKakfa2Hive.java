package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * fns日志
 */
public class FnsKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(FnsKakfa2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("fnskafka2hive.properties", FnsKakfa2Hive.class.getName());
    }

}
