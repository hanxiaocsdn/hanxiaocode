package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

public class GeoObj implements Serializable
{

	private static final long serialVersionUID = -1799539519033507180L;
	//-原始-
	private String	id; //设备ID
	private String 	un; //用户工号
	private String 	bn; //网点号
	private int		tp; //定位类型 1:GPS,5:wifi,6:基站
	private double	zx;	//纠偏前x
	private double	zy; //纠偏前y
	private int		ac;	//精度
	private String	ad;	//海拔
	private String	be;	//方位角
	private int		sl;	//卫星数

	private float	sp;	//速度
	private long		tm;	//时间戳
	private String	sc; //来源
	private String	cr;	//坐标系

	private int		bt; //电量
	private String	xh; //型号
	private String 	v;//版本

	//-纠偏后-
	private int 	ak;//项目pk
	private double	dx;	//纠偏后x
	private double	dy;	//纠偏后y
	private int		state;

	private int pc; //耗电量
	private String st; //类型 0-自营/1-外包

	public GeoObj()
	{
		tp=-1;
		ac=-1;
		zx=-1.0;
		zy=-1.0;
		tm=-1;
		sp=0.0f;
		sl=0;

		dx=-1;
		dy=-1;
		state=-1;
		pc=0;
	}

	@Override
	public String toString() {
		return this.toString();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUn() {
		return un;
	}

	public void setUn(String un) {
		this.un = un;
	}

	public String getBn() {
		return bn;
	}

	public void setBn(String bn) {
		this.bn = bn;
	}

	public int getTp() {
		return tp;
	}

	public void setTp(int tp) {
		this.tp = tp;
	}

	public double getZx() {
		return zx;
	}

	public void setZx(double zx) {
		this.zx = zx;
	}

	public double getZy() {
		return zy;
	}

	public void setZy(double zy) {
		this.zy = zy;
	}

	public int getAc() {
		return ac;
	}

	public void setAc(int ac) {
		this.ac = ac;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public String getBe() {
		return be;
	}

	public void setBe(String be) {
		this.be = be;
	}

	public int getSl() {
		return sl;
	}

	public void setSl(int sl) {
		this.sl = sl;
	}

	public float getSp() {
		return sp;
	}

	public void setSp(float sp) {
		this.sp = sp;
	}

	public long getTm() {
		return tm;
	}

	public void setTm(long tm) {
		this.tm = tm;
	}

	public String getSc() {
		return sc;
	}

	public void setSc(String sc) {
		this.sc = sc;
	}

	public String getCr() {
		return cr;
	}

	public void setCr(String cr) {
		this.cr = cr;
	}

	public int getBt() {
		return bt;
	}

	public void setBt(int bt) {
		this.bt = bt;
	}

	public String getXh() {
		return xh;
	}

	public void setXh(String xh) {
		this.xh = xh;
	}

	public String getV() {
		return v;
	}

	public void setV(String v) {
		this.v = v;
	}

	public int getAk() {
		return ak;
	}

	public void setAk(int ak) {
		this.ak = ak;
	}

	public double getDx() {
		return dx;
	}

	public void setDx(double dx) {
		this.dx = dx;
	}

	public double getDy() {
		return dy;
	}

	public void setDy(double dy) {
		this.dy = dy;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public int getPc() {
		return pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}
}