package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务ID：20003672
 * 任务名称：GIS_ASS_ADDS_ELEV
 */
public class PjKafkaToHive {
    public static Logger logger = LoggerFactory.getLogger(PjKafkaToHive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("pjslkafka2hive.properties", PjKafkaToHive.class.getName());
    }
}
