package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

public class SegIndexMonitor implements Serializable {
    private String date_time;
    private int resp_cnt;
    private int province_rec_cnt;
    private int city_rec_cnt;
    private int county_rec_cnt;
    private int town_rec_cnt;
    private int city_rec_rev_cnt;
    private int citycode_rec_cnt;
    private String inc_day;

    public SegIndexMonitor() {
    }

    public static SegIndexMonitor init() {
        SegIndexMonitor monitor = new SegIndexMonitor();
        monitor.setResp_cnt(0);
        monitor.setProvince_rec_cnt(0);
        monitor.setCity_rec_cnt(0);
        monitor.setCounty_rec_cnt(0);
        monitor.setTown_rec_cnt(0);
        monitor.setCity_rec_rev_cnt(0);
        monitor.setCitycode_rec_cnt(0);
        return monitor;
    }

    public int getCitycode_rec_cnt() {
        return citycode_rec_cnt;
    }

    public void setCitycode_rec_cnt(int citycode_rec_cnt) {
        this.citycode_rec_cnt = citycode_rec_cnt;
    }

    public String getDate_time() {
        return date_time;
    }

    public void setDate_time(String date_time) {
        this.date_time = date_time;
    }

    public int getResp_cnt() {
        return resp_cnt;
    }

    public void setResp_cnt(int resp_cnt) {
        this.resp_cnt = resp_cnt;
    }

    public int getProvince_rec_cnt() {
        return province_rec_cnt;
    }

    public void setProvince_rec_cnt(int province_rec_cnt) {
        this.province_rec_cnt = province_rec_cnt;
    }

    public int getCity_rec_cnt() {
        return city_rec_cnt;
    }

    public void setCity_rec_cnt(int city_rec_cnt) {
        this.city_rec_cnt = city_rec_cnt;
    }

    public int getCounty_rec_cnt() {
        return county_rec_cnt;
    }

    public void setCounty_rec_cnt(int county_rec_cnt) {
        this.county_rec_cnt = county_rec_cnt;
    }

    public int getTown_rec_cnt() {
        return town_rec_cnt;
    }

    public void setTown_rec_cnt(int town_rec_cnt) {
        this.town_rec_cnt = town_rec_cnt;
    }

    public int getCity_rec_rev_cnt() {
        return city_rec_rev_cnt;
    }

    public void setCity_rec_rev_cnt(int city_rec_rev_cnt) {
        this.city_rec_rev_cnt = city_rec_rev_cnt;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
