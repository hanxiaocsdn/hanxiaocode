package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

/**
 * Created by 01374443 on 2020/3/2.
 */
public class SgsKafkaData implements Serializable {
    private String txid = "";
    private String appointmentNo = "";
    private String sysSource = "";
    private String pickupType = "";
    private String kafkaTime = "";
    private String isUnderCall = "";
    private String orderType = "";
    private String company = "";
    private String mobile = "";
    private String phone = "";
    private String contact = "";
    private String customerId = "";
    private String insert_hive_time = "";
    private String locationCode = "";
    private String province = "";
    private String city = "";
    private String county = "";
    private String address = "";
    private String waybillMainNo = "";

    public String getTxid() {
        return txid;
    }

    public String getInsert_hive_time() {
        return insert_hive_time;
    }

    public void setInsert_hive_time(String insert_hive_time) {
        this.insert_hive_time = insert_hive_time;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public String getPickupType() {
        return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }

    public String getIsUnderCall() {
        return isUnderCall;
    }

    public void setIsUnderCall(String isUnderCall) {
        this.isUnderCall = isUnderCall;
    }

    public String getAppointmentNo() {
        return appointmentNo;
    }

    public void setAppointmentNo(String appointmentNo) {
        this.appointmentNo = appointmentNo;
    }

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public String getKafkaTime() {
        return kafkaTime;
    }

    public void setKafkaTime(String kafkaTime) {
        this.kafkaTime = kafkaTime;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }


    public String getWaybillMainNo() {
        return waybillMainNo;
    }

    public void setWaybillMainNo(String waybillMainNo) {
        this.waybillMainNo = waybillMainNo;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }


    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void update(SgsKafkaOriginData origin) {
        this.txid = origin.getTxid() == null ? "" : origin.getTxid().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        ;
        this.appointmentNo = origin.getAppointmentNo() == null ? "" : origin.getAppointmentNo().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        ;
        this.sysSource = origin.getSysSource() == null ? "" : origin.getSysSource().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        ;
        this.pickupType = origin.getPickupType() == null ? "" : origin.getPickupType().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        ;
        if (origin.getExpressInfoList() != null && origin.getExpressInfoList().size() > 0
                && origin.getExpressInfoList().get(0).getOriginateInfo() != null) {
            SgsKafkaOriginData.ExpressInfo expressInfo = origin.getExpressInfoList().get(0);
            if (expressInfo != null) {
                this.waybillMainNo = expressInfo.getWaybillMainNo() == null ? "" : expressInfo.getWaybillMainNo().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                ;
                SgsKafkaOriginData.ExpressInfo.OriginateInfo originateInfo = origin.getExpressInfoList().get(0).getOriginateInfo();
                if (originateInfo != null) {
                    this.company = originateInfo.getCompany() == null ? "" : originateInfo.getCompany().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                    ;
                    this.mobile = originateInfo.getMobile() == null ? "" : originateInfo.getMobile().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                    ;
                    this.phone = originateInfo.getPhone() == null ? "" : originateInfo.getPhone().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                    ;
                    this.contact = originateInfo.getContact() == null ? "" : originateInfo.getContact().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                    ;
                    this.customerId = originateInfo.getCustomerId() == null ? "" : originateInfo.getCustomerId().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                    ;

                    SgsKafkaOriginData.ExpressInfo.OriginateInfo.AddressInfo addressInfo = originateInfo.getAddressInfo();
                    if (addressInfo != null) {
                        this.locationCode = addressInfo.getLocationCode() == null ? "" : addressInfo.getLocationCode().split("-")[0].replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                        ;
                        this.province = addressInfo.getProvince() == null ? "" : addressInfo.getProvince().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                        ;
                        this.city = addressInfo.getCity() == null ? "" : addressInfo.getCity().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                        ;
                        this.county = addressInfo.getCounty() == null ? "" : addressInfo.getCounty().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                        ;
                        this.address = addressInfo.getAddress() == null ? "" : addressInfo.getAddress().replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
                        ;
                    }
                }
            }
        }
    }
}
