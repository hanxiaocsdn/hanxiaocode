package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.sf.gis.java.realtime.utils.DateUtil;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import com.sf.gis.java.realtime.utils.MD5Util;
import com.sf.gis.java.realtime.utils.SaltUtil;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

/*
 *小哥轨迹日志入库,非常重要，勿动相关工具包
 * 任务id:30000669
 */
public class TrackToHBaseSinkFunction extends RichSinkFunction<String> {

    public static Logger logger = LoggerFactory.getLogger(TrackToHBaseSinkFunction.class);

    private static final long serialVersionUID = 1L;

    //生产
    private String zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw";

    //测试
    //private String zkQuorum = "10.202.116.103,10.202.116.104,10.202.116.105,10.202.116.106,10.202.116.107,10.202.116.130";

    private String zkPort = "2181";

    private String zkParent = "/hbase";

    private String dataTableName = "gis:tloc_human_history";
    private String carTableName = "gis:tloc_car_history";

    private String hbase_columnFamily = "info";

    private int dataTbPartitionNum = 100;

    private int hbaseCommitBatchSize = 100;

    private transient Connection connection;
//    private String shAk =
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();

        conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);
        conf.set("hbase.client.retries.number", "11");

        connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);
    }

    /**
     * @param value 从kafka接收的每一条记录都是数组，数组中的每一个原始都是一条gps记录   [{},{},},{}...]
     * @throws Exception
     */
    @Override
    public void invoke(String value) throws Exception {
        if (!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
            JSONArray jsonArray = null;
            try {
                jsonArray = JSON.parseArray(value);
            } catch (Exception e) {
                e.printStackTrace();
            }
            //将轨迹点写出到hbase
            if (jsonArray != null && !jsonArray.isEmpty()) {
                putList(jsonArray);
            }

        }
    }


    public void putList(JSONArray jsonArray) throws IOException {
//        List<String> hbase_sh_ak_list = new ArrayList<String>();
//        //String[] hbase_sh_ak_arr = "6,7,8,9,10,11,12,13,14,15,16,17,18,19,23,24".split(",");
//        String[] hbase_sh_ak_arr = shAk.split(",");
//        for (String line : hbase_sh_ak_arr) {
//            hbase_sh_ak_list.add(line);
//        }

        Table table_human = null;
//        Table table_du = null;
        Table table_car = null;

        Map<String, Map<String, String>> valueHumanMap = new HashMap<String, Map<String, String>>();
//		Map<String, Map<String, String>> valueMapSH = new HashMap<String, Map<String, String>>();
        Map<String, Map<String, String>> valueMapCar = new HashMap<String, Map<String, String>>();

        //统计每天不同的用户列表，设备号任一条都可以
//        Map<String, Map<String, String>> valueMapDateUser = new HashMap<String, Map<String, String>>();

//		String logTableName = logTableName;

        try {
            table_human = connection.getTable(TableName.valueOf(dataTableName));
//            table_du = connection.getTable(TableName.valueOf(userTableName));
            table_car = connection.getTable(TableName.valueOf(carTableName));
            long index = 0;

            Iterator it = jsonArray.iterator();
//            System.out.println("-------------------------------------data start---------------------"+DateUtil.getCurrDatetime());
            while (it.hasNext()) {
                Map<String, String> mapTemp = new HashMap<String, String>();

//                try {
                    Map<String, Object> map = (Map) it.next();

                    Set<String> keySet = map.keySet();
                    Iterator<String> keySetIt = keySet.iterator();
                    while (keySetIt.hasNext()) {
                        String key = keySetIt.next();
                        String value = map.get(key).toString();
                        String valueTemp = value.replace("\"", "");
                        mapTemp.put(key, valueTemp);
//                        System.out.println(key+"="+valueTemp);
                    }

                    map.clear();
                    //时间戳
                    String tm = mapTemp.get("tm");
                    //用户工号
                    String un = mapTemp.get("un");
                    //设备id
                    String id = mapTemp.get("id");
                    //传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
                    long tmTemp = 0;
                    try{
                        tmTemp = Long.parseLong(tm) * 1000;
                    }catch (Exception e){
                        continue;
                    }
                    String trunc = DateUtil.truncTime(tmTemp + "");
                    if(trunc.isEmpty()){
                        continue;
                    }
                    String ak = mapTemp.get("ak");

                    //100个预分区
                    String md5Key = un + "_" + trunc + "_" + ak;
//					System.out.println("un="+un+",trunc="+trunc+",ak="+ak);
                    String rowkey = SaltUtil.generateSaltNew(md5Key, dataTbPartitionNum) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;




//					//舒华项目数据
//					if(hbase_sh_ak_list.contains(ak)) {
//						valueMapSH.put(rowkey, mapTemp);
//					} else {
//						valueMap.put(rowkey, mapTemp);
//					}
                    if (!"1".equals(ak)) {
                        valueMapCar.put(rowkey, mapTemp);
                    } else {
                        if(index==0){
                            //增加一次打印,方便调试
                            System.out.println("rowKey="+rowkey);
                        }
                        valueHumanMap.put(rowkey, mapTemp);
                    }

                    //统计每天不同的用户列表，设备号任一条都可以
                    //20个预分区
//                    String rowkeyDateUser = SaltUtil.generateSalt(ak + trunc, userTbPartitionNum) + "_" + ak + "_" + trunc + "_" + un + "_" + id;

//                    if (!valueMapDateUser.containsKey(rowkeyDateUser)) {
//						if(!getFromCache(rowkeyDateUser)) {
//							Map<String, String> mapDateUser = new HashMap<String, String>();
//							mapDateUser.put("un", un);
//							valueMapDateUser.put(rowkeyDateUser, mapDateUser);
//
//							gisCache.put(rowkeyDateUser, 1);
//						}
//                    }

                    if (index != 0 && index % hbaseCommitBatchSize == 0) {
                        if (!valueHumanMap.isEmpty()) {
                            HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
                            valueHumanMap.clear();
                        }

                        //舒华项目数据
//						if(!valueMapSH.isEmpty()) {
//							HBaseUtil.put(table, hbase_columnFamilySH, valueMapSH);
//							valueMapSH.clear();
//						}
                        //car
                        if (!valueMapCar.isEmpty()) {
                            HBaseUtil.put(table_car, hbase_columnFamily, valueMapCar);
                            valueMapCar.clear();
                        }
//                        if (!valueMapDateUser.isEmpty()) {
//                            HBaseUtil.put(table_du, hbase_columnFamily, valueMapDateUser);
//                            valueMapDateUser.clear();
//                        }

                        index = 0;
                    }

                    index = index + 1;
//                } catch (Exception e) {
////                    HBaseUtil.putLog(logTableName, valueHumanMap, valueMapDateUser, valueMapCar, e);
//                    logger.info("===========================异常记录:" + mapTemp);
//                }
            }

//            System.out.println("-------------------------------------data end---------------------"+DateUtil.getCurrDatetime());

            if (!valueHumanMap.isEmpty()) {
                HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
                valueHumanMap.clear();
            }

            //舒华项目数据
//			if(!valueMapSH.isEmpty()) {
//				HBaseUtil.put(table, hbase_columnFamilySH, valueMapSH);
//				valueMapSH.clear();
//			}
            //car
            if (!valueMapCar.isEmpty()) {
                HBaseUtil.put(table_car, hbase_columnFamily, valueMapCar);
                valueMapCar.clear();
            }
//            if (!valueMapDateUser.isEmpty()) {
//                HBaseUtil.put(table_du, hbase_columnFamily, valueMapDateUser);
//                valueMapDateUser.clear();
//            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;

//            try {
//                HBaseUtil.putLog(logTableName, valueHumanMap, valueMapDateUser, valueMapCar, e);
//            } catch (IOException e1) {
//                e1.printStackTrace();
//            }
        } finally {
            //保证关闭连接
            IOUtils.closeStream(table_human);
//            IOUtils.closeStream(table_du);
            IOUtils.closeStream(table_car);
        }

    }
}
