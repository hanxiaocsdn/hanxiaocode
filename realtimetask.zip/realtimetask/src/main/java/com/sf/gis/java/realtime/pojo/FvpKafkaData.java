package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

/**
 * Created by 01374443 on 2020/3/2.
 */
public class FvpKafkaData implements Serializable {
    private String sfOrderId = "";
    private String sysOrderId = "";
    private String sysSource = "";
    private String senderCityCode = "";
    private String senderProvince = "";
    private String senderCityName = "";
    private String senderArea = "";
    private String senderAddr = "";
    private String senderCompany = "";
    private String senderMobile = "";
    private String senderTel = "";
    private String senderName = "";
    private String orderTime = "";
    private String monthlyCard = "";
    private String isUnderCall = "";
    private String orderType = "";
    private String pickupType = "";
    private String insert_hive_time = "";

    public String getInsert_hive_time() {
        return insert_hive_time;
    }

    public void setInsert_hive_time(String insert_hive_time) {
        this.insert_hive_time = insert_hive_time;
    }

    public String getSfOrderId() {
        return sfOrderId;
    }

    public void setSfOrderId(String sfOrderId) {
        this.sfOrderId = sfOrderId;
    }

    public String getSysOrderId() {
        return sysOrderId;
    }

    public void setSysOrderId(String sysOrderId) {
        this.sysOrderId = sysOrderId;
    }

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }

    public String getSenderCityCode() {
        return senderCityCode;
    }

    public void setSenderCityCode(String senderCityCode) {
        this.senderCityCode = senderCityCode;
    }

    public String getSenderProvince() {
        return senderProvince;
    }

    public void setSenderProvince(String senderProvince) {
        this.senderProvince = senderProvince;
    }

    public String getSenderCityName() {
        return senderCityName;
    }

    public void setSenderCityName(String senderCityName) {
        this.senderCityName = senderCityName;
    }

    public String getSenderArea() {
        return senderArea;
    }

    public void setSenderArea(String senderArea) {
        this.senderArea = senderArea;
    }

    public String getSenderAddr() {
        return senderAddr;
    }

    public void setSenderAddr(String senderAddr) {
        this.senderAddr = senderAddr;
    }

    public String getSenderCompany() {
        return senderCompany;
    }

    public void setSenderCompany(String senderCompany) {
        this.senderCompany = senderCompany;
    }

    public String getSenderMobile() {
        return senderMobile;
    }

    public void setSenderMobile(String senderMobile) {
        this.senderMobile = senderMobile;
    }

    public String getSenderTel() {
        return senderTel;
    }

    public void setSenderTel(String senderTel) {
        this.senderTel = senderTel;
    }

    public String getSenderName() {
        return senderName;
    }

    public void setSenderName(String senderName) {
        this.senderName = senderName;
    }

    public String getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(String orderTime) {
        this.orderTime = orderTime;
    }

    public String getMonthlyCard() {
        return monthlyCard;
    }

    public void setMonthlyCard(String monthlyCard) {
        this.monthlyCard = monthlyCard;
    }

    public String getIsUnderCall() {
        return isUnderCall;
    }

    public void setIsUnderCall(String isUnderCall) {
        this.isUnderCall = isUnderCall;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getPickupType() {
        return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }

    public void removeT() {
        this.sfOrderId = this.sfOrderId.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.sysOrderId = this.sysOrderId.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.sysSource = this.sysSource.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderCityCode = this.senderCityCode.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderProvince = this.senderProvince.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderCityName = this.senderCityName.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderArea = this.senderArea.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderAddr = this.senderAddr.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderCompany = this.senderCompany.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderMobile = this.senderMobile.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderTel = this.senderTel.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.senderName = this.senderName.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.orderTime = this.orderTime.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.monthlyCard = this.monthlyCard.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.isUnderCall = this.isUnderCall.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.orderType = this.orderType.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.pickupType = this.pickupType.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
        this.insert_hive_time = this.insert_hive_time.replaceAll("[',\",\\r,\\n,\\t,\\\\]", "");
    }
}
