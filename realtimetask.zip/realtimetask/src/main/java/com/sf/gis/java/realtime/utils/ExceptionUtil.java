package com.sf.gis.java.realtime.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 */
public class ExceptionUtil {

    private static Logger logger = LoggerFactory.getLogger(ExceptionUtil.class);

    public static String getStackTraceMsg(Exception exception) {
        String msg = exception.getMessage();

        ByteArrayOutputStream stream = null;
        PrintStream ps = null;
        try {
            stream = new ByteArrayOutputStream();
            ps = new PrintStream(stream, true, "utf-8");
            exception.printStackTrace(ps);
            msg = stream.toString();
        } catch(Exception e) {
            logger.error(e.getMessage());
        } finally {
            if(ps != null) {
                try {
                    ps.close();
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }
            }

            if(stream != null) {
                try {
                    stream.close();
                } catch (Exception e) {
                    logger.error(e.getMessage());
                }
            }
        }
        return msg;
    }

}
