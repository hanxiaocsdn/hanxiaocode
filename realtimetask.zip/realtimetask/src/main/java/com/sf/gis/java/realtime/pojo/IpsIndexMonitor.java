package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;

public class IpsIndexMonitor implements Serializable {
    private String log_create_time;
    private String citycode;
    private int reps_cnt;
    private int rec_cnt;
    private int ft_rec_cnt;
    private String inc_day;

    public String getLog_create_time() {
        return log_create_time;
    }

    public void setLog_create_time(String log_create_time) {
        this.log_create_time = log_create_time;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public int getReps_cnt() {
        return reps_cnt;
    }

    public void setReps_cnt(int reps_cnt) {
        this.reps_cnt = reps_cnt;
    }

    public int getRec_cnt() {
        return rec_cnt;
    }

    public void setRec_cnt(int rec_cnt) {
        this.rec_cnt = rec_cnt;
    }

    public int getFt_rec_cnt() {
        return ft_rec_cnt;
    }

    public void setFt_rec_cnt(int ft_rec_cnt) {
        this.ft_rec_cnt = ft_rec_cnt;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public IpsIndexMonitor() {
    }

    public static IpsIndexMonitor init() {
        IpsIndexMonitor monitor = new IpsIndexMonitor();
        monitor.setFt_rec_cnt(0);
        monitor.setRec_cnt(0);
        monitor.setReps_cnt(0);
        return monitor;
    }

    @Override
    public String toString() {
        return "IpsIndexMonitor{" +
                "log_create_time='" + log_create_time + '\'' +
                ", citycode='" + citycode + '\'' +
                ", reps_cnt=" + reps_cnt +
                ", rec_cnt=" + rec_cnt +
                ", ft_rec_cnt=" + ft_rec_cnt +
                ", inc_day='" + inc_day + '\'' +
                '}';
    }
}
