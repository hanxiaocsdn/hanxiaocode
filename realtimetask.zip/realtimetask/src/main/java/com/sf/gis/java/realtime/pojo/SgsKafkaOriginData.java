package com.sf.gis.java.realtime.pojo;

import java.io.Serializable;
import java.util.List;

/**
 * Created by 01374443 on 2020/3/2.
 */
public class SgsKafkaOriginData implements Serializable {
    private String txid;
    private String appointmentNo;
    private String sysSource;
    private String pickupType;
    private List<ExpressInfo> expressInfoList;

    public String getPickupType() {

        return pickupType;
    }

    public void setPickupType(String pickupType) {
        this.pickupType = pickupType;
    }

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public String getAppointmentNo() {
        return appointmentNo;
    }

    public void setAppointmentNo(String appointmentNo) {
        this.appointmentNo = appointmentNo;
    }

    public String getSysSource() {
        return sysSource;
    }

    public void setSysSource(String sysSource) {
        this.sysSource = sysSource;
    }


    public List<ExpressInfo> getExpressInfoList() {
        return expressInfoList;
    }

    public void setExpressInfoList(List<ExpressInfo> expressInfoList) {
        this.expressInfoList = expressInfoList;
    }

    public static class ExpressInfo{
        private String waybillMainNo;
        private OriginateInfo originateInfo;

        public String getWaybillMainNo() {
            return waybillMainNo;
        }

        public void setWaybillMainNo(String waybillMainNo) {
            this.waybillMainNo = waybillMainNo;
        }

        public OriginateInfo getOriginateInfo() {
            return originateInfo;
        }

        public void setOriginateInfo(OriginateInfo originateInfo) {
            this.originateInfo = originateInfo;
        }

        public static class OriginateInfo{
            private String company;
            private String mobile;
            private String phone;
            private String contact;
            private String customerId;
            private AddressInfo addressInfo;

            public String getCompany() {
                return company;
            }

            public void setCompany(String company) {
                this.company = company;
            }

            public String getMobile() {
                return mobile;
            }

            public void setMobile(String mobile) {
                this.mobile = mobile;
            }

            public String getPhone() {
                return phone;
            }

            public void setPhone(String phone) {
                this.phone = phone;
            }

            public String getContact() {
                return contact;
            }

            public void setContact(String contact) {
                this.contact = contact;
            }

            public String getCustomerId() {
                return customerId;
            }

            public void setCustomerId(String customerId) {
                this.customerId = customerId;
            }

            public AddressInfo getAddressInfo() {
                return addressInfo;
            }

            public void setAddressInfo(AddressInfo addressInfo) {
                this.addressInfo = addressInfo;
            }

            public static class AddressInfo{
                private String locationCode;
                private String province;
                private String city;
                private String county;
                private String address;

                public String getLocationCode() {
                    return locationCode;
                }

                public void setLocationCode(String locationCode) {
                    this.locationCode = locationCode;
                }

                public String getProvince() {
                    return province;
                }

                public void setProvince(String province) {
                    this.province = province;
                }

                public String getCity() {
                    return city;
                }

                public void setCity(String city) {
                    this.city = city;
                }

                public String getCounty() {
                    return county;
                }

                public void setCounty(String county) {
                    this.county = county;
                }

                public String getAddress() {
                    return address;
                }

                public void setAddress(String address) {
                    this.address = address;
                }
            }
        }
    }
}
