package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.sf.gis.java.realtime.utils.DateUtil;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import com.sf.gis.java.realtime.utils.MD5Util;
import com.sf.gis.java.realtime.utils.SaltUtil;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

/*
 *需求描述：极兔kafka数据入库hbase
 *任务id:30002137
 *负责人：周勇 01390943
 */

public class JtTrackToHBaseSinkFunction extends RichSinkFunction<String> {

    public static Logger logger = LoggerFactory.getLogger(TrackToHBaseSinkFunction.class);

    private static final long serialVersionUID = 1L;

    //生产
    private String zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw";

    //测试
    //private String zkQuorum = "10.202.116.103,10.202.116.104,10.202.116.105,10.202.116.106,10.202.116.107";

    private String zkPort = "2181";

    private String zkParent = "/hbase";

    //生产
    private String dataTableName = "gis:tloc_ext_history";

    //测试
    //private String dataTableName = "default:jt_test";

    private String hbase_columnFamily = "info";

    private int dataTbPartitionNum = 100;

    private int hbaseCommitBatchSize = 100;

    private transient Connection connection;
    //    private String shAk =
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();

        conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);
        conf.set("hbase.client.retries.number", "11");

        connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);
    }

    /**
     * @param value 从kafka接收的每一条记录都是数组，数组中的每一个原始都是一条轨迹记录   [{},{},},{}...]
     * @throws Exception
     */
    @Override
    public void invoke(String value) throws Exception {
        if (!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
            JSONArray jsonArray = null;
            try {
                jsonArray = JSON.parseArray(value);
            } catch (Exception e) {
                e.printStackTrace();
            }
            //将轨迹点写出到hbase
            if (jsonArray != null && !jsonArray.isEmpty()) {
                putList(jsonArray);
            }

        }
    }

    public void putList(JSONArray jsonArray) throws IOException {

        Table table_jt = null;

        Map<String, Map<String, String>> valueJtMap = new HashMap<String, Map<String, String>>();

        try {
            table_jt = connection.getTable(TableName.valueOf(dataTableName));

            long index = 0;

            Iterator it = jsonArray.iterator();
            System.out.println("-------------------------------------data start---------------------"+DateUtil.getCurrDatetime());

            while (it.hasNext()) {
                Map<String, String> mapTemp = new HashMap<String, String>();

                Map<String, Object> map = (Map) it.next();

                Set<String> keySet = map.keySet();
                Iterator<String> keySetIt = keySet.iterator();
                while (keySetIt.hasNext()) {
                    String key = keySetIt.next();
                    String value = map.get(key).toString();
                    String valueTemp = value.replace("\"", "");
                    mapTemp.put(key, valueTemp);
                    //System.out.println(key+"="+valueTemp);
                }

                map.clear();
                //时间戳
                String tm = mapTemp.get("tm");
                //用户工号
                String un = mapTemp.get("un");
                //ak
                String ak = mapTemp.get("ak");
                //传入时间戳
                long tmTemp = 0;
                try{
                    tmTemp = Long.parseLong(tm) * 1000;
                }catch (Exception e){
                    continue;
                }
                String trunc = DateUtil.truncTime(tmTemp + "");
                if(trunc.isEmpty()){
                    continue;
                }

                //100个预分区
                String md5Key = un + "_" + trunc+ "_" + ak ;
                String rowkey = SaltUtil.generateSaltNew(md5Key, dataTbPartitionNum) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;

                //System.out.println("rowkey>>>>:"+rowkey);

                valueJtMap.put(rowkey, mapTemp);

                if (index != 0 && index % hbaseCommitBatchSize == 0) {
                    if (!valueJtMap.isEmpty()) {
                        HBaseUtil.put(table_jt, hbase_columnFamily, valueJtMap);
                        valueJtMap.clear();
                    }

                    index = 0;
                }

                index = index + 1;

            }

            if (!valueJtMap.isEmpty()) {
                HBaseUtil.put(table_jt, hbase_columnFamily, valueJtMap);
                valueJtMap.clear();
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw e;

        } finally {
            //保证关闭连接
            IOUtils.closeStream(table_jt);
        }

    }
}
