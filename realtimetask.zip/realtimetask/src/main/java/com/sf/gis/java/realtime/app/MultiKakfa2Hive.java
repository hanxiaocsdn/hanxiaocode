package com.sf.gis.java.realtime.app;

import com.sf.gis.java.realtime.utils.MultiKafka2HiveUtil22;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;

/**
 * GIS_RSS_SCM 【计提日志】计提推送信息存入BDP_V1.0
 * 需求内容：1.将计提相关的3个kafka数据接入BDP平台，3个kafka数据存入一张结果表，数据通过topic区分
 *         2.将ETA请求日志kafka数据接入BDP平台，数据通过topic区分 // （暂时不用，可下线）
 * 需求方：1.李非龙（ft220114）  2.曹倩倩（01425168）
 * @author 徐游飞（01417347）
 * 任务ID：20005014 (实时任务)
 * 任务名称：计提相关日志kafka数据接入
 */

public class MultiKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(MultiKakfa2Hive.class);
    public static String appName = MultiKakfa2Hive.class.getName();

    public static void main(String[] args) throws Exception {

        ArrayList<String> properties = new ArrayList<>();
        properties.add("multikafka2hive1.properties");   //李非龙（ft220114）
        properties.add("multikafka2hive2.properties");   //李非龙（ft220114）
        properties.add("multikafka2hive3.properties");   //李非龙（ft220114）
        properties.add("multikafka2hive4.properties");   //曹倩倩（01425168）

//        // 消费1个kafka数据
//        MultiKafka2HiveUtil22.process1(properties, appName);

//        // 消费2个kafka数据
//        MultiKafka2HiveUtil22.process2(properties, appName);
//
//        // 消费3个kafka数据
//        MultiKafka2HiveUtil22.process3(properties, appName);
//
        // 消费4个kafka数据
        MultiKafka2HiveUtil22.process4(properties, appName);

    }

}
