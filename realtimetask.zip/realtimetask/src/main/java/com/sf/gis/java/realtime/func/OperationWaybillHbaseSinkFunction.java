package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.HbaseUtil;
import com.sf.gis.java.realtime.utils.HBaseUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class OperationWaybillHbaseSinkFunction extends RichSinkFunction<String> {
    public static Logger logger = LoggerFactory.getLogger(OperationWaybillHbaseSinkFunction.class);
    private static final long serialVersionUID = 1L;

    private String zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw";
    private String zkPort = "2181";
    private String zkParent = "/hbase";
    private String tableName = "gis:shiva_oms_core_operation_waybill";
    private String cf = "info";
    private String column = "rules";
    private String prefix = "opw";
    private int batchSize = 100;
    private static Connection connection = null;
    private static BufferedMutator mutator;
    private static int count = 0;

    //    private static Table table;
    private static int cnt = 0;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);
        conf.set("hbase.client.retries.number", "11");
        connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);

        BufferedMutatorParams params = new BufferedMutatorParams(TableName.valueOf(tableName));
        params.writeBufferSize(2 * 1024 * 1024);
        mutator = connection.getBufferedMutator(params);
//        table = HbaseUtil.getTable(connection, tableName);
    }

    @Override
    public void invoke(String value) throws Exception {
        if (StringUtils.isNotEmpty(value)) {
            try {
                JSONObject jsonObject = JSON.parseObject(value);
                if (jsonObject != null) {
                    putList(jsonObject);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void putList(JSONObject o) throws IOException {
        try {
            String waybill_no = o.getString("waybill_no");
            if (StringUtils.isNotEmpty(waybill_no)) {
//                cnt++;
//                if (cnt <= 50) {
//                    logger.error("logger o:" + o.toJSONString());
//                }
                String rowKey = HbaseUtil.getKeyStr(prefix + "_" + waybill_no, 100);
                Put put = new Put(rowKey.getBytes());
                put.addColumn(cf.getBytes(), column.getBytes(), o.toJSONString().getBytes());
                mutator.mutate(put);
                if (count >= batchSize) {
                    mutator.flush();
                    count = 0;
                }
                count = count + 1;
//                String rowKey = HbaseUtil.getKeyStr(prefix + "_" + waybill_no, 100);
//                Put put = HbaseUtil.getPut(rowKey, cf, column, o.toJSONString());
//                table.put(put);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void close() throws IOException {
        if (mutator != null) {
            mutator.close();
        }
        if (connection != null) {
            connection.close();
        }
    }
}
