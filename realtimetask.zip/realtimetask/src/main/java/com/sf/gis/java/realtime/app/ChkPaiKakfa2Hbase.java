package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.ChkPai2HbaseSinkFunction;
import com.sf.gis.java.realtime.utils.CommonUtil;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Properties;

/**
 * 需求：派件日志实时入hbase
 * 需求方：李莹（01425237）
 * 研发：匡仁衡（01399581）
 * 任务id：30000322（flink）
 */
public class ChkPaiKakfa2Hbase {
    public static Logger logger = LoggerFactory.getLogger(ChkPaiKakfa2Hbase.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("chkpaikafka2hbase.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.parseInt(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.parseInt(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (CommonUtil.isConfAvailable(confInfo)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> dataStream = initKafakaSource(env, confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink
            dataStream.addSink(new ChkPai2HbaseSinkFunction()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(ChkPaiKakfa2Hbase.class.getName());
        }
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromGroupOffsets();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(ChkPaiKakfa2Hbase::filter).setParallelism(srcParallelism).flatMap(new FlatMapFunction<String, String>() {
                    @Override
                    public void flatMap(String line, Collector<String> collector) throws Exception {
                        ArrayList<String> list = parse(line);
                        for (String s : list) {
                            collector.collect(s);
                        }
                    }
                }).setParallelism(srcParallelism);

    }

    public static ArrayList<String> parse(String line) {
        ArrayList<String> list = new ArrayList<>();
        try {
            if (line.contains("=>receive oms waybill message")) {
                list = parseOmsToReq(line);
            } else if (line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS")) {
                list = parseOmsToRe(line);
            } else if (line.contains("ATPai->")) {
                list = parseATPaiData(line);
            } else if (line.contains("=>kafka topic GIS_ASS_RDS_CHK,message:")) {
                list = parseGisToKs(line);
            } else if (line.contains("=>ksMsg:")) {
                list = parseKsToGis(line);
            } else if (line.contains("kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:")) {
                list = parseGisToArss(line);
            } else if (line.contains("kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:")) {
                list = parseGisToArss(line);
            } else if (line.contains("=>receive waybill dept chk message")) {
                list = parseOmsDeptArss(line);
            } else if (line.contains("kafka topic GIS_ASS_RDS_TO_AWSM,message:")) {
                list = parseGisToAwsm(line);
            } else if (line.contains("=>receive awsm message")) {
                list = parseAwsmToGis(line);
            } else if (line.contains("=>receive sss addr chk message")) {
                list = parseSssToGis(line);
            } else if (line.contains("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM,message:")) {
                list = parseGisToAoi(line);
            } else if (line.contains("=>chkAoiMsg:")) {
                list = parseAoiToGis(line);
            } else if (line.contains("receive arss addr chk message")) {
                list = parseArssAddrChk(line);
            } else if (line.contains("AddressUnkowCheck:")) {
                list = parseAddressUnkonCheck(line);
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return list;
    }

    public static ArrayList<String> parseArssAddrChk(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("arss_addr_chk_time", createTime);
        String log_type = "arss_addr_chk_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseAddressUnkonCheck(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("address_unkow_check_time", createTime);
        body.put("async_waybillNo", body.getString("waybillNo"));
        body.put("async_time", createTime);

        String log_type = "address_unkow_check_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseAoiToGis(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("aoi_dept_re_time", createTime);
        body.put("async_waybillNo", body.getString("waybillNo"));
        body.put("async_time", createTime);

        String log_type = "aoi_dept_re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseGisToAoi(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        ArrayList<String> list = new ArrayList<>();
        //单个请求
        if (chkDisLogObj != null) {

            JSONObject re = new JSONObject();
            JSONObject body = chkDisLogObj;

            re.put("waybillNo", waybillNo);
            re.put("requestId", requestId);
            re.put("type", "omsto");
            re.put("nodeId", ip);

            body.put("aoi_dept_req_time", createTime);
            body.put("async_waybillNo", body.getString("waybillNo"));
            body.put("async_time", createTime);

            String log_type = "aoi_dept_req_body";
            re.put("log_type", log_type);
            re.put(log_type, body);
            list.add(re.toJSONString());
        }
        //批量请求
        JSONArray chkDisLogArray = jsonObject.getJSONArray("chkDisLogArray");
        if (chkDisLogArray != null) {
            JSONArray bodys = chkDisLogArray;
            for (int i = 0; i < bodys.size(); i++) {
                JSONObject re = new JSONObject();
                JSONObject body = bodys.getJSONObject(i);

                re.put("waybillNo", body.getString("waybillNo"));
                re.put("requestId", body.getString("requestId"));
                re.put("type", "omsto");
                re.put("nodeId", ip);

                body.put("aoi_dept_req_time", createTime);
                body.put("async_waybillNo", body.getString("waybillNo"));
                body.put("async_time", createTime);

                String log_type = "aoi_dept_req_body";
                re.put("log_type", log_type);
                re.put(log_type, body);

                list.add(re.toJSONString());
            }
        }
        return list;
    }

    public static ArrayList<String> parseSssToGis(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("sss_dept_re_time", createTime);
        body.put("async_waybillNo", body.getString("waybillNo"));
        body.put("async_time", createTime);
        String log_type = "sss_dept_re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseAwsmToGis(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("awsm_tc_re_time", createTime);
        body.put("async_waybillNo", body.getString("waybillNo"));
        body.put("async_time", createTime);
        String log_type = "awsm_tc_re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseGisToAwsm(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        ArrayList<String> list = new ArrayList<>();
        if (chkDisLogObj != null) {
            JSONObject re = new JSONObject();
            JSONObject body = chkDisLogObj;
            re.put("waybillNo", waybillNo);
            re.put("requestId", requestId);
            re.put("type", "omsto");
            re.put("nodeId", ip);

            body.put("awsm_tc_req_time", createTime);
            body.put("async_waybillNo", body.getString("waybillNo"));
            body.put("async_time", createTime);
            String log_type = "awsm_tc_req_body";
            re.put("log_type", log_type);
            re.put(log_type, body);
            list.add(re.toJSONString());
        }

        JSONArray chkDisLogArray = jsonObject.getJSONArray("chkDisLogArray");
        if (chkDisLogArray != null) {
            JSONArray bodys = chkDisLogArray;
            for (int i = 0; i < bodys.size(); i++) {
                JSONObject re = new JSONObject();
                JSONObject body = bodys.getJSONObject(i);
                re.put("waybillNo", body.getString("waybillNo"));
                re.put("requestId", body.getString("requestId"));
                re.put("type", "omsto");
                re.put("nodeId", ip);

                body.put("awsm_tc_req_time", createTime);
                body.put("async_waybillNo", body.getString("waybillNo"));
                body.put("async_time", createTime);

                String log_type = "awsm_tc_req_body";
                re.put("log_type", log_type);
                re.put(log_type, body);
                list.add(re.toJSONString());
            }
        }
        return list;
    }

    public static ArrayList<String> parseOmsDeptArss(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject body = chkDisLogObj;
        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("nodeId", ip);
        re.put("type", "omsto");
        body.put("arss_dept_re_time", createTime);
        body.put("async_time", createTime);
        body.put("async_waybillNo", body.getString("waybillNo"));
        String log_type = "arss_dept_re_array";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseGisToArss(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject chkDisLogObj = jsonObject.getJSONObject("chkDisLogObj");

        ArrayList<String> list = new ArrayList<>();
        //单个请求
        if (chkDisLogObj != null) {
            JSONObject body = chkDisLogObj;
            JSONObject re = new JSONObject();
            re.put("waybillNo", waybillNo);
            re.put("requestId", requestId);
            re.put("type", "omsto");
            re.put("nodeId", ip);

            body.put("arss_dept_req_time", createTime);
            body.put("async_time", createTime);
            body.put("async_waybillNo", body.getString("waybillNo"));
            String log_type = "arss_dept_req_array";
            re.put("log_type", log_type);
            re.put(log_type, body);
            list.add(re.toJSONString());
        }
        //批量请求
        JSONArray chkDisLogArray = jsonObject.getJSONArray("chkDisLogArray");
        if (chkDisLogArray != null) {
            JSONArray bodys = chkDisLogArray;
            for (int i = 0; i < bodys.size(); i++) {
                JSONObject re = new JSONObject();
                JSONObject body = bodys.getJSONObject(i);
                re.put("waybillNo", body.getString("waybillNo"));
                re.put("requestId", body.getString("requestId"));
                re.put("type", "omsto");
                re.put("nodeId", ip);

                body.put("arss_dept_req_time", createTime);
                body.put("async_time", createTime);
                body.put("async_waybillNo", body.getString("waybillNo"));
                String log_type = "arss_dept_req_array";
                re.put("log_type", log_type);
                re.put(log_type, body);
                list.add(re.toJSONString());
            }
        }
        return list;
    }

    public static ArrayList<String> parseKsToGis(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject result = body.getJSONObject("result");
        if (result != null) {
            JSONObject attachmentObj = result.getJSONObject("attachment");
            JSONObject omsReq = attachmentObj.getJSONObject("omsReq");
            if (omsReq != null) {
                re.put("async_waybillNo", omsReq.getString("waybillNo"));
                if (StringUtils.isEmpty(waybillNo)) {
                    waybillNo = omsReq.getString("waybillNo");
                }
            }
            result.remove("attachment");
            body.put("result", result);
        }

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("nodeId", ip);

        body.put("ks_re_time", createTime);
        body.put("async_time", createTime);
        String log_type = "ks_re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseGisToKs(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        JSONObject attachmentObj = body.getJSONObject("attachment");
        if (attachmentObj != null && attachmentObj.getJSONObject("omsReq") != null) {
            re.put("async_waybillNo", attachmentObj.getJSONObject("omsReq").getString("waybillNo"));
            if (StringUtils.isEmpty(waybillNo)) {
                waybillNo = attachmentObj.getJSONObject("omsReq").getString("waybillNo");
            }
        }
        body.remove("attachment");

        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("type", "omsto");
        re.put("nodeId", ip);

        body.put("async_time", createTime);
        body.put("ks_req_time", createTime);
        String log_type = "ks_req_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseATPaiData(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject atResBody = body.getJSONObject("res");
        JSONObject atPaiBody = new JSONObject();
        String notc = "0";
        String chkDeptSrc = "";
        String precision = "";
        String src = "";
        String groupId = "";
        String standardization = "";
        String city = "";
        String adcode = "";

        ArrayList<String> groupIds = new ArrayList<>();
        ArrayList<String> filters = new ArrayList<>();
        ArrayList<String> adcodes = new ArrayList<>();
        ArrayList<String> keys = new ArrayList<>();
        ArrayList<String> keyWords = new ArrayList<>();
        ArrayList<String> matchIds = new ArrayList<>();
        ArrayList<String> other_matchid = new ArrayList<>();
        String splitResult = "";
        String splitType = "-1";
        String aoiCode = "";
        String atAoiSrc = "";
        try {
            if (atResBody.containsKey("result")) {
                JSONObject result = atResBody.getJSONObject("result");
                JSONObject idList = JSONUtil.getJSONObject(result, "idList");
                if (idList == null) {
                    idList = JSONUtil.getJSONObject(result, "id_list");
                }
                atPaiBody.put("idList", idList);
                if (result.containsKey("tcs")) {
                    JSONArray tcs = result.getJSONArray("tcs");
                    if (tcs != null && tcs.size() > 0) {
                        atPaiBody.put("tcs", tcs);
                        JSONObject tcObj = tcs.getJSONObject(0);
                        aoiCode = tcObj.getString("aoicode");
                        atAoiSrc = tcObj.getString("atAoiSrc");
                        notc = tcObj.getString("notc");
                        src = tcObj.getString("src");
                        if (tcObj.containsKey("chkDeptSrc")) {
                            //增加审补网点来源
                            chkDeptSrc = tcObj.getString("chkDeptSrc");
                        }
                        if (tcObj.containsKey("precision")) {
                            //增加精确度
                            precision = tcObj.getString("precision");
                        }
                        if (tcObj.containsKey("other")) {
                            JSONObject other_obj = tcObj.getJSONObject("other");
                            other_matchid.add(JSONUtil.getJsonVal(other_obj, "matchId", ""));
                        }
                        groupId = tcObj.getString("groupid");
                    }
                }
                JSONObject myOther = result.getJSONObject("myOther");
                if (myOther == null) {
                    myOther = result.getJSONObject("other");
                }
                if (myOther != null) {
                    //          val myOther = result.getJSONObject("myOther")
                    city = JSONUtil.getJsonVal(myOther, "city", "");
                    adcode = JSONUtil.getJsonVal(myOther, "adcode", "");
                    if (myOther.containsKey("normresp")) {
                        JSONObject normResp = myOther.getJSONObject("normresp");
                        if (normResp.containsKey("result")) {
                            JSONObject normResult = normResp.getJSONObject("result");
                            splitResult = JSONUtil.getJsonVal(normResult, "splitResult", "").replaceAll(",", "|");
                            splitType = JSONUtil.getJsonVal(normResult, "splitType", "-1");
                            String[] terms = splitResult.split(";")[0].split("\\|");
                            if (normResult.containsKey("geocoder")) {
                                JSONArray geoCoders = normResult.getJSONArray("geocoder");
                                for (int i = 0; i < geoCoders.size(); i++) {
                                    JSONObject geoCoder = geoCoders.getJSONObject(i);
                                    String group = JSONUtil.getJsonVal(geoCoder, "group", "");
                                    groupIds.add(group);
                                    if ("norm".equals(src) && group.equals(groupId)) {
                                        standardization = JSONUtil.getJsonVal(geoCoder, "standardization", "");
                                    }
                                    filters.add(JSONUtil.getJsonVal(geoCoder, "filter", ""));
                                    adcodes.add(JSONUtil.getJsonVal(geoCoder, "adcode", ""));
                                    matchIds.add(JSONUtil.getJsonVal(geoCoder, "id", ""));
                                    String key = JSONUtil.getJsonVal(geoCoder, "key", "");
                                    keys.add(key);
                                    StringBuilder keyWordBuilder = new StringBuilder();
                                    if (!"".equals(key)) {
                                        for (String keyIdx : key.split("\\|")) {
                                            keyWordBuilder.append(terms[Integer.parseInt(keyIdx)].split("\\^")[0]);
                                        }
                                    }
                                    keyWords.add(keyWordBuilder.toString());
                                }
                            }
                        }
                    }
                }
            }
            if (atResBody.containsKey("rpcInfo")) {
                atPaiBody.put("rpcInfo", atResBody.getJSONObject("rpcInfo"));
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        atPaiBody.put("notc", notc);
        atPaiBody.put("city", city);
        atPaiBody.put("adcode", adcode);
        atPaiBody.put("standardization", standardization);
        atPaiBody.put("splitResult", splitResult);
        atPaiBody.put("splitType", splitType);
        atPaiBody.put("groupIds", groupIds);
        atPaiBody.put("filters", filters);
        atPaiBody.put("adcodes", adcodes);
        atPaiBody.put("keys", keys);
        atPaiBody.put("keyWords", keyWords);
        atPaiBody.put("matchIds", matchIds);
        atPaiBody.put("groupId", groupId);
        atPaiBody.put("chkDeptSrc", chkDeptSrc);
        atPaiBody.put("precision", precision);
        atPaiBody.put("other_matchid", other_matchid);
        atPaiBody.put("aoiCode", aoiCode);
        atPaiBody.put("aoiSrc", atAoiSrc);

        JSONObject re = new JSONObject();
        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("nodeId", ip);
        re.put("type", "omsto");


        atPaiBody.put("atpai_time", createTime);
        String log_type = "atpai_body";
        re.put("log_type", log_type);
        re.put(log_type, atPaiBody);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseOmsToRe(String line) {
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("nodeId", ip);
        re.put("type", "omsto");

        body.put("datetime", createTime);
        body.put("re_time", createTime);
        body.put("async_time", createTime);
        body.put("async_waybillNo", waybillNo);

        String log_type = "re_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }

    public static ArrayList<String> parseOmsToReq(String line) {
        ///香港请求特殊，存在一个翻译的过程，如果地址第一次没识别到，会发到arss做翻译，翻译完以后，就会生成一条新的oms请求，发到源头，走全流程链路
        //翻译标志addrChkResult:true
        JSONObject jsonObject = parseMessageObject(line);
        String waybillNo = jsonObject.getString("waybillNo");
        String requestId = jsonObject.getString("requestId");
        String ip = jsonObject.getString("ip");
        String createTime = jsonObject.getString("createTime");
        JSONObject body = jsonObject.getJSONObject("chkDisLogObj");

        JSONObject re = new JSONObject();
        re.put("waybillNo", waybillNo);
        re.put("requestId", requestId);
        re.put("nodeId", ip);
        re.put("type", "omsto");
        body.put("req_time", createTime);

        String log_type = "req_body";
        re.put("log_type", log_type);
        re.put(log_type, body);

        ArrayList<String> list = new ArrayList<>();
        list.add(re.toJSONString());
        return list;
    }


    public static JSONObject parseMessageObject(String line) {
        JSONObject o = new JSONObject();
        JSONObject jObj = JSON.parseObject(line.trim());
        String createTime = jObj.getString("createTime");
        if (createTime != null) {
            createTime = createTime.replace(".", " ");
        }
        String ip = jObj.getString("ip");
        JSONObject message = JSON.parseObject(jObj.getString("message").trim());
        String requestId = message.getString("requestId");
        if (requestId != null) {
            requestId = requestId.trim();
        }
        String waybillNo = message.getString("waybillNo");
        if (waybillNo != null) {
            waybillNo = waybillNo.trim();
        }
        String chkDisLogType = message.getString("chkDisLogType").trim();
        JSONObject chkDisLogObj = null;
        JSONArray chkDisLogArray = null;
        String chkDisLogMsg = null;
        if (message.containsKey("chkDisLogArray")) {
            JSONArray tmpArray = message.getJSONArray("chkDisLogArray");
            if (tmpArray != null && tmpArray.size() != 0) {
                chkDisLogArray = new JSONArray();
                for (int i = 0; i < tmpArray.size(); i++) {
                    chkDisLogArray.add(JSON.parseObject(tmpArray.getString(i).trim()));
                }
            }
        } else if (message.containsKey("chkDisLogMsg")) {
            chkDisLogMsg = message.getString("chkDisLogMsg").trim();
        } else {
            chkDisLogObj = message;
        }
        o.put("waybillNo", waybillNo);
        o.put("requestId", requestId);
        o.put("createTime", createTime);
        o.put("ip", ip);
        o.put("chkDisLogType", chkDisLogType);
        o.put("chkDisLogMsg", chkDisLogMsg);
        o.put("chkDisLogObj", chkDisLogObj);
        o.put("chkDisLogArray", chkDisLogArray);
        return o;
    }


    public static boolean filter(String line) {
        if (StringUtils.isNotEmpty(line)) {
            boolean b1 = line.contains("=>receive oms waybill message");
            boolean b2 = line.contains("=>kafka topic GIS_ASS_CORE_DEPT_TO_OMS");
            boolean b3 = line.contains("ATPai->");
            boolean b4 = line.contains("=>kafka topic GIS_ASS_RDS_CHK,message:");
            boolean b5 = line.contains("=>ksMsg:");
            boolean b6 = line.contains("kafka topic GIS_ASS_RDS_CHK_DISPATCH_TO_ARSS,message:");
            boolean b7 = line.contains("kafka topic GIS_ASS_RDS_CHKDEST_TO_ARSS,message:");
            boolean b8 = line.contains("=>receive waybill dept chk message");
            boolean b9 = line.contains("kafka topic GIS_ASS_RDS_TO_AWSM");
            boolean b10 = line.contains("=>receive awsm message");
            boolean b11 = line.contains("=>receive sss addr chk message");
            boolean b12 = line.contains("=>kafka topic GIS_ASS_RDS_AOI_TO_AWSM");
            boolean b13 = line.contains("=>chkAoiMsg:");
//            TODO
//            boolean b14 = line.contains("SSS取数据的request param——response result");
            boolean b15 = line.contains("receive arss addr chk message");
            boolean b16 = line.contains("AddressUnkowCheck:");

            return b1 || b2 || b3 || b4 || b5 || b6 || b7 || b8 || b9 || b10 || b11 || b12 || b13 || b15 || b16;
        }
        return false;
    }
}
