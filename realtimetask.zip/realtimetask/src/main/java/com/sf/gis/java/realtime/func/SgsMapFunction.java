package com.sf.gis.java.realtime.func;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.realtime.pojo.SgsKafkaData;
import com.sf.gis.java.realtime.pojo.SgsKafkaOriginData;

import com.sf.gis.java.realtime.utils.DateUtil;
import org.apache.flink.api.common.functions.RichMapFunction;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SgsMapFunction extends RichMapFunction<String, String> {
    List<String> validPickUpTypeArray = Arrays.asList(new String[]{"3", "6", "11", "20", "21", "23", "10", "18"});

    private String mapData(String t) throws ParseException {

        SgsKafkaOriginData origin = JSON.parseObject(t, SgsKafkaOriginData.class);
        SgsKafkaData ret = new SgsKafkaData();
        ret.update(origin);
        String time = DateUtil.longToTime(new Date().getTime(), "yyyy-MM-dd HH:mm:ss");
        if (!validPickUpTypeArray.contains(ret.getPickupType())) {
            return null;
        } else {
            String inc_day = time.substring(0, 10).replaceAll("-", "");
            ret.setIsUnderCall("1");
            ret.setOrderType("2");
            ret.setKafkaTime(time);
            ret.setInsert_hive_time(time.replaceAll("-", ""));
            Pattern p = Pattern.compile("\\d+");
            Matcher m = p.matcher(ret.getLocationCode());
            if (m.find()) {
                ret.setLocationCode(m.group());
            }

        }
        return JSON.toJSONString(ret);
    }

    @Override
    public String map(String o) throws Exception {

        if (o == null) {
            return null;
        }
        String ret = null;
        try {
            ret = mapData(o.toString());
        } catch (Exception e) {

        }
        return ret;
    }
}
