package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * chk shou日志
 */
public class ChkShouKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(ChkShouKakfa2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("chkshoukafka2hive.properties", ChkShouKakfa2Hive.class.getName());
    }

}
