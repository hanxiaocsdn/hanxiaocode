package com.sf.gis.java.realtime.func;

import org.apache.flink.api.common.functions.RichFilterFunction;

import java.util.Arrays;
import java.util.List;

public class FnsLogFilterFunction extends RichFilterFunction<String> {
    private  static final List<String> useList = Arrays.asList(
            "receive fns waybill message",
            "GIS_RDS_CHK_DISP_TO_FNS",
            "ATPai->",
            "RDS-CHK-DIS-FNS",
            "GIS_RDS_CHK_DISP_FNS_TO_KS",
            "=>ksMsg:",
            "GIS_RDS_CHK_DISP_FNS_TO_ARSS",
            "=>receive waybill dept chk message",
            "GIS_RDS_CHK_DISP_FNS_TO_CGCS",
            "=>chkAoiMsg:",
            "=>link to gid:",
            "AddressUnkowCheck:");
    @Override
    public boolean filter(String o) throws Exception {
        if(o == null || o.isEmpty()){
            return false;
        }
        for (String item : useList) {
            if ( o.contains(item) ){
                return true;
            }
        }
        return false;
    }

}
