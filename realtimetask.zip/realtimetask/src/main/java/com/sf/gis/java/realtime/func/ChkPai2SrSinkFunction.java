package com.sf.gis.java.realtime.func;

import com.sf.gis.java.realtime.pojo.ChkPaiIndexMonitor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ChkPai2SrSinkFunction extends RichSinkFunction<ChkPaiIndexMonitor> {
    private static final long serialVersionUID = 1L;
    private transient Connection connection;
    private transient PreparedStatement preparedStatement;

    // 定义StarRocks JDBC连接配置参数
    private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
    private static final String JDBC_URL = "jdbc:mysql://10.216.162.10:9030/gis_oms_uimp_rds";
    private static final String USER = "gis_oms_rds";
    private static final String PASSWORD = "gis_oms_rds@123@";
    private static final String table = "gis_add_rds_zone_resp_cnt_real_time_monitor";
    private List<ChkPaiIndexMonitor> batch = new ArrayList<>();
    private int batchSize = 100;

    @Override
    public void open(Configuration parameters) throws Exception {
        // 创建StarRocks连接并配置相应的连接信息
//        Class.forName("com.starrocks.jdbc.Driver");
//        connection = DriverManager.getConnection("jdbc:starrocks://10.216.162.10:9030/gis_oms_uimp_rds", "gis_oms_rds", "gis_oms_rds@123@");
        Class.forName(DRIVER_CLASS);
        connection = DriverManager.getConnection(JDBC_URL, USER, PASSWORD);
        connection.setAutoCommit(false);
        preparedStatement = connection.prepareStatement("insert into gis_add_rds_zone_resp_cnt_real_time_monitor (inc_day,dept_code,city_code,resp_cnt,log_create_time) values (?,?,?,?,?)");
//        stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
//        Class.forName("ru.yandex.clickhouse.ClickHouseDriver");
//        connection = DriverManager.getConnection("jdbc:clickhouse://host:port/database", "", "");
//        preparedStatement = connection.prepareStatement("insert into table values(?)");
    }

    @Override
    public void invoke(ChkPaiIndexMonitor value, Context context) throws Exception {
        batch.add(value);
        if (batch.size() >= batchSize) {
            executeBatch();
        }

//        String table = "gis_add_rds_zone_resp_cnt_real_time_monitor";
//        String insertSql = String.format("insert into %s (inc_day,dept_code,city_code,resp_cnt,log_create_time) values('%s','%s','%s',%s,'%s')", table, o.getInc_day(), o.getDeptcode(), o.getCitycode(), o.getCnt(), o.getLog_create_time());
//        stmt.execute(insertSql);
//        String selectSql = String.format("select log_create_time from %s where inc_day = '%s' and log_create_time = '%s' and dept_code = '%s'", table, o.getInc_day(), o.getLog_create_time(), o.getDeptcode());
//        String updateSql = String.format("update %s set resp_cnt = %s where inc_day = '%s' and log_create_time = '%s' and dept_code = '%s'", table, o.getCnt(), o.getInc_day(), o.getLog_create_time(), o.getDeptcode());
//        ResultSet resultSet = stmt.executeQuery(selectSql);
//        if (resultSet.first()) {
//            stmt.executeUpdate(updateSql);
//        } else {
//        }
    }

    @Override
    public void close() throws Exception {
        if (!batch.isEmpty()) {
            executeBatch();
        }

        if (preparedStatement != null) {
            preparedStatement.close();
        }
        if (connection != null) {
            connection.close();
        }
    }

    public void executeBatch() throws SQLException {
        for (ChkPaiIndexMonitor o : batch) {
            preparedStatement.setString(1, o.getInc_day());
            preparedStatement.setString(2, o.getDeptcode());
            preparedStatement.setString(3, o.getCitycode());
            preparedStatement.setInt(4, o.getCnt());
            preparedStatement.setString(5, o.getLog_create_time());
            preparedStatement.addBatch();
        }
        preparedStatement.executeBatch();
        connection.commit(); // 提交事务
        batch.clear();
    }

}
