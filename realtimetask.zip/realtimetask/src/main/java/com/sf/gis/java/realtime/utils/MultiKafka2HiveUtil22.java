package com.sf.gis.java.realtime.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.VMSTrackDeserializationSchema;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 多kafka数据合并后落地到hdfs
 *
 * @author 01370539 Created On May.17 2021
 */
public class MultiKafka2HiveUtil22 {
    private static final Logger logger = LoggerFactory.getLogger(MultiKafka2HiveUtil22.class);

    // 并行度
    private static int srcParallelism = 5;
    private static int sinkParallelism = 5;

    public static void process1(ArrayList<String> propertiesName,String appName) throws Exception {
        // 获取配置文件名称
        String fileName = propertiesName.get(0);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName);

        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");

        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> gisDataStream = initKafakaSource(env,confInfo1,zipType1);

            // sink
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(gisDataStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(appName);
        }
    }

    public static void process2(ArrayList<String> propertiesName,String appName) throws Exception {
        // 获取配置文件名称
        String fileName1 = propertiesName.get(0);
        String fileName2 = propertiesName.get(1);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName1);
        Properties confInfo2 = ConfigUtil.loadPropertiesConfiguration(fileName2);
        // 获取topic
        String topic1 = confInfo1.getProperty("kafka.topic");
        String topic2 = confInfo2.getProperty("kafka.topic");
        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");
        String zipType2 = confInfo2.getProperty("kafka.data.packed.format","");

        // 并行度以confInfo1的配置为准
        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);
        properties.add(confInfo2);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");

            // 获取第一个source数据
            DataStream<String> gisDataStream1 = initKafakaSource(env,confInfo1,zipType1);
            // 获取第二个source数据
            DataStream<String> gisDataStream2 = initKafakaSource(env,confInfo2,zipType2);
            // 将两个source数据合并
            DataStream<String> processStream = connectDataStream(gisDataStream1,gisDataStream2,topic1,topic2);

            // sink 以confInfo1的配置为准
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(processStream, outputPath, sinkParallelism);

            // 开启计算
            env.execute(appName);
        }
    }

    public static void process3(ArrayList<String> propertiesName,String appName) throws Exception {
        // 获取配置文件名称
        String fileName1 = propertiesName.get(0);
        String fileName2 = propertiesName.get(1);
        String fileName3 = propertiesName.get(2);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName1);
        Properties confInfo2 = ConfigUtil.loadPropertiesConfiguration(fileName2);
        Properties confInfo3 = ConfigUtil.loadPropertiesConfiguration(fileName3);

        // 获取topic
        String topic1 = confInfo1.getProperty("kafka.topic");
        String topic2 = confInfo2.getProperty("kafka.topic");
        String topic3 = confInfo3.getProperty("kafka.topic");
        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");
        String zipType2 = confInfo2.getProperty("kafka.data.packed.format","");
        String zipType3 = confInfo3.getProperty("kafka.data.packed.format","");

        // 并行度以confInfo1的配置为准
        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);
        properties.add(confInfo2);
        properties.add(confInfo3);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");

            // 获取第一个source数据
            DataStream<String> gisDataStream1 = initKafakaSource(env,confInfo1,zipType1);
            // 获取第二个source数据
            DataStream<String> gisDataStream2 = initKafakaSource(env,confInfo2,zipType2);
            // 获取第三个source数据
            DataStream<String> gisDataStream3 = initKafakaSource(env,confInfo3,zipType3);

            // 将两个source数据合并
            DataStream<String> processStream1 = connectDataStream(gisDataStream1,gisDataStream2,topic1,topic2);

            // 将两个source数据合并
            DataStream<String> processStream = connectDataStream(processStream1,gisDataStream3,null,topic3);

            // sink 以confInfo1的配置为准
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(processStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(appName);
        }
    }

    public static void process4(ArrayList<String> propertiesName,String appName) throws Exception {
        // 获取配置文件名称
        String fileName1 = propertiesName.get(0);
        String fileName2 = propertiesName.get(1);
        String fileName3 = propertiesName.get(2);
        String fileName4 = propertiesName.get(3);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName1);
        Properties confInfo2 = ConfigUtil.loadPropertiesConfiguration(fileName2);
        Properties confInfo3 = ConfigUtil.loadPropertiesConfiguration(fileName3);
        Properties confInfo4 = ConfigUtil.loadPropertiesConfiguration(fileName4);
        // 获取topic
        String topic1 = confInfo1.getProperty("kafka.topic");
        String topic2 = confInfo2.getProperty("kafka.topic");
        String topic3 = confInfo3.getProperty("kafka.topic");
        String topic4 = confInfo4.getProperty("kafka.topic");
        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");
        String zipType2 = confInfo2.getProperty("kafka.data.packed.format","");
        String zipType3 = confInfo3.getProperty("kafka.data.packed.format","");
        String zipType4 = confInfo4.getProperty("kafka.data.packed.format","");

        // 并行度以confInfo1的配置为准
        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);
        properties.add(confInfo2);
        properties.add(confInfo3);
        properties.add(confInfo4);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");

            // 获取第一个source数据
            DataStream<String> gisDataStream1 = initKafakaSource(env,confInfo1,zipType1);
            // 获取第二个source数据
            DataStream<String> gisDataStream2 = initKafakaSource(env,confInfo2,zipType2);
            // 获取第三个source数据
            DataStream<String> gisDataStream3 = initKafakaSource(env,confInfo3,zipType3);
            // 获取第四个source数据
            DataStream<String> gisDataStream4 = initKafakaSource(env,confInfo4,zipType4);

            // 将两个source数据合并
            DataStream<String> processStream1 = connectDataStream(gisDataStream1,gisDataStream2,topic1,topic2);

            // 将两个source数据合并
            DataStream<String> processStream2 = connectDataStream(gisDataStream3,gisDataStream4,topic3,topic4);

            // 将两个source数据合并
            DataStream<String> processStream = connectDataStream(processStream1,processStream2,null,null);

            // sink 以confInfo1的配置为准
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(processStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(appName);
        }
    }

    public static boolean isConfAvailable(ArrayList<Properties> properties) {
        boolean result = true;

        for(Properties confInfo: properties) {
            if (StringUtils.isEmpty(confInfo.getProperty("kafka.bootstrap.servers"))) {
                result = false;
                logger.error("parameter {} is null.", confInfo.getProperty("kafka.bootstrap.servers"));
                break;
            }
            if (StringUtils.isEmpty(confInfo.getProperty("kafka.topic"))) {
                result = false;
                logger.error("parameter {} is null.", confInfo.getProperty("kafka.topic"));
                break;
            }
            if (StringUtils.isEmpty(confInfo.getProperty("hive.table.name"))) {
                result = false;
                logger.error("parameter {} is null.", confInfo.getProperty("hive.table.name"));
                break;
            }
        }

        return result;
    }

    public static SingleOutputStreamOperator<String> connectDataStream(DataStream<String> gisDataStream1, DataStream<String> gisDataStream2, String topic1, String topic2) {

        SingleOutputStreamOperator<String> processStream = gisDataStream1.connect(gisDataStream2).process(new CoProcessFunction<String, String, String>() {
            @Override
            public void processElement1(String s, Context context, Collector<String> collector) throws Exception {

                JSONObject jsonObject1 = new JSONObject();
                try {
                    jsonObject1 = JSON.parseObject(s);
                } catch (Exception e) {
                    logger.error("数据转换json异常 error. ", e);
                }
                if(!StringUtils.isEmpty(topic1)){
                    jsonObject1.put("topic", topic1);
                }

                collector.collect(JSON.toJSONString(jsonObject1));
            }

            @Override
            public void processElement2(String s, Context context, Collector<String> collector) throws Exception {

                JSONObject jsonObject2 = new JSONObject();
                try {
                    jsonObject2 = JSON.parseObject(s);
                } catch (Exception e) {
                    logger.error("数据转换json异常 error. ", e);
                }
                if(!StringUtils.isEmpty(topic2)){
                    jsonObject2.put("topic", topic2);
                }

                collector.collect(JSON.toJSONString(jsonObject2));
            }
        });

        return processStream;
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env,Properties confInfo,String zipType) {
        String topic = confInfo.getProperty("kafka.topic");
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("offsetReset:"+offsetReset);
        KafkaSource<String> source = null;
        if(zipType.equals("gzip")){
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setValueOnlyDeserializer(new VMSTrackDeserializationSchema())
                    .build();
        }else{
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setValueOnlyDeserializer(new SimpleStringSchema())
                    .build();
        }

        Map<String, Boolean> isPrintMap = new HashMap<>();
        isPrintMap.put("isPrint", true);

        String[] keyList = StringUtils.isEmpty(confInfo.getProperty("kafka.data.keys")) ? new String[]{} : confInfo.getProperty("kafka.data.keys").split(",");
        return env.fromSource(source, WatermarkStrategy.noWatermarks(), topic).name(topic).uid(topic).setParallelism(srcParallelism).filter((FilterFunction<String>) line -> {
            if (keyList.length == 0) {
                if (isPrintMap.get("isPrint")) {
                    logger.error("log => " + line);
                    isPrintMap.put("isPrint", false);
                }
                return true;
            } else {
                for (String item : keyList) {
                    if (line != null && line.contains(item)) {
                        if (isPrintMap.get("isPrint")) {
                            logger.error("log => " + line);
                            isPrintMap.put("isPrint", false);
                        }
                        return true;
                    }
                }
                return false;
            }
        }).setParallelism(srcParallelism);
    }

//    // 获取kafka配置信息
//    public static Properties getProperties() {
//        Properties properties = new Properties();
//        properties.setProperty("bootstrap.servers", confInfo.getProperty("kafka.bootstrap.servers"));
//        properties.setProperty("group.id", confInfo.getProperty("hive.table.name"));
//        properties.setProperty("max.poll.interval.ms", String.valueOf(10 * 60 * 1000));
//        String offsetReset = confInfo.getProperty("auto.offset.reset");
//        logger.error("log => auto.offset.reset:" + offsetReset);
//        if ("earliest".equals(offsetReset)) {
//            properties.put("auto.offset.reset", "earliest");
//        } else {
//            properties.put("auto.offset.reset", "latest");
//        }
//
//        return properties;
//    }
}
