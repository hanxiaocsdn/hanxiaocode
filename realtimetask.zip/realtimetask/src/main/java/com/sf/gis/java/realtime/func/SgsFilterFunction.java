package com.sf.gis.java.realtime.func;

import org.apache.flink.api.common.functions.RichFilterFunction;

public class SgsFilterFunction extends RichFilterFunction<String> {
    @Override
    public boolean filter(String o) throws Exception {
        if(o == null){
            return false;
        }
        return true;
    }

}
