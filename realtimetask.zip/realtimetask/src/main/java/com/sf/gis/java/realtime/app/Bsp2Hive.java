package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BSP地址解析生产日志存表入库(01381101)
 * 开发：01417629
 * 任务id:30002569
 */
public class Bsp2Hive {
    public static Logger logger = LoggerFactory.getLogger(Bsp2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("bsp2Hive.properties", Bsp2Hive.class.getName());
    }

}
