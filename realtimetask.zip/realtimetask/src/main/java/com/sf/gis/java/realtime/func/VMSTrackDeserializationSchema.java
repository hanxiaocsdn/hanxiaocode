package com.sf.gis.java.realtime.func;

import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.TypeExtractor;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;

public class VMSTrackDeserializationSchema implements DeserializationSchema<String> {
    public String deserialize(byte[] bytes) throws IOException {
        // 注意: 函数 byte[] 类型的参数名为 bytes
        return uncompressToString(bytes, "utf-8");
    }

    public boolean isEndOfStream(String t) {
        return false;
    }

    public TypeInformation<String> getProducedType() {
        return TypeExtractor.getForClass(String.class);
    }

    /*
     *解压缩
     */
    public static String uncompressToString(byte[] bytes, String encoding) {
//        System.out.println("进来");
//        try{
//            System.out.println("ddd:"+new String(bytes));
//        }catch (Exception e){
//            e.printStackTrace();
//            System.out.println(e);
//        }
        if (bytes == null || bytes.length == 0) {
            System.out.println("empty");
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        try {
            GZIPInputStream ungzip = new GZIPInputStream(in);
            byte[] buffer = new byte[256];
            int n;
            while ((n = ungzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
//            System.out.println("数据:"+out.toString(encoding));
            return out.toString(encoding);
        } catch (IOException e) {
//            e.printStackTrace();
            System.out.println(e);
        }
        return null;
    }
}
