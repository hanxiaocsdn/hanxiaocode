package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * chk pai日志
 */
public class ChkPaiKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(ChkPaiKakfa2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("chkpaikafka2hive.properties", ChkPaiKakfa2Hive.class.getName());
    }

}
