package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * chk query日志
 */
public class ChkQueryKakfa2Hive {
    public static Logger logger = LoggerFactory.getLogger(ChkQueryKakfa2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("chkquerykafka2hive.properties", ChkQueryKakfa2Hive.class.getName());
    }

}
