package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CollectWifiBTDataKafka2Hive {
    public static Logger logger = LoggerFactory.getLogger(CollectWifiBTDataKafka2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("collectwifibtdatakafka2hive.properties", CollectWifiBTDataKafka2Hive.class.getName());
    }


}
