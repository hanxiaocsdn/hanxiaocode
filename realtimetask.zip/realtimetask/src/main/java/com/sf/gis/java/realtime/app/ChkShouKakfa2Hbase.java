package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.realtime.func.ChkShou2HbaseSinkFunction;
import com.sf.gis.java.realtime.pojo.constant.VariableConstant;
import com.sf.gis.java.realtime.utils.CommonUtil;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * 需求：收件日志实时入hbase
 * 需求方：李莹（01425237）
 * 研发：匡仁衡（01399581）
 * 任务id：30000336（flink）
 */

public class ChkShouKakfa2Hbase {
    public static Logger logger = LoggerFactory.getLogger(ChkShouKakfa2Hbase.class);

    private static Properties confInfo = null;
    // 并行度
    private static int srcParallelism = 8;
    private static int sinkParallelism = 8;

    private static Map<String, String> bodyKeyMap = new HashMap<String, String>() {{
        put("rds_true_req", VariableConstant.SYNC_REQ_BODY_KEY);
        put("rds_true_re", VariableConstant.SYNC_RE_BODY_KEY);
        put("rds_false_req", VariableConstant.ASYNC_REQ_BODY_KEY);
        put("rds_false_re", VariableConstant.ASYNC_RE_BODY_KEY);
        put("rds_false_arss_req", VariableConstant.RDS_ARSS_REQ_BODY_KEY);
        put("arss__arss_re", VariableConstant.ARSS_RE_BODY_KEY);
        put("rds_false_ks_resp", VariableConstant.KS_RE_BODY_KEY);
        put("rds_false_ks_req", VariableConstant.KS_REQ_BODY_KEY);
        put("building_true_re", VariableConstant.BUILDING_BODY_KEY);
    }};

    private static HashMap<String, String> sysOrderNoKeyMap = new HashMap<String, String>() {{
        put("rds_true_req", VariableConstant.SYNC_REQ_SYS_ORDERNO_KEY);
        put("rds_true_re", VariableConstant.SYNC_REQ_SYS_ORDERNO_KEY);
        put("rds_false_req", VariableConstant.ASYNC_REQ_SYS_ORDERNO_KEY);
        put("rds_false_re", VariableConstant.ASYNC_RE_SYS_ORDERNO_KEY);
        put("rds_false_arss_req", VariableConstant.RDS_ARSS_REQ_SYS_ORDERNO_KEY);
        put("rds_false_ks_req", VariableConstant.RDS_ARSS_REQ_SYS_ORDERNO_KEY);
    }};


    public static void main(String[] args) throws Exception {
        // 加载配置信息
        confInfo = ConfigUtil.loadPropertiesConfiguration("chkshoukafka2hbase.properties");
        if (!StringUtils.isEmpty(confInfo.getProperty("src.parallelism"))) {
            srcParallelism = Integer.parseInt(confInfo.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.parseInt(confInfo.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);
        if (CommonUtil.isConfAvailable(confInfo)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> dataStream = initKafakaSource(env, confInfo);

            logger.error("--------------启动sink-------------------------");
            // sink
            dataStream.addSink(new ChkShou2HbaseSinkFunction()).setParallelism(sinkParallelism);

            // 开启计算
            env.execute(ChkShouKakfa2Hbase.class.getName());
        }
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo) {
        String topic = confInfo.getProperty("kafka.topic");
        FlinkKafkaConsumer<String> gisDataKafkaConsumer = new FlinkKafkaConsumer<>(topic, new SimpleStringSchema(), CommonUtil.getProperties(confInfo));
        gisDataKafkaConsumer.setStartFromGroupOffsets();

        return env.addSource(gisDataKafkaConsumer).name(topic).uid(topic).setParallelism(srcParallelism)
                .filter(ChkShouKakfa2Hbase::filter).setParallelism(srcParallelism).map(ChkShouKakfa2Hbase::parse).setParallelism(srcParallelism);
    }

    public static String parse(String line) {
        JSONObject totalObj = JSONUtil.parseStr2Json(line);
        if (totalObj == null) {
            return "";
        } else if ("arss_re".equals(totalObj.getString("dataType")) && "arss".equals(totalObj.getString("type"))) {
            String _type = JSONUtil.getJsonVal(totalObj, "type", "");
            String syn = "";
            String dataType = JSONUtil.getJsonVal(totalObj, "dataType", "");
            String keyStr = String.format("%s_%s_%s", _type, syn, dataType);
//            String bodyKey = bodyKeyMap.get(keyStr);
//            String reqId = JSONUtil.getJsonVal(totalObj, "requestId", "");
            String sysOrderNo = JSONUtil.getJsonVal(totalObj, "data.sysOrderNo", null);
            JSONObject rslt = new JSONObject();
            String log_type = "arssReBody";
            rslt.put("sysOrderNo", sysOrderNo);
            rslt.put("log_type", log_type);
            rslt.put(log_type, totalObj);
            return rslt.toJSONString();
        } else {
            JSONObject message = totalObj.getJSONObject("message");
            String reqId = JSONUtil.getJsonVal(message, "requestId", "");
            String _type = JSONUtil.getJsonVal(message, "type", "");
            String syn = JSONUtil.getJsonVal(message, "syn", "");
            String dataType = JSONUtil.getJsonVal(message, "dataType", "");
            if (StringUtils.isEmpty(dataType)) {
                return "";
            }
            String keyStr = String.format("%s_%s_%s", _type, syn, dataType);
            String bodyKey = bodyKeyMap.get(keyStr);
            if (VariableConstant.KS_RE_BODY_KEY.equals(bodyKey)) {
                return ksToChkReParser(JSONUtil.getJsonVal(message, "ksStr", ""));
            }
            if (VariableConstant.KS_REQ_BODY_KEY.equals(bodyKey)) {
                return chkToKsReqParser(message.toJSONString());
            }
            if (VariableConstant.BUILDING_BODY_KEY.equals(bodyKey)) {
                return buildIngParser(message);
            }
            if ("rds_false_re".equals(keyStr) && ("10".equals(message.getString("status")) || "9".equals(message.getString("status"))) && message.getJSONObject("prodOmsInfo") != null) {
                JSONObject prodOmsInfo = message.getJSONObject("prodOmsInfo");
                String sysOrderNo = prodOmsInfo.getString("sysOrderNo");
                JSONObject rslt = new JSONObject();
                String log_type = "chkOmsRebody";
                rslt.put(log_type, prodOmsInfo);
                rslt.put("sysOrderNo", sysOrderNo);
                rslt.put("log_type", log_type);
                return rslt.toJSONString();
            }
            String sysOrderNoKey = sysOrderNoKeyMap.get(keyStr);
            if (VariableConstant.SYNC_REQ_BODY_KEY.equals(bodyKey) || VariableConstant.ASYNC_REQ_BODY_KEY.equals(bodyKey)) //获取第一条请求
                fetchBody(message, VariableConstant.ORDERINFO_LIST_KEY);

            if (VariableConstant.SYNC_RE_BODY_KEY.equals(bodyKey) || VariableConstant.ASYNC_RE_BODY_KEY.equals(bodyKey)) {
                fetchBody(message, VariableConstant.TCS_KEY);
                str2Json(message, VariableConstant.CHKRESULT_KEY);
            }

            JSONObject newObj = new JSONObject();
            newObj.put("log_type", bodyKey);
            newObj.put(bodyKey, message);
            if (sysOrderNoKey != null) { //有系统订单号
                String sysNo = JSONUtil.getJsonVal(message, sysOrderNoKey, "");
                newObj.put(VariableConstant.SYS_ORDERNO_KEY, sysNo);
                String orderKey = sysOrderNoKey.replace("sysOrderNo", "orderNo");
                String orderNo = (String) JSONUtil.getItem(message, orderKey, "");
                newObj.put(VariableConstant.ORDERNO_KEY, orderNo);
            }
            return newObj.toJSONString();
        }
    }

    public static void str2Json(JSONObject obj, String keys) {
        String[] keyArr = keys.split("\\.");
        Map<String, JSONObject> objMap = new HashMap<>();
        JSONObject tempObj = obj;

        for (int i = 0; i < keyArr.length; i++) {
            if (tempObj == null || !tempObj.containsKey(keyArr[i])) {
                break;
            }
            if (i < keyArr.length - 1) {
                tempObj = tempObj.getJSONObject(keyArr[i]);
            } else {
                tempObj = JSON.parseObject(tempObj.getString(keyArr[i]));
            }
            objMap.put(keyArr[i], tempObj);
        }
        for (int i = keyArr.length - 2; i >= 0; i--) {
            if (!objMap.containsKey(keyArr[i])) {
                break;
            }
            objMap.get(keyArr[i]).put(keyArr[i + 1], objMap.get(keyArr[i + 1]));
        }
        if (objMap.containsKey(keyArr[0])) {
            obj.put(keyArr[0], objMap.get(keyArr[0]));
        }
    }

    public static void fetchBody(JSONObject obj, String keys) {
        String[] keyArr = keys.split("\\.");
        Map<String, JSONObject> objMap = new HashMap<>();
        JSONObject tempObj = obj;

        for (int i = 0; i < keyArr.length; i++) {
            if (tempObj == null || !tempObj.containsKey(keyArr[i])) {
                break;
            }
            if (i < keyArr.length - 1) {
                tempObj = tempObj.getJSONObject(keyArr[i]);
            } else {
                tempObj = tempObj.getJSONArray(keyArr[i]).getJSONObject(0);
            }
            objMap.put(keyArr[i], tempObj);
        }

        for (int i = keyArr.length - 2; i >= 0; i--) {
            if (!objMap.containsKey(keyArr[i])) {
                break;
            }
            objMap.get(keyArr[i]).put(keyArr[i + 1], objMap.get(keyArr[i + 1]));
        }
        if (objMap.containsKey(keyArr[0])) {
            obj.put(keyArr[0], objMap.get(keyArr[0]));
        }
    }

    public static String buildIngParser(JSONObject message) {
        JSONObject rslt = new JSONObject();
        rslt.put("requestBuildingBody", JSON.parseObject(message.getString("requestBuilding")));
        rslt.put("responseBuildingBody", JSON.parseObject(message.getString("responseBuilding")));
        String sysOrderNo = JSONUtil.getJsonVal(message, "sysOrderNo", null);

        String log_type = "requestBuildingBody_responseBuildingBody";
        rslt.put("sysOrderNo", sysOrderNo);
        rslt.put("log_type", log_type);
        return rslt.toJSONString();
    }

    public static String chkToKsReqParser(String line) {
        JSONObject obj = JSONUtil.parseStr2Json(line);
        JSONObject rslt = new JSONObject();
        String requestId = obj.getString("requestId");
        String sysOrderNo = JSONUtil.getJsonVal(obj, "prodOmsInfo.sysOrderNo", "");
        obj.remove("orderInfo");
        obj.remove("producerArssInfo");

        String log_type = "chkKsReqBody";
        rslt.put("sysOrderNo", sysOrderNo);
        rslt.put("log_type", log_type);
        rslt.put(log_type, obj);
        return rslt.toJSONString();
    }

    public static String ksToChkReParser(String line) {
        JSONObject obj = JSONUtil.parseStr2Json(line);
        JSONObject result = obj.getJSONObject("result");
        String sysOrderNo = "";
        if (result != null) {
            JSONObject attachment = JSONUtil.parseStr2Json(JSONUtil.getJsonVal(result, "attachment", ""));
            sysOrderNo = JSONUtil.getJsonVal(attachment, "producerOmsInfo.sysOrderNo", "");
            String requestId = JSONUtil.getJsonVal(attachment, "producerArssInfo.requestId", "");
            result.remove("attachment");
            result.put("requestId", requestId);
            obj.put("result", result);
        }
        JSONObject rslt = new JSONObject();
        String log_type = "chkKsReBody";
        rslt.put("sysOrderNo", sysOrderNo);
        rslt.put("log_type", log_type);
        rslt.put(log_type, obj);
        return rslt.toJSONString();
    }

    public static boolean filter(String line) {
        if (StringUtils.isNotEmpty(line)) {
            return line.contains("dataType");
        }
        return false;
    }
}
