package com.sf.gis.java.realtime.app;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.FlinkUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.realtime.func.VMSTrackDeserializationSchema;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.sf.gis.java.base.util.HttpInvokeUtil.sendPostByParam;
import static com.sf.gis.java.realtime.utils.MultiKafka2HiveUtil22.connectDataStream;
import static com.sf.gis.java.realtime.utils.MultiKafka2HiveUtil22.isConfAvailable;


/**
 * GIS-RSS-ETA：【时效专项】 导航app司机上报数据（同步至丰声）
 * 需求方：童姚（01432466）
 * @author 徐游飞（01417347）
 * 任务ID：30002352 (实时任务)
 */

public class NavigationDriverData2FengSheng {
    public static Logger logger = LoggerFactory.getLogger(NavigationDriverData2FengSheng.class);
    public static String appName = NavigationDriverData2FengSheng.class.getName();
    // 并行度
    private static int srcParallelism = 5;
    private static int sinkParallelism = 5;
    private static String update_url  = "http://rttquery.sense-map.cn:80/tmc_event_test/manual_edit/upload_manual_event_auth?ak=&link_id=%s&adcode=%s&start_time=%s&end_time=%s";
    private static String download_url  = "https://gis.sf-express.com/appnavi/upload/downloadImg?ak=%s&fileName=%s";
    private static String roadAttr_url  = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/roadAttr?gzip=0&output=json&mask=31&ak=dc894b4a3c7444b4a3505315d00b87ad&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED&swId=%s";
    private static String send_url = "https://open-api-funsionwork.sf-express.com/ump-biz/platform/send";
    private static String token_all = "eyJhbGciOiJSUzI1NiIsImtpZCI6ImsxIiwidHlwIjoiSldUIn0.eyJjaWQiOiI1MTY4NTBjNThmNjI0M2NjYWEzOWI1OWE5OGFlNjJjMyIsImV4cCI6MTcwNDM3MzY4ODA1NCwiaWF0IjoxNzAzNzY4ODg4MDU0LCJpc3MiOiI1MTY4NTBjNThmNjI0M2NjYWEzOWI1OWE5OGFlNjJjMyIsImp0aSI6ImZjZWZlOTZmLTQ1YjgtNDJlOC1iNWYwLTIzNzBmN2E0NjM4ZiIsInN1YiI6IjEwMDE6NTE2ODUwYzU4ZjYyNDNjY2FhMzliNTlhOThhZTYyYzMiLCJ0aWQiOiIxMDAxIn0.r4MaQsXo-hAACdAmQP5ru8aXhuZIlaeA1e_Uifof7KloRvzdcUuSqDXjbDiG4xDGpPGjP7ljF-JNbS7tdg-oGomZ5jFY8Vuz4jZJfwciIpOzcmT5--NqnaSjA5E3vkMwoBouwJbLvhz7eL_QHLbPaoOzZpr46VeLVrA4u9WPHoc";
    private static Map<String, Long> processedIds = new HashMap<>(); // 存储已处理过的事件唯一标识和时间戳的映射关系
    private static long lastCleanTime = 1704211200000L; // 上次清理时间


    public static void main(String[] args) throws Exception {

        String toNums = "01417347";
        ArrayList<String> properties = new ArrayList<>();
        properties.add("navigationdriverdata2fengsheng.properties");   //童姚

        // 推送消息接受列表 工号用;分格
        try{
            ParameterTool parameterTool = ParameterTool.fromSystemProperties().mergeWith(ParameterTool.fromArgs(args));
            toNums = parameterTool.get("toNums");
            logger.error("log toNums:" + toNums);
        }
        catch(Exception e){
            e.printStackTrace();
        }

        // 消费1个kafka数据
        process(properties, appName,toNums);

    }

    public static void process(ArrayList<String> propertiesName,String appName,String toNums) throws Exception {
        // 获取配置文件名称
        String fileName = propertiesName.get(0);
        // 加载配置信息
        Properties confInfo1 = ConfigUtil.loadPropertiesConfiguration(fileName);

        // 获取kafka数据压缩格式
        String zipType1 = confInfo1.getProperty("kafka.data.packed.format","");

        if (!StringUtils.isEmpty(confInfo1.getProperty("src.parallelism"))) {
            srcParallelism = Integer.valueOf(confInfo1.getProperty("src.parallelism"));
        }
        if (!StringUtils.isEmpty(confInfo1.getProperty("sink.parallelism"))) {
            sinkParallelism = Integer.valueOf(confInfo1.getProperty("sink.parallelism"));
        }
        logger.error("srcParallelism:" + srcParallelism + ",sinkParallelism:" + sinkParallelism);

        ArrayList<Properties> properties = new ArrayList<>();
        properties.add(confInfo1);

        if (isConfAvailable(properties)) {
            StreamExecutionEnvironment env = FlinkUtil.getExecutionEnv();

            logger.error("--------------启动source-------------------------");
            // source
            DataStream<String> naviDataStream = initKafakaSource(env,confInfo1,zipType1);

            // 数据处理
            DataStream<String> sendDataStream = getSendDataStream(naviDataStream,toNums);

            // 将原始数据和处理后的数据合并
            DataStream<String> processStream = connectDataStream(naviDataStream,sendDataStream,"原始数据","已推送数据");

            // sink
            String outputPath = "hdfs://sfbd/user/hive/warehouse/dm_gis.db/" + confInfo1.getProperty("hive.table.name");
            FlinkUtil.initHdfsSink(processStream, outputPath, sinkParallelism);
            // 开启计算
            env.execute(appName);
        }
    }
    private static DataStream<String> getSendDataStream(DataStream<String> gisDataStream, String toNums) {
        // 过滤已推送的数据
        DataStream<String> sendDataStream = gisDataStream.filter(line -> {
            JSONObject line_obj = JSONObject.parseObject(line);
            String naviId = JSONUtil.getJsonVal(line_obj, "naviId", "");
            String error_type = JSONUtil.getJsonVal(line_obj, "errorType", "");
            String createTime = JSONUtil.getJsonVal(line_obj, "createTime", "");

            boolean bol = false;
            Long createTimeTm = dateToStamp(createTime);

            // 筛选 error_type 为禁限行|道路问题|其他问题
            if (error_type.equals("禁限行") || error_type.equals("道路问题") || error_type.equals("其他问题")) bol = true;

            // 如果 naviId 已经存在于 Map 中（已经推送完成），则忽略该条数据
            Long timestamp = processedIds.get(naviId);
            if (timestamp != null) {
                bol = false;
            }else{
                // 将未推送的 naviId 和时间戳添加到 Map 中
                processedIds.put(naviId, createTimeTm);
            }

            // 定期清理过期元素,获取access_token
            long now = System.currentTimeMillis();
            if ((now - lastCleanTime) >= (6 * 60 * 60 * 1000)) { // 每6小时清理一次
                String access_token = getToken();
                logger.error("log lastCleanTime =>" + lastCleanTime);
                if(!access_token.equals("error")){
                    token_all = access_token;
                }

                Iterator<Map.Entry<String, Long>> iterator = processedIds.entrySet().iterator();
                while (iterator.hasNext()) {
                    Map.Entry<String, Long> entry = iterator.next();
                    if (isExpired(entry.getValue())) { // 判断元素是否过期
                        iterator.remove();
                    }
                }
                lastCleanTime = now;
            }

            return bol;
        }).map(line -> {
            // 获取推送模板
            JSONObject body1203 = getBody(line,toNums);

            long sendTime = System.currentTimeMillis();
            String batch_id = String.format("XYF_%s", sendTime);
            JSONObject param = new JSONObject();
            // 接口入参
            param.put("batchId", batch_id);
            param.put("sendTime", sendTime);
            param.put("templateCode", "1203");
            param.put("body", body1203);
            // 接口请求头
            Map<String, String> headers = new HashMap<>();
            String value = String.format("Bearer %s", token_all);
            headers.put("Authorization", value);
            headers.put("Content-Type", "application/json");
            // 调信息推送接口
            String retStr = HttpInvokeUtil.postMultiHeader(send_url, param.toString(), headers);
            logger.error("log send =>" + line);

            JSONObject line_obj = JSONObject.parseObject(line);
            JSONObject retStr_obj = JSONObject.parseObject(retStr);
            String user_msg = JSONUtil.getJsonVal(retStr_obj, "userMsg", "");
            String code = JSONUtil.getJsonVal(retStr_obj, "code", "");

            line_obj.put("batch_id",batch_id);
            line_obj.put("user_msg",user_msg);
            line_obj.put("code",code);

            return line_obj.toJSONString();
        });

        return sendDataStream;
    }

    public static String getToken(){
        String tokenUrl = "https://open-api-funsionwork.sf-express.com/oauth2/token";
        Map<String, String> headerMap = new HashMap<>(1);
        headerMap.put("Content-Type", "application/x-www-form-urlencoded");
        Map<String, String> bodyMap = new HashMap<>(3);
        bodyMap.put("client_id", "516850c58f6243ccaa39b59a98ae62c3");
        bodyMap.put("client_secret", "a1d1252faf9b4da3be113e76790520de");
        bodyMap.put("grant_type", "client_credentials");
        String retStr = sendPostByParam(tokenUrl, headerMap, bodyMap);
        JSONObject retStr_obj = JSONObject.parseObject(retStr);
        return JSONUtil.getJsonVal(retStr_obj, "access_token", "error");
    }

    public static Long dateToStamp(String s) {
        Long res = 0L;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = simpleDateFormat.parse(s);
            res = date.getTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    private static boolean isExpired(long timestamp) {
        // 判断时间戳是否过期
        boolean expired = false;
        long now = System.currentTimeMillis();
        if((now - timestamp) >= (6 * 60 * 60 * 1000)) expired = true;

        return expired;
    }

    // 调接口获取 adcode
    private static String runRoadAttrInterface(String linkId) {
        String adcode = "";
        if (!StringUtils.isBlank(linkId)) {
            String finalUrl = String.format(roadAttr_url,linkId);
            JSONObject ret = HttpInvokeUtil.httpGetJSON(finalUrl, 1);
            adcode = JSONUtil.getJsonVal(ret, "adcode", "");
        }
        return adcode;
    }

    private static JSONObject getBody(String line,String toNums) {

        JSONObject line_obj = JSONObject.parseObject(line);
        String naviId = JSONUtil.getJsonVal(line_obj, "naviId", "");
        String error_type = JSONUtil.getJsonVal(line_obj, "errorType", "");
        String detail_desc = JSONUtil.getJsonVal(line_obj, "detailDesc", "");
        String image_url = JSONUtil.getJsonVal(line_obj, "imageUrl", "");
        String link_id = JSONUtil.getJsonVal(line_obj, "linkIds", "").split(",")[0];
        String create_time = JSONUtil.getJsonVal(line_obj, "createTime", "");
        String carNo = JSONUtil.getJsonVal(line_obj, "carNo", "");

        // 调接口获取 adcode
        String adcode = runRoadAttrInterface(link_id);

        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMddHHmmss");
        long timestamp = 0;
        try {
            timestamp = sdf1.parse(create_time).getTime();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        Date date1 = new Date(timestamp);
        Date date2 = new Date(timestamp + (30 * 60 * 1000L));
        String start_time = sdf2.format(date1);
        String end_time = sdf2.format(date2);

        String ak = "bfd681d7bb9343d29034be6ce16eb411";
        String[] imageArr = image_url.split(",");

        String download_url1 = "";
        String download_url2 = "";
        if (imageArr.length == 1){
            download_url1 = String.format(download_url, ak, imageArr[0]);
        }else if(imageArr.length > 1){
            download_url1 = String.format(download_url, ak, imageArr[0]);
            download_url2 = String.format(download_url, ak, imageArr[1]);
        }
        String update_url1 = String.format(update_url,link_id,adcode,start_time,end_time);

        // 推送消息接收人列表
        JSONArray toNumsList = new JSONArray();
        String[] to_nums_arr = toNums.split(";");
        for (String num : to_nums_arr) {
            toNumsList.add(num);
        }
        JSONArray toGroupIds = new JSONArray();
        toGroupIds.add("16145949");

        JSONObject tmp1 = new JSONObject();
        JSONObject tmp2 = new JSONObject();
        JSONObject tmp3 = new JSONObject();
        JSONObject tmp4 = new JSONObject();
        JSONObject tmp5 = new JSONObject();
        JSONObject tmp6 = new JSONObject();
        JSONObject tmp7 = new JSONObject();
        JSONObject tmp8 = new JSONObject();
        JSONArray list = new JSONArray();
        JSONObject content = new JSONObject();
        JSONObject pushContent = new JSONObject();

        tmp1.put("key","导航ID：");
        tmp1.put("value",naviId);
        tmp2.put("key","车牌号：");
        tmp2.put("value",carNo);
        tmp3.put("key", "问题类型：");
        tmp3.put("value", error_type);
        tmp4.put("key", "问题描述：");
        tmp4.put("value", detail_desc);
        tmp5.put("key", "上报时间：");
        tmp5.put("value", create_time);
        tmp6.put("key", "图片链接1：");
        tmp6.put("value", download_url1);
        tmp7.put("key", "图片链接2：");
        tmp7.put("value", download_url2);
        tmp8.put("key", "更新链接：");
        tmp8.put("value", update_url1);

        list.add(tmp1);
        list.add(tmp2);
        list.add(tmp3);
        list.add(tmp4);
        list.add(tmp5);
        list.add(tmp6);
        if(imageArr.length > 1){
            list.add(tmp7);
        }
        list.add(tmp8);

        content.put("isBigToFirst",true);
        content.put("list",list);
        pushContent.put("title", "导航司机上报数据审核提醒_new");
        pushContent.put("body","导航司机上报数据审核提醒_new");

        JSONObject body3 = new JSONObject();
        body3.put("range", "APPOINT");
        body3.put("toNums", toNumsList);
        body3.put("toGroupIds", toGroupIds);
        body3.put("title", "导航司机上报数据审核提醒_new");
        body3.put("desc", "您好，您有一条司机上报信息，请尽快处理！");
        body3.put("content", content);
        body3.put("detail", "详情");
        body3.put("pushContent",pushContent);

        return body3;
    }

    // 初始化kafka,获取数据
    private static SingleOutputStreamOperator<String> initKafakaSource(StreamExecutionEnvironment env, Properties confInfo, String zipType) {
        String topic = confInfo.getProperty("kafka.topic");
        String offsetReset = confInfo.getProperty("auto.offset.reset");
        logger.error("offsetReset:"+offsetReset);
        KafkaSource<String> source = null;
        if(zipType.equals("gzip")){
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setValueOnlyDeserializer(new VMSTrackDeserializationSchema())
                    .build();
        }else{
            source = KafkaSource.<String>builder()
                    .setBootstrapServers(confInfo.getProperty("kafka.bootstrap.servers"))
                    .setTopics(topic)
                    .setGroupId(confInfo.getProperty("hive.table.name"))
                    .setStartingOffsets("earliest".equals(offsetReset) ? OffsetsInitializer.earliest() : ("latest".equals(offsetReset) ? OffsetsInitializer.latest() :
                            OffsetsInitializer.committedOffsets()))
                    .setProperty("value.deserializer.encoding", "UTF-8")
                    .setValueOnlyDeserializer(new SimpleStringSchema())
                    .build();
        }

        return env.fromSource(source, WatermarkStrategy.noWatermarks(), topic).name(topic).uid(topic).setParallelism(srcParallelism);
    }

}
