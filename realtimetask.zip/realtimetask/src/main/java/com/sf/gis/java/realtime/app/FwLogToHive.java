package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 从kafka读取日志信息落地到hive表（丰网日志）
 * @author 01370539 Created On: May.07 2021
 */
public class FwLogToHive {
	public static Logger logger = LoggerFactory.getLogger(FwLogToHive.class);

	public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("fwkafka2hive.properties", FwLogToHive.class.getName());
	}
}
