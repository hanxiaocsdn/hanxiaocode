package com.sf.gis.java.realtime.app;

import com.sf.gis.java.base.util.Kafka2HiveUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 80管控日志接入，需求方：刘雨婷
 */
public class RdsPnsAoiKafka2Hive {

    public static Logger logger = LoggerFactory.getLogger(RdsPnsAoiKafka2Hive.class);

    public static void main(String[] args) throws Exception {
        Kafka2HiveUtil.process("rdspnsaoikafka2hive.properties", RdsPnsAoiKafka2Hive.class.getName());
    }
}
