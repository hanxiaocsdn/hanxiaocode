package com.sf.gis.app


import com.sf.gis.scala.base.spark.{Spark}
import org.apache.log4j.Logger

import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-05-08 14:20
 * @TaskId:
 * @TaskName:测试嘉里集群BDP调度节点
 * @Description:
 */

object TestBDP {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("id","consignment_no","act_delivery_date","recipient_address","recipient_soi","recipient_road","recipient_address2","recipient_postcode_id","destination_dc_id","destination_dc_code","destination_dc_en_name","destination_dc_th_name","consignment_no","status_id","geo_location","aoiid","aoicode")

    def main(args: Array[String]): Unit = {
//        var end_day=args(0)
//        var end_date=args(1)
        val end_day="20230326"
        val end_date="2023-03-26"
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        getWaybillData(sparkSession,end_day,end_date)



    }

    def getWaybillData(spark: SparkSession,end_day:String,end_date:String) = {

        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val df = spark.sql(sql)
        logger.error("数据量有----》"+df.count())

    }

}
