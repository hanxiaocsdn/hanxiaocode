package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:
 * @Author: 01407499
 * @CreateTime: 2023-05-06 10:42
 * @TaskId:739417
 * @TaskName:
 * @Description:
 */

object WaybillXYLocationAoi {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("id","consignment_no","act_delivery_date","recipient_address","recipient_soi","recipient_road","recipient_address2","recipient_postcode_id","destination_dc_id","destination_dc_code","destination_dc_en_name","destination_dc_th_name","consignment_no","status_id","geo_location","aoiid","aoicode")


    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val broadcastAoiList: Broadcast[List[JSONObject]] = getAoiWkt(sparkSession)
        val dataRdd = getWaybillData(sparkSession, broadcastAoiList,end_day,end_date)

        /*
        如果上面的无法跑出结果就用下面这个
        val aoiMapListBroad: Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]] = getBuildWkt(sparkSession)
        val dataRdd = getWaybillDataNew(sparkSession, aoiMapListBroad, end_day, end_date)
        */
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveKey, "dm_gis.thai_waybill_location_aoi",null, 25)


    }

    def getWaybillData(spark: SparkSession,aoiListBroadcast:Broadcast[List[JSONObject]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
              |
              |select * from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
              |) a
              |inner join
              |(
              |select consignment_no, status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |
              |""".stripMargin

        sql=
            """
              |select * from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20230124' and '20230326' and act_delivery_date between '2023-01-26 00:00:00' and '2023-03-26 23:59:59' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
              |) a
              |inner join
              |(
              |select consignment_no, status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20230126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |limit 1000
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.map(obj => {
            val aoiList = aoiListBroadcast.value
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(0)
            val y = geoStrings(0)
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                for (aoiObj <- aoiList) {
                    val wkt = aoiObj.getString("wkt")
                    val d = getGeoData(wkt, x.toDouble, y.toDouble)
                    if (distance >= 0.0 && distance < d) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")

                    } else if (distance < 0.0) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")

                    }

                }


            }
            dataObj.put("aoiid", aoiid)
            dataObj.put("aoicode", aoicode)
            (obj._1, dataObj)

        })

        val resultRdd = dataRdd.map(x => (x.getString("geo_location"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }



    def getWaybillDataNew(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.map(obj => {
            val aoiListMap = aoiListBroadcast.value
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(0)
            val y = geoStrings(0)
            var aoiid = ""
            var aoicode = ""
            val tuple = getDistance(x, y, aoiListMap, 0.001)
            val tuple2 = getDistance(x, y, aoiListMap, -0.001)
            if(StringUtils.nonEmpty(tuple._1)){
                aoiid=tuple._1
                aoicode=tuple._2
            }else if(StringUtils.nonEmpty(tuple2._1)){
                aoiid=tuple2._1
                aoicode=tuple2._2

            }
            dataObj.put("aoiid", aoiid)
            dataObj.put("aoicode", aoicode)
            (obj._1, dataObj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("点落面获得的aoi数据量---》"+aoiInfoRdd.count())

        val resultRdd = dataRdd.map(x => (x.getString("geo_location"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def getDistance(x:String,y:String,aoiListMap:mutable.HashMap[String, ListBuffer[JSONObject]],sub:Double) = {
        var distance = (-1.0)
        var aoiid = ""
        var aoicode = ""
        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
            val lon_index = x.substring(0, 7).toDouble + sub
            val lat_index = y.substring(0, 6).toDouble + sub
            val key = lon_index + "_" + lat_index
            if (aoiListMap.contains(key)) {
                val aoiList = aoiListMap.get(key).get
                for (aoiObj <- aoiList) {
                    val wkt = aoiObj.getString("wkt")
                    val d = getGeoData(wkt, x.toDouble, y.toDouble)
                    if (distance >= 0.0 && distance < d) {
                        distance = d
                        aoiid = aoiObj.getString("aoiid")
                        aoicode = aoiObj.getString("aoicode")

                    } else if (distance < 0.0) {
                        distance = d
                        aoiid = aoiObj.getString("aoiid")
                        aoicode = aoiObj.getString("aoicode")

                    }

                }
            }

        }
        (aoiid,aoicode)
    }

    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case e:Exception=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }

    def getAoiWkt(spark:SparkSession)={
        val columns=Array("gui_id","zno_code","name_chn","aoi_code","wkt")
        val srcDF = spark.read
            .option("inferschema", "false")
            //.option("multiLine", true)
            .option("header", "false")
            .option("encoding", "UTF-8")
            .csv("hdfs://kex/user/01407499/upload/gex_aoi_050602.csv")
            .toDF("gui_id","zno_code","name_chn","aoi_code","wkt")
        val dataRdd = srcDF.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getAs[String](columns(i)))
            }
            jObj
        })
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }

    def getBuildWkt(spark:SparkSession)={
        var sql=
            s"""
               |select wkt,guid as bld_id,name_chn bld_name,x_coord as bld_lon,y_coord as bld_lat,addr_chn as bld_addr from dm_gis.building_all_info where x_coord is not null and x_coord<>'' and x_coord<>'null' and y_coord is not null and y_coord<>'' and y_coord<>'null' and wkt is not null and wkt<>'' and wkt<>'null'  order by bld_lon,bld_lat
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        dataRdd.take(30).foreach(println)
        val dataList = dataRdd.collect().toList

        //113.60260156256727,22.33121691648796
        val dataMap = new mutable.HashMap[String, ListBuffer[JSONObject]]()
        for(obj<-dataList){
            val bld_lon = obj.getString("bld_lon")
            val bld_lat = obj.getString("bld_lat")
            if(StringUtils.nonEmpty(bld_lon)&&StringUtils.nonEmpty(bld_lat)&&bld_lon.length>7&&bld_lat.length>6){
                val lon_index=bld_lon.substring(0,7).toDouble+0.001
                val lat_index=bld_lat.substring(0,6).toDouble+0.001
                val key=lon_index+"_"+lat_index
                if(dataMap.contains(key)){
                    dataMap.put(key,dataMap.get(key).get+=obj)
                }else{
                    val listBuffer: ListBuffer[JSONObject] = ListBuffer()
                    listBuffer+=obj
                    dataMap.put(key,listBuffer)
                }
            }
        }
        spark.sparkContext.broadcast(dataMap)

    }

    def binarySearch(buildList:ListBuffer[JSONObject],lng:String,keyName:String,starIndex:Int,endIndex:Int)={
        var l=starIndex
        var r=endIndex
        val lngadd = lng.toDouble+0.01
        val lngsub=lng.toDouble-0.01
        //                val lngadd = lng.toDouble+2
        //                val lngsub=lng.toDouble-1
        //        var mid=0
        breakable{
            while(l<r){
                var mid:Int=(l+r)/2
                val bld_lon = buildList(mid).getString(keyName).toDouble
                if(bld_lon>lngadd){
                    r = mid - 1
                }else if(bld_lon<lngsub){
                    l=mid+1
                }else {
                    break
                }
            }
        }
        //寻找l
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l-1)/2
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_1 = math.abs(lng.toDouble - bld_lon_1)
                //                logger.error("bld_lon----->"+bld_lon+"---lngadd---->"+lngadd+" lngsub---->"+lngsub)

                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_1<=0.0007){
                        l=mid
                        //                        logger.error("search l---->"+l)
                        break
                    }else{
                        r_tem_l = mid + 1

                    }

                }

            }
        }
        //寻找r
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l)/2+1
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_2 = math.abs(lng.toDouble - bld_lon_2)
                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_2>0.0007){
                        r=mid
                        break
                    }else{
                        l_tem_l=mid-1

                    }

                }

            }
        }
        (l,r)


    }

    def getDistance(lng:String,lat:String,buildList:ListBuffer[JSONObject])={
        var bld_dis = (-1.0)
        var index=0
        val (start,end) = binarySearch(buildList, lng,"bld_lon",0,buildList.size-1)
        logger.error("start lng index---->"+start+"end lng index----->"+end)
        val (l,r)=binarySearch(buildList, lat,"bld_lat",start,end)
        logger.error("start index---->"+l+"----->end index------>"+r)
        breakable{
            for(i<- l until r){
                val buildobj=buildList(i)
                val wkt = buildobj.getString("wkt")
                val dist = getGeoData(wkt, lng.toDouble, lat.toDouble)
                if (dist >= 0.0&&dist<=50.0) {
                    if (bld_dis >= 0.0) {
                        if (dist < bld_dis) {
                            bld_dis = dist
                            index=i
                        }
                    } else {
                        bld_dis = dist
                        index=i
                    }
                }
                if (bld_dis == 0.0) {
                    break
                }
            }

        }

        (bld_dis,index)


    }


}
