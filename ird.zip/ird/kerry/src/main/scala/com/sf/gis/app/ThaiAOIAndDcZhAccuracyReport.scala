package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.HighFrequencyNotRecognizeAoiDataShou.logger
import com.sf.gis.app.ThaiDcAccuracyReport.{getZhUrlData, zhUrl}
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils._
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-09-20 10:42
 * @TaskId:869635
 * @TaskName:
 * @Description:aoi和dc准确率报表 zh
 */


/**
 *
 * 目前有三个需求用zh接口
0504&0706——每周一、周四跑数
高频未识别——每周日跑数
t-2的数据跑zh，每周三跑数
 *
 *
 */
object ThaiAOIAndDcZhAccuracyReport {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","is_same_zh_xj_batch_aoi","is_same_zh_xj_80_aoi","is_same_zh_xj_batch_or_80_aoi","is_same_zh_xj_dest_dc","is_same_zh_dj_dest_dc","is_same_zh_xj_80_dc","is_same_zh_dj_xj_dest_80_dc","src_zh","zh_dccode","zh_largedccode","zh_aoiid","zh_aoicode","zh_aoiarea","confidence","is_recognize_zh_aoi")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
//        end_day="20231115"
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("计算aoi和dc准确率报表")
        val resultRdd = calcAccuracy(sparkSession, end_day)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk_pai_zh",Array(("inc_day", end_day)), 25)


    }

    def calcAccuracy(spark: SparkSession,end_day:String)={


        var sql=
            s"""
              |
              |select * from dm_gis.thai_delivery_scheduling_chk where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        val resultRdd = dataRdd.map(obj => {
            val batch_aoi = obj.getString("batch_aoi")
            val aoiid = obj.getString("aoiid")
            val dest_zone_code = obj.getString("dest_zone_code")
            val dc = obj.getString("dc")
            val parmObj = new JSONObject()
            val input_param_receiver_addr= obj.getString("input_param_receiver_addr")
            val input_param_receiver_addr2= obj.getString("input_param_receiver_addr2")
            val input_param_receiver_postal_code= obj.getString("input_param_receiver_postal_code")

            parmObj.put("address", input_param_receiver_addr)
            parmObj.put("address2", input_param_receiver_addr2)
            parmObj.put("zipcode", input_param_receiver_postal_code)
            parmObj.put("type", "con")
            parmObj.put("extend", "1")

            val (srcchk,dcCodechk,largeDcCodechk,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,jSONObject) = getZhUrlData(parmObj)




            //丰图是否识别AOI
            var is_recognize_zh_aoi = "false"
            //识别小件AOI与排班AOI是否一致
            var is_same_zh_xj_batch_aoi = "false"
            //识别小件AOI与妥投AOI是否一致
            var is_same_zh_xj_80_aoi = "false"
            //识别小件AOI与排班AOI或妥投AOI是否一致zh
            var is_same_zh_xj_batch_or_80_aoi="false"

            //识别小件DC与dest_DC是否一致
            var is_same_zh_xj_dest_dc = "false"

            //识别大件DC与dest_DC是否一致
            var is_same_zh_dj_dest_dc = "false"

            //识别小件DC与妥投DC是否一致
            var is_same_zh_xj_80_dc = "false"

            //识别大件DC与妥投DC是否一致
            var is_same_zh_dj_xj_dest_80_dc = "false"


            if(StringUtils.nonEmpty(srcchk)&&Array("his","ml","geo-kw").contains(srcchk)){
                is_recognize_zh_aoi="true"
            }

            if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(result_data_aoicode) && batch_aoi.contains(result_data_aoicode)) {
                is_same_zh_xj_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(result_data_aoiid) && StringUtils.nonEmpty(aoiid) && result_data_aoiid.equals(aoiid)) {
                is_same_zh_xj_80_aoi = "true"
            }

            if(is_same_zh_xj_batch_aoi.equals("true")||is_same_zh_xj_80_aoi.equals("true")){
                is_same_zh_xj_batch_or_80_aoi="true"
            }

            if (StringUtils.nonEmpty(dcCodechk) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(dcCodechk)) {
                is_same_zh_xj_dest_dc = "true"
            }

            if (StringUtils.nonEmpty(largeDcCodechk) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(largeDcCodechk)) {
                is_same_zh_dj_dest_dc = "true"
            }
            if (StringUtils.nonEmpty(dcCodechk) && StringUtils.nonEmpty(dc) && dc.equals(dcCodechk)) {
                is_same_zh_xj_80_dc = "true"
            }
            if(is_same_zh_xj_dest_dc.equals("true")||is_same_zh_dj_dest_dc.equals("true")||is_same_zh_xj_80_dc.equals("true")){
                is_same_zh_dj_xj_dest_80_dc="true"

            }

            obj.put("is_recognize_zh_aoi", is_recognize_zh_aoi)
            obj.put("is_same_zh_xj_batch_aoi", is_same_zh_xj_batch_aoi)
            obj.put("is_same_zh_xj_80_aoi", is_same_zh_xj_80_aoi)
            obj.put("is_same_zh_xj_batch_or_80_aoi", is_same_zh_xj_batch_or_80_aoi)
            obj.put("is_same_zh_xj_dest_dc", is_same_zh_xj_dest_dc)

            obj.put("is_same_zh_dj_dest_dc", is_same_zh_dj_dest_dc)
            obj.put("is_same_zh_xj_80_dc", is_same_zh_xj_80_dc)
            obj.put("is_same_zh_dj_xj_dest_80_dc", is_same_zh_dj_xj_dest_80_dc)

            obj.put("src_zh", srcchk)
            obj.put("zh_dccode", dcCodechk)
            obj.put("zh_largedccode", largeDcCodechk)
            obj.put("zh_aoiid", result_data_aoiid)
            obj.put("zh_aoicode", result_data_aoicode)
            obj.put("zh_aoiarea", result_data_aoiarea)
            obj.put("confidence", confidence)

            obj
        }).distinct()

        resultRdd


    }


    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        Thread.sleep(3000)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }

    def getZhUrlData(parm:JSONObject): (String, String, String, String, String, String,String, JSONObject) ={

        //        var nowHour = getHour()
        //        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
        //            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
        //            Thread.sleep(1000*60)
        //            nowHour = getHour()
        //
        //        }
        var src=""
        var dcCode=""
        var largeDcCode=""
        var result_data_aoiid=""
        var result_data_aoicode=""
        var result_data_aoiarea=""
        var confidence=""
        var jSONObject =new JSONObject()

        if(parm.size()<1){
            return (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,jSONObject)
        }
        Thread.sleep(260)
        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","a9f889c1fc5a4904a29a63ef43206aaf")
        breakable {
            for(i<-0 until(3)){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(zhUrl, parm, stringToString))
                }
                catch {
                    case _=>{
                        logger.error("error parameter-----> "+parm.toString())
                        new JSONObject()
                    }
                }
                val status = JSONUtil.getJsonVal(jSONObject, "status", "")
                val msg = JSONUtil.getJsonVal(jSONObject, "result.msg", "")

                if(StringUtils.nonEmpty(status)&&status.equals("0")){
                    break
                }else{
                    if(msg.contains("many")&&msg.contains("too")){
                        Thread.sleep(30000)
                    }else{
                        break
                    }

                }
            }

        }


        src = JSONUtil.getJsonVal(jSONObject, "result.data.src", "")
        val status = JSONUtil.getJsonVal(jSONObject, "status", "")
        if(!status.equals("0")){
            src=JSONUtil.getJsonVal(jSONObject, "result.msg", "")
        }
        dcCode = JSONUtil.getJsonVal(jSONObject, "result.data.dcCode", "")
        largeDcCode = JSONUtil.getJsonVal(jSONObject, "result.data.largeDcCode", "")
        result_data_aoiid=JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        result_data_aoicode=JSONUtil.getJsonVal(jSONObject, "result.data.aoiCode", "")
        result_data_aoiarea=JSONUtil.getJsonVal(jSONObject, "result.data.aoiArea", "")
        confidence==JSONUtil.getJsonVal(jSONObject, "result.data.confidence", "")
        (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,jSONObject)

    }


}
