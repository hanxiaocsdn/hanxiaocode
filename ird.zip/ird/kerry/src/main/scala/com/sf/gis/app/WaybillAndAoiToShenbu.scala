package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.WaybillXYLocationAoi.{getGeoData, logger}
import com.sf.gis.utils.{Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2023-05-09 10:20
 * @TaskId:743977
 * @TaskName:
 * @Description:嘉里-审补数据入库
 */

object WaybillAndAoiToShenbu {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","aoi_percentage","aoi_total","input_param_receiver_postal_code")


    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
//        val broadcastAoiList: Broadcast[List[JSONObject]] = getAoiWktNew(sparkSession)
        val dataRdd = getWaybillDataNew(sparkSession,end_day,end_date)
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveKey, "dm_gis.thai_aoi_mid_shenbu",null, 25)

    }


    def getWaybillData(spark: SparkSession,aoiListBroadcast:Broadcast[List[JSONObject]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        sql=
            """
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','0280','10570','12120','13180','74130')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |    select *,
              |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20221126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |where destination_dc_code='LMK'
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.map(obj => {
            val aoiList = aoiListBroadcast.value
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(1)
            val y = geoStrings(0)
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            var zno_code=""
            val listBuffer: ListBuffer[String] = ListBuffer()
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                for (aoiObj <- aoiList) {
                    val wkt = aoiObj.getString("wkt")
                    val d = getGeoData(wkt, x.toDouble, y.toDouble)
                    if (distance >= 0.0 &&d>=0.0&& distance > d) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")
                        zno_code=aoiObj.getString("zno_code")
                        listBuffer+=(d.toString+":"+aoicode)

                    } else if (distance < 0.0&&d>=0.0) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")
                        zno_code=aoiObj.getString("zno_code")
                        listBuffer+=(d.toString+":"+aoicode)

                    }

                }

                dataObj.put("aoiid", aoiid)
                dataObj.put("aoicode", aoicode)
                dataObj.put("dc", zno_code)
//                dataObj.put("distanceList",listBuffer.toString())


            }

            (obj._1, dataObj)

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        aoiInfoRdd.take(10).foreach(println)

        val aoiRdd = dataRdd.map(x => (x.getString("geo_location"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        })


        val resultRdd = aoiRdd.map(obj => {
            //recipient_address,recipient_address2
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj


        }).groupBy(x => (x.getString("address"), x.getString("aoicode"))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoi_num = x._2.toList.length
            for (obj <- x._2) {
                obj.put("aoi_num", aoi_num)
                listBuffer += obj
            }

            listBuffer

        }).groupBy(x => x.getString("address")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val address_num = x._2.toList.length
            val aoiSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                aoiSet.add(obj.getString("aoicode"))
            }

            for (obj <- x._2) {
                obj.put("address_num", address_num)
                obj.put("aoi_total", aoiSet.size)
                listBuffer += obj
            }
            listBuffer
        }).map(obj => {
            val address_num = obj.getString("address_num")
            val aoi_num = obj.getString("aoi_num")
            var aoi_percentage = 0.0
            if (StringUtils.nonEmpty(address_num) && StringUtils.nonEmpty(aoi_num)) {
                aoi_percentage = aoi_num.toDouble / address_num.toDouble
                if (aoi_percentage > 0.85)
                    obj.put("aoi_percentage", aoi_percentage)
                else
                    obj.put("aoi_percentage", null)

            }


            obj

        }).filter(x => StringUtils.nonEmpty(x.getString("aoi_percentage"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+resultRdd.count())
        resultRdd

    }

    def getWaybillDataNew(spark: SparkSession,end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        //'10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','74130','10280','10570','10550','10320','13180'
        sql=
            """
              |select a.*, b.geo_location,c.aoiid,c.aoicode,c.zno_code as dc from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id in ('12110','12150')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |    select *,
              |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20221126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |left join dm_gis.thai_geo_xy_location_aoi_v2 c on b.geo_location=c.geo_location
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |
              |select * from dm_gis.thai_aoi_mid_shenbu_tmp_data where inc_day='$end_day' and address<>'' and address is not null
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.groupBy(x => (x.getString("address"), x.getString("aoicode"),x.getString("recipient_postcode_id"))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoi_num = x._2.toList.length
            for (obj <- x._2) {
                obj.put("aoi_num", aoi_num)
                listBuffer += obj
            }

            listBuffer

        }).groupBy(x => (x.getString("address"),x.getString("recipient_postcode_id"))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoi_total = x._2.toList.length
            for (obj <- x._2) {
                obj.put("aoi_total", aoi_total)
                listBuffer += obj
            }
            listBuffer
        }).map(obj => {
            val aoi_total = obj.getString("aoi_total")
            val aoi_num = obj.getString("aoi_num")
            var aoi_percentage = 0.0
            if (StringUtils.nonEmpty(aoi_total) && StringUtils.nonEmpty(aoi_num)) {
                aoi_percentage = aoi_num.toDouble / aoi_total.toDouble
                if (aoi_percentage > 0.85)
                    obj.put("aoi_percentage", aoi_percentage)
                else
                    obj.put("aoi_percentage", null)

            }
            obj
        }).filter(x => StringUtils.nonEmpty(x.getString("aoi_percentage"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+resultRdd.count())
        resultRdd
    }

    def getAoiWkt(spark:SparkSession)={
        val columns=Array("gui_id","zno_code","name_chn","aoi_code","wkt")
        val srcDF = spark.read
            .option("inferschema", "false")
            //.option("multiLine", true)
            .option("header", "false")
            .option("encoding", "UTF-8")
            .csv("hdfs://kex/user/01407499/upload/gex_aoi_050602.csv")
            .toDF("gui_id","zno_code","name_chn","aoi_code","wkt")
        val dataRdd = srcDF.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getAs[String](columns(i)))
            }
            jObj
        })
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }

    def getAoiWktNew(spark:SparkSession)={
        var sql="select * from dm_gis.thai_aoi_wkt_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }

    def replaceInvalidStr(addr:String): String ={
        var addrs=""
        if(!StringUtils.nonEmpty(addr)){
            return addrs
        }
        var flag=true
        addrs=addr.trim
        while(flag){
            if(addrs.matches("^([-])(.*)|(.*)([-])$")){
                addrs=addrs.replaceAll("^([-])?|([-])?$","").trim
            }else{
                flag=false
            }
        }
        addrs

    }

}
