package com.sf.scala.tloc.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNet}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import com.sf.scala.tloc.app.PathFix.{row2Json, writeToHive}
import com.sf.scala.tloc.util.MyHttpClientUtils

/**
 * 嘉里物流里程招标取数_V1.0
 * 需求方：陈俊璋（01432447）
 * @author 徐游飞（01417347）
 * 任务ID：873873
 * 任务名称：网点里程计算
 */
object GetDistanceTest {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  // 路径规划接口
  val GetDist_URL: String = "http://gis-gw.int.os-sgp.local:9080/pnsStdLine/api/plan?origin=%s&destination=%s&opt=gg2"
  val GetDist_AK: String = "d414b8fcbfab474a874b351aa2a28a71"  // header里放ak
  val parallelism = 5
  val akMinuLimit = 500

  // 调接口
  def runStdLineInteface(ak: String, obj: JSONObject): JSONObject = {

    val x1 = JSONUtil.getJsonVal(obj, "x1","")
    val y1 = JSONUtil.getJsonVal(obj, "y1","")
    val x2 = JSONUtil.getJsonVal(obj, "x2","")
    val y2 = JSONUtil.getJsonVal(obj, "y2","")

    val origin =  s"$y1,$x1"        // 纬度在前，经度在后
    val destination =  s"$y2,$x2"  // 纬度在前，经度在后
    val GetDistReq = String.format(GetDist_URL,origin, destination)
    var dist = 0.0
    var msg = ""
    try {
      // 调用路径规划接口获取车行距离L
      val byxyResp = MyHttpClientUtils.retryGet(GetDistReq) // header里放ak
      val jsonObj = JSON.parseObject(byxyResp)
      dist = jsonObj.getJSONObject("result").getDouble("dist")
      msg = jsonObj.getJSONObject("result").getString("msg")
    } catch {
      case e: Exception => ""
    }

    obj.put("dist",dist)
    obj.put("msg",msg)

    obj
  }


  def execute(spark: SparkSession, incDay: String) = {
    import spark.implicits._

    // 获取线下始发网点数据
    val rdd_start_3 = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load(s"/user/01417347/upload/start_$incDay.csv")
      .rdd.map(row2Json)

    // 调接口
    val rdd_all_1 = SparkNet.runInterfaceWithAkLimit(spark, rdd_start_3, runStdLineInteface, parallelism, GetDist_AK, akMinuLimit)

    val df_dist_1 = rdd_all_1.map(obj=>{
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val x1 = JSONUtil.getJsonVal(obj, "x1","")
      val y1 = JSONUtil.getJsonVal(obj, "y1","")
      val x2 = JSONUtil.getJsonVal(obj, "x2","")
      val y2 = JSONUtil.getJsonVal(obj, "y2","")

      val dist = JSONUtil.getJsonVal(obj, "dist", "")
      val msg = JSONUtil.getJsonVal(obj, "msg", "")

      (start_dept,end_dept,x1,y1,x2,y2,dist,msg)
    }).toDF("start_dept","end_dept","x1","y1","x2","y2","dist","msg")
      .withColumn("inc_day",lit(incDay))
      .withColumn("origin",lit(""))
      .withColumn("destination",lit(""))

    val cols_all = spark.sql("""select * from dm_gis.dm_dept_distance_dtl_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_dist_1.select(cols_all: _*), Seq("inc_day"), "dm_gis.dm_dept_distance_dtl_di")

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error(s"++++++++  任务开始  incDay=$incDay+++++++")
    execute(spark,incDay)
    logger.error("++++++++  任务完成 20240115  +++++++")

    spark.stop()

  }

}
