package com.sf.gis.app
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-12-11 16:52
 * @TaskId:873909
 * @TaskName:嘉里物流仓管标记错分数据接入
 * @Description:
 */

object SignMisclassificationLogParse {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("waybillno","requesttime","addresseeaddr","addresseepostalcode","addresseemobile","addresseedeptcode","addresseeaoicode","addresseeteamcode","currentdeptcode","newdeptcode","reporttime")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        logger.error("解析日志")
        val resultRdd = parseLog(sparkSession, end_day)
        logger.error("存储数据日志")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.sign_dept_error_log_parse_data",Array(("inc_day", end_day)), 25)

    }

    def parseLog(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.sign_dept_error_log where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val waybillNo = JSONUtil.getJsonVal(obj, "waybillNo", "")
            val requestTime = JSONUtil.getJsonVal(obj, "requestTime", "")
            val addresseeAddr = JSONUtil.getJsonVal(obj, "addresseeAddr", "")
            val addresseePostalCode = JSONUtil.getJsonVal(obj, "addresseePostalCode", "")
            val addresseeMobile = JSONUtil.getJsonVal(obj, "addresseeMobile", "")
            val addresseeDeptCode = JSONUtil.getJsonVal(obj, "addresseeDeptCode", "")
            val addresseeAoiCode = JSONUtil.getJsonVal(obj, "addresseeAoiCode", "")
            val addresseeTeamCode = JSONUtil.getJsonVal(obj, "addresseeTeamCode", "")
            val currentDeptCode = JSONUtil.getJsonVal(obj, "currentDeptCode", "")
            val newDeptCode = JSONUtil.getJsonVal(obj, "newDeptCode", "")
            val reportTime = JSONUtil.getJsonVal(obj, "reportTime", "")
            obj.put("waybillno", waybillNo)
            obj.put("requesttime", requestTime)
            obj.put("addresseeaddr", addresseeAddr)
            obj.put("addresseepostalcode", addresseePostalCode)
            obj.put("addresseemobile", addresseeMobile)
            obj.put("addresseedeptcode", addresseeDeptCode)
            obj.put("addresseeaoicode", addresseeAoiCode)
            obj.put("addresseeteamcode", addresseeTeamCode)
            obj.put("currentdeptcode", currentDeptCode)
            obj.put("newdeptcode", newDeptCode)
            obj.put("reporttime", reportTime)

            obj


        })

        resultRdd

    }

}
