package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01412995
 * @Author: 01407499
 * @CreateTime: 2023-12-06 10:54
 * @TaskId:873875
 * @TaskName:电话识别-数据预处理
 * @Description:
 */

object MobileRecognizePretreatment {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveMidKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","addresspin","is_same_out_his80_aoi","mobile_aoiid","mobile_type","input_param_addressee_mobile_new")
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","addresspin","is_same_out_his80_aoi","mobile_aoiid","input_param_addressee_mobile_new")
    def main(args: Array[String]): Unit = {

        var end_day=args(0)
        var start_day=args(1)
//        end_day="20231115"
//        start_day="20231101"
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始预处理数据")
        val(resultRdd,allDataRdd)=pretreatment(sparkSession,start_day,end_day)
        logger.error("开始存储全量数据")
        SparkWrite.save2HiveStaticNew(sparkSession, allDataRdd, saveMidKey, "dm_gis.thai_delivery_scheduling_chk_mobile_mid",Array(("inc_day", end_day)), 25)
        logger.error("开始存储最终结果数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk_mobile",Array(("inc_day", end_day)), 25)

    }

    def pretreatment(spark: SparkSession,start_day:String,end_day:String)={
        var sql=
            s"""
              |
              |
              |select *,regexp_replace(input_param_addressee_mobile,'[\\s ,\\\\-,\\, , \\\\ ,\\",\\/,\\. ,\\:,\\;,@,#,\\` ]','') as input_param_addressee_mobile_new from dm_gis.thai_delivery_scheduling_chk where inc_day between '$start_day'and '$end_day'
              |
              |""".stripMargin

        sql=
            s"""
              |
              |
              |select *,regexp_replace(input_param_addressee_mobile,'[\\s ,\\\\-,\\\\, , \\\\ ,\\\\",\\\\/,\\\\. ,\\\\:,\\\\;,@,#,\\\\` ]','') as input_param_addressee_mobile_new from dm_gis.thai_delivery_scheduling_chk where inc_day between '$start_day'and '$end_day'
              |
              |
              |
              |
              |""".stripMargin


        logger.error("sql---->"+sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val allDataRdd = dataRdd.map(obj => {
            val input_param_receiver_postal_code = obj.getString("input_param_receiver_postal_code")
            val input_param_addressee_mobile = obj.getString("input_param_addressee_mobile")
            val aoicode = obj.getString("aoicode")
            val batch_aoi = obj.getString("batch_aoi")
            val out_param_addressee_aoi_id = obj.getString("out_param_addressee_aoi_id")
            val aoiid = obj.getString("aoiid")
            var input_param_addressee_mobile_new=obj.getString("input_param_addressee_mobile_new").replace("$","")
            val is_recognize_aoi = JSONUtil.getJsonValSingle(obj,"is_recognize_aoi")

            val is_exist_batch_aoi = JSONUtil.getJsonValSingle(obj,"is_exist_batch_aoi")
            val is_same_xj_batch_aoi = JSONUtil.getJsonValSingle(obj,"is_same_xj_batch_aoi")
            val is_same_xj_80_aoi = JSONUtil.getJsonValSingle(obj,"is_same_xj_80_aoi")
            var temp_mobile_aoiid = ""
            var is_calc = "true"
            var mobile_type=""
            if (StringUtils.nonEmpty(input_param_receiver_postal_code) && (!input_param_receiver_postal_code.equals("null"))) {
                val postalSet = input_param_receiver_postal_code.toCharArray.toSet
                if (postalSet.size == 1 && input_param_receiver_postal_code.contains("0")) {
                    is_calc = "false"
                }

            } else {
                is_calc = "false"
            }

            if (StringUtils.nonEmpty(input_param_addressee_mobile_new) && (!input_param_addressee_mobile_new.equals("null"))) {
                val mobileSet = input_param_addressee_mobile_new.toCharArray.toSet
                if (mobileSet.size == 1 && input_param_addressee_mobile_new.contains("0")) {
                    is_calc = "false"
                }

            } else {
                is_calc = "false"
            }

            if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(aoicode) && batch_aoi.contains(aoicode)) {
                temp_mobile_aoiid = aoiid
                mobile_type="1"

            } else if (StringUtils.nonEmpty(out_param_addressee_aoi_id) && StringUtils.nonEmpty(aoiid) && out_param_addressee_aoi_id.trim.equals(aoiid.trim)) {
                temp_mobile_aoiid = out_param_addressee_aoi_id
                mobile_type="2"
            } else if (StringUtils.nonEmpty(is_recognize_aoi)&&is_recognize_aoi.contains("true")) {
                if(StringUtils.nonEmpty(is_exist_batch_aoi)&&is_exist_batch_aoi.trim.contains("true")){
                    if(((StringUtils.nonEmpty(is_same_xj_batch_aoi)&&is_same_xj_batch_aoi.trim.equals("true")) || (StringUtils.nonEmpty(is_same_xj_80_aoi)&&is_same_xj_80_aoi.trim.equals("true")))){
                        temp_mobile_aoiid = out_param_addressee_aoi_id
                        mobile_type="3"

                    }else{
                        mobile_type="4"
                    }

                }else {
                    mobile_type="5"
                }



            }else{
                mobile_type="6"
            }

            obj.put("input_param_addressee_mobile_new", input_param_addressee_mobile_new)
            obj.put("is_calc", is_calc)
            obj.put("mobile_type", mobile_type)
            obj.put("temp_mobile_aoiid", temp_mobile_aoiid)

            obj
        })

        val notNeedCalcRdd = allDataRdd.filter(x => (!(StringUtils.nonEmpty(x.getString("is_calc")) && x.getString("is_calc").toBoolean))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("不需要计算的数据---》"+notNeedCalcRdd.count())
        val needCalcRdd = allDataRdd.filter(x => StringUtils.nonEmpty(x.getString("is_calc")) && x.getString("is_calc").toBoolean).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要计算的数据---》"+needCalcRdd.count())
        Spark.clearPersistWithoutIdList(spark,Array(notNeedCalcRdd.id,needCalcRdd.id))
        val mobileAoiRdd = needCalcRdd.groupBy(x => (x.getString("input_param_receiver_postal_code"), x.getString("input_param_addressee_mobile_new"), x.getString("temp_mobile_aoiid"),x.getString("mobile_type"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val aoi_num = x._2.size
            for (obj <- x._2) {
                obj.put("aoi_num", aoi_num)
                listBuffer += obj

            }

            listBuffer

        }).groupBy(x => (x.getString("input_param_receiver_postal_code"), x.getString("input_param_addressee_mobile_new"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            var aoi_num_max_1 = 0L
            var aoi_num_max_2 = 0L
            var aoi_num_max_3 = 0L
            var mobile_type=""
            var mobile_aoiid_1=""
            var mobile_aoiid_2=""
            var mobile_aoiid_3=""
            var mobile_aoiid = ""
            for (obj <- x._2) {
                try {
                    val aoi_num = obj.getString("aoi_num").toLong
                    val mobile_type1 =obj.getString("mobile_type")
                    val temp_mobile_aoiid=obj.getString("temp_mobile_aoiid")
                    if(StringUtils.nonEmpty(mobile_type1)&&StringUtils.nonEmpty(temp_mobile_aoiid)){
                        if(mobile_type1.equals("1")){
                            if(aoi_num_max_1<aoi_num){
                                mobile_aoiid_1=temp_mobile_aoiid
                                aoi_num_max_1=aoi_num
                            }

                        }else if(mobile_type1.equals("2")){
                            if(aoi_num_max_2<aoi_num){
                                mobile_aoiid_2=temp_mobile_aoiid
                                aoi_num_max_2=aoi_num
                            }

                        }else if(mobile_type1.equals("3")){
                            if(aoi_num_max_3<aoi_num){
                                mobile_aoiid_3=temp_mobile_aoiid
                                aoi_num_max_3=aoi_num
                            }

                        }

                    }
                } catch {
                    case e: Exception => logger.error(e.toString)
                }

            }


            if(StringUtils.nonEmpty(mobile_aoiid_1)){
                mobile_aoiid=mobile_aoiid_1
                mobile_type="1"

            }else if(StringUtils.nonEmpty(mobile_aoiid_2)){
                mobile_aoiid=mobile_aoiid_2
                mobile_type="2"
            }else if(StringUtils.nonEmpty(mobile_aoiid_3)){
                mobile_aoiid=mobile_aoiid_3
                mobile_type="3"
            }
            for (obj <- x._2) {
                val tmpObj = new JSONObject()
                tmpObj.fluentPutAll(obj)
                tmpObj.put("mobile_aoiid", mobile_aoiid)
                tmpObj.put("mobile_type", mobile_type)
                listBuffer += tmpObj

            }


            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算的数据——--》"+mobileAoiRdd.count())

        val resultRdd = mobileAoiRdd.groupBy(x => (x.getString("input_param_receiver_postal_code"), x.getString("input_param_addressee_mobile_new"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            dataObj.fluentPutAll(x._2.head)
            listBuffer += dataObj

            listBuffer
        }).filter(x => StringUtils.nonEmpty(x.getString("mobile_aoiid")))

        (resultRdd,notNeedCalcRdd.union(mobileAoiRdd))
    }



}
