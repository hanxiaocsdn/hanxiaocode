package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.ThaiAutomationBuildingAddressDatabase.{className, getSplitResult, getWaybillDataNew, logger, saveMidKey}
import com.sf.gis.app.WaybillAndAoiToShenbuMid.replaceInvalidStr
import com.sf.gis.utils.{Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:ft80006092
 * @Author: 01407499
 * @CreateTime: 2023-07-27 17:08
 * @TaskId:782359
 * @TaskName:
 * @Description:地址建库-获取切词数据
 */

object ThaiAddrSplit {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveMidKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","split_result", "addr_split_info")
    val saveKey=Array("id","name","alias","subno","adcode","x","y","tag","dccode","dc","aoiid","aoi_code","level","waybill_no","groupby","all_code_list","groupby_count","aoi_code_max","aoi_code_max_percent","data_type","zipcode","address")
    val saveTmpKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","split_result","addr_split_info","province","district","subno","name","level","tag","adcode")
    val geoUrl="http://10.234.0.255:7014/?query_type=GEOCODE&address=%s&zipcode=%s&filter_uprecision=2&ret_splitinfo=1&output=json"

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取地址切词数据数据")
        val dataRdd=getWaybillDataNew(sparkSession,end_day)
        logger.error("存储地址切词数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveMidKey, "dm_gis.thai_aoi_standard_addr_mid_data",Array(("inc_day", end_day)), 25)
    }

    def getWaybillDataNew(spark: SparkSession,end_day:String) = {

        //'10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','74130','10280','10570','10550','10320','13180'
        var sql=
            """
              |
              |
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id in ('74110','74000','74120','74130')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |select *,
              |row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |from ods_kems.consignment_tracking
              |where inc_day between '20221126' and '20230326' and status_id='21' and geo_location is not null
              |) bb where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |""".stripMargin

        //原来建库
        sql=
            s"""
               |
               |
               |select * from dm_gis.thai_waybill_location_aoi where recipient_postcode_id in ('74110','74000','74120','74130') and inc_day='$end_day'
               |
               |""".stripMargin

        sql=
            s"""
               |
               |
               |select * from dm_gis.thai_waybill_location_aoi where  inc_day='$end_day'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val addrRdd = dataRdd.map(obj => {
            //recipient_address,recipient_address2
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+addrRdd.count())
        Spark.clearPersistWithoutId(spark,addrRdd.id)
        val resultRdd = addrRdd.mapPartitions(x => {
            val datalist = new ListBuffer[JSONObject]()
            for (obj <- x) {
                val address = obj.getString("address")
                val recipient_postcode_id = obj.getString("recipient_postcode_id")
                val (splitResult, addrSplitInfo) = getSplitResult(address, recipient_postcode_id)

                obj.put("split_result",splitResult)
                obj.put("addr_split_info",addrSplitInfo)
                datalist += obj
            }
            datalist.iterator

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取地址切词数据量---》"+resultRdd.count())
        resultRdd

    }

}
