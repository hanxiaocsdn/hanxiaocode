package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.GisVmsTrackDeviceTrack.{row2Json, writeToHive}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession

import java.util
import java.util.Calendar
import scala.util.control.Breaks.{break, breakable}

/**
 * 泰国嘉里分单仓管审补地址自动化回收工艺需求_V1.0(接口部分)
 * 需求方：陈丽（01430458）
 * @author 徐游飞（01417347）
 * 任务ID：874287
 * 任务名称：嘉里分单仓管审补_地址入库
 */
object ShenbuAddressChange {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  // 回收地址接口
  val change_url: String = "http://gis-ird-cms.int.os-sgp.local/globalexpress/openapi/address/change"
  // 下发地址接口
  var token_all: String = null
  val add_url: String = "http://gis-ird-cms.int.os-sgp.local/globalexpress/openapi/waybill/addWaybillTask"
  val parallelism = 10
  val akMinuLimit = 1800

  def getToken(): String = {
    var access_token = ""

    val username = "01417347"
    val password = "Xyf01417347@"
    val header = "Authorization"
    val value = "Basic R0lTLUlSRC1DT1JFLUNNUy1DTElFTlQ6QU9TQEJEUCEyMDIy"
    val url = "http://gis-ird-gateway.int.os-sgp.local/uac/oauth/token?grant_type=password&username=%s&password=%s".format(username, password)

    breakable(
      for (i <- 0.until(3)) {
        try {
          val jsonObject = HttpInvokeUtil.sendPostHeader(url, "", header, value, "UTF-8", "UTF-8")
          logger.error(">>>访问getToken：url" + i + "=" + url + ", result=" + jsonObject)
          Thread.sleep(2000)
          if (jsonObject != null) {

            access_token = JSONUtil.parseJSONObject(jsonObject).getString("access_token")
            if (!StringUtils.isEmpty(access_token)) break
            else Thread.sleep(2000)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => logger.error(">>>访问getToken：url" + i + "=" + url)
        }
      }
    )
    access_token
  }

  // 调接口下发地址
  def runAddInteface(obj: JSONObject, token: String): JSONObject = {

    val is_compliant = JSONUtil.getJsonVal(obj, "is_compliant", "")
    val address = JSONUtil.getJsonVal(obj, "address","")
    val zip_code = JSONUtil.getJsonVal(obj, "zip_code","")
    val city_code = JSONUtil.getJsonVal(obj, "city_code","")
    val dc = JSONUtil.getJsonVal(obj, "dc","")
    val wb_no = JSONUtil.getJsonVal(obj, "wb_no","")
    val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
    val aoi_dc = JSONUtil.getJsonVal(obj, "aoi_dc", "")
    val x = JSONUtil.getJsonVal(obj, "x", "")
    val y = JSONUtil.getJsonVal(obj, "y", "")

    var code = ""
    var message = ""
    var ret = ""
    var value11 = ""
    var header11 = ""
    var url = ""
    var retJSONObject = new JSONObject()
    val param = new JSONObject()

    if (is_compliant.equalsIgnoreCase("yes1") || is_compliant.equalsIgnoreCase("yes2")) {
      // 接口入参
      param.put("adType", 2)
      param.put("address", address)
      param.put("aoi", aoi_id)
      param.put("dc", aoi_dc)
      param.put("x", x)
      param.put("y", y)
      param.put("zipCode", zip_code)
      param.put("sourceType", 5)
      param.put("region", "TH")
      param.put("cityCode", city_code)

      try {
        val retStr = HttpInvokeUtil.sendPost(change_url, param.toJSONString, 3)
        retJSONObject = JSON.parseObject(retStr)
        code = retJSONObject.getString("code")
        message = retJSONObject.getString("message")
        ret = retStr
        url = change_url
      } catch {
        case e: Exception => logger.error(">>>访问change接口异常：" + e + "params=" + param.toString + ", json=" + retJSONObject)
      }

    } else if (is_compliant.equalsIgnoreCase("no1") || is_compliant.equalsIgnoreCase("no2")){
      // 接口入参
      param.put("cityCode", city_code)
      param.put("zipCode", zip_code)
      param.put("address", address)
      param.put("dc", dc)
      param.put("taskType", 1)
      param.put("region", "TH")
      param.put("wbNo", wb_no)
      // 接口请求头
      val headers = new util.HashMap[String,String]()
      val value = "Bearer " + token
      headers.put("Accept-language","zh-CN")
      headers.put("Auth-client-id","GIS-IRD-CORE-CMS")
      headers.put("Auth-tenant-code","TH")
      headers.put("Auth-tenant-id","40")
      headers.put("Authorization",value)
      headers.put("Content-Type", "application/json");
      headers.put("Connection", "Keep-Alive");
      headers.put("Accept", "application/json");

      try {
        val retStr = HttpInvokeUtil.sendPostMultiHeader(add_url, param.toString, headers, 3)
        retJSONObject = JSON.parseObject(retStr)
        code = retJSONObject.getString("code")
        message = retJSONObject.getString("message")
        ret = retStr
        url = add_url
        value11 = value
        header11 = headers.toString
      } catch {
        case e: Exception => logger.error(">>>访问add接口异常：" + e + "params=" + param.toString + ", json=" + retJSONObject)
      }
    }

    //新增接口返回值字段
    obj.put("code", code)
    obj.put("message", message)

    obj.put("param", param.toJSONString)
    obj.put("url", url)
    obj.put("ret", ret)
    obj.put("token", value11)
    obj.put("header", header11)
    obj
  }

  def shenbuAddressChange(spark: SparkSession, inc_day: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val shenbu_addr_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.thai_aoi_shenbu_addr_dtl
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println(shenbu_addr_sql)

    val rdd_shenbu_addr = spark.sql(shenbu_addr_sql)
      .filter('is_compliant.contains("yes"))  //只筛选达标数据，调回收接口
      .withColumn("rn", row_number().over(Window.partitionBy("address","is_compliant").orderBy(desc("inc_day"))))
      .filter('rn === 1)  // 按地址和类型去重
      .drop("rn")
      .rdd.map(row2Json).repartition(10)

    val cores = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.cores", "0"))
    val excutors = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量：" + excutors + ",cores数量：" + cores)
    logger.error("分区数：" + rdd_shenbu_addr.getNumPartitions)
    logger.error("单分区ak最大分钟限制：" + akMinuLimit / parallelism)

    val df_all_ret = rdd_shenbu_addr.mapPartitions(itr => {
      val partitionLimitMinu = akMinuLimit / parallelism
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      // 通过UAC鉴权接口获取token
      token_all = getToken()
      // 接口访问速度限制
      itr.map(obj=>{
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val sleep_cnt = new util.ArrayList[String]()
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
            sleep_cnt.add(s"休眠 =>>  次数： $timeInt + 总数： $partitionsCount")
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        obj.put("sleep_cnt",sleep_cnt)
        // 调接口回收和下发地址
        runAddInteface(obj, token_all)
      })
    }).map(obj=>{
      val batch_aoi = JSONUtil.getJsonVal(obj, "batch_aoi", "")
      val addresspin = JSONUtil.getJsonVal(obj, "addresspin", "")
      val pod_aoiid = JSONUtil.getJsonVal(obj, "pod_aoiid", "")
      val is_same_batch_aoi = JSONUtil.getJsonVal(obj, "is_same_batch_aoi", "")
      val is_same_pod_aoiid = JSONUtil.getJsonVal(obj, "is_same_pod_aoiid", "")
      val city_code = JSONUtil.getJsonVal(obj, "city_code", "")
      val zip_code = JSONUtil.getJsonVal(obj, "zip_code", "")
      val dc = JSONUtil.getJsonVal(obj, "dc", "")
      val wb_no = JSONUtil.getJsonVal(obj, "wb_no", "")
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
      val aoi_code = JSONUtil.getJsonVal(obj, "aoi_code", "")
      val aoi_dc = JSONUtil.getJsonVal(obj, "aoi_dc", "")
      val exc_type = JSONUtil.getJsonVal(obj, "exc_type", "")
      val mark_coor = JSONUtil.getJsonVal(obj, "mark_coor", "")
      val task_state = JSONUtil.getJsonVal(obj, "task_state", "")
      val get_by = JSONUtil.getJsonVal(obj, "get_by", "")
      val coverage = JSONUtil.getJsonVal(obj, "coverage", "")
      val accuracy = JSONUtil.getJsonVal(obj, "accuracy", "")
      val is_compliant = JSONUtil.getJsonVal(obj, "is_compliant", "")
      val x = JSONUtil.getJsonVal(obj, "x", "")
      val y = JSONUtil.getJsonVal(obj, "y", "")
      val code = JSONUtil.getJsonVal(obj, "code", "")
      val message = JSONUtil.getJsonVal(obj, "message", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")

      // 辅助字段
      val param = JSONUtil.getJsonVal(obj, "param", "")
      val ret = JSONUtil.getJsonVal(obj, "ret", "")
      val url = JSONUtil.getJsonVal(obj, "url", "")
      val token = JSONUtil.getJsonVal(obj, "token", "")
      val header = JSONUtil.getJsonVal(obj, "header", "")
      val sleep_cnt = JSONUtil.getJsonVal(obj, "sleep_cnt", "")

      ShenbuV1(batch_aoi,addresspin,pod_aoiid,is_same_batch_aoi,is_same_pod_aoiid,city_code,zip_code,dc,wb_no,address,aoi_id,
        aoi_code,aoi_dc,exc_type,mark_coor,task_state,get_by,coverage,accuracy,is_compliant,x,y,code,message,inc_day,
        param,ret,url,token,header,sleep_cnt)
    }).toDF()

    val cols_v1 = spark.sql("""select * from dm_gis.thai_aoi_shenbu_v1 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_all_ret.select(cols_v1: _*).coalesce(3), Seq("inc_day"), "dm_gis.thai_aoi_shenbu_v1")

  }

  case class ShenbuV1(
                       batch_aoi: String,
                       addresspin: String,
                       pod_aoiid: String,
                       is_same_batch_aoi: String,
                       is_same_pod_aoiid: String,
                       city_code: String,
                       zip_code: String,
                       dc: String,
                       wb_no: String,
                       address: String,
                       aoi_id: String,
                       aoi_code: String,
                       aoi_dc: String,
                       exc_type: String,
                       mark_coor: String,
                       task_state: String,
                       get_by: String,
                       coverage: String,
                       accuracy: String,
                       is_compliant: String,
                       x: String,
                       y: String,
                       code: String,
                       message: String,
                       inc_day: String,
                       param: String,
                       ret: String,
                       url: String,
                       token: String,
                       header: String,
                       sleep_cnt: String
                     )



  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error(s"++++  任务开始 inc_day=$inc_day  ++++")
    // 调过接口回收和下发地址(目前只调回收接口)
    shenbuAddressChange(spark, inc_day)
    logger.error("++++++++  任务完成 20240115  ++++")

    spark.stop()

  }

}
