package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.WaybillAndAoiToShenbu.{className, logger, saveKey}
import com.sf.gis.app.WaybillXYLocationAoi.getHour
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-08-23 17:52
 * @TaskId:794426
 * @TaskName:
 * @Description:嘉里-审补数据入库
 */

object WaybillAndAoiToShenbuRuKu {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    var addrChangeUrl=" http://orion-cms.int.kex.local:1080/globalexpress/openapi/address/change"
    addrChangeUrl="http://gis-ird-cms.int.os-sgp-local/globalexpress/openapi/address/change"
    addrChangeUrl="https://gis-ird-cms.th.kerryexpress.com/globalexpress/openapi/address/change"
    val saveKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","aoi_percentage","aoi_total","code","message")
    def main(args: Array[String]): Unit = {
        var end_day=args(0)
//        var end_date=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = getData(sparkSession, end_day)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_aoi_shenbu_v3_ruku",Array(("inc_day", end_day)), 25)


    }

    def getData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.thai_aoi_shenbu_v3 where inc_day='$end_day'
              |
              |""".stripMargin

//        sql=
//            """
//              |
//              |select * from dm_gis.thai_aoi_shenbu_v3_ruku where inc_day='20231102' and code<>'200'
//              |
//              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        //.filter(x=>StringUtils.nonEmpty(x.getString("code"))&&x.getString("code").equals("500"))
        val resultRdd = dataRdd.map(obj => {
            try{
                val tmpObj = new JSONObject()
                val address = obj.getString("address")
//                val recipient_postcode_id = obj.getString("recipient_postcode_id")
                val recipient_postcode_id = obj.getString("input_param_receiver_postal_code")
                val aoiid = obj.getString("aoiid")
                val dc = obj.getString("dc")
                val geoStrings = obj.getString("geo_location").split(",")
                obj.put("recipient_postcode_id",recipient_postcode_id)

                val x = geoStrings(1)
                val y = geoStrings(0)
                tmpObj.put("sourceType", "3")
                tmpObj.put("adType", "2")
                tmpObj.put("address", address)
                tmpObj.put("aoi", aoiid)
                tmpObj.put("dc", dc)
                tmpObj.put("x", x)
                tmpObj.put("y", y)
                tmpObj.put("zipCode", recipient_postcode_id)
                val (code, message) = postInterface(tmpObj)
                obj.put("code", code)
                obj.put("message", message)

            }catch {case e:Exception=>logger.error(e.getStackTrace)}
            obj
        })

        //.filter(x=>StringUtils.nonEmpty(x.getString("code")))
        resultRdd



    }

    def postInterface(dataObj:JSONObject)={


        var nowHour = getHour()
        if((nowHour>=21||(nowHour>=0&&nowHour<8))){
            Thread.sleep(40)
        }else{
            Thread.sleep(90)

        }
        var message=""
        var code=""

        val jSONObject = try {
//            Thread.sleep(280)
            HttpUtils.urlConnectionPostJson(addrChangeUrl,dataObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+dataObj.toString())
                message=e.toString
                null
            }
        }
        if(jSONObject!=null){
            code = JSONUtil.getJsonVal(jSONObject, "code", "")
            message = JSONUtil.getJsonVal(jSONObject, "message", "")

        }


        (code,message)

    }

}
