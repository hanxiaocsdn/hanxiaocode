package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils._
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-09-20 10:42
 * @TaskId:857760
 * @TaskName:
 * @Description:aoi和dc准确率报表
 */

object ThaiChkQueryAOIAndDcAccuracyReport {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("district","city_code","waybill_no","source_zone_code","dest_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","data_result_query_consignmentno","data_result_query_address","data_result_query_address2","data_result_query_zipcode","datetime","data_result_data_aoiarea","data_result_data_aoicode","data_result_data_aoiid","data_result_data_dccode","data_result_data_transcode","data_result_data_largedccode","geo_location","aoiid","aoicode","dc","geo_location_thai","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","data_result_data_src","is_recognize_aoi")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        var start_day=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")

        logger.error("获取邮编区域映射信息")
        val postalMapBro: Broadcast[collection.Map[String, String]] = getZipCityInfo(sparkSession)
        logger.error("计算aoi和dc准确率报表")
        val resultRdd = calcAccuracy(sparkSession, end_day, end_date, start_day, postalMapBro)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk_query",Array(("inc_day", end_day)), 25)


    }

    def getZipCityInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.thai_postal_city_info
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val postalMap = dataRdd.map(obj => {
            val postal_code = obj.getString("postal_code")
            val city_code = obj.getString("city_code")
            val district = obj.getString("district")
            (postal_code, city_code + "\001" + district)

        }).collectAsMap()
        spark.sparkContext.broadcast(postalMap)

    }



    def calcAccuracy(spark: SparkSession,end_day:String,end_date:String,start_day:String,postalMapBro:Broadcast[collection.Map[String, String]])={
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        //select a.*, b.*, c.geo_location ,d.aoiid,d.aoicode,d.dc,d.geo_location_thai

        var sql=
            s"""
              |
              |select * from dm_gis.thai_delivery_scheduling_chk_query_mid_data where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val addOtherWaybillAoi = dataRdd.distinct().mapPartitions(x => {
            val list = new ListBuffer[JSONObject]()
            for (obj <- x) {
                try{
                    val geo_location = obj.getString("geo_location")
                    val geo_location_thai = obj.getString("geo_location_thai")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    if(geo_location_thai==null||geo_location_thai.isEmpty){
                        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                            val (aoi_id,aoi_code,zno_code) = getAoiFromInterface(x, y)
                            obj.put("aoiid", aoi_id)
                            obj.put("aoicode", aoi_code)
                            obj.put("dc", zno_code)
                        }
                    }


                }catch {case e:Exception=>logger.error(e.getMessage)}

                list += obj
            }
            list.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("对于没有aoi的数据重新调用点落aoi接口----》"+addOtherWaybillAoi.count())


        val resultRdd = addOtherWaybillAoi.map(obj => {
            val postalMap = postalMapBro.value
            val data_result_data_dccode = obj.getString("data_result_data_dccode")
            val data_result_data_aoiid = obj.getString("data_result_data_aoiid")
            val data_result_data_largedccode = obj.getString("data_result_data_largedccode")
            val dest_zone_code = obj.getString("dest_zone_code")
            val data_result_query_zipcode = obj.getString("data_result_query_zipcode")
            var city_code = ""
            var county = ""
            if (postalMap.contains(data_result_query_zipcode)) {
                val str = postalMap.get(data_result_query_zipcode).get.split("\001")
                if (str.length > 1) {
                    city_code = str(0)
                    county = str(1)
                }

            }


            val dc = obj.getString("dc")

            //丰图是否识别AOI
            var is_recognize_aoi = "false"
            //识别小件DC与dest_DC是否一致
            var is_same_xj_dest_dc = "false"

            //识别大件DC与dest_DC是否一致
            var is_same_dj_dest_dc = "false"

            //识别小件DC与妥投DC是否一致
            var is_same_xj_80_dc = "false"




            if (StringUtils.nonEmpty(data_result_data_aoiid)) {
                is_recognize_aoi = "true"
            }

            if (StringUtils.nonEmpty(data_result_data_dccode) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(data_result_data_dccode)) {
                is_same_xj_dest_dc = "true"
            }

            if (StringUtils.nonEmpty(data_result_data_largedccode) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(data_result_data_largedccode)) {
                is_same_dj_dest_dc = "true"
            }
            if (StringUtils.nonEmpty(data_result_data_dccode) && StringUtils.nonEmpty(dc) && dc.equals(data_result_data_dccode)) {
                is_same_xj_80_dc = "true"
            }


            obj.put("is_recognize_aoi", is_recognize_aoi)
            obj.put("is_same_xj_dest_dc", is_same_xj_dest_dc)
            obj.put("is_same_dj_dest_dc", is_same_dj_dest_dc)
            obj.put("is_same_xj_80_dc", is_same_xj_80_dc)
            obj.put("city_code", city_code)
            obj.put("district", county)

            obj
        }).distinct()

        resultRdd


    }


    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        Thread.sleep(3000)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }


}
