package com.sf.gis.utils

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
  * Created by 01374443 on 2020/7/27.
  */
object Spark {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)


  /**
    * 获取spark session
    *
    * @param appName : spark应用名称
    * @param confMap : spark配置，null则为默认配置
    * @param isLocal : 是否本地模式，true:本地模式，false:集群模式
    * @return
    */
  def getSparkSession(appName: String, confMap: Map[String, String] = null, isLocal: Boolean = false, localThread: Int = 2): SparkSession = {
    var sparkSession: SparkSession = null
    if (isLocal) {
      sparkSession = SparkSession.builder().config(getSparkConf(appName, confMap).setMaster("local[" + localThread + "]")).getOrCreate()
    } else {
      sparkSession = SparkSession.builder().config(getSparkConf(appName, confMap)).enableHiveSupport().getOrCreate()
    }
    sparkSession.sparkContext.setLogLevel("ERROR")
    logger.error("conf list:")
    val confAll = sparkSession.conf.getAll
    for (confName <- confAll.keySet) {
      logger.error(confName + ": " + confAll.apply(confName))
    }
    sparkSession
  }

  def getSparkConf(appName: String, confMap: Map[String, String]): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
      .set("spark.sql.broadcastTimeout", "36000")
      .set("spark.network.timeout", "30001")
      .set("spark.executor.heartbeatInterval", "30000")
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.result.partition.ratio","1")
      .set("spark.executor.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
      .set("spark.driver.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
      .set("hive.vectorized.execution.enabled","false")
      .set("hive.vectorized.execution.reduce.enabled","false")
      .set("spark.hive.mapred.supports.subdirectories","true")
      .set("spark.hadoop.mapreduce.input.fileinputformat.input.dir.recursive","true")
    //.set("spark.sql.hive.convertMetastoreOrc","false")
    //.set("spark.sql.hive.convertMetastoreParquet","false")
    if (confMap != null) {
      for (confName <- confMap.keySet) {
        conf.set(confName, confMap.apply(confName))
      }
    }
    conf
  }

  /**
   * 获取调度节点数和单节点核数
   * @return
   */
  def getExcutorInfo(sparkSession:SparkSession): (Int,Int) ={
    var cores = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    val localMaster = sparkSession.sparkContext.getConf.get("spark.master", "")
    println(localMaster)
    if (!localMaster.isEmpty && localMaster.startsWith("local")) {
      logger.error("本地调用")
      excutors = localMaster.takeRight(2).dropRight(1).toInt;
      cores = 1
    }
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    (excutors,cores)
  }
  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  /**
   * 移除非指定的rdd的其他rdd
   * @param sparkSession
   * @param withoutId
   */
  def clearPersistWithoutId(sparkSession:SparkSession,withoutId:Int): Unit ={
    //移除缓存数据
    val ds: collection.Map[Int, RDD[_]] = sparkSession.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      if (withoutId != x._2.id) {
        logger.error("移除缓存RDD,id:" + x._2.id)
        x._2.unpersist()
      }
    })
  }
  /**
   * 移除非指定的rdd的其他rdds
   * @param sparkSession
   * @param withoutId
   */
  def clearPersistWithoutIdList(sparkSession:SparkSession,withoutId:Array[Int]): Unit ={
    //移除缓存数据
    val ds: collection.Map[Int, RDD[_]] = sparkSession.sparkContext.getPersistentRDDs
    ds.foreach(x => {
      if (!withoutId.contains(x._2.id)) {
        logger.error("移除缓存RDD,id:" + x._2.id)
        x._2.unpersist()
      }
    })
  }
}
