package com.sf.scala.tloc.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.java.base.util.DateUtil.tmToDate
import com.sf.gis.java.base.util.DistanceUtils.getDistance
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DistanceTool, JSONUtil}
import com.sf.scala.tloc.app.PathFix.{row2Json, writeToHive}
import com.sf.scala.tloc.util.MyHttpClientUtils
import com.vividsolutions.jts.geom.{Coordinate, GeometryFactory, MultiPolygon, Point, Polygon}
import com.vividsolutions.jts.io.WKTReader
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import org.geotools.geometry.jts.JTSFactoryFinder
import org.apache.spark.{HashPartitioner, Partitioner}
import org.json4s._
import org.json4s.jackson.JsonMethods._

import java.util
import java.util.Calendar
import scala.collection.JavaConversions._
import scala.collection.mutable.ListBuffer


/**
 * 泰国车油补里程计算V1.0
 * 需求内容：计算小哥全量里程和网点里程,并依据计算结果,给予相应的车补和油补;kex集群scala版本与bdp不一致,打包前需修改 scala版本为2.12.14
 * 需求方：丁汀（01430258）
 * @author 徐游飞（01417347）
 * 任务ID：840991
 * 任务名称：小哥里程明细表
 */
object XiaoGePathDistance {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
//  // 纠偏接口
//  val Rectify_URL: String = "http://gis-jp.int.kex.local:1081/drectify"  // 不用ak
//  val Rectify_AK: String = ""
  // 路径规划接口
  val GetDist_URL: String = "http://gis-gw.int.os-sgp.local:9080/pnsStdLine/api/plan?origin=%s&destination=%s&opt=gg2"
  val GetDist_AK: String = "d414b8fcbfab474a874b351aa2a28a71"  // header里放ak
  val parallelism = 20
  val akMinuLimit = 1000

  //允许的最大距离范围
  val maxAllowDistance = 1500


  def fetchXyPolygon(obj: JSONObject, callMethod: String, zcXys: JSONObject, geometryFactory: GeometryFactory, wKTReader: WKTReader): util.ArrayList[Polygon] = {
    val polygonList = new util.ArrayList[Polygon]()
    if (zcXys == null || zcXys.isEmpty) {
      return polygonList
    }
    val zcXyArray = zcXys.keySet()

    for (zc <- zcXyArray) {
      try {
        val zcXy = zcXys.getString(zc)
        if (!zcXy.isEmpty) {
          val point = wKTReader.read(zcXy).asInstanceOf[Polygon]
          polygonList.add(point)
        }
      } catch {
        case e: Exception =>
          val errorMsg = s"method=>$callMethod,message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchXyPolygon")
              && !elem.toString.contains("apply")).mkString(";")

          obj.put("fetchXyPolygonMsg", errorMsg)
      }
    }
    polygonList
  }

  def checkCircleIntersectsPolygon(geometryFactory: GeometryFactory, pointMid: Point, maxAllowDistance: Double, zcXyPolygon: Polygon): Boolean = {
    val circle = DistanceTool.createRingPolygon(geometryFactory, pointMid.getX, pointMid.getY, maxAllowDistance)
    circle.intersects(zcXyPolygon)
  }

  def checkCircleIntersectsMultiPolygon(geometryFactory: GeometryFactory, pointMid: Point, maxAllowDistance: Double, zcXyMultiPolygon: MultiPolygon): Boolean = {
    val circle = DistanceTool.createRingPolygon(geometryFactory, pointMid.getX, pointMid.getY, maxAllowDistance)
    circle.intersects(zcXyMultiPolygon)
  }

  def checkInZc(point1: Point, point2: Point, geometryFactory: GeometryFactory, wKTReader: WKTReader, zcXys: JSONObject): Boolean = {

    if (zcXys == null || zcXys.isEmpty) {
      return false
    }

    val zcXyArray = zcXys.keySet()
    for (zc <- zcXyArray) {
      try {
        val zcXy = zcXys.getString(zc)
        if (!zcXy.isEmpty) {
          if(zcXy.contains("MULTIPOLYGON")){
            val zcXyMultiPolygon = wKTReader.read(zcXy).asInstanceOf[MultiPolygon]
            if ((point1.within(zcXyMultiPolygon) || checkCircleIntersectsMultiPolygon(geometryFactory, point1, maxAllowDistance, zcXyMultiPolygon))
              && (point2.within(zcXyMultiPolygon) || checkCircleIntersectsMultiPolygon(geometryFactory, point2, maxAllowDistance, zcXyMultiPolygon))) {
              return true
            }
          }else if(zcXy.contains("POLYGON")){
            val zcXyPolygon = wKTReader.read(zcXy).asInstanceOf[Polygon]
            if ((point1.within(zcXyPolygon) || checkCircleIntersectsPolygon(geometryFactory, point1, maxAllowDistance, zcXyPolygon))
              && (point2.within(zcXyPolygon) || checkCircleIntersectsPolygon(geometryFactory, point2, maxAllowDistance, zcXyPolygon))) {
              return true
            }
          }

        }
      } catch {
        case e: Exception =>
          val errorMsg = s"message=>" + e.fillInStackTrace() + ",stack =>" +
            e.getStackTrace().filter(elem => elem.toString.contains("fetchXyPolygon")
              && !elem.toString.contains("apply")).mkString(";")
          logger.error(errorMsg)
      }
    }

    false
  }

  // 根据纠偏轨迹，计算里程
  def calDistance(obj: JSONObject,polygonJson: JSONObject): JSONObject = {
    val http_ret = new JSONObject()
    val test_list = new ListBuffer[String]

    val rsp = JSONUtil.getJsonObjectMulti(obj, "rsp")
    val tracks = JSONUtil.getJsonArrayMulti(rsp,"tracks")

    if (tracks == null || tracks.size() < 2) {
      logger.error("tracks non")
      http_ret.put("err","轨迹点小于2")
      return http_ret
    }

    val time_list = new ListBuffer[Long]
    var disall = 0.0  //全量里程
    var disall_add = 0.0  //全量补充里程
    var distance_in_dept = 0.0  //网点内里程
    var distance_in_dept_add = 0.0  //网点内补充里程

    val geometryFactory = JTSFactoryFinder.getGeometryFactory(null)
    val wKTReader = new WKTReader(geometryFactory)

    try {
      for (i <- 0 until tracks.size() - 1) {
        val track1 = tracks.getJSONObject(i)
        val time1 = track1.getLong("time")
        val x1 = track1.getDouble("x")
        val y1 = track1.getDouble("y")
        val coord1 = new Coordinate(x1, y1)
        val point1 = geometryFactory.createPoint(coord1)

        val track2 = tracks.getJSONObject(i + 1)
        val time2 = track2.getLong("time")
        val x2 = track2.getDouble("x")
        val y2 = track2.getDouble("y")
        val coord2 = new Coordinate(x2, y2)
        val point2 = geometryFactory.createPoint(coord2)

        val tmpDis = getDistance(x1, y1, x2, y2)       //单位：米
        time_list.append(time1)
        time_list.append(time2)

        if (tmpDis != 0 && tmpDis <= maxAllowDistance) {
          //全量里程
          disall += tmpDis

          //判断网点内
          val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
          if (chkZc) {
            //网点内里程
            distance_in_dept += tmpDis
          }
        } else if(tmpDis != 0) {
          val subTm = Math.abs(time2 - time1) / (60.0 * 60.0)
          val v = (tmpDis / 1000.0) / subTm
          if (v <= 60) {  // 速度小于60，即速度正常
            if (tmpDis > 3000) {  // 距离S>3km时，调用路径规划接口获取车行距离L

              val origin =  s"$y1,$x1"        // 纬度在前，经度在后
              val destination =  s"$y2,$x2"  // 纬度在前，经度在后
              val GetDistReq = String.format(GetDist_URL,origin, destination)
              // 调用路径规划接口获取车行距离L
              val byxyResp = MyHttpClientUtils.retryGet(GetDistReq)  // header里放ak
              val jsonObj = JSON.parseObject(byxyResp)
              var dist = 0.0
              try {
                dist = jsonObj.getJSONObject("result").getDouble("dist")
              } catch {
                case e: Exception => ""
              }

              logger.error("接口调用完毕 ==> dist = "+dist)
              //如果接口返回车行距离里程数大于且等于直线距离的2倍，那么以直线距离的2倍作为该段补充的距离
              if(dist >= tmpDis * 2){
                dist = tmpDis * 2
              }

              //全量里程
              disall += dist
              //全量补充里程
              disall_add += dist
              //判断网点内
              val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
              if (chkZc) {
                //网点内里程
                distance_in_dept += dist
                //网点内补充里程
                distance_in_dept_add += dist
              }

            } else {
              //全量里程
              disall += tmpDis
              //全量补充里程
              disall_add += tmpDis

              //判断网点内
              val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
              if (chkZc) {
                //网点内里程
                distance_in_dept += tmpDis
                //网点内补充里程
                distance_in_dept_add += tmpDis
              }

            }
          }

        }
      }
    } catch {
      case e: Exception =>
        e.printStackTrace()
      //        val errorMsg = "message=>" + e.fillInStackTrace() + ",stack =>" + e.getStackTrace().mkString(";")
      //        errMsgJsonArr.add(errorMsg)
      //
      //        throw e
    }

    var disall_ret = ""
    var disall_add_ret = ""
    var distance_in_dept_ret = ""
    var distance_in_dept_add_ret = ""
    if(disall != 0.0) disall_ret = (disall / 1000).toString
    if(disall_add != 0.0) disall_add_ret = (disall_add / 1000).toString
    if(distance_in_dept != 0.0) distance_in_dept_ret = (distance_in_dept / 1000).toString
    if(distance_in_dept_add != 0.0) distance_in_dept_add_ret = (distance_in_dept_add / 1000).toString

    var path_start_time = ""
    var path_end_time = ""
    try {
      path_start_time = tmToDate((time_list.min * 1000).toString,"yyyy-MM-dd HH:mm:ss")
      path_end_time = tmToDate((time_list.max * 1000).toString,"yyyy-MM-dd HH:mm:ss")
    } catch {
      case e: Exception => ""
    }

    http_ret.put("disall",disall_ret)
    http_ret.put("disall_add",disall_add_ret)
    http_ret.put("distance_in_dept",distance_in_dept_ret)
    http_ret.put("distance_in_dept_add",distance_in_dept_add_ret)
    http_ret.put("path_start_time",path_start_time)
    http_ret.put("path_end_time",path_end_time)
    //测试字段
    http_ret.put("byxyResp",test_list.mkString("@@@"))

    http_ret
  }

  // 自定义分区器
  class DataSizePartitioner(numParts: Int) extends Partitioner {
    def numPartitions: Int = numParts

    // 计算分区号
    def getPartition(key: Any): Int = key match {
      case json: JSONObject => calculatePartition(json)
      case _ => throw new IllegalArgumentException("Key is not a JValue")
    }

    // 计算分区的逻辑
    private def calculatePartition(json: JSONObject): Int = {
      val rsp = JSONUtil.getJsonObjectMulti(json, "rsp")
      val tracks = JSONUtil.getJsonArrayMulti(rsp,"tracks")
      val dataSize = tracks.size() // 获取轨迹点数量作为数据大小
      dataSize % numPartitions
    }
  }

  def execute(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    val track_sql =
      s"""
         |select
         |  un,
         |  bn,
         |  req,
         |  err,
         |  rsp
         |from
         |  dm_gis.dm_path_fix_dtl_di
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println(track_sql)

    val polygon_sql =
      s"""
         |select
         |  dc as bn,
         |  dc_type,
         |  aoi_ids,
         |  wkt
         |from
         |  dm_gis.dm_dc_aoi_polygon_dtl_df
         |where
         |  inc_day = '$dayBefore1'
         |  and dc <> ''
         |  and dc is not null
         |""".stripMargin
    println(polygon_sql)

    val df_polygon = spark.sql(polygon_sql)
    val rdd_track = spark.sql(track_sql)
      .join(df_polygon,Seq("bn"),"left")  // 关联获取aoi多边形
      .withColumn("rsp",when('err === "疑似纠偏异常",'req).otherwise('rsp)) // 如果疑似纠偏异常就用原始轨迹计算里程
      .withColumn("trajector_source",when('err === "疑似纠偏异常","原始").otherwise("hive"))
      .rdd
      .map(r => {
        val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
        val rowMap: Map[String, String] = rowMap_tmp.map(v => {
          if (v._2 == null) (v._1, "") else v
        })

        val obj: JSONObject = new JSONObject()
        for (m <- rowMap) obj.put(m._1, m._2)

        val rsp = JSONUtil.getJsonObjectMulti(obj, "rsp")
        val tracks = JSONUtil.getJsonArrayMulti(rsp,"tracks")
        val tracksSize = tracks.size() // 获取轨迹点数量作为数据大小

        (tracksSize,obj)  // 将每个JSONObject映射成(key, value)对,key为轨迹点数量
      })
      .partitionBy(new HashPartitioner(parallelism)) // 按照轨迹点数量进行重分区
      .map(_._2)  // 去除掉之前添加的key，只保留原始的JSONObject

    val cores = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.cores", "0"))
    val excutors = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量：" + excutors + ",cores数量：" + cores)
    logger.error("分区数：" + rdd_track.getNumPartitions)
    logger.error("单分区ak最大分钟限制：" + akMinuLimit / parallelism)

    val retRdd = rdd_track.mapPartitions(partitions => {
      val partitionLimitMinu = akMinuLimit / parallelism
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }

        val emp_code = JSONUtil.getJsonVal(obj, "un", "")
        val wkt = JSONUtil.getJsonVal(obj, "wkt", "")
        val rsp = JSONUtil.getJsonObjectMulti(obj, "rsp")
        val tracks = JSONUtil.getJsonArrayMulti(rsp,"tracks")
        val polygonJson = new JSONObject()
        polygonJson.put(emp_code, wkt)

        val http_err = new util.ArrayList[String]()
        if (tracks == null || tracks.size() < 2) {
          logger.error("tracks non")
          http_err.add("轨迹点小于2")
        }

        // 根据纠偏轨迹，计算里程
        val geometryFactory = JTSFactoryFinder.getGeometryFactory(null)
        val wKTReader = new WKTReader(geometryFactory)

        val time_list = new ListBuffer[Long]
        var disall = 0.0  //全量里程
        var disall_add = 0.0  //全量补充里程
        var distance_in_dept = 0.0  //网点内里程
        var distance_in_dept_add = 0.0  //网点内补充里程

        try {
          for (i <- 0 until tracks.size() - 1) {
            val track1 = tracks.getJSONObject(i)
            val time1 = track1.getLong("time")
            val x1 = track1.getDouble("x")
            val y1 = track1.getDouble("y")
            val coord1 = new Coordinate(x1, y1)
            val point1 = geometryFactory.createPoint(coord1)

            val track2 = tracks.getJSONObject(i + 1)
            val time2 = track2.getLong("time")
            val x2 = track2.getDouble("x")
            val y2 = track2.getDouble("y")
            val coord2 = new Coordinate(x2, y2)
            val point2 = geometryFactory.createPoint(coord2)

            val tmpDis = getDistance(x1, y1, x2, y2)       //单位：米
            time_list.append(time1)
            time_list.append(time2)

            if (tmpDis != 0 && tmpDis <= maxAllowDistance) {
              //全量里程
              disall += tmpDis

              //判断网点内
              val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
              if (chkZc) {
                //网点内里程
                distance_in_dept += tmpDis
              }
            } else if(tmpDis != 0) {
              val subTm = Math.abs(time2 - time1) / (60.0 * 60.0)
              val v = (tmpDis / 1000.0) / subTm
              if (v <= 60) {  // 速度小于60，即速度正常
                if (tmpDis > 3000) {  // 距离S>3km时，调用路径规划接口获取车行距离L

                  val second = Calendar.getInstance().get(Calendar.SECOND)
                  val cur = Calendar.getInstance().get(Calendar.MINUTE)
                  if (cur == lastMin) {
                    timeInt = timeInt + 1
                    if (timeInt >= partitionLimitMinu) {
                      logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
                      Thread.sleep((60 - second) * 1000)
                      http_err.add(s"休眠 =>>  次数： $timeInt + 总数： $partitionsCount")
                    }
                  } else {
                    timeInt = 1
                    lastMin = cur
                  }

                  val origin =  s"$y1,$x1"        // 纬度在前，经度在后
                  val destination =  s"$y2,$x2"  // 纬度在前，经度在后
                  val GetDistReq = String.format(GetDist_URL,origin, destination)
                  // 调用路径规划接口获取车行距离L
                  val byxyResp = MyHttpClientUtils.retryGet(GetDistReq)  // header里放ak
                  val jsonObj = JSON.parseObject(byxyResp)
                  var dist = 0.0
                  try {
                    dist = jsonObj.getJSONObject("result").getDouble("dist")
                  } catch {
                    case e: Exception => ""
                  }

                  logger.error("接口调用完毕 ==> dist = "+dist)
                  //如果接口返回车行距离里程数大于且等于直线距离的2倍，那么以直线距离的2倍作为该段补充的距离
                  if(dist >= tmpDis * 2){
                    dist = tmpDis * 2
                  }

                  //全量里程
                  disall += dist
                  //全量补充里程
                  disall_add += dist
                  //判断网点内
                  val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
                  if (chkZc) {
                    //网点内里程
                    distance_in_dept += dist
                    //网点内补充里程
                    distance_in_dept_add += dist
                  }

                } else {
                  //全量里程
                  disall += tmpDis
                  //全量补充里程
                  disall_add += tmpDis

                  //判断网点内
                  val chkZc = checkInZc(point1, point2, geometryFactory, wKTReader, polygonJson)
                  if (chkZc) {
                    //网点内里程
                    distance_in_dept += tmpDis
                    //网点内补充里程
                    distance_in_dept_add += tmpDis
                  }

                }
              }

            }
          }
        } catch {
          case e: Exception =>
            e.printStackTrace()
          //        val errorMsg = "message=>" + e.fillInStackTrace() + ",stack =>" + e.getStackTrace().mkString(";")
          //        errMsgJsonArr.add(errorMsg)
          //
          //        throw e
        }

        var disall_ret = ""
        var disall_add_ret = ""
        var distance_in_dept_ret = ""
        var distance_in_dept_add_ret = ""
        if(disall != 0.0) disall_ret = (disall / 1000).toString
        if(disall_add != 0.0) disall_add_ret = (disall_add / 1000).toString
        if(distance_in_dept != 0.0) distance_in_dept_ret = (distance_in_dept / 1000).toString
        if(distance_in_dept_add != 0.0) distance_in_dept_add_ret = (distance_in_dept_add / 1000).toString

        var path_start_time = ""
        var path_end_time = ""
        try {
          path_start_time = tmToDate((time_list.min * 1000).toString,"yyyy-MM-dd HH:mm:ss")
          path_end_time = tmToDate((time_list.max * 1000).toString,"yyyy-MM-dd HH:mm:ss")
        } catch {
          case e: Exception => ""
        }

        obj.put("disall",disall_ret)
        obj.put("disall_add",disall_add_ret)
        obj.put("distance_in_dept",distance_in_dept_ret)
        obj.put("distance_in_dept_add",distance_in_dept_add_ret)
        obj.put("path_start_time",path_start_time)
        obj.put("path_end_time",path_end_time)
        obj.put("http_err",http_err.mkString("|"))

        obj
      })
    })

    val df_path_dist = retRdd.map(obj=>{
      val emp_code = JSONUtil.getJsonVal(obj, "un", "")
      val dept_code = JSONUtil.getJsonVal(obj, "bn", "")
      val trajector_source = JSONUtil.getJsonVal(obj, "trajector_source", "")
      val disall = JSONUtil.getJsonVal(obj, "disall", "")
      val disall_add = JSONUtil.getJsonVal(obj, "disall_add", "")
      val distance_in_dept = JSONUtil.getJsonVal(obj, "distance_in_dept", "")
      val distance_in_dept_add = JSONUtil.getJsonVal(obj, "distance_in_dept_add", "")
      val path_start_time = JSONUtil.getJsonVal(obj, "path_start_time", "")
      val path_end_time = JSONUtil.getJsonVal(obj, "path_end_time", "")

      //测试字段
      val byxyResp = JSONUtil.getJsonVal(obj, "http_err", "")

      (emp_code,dept_code,path_start_time,path_end_time,disall,disall_add,distance_in_dept,distance_in_dept_add,trajector_source,byxyResp)
    }).toDF("emp_code","dept_code","path_start_time","path_end_time","disall","disall_add","distance_in_dept","distance_in_dept_add","trajector_source","byxyResp")
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("有休眠的数据量："+df_path_dist.filter('byxyResp.contains("休眠 =>>")).count())
    df_path_dist.filter('byxyResp.contains("休眠 =>>"))
      .select("emp_code","byxyResp")
      .show(200,false)


    val cols_all = spark.sql("""select * from dm_gis.dm_xiaoge_path_distance_dtl_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_path_dist.select(cols_all: _*), Seq("inc_day"), "dm_gis.dm_xiaoge_path_distance_dtl_di")

    df_path_dist.unpersist()

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error("++++++++  任务开始 20231120  +++++++")
    execute(spark,dayBefore1)
    logger.error("++++++++  任务完成 20231120  +++++++")

    spark.stop()

  }

}
