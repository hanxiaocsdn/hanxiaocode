package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.ThaiAOIAndDcAccuracyReport.{getZipCityInfo, logger, saveKey}
import com.sf.gis.app.ThaiDcAccuracyReportMid.{getZipCityInfo, logger}
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.SparkRead.logger
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import java.util.Calendar
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-09-26 16:28
 * @TaskId:856704
 * @TaskName:
 * @Description:0504-0706 zh和chk接口指标监控
 */

object ThaiDcAccuracyReport {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val chkUrl="http://gis-gw.int.os-sgp.local:9080/irdquery/api"
    val zhUrl="http://gis-gw.int.os-sgp.local:9080/irdispatch/api"
    val save0504Key=Array("city_code","county","consignment_no","act_delivery_date","address","address2","postcode_id","destination_dc_code","geo_location","aoiid","aoicode","dc","src","dccode","largedccode","result_data_aoiid","result_data_aoicode","result_data_aoiarea","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_80_xj_dc","interface_data","is_recognize_aoi")
    val save0706Key=Array("city_code","county","booking_no","description","address","address2","soi","road","subdistrict","district","province","mobile_no1","mobile_no2","postcode_id","destination_dc_code","employee_no","geo_location","booking_datetime","aoiid","aoicode","dc","src","dccode","largedccode","result_data_aoiid","result_data_aoicode","result_data_aoiarea","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_80_xj_dc","interface_data","is_recognize_aoi")
    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val mode=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取邮编区域映射信息")
        val postalMapBro: Broadcast[collection.Map[String, String]] = getZipCityInfo(sparkSession)
        logger.error("获取0504运单数据")
        val waybill0504Rdd = get0504WaybillData(sparkSession,start_day)
        logger.error("获取0706运单数据")
        val waybill0706Rdd = get0706WaybillData(sparkSession,start_day)
        if(mode.equals("chk")){
            logger.error("0706运单调用chk服务")
            val waybill0706ChkRdd = calcData(waybill0706Rdd, "0706", "chk",postalMapBro)
            logger.error("0706运单调用chk服务数据存储")
            SparkWrite.save2HiveStaticNew(sparkSession, waybill0706ChkRdd, save0706Key, "dm_gis.thai_0706collect_chk",Array(("inc_day", end_day)), 25)
            logger.error("0504运单调用chk服务")
            val waybill0504ChkRdd = calcData(waybill0504Rdd, "0504", "chk",postalMapBro)
            logger.error("0504运单调用chk服务数据存储")
            SparkWrite.save2HiveStaticNew(sparkSession, waybill0504ChkRdd, save0504Key, "dm_gis.thai_0504delivery_chk",Array(("inc_day", end_day)), 25)
        }else if(mode.equals("zh")){
            logger.error("0706运单调用zh服务")
            val waybill0706ZhRdd = calcData(waybill0706Rdd, "0706", "zh",postalMapBro)
            logger.error("0706运单调用zh服务数据存储")
            SparkWrite.save2HiveStaticNew(sparkSession, waybill0706ZhRdd, save0706Key, "dm_gis.thai_0706collect_zh",Array(("inc_day", end_day)), 25)
            logger.error("0504运单调用zh服务")
            val waybill0504ZhRdd = calcData(waybill0504Rdd, "0504", "zh",postalMapBro)
            logger.error("0504运单调用zh服务数据存储")
            SparkWrite.save2HiveStaticNew(sparkSession, waybill0504ZhRdd, save0504Key, "dm_gis.thai_0504delivery_zh",Array(("inc_day", end_day)), 25)



        }




    }

    def getZipCityInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.thai_postal_city_info
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val postalMap = dataRdd.map(obj => {
            val postal_code = obj.getString("postal_code")
            val city_code = obj.getString("city_code")
            val district = obj.getString("district")
            (postal_code, city_code + "\001" + district)

        }).collectAsMap()
        spark.sparkContext.broadcast(postalMap)

    }
    def get0504WaybillData(spark: SparkSession,start_day:String)={
        var sql=s"select * from dm_gis.thai_0504delivery_location where inc_day='$start_day'"

        sql=
            """
              |
              |select * from dm_gis.thai_waybill_0504_data where address<>'Address'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        dataRdd

    }

    def get0706WaybillData(spark: SparkSession,start_day:String)={
        var sql=s"select * from dm_gis.thai_0706collect_location where inc_day='$start_day'"
        sql=
            """
              |
              |select * from dm_gis.thai_waybill_0706_data where address<>'Address'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        dataRdd

    }
    def getGeoLocationData(dataRdd:RDD[JSONObject],postalMapBro:Broadcast[collection.Map[String, String]])={
        val resultRdd = dataRdd.mapPartitions(x => {
            val postalMap = postalMapBro.value
            val list = new ListBuffer[JSONObject]()
            for (obj <- x) {
                try{
                    val postcode_id = obj.getString("postcode_id")
                    if (postalMap.contains(postcode_id)) {
                        val str = postalMap.get(postcode_id).get.split("\001")
                        if (str.length > 1) {
                            val city_code = str(0)
                            val county = str(1)
                            obj.put("city_code", city_code)
                            obj.put("district", county)
                            obj.put("county", county)

                        }
                    }
                    val geo_location = obj.getString("geo_location")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                        val (aoi_id,aoi_code,zno_code) = getAoiFromInterface(x, y)

                        obj.put("aoiid", aoi_id)
                        obj.put("aoicode", aoi_code)
                        obj.put("dc", zno_code)

                    }

                }catch {case e:Exception=>logger.error(e.getMessage)}

                list += obj
            }
            list.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("落aoi数据量---》"+resultRdd.count())
        resultRdd

    }

    def calcData(dataRdd:RDD[JSONObject],mode:String,urlType:String,postalMapBro:Broadcast[collection.Map[String, String]])={
        val resultRdd = dataRdd.map(obj => {
            val postalMap = postalMapBro.value

            try{
                val parmObj = new JSONObject()
                val destination_dc_code = obj.getString("destination_dc_code")
                val dc = obj.getString("dc")
                //丰图是否识别AOI
                var is_recognize_aoi = "false"
                var is_same_xj_dest_dc = ""
                var is_same_dj_dest_dc = ""
                var is_same_80_xj_dc = ""
                var src=""
                var dcCode=""
                var largeDcCode=""
                var aoi_id=""
                val recipient_address = obj.getString("address")
                val recipient_address2 = obj.getString("address2")
                val recipient_postcode_id = obj.getString("postcode_id")
                parmObj.put("address", recipient_address)
                parmObj.put("address2", recipient_address2)
                parmObj.put("zipcode", recipient_postcode_id)
                parmObj.put("type", "con")
                parmObj.put("extend", "1")

                if (postalMap.contains(recipient_postcode_id)) {
                    val str = postalMap.get(recipient_postcode_id).get.split("\001")
                    if (str.length > 1) {
                        val city_code = str(0)
                        val county = str(1)
                        obj.put("city_code", city_code)
                        obj.put("district", county)
                        obj.put("county", county)

                    }
                }

                if(urlType.equals("chk")){
                    val (srcchk,dcCodechk,largeDcCodechk,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject) = getChkUrlData(parmObj)
                    src=srcchk
                    dcCode=dcCodechk
                    largeDcCode=largeDcCodechk
                    aoi_id=result_data_aoiid
                    obj.put("result_data_aoiid",result_data_aoiid)
                    obj.put("result_data_aoicode",result_data_aoicode)
                    obj.put("result_data_aoiarea",result_data_aoiarea)
                    obj.put("interface_data",jSONObject.toString)
                }else if(urlType.equals("zh")){
                    val (srcchk,dcCodechk,largeDcCodechk,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject) = getZhUrlData(parmObj)
                    src=srcchk
                    dcCode=dcCodechk
                    largeDcCode=largeDcCodechk
                    aoi_id=result_data_aoiid
                    obj.put("result_data_aoiid",result_data_aoiid)
                    obj.put("result_data_aoicode",result_data_aoicode)
                    obj.put("result_data_aoiarea",result_data_aoiarea)
                    obj.put("interface_data",jSONObject.toString)
                }

                if(StringUtils.nonEmpty(aoi_id)){
                    is_recognize_aoi="true"
                }
                if (StringUtils.nonEmpty(dcCode) && StringUtils.nonEmpty(destination_dc_code) && dcCode.equals(destination_dc_code)) {
                    is_same_xj_dest_dc = "true"

                } else {
                    is_same_xj_dest_dc = "false"
                }
                if (StringUtils.nonEmpty(largeDcCode) && StringUtils.nonEmpty(destination_dc_code) && largeDcCode.equals(destination_dc_code)) {
                    is_same_dj_dest_dc = "true"

                } else {
                    is_same_dj_dest_dc = "false"
                }

                if (StringUtils.nonEmpty(dc) && StringUtils.nonEmpty(dcCode) && dc.equals(dcCode)) {
                    is_same_80_xj_dc = "true"

                } else {
                    is_same_80_xj_dc = "false"
                }

                obj.put("src", src)
                obj.put("dccode", dcCode)
                obj.put("largedccode", largeDcCode)
                obj.put("is_recognize_aoi", is_recognize_aoi)
                obj.put("is_same_xj_dest_dc", is_same_xj_dest_dc)
                obj.put("is_same_dj_dest_dc", is_same_dj_dest_dc)
                obj.put("is_same_80_xj_dc", is_same_80_xj_dc)

            }catch {case e:Exception=>logger.error(e.printStackTrace())}


            obj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("查询的总数据量:" + resultRdd.count())
        resultRdd


    }


    def getChkUrlData(parm:JSONObject): (String, String, String, String, String, String, JSONObject) ={
        var nowHour = getHour()
//        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
//            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
//            Thread.sleep(1000*60)
//            nowHour = getHour()
//
//        }
        var src=""
        var dcCode=""
        var largeDcCode=""
        var result_data_aoiid=""
        var result_data_aoicode=""
        var result_data_aoiarea=""
        var jSONObject =new JSONObject()

        if(parm.size()<1){
            return (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)
        }
        Thread.sleep(260)
        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","d24c4f5652ea40e893c482bacfbd472b")
        breakable {
            for(i<-0 until(3)){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(chkUrl, parm, stringToString))
                }
                catch {
                    case _=>{
                        logger.error("error parameter-----> "+parm.toString())
                        new JSONObject()
                    }
                }
                val status = JSONUtil.getJsonVal(jSONObject, "status", "")
                val msg = JSONUtil.getJsonVal(jSONObject, "result.msg", "")
                if(StringUtils.nonEmpty(status)&&status.equals("0")){
                    break
                }else{
                    if(msg.contains("many")&&msg.contains("too")){
                        Thread.sleep(30000)
                    }else{
                        break
                    }

                }
            }

        }


        src = JSONUtil.getJsonVal(jSONObject, "result.data.src", "")
        dcCode = JSONUtil.getJsonVal(jSONObject, "result.data.dcCode", "")
        largeDcCode = JSONUtil.getJsonVal(jSONObject, "result.data.largeDcCode", "")
        result_data_aoiid=JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        result_data_aoicode=JSONUtil.getJsonVal(jSONObject, "result.data.aoiCode", "")
        result_data_aoiarea=JSONUtil.getJsonVal(jSONObject, "result.data.aoiArea", "")
        (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)

    }

    def getZhUrlData(parm:JSONObject): (String, String, String, String, String, String, JSONObject) ={

//        var nowHour = getHour()
//        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
//            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
//            Thread.sleep(1000*60)
//            nowHour = getHour()
//
//        }
        var src=""
        var dcCode=""
        var largeDcCode=""
        var result_data_aoiid=""
        var result_data_aoicode=""
        var result_data_aoiarea=""
        var jSONObject =new JSONObject()

        if(parm.size()<1){
            return (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)
        }
        Thread.sleep(240)
        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","d24c4f5652ea40e893c482bacfbd472b")
        breakable {
            for(i<-0 until(3)){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(zhUrl, parm, stringToString))
                }
                catch {
                    case _=>{
                        logger.error("error parameter-----> "+parm.toString())
                        new JSONObject()
                    }
                }
                val status = JSONUtil.getJsonVal(jSONObject, "status", "")
                val msg = JSONUtil.getJsonVal(jSONObject, "result.msg", "")

                if(StringUtils.nonEmpty(status)&&status.equals("0")){
                    break
                }else{
                    if(msg.contains("many")&&msg.contains("too")){
                        Thread.sleep(10000)
                    }else{
                        break
                    }

                }
            }

        }


        src = JSONUtil.getJsonVal(jSONObject, "result.data.src", "")
        dcCode = JSONUtil.getJsonVal(jSONObject, "result.data.dcCode", "")
        largeDcCode = JSONUtil.getJsonVal(jSONObject, "result.data.largeDcCode", "")
        result_data_aoiid=JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        result_data_aoicode=JSONUtil.getJsonVal(jSONObject, "result.data.aoiCode", "")
        result_data_aoiarea=JSONUtil.getJsonVal(jSONObject, "result.data.aoiArea", "")
        (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)

    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        var nowHour = getHour()
        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
            Thread.sleep(1000*60)
            nowHour = getHour()

        }

        Thread.sleep(500)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }

}
