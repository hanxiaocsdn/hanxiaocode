package com.sf.gis.utils

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2020/7/27.
  */
object SparkRead {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
    * 执行spark sql
    *
    * @param sparkSession
    * @param sql : sql语句
    * @return 数据数组集，列名数组
    */
  def readHiveAsRow(sparkSession: SparkSession, sql: String,repartitions:Int=0): (RDD[Row], Array[String]) = {
    val df = sparkSession.sql(sql)
    val columns = df.columns
    logger.error("列名:" + columns.mkString(","))
    var partition = repartitions
    val tmpPartitions = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"))*  Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    if(partition==0 ){
      partition =  tmpPartitions*4
    }
    val dataRdd = df.rdd.repartition(partition).map(obj => {
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("查询的总数据量:" + dataRdd.count())
    (dataRdd, columns)
  }

  /**
    * 执行spark sql
    *
    * @param sparkSession
    * @param sql : sql语句
    * @return 数据Json集，列名数组
    */
  def readHiveAsJson(sparkSession: SparkSession, sql: String,repartitions:Int=0): (RDD[JSONObject], Array[String]) = {
    val df = sparkSession.sql(sql)
    val columns = df.columns
    logger.error("列名:" + columns.mkString(","))
    var partition = repartitions
    val tmpPartitions = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"))*  Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    if(partition==0 ){
      partition = tmpPartitions*4
    }
    var dataRdd:RDD[JSONObject] = null;
    if(partition == -1){
      dataRdd = df.rdd.map(obj => {
        val jObj = new JSONObject()
        for (i <- columns.indices) {
          jObj.put(columns(i), obj.getString(i))
        }
        jObj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    }else{
      dataRdd = df.rdd.repartition(partition).map(obj => {
        val jObj = new JSONObject()
        for (i <- columns.indices) {
          jObj.put(columns(i), obj.getString(i))
        }
        jObj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    }
    logger.error("查询的总数据量:" + dataRdd.count())
    (dataRdd, columns)
  }


  /**
   * 执行spark sql
   *
   * @param sparkSession
   * @param sql : sql语句
   * @return 数据Json集，列名数组
   */
  def readHiveAsJsonNew(sparkSession: SparkSession, sql: String,repartitions:Int=0): (RDD[JSONObject], Array[String]) = {
    val df = sparkSession.sql(sql)
    logger.error("sql---》查询总数据量"+df.count())
    val columns = df.columns
    logger.error("列名:" + columns.mkString(","))
    var dataRdd:RDD[JSONObject] = null;
    dataRdd = df.rdd.map(obj => {
      val jObj = new JSONObject()
      for (i <- columns.indices) {
        jObj.put(columns(i), obj.getString(i))
      }
      jObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("查询的总数据量:" + dataRdd.count())
    (dataRdd, columns)
  }


  /* 读取csv文件,输出dataFrame
  * @param sparkSession
  * @param fileName: 文件路径,本地路径/hdfs路径
  * @return 输出数组型的RDD数据, 表头数组
  */
  def readCsvAsRow(sparkSession: SparkSession, filePath: String, encoding: String = "utf8", seq: String = "\t", header: Boolean = true): (RDD[Row], Array[String]) = {
    val df = sparkSession.read.option("header", header)
      .option("encoding", encoding).option("sep", seq).csv(filePath)
    val headers = df.columns
    val dataRdd = df.rdd.map(obj => {
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("文件读取数据量:" + dataRdd.count())
    (dataRdd, headers)
  }

  /* 读取csv文件,输出JSON
  * @param sparkSession
  * @param fileName: 文件路径,本地路径/hdfs路径
  * @return 输出JSONObject型的RDD数据, 表头数组
  */
  def readCsvAsJson(sparkSession: SparkSession, filePath: String, encoding: String = "utf8", seq: String = "\t", header: Boolean = true): (RDD[JSONObject], Array[String]) = {
    val df = sparkSession.read.option("header", header)
      .option("encoding", encoding).option("sep", seq).csv(filePath)
    val headers = df.columns
    logger.error("标题:" + headers.mkString(","))
    val headerBc = sparkSession.sparkContext.broadcast(headers)
    val dataRdd = df.rdd.map(obj => {
      val json = new JSONObject()
      val headerValue = headerBc.value
      for (i <- headerValue.indices) {
        json.put(headerValue.apply(i), obj.getString(i))
      }
      json
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("文件读取数据量:" + dataRdd.count())
    (dataRdd, headers)
  }


}
