package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-03 09:33
 * @TaskId:784592
 * @TaskName:
 * @Description:chk派日志解析
 */

object ChkPaiLogParse {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("input_param_waybill_no","input_param_order_no","input_param_source_city_code","input_param_dest_city_code","input_param_addressee_contacts","input_param_addressee_phone","input_param_addressee_mobile","input_param_receiver_mobile2","input_param_input_emp_code","input_param_addressee_comp_name","input_param_receiver_province","input_param_receiver_city","input_param_receiver_area","input_param_receiver_addr","input_param_receiver_addr2","input_param_receiver_road","input_param_receiver_soi","input_param_receiver_postal_code","input_param_send_time","input_param_send_time_ts","input_param_product_code","input_param_limit_type_code","input_param_cargo_type_code","input_param_express_type_code","input_param_source_province","input_param_source_city","input_param_source_area","input_param_source_road","input_param_source_soi","input_param_source_addr","input_param_source_addr2","input_param_source_contacts","input_param_source_mobile","input_param_source_mobile2","input_param_source_phone","input_param_source_postal_code","out_param_addressee_aoi_area","out_param_addressee_aoi_area_group","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_aoi_type","out_param_addressee_city_code","out_param_addressee_dept_code","out_param_addressee_dept_group","out_param_addressee_transit_code","out_param_order_no","out_param_receiver_addr","out_param_receiver_addr2","out_param_receiver_area","out_param_receiver_city","out_param_receiver_province","out_param_receiver_road","out_param_receiver_soi","out_param_request_id","out_param_resp_time","out_param_source_aoi_area","out_param_source_aoi_code","out_param_source_aoi_id","out_param_source_dept_code","out_param_source_transit_code","out_param_waybill_no","dest_input_param","dest_output_param","source_input_param","source_output_param","log","region")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("解析日志")
        val resultRdd = parseLog(sparkSession, end_day)
        logger.error("存储数据日志")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.obs_chk_pai_log_parse_data",Array(("inc_day", end_day)), 25)


    }

    def parseLog(spark: SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |select log from dm_gis.obs_chk_pai_log where inc_day='$end_day' group by log
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        val allLog = dataRdd.map(obj => {
            val log = obj.getString("log")
            //标记日志
            markLog(log, "dest", "CHKQUERY-DEST", obj)
            markLog(log, "source", "CHKQUERY-SOURCE", obj)
            markLog(log, "push", "OmsResProducer", obj)
            markLog(log, "consumer", "OmsConsumer", obj)


            obj
        })

        val destLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("dest")).map(obj => (obj.getString("logKey"), obj))
        val sourceLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("source")).map(obj => (obj.getString("logKey"), obj))
        val pushLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("push")).map(obj => (obj.getString("logKey"), obj))
        val consumerLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("consumer")).map(obj => (obj.getString("logKey"), obj))
        val destAndSourceRdd = destLogRdd.leftOuterJoin(sourceLogRdd).map(x => {
            val dataObj = new JSONObject()
            val logKey = x._1
            val destLog = x._2._1
            val sourceLog = x._2._2
            if (!destLog.isEmpty) {
                if (sourceLog.nonEmpty) {
                    try {
                        val destLogData = destLog.getString("log")
                        val destArr = JSON.parseObject(destLogData)
                        dataObj.put("dest_input_param", destArr.getJSONObject("arg").toString)
                        dataObj.put("dest_output_param", destArr.getJSONObject("res").getJSONObject("DEST").toString)

                        val sourceLogData = sourceLog.get.getString("log")
                        val sourceArr = JSON.parseObject(sourceLogData)
                        dataObj.put("source_input_param", sourceArr.getJSONObject("arg").toString)
                        dataObj.put("source_output_param", sourceArr.getJSONObject("res").getJSONObject("SOURCE").toString)
                        dataObj.put("log",destLogData+"\001"+sourceLogData)


                    } catch {
                        case e: Exception => {
                            dataObj.put("log",e.printStackTrace())
                        }
                    }

                }
            }

            (logKey, dataObj)


        })

        val resultRdd = destAndSourceRdd.leftOuterJoin(pushLogRdd).map(x => {
            val logKey = x._1
            val obj = x._2._1
            val pushLog = x._2._2
            if (!obj.isEmpty) {
                if (pushLog.nonEmpty) {
                    try{

                        val pushObj = JSON.parseObject(pushLog.get.getString("log")).getJSONObject("res")
                        val addressee_aoi_area = JSONUtil.getJsonVal(pushObj, "addresseeAoiArea", "")
                        val addressee_aoi_area_group = JSONUtil.getJsonVal(pushObj, "addresseeAoiAreaGroup", "")
                        val addressee_aoi_code = JSONUtil.getJsonVal(pushObj, "addresseeAoiCode", "")
                        val addressee_aoi_id = JSONUtil.getJsonVal(pushObj, "addresseeAoiId", "")
                        val addressee_aoi_type = JSONUtil.getJsonVal(pushObj, "addresseeAoiType", "")
                        val addressee_city_code = JSONUtil.getJsonVal(pushObj, "addresseeCityCode", "")
                        val addressee_dept_code = JSONUtil.getJsonVal(pushObj, "addresseeDeptCode", "")
                        val addressee_dept_group = JSONUtil.getJsonVal(pushObj, "addresseeDeptGroup", "")
                        val addressee_transit_code = JSONUtil.getJsonVal(pushObj, "addresseeTransitCode", "")
                        val order_no = JSONUtil.getJsonVal(pushObj, "orderNo", "")
                        val receiver_addr = JSONUtil.getJsonVal(pushObj, "receiverAddr", "")
                        val receiver_addr2 = JSONUtil.getJsonVal(pushObj, "receiverAddr2", "")
                        val receiver_area = JSONUtil.getJsonVal(pushObj, "receiverArea", "")
                        val receiver_city = JSONUtil.getJsonVal(pushObj, "receiverCity", "")
                        val receiver_province = JSONUtil.getJsonVal(pushObj, "receiverProvince", "")
                        val receiver_road = JSONUtil.getJsonVal(pushObj, "receiverRoad", "")
                        val receiver_soi = JSONUtil.getJsonVal(pushObj, "receiverSoi", "")
                        val request_id = JSONUtil.getJsonVal(pushObj, "requestId", "")
                        val resp_time = JSONUtil.getJsonVal(pushObj, "respTime", "")
                        val source_aoi_area = JSONUtil.getJsonVal(pushObj, "sourceAoiArea", "")
                        val source_aoi_code = JSONUtil.getJsonVal(pushObj, "sourceAoiCode", "")
                        val source_aoi_id = JSONUtil.getJsonVal(pushObj, "sourceAoiId", "")
                        val source_dept_code = JSONUtil.getJsonVal(pushObj, "sourceDeptCode", "")
                        val source_transit_code = JSONUtil.getJsonVal(pushObj, "sourceTransitCode", "")
                        val waybill_no = JSONUtil.getJsonVal(pushObj, "waybillNo", "")

                        obj.put("out_param_addressee_aoi_area", addressee_aoi_area)
                        obj.put("out_param_addressee_aoi_area_group", addressee_aoi_area_group)
                        obj.put("out_param_addressee_aoi_code", addressee_aoi_code)
                        obj.put("out_param_addressee_aoi_id", addressee_aoi_id)
                        obj.put("out_param_addressee_aoi_type", addressee_aoi_type)
                        obj.put("out_param_addressee_city_code", addressee_city_code)
                        obj.put("out_param_addressee_dept_code", addressee_dept_code)
                        obj.put("out_param_addressee_dept_group", addressee_dept_group)
                        obj.put("out_param_addressee_transit_code", addressee_transit_code)
                        obj.put("out_param_order_no", order_no)
                        obj.put("out_param_receiver_addr", receiver_addr)
                        obj.put("out_param_receiver_addr2", receiver_addr2)
                        obj.put("out_param_receiver_area", receiver_area)
                        obj.put("out_param_receiver_city", receiver_city)
                        obj.put("out_param_receiver_province", receiver_province)
                        obj.put("out_param_receiver_road", receiver_road)
                        obj.put("out_param_receiver_soi", receiver_soi)
                        obj.put("out_param_request_id", request_id)
                        obj.put("out_param_resp_time", resp_time)
                        obj.put("out_param_source_aoi_area", source_aoi_area)
                        obj.put("out_param_source_aoi_code", source_aoi_code)
                        obj.put("out_param_source_aoi_id", source_aoi_id)
                        obj.put("out_param_source_dept_code", source_dept_code)
                        obj.put("out_param_source_transit_code", source_transit_code)
                        obj.put("out_param_waybill_no", waybill_no)

                        obj.put("log", obj.getString("log") + "\001" + pushLog.get.getString("log"))


                    }catch {
                        case e: Exception => {
                            obj.put("log",e.printStackTrace())
                        }
                    }



                }

            }

            (logKey, obj)


        }).leftOuterJoin(consumerLogRdd).map(x => {
            val obj = x._2._1
            if (!obj.isEmpty) {
                if (x._2._2.nonEmpty) {
                    try{

                        val pushObj = JSON.parseObject(x._2._2.get.getString("log")).getJSONObject("arg")
                        val input_param_waybill_no = JSONUtil.getJsonVal(pushObj, "waybillNo", "")
                        val region = JSONUtil.getJsonVal(pushObj, "region", "")
                        val input_param_order_no = JSONUtil.getJsonVal(pushObj, "orderNo", "")
                        val input_param_source_city_code = JSONUtil.getJsonVal(pushObj, "sourceCityCode", "")
                        val input_param_dest_city_code = JSONUtil.getJsonVal(pushObj, "destCityCode", "")
                        val input_param_addressee_contacts = JSONUtil.getJsonVal(pushObj, "addresseeContacts", "")
                        val input_param_addressee_phone = JSONUtil.getJsonVal(pushObj, "addresseePhone", "")
                        val input_param_addressee_mobile = JSONUtil.getJsonVal(pushObj, "addresseeMobile", "")
                        val input_param_receiver_mobile2 = JSONUtil.getJsonVal(pushObj, "receiverMobile2", "")
                        val input_param_input_emp_code = JSONUtil.getJsonVal(pushObj, "inputEmpCode", "")
                        val input_param_addressee_comp_name = JSONUtil.getJsonVal(pushObj, "addresseeCompName", "")
                        val input_param_receiver_province = JSONUtil.getJsonVal(pushObj, "receiverProvince", "")
                        val input_param_receiver_city = JSONUtil.getJsonVal(pushObj, "receiverCity", "")
                        val input_param_receiver_area = JSONUtil.getJsonVal(pushObj, "receiverArea", "")
                        val input_param_receiver_addr = JSONUtil.getJsonVal(pushObj, "receiverAddr", "")
                        val input_param_receiver_addr2 = JSONUtil.getJsonVal(pushObj, "receiverAddr2", "")
                        val input_param_receiver_road = JSONUtil.getJsonVal(pushObj, "receiverRoad", "")
                        val input_param_receiver_soi = JSONUtil.getJsonVal(pushObj, "receiverSoi", "")
                        val input_param_receiver_postal_code = JSONUtil.getJsonVal(pushObj, "receiverPostalCode", "")
                        val input_param_send_time = JSONUtil.getJsonVal(pushObj, "sendTime", "")
                        val input_param_send_time_ts = JSONUtil.getJsonVal(pushObj, "sendTimeTs", "")
                        val input_param_product_code = JSONUtil.getJsonVal(pushObj, "productCode", "")
                        val input_param_limit_type_code = JSONUtil.getJsonVal(pushObj, "limitTypeCode", "")
                        val input_param_cargo_type_code = JSONUtil.getJsonVal(pushObj, "cargoTypeCode", "")
                        val input_param_express_type_code = JSONUtil.getJsonVal(pushObj, "expressTypeCode", "")
                        val input_param_source_province = JSONUtil.getJsonVal(pushObj, "sourceProvince", "")
                        val input_param_source_city = JSONUtil.getJsonVal(pushObj, "sourceCity", "")
                        val input_param_source_area = JSONUtil.getJsonVal(pushObj, "sourceArea", "")
                        val input_param_source_road = JSONUtil.getJsonVal(pushObj, "sourceRoad", "")
                        val input_param_source_soi = JSONUtil.getJsonVal(pushObj, "sourceSoi", "")
                        val input_param_source_addr = JSONUtil.getJsonVal(pushObj, "sourceAddr", "")
                        val input_param_source_addr2 = JSONUtil.getJsonVal(pushObj, "sourceAddr2", "")
                        val input_param_source_contacts = JSONUtil.getJsonVal(pushObj, "sourceContacts", "")
                        val input_param_source_mobile = JSONUtil.getJsonVal(pushObj, "sourceMobile", "")
                        val input_param_source_mobile2 = JSONUtil.getJsonVal(pushObj, "sourceMobile2", "")
                        val input_param_source_phone = JSONUtil.getJsonVal(pushObj, "sourcePhone", "")
                        val input_param_source_postal_code = JSONUtil.getJsonVal(pushObj, "sourcePostalCode", "")

                        obj.put("input_param_waybill_no", input_param_waybill_no)
                        obj.put("input_param_order_no", input_param_order_no)
                        obj.put("input_param_source_city_code", input_param_source_city_code)
                        obj.put("input_param_dest_city_code", input_param_dest_city_code)
                        obj.put("input_param_addressee_contacts", input_param_addressee_contacts)
                        obj.put("input_param_addressee_phone", input_param_addressee_phone)
                        obj.put("input_param_addressee_mobile", input_param_addressee_mobile)
                        obj.put("input_param_receiver_mobile2", input_param_receiver_mobile2)
                        obj.put("input_param_input_emp_code", input_param_input_emp_code)
                        obj.put("input_param_addressee_comp_name", input_param_addressee_comp_name)
                        obj.put("input_param_receiver_province", input_param_receiver_province)
                        obj.put("input_param_receiver_city", input_param_receiver_city)
                        obj.put("input_param_receiver_area", input_param_receiver_area)
                        obj.put("input_param_receiver_addr", input_param_receiver_addr)
                        obj.put("input_param_receiver_addr2", input_param_receiver_addr2)
                        obj.put("input_param_receiver_road", input_param_receiver_road)
                        obj.put("input_param_receiver_soi", input_param_receiver_soi)
                        obj.put("input_param_receiver_postal_code", input_param_receiver_postal_code)
                        obj.put("input_param_send_time", input_param_send_time)
                        obj.put("input_param_send_time_ts", input_param_send_time_ts)
                        obj.put("input_param_product_code", input_param_product_code)
                        obj.put("input_param_limit_type_code", input_param_limit_type_code)
                        obj.put("input_param_cargo_type_code", input_param_cargo_type_code)
                        obj.put("input_param_express_type_code", input_param_express_type_code)
                        obj.put("input_param_source_province", input_param_source_province)
                        obj.put("input_param_source_city", input_param_source_city)
                        obj.put("input_param_source_area", input_param_source_area)
                        obj.put("input_param_source_road", input_param_source_road)
                        obj.put("input_param_source_soi", input_param_source_soi)
                        obj.put("input_param_source_addr", input_param_source_addr)
                        obj.put("input_param_source_addr2", input_param_source_addr2)
                        obj.put("input_param_source_contacts", input_param_source_contacts)
                        obj.put("input_param_source_mobile", input_param_source_mobile)
                        obj.put("input_param_source_mobile2", input_param_source_mobile2)
                        obj.put("input_param_source_phone", input_param_source_phone)
                        if(StringUtils.nonEmpty(region)){
                            obj.put("region",region)
                        }else{
                            obj.put("region","TH")
                        }
                        obj.put("input_param_source_postal_code", input_param_source_postal_code)
                        obj.put("log", obj.getString("log") + "\001" + x._2._2.get.getString("log"))



                    }catch {
                        case e: Exception => {
                            obj.put("log",e.printStackTrace())
                        }
                    }


                }

            }
            obj

        }).distinct()
        resultRdd




    }



    def parseOldLog(spark: SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |select log from dm_gis.obs_chk_pai_log where inc_day='$end_day' group by log
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        val allLog = dataRdd.map(obj => {
            val log = obj.getString("log")
            //标记日志
            markOldLog(log, "dest", "目的地", obj)
            markOldLog(log, "source", "原寄地", obj)
            markOldLog(log, "push", "推送数据", obj)
            markOldLog(log, "consumer", "消费数据", obj)


            obj
        })

        val destLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("dest")).map(obj => (obj.getString("logKey"), obj))
        val sourceLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("source")).map(obj => (obj.getString("logKey"), obj))
        val pushLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("push")).map(obj => (obj.getString("logKey"), obj))
        val consumerLogRdd = allLog.filter(obj => StringUtils.nonEmpty(obj.getString("markKey")) && obj.getString("markKey").equals("consumer")).map(obj => (obj.getString("logKey"), obj))
        val destAndSourceRdd = destLogRdd.leftOuterJoin(sourceLogRdd).map(x => {
            val dataObj = new JSONObject()
            val logKey = x._1
            val destLog = x._2._1
            val sourceLog = x._2._2
            if (!destLog.isEmpty) {
                if (sourceLog.nonEmpty) {
                    try {
                        val destLogData = destLog.getString("log")

                        val destArr = JSON.parseArray("["+destLogData.split("目的地:")(1)+"]")
                        dataObj.put("dest_input_param", destArr.getJSONObject(0).toString)
                        dataObj.put("dest_output_param", destArr.getJSONObject(1).getJSONObject("DEST").toString)

                        val sourceLogData = sourceLog.get.getString("log")

                        val sourceArr = JSON.parseArray("["+sourceLogData.split("原寄地:")(1)+"]")
                        dataObj.put("source_input_param", sourceArr.getJSONObject(0).toString)
                        dataObj.put("source_output_param", sourceArr.getJSONObject(1).getJSONObject("SOURCE").toString)
                        dataObj.put("log",destLogData+"\001"+sourceLogData)


                    } catch {
                        case e: Exception => {
                            dataObj.put("log",e.printStackTrace())
                        }
                    }

                }
            }

            (logKey, dataObj)


        })

        val resultRdd = destAndSourceRdd.leftOuterJoin(pushLogRdd).map(x => {
            val logKey = x._1
            val obj = x._2._1
            val pushLog = x._2._2
            if (!obj.isEmpty) {
                if (pushLog.nonEmpty) {
                    try{

                        val pushObj = JSON.parseObject(pushLog.get.getString("log").split("推送数据:")(1).split(",耗时")(0))
                        val addressee_aoi_area = JSONUtil.getJsonVal(pushObj, "addresseeAoiArea", "")
                        val addressee_aoi_area_group = JSONUtil.getJsonVal(pushObj, "addresseeAoiAreaGroup", "")
                        val addressee_aoi_code = JSONUtil.getJsonVal(pushObj, "addresseeAoiCode", "")
                        val addressee_aoi_id = JSONUtil.getJsonVal(pushObj, "addresseeAoiId", "")
                        val addressee_aoi_type = JSONUtil.getJsonVal(pushObj, "addresseeAoiType", "")
                        val addressee_city_code = JSONUtil.getJsonVal(pushObj, "addresseeCityCode", "")
                        val addressee_dept_code = JSONUtil.getJsonVal(pushObj, "addresseeDeptCode", "")
                        val addressee_dept_group = JSONUtil.getJsonVal(pushObj, "addresseeDeptGroup", "")
                        val addressee_transit_code = JSONUtil.getJsonVal(pushObj, "addresseeTransitCode", "")
                        val order_no = JSONUtil.getJsonVal(pushObj, "orderNo", "")
                        val receiver_addr = JSONUtil.getJsonVal(pushObj, "receiverAddr", "")
                        val receiver_addr2 = JSONUtil.getJsonVal(pushObj, "receiverAddr2", "")
                        val receiver_area = JSONUtil.getJsonVal(pushObj, "receiverArea", "")
                        val receiver_city = JSONUtil.getJsonVal(pushObj, "receiverCity", "")
                        val receiver_province = JSONUtil.getJsonVal(pushObj, "receiverProvince", "")
                        val receiver_road = JSONUtil.getJsonVal(pushObj, "receiverRoad", "")
                        val receiver_soi = JSONUtil.getJsonVal(pushObj, "receiverSoi", "")
                        val request_id = JSONUtil.getJsonVal(pushObj, "requestId", "")
                        val resp_time = JSONUtil.getJsonVal(pushObj, "respTime", "")
                        val source_aoi_area = JSONUtil.getJsonVal(pushObj, "sourceAoiArea", "")
                        val source_aoi_code = JSONUtil.getJsonVal(pushObj, "sourceAoiCode", "")
                        val source_aoi_id = JSONUtil.getJsonVal(pushObj, "sourceAoiId", "")
                        val source_dept_code = JSONUtil.getJsonVal(pushObj, "sourceDeptCode", "")
                        val source_transit_code = JSONUtil.getJsonVal(pushObj, "sourceTransitCode", "")
                        val waybill_no = JSONUtil.getJsonVal(pushObj, "waybillNo", "")

                        obj.put("out_param_addressee_aoi_area", addressee_aoi_area)
                        obj.put("out_param_addressee_aoi_area_group", addressee_aoi_area_group)
                        obj.put("out_param_addressee_aoi_code", addressee_aoi_code)
                        obj.put("out_param_addressee_aoi_id", addressee_aoi_id)
                        obj.put("out_param_addressee_aoi_type", addressee_aoi_type)
                        obj.put("out_param_addressee_city_code", addressee_city_code)
                        obj.put("out_param_addressee_dept_code", addressee_dept_code)
                        obj.put("out_param_addressee_dept_group", addressee_dept_group)
                        obj.put("out_param_addressee_transit_code", addressee_transit_code)
                        obj.put("out_param_order_no", order_no)
                        obj.put("out_param_receiver_addr", receiver_addr)
                        obj.put("out_param_receiver_addr2", receiver_addr2)
                        obj.put("out_param_receiver_area", receiver_area)
                        obj.put("out_param_receiver_city", receiver_city)
                        obj.put("out_param_receiver_province", receiver_province)
                        obj.put("out_param_receiver_road", receiver_road)
                        obj.put("out_param_receiver_soi", receiver_soi)
                        obj.put("out_param_request_id", request_id)
                        obj.put("out_param_resp_time", resp_time)
                        obj.put("out_param_source_aoi_area", source_aoi_area)
                        obj.put("out_param_source_aoi_code", source_aoi_code)
                        obj.put("out_param_source_aoi_id", source_aoi_id)
                        obj.put("out_param_source_dept_code", source_dept_code)
                        obj.put("out_param_source_transit_code", source_transit_code)
                        obj.put("out_param_waybill_no", waybill_no)

                        obj.put("log", obj.getString("log") + "\001" + pushLog.get.getString("log"))


                    }catch {
                        case e: Exception => {
                            obj.put("log",e.printStackTrace())
                        }
                    }



                }

            }

            (logKey, obj)


        }).leftOuterJoin(consumerLogRdd).map(x => {
            val obj = x._2._1
            if (!obj.isEmpty) {
                if (x._2._2.nonEmpty) {
                    try{

                        val pushObj = JSON.parseObject(x._2._2.get.getString("log").split("消费数据:")(1).split(",耗时")(0))
                        val input_param_waybill_no = JSONUtil.getJsonVal(pushObj, "waybillNo", "")
                        val input_param_order_no = JSONUtil.getJsonVal(pushObj, "orderNo", "")
                        val input_param_source_city_code = JSONUtil.getJsonVal(pushObj, "sourceCityCode", "")
                        val input_param_dest_city_code = JSONUtil.getJsonVal(pushObj, "destCityCode", "")
                        val input_param_addressee_contacts = JSONUtil.getJsonVal(pushObj, "addresseeContacts", "")
                        val input_param_addressee_phone = JSONUtil.getJsonVal(pushObj, "addresseePhone", "")
                        val input_param_addressee_mobile = JSONUtil.getJsonVal(pushObj, "addresseeMobile", "")
                        val input_param_receiver_mobile2 = JSONUtil.getJsonVal(pushObj, "receiverMobile2", "")
                        val input_param_input_emp_code = JSONUtil.getJsonVal(pushObj, "inputEmpCode", "")
                        val input_param_addressee_comp_name = JSONUtil.getJsonVal(pushObj, "addresseeCompName", "")
                        val input_param_receiver_province = JSONUtil.getJsonVal(pushObj, "receiverProvince", "")
                        val input_param_receiver_city = JSONUtil.getJsonVal(pushObj, "receiverCity", "")
                        val input_param_receiver_area = JSONUtil.getJsonVal(pushObj, "receiverArea", "")
                        val input_param_receiver_addr = JSONUtil.getJsonVal(pushObj, "receiverAddr", "")
                        val input_param_receiver_addr2 = JSONUtil.getJsonVal(pushObj, "receiverAddr2", "")
                        val input_param_receiver_road = JSONUtil.getJsonVal(pushObj, "receiverRoad", "")
                        val input_param_receiver_soi = JSONUtil.getJsonVal(pushObj, "receiverSoi", "")
                        val input_param_receiver_postal_code = JSONUtil.getJsonVal(pushObj, "receiverPostalCode", "")
                        val input_param_send_time = JSONUtil.getJsonVal(pushObj, "sendTime", "")
                        val input_param_send_time_ts = JSONUtil.getJsonVal(pushObj, "sendTimeTs", "")
                        val input_param_product_code = JSONUtil.getJsonVal(pushObj, "productCode", "")
                        val input_param_limit_type_code = JSONUtil.getJsonVal(pushObj, "limitTypeCode", "")
                        val input_param_cargo_type_code = JSONUtil.getJsonVal(pushObj, "cargoTypeCode", "")
                        val input_param_express_type_code = JSONUtil.getJsonVal(pushObj, "expressTypeCode", "")
                        val input_param_source_province = JSONUtil.getJsonVal(pushObj, "sourceProvince", "")
                        val input_param_source_city = JSONUtil.getJsonVal(pushObj, "sourceCity", "")
                        val input_param_source_area = JSONUtil.getJsonVal(pushObj, "sourceArea", "")
                        val input_param_source_road = JSONUtil.getJsonVal(pushObj, "sourceRoad", "")
                        val input_param_source_soi = JSONUtil.getJsonVal(pushObj, "sourceSoi", "")
                        val input_param_source_addr = JSONUtil.getJsonVal(pushObj, "sourceAddr", "")
                        val input_param_source_addr2 = JSONUtil.getJsonVal(pushObj, "sourceAddr2", "")
                        val input_param_source_contacts = JSONUtil.getJsonVal(pushObj, "sourceContacts", "")
                        val input_param_source_mobile = JSONUtil.getJsonVal(pushObj, "sourceMobile", "")
                        val input_param_source_mobile2 = JSONUtil.getJsonVal(pushObj, "sourceMobile2", "")
                        val input_param_source_phone = JSONUtil.getJsonVal(pushObj, "sourcePhone", "")
                        val input_param_source_postal_code = JSONUtil.getJsonVal(pushObj, "sourcePostalCode", "")

                        obj.put("input_param_waybill_no", input_param_waybill_no)
                        obj.put("input_param_order_no", input_param_order_no)
                        obj.put("input_param_source_city_code", input_param_source_city_code)
                        obj.put("input_param_dest_city_code", input_param_dest_city_code)
                        obj.put("input_param_addressee_contacts", input_param_addressee_contacts)
                        obj.put("input_param_addressee_phone", input_param_addressee_phone)
                        obj.put("input_param_addressee_mobile", input_param_addressee_mobile)
                        obj.put("input_param_receiver_mobile2", input_param_receiver_mobile2)
                        obj.put("input_param_input_emp_code", input_param_input_emp_code)
                        obj.put("input_param_addressee_comp_name", input_param_addressee_comp_name)
                        obj.put("input_param_receiver_province", input_param_receiver_province)
                        obj.put("input_param_receiver_city", input_param_receiver_city)
                        obj.put("input_param_receiver_area", input_param_receiver_area)
                        obj.put("input_param_receiver_addr", input_param_receiver_addr)
                        obj.put("input_param_receiver_addr2", input_param_receiver_addr2)
                        obj.put("input_param_receiver_road", input_param_receiver_road)
                        obj.put("input_param_receiver_soi", input_param_receiver_soi)
                        obj.put("input_param_receiver_postal_code", input_param_receiver_postal_code)
                        obj.put("input_param_send_time", input_param_send_time)
                        obj.put("input_param_send_time_ts", input_param_send_time_ts)
                        obj.put("input_param_product_code", input_param_product_code)
                        obj.put("input_param_limit_type_code", input_param_limit_type_code)
                        obj.put("input_param_cargo_type_code", input_param_cargo_type_code)
                        obj.put("input_param_express_type_code", input_param_express_type_code)
                        obj.put("input_param_source_province", input_param_source_province)
                        obj.put("input_param_source_city", input_param_source_city)
                        obj.put("input_param_source_area", input_param_source_area)
                        obj.put("input_param_source_road", input_param_source_road)
                        obj.put("input_param_source_soi", input_param_source_soi)
                        obj.put("input_param_source_addr", input_param_source_addr)
                        obj.put("input_param_source_addr2", input_param_source_addr2)
                        obj.put("input_param_source_contacts", input_param_source_contacts)
                        obj.put("input_param_source_mobile", input_param_source_mobile)
                        obj.put("input_param_source_mobile2", input_param_source_mobile2)
                        obj.put("input_param_source_phone", input_param_source_phone)
                        obj.put("input_param_source_postal_code", input_param_source_postal_code)
                        obj.put("log", obj.getString("log") + "\001" + x._2._2.get.getString("log"))



                    }catch {
                        case e: Exception => {
                            obj.put("log",e.printStackTrace())
                        }
                    }


                }

            }
            obj

        }).distinct()
        resultRdd




    }
    def markLog(log:String,markKey:String,prefix:String,obj:JSONObject) ={
        if(log.contains(prefix)){
            try{
                val logObj = JSON.parseObject(log)
                val logKey = logObj.getString("requestId")
                obj.put("logKey",logKey)
                obj.put("markKey",markKey)
            }catch {case e:Exception=>{

            }}



        }


    }

    def markOldLog(log:String,markKey:String,prefix:String,obj:JSONObject) ={
        if(log.contains(prefix)){
            try{
                val logKey=log.split("><")(1).split(">")(0)
//                val logObj = JSON.parseObject(log)
//                val logKey = logObj.getString("requestId")
                obj.put("logKey",logKey)
                obj.put("markKey",markKey)
            }catch {case e:Exception=>{

            }}



        }


    }

}
