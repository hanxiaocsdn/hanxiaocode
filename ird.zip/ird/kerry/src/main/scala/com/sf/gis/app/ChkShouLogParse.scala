package com.sf.gis.app

import com.alibaba.fastjson.JSON
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-03 14:58
 * @TaskId:785175
 * @TaskName:
 * @Description:chk收日志解析
 */

object ChkShouLogParse {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("interfacetype","orderfromvo_customerid","orderfromvo_citycode","orderfromvo_province","orderfromvo_city","orderfromvo_county","orderfromvovo_address","orderfromvo_address2","orderfromvo_phone","orderfromvo_mobile","orderfromvo_mobile2","orderfromvo_faxno","orderfromvo_road","orderfromvo_soi","orderfromvo_zipcode","orderfromvo_contactsname","orderfromvo_company","orderfromvo_customeraccount","orderto_customerid","orderno","sysorderno","ordertype","bookingtype","bookingdatetime","weight","servivecodelist","syssource","clientcode","limittypecode","paytype","aoiareacode","aoicode","aoiid","deptcode","code","omssendtime","gissendtime","chkqueryparam","chkqueryresult","log","region")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("解析日志")
        val resultRdd = parseLog(sparkSession, end_day)
        logger.error("存储数据日志")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.obs_chk_shou_log_parse_data",Array(("inc_day", end_day)), 25)



    }

    def parseLog(spark: SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |select log from dm_gis.obs_chk_shou_log where inc_day='$end_day'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val log = obj.getString("log")
            try {
//                val logObj = JSON.parseObject("{"+log.split("> \\{")(1))
                val logObj = JSON.parseObject(log)
                val interfacetype = JSONUtil.getJsonVal(logObj, "interfaceType", "")
                val orderFromVO = JSONUtil.getJsonArrayFromObject(logObj, "reqS.orderFromToList").getJSONObject(0)

                val orderfromvo_customerid = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.customerId", "")
                val orderfromvo_citycode = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.cityCode", "")
                val orderfromvo_province = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.province", "")
                val orderfromvo_city = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.city", "")
                val orderfromvo_county = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.county", "")
                val orderfromvovo_address = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.address", "")
                val orderfromvo_address2 = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.address2", "")
                val orderfromvo_phone = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.phone", "")
                val orderfromvo_mobile = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.mobile", "")
                val orderfromvo_mobile2 = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.mobile2", "")
                val orderfromvo_faxno = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.faxNo", "")
                val orderfromvo_road = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.road", "")
                val orderfromvo_soi = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.soi", "")
                val orderfromvo_zipcode = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.zipCode", "")
                val orderfromvo_contactsname = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.contactsName", "")
                val orderfromvo_company = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.company", "")
                val orderfromvo_customeraccount = JSONUtil.getJsonVal(orderFromVO, "orderFromVO.customerAccount", "")
                val orderto_customerid = JSONUtil.getJsonVal(orderFromVO, "orderTo.customerId", "")

                val orderno = JSONUtil.getJsonVal(logObj, "reqS.orderNo", "")
                val sysorderno = JSONUtil.getJsonVal(logObj, "reqS.sysOrderNo", "")
                val ordertype = JSONUtil.getJsonVal(logObj, "reqS.orderType", "")
                val bookingtype = JSONUtil.getJsonVal(logObj, "reqS.bookingType", "")
                val bookingdatetime = JSONUtil.getJsonVal(logObj, "reqS.bookingDateTime", "")
                val weight = JSONUtil.getJsonVal(logObj, "reqS.weight", "")
                val servivecodelist = JSONUtil.getJsonVal(logObj, "reqS.serviveCodeList", "")
                val syssource = JSONUtil.getJsonVal(logObj, "reqS.sysSource", "")
                val clientcode = JSONUtil.getJsonVal(logObj, "reqS.clientCode", "")
                val limittypecode = JSONUtil.getJsonVal(logObj, "reqS.limitTypeCode", "")
                val paytype = JSONUtil.getJsonVal(logObj, "reqS.payType", "")
                var aoiareacode = ""
                var aoicode = ""
                var aoiid = ""
                var deptcode = ""
                if (interfacetype.equals("async")) {
                    aoiareacode = JSONUtil.getJsonVal(logObj, "reqE.orderFrom.aoiAreaCode", "")
                    aoicode = JSONUtil.getJsonVal(logObj, "reqE.orderFrom.aoiCode", "")
                    aoiid = JSONUtil.getJsonVal(logObj, "reqE.orderFrom.aoiId", "")
                    deptcode = JSONUtil.getJsonVal(logObj, "reqE.orderFrom.deptCode", "")

                } else if (interfacetype.equals("sync")) {
                    aoiareacode = JSONUtil.getJsonVal(logObj, "reqE.result.orderFromTo.teamFrom.aoiAreaCode", "")
                    aoicode = JSONUtil.getJsonVal(logObj, "reqE.result.orderFromTo.teamFrom.aoiCode", "")
                    aoiid = JSONUtil.getJsonVal(logObj, "reqE.result.orderFromTo.teamFrom.aoiId", "")
                    deptcode = JSONUtil.getJsonVal(logObj, "reqE.result.orderFromTo.teamFrom.deptCode", "")

                }

                val code = JSONUtil.getJsonVal(logObj, "reqE.code", "")
                val omssendtime = JSONUtil.getJsonVal(logObj, "reqS.omsSendTime", "")
                val gissendtime = JSONUtil.getJsonVal(logObj, "reqE.gisSendTime", "")
                val chkqueryparam = JSONUtil.getJsonVal(logObj, "chkQueryParam", "")
                val chkqueryresult = JSONUtil.getJsonVal(logObj, "chkQueryResult", "")
                val region=JSONUtil.getJsonVal(logObj, "chkQueryParam.region", "")
                if(StringUtils.nonEmpty(region)){
                    obj.put("region",region)
                }else{
                    obj.put("region","TH")
                }
                obj.put("interfacetype", interfacetype)
                obj.put("orderfromvo_customerid", orderfromvo_customerid)
                obj.put("orderfromvo_citycode", orderfromvo_citycode)
                obj.put("orderfromvo_province", orderfromvo_province)
                obj.put("orderfromvo_city", orderfromvo_city)
                obj.put("orderfromvo_county", orderfromvo_county)
                obj.put("orderfromvovo_address", orderfromvovo_address)
                obj.put("orderfromvo_address2", orderfromvo_address2)
                obj.put("orderfromvo_phone", orderfromvo_phone)
                obj.put("orderfromvo_mobile", orderfromvo_mobile)
                obj.put("orderfromvo_mobile2", orderfromvo_mobile2)
                obj.put("orderfromvo_faxno", orderfromvo_faxno)
                obj.put("orderfromvo_road", orderfromvo_road)
                obj.put("orderfromvo_soi", orderfromvo_soi)
                obj.put("orderfromvo_zipcode", orderfromvo_zipcode)
                obj.put("orderfromvo_contactsname", orderfromvo_contactsname)
                obj.put("orderfromvo_company", orderfromvo_company)
                obj.put("orderfromvo_customeraccount", orderfromvo_customeraccount)
                obj.put("orderto_customerid", orderto_customerid)
                obj.put("orderno", orderno)
                obj.put("sysorderno", sysorderno)
                obj.put("ordertype", ordertype)
                obj.put("bookingtype", bookingtype)
                obj.put("bookingdatetime", bookingdatetime)
                obj.put("weight", weight)
                obj.put("servivecodelist", servivecodelist)
                obj.put("syssource", syssource)
                obj.put("clientcode", clientcode)
                obj.put("limittypecode", limittypecode)
                obj.put("paytype", paytype)
                obj.put("aoiareacode", aoiareacode)
                obj.put("aoicode", aoicode)
                obj.put("aoiid", aoiid)
                obj.put("deptcode", deptcode)
                obj.put("code", code)
                obj.put("omssendtime", omssendtime)
                obj.put("gissendtime", gissendtime)
                obj.put("chkqueryparam", chkqueryparam)
                obj.put("chkqueryresult", chkqueryresult)


            } catch {
                case e: Exception => logger.error(e.getMessage)
            }

            obj

        }).filter(obj=>StringUtils.nonEmpty(obj.getString("interfacetype"))).distinct()

        resultRdd


    }


}
