package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.utils.HttpInvokeUtil
import com.sf.gis.utils._
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2023-12-27 10:37
 * @TaskId:873980
 * @TaskName:自动下发补码埋点数据
 * @Description:
 */

object ThaiAutomationDistributeBuMaBuryingPointData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val addWaybillTaskUrl="https://gis-aos.th.kerryexpress.com/work/api/addWaybillTask"
    ///globalexpress/openapi/waybill/addWaybillTask
    var token_all=""
    val saveKey=Array("hq_code","batch_aoi","waybill_no","consignee_post_code","out_param_addressee_dept_code","addresspin","pod_aoiid","code","message","geo_location")
    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = distribute(sparkSession, end_day, start_day,end_date)
        //dm_gis.dm_thai_distribute_burying_point_data_di
        //dm_gis.dm_thai_distribute_burying_point_data_tmp_di
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_thai_distribute_burying_analysis_data_di",Array(("inc_day", end_date)), 25)



    }

    def distribute(spark: SparkSession,end_day:String,start_day:String,end_date:String)={



        var sql_dept=
            s"""
              |
              |select hq_code  from dm_gis.dm_thai_shenbu_analysis_di   where inc_day='$end_date'
              |
              |""".stripMargin
        val deptCodeInfoBroad = spark.sparkContext.broadcast(SparkRead.readHiveAsJson(spark, sql_dept)._1.map(x => x.getString("hq_code")).collect().toSet)

        var sql_max=
            s"""
              |
              |select cast(max(cast(addr_freq as int)) as string) as addr_freq  from dm_gis.dm_thai_shenbu_analysis_di   where inc_day='$end_date'
              |
              |""".stripMargin

        val addrFreqInfoBroad = spark.sparkContext.broadcast(SparkRead.readHiveAsJson(spark, sql_max)._1.map(x => x.getString("addr_freq")).collect().toSet)

        var sql=
            s"""
              |
              |select hq_code,batch_aoi,waybill_no,consignee_post_code,out_param_addressee_dept_code, addresspin, pod_aoiid,geo_location from (
              |select hq_code,batch_aoi,waybill_no,consignee_post_code,out_param_addressee_dept_code, addresspin,aoiid pod_aoiid,geo_location,row_number()over(partition by hq_code order by addresspin ) as num from (
              |select *,row_number()over(partition by addresspin order by consigned_tm desc ) as rnk from dm_gis.thai_delivery_scheduling_chk where inc_day between '$start_day' and '$end_day' and is_recognize_aoi = 'true' and is_exist_batch_aoi = 'true' and (is_same_xj_batch_aoi = 'true' or is_same_xj_80_aoi = 'true')
              |
              |) t
              |where t.rnk=1
              |) x
              |where x.num<=20
              |
              |
              |
              |
              |
              |""".stripMargin

        //and  out_param_addressee_dept_code in('BSU','JKB','TON','PRH')

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)


        val resultRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            val deptCodeInfo = deptCodeInfoBroad.value
            val addrFreqInfo = addrFreqInfoBroad.value
            // 通过UAC鉴权接口获取token
            token_all = getToken()
            for (obj <- x) {
                val out_param_addressee_dept_code = obj.getString("out_param_addressee_dept_code")
                val hq_code = obj.getString("hq_code")
                if (deptCodeInfo.contains(hq_code)) {
                    val waybill_no = obj.getString("waybill_no")

                    val consignee_post_code = obj.getString("consignee_post_code")
                    val addresspin = obj.getString("addresspin")
                    val geo_location=obj.getString("geo_location")
                    val parmObj = new JSONObject()
                    parmObj.put("district", hq_code)
                    parmObj.put("zipCode", consignee_post_code)
                    parmObj.put("address", addresspin)
                    parmObj.put("dc", out_param_addressee_dept_code)
                    parmObj.put("deliverCoor",geo_location)
                    parmObj.put("taskType", "1")
                    parmObj.put("freq", addrFreqInfo.head.toInt+1)
//                    parmObj.put("region", "TH")
                    parmObj.put("wbNo", waybill_no)
                    val (code, message) = getInterfaceData(parmObj,token_all)
                    obj.put("code", token_all)
                    obj.put("message", message)
//                    obj.put("addresspin",parmObj)
                    listbuffer += obj


                }


            }

            listbuffer.iterator

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("自动下发的数据量----》"+resultRdd.count())
        logger.error("token---->"+token_all)
        resultRdd

    }

    def getInterfaceData(param:JSONObject,token_all:String)={




        val headers = new util.HashMap[String,String]()
        val value = "Bearer " + token_all
        headers.put("Accept-language","zh-CN")
        headers.put("Auth-client-id","GIS-IRD-CORE-CMS")
        headers.put("Auth-tenant-code","TH")
        headers.put("Auth-tenant-id","40")
        headers.put("Authorization",value)
        var code=""
        var message=""
        Thread.sleep(500)
        val jSONObject = try {
            JSON.parseObject(HttpInvokeUtil.sendPostMultiHeader(addWaybillTaskUrl, param.toString, headers, 3))
        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+param.toString())
                new JSONObject()
            }
        }

        if(jSONObject!=null){
            code=JSONUtil.getJsonVal(jSONObject,"code","")
            message=JSONUtil.getJsonVal(jSONObject,"message","")

        }
        (code,message)
    }

    def getToken(): String = {
        var access_token = ""

        val username = "01407499"
        val password = "Lzj01407499@"
        val header = "Authorization"
        val value = "Basic R0lTLUFTUy1BT1MtQkRQOkFPU0BCRFAhMjAyMg=="
        val url = "http://gis-ird-gateway.int.os-sgp.local/uac/oauth/token?grant_type=password&username=%s&password=%s".format(username, password)

        breakable(
            for (i <- 0.until(5)) {
                try {
                    val jsonObject = HttpInvokeUtil.sendPostHeader(url, "", header, value, "UTF-8", "UTF-8")
                    logger.error(">>>访问getToken：url" + i + "=" + url + ", result=" + jsonObject)
                    Thread.sleep(2000)
                    if (jsonObject != null) {

                        access_token = JSONUtil.parseJSONObject(jsonObject).getString("access_token")
                        if (StringUtils.nonEmpty(access_token)) break
                        else Thread.sleep(2000)
                    }
                    if (i >= 4) break
                } catch {
                    case e: Exception => logger.error(">>>访问getToken：url" + i + "=" + url)
                }
            }
        )
        access_token
    }

}
