package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.WaybillAndAoiToShenbu.replaceInvalidStr
import com.sf.gis.java.utils.GeometryUtil
import com.sf.gis.utils.{Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-05-06 10:42
 * @TaskId:739417
 * @TaskName:
 * @Description:注意嘉里集群scala版本为：2.12.15
 */

object XYLocationAoiTest {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
//    val saveKey=Array("geo_location","aoiid","aoicode","zno_code","name_chn","wkt","dis")
    val saveKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始读取aoi多边形数据")
        val broadcastAoiList: Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]] = getAoiWktNew(sparkSession)
        logger.error("开始计算点落aoi多边形")
        val dataRdd = getWaybillData(sparkSession, broadcastAoiList,end_day,end_date)

        /*
        如果上面的无法跑出结果就用下面这个
        val aoiMapListBroad: Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]] = getBuildWkt(sparkSession)
        val dataRdd = getWaybillDataNew(sparkSession, aoiMapListBroad, end_day, end_date)
        */
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveKey, "dm_gis.thai_aoi_test_shenbu_v3",Array(("inc_day", end_day)), 25)


    }

    def getWaybillData(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql=""

        if(end_day.equals("20230514")){
            sql=
                """
                  |
                  |select a.*, b.geo_location from
                  |(
                  |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
                  |dwd.dwd_consignment_dtl_di
                  |where inc_day between '20230506' and '20230514' and act_delivery_date between '2023-05-08 00:00:00' and '2023-05-14 23:59:59' and recipient_postcode_id in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','0280','10570','12120','13180','74130')
                  |) a
                  |inner join
                  |(
                  |select consignment_no, geo_location from
                  |(
                  |    select *,
                  |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
                  |     from  ods_kems.consignment_tracking
                  |     where inc_day between '20230508' and '20230514' and status_id='21'  and geo_location is not null
                  |) bb  where rank =1
                  |) b
                  |on a.consignment_no = b.consignment_no
                  |
                  |""".stripMargin

        }
        if(end_day.equals("20230504")){
            sql=
                """
                  |select a.*, b.geo_location from (select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from dwd.dwd_consignment_dtl_di where inc_day between '20230426' and '20230504' and act_delivery_date between '2023-04-28 00:00:00' and '2023-05-04 23:59:59' and recipient_postcode_id in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','0280','10570','12120','13180','74130') ) a inner join( select consignment_no, geo_location from( select *,row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank from  ods_kems.consignment_tracking where inc_day between '20230428' and '20230504' and status_id='21'  and geo_location is not null) bb  where rank =1) b on a.consignment_no = b.consignment_no
                  |
                  |""".stripMargin

        }
        if(end_day.equals("20230402")){
            sql=
                """
                  |
                  |select a.*, b.geo_location from
                  |(
                  |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
                  |dwd.dwd_consignment_dtl_di
                  |where inc_day between '20230327' and '20230402' and act_delivery_date between '2023-03-27 00:00:00' and '2023-04-02 23:59:59' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
                  |) a
                  |inner join
                  |(
                  |select consignment_no, geo_location from
                  |(
                  |    select *,
                  |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
                  |     from  ods_kems.consignment_tracking
                  |     where inc_day between '20230327' and '20230402' and status_id='21'  and geo_location is not null
                  |) bb  where rank =1
                  |) b
                  |on a.consignment_no = b.consignment_no
                  |
                  |""".stripMargin

        }




        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val aoiListMap = aoiListBroadcast.value
            val geoStrings = obj.getString("geo_location").split(",")
            val x = geoStrings(1)
            val y = geoStrings(0)
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            var wktend=""
            var zno_code=""
            var name_chn=""
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                breakable {
                    val key = GeometryUtil.sliceUpCoordinate(x.toDouble, y.toDouble)
                    if(aoiListMap.contains(key)){
                        val aoiList = aoiListMap.get(key).get
                        for (aoiObj <- aoiList) {
                            val wkt = aoiObj.getString("wkt")
                            val d = getGeoData(wkt, x.toDouble, y.toDouble)
                            /*
                            if (distance >= 0.0 &&d>=0.0&& distance > d) {
                                distance = d
                                aoiid = aoiObj.getString("gui_id")
                                aoicode = aoiObj.getString("aoi_code")
                                zno_code=aoiObj.getString("zno_code")


                            } else if (distance < 0.0&&d>=0.0) {
                                distance = d
                                aoiid = aoiObj.getString("gui_id")
                                aoicode = aoiObj.getString("aoi_code")
                                zno_code=aoiObj.getString("zno_code")

                            }
                            */
                            if(d==0.0){
                                distance = d
                                aoiid = aoiObj.getString("gui_id")
                                aoicode = aoiObj.getString("aoi_code")
                                zno_code=aoiObj.getString("zno_code")
                                break
                            }
                        }

                    }


                }

            }
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj.put("aoiid", aoiid)
            obj.put("aoicode", aoicode)
            obj.put("dc",zno_code)
            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }



    def getWaybillDataNew(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.map(obj => {
            val aoiListMap = aoiListBroadcast.value
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(0)
            val y = geoStrings(0)
            var aoiid = ""
            var aoicode = ""
            val tuple = getDistance(x, y, aoiListMap, 0.001)
            val tuple2 = getDistance(x, y, aoiListMap, -0.001)
            if(StringUtils.nonEmpty(tuple._1)){
                aoiid=tuple._1
                aoicode=tuple._2
            }else if(StringUtils.nonEmpty(tuple2._1)){
                aoiid=tuple2._1
                aoicode=tuple2._2

            }
            dataObj.put("aoiid", aoiid)
            dataObj.put("aoicode", aoicode)
            (obj._1, dataObj)
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("点落面获得的aoi数据量---》"+aoiInfoRdd.count())

        val resultRdd = dataRdd.map(x => (x.getString("geo_location"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def getDistance(x:String,y:String,aoiListMap:mutable.HashMap[String, ListBuffer[JSONObject]],sub:Double) = {
        var distance = (-1.0)
        var aoiid = ""
        var aoicode = ""
        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
            val lon_index = x.substring(0, 7).toDouble + sub
            val lat_index = y.substring(0, 6).toDouble + sub
            val key = lon_index + "_" + lat_index
            if (aoiListMap.contains(key)) {
                val aoiList = aoiListMap.get(key).get
                for (aoiObj <- aoiList) {
                    val wkt = aoiObj.getString("wkt")
                    val d = getGeoData(wkt, x.toDouble, y.toDouble)
                    if (distance >= 0.0 && distance < d) {
                        distance = d
                        aoiid = aoiObj.getString("aoiid")
                        aoicode = aoiObj.getString("aoicode")

                    } else if (distance < 0.0) {
                        distance = d
                        aoiid = aoiObj.getString("aoiid")
                        aoicode = aoiObj.getString("aoicode")

                    }

                }
            }

        }
        (aoiid,aoicode)
    }

    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case e:Exception=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }

    def getAoiWktNew(spark:SparkSession)={
        var sql="select * from dm_gis.thai_aoi_wkt_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val wktMap = new mutable.HashMap[String, mutable.ListBuffer[JSONObject]]()
        val list = dataRdd.collect().toList
        for(obj<-list){
            val wkt = obj.getString("wkt")
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(wkt)

                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    if(wktMap.contains(key)){
                        val value: ListBuffer[JSONObject] = wktMap.get(key).get
                        value+=obj
                        wktMap.put(key,value)

                    }else{
                        val temList = new ListBuffer[JSONObject]()
                        temList+=obj
                        wktMap.put(key,temList)

                    }
                }

            }catch {
                case e:Exception=>logger.error("error reason---->"+e.getMessage)
            }


        }
        spark.sparkContext.broadcast(wktMap)


    }

    def getAoiWkt(spark:SparkSession)={
        val columns=Array("gui_id","zno_code","name_chn","aoi_code","wkt")
        val aoiPath = "file://"+System.getProperty("user.dir") + "/gex_aoi_050602.csv"
        logger.error("aoi 多边形数据path---》"+aoiPath)
        //hdfs://kex/user/01407499/upload/gex_aoi_050602.csv
        val srcDF = spark.read
            .option("inferschema", "false")
            //.option("multiLine", true)
            .option("header", "false")
            .option("encoding", "UTF-8")
            .csv("hdfs://kex/user/01407499/upload/gex_aoi_050602.csv")
            .toDF("gui_id","zno_code","name_chn","aoi_code","wkt")
        val dataRdd = srcDF.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getAs[String](columns(i)))
            }
            jObj
        })
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }

    def getBuildWkt(spark:SparkSession)={
        var sql=
            s"""
               |select wkt,guid as bld_id,name_chn bld_name,x_coord as bld_lon,y_coord as bld_lat,addr_chn as bld_addr from dm_gis.building_all_info where x_coord is not null and x_coord<>'' and x_coord<>'null' and y_coord is not null and y_coord<>'' and y_coord<>'null' and wkt is not null and wkt<>'' and wkt<>'null'  order by bld_lon,bld_lat
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        dataRdd.take(30).foreach(println)
        val dataList = dataRdd.collect().toList

        //113.60260156256727,22.33121691648796
        val dataMap = new mutable.HashMap[String, ListBuffer[JSONObject]]()
        for(obj<-dataList){
            val bld_lon = obj.getString("bld_lon")
            val bld_lat = obj.getString("bld_lat")
            if(StringUtils.nonEmpty(bld_lon)&&StringUtils.nonEmpty(bld_lat)&&bld_lon.length>7&&bld_lat.length>6){
                val lon_index=bld_lon.substring(0,7).toDouble+0.001
                val lat_index=bld_lat.substring(0,6).toDouble+0.001
                val key=lon_index+"_"+lat_index
                if(dataMap.contains(key)){
                    dataMap.put(key,dataMap.get(key).get+=obj)
                }else{
                    val listBuffer: ListBuffer[JSONObject] = ListBuffer()
                    listBuffer+=obj
                    dataMap.put(key,listBuffer)
                }
            }
        }
        spark.sparkContext.broadcast(dataMap)

    }

    def binarySearch(buildList:ListBuffer[JSONObject],lng:String,keyName:String,starIndex:Int,endIndex:Int)={
        var l=starIndex
        var r=endIndex
        val lngadd = lng.toDouble+0.01
        val lngsub=lng.toDouble-0.01
        //                val lngadd = lng.toDouble+2
        //                val lngsub=lng.toDouble-1
        //        var mid=0
        breakable{
            while(l<r){
                var mid:Int=(l+r)/2
                val bld_lon = buildList(mid).getString(keyName).toDouble
                if(bld_lon>lngadd){
                    r = mid - 1
                }else if(bld_lon<lngsub){
                    l=mid+1
                }else {
                    break
                }
            }
        }
        //寻找l
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l-1)/2
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_1 = math.abs(lng.toDouble - bld_lon_1)
                //                logger.error("bld_lon----->"+bld_lon+"---lngadd---->"+lngadd+" lngsub---->"+lngsub)

                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_1<=0.0007){
                        l=mid
                        //                        logger.error("search l---->"+l)
                        break
                    }else{
                        r_tem_l = mid + 1

                    }

                }

            }
        }
        //寻找r
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l)/2+1
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_2 = math.abs(lng.toDouble - bld_lon_2)
                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_2>0.0007){
                        r=mid
                        break
                    }else{
                        l_tem_l=mid-1

                    }

                }

            }
        }
        (l,r)


    }

    def getDistance(lng:String,lat:String,buildList:ListBuffer[JSONObject])={
        var bld_dis = (-1.0)
        var index=0
        val (start,end) = binarySearch(buildList, lng,"bld_lon",0,buildList.size-1)
        logger.error("start lng index---->"+start+"end lng index----->"+end)
        val (l,r)=binarySearch(buildList, lat,"bld_lat",start,end)
        logger.error("start index---->"+l+"----->end index------>"+r)
        breakable{
            for(i<- l until r){
                val buildobj=buildList(i)
                val wkt = buildobj.getString("wkt")
                val dist = getGeoData(wkt, lng.toDouble, lat.toDouble)
                if (dist >= 0.0&&dist<=50.0) {
                    if (bld_dis >= 0.0) {
                        if (dist < bld_dis) {
                            bld_dis = dist
                            index=i
                        }
                    } else {
                        bld_dis = dist
                        index=i
                    }
                }
                if (bld_dis == 0.0) {
                    break
                }
            }

        }

        (bld_dis,index)


    }


}
