package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}

import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

import java.util
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01412995
 * @Author: 01407499
 * @CreateTime: 2023-11-21 16:05
 * @TaskId:873807
 * @TaskName:
 * @Description:指标验收跑数-chkquery
 */

object IndicatorAacceptanceIRD {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val chkQueryUrl="http://gis-gw.int.os-sgp.local:9080/irdispatch/api"
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","src_ird","ird_dccode","ird_largedccode","ird_aoiid","ird_aoicode","ird_aoiarea","ird_largeaoiarea","transcode","linehaulroute","is_same_ird_xj_batch_aoi","is_same_ird_xj_80_aoi","is_same_ird_xj_batch_or_80_aoi","is_same_ird_xj_dest_dc","is_same_ird_dj_dest_dc","is_same_ird_xj_80_dc","is_same_ird_dj_xj_dest_80_dc","interfacedata" )
    val ak_prod="d1aec36bec0d4a539f3251a7c290a4cd"
    val ak_gray="ff1fcdd9ea894680af6455ed603737c2"
    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var env=args(1)
        var region=args(2)
        var opt=args(3)
        var ak=""
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        if(StringUtils.nonEmpty(env)&&env.equals("gray")){
            ak=ak_gray
        }else{
            env="prod"
            ak=ak_prod
        }

        getData(sparkSession,end_day,ak,region,env,opt)

    }

    def getData(spark: SparkSession,end_day:String,ak:String,region:String,env:String,opt:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.thai_delivery_scheduling_chk_test
              |
              |
              |""".stripMargin

        sql=
            """
              |
              |select * from dm_gis.thai_delivery_scheduling_chk where inc_day between '20231201' and '20231220' and is_recognize_aoi = 'true' and is_exist_batch_aoi = 'true'and is_same_xj_batch_aoi = 'false' and is_same_xj_80_aoi = 'false'and inc_day not in('20231207' ,'20231208', '20231209' ,'20231210' ,'20231211' ,'20231212' )
              |
              |
              |""".stripMargin
        //where inc_day='$end_day'

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        val resultRdd = dataRdd.map(obj => {

            try{
                val batch_aoi = obj.getString("batch_aoi")
                val aoiid = obj.getString("aoiid")
                val dest_zone_code = obj.getString("dest_zone_code")
                val dc = obj.getString("dc")
                val parmObj = new JSONObject()
                val input_param_receiver_addr= obj.getString("input_param_receiver_addr")
                val input_param_receiver_addr2= obj.getString("input_param_receiver_addr2")
                val input_param_receiver_postal_code= obj.getString("input_param_receiver_postal_code")

                parmObj.put("address", input_param_receiver_addr)
                parmObj.put("address2", input_param_receiver_addr2)
                parmObj.put("zipcode", input_param_receiver_postal_code)
                parmObj.put("region", region)
                parmObj.put("opt", opt)

                parmObj.put("extend", "1")

                val (srcchk,dcCodechk,largeDcCodechk,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,largeAoiArea,jSONObject,response) = getZhUrlData(parmObj,ak)




                //丰图是否识别AOI
                //            var is_recognize_zh_aoi = "false"
                //识别小件AOI与排班AOI是否一致
                var is_same_ird_xj_batch_aoi = "false"
                //识别小件AOI与妥投AOI是否一致
                var is_same_ird_xj_80_aoi = "false"
                //识别小件AOI与排班AOI或妥投AOI是否一致zh
                var is_same_ird_xj_batch_or_80_aoi="false"

                //识别小件DC与dest_DC是否一致
                var is_same_ird_xj_dest_dc = "false"

                //识别大件DC与dest_DC是否一致
                var is_same_ird_dj_dest_dc = "false"

                //识别小件DC与妥投DC是否一致
                var is_same_ird_xj_80_dc = "false"

                //识别大件DC与妥投DC是否一致
                var is_same_ird_dj_xj_dest_80_dc = "false"


                //            if(StringUtils.nonEmpty(srcchk)&&Array("his","ml","geo-kw").contains(srcchk)){
                //                is_recognize_zh_aoi="true"
                //            }

                if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(result_data_aoicode) && batch_aoi.contains(result_data_aoicode)) {
                    is_same_ird_xj_batch_aoi = "true"
                }
                if (StringUtils.nonEmpty(result_data_aoiid) && StringUtils.nonEmpty(aoiid) && result_data_aoiid.equals(aoiid)) {
                    is_same_ird_xj_80_aoi = "true"
                }

                if(is_same_ird_xj_batch_aoi.equals("true")||is_same_ird_xj_80_aoi.equals("true")){
                    is_same_ird_xj_batch_or_80_aoi="true"
                }

                if (StringUtils.nonEmpty(dcCodechk) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(dcCodechk)) {
                    is_same_ird_xj_dest_dc = "true"
                }

                if (StringUtils.nonEmpty(largeDcCodechk) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(largeDcCodechk)) {
                    is_same_ird_dj_dest_dc = "true"
                }
                if (StringUtils.nonEmpty(dcCodechk) && StringUtils.nonEmpty(dc) && dc.equals(dcCodechk)) {
                    is_same_ird_xj_80_dc = "true"
                }
                if(is_same_ird_xj_dest_dc.equals("true")||is_same_ird_dj_dest_dc.equals("true")||is_same_ird_xj_80_dc.equals("true")){
                    is_same_ird_dj_xj_dest_80_dc="true"

                }

                //            obj.put("is_recognize_zh_aoi", is_recognize_zh_aoi)
                obj.put("is_same_ird_xj_batch_aoi", is_same_ird_xj_batch_aoi)
                obj.put("is_same_ird_xj_80_aoi", is_same_ird_xj_80_aoi)
                obj.put("is_same_ird_xj_batch_or_80_aoi", is_same_ird_xj_batch_or_80_aoi)
                obj.put("is_same_ird_xj_dest_dc", is_same_ird_xj_dest_dc)

                obj.put("is_same_ird_dj_dest_dc", is_same_ird_dj_dest_dc)
                obj.put("is_same_ird_xj_80_dc", is_same_ird_xj_80_dc)
                obj.put("is_same_ird_dj_xj_dest_80_dc", is_same_ird_dj_xj_dest_80_dc)

                obj.put("src_ird", srcchk)
                obj.put("ird_dccode", dcCodechk)
                obj.put("ird_largedccode", largeDcCodechk)
                obj.put("ird_aoiid", result_data_aoiid)
                obj.put("ird_aoicode", result_data_aoicode)
                obj.put("ird_aoiarea", result_data_aoiarea)
                obj.put("ird_largeaoiarea", largeAoiArea)
                obj.put("confidence", jSONObject.toString)
                obj.put("interfacedata",response)

            }catch {case e:Exception=>logger.error(e.toString)}

//            obj.put("linehaulroute", lineHaulRoute)
            //transcode,lineHaulRoute,largeAoiArea,jSONObject


            obj
        }).distinct()


        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKey.indices) {
            schemaEle.append(StructField(saveKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = resultRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveKey.indices) {
                row.append(JSONUtil.getJsonValSingle(obj, saveKey.apply(i)).replaceAll("[\\r\\n\\t]", ""))
            }
            val ret = Row.fromSeq(row)
            ret
        })
        var rowDf = spark.createDataFrame(rowRdd, schema)

        rowDf.createOrReplaceTempView("tmp_ird_result")
        var sql_w=
            s"""
              |
              |insert overwrite table dm_gis.thai_delivery_scheduling_chk_ird partition (inc_day='$end_day',region='$region',ak='$env',opt='$opt')
              |select
              |district
              |,city_code
              |,input_param_receiver_postal_code
              |,dest_zone_code
              |,src
              |,is_recognize_aoi
              |,is_exist_batch_aoi
              |,is_same_xj_batch_aoi
              |,is_same_xj_80_aoi
              |,is_same_xj_dest_dc
              |,is_same_dj_dest_dc
              |,is_same_xj_80_dc
              |,is_same_dj_80_dc
              |,batch_aoi
              |,aoiid
              |,aoicode
              |,dc
              |,waybill_no
              |,source_zone_code
              |,addressee_dept_code
              |,addresseeaoicode
              |,dest_lgt
              |,dest_lat
              |,consignee_emp_code
              |,consigned_tm
              |,deliver_emp_code
              |,signin_tm
              |,consignor_post_code
              |,consignee_post_code
              |,input_param_waybill_no
              |,input_param_receiver_addr
              |,input_param_receiver_addr2
              |,input_param_send_time
              |,out_param_addressee_aoi_area
              |,out_param_addressee_aoi_code
              |,out_param_addressee_aoi_id
              |,out_param_addressee_dept_code
              |,out_param_addressee_transit_code
              |,largedccode
              |,geo_location
              |,input_param_addressee_mobile
              |,input_param_receiver_mobile2
              |,hq_code
              |,src_ird
              |,ird_dccode
              |,ird_largedccode
              |,ird_aoiid
              |,ird_aoicode
              |,ird_aoiarea
              |,ird_largeaoiarea
              |,transcode
              |,linehaulroute
              |,is_same_ird_xj_batch_aoi
              |,is_same_ird_xj_80_aoi
              |,is_same_ird_xj_batch_or_80_aoi
              |,is_same_ird_xj_dest_dc
              |,is_same_ird_dj_dest_dc
              |,is_same_ird_xj_80_dc
              |,is_same_ird_dj_xj_dest_80_dc
              |,interfacedata
              |from tmp_ird_result
              |
              |
              |""".stripMargin
        logger.error(sql_w)
        spark.sql(sql_w)
        logger.error("数据存储完毕")


    }

    def getZhUrlData(parm:JSONObject,ak:String): (String, String, String, String, String, String, String, String, JSONObject,String) ={

        //        var nowHour = getHour()
        //        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
        //            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
        //            Thread.sleep(1000*60)
        //            nowHour = getHour()
        //
        //        }
        var src=""
        var dcCode=""
        var largeDcCode=""
        var result_data_aoiid=""
        var result_data_aoicode=""
        var result_data_aoiarea=""
//        var transcode=""
//        var lineHaulRoute=""
        var confidence=""
        var largeAoiArea=""
        var jSONObject =new JSONObject()
        var response=""

        if(parm.size()<1){
            return (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,largeAoiArea,jSONObject,response)
        }
        Thread.sleep(80)
        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak",ak)
        breakable {
            for(i<-0 until(3)){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(chkQueryUrl, parm, stringToString))
                }
                catch {
                    case _=>{
                        logger.error("error parameter-----> "+parm.toString())
                        new JSONObject()
                    }
                }
                val status = JSONUtil.getJsonVal(jSONObject, "status", "")
                val msg = JSONUtil.getJsonVal(jSONObject, "result.msg", "")

                if(StringUtils.nonEmpty(status)&&status.equals("0")){
                    break
                }else{
                    if(msg.contains("many")&&msg.contains("too")){
                        Thread.sleep(30000)
                    }else{
                        break
                    }

                }
            }

        }


        if(jSONObject!=null&&(!jSONObject.isEmpty)){
            response=jSONObject.toString
        }
        src = JSONUtil.getJsonVal(jSONObject, "result.data.src", "")
        val status = JSONUtil.getJsonVal(jSONObject, "status", "")
        if(!status.equals("0")){
            src=JSONUtil.getJsonVal(jSONObject, "result.msg", "")
        }
        dcCode = JSONUtil.getJsonVal(jSONObject, "result.data.dcCode", "")
        largeDcCode = JSONUtil.getJsonVal(jSONObject, "result.data.largeDcCode", "")
        result_data_aoiid=JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        result_data_aoicode=JSONUtil.getJsonVal(jSONObject, "result.data.aoiCode", "")
        result_data_aoiarea=JSONUtil.getJsonVal(jSONObject, "result.data.aoiArea", "")
        confidence==JSONUtil.getJsonVal(jSONObject, "result.data.confidence", "")
//        transcode=JSONUtil.getJsonVal(jSONObject, "result.data.transCode", "")
//        lineHaulRoute=JSONUtil.getJsonVal(jSONObject, "result.data.lineHaulRoute", "")
        largeAoiArea=JSONUtil.getJsonVal(jSONObject, "result.data.largeAoiArea", "")
        (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,confidence,largeAoiArea,jSONObject,response)

    }



}
