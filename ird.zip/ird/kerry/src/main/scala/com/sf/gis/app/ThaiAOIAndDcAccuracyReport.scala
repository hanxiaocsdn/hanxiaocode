package com.sf.gis.app


import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.HighFrequencyNotRecognizeAoiDataPai.replaceInvalidStr
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-09-20 10:42
 * @TaskId:828562
 * @TaskName:
 * @Description:aoi和dc准确率报表
 */

object ThaiAOIAndDcAccuracyReport {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","addresspin","is_same_out_his80_aoi","output_80_aoi_area_id","is_same_xj_80_aoi_area")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        var start_day=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")

        logger.error("获取邮编区域映射信息")
        val postalMapBro: Broadcast[collection.Map[String, String]] = getZipCityInfo(sparkSession)
        val aoiAreaInfoMapBroad = getAoiAreaInfo(sparkSession, end_day)
        logger.error("获取排班信息")
        val batchAoiRdd = getScheduleBatchData(sparkSession, end_day)
        logger.error("计算aoi和dc准确率报表")
        val resultRdd = calcAccuracy(sparkSession, end_day, end_date, start_day, batchAoiRdd, postalMapBro,aoiAreaInfoMapBroad)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk",Array(("inc_day", end_day)), 25)


    }

    def getZipCityInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.thai_postal_city_info
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val postalMap = dataRdd.map(obj => {
            val postal_code = obj.getString("postal_code")
            val city_code = obj.getString("city_code")
            val district = obj.getString("district")
            (postal_code, city_code + "\001" + district)

        }).collectAsMap()
        spark.sparkContext.broadcast(postalMap)

    }

    def getAoiAreaInfo(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select guid,aoi_area_id from
              |    dm_tc_waybillinfo.dm_sds_aoi_area_aoi_info_dtl_df b
              |    where inc_day ='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val aoiAreaInfoMap = dataRdd.map(obj => {

            val guid = obj.getString("guid")
            val aoi_area_id = obj.getString("aoi_area_id")
            (guid, aoi_area_id)
        }).collectAsMap()
        spark.sparkContext.broadcast(aoiAreaInfoMap)


    }

    def getScheduleBatchData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select emp_no,aoi_id batch_aoi from dm_tc_waybillinfo.dm_sds_scheduling_result_dtl_df where inc_day = '$end_day' and batch_date = '$end_day'
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val batchAoiRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("emp_no"))).groupBy(x => x.getString("emp_no")).flatMap(x => {
            val list = new ListBuffer[JSONObject]()
            val emp_no = x._1
            val aoiSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                try {
                    val batch_aoi = obj.getString("batch_aoi")
                    val aoiArr = JSON.parseObject(batch_aoi)
                    val aois = aoiArr.keySet().toArray()
                    for (aoiKey <- aois) {
                        if (!aoiSet.contains(aoiKey.toString)) {
                            aoiSet.add(aoiKey.toString)
                        }
                    }

                } catch {
                    case e: Exception => logger.error(e.printStackTrace())
                }
            }
            if (aoiSet.size > 0) {
                val tmpObj = new JSONObject()
                tmpObj.put("emp_no", emp_no)
                tmpObj.put("batch_aoi", aoiSet.mkString(","))
                list += tmpObj

            }

            list
        }).filter(x => StringUtils.nonEmpty(x.getString("emp_no"))).map(x => (x.getString("emp_no"), x))

        batchAoiRdd

    }


    def calcAccuracy(spark: SparkSession,end_day:String,end_date:String,start_day:String,batchAoiRdd:RDD[(String,JSONObject)],postalMapBro:Broadcast[collection.Map[String, String]],aoiAreaInfoMapBroad:Broadcast[collection.Map[String, String]])={
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        //select a.*, b.*, c.geo_location ,d.aoiid,d.aoicode,d.dc,d.geo_location_thai
        var sql=
            s"""
              |
              |select a.*, b.*, c.geo_location ,d.aoiid,d.aoicode,d.dc,d.geo_location_thai
              |from
              |(
              |    select waybill_no,source_zone_code,dest_zone_code,addressee_dept_code,addresseeaoicode,dest_lgt,dest_lat,consignee_emp_code,cast(consigned_tm as string) as consigned_tm,deliver_emp_code,cast(signin_tm as string) as signin_tm,consignor_post_code,consignee_post_code
              |    from dwd.dwd_waybill_kex_info_dtl_di
              |    where inc_day between '$start_day' and '$end_day' and signin_tm between '$start_date' and '$end'
              | ) a
              | inner join
              | (
              |    select input_param_waybill_no,input_param_receiver_addr,input_param_receiver_addr2,input_param_receiver_postal_code,input_param_send_time,out_param_addressee_aoi_area,out_param_addressee_aoi_code,out_param_addressee_aoi_id,out_param_addressee_dept_code,out_param_addressee_transit_code,get_json_object(dest_output_param,'$$.result.data.largeDcCode') as largedccode ,get_json_object(dest_output_param,'$$.result.data.src') as src
              |    from
              |    (
              |        select *, row_number() over(partition BY input_param_waybill_no order by input_param_send_time desc) as rank
              |        from dm_gis.obs_chk_pai_log_parse_data
              |        where inc_day between '$start_day' and '$end_day' ) bb where rank = 1
              |    ) b on a.waybill_no = b. input_param_waybill_no
              |    inner join
              |    (
              |    select consignment_no, geo_location
              |        from
              |        (
              |            select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |            from ods_kems.consignment_tracking
              |            where inc_day between '$end_day' and '$end_day' and status_id='21'
              |        ) cc
              |        where rank =1
              |    )c on a.waybill_no = c.consignment_no
              | left join
              |
              |    (
              |        select consignment_no, geo_location as geo_location_thai,aoiid,aoicode,dc from dm_gis.thai_waybill_location_aoi where inc_day between '$start_day' and '$end_day'
              |
              |    ) d on a.waybill_no = d.consignment_no
              |
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |select a.*,b.hq_code from
              | (select * from dm_gis.thai_delivery_scheduling_chk_mid_data where inc_day='$end_day') a
              |left join
              |(select
              | *
              | from dim.dim_department_info_df
              | WHERE dept_type_code IN ('DB05-DB', 'DB05-JPZ', 'FB04-ZHB')
              | AND delete_flg = '0'
              | and inc_day = '$end_day' ) b on a.dest_zone_code = b.dept_code
              |
              |
              |
              |""".stripMargin



        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val addOtherWaybillAoi = dataRdd.distinct().mapPartitions(x => {
            val list = new ListBuffer[JSONObject]()
            for (obj <- x) {
                try{
                    val geo_location = obj.getString("geo_location")
                    val geo_location_thai = obj.getString("geo_location_thai")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    if(geo_location_thai==null||geo_location_thai.isEmpty){
                        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                            val (aoi_id,aoi_code,zno_code) = getAoiFromInterface(x, y)
                            obj.put("aoiid", aoi_id)
                            obj.put("aoicode", aoi_code)
                            obj.put("dc", zno_code)
                        }
                    }


                }catch {case e:Exception=>logger.error(e.getMessage)}

                list += obj
            }
            list.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("对于没有aoi的数据重新调用点落aoi接口----》"+addOtherWaybillAoi.count())
        val addBatchAoiRdd = addOtherWaybillAoi.map(x => (x.getString("deliver_emp_code"), x)).leftOuterJoin(batchAoiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.put("batch_aoi", rightOp.get.getString("batch_aoi"))

                }

            }
            leftObj


        })

        val resultRdd = addBatchAoiRdd.map(obj => {
            val postalMap = postalMapBro.value
            val aoiAreaInfoMap = aoiAreaInfoMapBroad.value
            val out_param_addressee_aoi_id = obj.getString("out_param_addressee_aoi_id")
            val batch_aoi = obj.getString("batch_aoi")
            val out_param_addressee_aoi_code = obj.getString("out_param_addressee_aoi_code")
            val out_param_addressee_aoi_area=obj.getString("out_param_addressee_aoi_area")
            val aoiid = obj.getString("aoiid")
            val out_param_addressee_dept_code = obj.getString("out_param_addressee_dept_code")
            val largedccode = obj.getString("largedccode")
            val dest_zone_code = obj.getString("dest_zone_code")
            val input_param_receiver_postal_code = obj.getString("input_param_receiver_postal_code")
            val address1 = replaceInvalidStr(obj.getString("input_param_receiver_addr"))
            val address2 = replaceInvalidStr(obj.getString("input_param_receiver_addr2"))
            val address = address1 + " " + address2
            var output_80_aoi_area_id=""
            obj.put("addresspin",address.trim)
            var city_code = ""
            var county = ""
            if (postalMap.contains(input_param_receiver_postal_code)) {
                val str = postalMap.get(input_param_receiver_postal_code).get.split("\001")
                if (str.length > 1) {
                    city_code = str(0)
                    county = str(1)
                }

            }

            if(aoiAreaInfoMap.contains(aoiid)){
                output_80_aoi_area_id=aoiAreaInfoMap.get(aoiid).get
            }

            val dc = obj.getString("dc")
            //丰图是否识别AOI
            var is_recognize_aoi = "false"
            //是否存在排班aoi
            var is_exist_batch_aoi = "false"
            //识别小件AOI与排班AOI是否一致
            var is_same_xj_batch_aoi = "false"
            //识别小件AOI与妥投AOI是否一致
            var is_same_xj_80_aoi = "false"

            //识别小件DC与dest_DC是否一致
            var is_same_xj_dest_dc = "false"

            //识别大件DC与dest_DC是否一致
            var is_same_dj_dest_dc = "false"

            //识别小件DC与妥投DC是否一致
            var is_same_xj_80_dc = "false"

            //识别大件DC与妥投DC是否一致
            var is_same_dj_80_dc = "false"
            //识别小件aoi区域是否一致
            var is_same_xj_80_aoi_area="false"


            if (StringUtils.nonEmpty(out_param_addressee_aoi_id)) {
                is_recognize_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi)) {
                is_exist_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(out_param_addressee_aoi_code) && batch_aoi.contains(out_param_addressee_aoi_code)) {
                is_same_xj_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(out_param_addressee_aoi_id) && StringUtils.nonEmpty(aoiid) && out_param_addressee_aoi_id.equals(aoiid)) {
                is_same_xj_80_aoi = "true"
            }

            if (StringUtils.nonEmpty(out_param_addressee_dept_code) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(out_param_addressee_dept_code)) {
                is_same_xj_dest_dc = "true"
            }

            if (StringUtils.nonEmpty(largedccode) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(largedccode)) {
                is_same_dj_dest_dc = "true"
            }
            if (StringUtils.nonEmpty(out_param_addressee_dept_code) && StringUtils.nonEmpty(dc) && dc.equals(out_param_addressee_dept_code)) {
                is_same_xj_80_dc = "true"
            }
            if (StringUtils.nonEmpty(largedccode) && StringUtils.nonEmpty(dc) && dc.equals(largedccode)) {
                is_same_dj_80_dc = "true"
            }
            if(StringUtils.nonEmpty(output_80_aoi_area_id)&&StringUtils.nonEmpty(out_param_addressee_aoi_area)&&out_param_addressee_aoi_area.equals(output_80_aoi_area_id)){
                is_same_xj_80_aoi_area="true"

            }

            obj.put("is_recognize_aoi", is_recognize_aoi)
            obj.put("is_exist_batch_aoi", is_exist_batch_aoi)
            obj.put("is_same_xj_batch_aoi", is_same_xj_batch_aoi)
            obj.put("is_same_xj_80_aoi", is_same_xj_80_aoi)
            obj.put("is_same_xj_dest_dc", is_same_xj_dest_dc)
            obj.put("is_same_dj_dest_dc", is_same_dj_dest_dc)
            obj.put("is_same_xj_80_dc", is_same_xj_80_dc)
            obj.put("is_same_dj_80_dc", is_same_dj_80_dc)
            obj.put("city_code", city_code)
            obj.put("district", county)
            obj.put("output_80_aoi_area_id", output_80_aoi_area_id)
            obj.put("is_same_xj_80_aoi_area", is_same_xj_80_aoi_area)

            obj
        }).distinct()

        resultRdd


    }


    def calcAccuracyNew(spark: SparkSession,end_day:String,end_date:String,start_day:String,batchAoiRdd:RDD[(String,JSONObject)],postalMapBro:Broadcast[collection.Map[String, String]])={
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        //select a.*, b.*, c.geo_location ,d.aoiid,d.aoicode,d.dc,d.geo_location_thai
        var sql=
            s"""
               |
               |select a.*, b.*, c.geo_location ,d.aoiid,d.aoicode,d.dc,d.geo_location_thai
               |from
               |(
               |    select waybill_no,source_zone_code,dest_zone_code,addressee_dept_code,addresseeaoicode,dest_lgt,dest_lat,consignee_emp_code,cast(consigned_tm as string) as consigned_tm,deliver_emp_code,cast(signin_tm as string) as signin_tm,consignor_post_code,consignee_post_code
               |    from dwd.dwd_waybill_kex_info_dtl_di
               |    where inc_day between '$start_day' and '$end_day' and signin_tm between '$start_date' and '$end'
               | ) a
               | inner join
               | (
               |    select input_param_waybill_no,input_param_receiver_addr,input_param_receiver_addr2,input_param_receiver_postal_code,input_param_send_time,out_param_addressee_aoi_area,out_param_addressee_aoi_code,out_param_addressee_aoi_id,out_param_addressee_dept_code,out_param_addressee_transit_code,get_json_object(dest_output_param,'$$.result.data.largeDcCode') as largedccode ,get_json_object(dest_output_param,'$$.result.data.src') as src
               |    from
               |    (
               |        select *, row_number() over(partition BY input_param_waybill_no order by input_param_send_time desc) as rank
               |        from dm_gis.obs_chk_pai_log_parse_data
               |        where inc_day between '$start_day' and '$end_day' ) bb where rank = 1
               |    ) b on a.waybill_no = b. input_param_waybill_no
               |    inner join
               |    (
               |    select consignment_no, geo_location
               |        from
               |        (
               |            select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |            from ods_kems.consignment_tracking
               |            where inc_day between '$end_day' and '$end_day' and status_id='21'
               |        ) cc
               |        where rank =1
               |    )c on a.waybill_no = c.consignment_no
               | left join
               |
               |    (
               |        select consignment_no, geo_location as geo_location_thai,aoiid,aoicode,dc from dm_gis.thai_waybill_location_aoi where inc_day between '$start_day' and '$end_day'
               |
               |    ) d on a.waybill_no = d.consignment_no
               |
               |
               |
               |""".stripMargin

        sql=
            s"""
               |
               |select a.*,b.hq_code from
               | (select * from dm_gis.thai_delivery_scheduling_chk_mid_data where inc_day='$end_day') a
               |left join
               |(select
               | *
               | from dim.dim_department_info_df
               | WHERE dept_type_code IN ('DB05-DB', 'DB05-JPZ', 'FB04-ZHB')
               | AND delete_flg = '0'
               | and inc_day = '$end_day' ) b on a.dest_zone_code = b.dept_code
               |
               |
               |
               |""".stripMargin

        sql=
            s"""
               |
               |select * from dm_gis.thai_delivery_scheduling_chk where inc_day='$end_day'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val postalMap = postalMapBro.value
            val out_param_addressee_aoi_id = obj.getString("out_param_addressee_aoi_id")
            val batch_aoi = obj.getString("batch_aoi")
            val out_param_addressee_aoi_code = obj.getString("out_param_addressee_aoi_code")
            val aoiid = obj.getString("aoiid")
            val out_param_addressee_dept_code = obj.getString("out_param_addressee_dept_code")
            val largedccode = obj.getString("largedccode")
            val dest_zone_code = obj.getString("dest_zone_code")
            val input_param_receiver_postal_code = obj.getString("input_param_receiver_postal_code")
            val address1 = replaceInvalidStr(obj.getString("input_param_receiver_addr"))
            val address2 = replaceInvalidStr(obj.getString("input_param_receiver_addr2"))
            val address = address1 + " " + address2
            obj.put("addresspin",address.trim)
            var city_code = ""
            var county = ""
            if (postalMap.contains(input_param_receiver_postal_code)) {
                val str = postalMap.get(input_param_receiver_postal_code).get.split("\001")
                if (str.length > 1) {
                    city_code = str(0)
                    county = str(1)
                }

            }


            val dc = obj.getString("dc")
            //丰图是否识别AOI
            var is_recognize_aoi = "false"
            //是否存在排班aoi
            var is_exist_batch_aoi = "false"
            //识别小件AOI与排班AOI是否一致
            var is_same_xj_batch_aoi = "false"
            //识别小件AOI与妥投AOI是否一致
            var is_same_xj_80_aoi = "false"

            //识别小件DC与dest_DC是否一致
            var is_same_xj_dest_dc = "false"

            //识别大件DC与dest_DC是否一致
            var is_same_dj_dest_dc = "false"

            //识别小件DC与妥投DC是否一致
            var is_same_xj_80_dc = "false"

            //识别大件DC与妥投DC是否一致
            var is_same_dj_80_dc = "false"


            if (StringUtils.nonEmpty(out_param_addressee_aoi_id)) {
                is_recognize_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi)) {
                is_exist_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(out_param_addressee_aoi_code) && batch_aoi.contains(out_param_addressee_aoi_code)) {
                is_same_xj_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(out_param_addressee_aoi_id) && StringUtils.nonEmpty(aoiid) && out_param_addressee_aoi_id.equals(aoiid)) {
                is_same_xj_80_aoi = "true"
            }

            if (StringUtils.nonEmpty(out_param_addressee_dept_code) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(out_param_addressee_dept_code)) {
                is_same_xj_dest_dc = "true"
            }

            if (StringUtils.nonEmpty(largedccode) && StringUtils.nonEmpty(dest_zone_code) && dest_zone_code.equals(largedccode)) {
                is_same_dj_dest_dc = "true"
            }
            if (StringUtils.nonEmpty(out_param_addressee_dept_code) && StringUtils.nonEmpty(dc) && dc.equals(out_param_addressee_dept_code)) {
                is_same_xj_80_dc = "true"
            }
            if (StringUtils.nonEmpty(largedccode) && StringUtils.nonEmpty(dc) && dc.equals(largedccode)) {
                is_same_dj_80_dc = "true"
            }

            obj.put("is_recognize_aoi", is_recognize_aoi)
            obj.put("is_exist_batch_aoi", is_exist_batch_aoi)
            obj.put("is_same_xj_batch_aoi", is_same_xj_batch_aoi)
            obj.put("is_same_xj_80_aoi", is_same_xj_80_aoi)
            obj.put("is_same_xj_dest_dc", is_same_xj_dest_dc)
            obj.put("is_same_dj_dest_dc", is_same_dj_dest_dc)
            obj.put("is_same_xj_80_dc", is_same_xj_80_dc)
            obj.put("is_same_dj_80_dc", is_same_dj_80_dc)
            obj.put("city_code", city_code)
            obj.put("district", county)

            obj
        }).distinct()

        resultRdd


    }


    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        Thread.sleep(3000)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }


}
