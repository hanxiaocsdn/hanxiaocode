package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions.col

import scala.collection.mutable.ArrayBuffer

/**
 * 泰国轨迹数据存储V1.1
 * 需求方：李非龙（ft220114）
 * @author 徐游飞（01417347）
 * 任务ID：766381
 * 任务名称：嘉里车辆轨迹解析
 */
object GisVmsTrackDeviceTrack {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  /**
     * 把df数据按分区覆盖写入到hive
     * @param spark
     * @param dataframe
     * @param partitionCol 分区字段
     * @param resTableName hive表名
   * */

  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    logger.error(s"$resTableName 表写入完成")
    spark.catalog.dropTempView("tmpTableName")
  }

  // 将df的每一行数据转为json
  def row2Json(r: Row): JSONObject = {
    val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
    val rowMap: Map[String, String] = rowMap_tmp.map(v => {
      if (v._2 == null) (v._1, "") else v
    })
    val obj: JSONObject = new JSONObject()
    for (m <- rowMap) obj.put(m._1, m._2)
    obj
  }

  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val` : String = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case _: Exception =>
    }
    if(`val` == null) `val` = defaultValue
    `val`
  }

  def execute(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {
    import spark.implicits._
    val log_sql =
      s"""
        |select
        |  data as log,
        |  inc_day
        |from
        |  dm_gis.dm_xyf_tmp_log_di
        |where
        |  inc_day >= '$dayBefore3'
        |  and inc_day <= '$dayBefore1'
        |""".stripMargin
    println(log_sql)

    spark.sql(log_sql).show(2,false)

    val ret_df = spark.sql(log_sql).rdd
      .flatMap(obj=>{
        val log = obj.getString(0)
        val inc_day = obj.getString(1)
        val data_arr = JSON.parseArray(log)

        val list = new ArrayBuffer[JSONObject]()
        for( i <- 0 until data_arr.size() ){
          val data_obj = JSON.parseObject(data_arr.getString(i))
          data_obj.put("inc_day",inc_day)
          list += data_obj
        }
        list.iterator
      }).map(data_obj=>{
        val id = getJsonVal(data_obj, "id", "")
        val un = getJsonVal(data_obj, "un", "")
        val tp = getJsonVal(data_obj, "tp", "")
        val zx = getJsonVal(data_obj, "zx", "")
        val zy = getJsonVal(data_obj, "zy", "")
        val ac = getJsonVal(data_obj, "ac", "")
        val ad = getJsonVal(data_obj, "ad", "")
        val be = getJsonVal(data_obj, "be", "")
        val sl = getJsonVal(data_obj, "sl", "")
        val sp = getJsonVal(data_obj, "sp", "")
        val tm = getJsonVal(data_obj, "tm", "")
        val sc = getJsonVal(data_obj, "sc", "")
        val cr = getJsonVal(data_obj, "cr", "")
        val bt = getJsonVal(data_obj, "bt", "")
        val xh = getJsonVal(data_obj, "xh", "")
        val ak = getJsonVal(data_obj, "ak", "")
        val dx = getJsonVal(data_obj, "dx", "")
        val dy = getJsonVal(data_obj, "dy", "")
        val state = getJsonVal(data_obj, "state", "")
        val pc = getJsonVal(data_obj, "pc", "")
        val rt = getJsonVal(data_obj, "rt", "")
        val inc_day = getJsonVal(data_obj, "inc_day", "")

        (id,un,tp,zx,zy,ac,ad,be,sl,sp,tm,sc,cr,bt,xh,ak,dx,dy,state,pc,rt,inc_day)
    }).toDF("id","un","tp","zx","zy","ac","ad","be","sl","sp","tm","sc","cr","bt","xh","ak","dx","dy","state","pc","rt","inc_day")

    val cols_all = spark.sql("""select * from dm_gis.dm_vms_track_device_track_dtl_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, ret_df.select(cols_all: _*), Seq("inc_day"), "dm_gis.dm_vms_track_device_track_dtl_di")

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error("++++++++  任务开始 20230814 vvvvvvvvv ++++")
    // 开始解析轨迹日志
    execute(spark,dayBefore1,dayBefore3)

    logger.error("++++++++  任务完成 20230814  ++++")

    spark.stop()

  }

}
