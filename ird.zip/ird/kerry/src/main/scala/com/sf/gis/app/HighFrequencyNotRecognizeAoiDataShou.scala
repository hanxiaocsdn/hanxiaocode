package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.ThaiDcAccuracyReport.{getZhUrlData, logger, zhUrl}
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-10-12 16:22
 * @TaskId:869593
 * @TaskName:
 * @Description:高频未识别下发核实收件数据
 */

object HighFrequencyNotRecognizeAoiDataShou {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("booking_no","address","address2","customer_address","geo_location_order","postcode_id","geo_location_desc","id","pickup_order_route_id","tracking_datetime","status_id","exception_id","person_incharge","remark","location_dc_id","created_by","created_date","modified_by","modified_date","timestamp","deleted_flag","deleted_datetime","deleted_by","deleted_remark","last_source","last_client_name","last_access_ip","geo_location","sync_status","sync_status_datetime","addresspin","addr_freq","src","interface_data")

    val saveTmpKey=Array("booking_no","address","address2","customer_address","geo_location_order","postcode_id","geo_location_desc","id","pickup_order_route_id","tracking_datetime","status_id","exception_id","person_incharge","remark","location_dc_id","created_by","created_date","modified_by","modified_date","timestamp","deleted_flag","deleted_datetime","deleted_by","deleted_remark","last_source","last_client_name","last_access_ip","geo_location","sync_status","sync_status_datetime","addresspin")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val start_date=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取原来已下发数据")
        val oldAddrRdd = getOldData(sparkSession, end_day)
        logger.error("统计新增待下发数据")
        val resultRdd = getData(sparkSession, end_day, oldAddrRdd,start_day,end_date,start_date)
        logger.error("存储待下发数据数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_weishibie_weixiafa_chk_shou_mid_data",Array(("inc_day", end_day)), 25)


    }
    def getOldData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select addresspin from dm_gis.thai_weishibie_weixiafa_chk_shou where inc_day<'$end_day'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        dataRdd.map(x=>(x.getString("addresspin"),x))

    }

    def getData(spark: SparkSession,end_day:String,addrRdd:RDD[(String,JSONObject)],start_day:String,end_date:String,start_date:String)={
        var start=start_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql=
            s"""
              |
              |
              |select po.booking_no, po.address,po.address2,po.customer_address,po.geo_location as geo_location_order ,po.postcode_id,po.geo_location_desc ,pot.*
              |from
              |(
              |    select
              |	id
              |	,cast(pickup_order_route_id as string) as pickup_order_route_id
              |	,cast(tracking_datetime as string) as tracking_datetime
              |	,cast(status_id as string) as status_id
              |	,cast(exception_id as string) as exception_id
              |	,person_incharge
              |	,remark
              |	,cast(location_dc_id as string) as location_dc_id
              |	,created_by
              |	,cast(created_date as string) as created_date
              |	,modified_by
              |	,cast(modified_date as string) as modified_date
              |	,cast(`timestamp` as string) as `timestamp`
              |	,deleted_flag
              |	,cast(deleted_datetime as string) as deleted_datetime
              |	,deleted_by
              |	,deleted_remark
              |	,last_source
              |	,last_client_name
              |	,last_access_ip
              |	,geo_location
              |	,sync_status
              |	,cast(sync_status_datetime as string) as sync_status_datetime
              |    from ods_kems.pickup_order_tracking
              |    where inc_day between '$start_day' and '$end_day' and Tracking_Datetime >='$start' and Tracking_Datetime <'$end' and Status_ID =3 ) pot
              |inner join (select * from ods_kems.pickup_order_route where  inc_day between '$start_day' and '$end_day' ) por on pot.Pickup_Order_Route_ID =por.ID
              |inner join (select * from ods_kems.pickup_order where  inc_day between '$start_day' and '$end_day' ) po on por.Pickup_Order_ID =po.id
              |
              |""".stripMargin

        sql=
            s"""
              |
              |select * from dm_gis.thai_weishibie_weixiafa_chk_shou_tmp where inc_day='$end_day'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val midRdd = dataRdd.map(obj => {
            val address1 = replaceInvalidStr(obj.getString("address"))
            val address2 = replaceInvalidStr(obj.getString("address2"))
            val address = address1 + " " + address2
            obj.put("addresspin", address.trim)
            obj

        })

        val highFrequencyRdd= midRdd.groupBy(x => x.getString("addresspin")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val address_num = x._2.toList.length
            val tmpObj = new JSONObject()
            tmpObj.fluentPutAll(x._2.head)
            tmpObj.put("addr_freq", address_num)
            listBuffer+=tmpObj

            listBuffer
        }).map(x => (x.getString("addresspin"), x)).leftOuterJoin(addrRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                if (rightObj.isEmpty) {
                    dataObj.fluentPutAll(leftObj)

                }

            }
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("addresspin"))).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("高频地址数据量----》"+highFrequencyRdd.count())
        val resultRdd =highFrequencyRdd.map(obj=>{

            val parmObj = new JSONObject()
            var recipient_address = obj.getString("address")
            var recipient_address2 = obj.getString("address2")
            val recipient_postcode_id = obj.getString("postcode_id")
//            if(StringUtils.nonEmpty(recipient_address)){
//                recipient_address=URLEncoder.encode(recipient_address, "UTF-8")
//            }
//            if(StringUtils.nonEmpty(recipient_address2)){
//                recipient_address2=URLEncoder.encode(recipient_address2, "UTF-8")
//            }

            parmObj.put("address", recipient_address)
            parmObj.put("address2", recipient_address2)
            parmObj.put("zipcode", recipient_postcode_id)
            parmObj.put("type", "con")
            parmObj.put("extend", "1")

            val (srcchk,dcCodechk,largeDcCodechk,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject) = getZhUrlData(parmObj)
            obj.put("src",srcchk)
            obj.put("interface_data",jSONObject)
            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        //.filter(obj=>StringUtils.nonEmpty(obj.getString("src"))&&(!Array("his","ml","geo-kw").contains(obj.getString("src"))))
        logger.error("查询的总数据量:" + resultRdd.count())

        /*

        .filter(x => {
            val addr_freq = x.getString("addr_freq")
            if (StringUtils.nonEmpty(addr_freq) && addr_freq.toLong >= 7) {
                true
            } else {
                false
            }

        }).
         */

        resultRdd

    }



    def replaceInvalidStr(addr:String): String ={
        var addrs=""
        if(!StringUtils.nonEmpty(addr)){
            return addrs
        }
        var flag=true
        addrs=addr.trim
        while(flag){
            if(addrs.matches("^([-])(.*)|(.*)([-])$")){
                addrs=addrs.replaceAll("^([-])?|([-])?$","").trim
            }else{
                flag=false
            }
        }
        addrs

    }

    def getZhUrlData(parm:JSONObject): (String, String, String, String, String, String, JSONObject) ={

        //        var nowHour = getHour()
        //        while (!(nowHour>=22||(nowHour>=0&&nowHour<8))){
        //            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
        //            Thread.sleep(1000*60)
        //            nowHour = getHour()
        //
        //        }
        var src=""
        var dcCode=""
        var largeDcCode=""
        var result_data_aoiid=""
        var result_data_aoicode=""
        var result_data_aoiarea=""
        var jSONObject =new JSONObject()

        if(parm.size()<1){
            return (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)
        }
        Thread.sleep(260)
        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","a0e79cf6697349a2b13bb5fa6ffe96c8")
        breakable {
            for(i<-0 until(3)){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(zhUrl, parm, stringToString))
                }
                catch {
                    case e:Exception=>{
                        logger.error("error parameter-----> "+parm.toString())
                        val stackTraceElement = e.getStackTrace()(0)
                        src="系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber()
                        new JSONObject()
                    }
                }
                val status = JSONUtil.getJsonVal(jSONObject, "status", "")
                val msg = JSONUtil.getJsonVal(jSONObject, "result.msg", "")

                if(StringUtils.nonEmpty(status)&&status.equals("0")){
                    break
                }else{
                    if(msg.contains("many")&&msg.contains("too")){
                        Thread.sleep(30000)
                    }else{
                        break
                    }

                }
            }

        }


        src = JSONUtil.getJsonVal(jSONObject, "result.data.src", "")
        val status = JSONUtil.getJsonVal(jSONObject, "status", "")
        if(!status.equals("0")){
            src=JSONUtil.getJsonVal(jSONObject, "result.msg", "")
        }
        dcCode = JSONUtil.getJsonVal(jSONObject, "result.data.dcCode", "")
        largeDcCode = JSONUtil.getJsonVal(jSONObject, "result.data.largeDcCode", "")
        result_data_aoiid=JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        result_data_aoicode=JSONUtil.getJsonVal(jSONObject, "result.data.aoiCode", "")
        result_data_aoiarea=JSONUtil.getJsonVal(jSONObject, "result.data.aoiArea", "")
        (src,dcCode,largeDcCode,result_data_aoiid,result_data_aoicode,result_data_aoiarea,jSONObject)

    }

}




