package com.sf.gis.app


import com.alibaba.fastjson.JSON
import com.obs.services.ObsClient
import com.sf.gis.java.utils.HuaweiObsUtil
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession




/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-07-11 17:56
 * @TaskId:777862
 * @TaskName:
 * @Description:chk query日志解析
 */

object ChkQueryLogParse {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("param_mobile2","param_zipcode","param_subdistrict","param_address2","param_mobile","param_road","param_phone","param_soi","param_consignmentno","param_province","param_fax","param_address","param_district","param_opt","type","data_result_query_consignmentno","data_result_query_address","data_result_query_address2","data_result_query_zipcode","data_result_query_phone","data_result_query_subdistrict","data_result_query_district","data_result_query_province","data_result_data_aoiarea","data_result_data_subdistrict","data_result_data_zipcode","data_result_data_dccode","data_result_data_areacode","data_result_data_src","data_result_data_transcode","data_result_data_linehaulroute","data_result_data_largedccode","data_result_data_aoicode","data_result_data_aoiid","hostip","podip","containername","data_status","hostid","ak","podname","datetime","hostname","clusterid","pathfile","data_reqid","content","clustername","namespace","sn","collecttime","remoteip","appname","url","uno","time","category","serviceid","call_type","log","data_result_data_largeaoiarea","param_type")


    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("解析日志")
        val resultRdd = parseLog(sparkSession, end_day)
        logger.error("存储数据日志")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.obs_chk_query_log_parse_data",Array(("inc_day", end_day)), 25)



    }
    def parseLog(spark: SparkSession,end_day:String)={

        var sql=
            s"""
              |
              |select log from dm_gis.obs_chk_query_log where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val log = obj.getString("log")
            try {
                val logObj = JSON.parseObject(log)
                val param_mobile2 = JSONUtil.getJsonVal(logObj, "param.mobile2", "")
                val param_type = JSONUtil.getJsonVal(logObj, "param.type", "")
                val param_zipcode = JSONUtil.getJsonVal(logObj, "param.zipcode", "")
                val param_subdistrict = JSONUtil.getJsonVal(logObj, "param.subDistrict", "")
                val param_address2 = JSONUtil.getJsonVal(logObj, "param.address2", "")
                val param_mobile = JSONUtil.getJsonVal(logObj, "param.mobile", "")
                val param_road = JSONUtil.getJsonVal(logObj, "param.road", "")
                val param_phone = JSONUtil.getJsonVal(logObj, "param.phone", "")
                val param_soi = JSONUtil.getJsonVal(logObj, "param.soi", "")
                val param_consignmentno = JSONUtil.getJsonVal(logObj, "param.consignmentNo", "")
                val param_province = JSONUtil.getJsonVal(logObj, "param.province", "")
                val param_fax = JSONUtil.getJsonVal(logObj, "param.fax", "")
                val param_address = JSONUtil.getJsonVal(logObj, "param.address", "")
                val param_district = JSONUtil.getJsonVal(logObj, "param.district", "")
                val param_opt = JSONUtil.getJsonVal(logObj, "param.opt", "")
                val type_ = JSONUtil.getJsonVal(logObj, "type", "")
                val data_result_query_consignmentno = JSONUtil.getJsonVal(logObj, "data.result.query.consignmentNo", "")
                val data_result_query_address = JSONUtil.getJsonVal(logObj, "data.result.query.address", "")
                val data_result_query_address2 = JSONUtil.getJsonVal(logObj, "data.result.query.address2", "")
                val data_result_query_zipcode = JSONUtil.getJsonVal(logObj, "data.result.query.zipcode", "")
                val data_result_query_phone = JSONUtil.getJsonVal(logObj, "data.result.query.phone", "")
                val data_result_query_subdistrict = JSONUtil.getJsonVal(logObj, "data.result.query.subDistrict", "")
                val data_result_query_district = JSONUtil.getJsonVal(logObj, "data.result.query.district", "")
                val data_result_query_province = JSONUtil.getJsonVal(logObj, "data.result.query.province", "")
                val data_result_data_aoiarea = JSONUtil.getJsonVal(logObj, "data.result.data.aoiArea", "")
                val data_result_data_subdistrict = JSONUtil.getJsonVal(logObj, "data.result.data.subDistrict", "")
                val data_result_data_zipcode = JSONUtil.getJsonVal(logObj, "data.result.data.zipcode", "")
                val data_result_data_dccode = JSONUtil.getJsonVal(logObj, "data.result.data.dcCode", "")
                val data_result_data_areacode = JSONUtil.getJsonVal(logObj, "data.result.data.areaCode", "")
                val data_result_data_src = JSONUtil.getJsonVal(logObj, "data.result.data.src", "")
                val data_result_data_transcode = JSONUtil.getJsonVal(logObj, "data.result.data.transCode", "")
                val data_result_data_linehaulroute = JSONUtil.getJsonVal(logObj, "data.result.data.lineHaulRoute", "")
                val data_result_data_largedccode = JSONUtil.getJsonVal(logObj, "data.result.data.largeDcCode", "")
                val data_result_data_largeaoiarea = JSONUtil.getJsonVal(logObj, "data.result.data.largeAoiArea", "")
                val data_result_data_aoicode = JSONUtil.getJsonVal(logObj, "data.result.data.aoiCode", "")
                val data_result_data_aoiid = JSONUtil.getJsonVal(logObj, "data.result.data.aoiId", "")
                val hostip = JSONUtil.getJsonVal(logObj, "hostIP", "")
                val podip = JSONUtil.getJsonVal(logObj, "podIp", "")
                val containername = JSONUtil.getJsonVal(logObj, "containerName", "")
                val data_status = JSONUtil.getJsonVal(logObj, "data.status", "")
                val hostid = JSONUtil.getJsonVal(logObj, "hostId", "")
                val ak = JSONUtil.getJsonVal(logObj, "ak", "").substring(0,5)
                val podname = JSONUtil.getJsonVal(logObj, "podName", "")
                val datetime = JSONUtil.getJsonVal(logObj, "dateTime", "")
                val hostname = JSONUtil.getJsonVal(logObj, "hostName", "")
                val clusterid = JSONUtil.getJsonVal(logObj, "clusterId", "")
                val pathfile = JSONUtil.getJsonVal(logObj, "pathFile", "")
                val data_reqid = JSONUtil.getJsonVal(logObj, "data.reqId", "")
                val content = JSONUtil.getJsonVal(logObj, "content", "")
                val clustername = JSONUtil.getJsonVal(logObj, "clusterName", "")
                val namespace = JSONUtil.getJsonVal(logObj, "nameSpace", "")
                val sn = JSONUtil.getJsonVal(logObj, "sn", "")
                val collecttime = JSONUtil.getJsonVal(logObj, "collectTime", "")
                val remoteip = JSONUtil.getJsonVal(logObj, "remoteIp", "")
                val appname = JSONUtil.getJsonVal(logObj, "appName", "")
                val url = JSONUtil.getJsonVal(logObj, "url", "")
                val uno = JSONUtil.getJsonVal(logObj, "uno", "")
                val time = JSONUtil.getJsonVal(logObj, "time", "")
                val category = JSONUtil.getJsonVal(logObj, "category", "")
                val serviceid = JSONUtil.getJsonVal(logObj, "serviceID", "")


                obj.put("param_mobile2", param_mobile2)
                obj.put("param_type", param_type)
                obj.put("param_zipcode", param_zipcode)
                obj.put("param_subdistrict", param_subdistrict)
                obj.put("param_address2", param_address2)
                obj.put("param_mobile", param_mobile)
                obj.put("param_road", param_road)
                obj.put("param_phone", param_phone)
                obj.put("param_soi", param_soi)
                obj.put("param_consignmentno", param_consignmentno)
                obj.put("param_province", param_province)
                obj.put("param_fax", param_fax)
                obj.put("param_address", param_address)
                obj.put("param_district", param_district)
                obj.put("param_opt", param_opt)
                obj.put("type", type_)
                obj.put("data_result_query_consignmentno", data_result_query_consignmentno)
                obj.put("data_result_query_address", data_result_query_address)
                obj.put("data_result_query_address2", data_result_query_address2)
                obj.put("data_result_query_zipcode", data_result_query_zipcode)
                obj.put("data_result_query_phone", data_result_query_phone)
                obj.put("data_result_query_subdistrict", data_result_query_subdistrict)
                obj.put("data_result_query_district", data_result_query_district)
                obj.put("data_result_query_province", data_result_query_province)
                obj.put("data_result_data_aoiarea", data_result_data_aoiarea)
                obj.put("data_result_data_subdistrict", data_result_data_subdistrict)
                obj.put("data_result_data_zipcode", data_result_data_zipcode)
                obj.put("data_result_data_dccode", data_result_data_dccode)
                obj.put("data_result_data_areacode", data_result_data_areacode)
                obj.put("data_result_data_src", data_result_data_src)
                obj.put("data_result_data_transcode", data_result_data_transcode)
                obj.put("data_result_data_linehaulroute", data_result_data_linehaulroute)
                obj.put("data_result_data_largedccode", data_result_data_largedccode)
                obj.put("data_result_data_largeaoiarea", data_result_data_largeaoiarea)

                obj.put("data_result_data_aoicode", data_result_data_aoicode)
                obj.put("data_result_data_aoiid", data_result_data_aoiid)
                obj.put("hostip", hostip)
                obj.put("podip", podip)
                obj.put("containername", containername)
                obj.put("data_status", data_status)
                obj.put("hostid", hostid)
                obj.put("ak", ak)
                obj.put("podname", podname)
                obj.put("datetime", datetime)
                obj.put("hostname", hostname)
                obj.put("clusterid", clusterid)
                obj.put("pathfile", pathfile)
                obj.put("data_reqid", data_reqid)
                obj.put("content", content)
                obj.put("clustername", clustername)
                obj.put("namespace", namespace)
                obj.put("sn", sn)
                obj.put("collecttime", collecttime)
                obj.put("remoteip", remoteip)
                obj.put("appname", appname)
                obj.put("url", url)
                obj.put("uno", uno)
                obj.put("time", time)
                obj.put("category", category)
                obj.put("serviceid", serviceid)
                obj.put("call_type","")


            } catch {
                case e: Exception => {
                    logger.error(e.getStackTrace)

                }
            }
            obj
        }).filter(x=>StringUtils.nonEmpty(x.getString("data_result_query_consignmentno"))).distinct()
        resultRdd


    }

    def testOBS()={
        val mgsocol_obs_ak = "KMHJBPAIWF1YN8719PJX"
        val mgsocol_obs_sk = "UHJtA5vHfl7sw0hY2bumChikOVjuwky3L29mRdzw"
        //    val mgsocol_obs_endPoint = "https://kex-gis-ird-core-os.obs.ap-southeast-2.myhuaweicloud.com"
        val mgsocol_obs_endPoint = "obs.ap-southeast-2.myhuaweicloud.com"
        val client = new ObsClient(mgsocol_obs_ak, mgsocol_obs_sk, mgsocol_obs_endPoint)
        val bucketName="kex-gis-ird-core-os"
        //        val path="443/LogTanks/ap-southeast-2/lts"

        val objKeyList = HuaweiObsUtil.listAllDirs(client, bucketName)
        logger.error(" obj key --->"+objKeyList)
        //        val fileList = HuaweiObsUtil.listDirs(client, bucketName, path)
        //        logger.error("file list --->"+fileList.toString)
        //        val dataList = HuaweiObsUtil.getObsData(client, bucketName, path).asScala
        //        logger.error("数据量---》  "+dataList.size)
        HuaweiObsUtil.writeFileToLocal(client,bucketName,"LogTanks/ap-southeast-2/lts/2023/07/12/ird_chk_query_systemLog_LogTank_0ee535f6bb0090ab2f06c0196f505354_2023-07-12T08-50-00Z_c934142d5268d4ad.gz","")
        //        val value = sparkSession.sparkContext.parallelize(dataList)
        //        value.take(10).foreach(println)


    }

}
