package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.GisVmsTrackDeviceTrack.{row2Json, writeToHive}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import java.util
import java.util.Calendar
import scala.util.control.Breaks.{break, breakable}

/**
 * 泰国嘉里分单仓管审补地址自动化回收工艺需求_V1.0(贡献率)
 * 需求方：陈丽（01430458）
 * @author 徐游飞（01417347）
 * 任务ID：874299
 * 任务名称：嘉里分单仓管审补_地址贡献率
 */
object ThaiAoiShenbuContri {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def aoiShenbuContri(spark: SparkSession, inc_day: String) = {
    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 2)

    val scheduling_sql =
      s"""
         |select
         |  addresspin,
         |  waybill_no,
         |  is_recognize_aoi,
         |  is_exist_batch_aoi,
         |  is_same_xj_batch_aoi,
         |  is_same_xj_80_aoi,
         |  is_same_out_his80_aoi
         |from
         |  dm_gis.thai_delivery_scheduling_chk
         |where
         |  inc_day = '$dayBefore2'
         |""".stripMargin
    println(scheduling_sql)
    val df_scheduling = spark.sql(scheduling_sql)

    val shenbu_v1_sql =
      s"""
         |select
         |  address as addresspin,
         |  1 as join_tag
         |from
         |  dm_gis.thai_aoi_shenbu_v1
         |where
         |  inc_day = '$dayBefore1'
         |  and code = '200'
         |""".stripMargin
    println(shenbu_v1_sql)
    val df_shenbu_v1 = spark.sql(shenbu_v1_sql)

    val filter_tag1 = when('join_tag === 1 and 'is_recognize_aoi === "true" and 'is_exist_batch_aoi === "true" and 'is_same_xj_batch_aoi === "false"
      and 'is_same_xj_80_aoi === "false" and !'waybill_no.contains("RTN") and 'is_same_out_his80_aoi =!= "true",true).otherwise(false)
    val filter_tag2 = when('is_recognize_aoi === "true" and 'is_exist_batch_aoi === "true" and !'waybill_no.contains("RTN"), true).otherwise(false)

    val df_contri = df_scheduling.join(df_shenbu_v1, Seq("addresspin"), "left")
      .withColumn("group_tag", lit(2))
      .withColumn("is_same_addr", when(filter_tag1, "yes"))
      .withColumn("contribution_num",count(when(filter_tag1, 'addresspin).otherwise(null)).over(Window.partitionBy("group_tag")))
      .withColumn("total_num",count(when(filter_tag2, 'addresspin).otherwise(null)).over(Window.partitionBy("group_tag")))
      .withColumn("contribution_rate", doubleToPercent(when('total_num =!= 0, 'contribution_num / 'total_num).otherwise(0.0)))
      .withColumn("inc_day", lit(dayBefore1))

    df_contri.show(2,true)
    val cols = spark.sql("""select * from dm_gis.dm_thai_aoi_shenbu_contri_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_contri.select(cols: _*).coalesce(3), Seq("inc_day"), "dm_gis.dm_thai_aoi_shenbu_contri_di")

  }

  // 将小数转化成百分数函数，保留5位
  def doubleToPercent = udf((col1: Double) => {
    var percent = "0.0%"
    if (col1 != null) {
      try {
        percent = f"${col1 * 100}%.5f%%"
      } catch {
        case e: Exception => println(">>>小数转换成百分数异常：" + e)
      }
    }
    percent
  })

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error(s"++++  任务开始 inc_day=$inc_day  ++++")
    // 计算aoi贡献率
    aoiShenbuContri(spark,inc_day)
    logger.error("++++++++  任务完成 20240125  ++++")

    spark.stop()

  }

}
