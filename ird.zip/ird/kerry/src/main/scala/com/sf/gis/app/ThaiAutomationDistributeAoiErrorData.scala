package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.utils.HttpInvokeUtil
import com.sf.gis.utils._
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2023-12-27 10:37
 * @TaskId:874045
 * @TaskName:泰国嘉里分单仓管错分任务自动下发工艺-自动下发
 * @Description:
 */

object ThaiAutomationDistributeAoiErrorData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val addWaybillTaskUrl="http://gis-ird-cms.int.os-sgp.local/globalexpress/openapi/waybill/addWaybillTask"
    ///globalexpress/openapi/waybill/addWaybillTask
    var token_all=""
    val saveKey=Array("city_code","waybill_no","consignee_post_code","out_param_addressee_dept_code","addresspin","not_fit_both","code","message")
    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = distribute(sparkSession, end_day, start_day)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_thai_shenbu_misssort_di",Array(("inc_day", end_date)), 25)



    }

    def distribute(spark: SparkSession,end_day:String,start_day:String)={


        var sql=
            s"""
              |
              |
              |
              |select a.* from
              |(select * from dm_gis.dm_thai_shenbu_misssort_mid_di where inc_day='$end_day' and not_fit_both='yes' ) a
              |left join
              |(select addresspin from dm_gis.dm_thai_shenbu_misssort_di where inc_day='$start_day' ) b on a.addresspin=b.addresspin
              |where b.addresspin is null
              |
              |
              |
              |""".stripMargin

        //and  out_param_addressee_dept_code in('BSU','JKB','TON','PRH')

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)


        val resultRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]

            // 通过UAC鉴权接口获取token
            token_all = getToken()
            for (obj <- x) {
                val out_param_addressee_dept_code = obj.getString("out_param_addressee_dept_code")
                val waybill_no = obj.getString("waybill_no")
                val city_code = obj.getString("city_code")
                val consignee_post_code = obj.getString("consignee_post_code")
                val addresspin = obj.getString("addresspin")
                val parmObj = new JSONObject()
                parmObj.put("cityCode", city_code)
                parmObj.put("zipCode", consignee_post_code)
                parmObj.put("address", addresspin)
                parmObj.put("dc", out_param_addressee_dept_code)
                parmObj.put("taskType", "1")
                parmObj.put("region", "TH")
                parmObj.put("wbNo", waybill_no)
                val (code, message) = getInterfaceData(parmObj,token_all)
                obj.put("code", code)
                obj.put("message", message)
                listbuffer += obj



            }

            listbuffer.iterator

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("自动下发的数据量----》"+resultRdd.count())
        logger.error("token---->"+token_all)
        resultRdd

    }

    def getInterfaceData(param:JSONObject,token_all:String)={




        val headers = new util.HashMap[String,String]()
        val value = "Bearer " + token_all
        headers.put("Accept-language","zh-CN")
        headers.put("Auth-client-id","GIS-IRD-CORE-CMS")
        headers.put("Auth-tenant-code","TH")
        headers.put("Auth-tenant-id","40")
        headers.put("Authorization",value)
        var code=""
        var message=""
        Thread.sleep(500)
        val jSONObject = try {
            JSON.parseObject(HttpInvokeUtil.sendPostMultiHeader(addWaybillTaskUrl, param.toString, headers, 3))
        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+param.toString())
                new JSONObject()
            }
        }

        if(jSONObject!=null){
            code=JSONUtil.getJsonVal(jSONObject,"code","")
            message=JSONUtil.getJsonVal(jSONObject,"message","")

        }
        (code,message)
    }

    def getToken(): String = {
        var access_token = ""

        val username = "01407499"
        val password = "Lzj01407499@"
        val header = "Authorization"
        val value = "Basic R0lTLUlSRC1DT1JFLUNNUy1DTElFTlQ6QU9TQEJEUCEyMDIy"
        val url = "http://gis-ird-gateway.int.os-sgp.local/uac/oauth/token?grant_type=password&username=%s&password=%s".format(username, password)

        breakable(
            for (i <- 0.until(5)) {
                try {
                    val jsonObject = HttpInvokeUtil.sendPostHeader(url, "", header, value, "UTF-8", "UTF-8")
                    logger.error(">>>访问getToken：url" + i + "=" + url + ", result=" + jsonObject)
                    Thread.sleep(2000)
                    if (jsonObject != null) {

                        access_token = JSONUtil.parseJSONObject(jsonObject).getString("access_token")
                        if (StringUtils.nonEmpty(access_token)) break
                        else Thread.sleep(2000)
                    }
                    if (i >= 4) break
                } catch {
                    case e: Exception => logger.error(">>>访问getToken：url" + i + "=" + url)
                }
            }
        )
        access_token
    }

}
