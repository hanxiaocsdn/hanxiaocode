package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.ThaiAOIAndDcAccuracyReport.{getAoiFromInterface, logger}
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2024-01-08 14:54
 * @TaskId:874077
 * @TaskName:嘉里物流-aoi和dc准确率报表-使用轨迹校正aoi数据
 * @Description:
 */

object ThaiAOIAndDcAccuracyTraceReport {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","addresspin","is_same_out_his80_aoi","output_80_aoi_area_id","is_same_xj_80_aoi_area","is_track_80_aoi")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取aoi区域数据")
        val aoiAreaInfoMapBroad = getAoiAreaInfo(sparkSession, end_day)
        logger.error("关联轨迹数据")
        val traceRdd = getTraceData(sparkSession, end_day, aoiAreaInfoMapBroad)
        logger.error("更新aoi和dc准确率报表")
        val resultRdd = joinOldData(sparkSession, end_day, traceRdd)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk",Array(("inc_day", end_day)), 25)


    }

    def getAoiAreaInfo(spark: SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |
               |select guid,aoi_area_id from
               |    dm_tc_waybillinfo.dm_sds_aoi_area_aoi_info_dtl_df b
               |    where inc_day ='$end_day'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val aoiAreaInfoMap = dataRdd.map(obj => {

            val guid = obj.getString("guid")
            val aoi_area_id = obj.getString("aoi_area_id")
            (guid, aoi_area_id)
        }).collectAsMap()
        spark.sparkContext.broadcast(aoiAreaInfoMap)


    }



    def getTraceData(spark: SparkSession,end_day:String,aoiAreaInfoMapBroad:Broadcast[collection.Map[String, String]])={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.thai_delivery_scheduling_chk_trace where inc_day='$end_day'
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val traceRdd = dataRdd.groupBy(x => x.getString("waybill_no")).map(x => (x._1, x._2.toList.sortBy(_.getString("diff")))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoiAreaInfoMap = aoiAreaInfoMapBroad.value
            val head = x._2.head
            var is_same_xj_80_aoi_area=head.getString("is_same_xj_80_aoi_area")
            head.put("is_track_80_aoi", "false")

            breakable {
                for (obj <- x._2) {
                    val zx = obj.getString("zx")
                    val zy = obj.getString("zy")
                    val out_param_addressee_aoi_area = obj.getString("out_param_addressee_aoi_area")
                    if (StringUtils.nonEmpty(zx) && StringUtils.nonEmpty(zy)) {
                        val (aoi_id, aoi_code, zno_code) = getAoiFromInterface(zx, zy)
                        if (aoiAreaInfoMap.contains(aoi_id)) {
                            val aoi_area_id = aoiAreaInfoMap.get(aoi_id).get
                            if (StringUtils.nonEmpty(out_param_addressee_aoi_area) && out_param_addressee_aoi_area.equals(aoi_area_id)) {
                                is_same_xj_80_aoi_area="true"
                                head.put("aoiid", aoi_id)
                                head.put("aoicode", aoi_code)
                                head.put("dc", zno_code)
                                head.put("is_track_80_aoi", "true")
                                head.put("output_80_aoi_area_id", out_param_addressee_aoi_area)
                                head.put("is_same_xj_80_aoi_area", is_same_xj_80_aoi_area)
                                break
                            }
                        }
                    }
                }
            }
            listBuffer += head
            listBuffer
        }).map(x=>(x.getString("waybill_no"),x)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("跑完点落面，数据量----》 "+traceRdd.count())
        traceRdd


    }

    def joinOldData(spark: SparkSession,end_day:String,traceDataRdd:RDD[(String,JSONObject)])={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.thai_delivery_scheduling_chk where inc_day='$end_day'
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(x => (x.getString("waybill_no"), x)).leftOuterJoin(traceDataRdd).map(x => {
            var dataObj = new JSONObject()
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (rightOp.nonEmpty) {
                dataObj.fluentPutAll(rightOp.get)

            } else {
                dataObj.fluentPutAll(leftObj)
            }
            dataObj

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联完，数据量----》 "+resultRdd.count())
        resultRdd

    }

    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        Thread.sleep(300)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }

}
