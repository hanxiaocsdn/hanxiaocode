package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.app.ThaiAutomationBuildingAddressDatabase.{checkDictLevel, dict_10, dict_13, dict_14, dict_6, dict_9, geoUrl, getSplitResult, logger}
import com.sf.gis.app.WaybillAndAoiToShenbuRuKu.{addrChangeUrl, className, logger, saveKey}
import com.sf.gis.app.WaybillXYLocationAoi.{getHour, logger}
import com.sf.gis.java.utils.{HttpUtils, MD5Util, XmlParseUtil}
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2023-09-05 14:48
 * @TaskId:807371
 * @TaskName:
 * @Description:嘉里丰化-嘉里审补库数据清洗
 */

object WaybillAndAoiToShenbuClean {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val geoUrl="http://10.234.0.255:7014/?query_type=GEOCODE&address=%s&zipcode=%s&filter_uprecision=2&ret_splitinfo=1&output=json"
    val splitUrl="http://10.234.1.208:8902/split?zipcode=%s&address=%s"
    val deleteUrl="http://orion-cms.int.kex.local:1080/globalexpress/openapi/address/delete"
    val saveSplitinfoKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","aoi_percentage","aoi_total","splitresult","score","status","msg","addrunkonwflag")

    val saveCleanKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","aoi_percentage","aoi_total","splitresult","score","status","msg","addrunkonwflag","srcuid","code","message")


    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var mode=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        if(mode.equals("judge")){
            logger.error("获取地址不详数据")
            val resultRdd = getAddrUnKnowData(sparkSession, end_day)
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveSplitinfoKey, "dm_gis.thai_aoi_shenbu_addr_unknow",Array(("inc_day", end_day)), 25)

        }else if(mode.equals("delete")){
            val resultRdd = deleteAddr(sparkSession, end_day)
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveCleanKey, "dm_gis.thai_aoi_shenbu_v3_qingxi_address_unknown",Array(("inc_day", end_day)), 25)


        }


    }

    def deleteAddr(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.thai_aoi_shenbu_v3_qingxi_address_unknown where inc_day='20230825' and addrunkonwflag='true' and (code='' or  code is null)
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("addrunkonwflag")) && x.getString("addrunkonwflag").toBoolean).map(obj => {
            val srcuid = getMd5Key(obj.getString("address"))
            val parmObj = new JSONObject()
            parmObj.put("srcuid", srcuid)
            val (code, message) = delete(parmObj)
            obj.put("srcuid", srcuid)
            obj.put("code", code)
            obj.put("message", message)


            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def getAddrUnKnowData(spark: SparkSession,end_day:String)= {
        var sql =
            s"""
               |
               |select * from dm_gis.thai_aoi_shenbu_addr_unknow where inc_day='20230820'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            try {
                val address = obj.getString("address")
                val recipient_postcode_id = obj.getString("recipient_postcode_id")
                val splitObj = XmlParseUtil.xmlParseSplit(getSplitResult(address, recipient_postcode_id))
                obj.fluentPutAll(splitObj)
                val splitresult = obj.getString("splitresult")
                val addrUnkonwFlag = checkSplitLevelNew(splitresult)

                obj.put("addrunkonwflag", addrUnkonwFlag)

            } catch {
                case e: Exception => logger.error(e.getStackTrace)
            }

            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        //.filter(x=>StringUtils.nonEmpty(x.getString("addrunkonwflag"))&&x.getString("addrunkonwflag").toBoolean)
        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def checkSplitLevelNew(addrSplitInfo:String) ={
        var level2=true
        var level3=true
        var level6=true
        var level9=true
        var level10=true
        var level13=true
        var level14=true
        var addrUnkonwFlag=false

        for(i<-0 until addrSplitInfo.split(";")(0).split(",").length){

            try{
                val level = addrSplitInfo.split(";")(0).split(",")(i).split("\\^")(1)
                if(level.equals("114")){
                    level14=false
                }else if(level.equals("113")){
                    level13=false
                }else if(level.equals("110")){
                    level10=false
                }else if(level.equals("19")){
                    level9=false
                }else if(level.equals("16")){
                    level6=false
                }else if(level.equals("13")){
                    level3=false
                }else if(level.equals("12")){
                    level2=false
                }
            }catch {case e:Exception=>logger.error(e.printStackTrace())}

        }


        if(level2&&level3){
            addrUnkonwFlag=true
        }
        if(level6&&level9&&level10&&level13){
            addrUnkonwFlag=true
        }
        if(level13&&level14){
            addrUnkonwFlag=true
        }

        addrUnkonwFlag

    }

    def checkSplitLevel(addrSplitInfo:JSONArray) ={
        var level2=true
        var level3=true
        var level6=true
        var level9=true
        var level10=true
        var level13=true
        var level14=true
        var addrUnkonwFlag=false
        for(i<-0 until addrSplitInfo.size()){
            val levelInfo = addrSplitInfo.getJSONObject(i)
            val level = levelInfo.getString("level")
            if(level.equals("14")){
                level14=false
            }else if(level.equals("13")){
                level13=false
            }else if(level.equals("10")){
                level10=false
            }else if(level.equals("9")){
                level9=false
            }else if(level.equals("6")){
                level6=false
            }else if(level.equals("3")){
                level3=false
            }else if(level.equals("2")){
                level2=false
            }
        }


        if(level2&&level3){
            addrUnkonwFlag=true
        }
        if(level6&&level9&&level10&&level13){
            addrUnkonwFlag=true
        }
        if(level13&&level14){
            addrUnkonwFlag=true
        }

        addrUnkonwFlag

    }

    def getSplitResult(addr:String,zipcode:String)={
        val url=String.format(splitUrl,zipcode, URLEncoder.encode(addr, "UTF-8"))

        Thread.sleep(150)
        val responseStr = try {
            HttpUtils.urlConnectionGetStr(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
               ""
            }
        }
        responseStr

    }

    def getGeoResult(addr:String,zipcode:String)={
        val url=String.format(geoUrl, URLEncoder.encode(addr, "UTF-8"),zipcode)

        Thread.sleep(260)
        val jSONObject = try {
            JSON.parseObject(HttpUtils.urlConnectionGetStr(url, 5000).replaceAll("\\+",""))
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                new JSONObject()
            }
        }

        val splitResult=JSONUtil.getJsonVal(jSONObject,"splitResult","")
        val addrSplitInfo = JSONUtil.getJsonArrayFromObject(jSONObject, "addrSplitInfo")
        (splitResult,addrSplitInfo)

    }

    def delete(dataObj:JSONObject)={
//        var nowHour = getHour()
//        if((nowHour>=21||(nowHour>=0&&nowHour<8))){
//            Thread.sleep(800)
//        }else{
//            Thread.sleep(800)
//        }
        Thread.sleep(800)
        val jSONObject = try {
            HttpUtils.urlConnectionPostJson(deleteUrl,dataObj.toString(),5000)
        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+dataObj.toString())
                null
            }
        }
        val code = JSONUtil.getJsonVal(jSONObject, "code", "")
        val message = JSONUtil.getJsonVal(jSONObject, "message", "")



        (code,message)
    }

    def getMd5Key(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr.toUpperCase
        }
        resultMd5Str

    }

}
