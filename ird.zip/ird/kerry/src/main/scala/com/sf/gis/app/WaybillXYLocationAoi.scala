package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.TripleSourceBuildDataBaseRuKu.{limitAkUsetest, logger}
import com.sf.gis.java.utils.{GeometryUtil, HttpUtils}
import com.sf.gis.pojo.{Cnt, StratTime}
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.util
import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-05-06 10:42
 * @TaskId:739417
 * @TaskName:
 * @Description:注意嘉里集群scala版本为：2.12.15
 */

object WaybillXYLocationAoi {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("id","consignment_no","act_delivery_date","recipient_address","recipient_soi","recipient_road","recipient_address2","recipient_postcode_id","destination_dc_id","destination_dc_code","destination_dc_en_name","destination_dc_th_name","status_id","geo_location","aoiid","aoicode","dc","interfacedata")
    val saveDynamicKey=Array("id","consignment_no","act_delivery_date","recipient_address","recipient_soi","recipient_road","recipient_address2","recipient_postcode_id","destination_dc_id","destination_dc_code","destination_dc_en_name","destination_dc_th_name","status_id","geo_location","aoiid","aoicode","inc_day")


    //    val searchByPointUrl="https://gis-ird-cms.th.kerryexpress.com/globalexpress/openapi/aoi/searchByPoint?x=%s&y=%s"

//    val searchByPointUrl="http://orion-cms.int.kex.local:1080/globalexpress/openapi/aoi/searchByPoint?x=%s&y=%s"
    val searchByPointUrl="http://gis-ird-cms.int.os-sgp.local/globalexpress/openapi/aoi/searchByPoint?x=%s&y=%s"

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        var start_day=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始读取aoi多边形数据")
//        val broadcastAoiList = getAoiWktNew(sparkSession)
        logger.error("开始计算点落aoi多边形")


        val dataRdd = getWaybillAoiData(sparkSession,end_day,end_date,start_day)
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveKey, "dm_gis.thai_waybill_location_aoi",Array(("inc_day", end_day)), 25)

//        val dataRdd = getWaybillData(sparkSession, broadcastAoiList,end_day,end_date,start_day)
//        SparkWrite.save2HiveStaticNew(sparkSession,dataRdd,saveDynamicKey,"dm_gis.thai_waybill_location_aoi_bak",Array(("incday", end_day)),2000)

    }

    def getWaybillData(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String,end_date:String,start_day:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
              |
              |select * from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end_date' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string), geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |
              |""".stripMargin

        sql=
            """
              |select a.*,b.status_id,b.geo_location from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20230124' and '20230326' and act_delivery_date between '2023-01-26 00:00:00' and '2023-03-26 23:59:59'  and recipient_postcode_id in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10170','10140','10600','10700','10600','10240','10150','10120','10800','10260','10150','10700','10500','10220','10160','10240','10330','10250','10100','10400','10200','10260','10160','10510','10120','10400','10140','10520','10230','10310','10110','10250','10240','10100','10120','10220','10530','10160','10210','10310')
              |
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string) as status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20230126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |select a.*,b.status_id,b.geo_location from
              |(
              |select id, consignment_no, cast(act_delivery_date as string) as act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day<='$end_day' and inc_day>='$start_day' and act_delivery_date between '$start_date' and '$end' and recipient_postcode_id in ('10100','10110','10120','10130','10140','10150','10160','10170','10200','10210','10220','10230','10240','10250','10260','10270','10280','10290','10300','10310','10320','10330','10400','10500','10510','10520','10530','10540','10550','10560','10570','10600','10700','10800','10900','11000','11110','11120','11130','11140','11150','12000','12110','12120','12130','12140','12150','12160','12170','74000','74110','74120','74130')
              |
              |
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string) as status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |
              |
              |""".stripMargin



        sql=
            s"""
               |
               |
               |select a.*,b.status_id,b.geo_location,b.inc_day from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day<='$end_day' and inc_day>='$start_day' and act_delivery_date between '$start_date' and '$end'
               |
               |) a
               |inner join
               |(
               |select consignment_no, cast(status_id as string) as status_id, geo_location,inc_day from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day<='$end_day' and inc_day>'$start_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |
               |
               |
               |""".stripMargin


        sql=
            s"""
               |
               |
               |select a.*,b.status_id,b.geo_location,b.inc_day from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59'
               |
               |) a
               |inner join
               |(
               |select consignment_no, cast(status_id as string) as status_id, geo_location,inc_day from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day between '20221124' and '20230326' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |
               |
               |
               |""".stripMargin

        sql=
            s"""
               |
               |
               |select a.*,b.status_id,b.geo_location,b.inc_day from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day between '20230601' and '20230726' and act_delivery_date between '2023-06-01 00:00:00' and '2023-07-26 23:59:59'
               |
               |) a
               |inner join
               |(
               |select consignment_no, cast(status_id as string) as status_id, geo_location,inc_day from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day between '20230601' and '20230726' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |
               |
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.repartition(4000).map(obj => {
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(1)
            val y = geoStrings(0)
            val aoiListMap = aoiListBroadcast.value
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            var wktend=""
            var zno_code=""
            var name_chn=""
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                breakable {
                    val key = GeometryUtil.sliceUpCoordinate(x.toDouble, y.toDouble)
                    if(aoiListMap.contains(key)){
                        val aoiList = aoiListMap.get(key).get
                        for (aoiObj <- aoiList) {
                            val wkt = aoiObj.getString("wkt")
                            val d = getGeoData(wkt, x.toDouble, y.toDouble)
                            if(d==0.0){
                                distance = d
                                aoiid = aoiObj.getString("gui_id")
                                aoicode = aoiObj.getString("aoi_code")
                                wktend=aoiObj.getString("wkt")
                                zno_code=aoiObj.getString("zno_code")
                                name_chn=aoiObj.getString("name_chn")
                                break
                            }
                        }

                    }


                }

            }
            dataObj.put("aoiid", aoiid)
            dataObj.put("aoicode", aoicode)
            dataObj.put("wkt",wktend)
            dataObj.put("zno_code",zno_code)
            dataObj.put("name_chn",name_chn)
            dataObj.put("dis", distance)
            (obj._1, dataObj)

        })

        val resultRdd = dataRdd.map(x => (x.getString("geo_location"), x)).repartition(4000).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def getWaybillAoiData(spark: SparkSession,end_day:String,end_date:String,start_day:String)={
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql=
            s"""
              |
              |
              |select a.*,b.status_id,b.geo_location from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day<='$end_day' and inc_day>='$start_day' and act_delivery_date between '$start_date' and '$end' and recipient_postcode_id in ('10100','10110','10120','10130','10140','10150','10160','10170','10200','10210','10220','10230','10240','10250','10260','10270','10280','10290','10300','10310','10320','10330','10400','10500','10510','10520','10530','10540','10550','10560','10570','10600','10700','10800','10900','11000','11110','11120','11130','11140','11150','12000','12110','12120','12130','12140','12150','12160','12170','74000','74110','74120','74130')
              |
              |
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string) as status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |
              |select a.*,b.status_id,b.geo_location from
              |(
              |select id, consignment_no, cast(act_delivery_date as string) as act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day<='$end_day' and inc_day>='$start_day' and act_delivery_date between '$start_date' and '$end'
              |
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string) as status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day='$end_day' and status_id='21'
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |
              |
              |
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.mapPartitions(x => {
            val list = new ListBuffer[JSONObject]()
            val startTime = new StratTime(System.currentTimeMillis())
            val cn1 = new Cnt(0)
            for (obj <- x) {
                try{
                    val geo_location = obj.getString("geo_location")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
//                        val allcnt=limitAkUsetest(startTime,cn1,logger)
                        val (aoi_id,aoi_code,zno_code,response) = getAoiFromInterface(x, y)
//                        var nowHour = getHour()
                        obj.put("aoiid", aoi_id)
//                        obj.put("recipient_soi",allcnt.toString)
//                        obj.put("id",nowHour.toString)
                        obj.put("aoicode", aoi_code)
                        obj.put("dc", zno_code)
                        obj.put("interfacedata", response)

                    }

                }catch {case e:Exception=>logger.error(e.getMessage)}

                list += obj
            }
            list.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("落aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def limitAkUsetest(stratTime: StratTime, cnt: Cnt, logger: Logger) = {
        cnt.cnt += 1
        var allcnt=0L
        val endTime = System.currentTimeMillis() - stratTime.stratTime
        if (endTime >= 60 * 1000) {
            logger.error("1 min access interface ------>"+cnt.cnt)
            allcnt=cnt.cnt
            stratTime.stratTime = System.currentTimeMillis()
            cnt.cnt = 0
        }
        allcnt
    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)
        //每分钟 11000次，响应速度 6ms/次

        var nowHour = getHour()
        var response=""
//        while (!(nowHour>=22||(nowHour>=0&&nowHour<7))){
//            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
//            Thread.sleep(1000*60)
//            nowHour = getHour()
//
//        }
//
        Thread.sleep(1)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                response=e.toString
                null
            }
        }
        if(jSONObject!=null){
            response=jSONObject.toString
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code,response)



    }

    def getAoiWktNew(spark:SparkSession)={
        var sql="select * from dm_gis.thai_aoi_wkt_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val wktMap = new mutable.HashMap[String, mutable.ListBuffer[JSONObject]]()
        val list = dataRdd.collect().toList
        for(obj<-list){
            val wkt = obj.getString("wkt")
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(wkt)

                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    if(wktMap.contains(key)){
                        val value: ListBuffer[JSONObject] = wktMap.get(key).get
                        value+=obj
                        wktMap.put(key,value)

                    }else{
                        val temList = new ListBuffer[JSONObject]()
                        temList+=obj
                        wktMap.put(key,temList)

                    }
                }

            }catch {
                case e:Exception=>logger.error("error reason---->"+e.getMessage)
            }


        }
        spark.sparkContext.broadcast(wktMap)


    }


    def getWaybillDataNew(spark: SparkSession,aoiListBroadcast:Broadcast[List[JSONObject]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, cast(status_id as string), geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        sql=
            """
              |select a.*,b.status_id,b.geo_location,c.aoiid,c.aoicode from
              |(
              |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20230124' and '20230326' and act_delivery_date between '2023-01-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10170','10140','10600','10700','10600','10240','10150','10120','10800','10260','10150','10700','10500','10220','10160','10240','10330','10250','10100','10400','10200','10260','10160','10510','10120','10400','10140','10520','10230','10310','10110','10250','10240','10100','10120','10220','10530','10160','10210','10310')
              |
              |
              |) a
              |inner join
              |(
              |select consignment_no, cast(status_id as string) as status_id, geo_location from
              |(
              |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20230126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |left join dm_gis.thai_geo_xy_location_aoi_v2 c on b.geo_location=c.geo_location
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        dataRdd

    }



    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case e:Exception=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }


    def getAoiWkt(spark:SparkSession)={
        val columns=Array("gui_id","zno_code","name_chn","aoi_code","wkt")
        val aoiPath = "file://"+System.getProperty("user.dir") + "/gex_aoi_050602.csv"
        logger.error("aoi 多边形数据path---》"+aoiPath)
        //hdfs://kex/user/01407499/upload/gex_aoi_050602.csv
        val srcDF = spark.read
            .option("inferschema", "false")
            //.option("multiLine", true)
            .option("header", "false")
            .option("encoding", "UTF-8")
            .csv("hdfs://kex/user/01407499/upload/gex_aoi_050602.csv")
            .toDF("gui_id","zno_code","name_chn","aoi_code","wkt")
        val dataRdd = srcDF.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getAs[String](columns(i)))
            }
            jObj
        })
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }

    def getBuildWkt(spark:SparkSession)={
        var sql=
            s"""
               |select wkt,guid as bld_id,name_chn bld_name,x_coord as bld_lon,y_coord as bld_lat,addr_chn as bld_addr from dm_gis.building_all_info where x_coord is not null and x_coord<>'' and x_coord<>'null' and y_coord is not null and y_coord<>'' and y_coord<>'null' and wkt is not null and wkt<>'' and wkt<>'null'  order by bld_lon,bld_lat
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        dataRdd.take(30).foreach(println)
        val dataList = dataRdd.collect().toList

        //113.60260156256727,22.33121691648796
        val dataMap = new mutable.HashMap[String, ListBuffer[JSONObject]]()
        for(obj<-dataList){
            val bld_lon = obj.getString("bld_lon")
            val bld_lat = obj.getString("bld_lat")
            if(StringUtils.nonEmpty(bld_lon)&&StringUtils.nonEmpty(bld_lat)&&bld_lon.length>7&&bld_lat.length>6){
                val lon_index=bld_lon.substring(0,7).toDouble+0.001
                val lat_index=bld_lat.substring(0,6).toDouble+0.001
                val key=lon_index+"_"+lat_index
                if(dataMap.contains(key)){
                    dataMap.put(key,dataMap.get(key).get+=obj)
                }else{
                    val listBuffer: ListBuffer[JSONObject] = ListBuffer()
                    listBuffer+=obj
                    dataMap.put(key,listBuffer)
                }
            }
        }
        spark.sparkContext.broadcast(dataMap)

    }

    def binarySearch(buildList:ListBuffer[JSONObject],lng:String,keyName:String,starIndex:Int,endIndex:Int)={
        var l=starIndex
        var r=endIndex
        val lngadd = lng.toDouble+0.01
        val lngsub=lng.toDouble-0.01
        //                val lngadd = lng.toDouble+2
        //                val lngsub=lng.toDouble-1
        //        var mid=0
        breakable{
            while(l<r){
                var mid:Int=(l+r)/2
                val bld_lon = buildList(mid).getString(keyName).toDouble
                if(bld_lon>lngadd){
                    r = mid - 1
                }else if(bld_lon<lngsub){
                    l=mid+1
                }else {
                    break
                }
            }
        }
        //寻找l
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l-1)/2
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_1 = math.abs(lng.toDouble - bld_lon_1)
                //                logger.error("bld_lon----->"+bld_lon+"---lngadd---->"+lngadd+" lngsub---->"+lngsub)

                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_1<=0.0007){
                        l=mid
                        //                        logger.error("search l---->"+l)
                        break
                    }else{
                        r_tem_l = mid + 1

                    }

                }

            }
        }
        //寻找r
        breakable{
            var l_tem_l=l
            var r_tem_l=r
            while(l_tem_l<r_tem_l){
                var mid:Int=(l_tem_l+r_tem_l)/2+1
                if(mid<=0||mid>=buildList.length-1){
                    break
                }
                val bld_lon = buildList(mid).getString(keyName).toDouble
                val bld_lon_1 = buildList(mid-1).getString(keyName).toDouble
                val bld_lon_2 = buildList(mid+1).getString(keyName).toDouble
                val bld_sub = math.abs(lng.toDouble - bld_lon)
                val bld_sub_2 = math.abs(lng.toDouble - bld_lon_2)
                if(bld_sub>=0.0007){
                    r_tem_l = mid - 1
                }else if(bld_sub<0.0007){
                    l_tem_l=mid+1
                }else{
                    if(bld_sub_2>0.0007){
                        r=mid
                        break
                    }else{
                        l_tem_l=mid-1

                    }

                }

            }
        }
        (l,r)


    }

    def getDistance(lng:String,lat:String,buildList:ListBuffer[JSONObject])={
        var bld_dis = (-1.0)
        var index=0
        val (start,end) = binarySearch(buildList, lng,"bld_lon",0,buildList.size-1)
        logger.error("start lng index---->"+start+"end lng index----->"+end)
        val (l,r)=binarySearch(buildList, lat,"bld_lat",start,end)
        logger.error("start index---->"+l+"----->end index------>"+r)
        breakable{
            for(i<- l until r){
                val buildobj=buildList(i)
                val wkt = buildobj.getString("wkt")
                val dist = getGeoData(wkt, lng.toDouble, lat.toDouble)
                if (dist >= 0.0&&dist<=50.0) {
                    if (bld_dis >= 0.0) {
                        if (dist < bld_dis) {
                            bld_dis = dist
                            index=i
                        }
                    } else {
                        bld_dis = dist
                        index=i
                    }
                }
                if (bld_dis == 0.0) {
                    break
                }
            }

        }

        (bld_dis,index)


    }


}
