package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.WaybillXYLocationAoi.getHour
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.pojo.{Cnt, StratTime}
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2024-02-22 17:00
 * @TaskId:874388
 * @TaskName:三源建库数据入库
 * @Description:
 */

object TripleSourceBuildDataBaseRuKu {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val addrChangeUrl="http://gis-ird-cms.int.os-sgp.local/globalexpress/openapi/address/change"
    val saveKey=Array("district","city_code","input_param_receiver_postal_code","dest_zone_code","src","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","is_same_xj_dest_dc","is_same_dj_dest_dc","is_same_xj_80_dc","is_same_dj_80_dc","batch_aoi","aoiid","aoicode","dc","waybill_no","source_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","geo_location","input_param_addressee_mobile","input_param_receiver_mobile2","hq_code","addresspin","is_same_out_his80_aoi","output_80_aoi_area_id","is_same_xj_80_aoi_area","is_track_80_aoi","postal_cnt","aoi_cnt","label","aoi_new","dc_new","code","message")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var limitnum=args(1)
        var start_index=args(2)
        var end_index=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")

        for(i<-start_index.toInt until(end_index.toInt)){
            try{
                getData(sparkSession,end_day,limitnum,i.toString)
            }catch {case e:Exception=>logger.error(e.toString)}
        }


    }

    def getData(spark: SparkSession,end_day:String,limitnum:String,index:String)={
        var sql=
            s"""
              |
              |
              |select
              |district
              |,input_param_receiver_postal_code
              |,dest_zone_code
              |,is_same_xj_batch_aoi
              |,is_same_xj_80_aoi
              |,aoiid
              |,aoicode
              |,waybill_no
              |,input_param_send_time
              |,out_param_addressee_aoi_id
              |,out_param_addressee_aoi_code
              |,geo_location
              |,addresspin
              |,postal_cnt
              |,aoi_cnt
              |,label
              |,aoi_new
              |,dc_new
              |from dm_gis.thai_delivery_scheduling_chk_is_same_xj_80_batch_aoi_ruku_mid where inc_day='$index' limit $limitnum
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJsonNew(spark, sql)
        val resultRdd = dataRdd.repartition(16).mapPartitions(x => {

            val listbuffer = new ListBuffer[JSONObject]
            val startTime = new StratTime(System.currentTimeMillis())
            val cn1 = new Cnt(0)
            for(obj<-x){
                try{
                    val tmpObj = new JSONObject()
                    val address = obj.getString("addresspin")
                    val recipient_postcode_id = obj.getString("input_param_receiver_postal_code")
                    val aoiid = obj.getString("aoi_new")
                    val dc = obj.getString("dc_new")
                    val geoStrings = obj.getString("geo_location").split(",")
                    obj.put("recipient_postcode_id",recipient_postcode_id)
                    var x=""
                    var y=""

                    if(geoStrings.size>1){
                        x=geoStrings(1)
                        y = geoStrings(0)
                    }

                    tmpObj.put("sourceType", "3")
                    tmpObj.put("adType", "2")
                    tmpObj.put("address", address)
                    tmpObj.put("aoi", aoiid)
                    tmpObj.put("dc", dc)
                    tmpObj.put("x", x)
                    tmpObj.put("y", y)
                    tmpObj.put("zipCode", recipient_postcode_id)
                    tmpObj.put("cityCode", recipient_postcode_id.substring(0,2))
                    tmpObj.put("region","TH")
                    val allcnt=limitAkUsetest(startTime,cn1,logger)
                    val (code, message) = postInterface(tmpObj)
                    obj.put("code", code)
                    obj.put("message", message)
//                    obj.put("dest_zone_code",allcnt)

                }catch {case e:Exception=>logger.error(e.getStackTrace)}
                listbuffer+=obj

            }

            listbuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("入库数据量---》"+resultRdd.count())
        saveDataToHive(spark,resultRdd,end_day,index)



    }

    def saveDataToHive(sparkSession:SparkSession,standardRdd:RDD[JSONObject],end_date:String,group_num:String)={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKey.indices) {
            schemaEle.append(StructField(saveKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = standardRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveKey.indices) {
                var tmpStr = JSONUtil.getJsonValSingle(obj, saveKey.apply(i))
                row.append(tmpStr)
            }
            val ret = Row.fromSeq(row)
            ret
        })

        sparkSession.createDataFrame(rowRdd, schema).createOrReplaceTempView("tmp_result")

        var sql_w=
            s"""
               |
               |insert overwrite table dm_gis.thai_delivery_scheduling_chk_is_same_xj_80_batch_aoi_ruku partition(inc_day='$end_date',index='$group_num')
               |select
               |district
               |,city_code
               |,input_param_receiver_postal_code
               |,dest_zone_code
               |,src
               |,is_recognize_aoi
               |,is_exist_batch_aoi
               |,is_same_xj_batch_aoi
               |,is_same_xj_80_aoi
               |,is_same_xj_dest_dc
               |,is_same_dj_dest_dc
               |,is_same_xj_80_dc
               |,is_same_dj_80_dc
               |,batch_aoi
               |,aoiid
               |,aoicode
               |,dc
               |,waybill_no
               |,source_zone_code
               |,addressee_dept_code
               |,addresseeaoicode
               |,dest_lgt
               |,dest_lat
               |,consignee_emp_code
               |,consigned_tm
               |,deliver_emp_code
               |,signin_tm
               |,consignor_post_code
               |,consignee_post_code
               |,input_param_waybill_no
               |,input_param_receiver_addr
               |,input_param_receiver_addr2
               |,input_param_send_time
               |,out_param_addressee_aoi_area
               |,out_param_addressee_aoi_code
               |,out_param_addressee_aoi_id
               |,out_param_addressee_dept_code
               |,out_param_addressee_transit_code
               |,largedccode
               |,geo_location
               |,input_param_addressee_mobile
               |,input_param_receiver_mobile2
               |,hq_code
               |,addresspin
               |,is_same_out_his80_aoi
               |,output_80_aoi_area_id
               |,is_same_xj_80_aoi_area
               |,is_track_80_aoi
               |,postal_cnt
               |,aoi_cnt
               |,label
               |,aoi_new
               |,dc_new
               |,code
               |,message
               |from
               |tmp_result
               |
               |
               |
               |
               |""".stripMargin

        logger.error("存储outbuilding数据sql---》"+sql_w)
        sparkSession.sql(sql_w)
        logger.error("存储outbuilding数据完毕")

    }

    def limitAkUsetest(stratTime: StratTime, cnt: Cnt, logger: Logger) = {
        cnt.cnt += 1
        var allcnt=0L
        val endTime = System.currentTimeMillis() - stratTime.stratTime
        if (endTime >= 60 * 1000) {
            logger.error("1 min access interface ------>"+cnt.cnt)
            allcnt=cnt.cnt
            stratTime.stratTime = System.currentTimeMillis()
            cnt.cnt = 0
        }
        allcnt
    }

    def postInterface(dataObj:JSONObject)={


        //接口响应速度 每分钟2000次，30ms
        var nowHour = getHour()
        if((nowHour>=21||(nowHour>=0&&nowHour<8))){
            Thread.sleep(10)
        }else{
            Thread.sleep(100)

        }
        var message=""
        var code=""
        var jSONObject=new JSONObject()
        jSONObject = try {
            HttpUtils.urlConnectionPostJson(addrChangeUrl,dataObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+dataObj.toString())
                message=e.toString
                null
            }
        }


//        breakable {
//            for(i<- 0 until 5){
//                jSONObject = try {
//                    HttpUtils.urlConnectionPostJson(addrChangeUrl,dataObj.toString(),5000)
//                }
//                catch {
//                    case e:Exception=>{
//                        logger.error("error parameter-----> "+dataObj.toString())
//                        message=e.toString
//                        null
//                    }
//                }
//                code=JSONUtil.getJsonVal(jSONObject,"code","")
//                if(StringUtils.nonEmpty(code)&&code.equals("200")){
//                    break
//                }else{
//                    Thread.sleep(5000)
//                }
//            }
//
//        }

        if(jSONObject!=null){
            code = JSONUtil.getJsonVal(jSONObject, "code", "")
            message = JSONUtil.getJsonVal(jSONObject, "message", "")

        }


        (code,message)

    }


}
