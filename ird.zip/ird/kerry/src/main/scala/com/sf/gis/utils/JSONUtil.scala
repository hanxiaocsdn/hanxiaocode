package com.sf.gis.utils

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.log4j.Logger

/**
  * Created by 01374443 on 2018/2/6.
  */
object JSONUtil extends Serializable {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  def getJSONObjectString(jObj: JSONObject, key:String,defaultValue:String): String ={
    try {
      if (jObj.getJSONObject(key) != null) {
        jObj.getJSONObject(key).toJSONString
      } else {
        defaultValue
      }
    }catch {
      case e:Exception => defaultValue
    }
  }
  def parseStr2Json(str : String) : JSONObject = {
    var obj : JSONObject = null
    try{
      obj = JSON.parseObject(str)
    }catch {
      case e : Exception =>
        logger.error(s"""parse $str to json error. """, e)
    }
    obj
  }
  /**
   * 获取json里面的json对象
   * @param obj
   * @param key
   * @param defaultValue
   * @return
   */
  def getJsonObj(obj: JSONObject, key: String, defaultValue: String): String ={
    var returnStr : String = defaultValue
    try{

      val returnObj:JSONObject = obj.getJSONObject(key)
      //      if(returnObj!=null) returnStr = JSON.toJSONString(returnObj).replaceAll("[\\r\\n\\t]", "")
      if(returnObj!=null) returnStr = returnObj.toJSONString.replaceAll("[\\r\\n\\t]", "")
    }catch{
      case e:Exception =>

      //        logger.error("获取json数据项" + key + "出错:" + obj, e)
    }
    returnStr
  }
  /**
   * 获取json里面的json数组字符串
   * @param obj
   * @param key
   * @param defaultValue
   * @return
   */
  def getJsonArray(obj: JSONObject, key: String, defaultValue: String): String ={
    var returnStr : String = defaultValue
    try{

      val returnObj:JSONArray = obj.getJSONArray(key)
      //      if(returnObj!=null) returnStr = JSON.toJSONString(returnObj).replaceAll("[\\r\\n\\t]", "")
      if(returnObj!=null) returnStr = returnObj.toJSONString.replaceAll("[\\r\\n\\t]", "")
    }catch{
      case e:Exception =>
      //        logger.error("获取json数据项" + key + "出错:" + obj, e)
    }
    returnStr
  }
  /**
   * json转为字符串，替换特殊字符
   * @param jObj：json对象
   * @return
   */
  def convertJsonToStr(jObj: JSONObject): String ={
    if(jObj == null){
      ""
    }else{
      jObj.toJSONString.replaceAll("[\\r\\n\\t]", "")
    }
  }
  def parseJSONObjectFromStr( jsonStr:String):JSONObject={
    try{
      val obj = JSON.parseObject(jsonStr)
      return obj
    }catch {
      case _: Exception =>
    }
    null
  }
  /**
   * @param obj
   * @param keys
   * @return
   */
  def getItem(obj: JSONObject, keys: String, defaultValue: Object): Object = {
    var value : Object = null
    var tempObj = obj
    try {
      var keyArr : Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        } else{
          value = tempObj.get(keyArr(i))
        }
      }
    } catch {
      case e: Exception =>
        logger.error("get json {} from {} error", keys, obj, e)
    }
    if(value == null) value = defaultValue
    value
  }
  /**
    * 获取多层json的值
    *
    * @param obj  json对象
    * @param keys 串接的key值
    * @return
    */
  def getJsonValMulti(obj: JSONObject, keys: String, defaultValue: String = ""): String = {
    var `val`: String = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case _: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }

  /**
    * 获取单层json数据
    * @param obj
    * @param keys
    * @param defaultValue
    * @return
    */
  def getJsonValSingle(obj: JSONObject, keys: String, defaultValue: String = ""): String = {
    var `val`: String = null
    try {
      `val` = obj.get(keys).toString
    } catch {
      case _: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }
  /**
    * 获取多层级jsonObject
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonObjectMulti(obj: JSONObject, keys: String, defaultValue: JSONObject = new JSONObject()): JSONObject = {
    var `val`: JSONObject = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getJSONObject(keyArr(i))
      }
    } catch {
      case _: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }


  def getJsonArrayFromObject(obj: JSONObject, keys: String, defaultValue: JSONArray = new JSONArray()): JSONArray = {
    var `val` : JSONArray = null
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getJSONArray(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }



  def getJsonValInt(obj: JSONObject, keys: String, defaultValue: Int): Int = {
    var `val` : Int = defaultValue
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getInteger(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }

  /**
    * 获取多层级jsonArray
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonArrayMulti(obj: JSONObject, keys: String, defaultValue: JSONArray = new JSONArray()): JSONArray = {
    var `val`: JSONArray = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getJSONArray(keyArr(i))
      }
    } catch {
      case _: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }

  /**
   * 获取单层json数据
   * @param obj
   * @param keys
   * @param defaultValue
   * @return
   */
  def getJsonValSingleDouble(obj: JSONObject, keys: String, defaultValue: Double): Double = {
    var `val`: Double = defaultValue
    try {
      `val` = obj.getDouble(keys)
    } catch {
      case _: Exception =>
    }
    `val`
  }

  /**
    * 获取多层级jsonArray,取结果数组的第一个元素
    *
    * @param obj
    * @param keys
    * @return
    */
  def getJsonArrayMultiOfFirstObject(obj: JSONObject, keys: String, defaultValue: JSONObject = new JSONObject()): JSONObject = {
    var `val`: JSONObject = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getJSONArray(keyArr(i)).getJSONObject(0)
      }
    } catch {
      case _: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }

  /**
   * 获取多层json的值
   *
   * @param obj  json对象
   * @param keys 串接的key值
   * @return
   */
  def getJsonValMultiInt(obj: JSONObject, keys: String, defaultValue: Int = 0): Int = {
    var `val`: Int = defaultValue
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getInteger(keyArr(i))
      }
    } catch {
      case _: Exception =>
    }
    //    if (`val` == null) `val` = defaultValue
    `val`
  }


  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val` : String = null
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }
  /**
   * 合并数组
   * @param array1
   * @param array2
   * @return
   */
  def mergeJSONArrayItem(array1:JSONArray,array2:JSONArray): JSONArray ={
    if (array1 != null && array2 != null) {
      for (i <- 0 until array2.size()) {
        array1.add(array2.get(i))
      }
      array1
    } else if (array1 == null && array2 != null) {
      array2
    }else{
      array1
    }
  }
  def getJSONObject(obj:JSONObject,keyStr:String):JSONObject={
    var ret:JSONObject = null
    try{
      ret = obj.getJSONObject(keyStr)
    }catch {
      case e:Exception=>
      //        logger.error(e)
    }
    ret
  }
  def getJsonLong(obj: JSONObject, keys: String, defaultValue: Long): Long = {
    var `val` : Long = defaultValue
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getLong(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }

  def getJsonDouble(obj: JSONObject, keys: String, defaultValue: Double): Double = {
    var `val` : Double = defaultValue
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getDouble(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }
  /**
   * 获取多层json的值
   *
   * @param obj
   * @param keys
   * @return
   */
  def getJsonValObject(obj: JSONObject, keys: String, defaultValue: Object): Object = {
    var `val` : Object = null
    var tempObj = obj
    try {
      var keyArr : Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1){
        if (i < (keyArr.length - 1)){
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.get(keyArr(i))
      }
    } catch {
      case e: Exception =>
        logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if(`val` == null) `val` = defaultValue
    `val`
  }
  def parseJSONObject(str: String): JSONObject = {
    if (!StringUtils.nonEmpty(str)) {
      return null
    }
    var jObj: JSONObject = null
    try {
      jObj = JSON.parseObject(str)
    } catch {
      case e: Exception => null
    }
    jObj
  }
  def isValidJSON(jsonStr: String): Boolean = {
    var boolean: Boolean = true
    try {
      JSON.parseObject(jsonStr)
    } catch {
      case e: Exception => boolean = false
    }
    boolean
  }

}
