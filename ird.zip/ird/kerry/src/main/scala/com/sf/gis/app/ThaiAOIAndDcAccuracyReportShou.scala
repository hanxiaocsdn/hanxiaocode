package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.HighFrequencyNotRecognizeAoiDataPai.replaceInvalidStr
import com.sf.gis.app.ThaiAOIAndDcAccuracyReport.{getZipCityInfo, logger}
import com.sf.gis.app.WaybillXYLocationAoi.searchByPointUrl
import com.sf.gis.java.utils.HttpUtils
import com.sf.gis.utils._
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-09-20 10:42
 * @TaskId:828562
 * @TaskName:
 * @Description:aoi和dc准确率报表
 */

object ThaiAOIAndDcAccuracyReportShou {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)

    val saveKey=Array("sysorderno","interfacetype","ordertype","bookingdatetime","orderfromvo_zipcode","orderfromvovo_address","orderfromvo_address2","orderfromvo_mobile","syssource","clientcode","aoiareacode","aoicode","aoiid","deptcode","omssendtime","src","originid","geo_location","userid","output_80_aoi_id","output_80_aoi_code","output_80_dc","is_recognize_aoi","is_exist_batch_aoi","is_same_xj_batch_aoi","is_same_xj_80_aoi","output_80_aoi_area_id","is_same_xj_80_aoi_area","addresspin","batch_aoi","district","hq_code")
    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取邮编区域映射信息")
        val postalMapBro: Broadcast[collection.Map[String, String]] = getZipCityInfo(sparkSession)
        val aoiAreaInfoMapBroad = getAoiAreaInfo(sparkSession, end_day)
        logger.error("获取排班信息")
        val batchAoiRdd = getScheduleBatchData(sparkSession, end_day)
        logger.error("计算收件aoi准确率报表")
        val resultRdd = calcAccuracy(sparkSession, end_day, batchAoiRdd,aoiAreaInfoMapBroad,postalMapBro)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_delivery_scheduling_chk_shou",Array(("inc_day", end_day)), 25)


    }


    def getZipCityInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.thai_postal_city_info
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val postalMap = dataRdd.map(obj => {
            val postal_code = obj.getString("postal_code")
            val city_code = obj.getString("city_code")
            val district = obj.getString("district")
            (postal_code, city_code + "\001" + district)

        }).collectAsMap()
        spark.sparkContext.broadcast(postalMap)

    }

    def getAoiAreaInfo(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select guid,aoi_area_id from
              |    dm_tc_waybillinfo.dm_sds_aoi_area_aoi_info_dtl_df b
              |    where inc_day ='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val aoiAreaInfoMap = dataRdd.map(obj => {

            val guid = obj.getString("guid")
            val aoi_area_id = obj.getString("aoi_area_id")
            (guid, aoi_area_id)
        }).collectAsMap()
        spark.sparkContext.broadcast(aoiAreaInfoMap)


    }

    def getScheduleBatchData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select emp_no,aoi_id batch_aoi from dm_tc_waybillinfo.dm_sds_scheduling_result_dtl_df where inc_day = '$end_day' and batch_date = '$end_day'
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val batchAoiRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("emp_no"))).groupBy(x => x.getString("emp_no")).flatMap(x => {
            val list = new ListBuffer[JSONObject]()
            val emp_no = x._1
            val aoiSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                try {
                    val batch_aoi = obj.getString("batch_aoi")
                    val aoiArr = JSON.parseObject(batch_aoi)
                    val aois = aoiArr.keySet().toArray()
                    for (aoiKey <- aois) {
                        if (!aoiSet.contains(aoiKey.toString)) {
                            aoiSet.add(aoiKey.toString)
                        }
                    }

                } catch {
                    case e: Exception => logger.error(e.printStackTrace())
                }
            }
            if (aoiSet.size > 0) {
                val tmpObj = new JSONObject()
                tmpObj.put("emp_no", emp_no)
                tmpObj.put("batch_aoi", aoiSet.mkString(","))
                list += tmpObj

            }

            list
        }).filter(x => StringUtils.nonEmpty(x.getString("emp_no"))).map(x => (x.getString("emp_no"), x))

        batchAoiRdd

    }


    def calcAccuracy(spark: SparkSession,end_day:String,batchAoiRdd:RDD[(String,JSONObject)],aoiAreaInfoMapBroad:Broadcast[collection.Map[String, String]],postalMapBro:Broadcast[collection.Map[String, String]])={


        var sql=
            s"""
              |
              |select * from dm_gis.thai_delivery_scheduling_chk_shou_mid_data where inc_day='$end_day'
              |
              |
              |
              |""".stripMargin


        sql=
            s"""
              |
              |
              |select a.*,b.hq_code from
              | (select * from dm_gis.thai_delivery_scheduling_chk_shou_mid_data where inc_day='$end_day') a
              |left join
              |(select
              | *
              | from dim.dim_department_info_df
              | WHERE dept_type_code IN ('DB05-DB', 'DB05-JPZ', 'FB04-ZHB')
              | AND delete_flg = '0'
              | and inc_day = '$end_day' ) b on a.deptcode = b.dept_code
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val addOtherWaybillAoi = dataRdd.distinct().mapPartitions(x => {
            val list = new ListBuffer[JSONObject]()
            for (obj <- x) {
                try{
                    val geo_location = obj.getString("geo_location")
                    val output_80_aoi_id = obj.getString("output_80_aoi_id")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    if(!StringUtils.nonEmpty(output_80_aoi_id)){
                        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                            val (aoi_id,aoi_code,zno_code) = getAoiFromInterface(x, y)
                            obj.put("output_80_aoi_id", aoi_id)
                            obj.put("output_80_aoi_code", aoi_code)
                            obj.put("output_80_dc", zno_code)
                        }

                    }



                }catch {case e:Exception=>logger.error(e.getMessage)}

                list += obj
            }
            list.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("对于没有aoi的数据重新调用点落aoi接口----》"+addOtherWaybillAoi.count())
        val addBatchAoiRdd = addOtherWaybillAoi.map(x => (x.getString("userid"), x)).leftOuterJoin(batchAoiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.put("batch_aoi", rightOp.get.getString("batch_aoi"))

                }

            }
            leftObj


        })

        val resultRdd = addBatchAoiRdd.map(obj => {

            val aoiAreaInfoMap = aoiAreaInfoMapBroad.value
            val postalMap = postalMapBro.value
            val aoiid = obj.getString("aoiid")
            val batch_aoi = obj.getString("batch_aoi")
            val aoicode = obj.getString("aoicode")
            val aoiareacode=obj.getString("aoiareacode")
            val output_80_aoi_id = obj.getString("output_80_aoi_id")
            val address1 = replaceInvalidStr(obj.getString("orderfromvovo_address"))
            val address2 = replaceInvalidStr(obj.getString("orderfromvo_address2"))
            val orderfromvo_zipcode = obj.getString("orderfromvo_zipcode")
            val address = address1 + " " + address2
            var output_80_aoi_area_id=""
            obj.put("addresspin",address.trim)

            var city_code = ""
            var county = ""
            if (postalMap.contains(orderfromvo_zipcode)) {
                val str = postalMap.get(orderfromvo_zipcode).get.split("\001")
                if (str.length > 1) {
                    city_code = str(0)
                    county = str(1)
                }

            }

            if(aoiAreaInfoMap.contains(output_80_aoi_id)){
                output_80_aoi_area_id=aoiAreaInfoMap.get(output_80_aoi_id).get
            }
            //丰图是否识别AOI
            var is_recognize_aoi = "false"
            //是否存在排班aoi
            var is_exist_batch_aoi = "false"
            //识别小件AOI与排班AOI是否一致
            var is_same_xj_batch_aoi = "false"
            //识别小件AOI与妥投AOI是否一致
            var is_same_xj_80_aoi = "false"
            //识别小件aoi区域是否一致
            var is_same_xj_80_aoi_area="false"


            if (StringUtils.nonEmpty(aoiid)) {
                is_recognize_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi)) {
                is_exist_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(batch_aoi) && StringUtils.nonEmpty(aoicode) && batch_aoi.contains(aoicode)) {
                is_same_xj_batch_aoi = "true"
            }
            if (StringUtils.nonEmpty(aoiid) && StringUtils.nonEmpty(output_80_aoi_id) && aoiid.equals(output_80_aoi_id)) {
                is_same_xj_80_aoi = "true"
            }

            if(StringUtils.nonEmpty(output_80_aoi_area_id)&&StringUtils.nonEmpty(aoiareacode)&&aoiareacode.equals(output_80_aoi_area_id)){
                is_same_xj_80_aoi_area="true"

            }

            obj.put("is_recognize_aoi", is_recognize_aoi)
            obj.put("is_exist_batch_aoi", is_exist_batch_aoi)
            obj.put("is_same_xj_batch_aoi", is_same_xj_batch_aoi)
            obj.put("is_same_xj_80_aoi", is_same_xj_80_aoi)
            obj.put("output_80_aoi_area_id", output_80_aoi_area_id)
            obj.put("is_same_xj_80_aoi_area", is_same_xj_80_aoi_area)
            obj.put("district", county)

            obj
        }).distinct()

        resultRdd


    }




    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }
    def getAoiFromInterface(x:String,y:String)={

        val url=String.format(searchByPointUrl,x,y)

        Thread.sleep(1200)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                null
            }
        }
        val aoi_id = JSONUtil.getJsonVal(jSONObject, "result.id", "")
        val aoi_code = JSONUtil.getJsonVal(jSONObject, "result.aoiCode", "")
        val zno_code = JSONUtil.getJsonVal(jSONObject, "result.znoCode", "")
        (aoi_id,aoi_code,zno_code)



    }


}
