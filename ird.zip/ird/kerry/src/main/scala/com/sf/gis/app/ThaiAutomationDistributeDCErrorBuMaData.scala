package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}

import com.sf.gis.java.utils.HttpInvokeUtil
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2024-01-10 14:17
 * @TaskId:874166
 * @TaskName:嘉里分单补码错分任务自动下发
 * @Description:
 */

object ThaiAutomationDistributeDCErrorBuMaData {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val url="https://gis-aos.th.kerryexpress.com/work/api/addWaybillTask"
    val saveKey=Array("hq_code","waybill_no","consignee_post_code","out_param_addressee_dept_code","addresspin","code","message","addr_freq","geo_location")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = getData(sparkSession, end_day, start_day)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_thai_shenbu_analysis_di",Array(("inc_day", end_date)), 25)


    }

    def getData(spark: SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |
              |select a.* from
              |(select * from dm_gis.thai_delivery_scheduling_chk_dc_error where inc_day='$end_day' and addr_freq > 1 and hq_code<>'' and out_param_addressee_dept_code<>'' ) a
              |left join
              |(select addresspin from dm_gis.dm_thai_shenbu_analysis_di where inc_day='$start_day' ) b on a.addresspin=b.addresspin
              |where b.addresspin is null
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        val resultRdd = dataRdd.repartition(1).mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            val token=getToken()

            for (obj <- x) {
                val out_param_addressee_dept_code = obj.getString("out_param_addressee_dept_code")
                val hq_code = obj.getString("hq_code")
                val waybill_no = obj.getString("waybill_no")
                val consignee_post_code = obj.getString("consignee_post_code")
                val addresspin = obj.getString("addresspin")
                val addr_freq=obj.getString("addr_freq")
                val geo_location=obj.getString("geo_location")
                val parmObj = new JSONObject()
                //{"district":"755","zipCode":"123","taskType":2,"address":"112","wbNo":"","dc":"010","srcuid":"","delFlag":""}
                parmObj.put("district", hq_code)
                parmObj.put("freq", addr_freq.toInt)
                parmObj.put("zipCode", consignee_post_code)
                parmObj.put("address", addresspin)
                parmObj.put("dc", out_param_addressee_dept_code)
                parmObj.put("deliverCoor",geo_location)
                parmObj.put("taskType", "1")
                //                parmObj.put("region", "TH")
                parmObj.put("wbNo", waybill_no)
                val (code, message) = getInterfaceData(parmObj,token)
                obj.put("code", code)
                obj.put("message", message)
//                obj.put("addresspin",parmObj.toString)
                listbuffer += obj

            }

            listbuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量----》"+resultRdd.count())

        resultRdd




    }


    def getInterfaceData(param:JSONObject,token:String)={




        val headers = new util.HashMap[String,String]()
        val value = "Bearer " + token

        headers.put("Accept-language","zh-CN")
        headers.put("Auth-client-id","orioncloud-client-work")
        headers.put("Auth-tenant-code","TH")
        headers.put("Auth-tenant-id","24")
        headers.put("Authorization",value)
        var code=""
        var message=""
        Thread.sleep(200)
        val jSONObject = try {
            JSON.parseObject(HttpInvokeUtil.sendPostMultiHeader(url, param.toString, headers, 3))
//            JSON.parseObject(HttpInvokeUtil.sendPostHeader(url, param.toString, "Authorization",value,"utf-8","utf-8"))
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+param.toString())
                message=e.toString
                new JSONObject()
            }
        }

        if(jSONObject!=null){
            code=JSONUtil.getJsonVal(jSONObject,"code","")
            message=JSONUtil.getJsonVal(jSONObject,"message","")
//            message=jSONObject.toString

        }
        (code,message)
    }


    def getToken(): String = {
        var access_token = ""

        val username = "01407499"
        val password = "Lzj01407499@"
        val header = "Authorization"
        val value = "Basic R0lTLUFTUy1BT1MtQkRQOkFPU0BCRFAhMjAyMg=="
        val url = "http://gis-ird-gateway.int.os-sgp.local/uac/oauth/token?grant_type=password&username=%s&password=%s".format(username, password)

        breakable(
            for (i <- 0.until(5)) {
                try {
                    val jsonObject = HttpInvokeUtil.sendPostHeader(url, "", header, value, "UTF-8", "UTF-8")
                    logger.error(">>>访问getToken：url" + i + "=" + url + ", result=" + jsonObject)
                    Thread.sleep(2000)
                    if (jsonObject != null) {

                        access_token = JSONUtil.parseJSONObject(jsonObject).getString("access_token")
                        if (StringUtils.nonEmpty(access_token)) break
                        else Thread.sleep(2000)
                    }
                    if (i >= 4) break
                } catch {
                    case e: Exception => logger.error(">>>访问getToken：url" + i + "=" + url)
                }
            }
        )
        access_token
    }




}
