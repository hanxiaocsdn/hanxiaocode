package com.sf.gis.app

import com.alibaba.fastjson.JSONObject

import com.sf.gis.utils.{Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01431608
 * @Author: 01407499
 * @CreateTime: 2023-10-12 16:22
 * @TaskId:862403
 * @TaskName:
 * @Description:高频未识别下发核实派件数据
 */

object HighFrequencyNotRecognizeAoiDataPai {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("waybill_no","source_zone_code","dest_zone_code","addressee_dept_code","addresseeaoicode","dest_lgt","dest_lat","consignee_emp_code","consigned_tm","deliver_emp_code","signin_tm","consignor_post_code","consignee_post_code","input_param_waybill_no","input_param_receiver_addr","input_param_receiver_addr2","input_param_receiver_postal_code","input_param_send_time","out_param_addressee_aoi_area","out_param_addressee_aoi_code","out_param_addressee_aoi_id","out_param_addressee_dept_code","out_param_addressee_transit_code","largedccode","addresspin","addr_freq","geo_location")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取原来已下发数据")
        val oldAddrRdd = getOldData(sparkSession, end_day)
        logger.error("统计新增待下发数据")
        val resultRdd = getData(sparkSession, end_day, oldAddrRdd)
        logger.error("存储待下发数据数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_weishibie_weixiafa_chk_pai",Array(("inc_day", end_day)), 25)


    }
    def getOldData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select addresspin from dm_gis.thai_weishibie_weixiafa_chk_pai where inc_day<'$end_day'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        dataRdd.filter(x=>StringUtils.nonEmpty(x.getString("addresspin"))).map(x=>(x.getString("addresspin"),x))

    }

    def getData(spark: SparkSession,end_day:String,addrRdd:RDD[(String,JSONObject)])={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.thai_weishibie_weixiafa_chk_pai_mid_data where inc_day='$end_day'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val address1 = replaceInvalidStr(obj.getString("input_param_receiver_addr"))
            val address2 = replaceInvalidStr(obj.getString("input_param_receiver_addr2"))
            val address = address1 + " " + address2
            obj.put("addresspin", address.trim)
            obj

        }).filter(x=>StringUtils.nonEmpty(x.getString("addresspin"))).groupBy(x => x.getString("addresspin")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val address_num = x._2.toList.length
            val tmpObj = new JSONObject()
            tmpObj.fluentPutAll(x._2.head)
            tmpObj.put("addr_freq", address_num)
            listBuffer+=tmpObj

            listBuffer
        }).map(x => (x.getString("addresspin"), x)).leftOuterJoin(addrRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                if (rightObj.isEmpty) {
                    dataObj.fluentPutAll(leftObj)

                }

            }
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("addresspin")))

        /*

.filter(x => {
            val addr_freq = x.getString("addr_freq")
//            if (StringUtils.nonEmpty(addr_freq) && addr_freq.toLong >= 7) {
//                true
//            } else {
//                false
//            }

        })

         */

        resultRdd

    }



    def replaceInvalidStr(addr:String): String ={
        var addrs=""
        if(!StringUtils.nonEmpty(addr)){
            return addrs
        }
        var flag=true
        addrs=addr.trim
        while(flag){
            if(addrs.matches("^([-])(.*)|(.*)([-])$")){
                addrs=addrs.replaceAll("^([-])?|([-])?$","").trim
            }else{
                flag=false
            }
        }
        addrs

    }

}




