package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.app.WaybillXYLocationAoi.{getGeoData, logger}
import com.sf.gis.java.utils.GeometryUtil
import com.sf.gis.utils.{Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01430458
 * @Author: 01407499
 * @CreateTime: 2023-05-09 10:20
 * @TaskId:773611
 * @TaskName:
 * @Description:嘉里-审补数据入库-中间数据
 */

object WaybillAndAoiToShenbuMid {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","input_param_receiver_postal_code")


    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var end_date=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val broadcastAoiList = getAoiWktNew(sparkSession)
        val dataRdd = getWaybillDataNew(sparkSession, broadcastAoiList,end_day,end_date)
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveKey, "dm_gis.thai_aoi_mid_shenbu_tmp_data",Array(("inc_day", end_day)), 500)

    }


    def getWaybillData(spark: SparkSession,aoiListBroadcast:Broadcast[List[JSONObject]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        sql=
            """
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id not in ('10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','0280','10570','12120','13180','74130')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |    select *,
              |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20221126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |where destination_dc_code='LMK'
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.repartition(4000).map(obj => {
            val aoiList = aoiListBroadcast.value
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(1)
            val y = geoStrings(0)
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            var zno_code=""
            val listBuffer: ListBuffer[String] = ListBuffer()
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                for (aoiObj <- aoiList) {
                    val wkt = aoiObj.getString("wkt")
                    val d = getGeoData(wkt, x.toDouble, y.toDouble)
                    if (distance >= 0.0 &&d>=0.0&& distance > d) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")
                        zno_code=aoiObj.getString("zno_code")
                        listBuffer+=(d.toString+":"+aoicode)

                    } else if (distance < 0.0&&d>=0.0) {
                        distance = d
                        aoiid = aoiObj.getString("gui_id")
                        aoicode = aoiObj.getString("aoi_code")
                        zno_code=aoiObj.getString("zno_code")
                        listBuffer+=(d.toString+":"+aoicode)

                    }

                }

                dataObj.put("aoiid", aoiid)
                dataObj.put("aoicode", aoicode)
                dataObj.put("dc", zno_code)
//                dataObj.put("distanceList",listBuffer.toString())


            }

            (obj._1, dataObj)

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        aoiInfoRdd.take(10).foreach(println)

        val aoiRdd = dataRdd.map(x => (x.getString("geo_location"), x)).repartition(4000).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        })


        val resultRdd = aoiRdd.map(obj => {
            //recipient_address,recipient_address2
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj


        }).groupBy(x => (x.getString("address"), x.getString("aoicode"))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoi_num = x._2.toList.length
            for (obj <- x._2) {
                obj.put("aoi_num", aoi_num)
                listBuffer += obj
            }

            listBuffer

        }).groupBy(x => x.getString("address")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val address_num = x._2.toList.length
            val aoiSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                aoiSet.add(obj.getString("aoicode"))
            }

            for (obj <- x._2) {
                obj.put("address_num", address_num)
                obj.put("aoi_total", aoiSet.size)
                listBuffer += obj
            }
            listBuffer
        }).map(obj => {
            val address_num = obj.getString("address_num")
            val aoi_num = obj.getString("aoi_num")
            var aoi_percentage = 0.0
            if (StringUtils.nonEmpty(address_num) && StringUtils.nonEmpty(aoi_num)) {
                aoi_percentage = aoi_num.toDouble / address_num.toDouble
                if (aoi_percentage > 0.85)
                    obj.put("aoi_percentage", aoi_percentage)
                else
                    obj.put("aoi_percentage", null)

            }


            obj

        }).filter(x => StringUtils.nonEmpty(x.getString("aoi_percentage"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+resultRdd.count())
        resultRdd

    }

    def getAoiWktNew(spark:SparkSession)={
        var sql="select * from dm_gis.thai_aoi_wkt_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val wktMap = new mutable.HashMap[String, mutable.ListBuffer[JSONObject]]()
        val list = dataRdd.collect().toList
        for(obj<-list){
            val wkt = obj.getString("wkt")
            val gui_id=obj.getString("gui_id")
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(wkt)

                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    if(wktMap.contains(key)){
                        val value: ListBuffer[JSONObject] = wktMap.get(key).get
                        value+=obj
                        wktMap.put(key,value)

                    }else{
                        val temList = new ListBuffer[JSONObject]()
                        temList+=obj
                        wktMap.put(key,temList)

                    }
                }

            }catch {
                case e:Exception=>{
                    logger.error("error aoiid---> "+gui_id+" error wkt---> "+wkt)
                    logger.error("error reason---->"+e.getMessage)
                }
            }


        }
        spark.sparkContext.broadcast(wktMap)


    }

    def getWaybillDataNew(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String,end_date:String) = {
        var start_date=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"
        var sql =
            s"""
               |
               |select * from
               |(
               |select id, consignment_no, act_delivery_date,recipient_address, recipient_soi,recipient_road,recipient_address2,recipient_postcode_id, destination_dc_id,destination_dc_code,destination_dc_en_name,destination_dc_th_name from
               |dwd.dwd_consignment_dtl_di
               |where inc_day='$end_day' and act_delivery_date between '$start_date' and '$end' and destination_dc_code in ('LMK','PBP','PH2','PHT','SKK')
               |) a
               |inner join
               |(
               |select consignment_no, status_id, geo_location from
               |(
               |    select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
               |     from  ods_kems.consignment_tracking
               |     where inc_day='$end_day' and status_id='21'  and geo_location is not null
               |) bb  where rank =1
               |) b
               |on a.consignment_no = b.consignment_no
               |
               |
               |
               |""".stripMargin

        //'10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','74130','10280','10570','10550','10320','13180'




        sql=
            """
              |
              |
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id not in ('10100','10110','10120','10140','10150','10160','10170','10200','10210','10220','10230','10240','10250','10260','10300','10310','10330','10400','10500','10510','10520','10530','10600','10700','10800','10900','10550','10320','10130','10280','10560','10270','10540','10570','10290','11000','11120','11130','11140','11110','11150','12130','12120','12140','12160','12000','12170','12110','12150','74110','74000','74130','74120','13180')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |    select *,
              |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20221126' and '20230326' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |""".stripMargin

        sql=
            """
              |
              |
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20230502' and '20230504' and act_delivery_date between '2023-05-04 00:00:00' and '2023-05-04 23:59:59' and recipient_postcode_id not in ('10100','10110','10120','10140','10150','10160','10170','10200','10210','10220','10230','10240','10250','10260','10300','10310','10330','10400','10500','10510','10520','10530','10600','10700','10800','10900','10550','10320','10130','10280','10560','10270','10540','10570','10290','11000','11120','11130','11140','11110','11150','12130','12120','12140','12160','12000','12170','12110','12150','74110','74000','74130','74120','13180')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |    select *,
              |    row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |     from  ods_kems.consignment_tracking
              |     where inc_day between '20230504' and '20230504' and status_id='21'  and geo_location is not null
              |) bb  where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |
              |
              |
              |""".stripMargin

        sql=
            """
              |
              |
              |select  consignment_no,act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id,destination_dc_code,geo_location from dm_gis.thai_aoi_mid_shenbu_tmp_data  WHERE inc_day IN ('20230701', '20230819')
              |  AND recipient_postcode_id NOT IN ('10100','10110','10120','10170','10200','10260','10300','10310','10330','10400','10500','10600','10800','10900','10320')
              |
              |
              |""".stripMargin
        sql=
            """
              |
              |
              |select a.*,b.recipient_address,b.recipient_address2,b.input_param_receiver_postal_code,c. geo_location
              |from
              |(
              |
              |    select waybill_no consignment_no,dest_zone_code destination_dc_code,cast(signin_tm as string) act_delivery_date
              |    from dwd.dwd_waybill_kex_info_dtl_di
              |    where inc_day between '20230801' and '20231113' and signin_tm between '2023-08-01 00:00:00' and '2023-11-13 23:59:59'
              |) a inner join
              |(
              |    select input_param_waybill_no,input_param_receiver_addr recipient_address,input_param_receiver_addr2 recipient_address2,input_param_receiver_postal_code
              |    from
              |    (
              |        select *, row_number() over(partition BY input_param_waybill_no order by input_param_send_time desc) as rank
              |        from dm_gis.obs_chk_pai_log_parse_data
              |        where inc_day between '20230801' and '20231113'
              |        and out_param_addressee_aoi_code = ''
              |        and input_param_receiver_postal_code NOT IN ('10100','10110','10120','10170','10200','10260','10300','10310','10330','10400','10500','10600','10800','10900','10320')
              |    ) bb
              |    where rank = 1
              |) b on a.consignment_no = b. input_param_waybill_no
              |inner join
              |(
              |    select consignment_no, geo_location
              |    from
              |    (
              |        select *, row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |        from ods_kems.consignment_tracking
              |        where inc_day between '20230801' and '20231113' and status_id='21'
              |    ) cc
              |    where rank =1
              |) c on a.consignment_no = c.consignment_no
              |
              |
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val geoRdd = dataRdd.map(obj => (obj.getString("geo_location"),new JSONObject())).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey()
        val aoiInfoRdd = geoRdd.repartition(4000).map(obj => {
            val geoStrings = obj._1.split(",")
            val dataObj = new JSONObject()
            val x = geoStrings(1)
            val y = geoStrings(0)
            val aoiListMap = aoiListBroadcast.value
            var distance = (-1.0)
            var aoiid = ""
            var aoicode = ""
            var wktend=""
            var zno_code=""
            var name_chn=""
            if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                breakable {
                    val key = GeometryUtil.sliceUpCoordinate(x.toDouble, y.toDouble)
                    if(aoiListMap.contains(key)){
                        val aoiList = aoiListMap.get(key).get
                        for (aoiObj <- aoiList) {
                            val wkt = aoiObj.getString("wkt")
                            val d = getGeoData(wkt, x.toDouble, y.toDouble)
                            if(d==0.0){
                                distance = d
                                aoiid = aoiObj.getString("gui_id")
                                aoicode = aoiObj.getString("aoi_code")
                                wktend=aoiObj.getString("wkt")
                                zno_code=aoiObj.getString("zno_code")
//                                name_chn=aoiObj.getString("name_chn")
                                break
                            }
                        }

                    }


                }

            }
            dataObj.put("aoiid", aoiid)
            dataObj.put("aoicode", aoicode)
            dataObj.put("wkt",wktend)
            dataObj.put("dc",zno_code)
//            dataObj.put("name_chn",name_chn)
            dataObj.put("dis", distance)
            (obj._1, dataObj)

        })
        val aoiRdd = dataRdd.map(x => (x.getString("geo_location"), x)).repartition(4000).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (rightObj.nonEmpty) {
                leftObj.fluentPutAll(rightObj.get)
            }
            leftObj

        }).distinct()

        val resultRdd = aoiRdd.map(obj => {
            //recipient_address,recipient_address2
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+resultRdd.count())
        resultRdd.take(10).foreach(println)
        Spark.clearPersistWithoutId(spark,resultRdd.id)
        resultRdd
    }

    def getAoiWkt(spark:SparkSession)={
        val columns=Array("gui_id","zno_code","name_chn","aoi_code","wkt")
        val srcDF = spark.read
            .option("inferschema", "false")
            //.option("multiLine", true)
            .option("header", "false")
            .option("encoding", "UTF-8")
            .csv("hdfs://kex/user/01407499/upload/gex_aoi_050602.csv")
            .toDF("gui_id","zno_code","name_chn","aoi_code","wkt")
        val dataRdd = srcDF.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getAs[String](columns(i)))
            }
            jObj
        })
        spark.sparkContext.broadcast(dataRdd.collect().toList)

    }


    def replaceInvalidStr(addr:String): String ={
        var addrs=""
        if(!StringUtils.nonEmpty(addr)){
            return addrs
        }
        var flag=true
        addrs=addr.trim
        while(flag){
            if(addrs.matches("^([-])(.*)|(.*)([-])$")){
                addrs=addrs.replaceAll("^([-])?|([-])?$","").trim
            }else{
                flag=false
            }
        }
        addrs

    }

}
