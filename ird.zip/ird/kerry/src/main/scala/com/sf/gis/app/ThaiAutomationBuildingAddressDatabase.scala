package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.app.ThaiAutomationBuildingAddressDatabase.checkDictLevel
import com.sf.gis.app.WaybillAndAoiToShenbuMid.replaceInvalidStr
import com.sf.gis.app.WaybillXYLocationAoi.getGeoData
import com.sf.gis.java.utils.{GeometryUtil, HttpUtils, MD5Util}
import com.sf.gis.utils.{JSONUtil, Spark, SparkRead, SparkWrite, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:ft80006092
 * @Author: 01407499
 * @CreateTime: 2023-07-04 10:46
 * @TaskId:775283
 * @TaskName:
 * @Description:嘉里分单-构建地址库
 */

object ThaiAutomationBuildingAddressDatabase {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveMidKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","split_result", "addr_split_info")
    val saveKey=Array("id","name","alias","subno","adcode","x","y","tag","dccode","dc","aoiid","aoi_code","level","waybill_no","groupby","all_code_list","groupby_count","aoi_code_max","aoi_code_max_percent","data_type","zipcode","address")
    val saveTmpKey=Array("consignment_no","act_delivery_date","recipient_address","recipient_address2","recipient_postcode_id","destination_dc_code","geo_location","address","dc","aoicode","aoiid","split_result","addr_split_info","province","district","subno","name","level","tag","adcode")
    val geoUrl="http://10.234.0.255:7014/?query_type=GEOCODE&address=%s&zipcode=%s&filter_uprecision=2&ret_splitinfo=1&output=json"
    val dict_13=Array("ออฟฟิศ","ที่ทำการ","สถานที่ทำการ","สนง.","กระทรวง","กรม","กอง","สำนัก","ศูนย์","ค่าย","มณฑลทหารบก","กรม","กอง","กองบัญชาการ","กองทัพ","ฐานทัพ","โรง","คลินิก","คลินิค","คลีนิก","คลีนิค","ร้านทอง","ห้างทอง","หอพัก","โชว์รูม","สนามกอล์ฟ","วัด","โครงการ","มูลนิธิ","การไฟฟ้า","รร.","ร.ร.","โกดัง","คลัง","เอื้ออาทร","อู่","สถาบัน","ศาล","สุขาภิบาล","สถาน","สนาม","ชุมชน","ประชาคม","ร้านรถเมล์","ตลาด","ธุรกิจ","ร้านค้า")
    val dict_14=Array("บ้านเลขที่","หมู่ที่","ลขที่","บ้านที่","บ้าน้ลขที่","ตึก")
    val dict_10=Array("แยก", "เเยก", "yaek", "yeak", "soi", "ซ.", "ซ", "ซ .", "ซอย", "ตรอก")
    val dict_9=Array("ถนนจร","ถ.","ถนน","ทางด่วน")
    val dict_6=Array("ม.","หมู","หมุ่","moo","บ้าน","บ.","มบ.","โซน","หมู่บ้าน","บ.","บจก.","ห้างหุ้นส่วนจำกัด","หจก.","บมจ.","บจ.","บริษัท ")
    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val mode=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取dccode数据")
        val dcCodeInfoMapBroad: Broadcast[Map[String, String]] = getDccodeInfo(sparkSession)
        logger.error("获取district数据")
        val districtInfoMapBroad = getDistrictInfo(sparkSession)
        logger.error("获取aoi区域数据")
        val broadcastAoiList = getAoiWktNew(sparkSession)
        logger.error("获取Subdistrict区域数据")
        val broadcastSubdistrictList = getSubdistrictWktNew(sparkSession)
        var dataRdd:RDD[JSONObject]=null
        if(mode.equals("add")){
            logger.error("获取地址切词数据数据")
            dataRdd=getWaybillDataNew(sparkSession,broadcastAoiList,end_day)
            logger.error("存储地址切词数据")
            SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveMidKey, "dm_gis.thai_aoi_standard_addr_mid_data",Array(("inc_day", end_day)), 25)

        }else if(mode.equals("update")){
            dataRdd=getAddrSplitInfo(sparkSession,end_day)

        }
        logger.error("计算地址库数据")
        val resultRdd = checkAddrSplit(dataRdd, dcCodeInfoMapBroad, districtInfoMapBroad,broadcastSubdistrictList,sparkSession,end_day)
        logger.error("存储地址库数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.thai_aoi_standard_addr_data",Array(("inc_day", end_day)), 25)

    }

    def getAddrSplitInfo(spark: SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.thai_aoi_standard_addr_mid_data where inc_day='$end_day'
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)

        dataRdd

    }

    def getDccodeInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select dccode,aoi_id from dm_gis.thai_dccode_info
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val dcCodeMap = dataRdd.map(obj => (obj.getString("aoi_id"), obj.getString("dccode"))).collect().toMap
        spark.sparkContext.broadcast(dcCodeMap)


    }

    def getDistrictInfo(spark: SparkSession)={
        var sql=
            """
              |
              |select `name` as subdistrict,adcode ,zipcodes from dm_gis.thai_district_info where `level`='3'
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val zipcodeRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val zipcodes = obj.getString("zipcodes")
                if (zipcodes.split(";").size > 1) {
                    for (i <- 0 until zipcodes.split(";").size) {
                        val tmpObj = new JSONObject()
                        tmpObj.fluentPutAll(obj)
                        tmpObj.put("zipcodes", zipcodes.split(";")(i))
                        listbuffer += tmpObj
                    }
                } else {
                    listbuffer += obj
                }
            }
            listbuffer.iterator

        })
        val dcCodeMap = zipcodeRdd.map(obj => (obj.getString("zipcodes").trim+obj.getString("subdistrict").trim, obj.getString("adcode"))).collect().toMap
        spark.sparkContext.broadcast(dcCodeMap)


    }
    def getWaybillDataNew(spark: SparkSession,aoiListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],end_day:String) = {



        //'10600','10510','10110','10230','10900','10150','10210','10400','10300','10170','10140','10700','10240','10120','10800','10260','10500','10220','10160','10330','10250','10100','10200','10520','10310','10530','10560','10540','10130','10290','10270','74110','74120','74000','12120','12130','12140','12160','12170','12000','11130','11110','11140','11120','11000','11150','74130','10280','10570','10550','10320','13180'
        var sql=
            """
              |
              |
              |select a.*, b.geo_location from
              |(
              |select consignment_no, act_delivery_date,recipient_address,recipient_address2,recipient_postcode_id, destination_dc_code from
              |dwd.dwd_consignment_dtl_di
              |where inc_day between '20221124' and '20230326' and act_delivery_date between '2022-11-26 00:00:00' and '2023-03-26 23:59:59' and recipient_postcode_id in ('74110','74000','74120','74130')
              |) a
              |inner join
              |(
              |select consignment_no, geo_location from
              |(
              |select *,
              |row_number() over(partition BY consignment_no order by tracking_datetime desc) as rank
              |from ods_kems.consignment_tracking
              |where inc_day between '20221126' and '20230326' and status_id='21' and geo_location is not null
              |) bb where rank =1
              |) b
              |on a.consignment_no = b.consignment_no
              |
              |
              |""".stripMargin

        //原来建库
        sql=
            s"""
              |
              |
              |select * from dm_gis.thai_waybill_location_aoi where recipient_postcode_id in ('74110','74000','74120','74130') and inc_day='$end_day'
              |
              |""".stripMargin

        sql=
            s"""
               |
               |
               |select * from dm_gis.thai_waybill_location_aoi where recipient_postcode_id in ('74110','74000','74120','74130') and inc_day='$end_day'
               |
               |""".stripMargin

        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val addrRdd = dataRdd.map(obj => {
            //recipient_address,recipient_address2
            val address1 = replaceInvalidStr(obj.getString("recipient_address"))
            val address2 = replaceInvalidStr(obj.getString("recipient_address2"))
            val address = address1 + " " + address2
            obj.put("address", address.trim)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+addrRdd.count())
        Spark.clearPersistWithoutId(spark,addrRdd.id)
        val resultRdd = addrRdd.mapPartitions(x => {
            val datalist = new ListBuffer[JSONObject]()
            for (obj <- x) {
                val address = obj.getString("address")
                val recipient_postcode_id = obj.getString("recipient_postcode_id")
                val (splitResult, addrSplitInfo) = getSplitResult(address, recipient_postcode_id)

                obj.put("split_result",splitResult)
                obj.put("addr_split_info",addrSplitInfo)
                datalist += obj
            }
            datalist.iterator

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取地址切词数据量---》"+resultRdd.count())
        resultRdd

    }

    def checkAddrSplit(addrRdd:RDD[JSONObject],dcCodeInfoMapBroad: Broadcast[Map[String, String]],districtInfoMapBroad: Broadcast[Map[String, String]],subdistrictListBroadcast:Broadcast[mutable.HashMap[String, ListBuffer[JSONObject]]],spark: SparkSession,end_day:String)={

        val checkAddrRdd = addrRdd.mapPartitions(x => {
            val datalist = new ListBuffer[JSONObject]()
            val districtInfoMap = districtInfoMapBroad.value
            val dcCodeInfoMap = dcCodeInfoMapBroad.value
            val subdistrictListMap = subdistrictListBroadcast.value
            for (obj <- x) {
                try {
                    ////"split_result", "addr_split_info"
                    var distance = (-1.0)
                    val splitResult = obj.getString("split_result")
                    val addrSplitInfoStr = obj.getString("addr_split_info")
                    val addrSplitInfo = JSON.parseArray(addrSplitInfoStr)
                    val aoiid = obj.getString("aoiid")
                    val zipcode=obj.getString("recipient_postcode_id").trim
                    val geo_location = obj.getString("geo_location")
                    val x = geo_location.split(",")(1)
                    val y = geo_location.split(",")(0)
                    var dccode = ""
                    val (checkSplitResult, province, district, subdistrict, subno) = checkSplitLevel(addrSplitInfo)
                    if (StringUtils.nonEmpty(subdistrict)&&districtInfoMap.contains(zipcode+subdistrict.trim)) {
                        obj.put("adcode", districtInfoMap.getOrElse(zipcode+subdistrict.trim, ""))
                        obj.put("subdistrict", subdistrict)
                    } else {
                        //如果
                        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y)) {
                            var tam_nam_t=""
                            breakable {
                                val key = GeometryUtil.sliceUpCoordinate(x.toDouble, y.toDouble)
                                if(subdistrictListMap.contains(key)){
                                    val aoiList = subdistrictListMap.get(key).get
                                    for (aoiObj <- aoiList) {
                                        val wkt = aoiObj.getString("wkt")
                                        val d = getGeoData(wkt, x.toDouble, y.toDouble)
                                        if(d==0.0){
                                            distance = d
                                            tam_nam_t = aoiObj.getString("tam_nam_t")
                                            break
                                        }
                                    }
                                }
                            }
                            obj.put("adcode", districtInfoMap.getOrElse(zipcode+tam_nam_t.trim, ""))
                            obj.put("subdistrict", tam_nam_t)
                        }


                    }
                    if (StringUtils.nonEmpty(aoiid)) {
                        dccode = dcCodeInfoMap.getOrElse(aoiid, "")

                    }
                    obj.put("checkSplitResult", checkSplitResult)
                    obj.put("province", province)
                    obj.put("district", district)

                    obj.put("subno", subno)
                    obj.put("x", x)
                    obj.put("y", y)
                    obj.put("alias", "")
                    obj.put("dccode", dccode)

                    val(name,level,tag)=checkAddrSplitResult(splitResult)
                    obj.put("level", level)
                    obj.put("name", name)
                    obj.put("tag",tag)
                    if(StringUtils.nonEmpty(name))
                    datalist += obj

                    /*
                    for (i <- 0 until addrSplitInfo.size()) {
                        val addrObj = addrSplitInfo.getJSONObject(i)
                        val level = addrObj.getString("level")
                        val name = addrObj.getString("name")
                        if (level.equals("13")) {
                            if(checkDictLevel(dict_13,name)){
                                obj.put("level", level)
                                obj.put("name", name)
                                obj.put("tag",subno+name+"^1"+level)
                                datalist += obj

                            }


                        } else if (level.equals("6")) {
                            if(checkDictLevel(dict_6,name)){
                                obj.put("level", level)
                                obj.put("name", name)
                                obj.put("tag",subno+name+"^1"+level)
                                datalist += obj

                            }

                        } else if (level.equals("10")) {
                            if(checkDictLevel(dict_10,name)){
                                obj.put("level", level)
                                obj.put("name", name)
                                obj.put("tag",subno+name+"^1"+level)
                                datalist += obj

                            }

                        } else if (level.equals("9")) {
                            if(checkDictLevel(dict_9,name)){
                                obj.put("level", level)
                                obj.put("name", name)
                                obj.put("tag",subno+name+"^1"+level)
                                datalist += obj

                            }
                        }
                    }
                    */

                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                    }
                }

            }
            datalist.iterator

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取切词校验的数据数据量---》"+checkAddrRdd.count())
        SparkWrite.save2HiveStaticNew(spark, checkAddrRdd, saveTmpKey, "dm_gis.thai_aoi_standard_addr_mid_data_tmp",Array(("inc_day", end_day)), 25)
//        val filterRdd = checkAddrRdd.filter(obj => StringUtils.nonEmpty(obj.getString("checkSplitResult")) && obj.getString("checkSplitResult").toBoolean)
        val countRdd = checkAddrRdd.map(obj => {
            //name+subno+adcode+tag
            val name = obj.getString("name")
            val subno = obj.getString("subno")
            val adcode = obj.getString("adcode")
            val tag = obj.getString("tag")
            var groupby=""
            if(StringUtils.nonEmpty(name)){
                groupby=name+"|"
            }
            if(StringUtils.nonEmpty(subno)){
                groupby=groupby+subno+"|"
            }
            if(StringUtils.nonEmpty(adcode)){
                groupby=groupby+adcode+"|"
            }
            if(StringUtils.nonEmpty(tag)){
                groupby=groupby+tag+"|"
            }
            if(groupby.matches("(.*)\\|$")){
                groupby=groupby.substring(0,groupby.length-1)

            }

            obj.put("groupby", groupby)
            obj


        }).groupBy(x=>x.getString("groupby")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val address_num = x._2.toList.length
            val aoiSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                aoiSet.add(obj.getString("aoicode"))
            }
            for (obj <- x._2) {
                obj.put("groupby_count", address_num)
                obj.put("all_code_list",aoiSet.mkString("|"))
                listBuffer += obj
            }
            listBuffer
        }).groupBy(x => (x.getString("groupby"), x.getString("aoicode"))).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val aoi_num = x._2.toList.length
            for (obj <- x._2) {
                obj.put("aoi_num", aoi_num)
                listBuffer += obj
            }

            listBuffer

        })
        val resultRdd = countRdd.groupBy(x => x.getString("groupby")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataObj = new JSONObject()
            var aoi_code_max = ""
            var aoi_code_max_percent = 0.0
            var data_type = ""
            var address = ""
            var zipcode = ""
            var waybill_no = ""
            var status = "N"
            var aoi_code = ""
            var dc=""
            for (obj <- x._2) {
                val groupby_count = obj.getString("groupby_count")
                val aoi_num = obj.getString("aoi_num")
                if (StringUtils.nonEmpty(groupby_count) && StringUtils.nonEmpty(aoi_num) && (aoi_num.toDouble / groupby_count.toDouble > aoi_code_max_percent)) {
                    aoi_code_max = obj.getString("aoicode")
                    aoi_code_max_percent=aoi_num.toDouble / groupby_count.toDouble
                    dataObj = obj
                    //subno+name+tag+subdistrict+district+province
                    val subno = obj.getString("subno")
                    val name=obj.getString("name")
                    val tag=obj.getString("tag").split("\\^")(0)
                    val subdistrict=obj.getString("subdistrict")
                    val district=obj.getString("district")
                    val province=obj.getString("province")
                    if(StringUtils.nonEmpty(subno)){
                        address=subno+" "
                    }
                    if(StringUtils.nonEmpty(name)){
                        address=address+name+" "
                    }
                    if(StringUtils.nonEmpty(tag)){
                        address=address+tag+" "
                    }
                    if(StringUtils.nonEmpty(subdistrict)){
                        address=address+subdistrict+" "
                    }
                    if(StringUtils.nonEmpty(district)){
                        address=address+district+""
                    }
                    if(StringUtils.nonEmpty(province)){
                        address=address+province
                    }
                    address=address.trim
                    zipcode = obj.getString("recipient_postcode_id")
                    waybill_no = obj.getString("consignment_no")
                    dc=obj.getString("destination_dc_code")
                    val level = obj.getString("level")
                    if (level.equals("6") || level.equals("13")) {
                        data_type = "poi"

                    } else if (level.equals("9") || level.equals("10")) {
                        data_type = "streetno"
                    }
                }
            }

            if (aoi_code_max_percent >= 0.85) {
                aoi_code = aoi_code_max
                status = "Y"
                dataObj.put("status", status)
                dataObj.put("aoi_code", aoi_code)
            } else {
                status = "N"
                dataObj.put("status", status)
                dataObj.put("aoi_code", "")
                dataObj.put("dccode", "")
                dataObj.put("aoiid", "")


            }
            dataObj.put("aoi_code_max", aoi_code_max)
            dataObj.put("aoi_code_max_percent", aoi_code_max_percent)
            dataObj.put("data_type", data_type)
            dataObj.put("address", address)
            dataObj.put("zipcode", zipcode)
            dataObj.put("waybill_no", waybill_no)
            dataObj.put("dc", dc)
            dataObj.put("id",getMd5AllKey(waybill_no+dataObj.getString("name")+zipcode))
            listBuffer+=dataObj

            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("地址库数据量---》"+resultRdd.count())
        resultRdd

    }

    def checkAddrSplitResult(splitResult:String): (String,String, String) ={
        var name=""
        var tag=""
        var level=""
        if(!StringUtils.nonEmpty(splitResult)){
            return (name,level,tag)
        }
        val splitResultArr = splitResult.split(",")

        for(i<-0 until splitResultArr.size){
            val name_s = splitResultArr(i).split("\\^")(0)
            val level_s = splitResultArr(i).split("\\^")(1)
            if (level_s.equals("113")) {
                if(checkDictLevel(dict_13,name_s)){
                    if(name.isEmpty){
                        name=name_s
                        level="13"
                    }
                }
                if(StringUtils.nonEmpty(name)&&(!name.equals(name_s))){
                    if(tag.isEmpty){
                        tag=splitResultArr(i)
                    }
                }
            } else if (level_s.equals("16")) {
                if(checkDictLevel(dict_6,name)){
                    if(name.isEmpty){
                        name=name_s
                        level="6"
                    }
                }
                if(StringUtils.nonEmpty(name)&&(!name.equals(name_s))){
                    if(tag.isEmpty){
                        tag=splitResultArr(i)
                    }

                }

            } else if (level_s.equals("110")) {
                if(checkDictLevel(dict_10,name)){
                    if(name.isEmpty){
                        name=name_s
                        level="10"
                    }
                }
                if(StringUtils.nonEmpty(name)&&(!name.equals(name_s))){
                    if(tag.isEmpty){
                        tag=splitResultArr(i)
                    }
                }
            } else if (level_s.equals("19")) {
                if(checkDictLevel(dict_9,name)){
                    if(name.isEmpty){
                        name=name_s
                        level="9"
                    }
                }
                if(StringUtils.nonEmpty(name)&&(!name.equals(name_s))){
                    if(tag.isEmpty){
                        tag=splitResultArr(i)
                    }
                }
            }
        }
        (name,level,tag)

    }

    def getMd5AllKey(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr
        }
        resultMd5Str

    }

    def checkSplitLevel(addrSplitInfo:JSONArray) ={
        var level14CheckNum=0
        var level13CheckNum=0
        var level10CheckNum=0
        var level9CheckNum=0
        var level6CheckNum=0
        var province=""
        var district=""
        var subdistrict=""
        var subno=""

        var flag=true
        for(i<-0 until addrSplitInfo.size()){
            val levelInfo = addrSplitInfo.getJSONObject(i)
            val level = levelInfo.getString("level")
            val name = levelInfo.getString("name")
            if(level.equals("14")){
                subno=name.replaceAll("([^\\d|\\/])","")
                if(checkDictLevel(dict_14,name)){
                    level14CheckNum=1
                }

            }else if(level.equals("13")){
                if(checkDictLevel(dict_13,name)){
                    level13CheckNum=1
                }

            }else if(level.equals("10")){
                if(checkDictLevel(dict_10,name)){
                    level10CheckNum=1
                }

            }else if(level.equals("9")){
                if(checkDictLevel(dict_9,name)){
                    level9CheckNum=1
                }

            }else if(level.equals("6")){
                if(checkDictLevel(dict_6,name)){
                    level6CheckNum=1
                }

            }else if(level.equals("3")){
                subdistrict=name

            }else if(level.equals("2")){
                district=name

            }else if(level.equals("1")){
                province=name

            }
        }
        if((level13CheckNum+level10CheckNum+level9CheckNum+level6CheckNum)<1){
            flag=false

        }
        (flag,province,district,subdistrict,subno)


    }

    def checkDictLevel(dict:Array[String],name:String)={
        var flag=false
        for(key<-dict){
            val regex="^"+key+"(.*)"
            if(name.matches(regex)){
                flag=true
            }
        }
        if(name.length<4){
            flag=false
        }
        flag
    }
    def getSplitResult(addr:String,zipcode:String)={
        val url=String.format(geoUrl, URLEncoder.encode(addr, "UTF-8"),zipcode)

        Thread.sleep(1000)
        val jSONObject = try {
            JSON.parseObject(HttpUtils.urlConnectionGetStr(url, 5000).replaceAll("\\+",""))
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error(e.getMessage)
                new JSONObject()
            }
        }

        val splitResult=JSONUtil.getJsonVal(jSONObject,"splitResult","")
        val addrSplitInfo = JSONUtil.getJsonArrayFromObject(jSONObject, "addrSplitInfo")
        (splitResult,addrSplitInfo)

    }

    def getAoiWktNew(spark:SparkSession)={
        var sql="select * from dm_gis.thai_aoi_wkt_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val wktMap = new mutable.HashMap[String, mutable.ListBuffer[JSONObject]]()
        val list = dataRdd.collect().toList
        for(obj<-list){
            val wkt = obj.getString("wkt")
            val gui_id=obj.getString("gui_id")
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(wkt)

                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    if(wktMap.contains(key)){
                        val value: ListBuffer[JSONObject] = wktMap.get(key).get
                        value+=obj
                        wktMap.put(key,value)

                    }else{
                        val temList = new ListBuffer[JSONObject]()
                        temList+=obj
                        wktMap.put(key,temList)

                    }
                }

            }catch {
                case e:Exception=>{
                    logger.error("error aoiid---> "+gui_id+" error wkt---> "+wkt)
                    logger.error("error reason---->"+e.getMessage)
                }
            }


        }
        spark.sparkContext.broadcast(wktMap)


    }

    def getSubdistrictWktNew(spark:SparkSession)={
        var sql="select wkt,tam_nam_t from dm_gis.thai_wkt_subdistrict_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val wktMap = new mutable.HashMap[String, mutable.ListBuffer[JSONObject]]()
        val list = dataRdd.collect().toList
        for(obj<-list){
            val wkt = obj.getString("wkt")
            val tam_nam_t=obj.getString("tam_nam_t")
            if(tam_nam_t.split("\\.").size>1){
                obj.put("tam_nam_t",tam_nam_t.split("\\.")(1))
            }
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(wkt)

                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    if(wktMap.contains(key)){
                        val value: ListBuffer[JSONObject] = wktMap.get(key).get
                        value+=obj
                        wktMap.put(key,value)

                    }else{
                        val temList = new ListBuffer[JSONObject]()
                        temList+=obj
                        wktMap.put(key,temList)

                    }
                }

            }catch {
                case e:Exception=>{
                    logger.error("error aoiid---> "+tam_nam_t+" error wkt---> "+wkt)
                    logger.error("error reason---->"+e.getMessage)
                }
            }


        }
        spark.sparkContext.broadcast(wktMap)


    }

}



