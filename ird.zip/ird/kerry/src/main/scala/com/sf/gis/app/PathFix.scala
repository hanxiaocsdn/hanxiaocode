package com.sf.scala.tloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * 泰国车油补里程计算V1.0
 * 需求内容：计算小哥全量里程和网点里程,并依据计算结果,给予相应的车补和油补;kex集群scala版本与bdp不一致,打包前需修改 scala版本为2.12.14
 * 需求方：丁汀（01430258）
 * @author 徐游飞（01417347）
 * 任务ID：840734
 * 任务名称：轨迹纠偏结果
 */
object PathFix {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  // 纠偏接口
  val Rectify_URL: String = "http://gis-jp.int.os-sgp.local/drectify"  // 不用ak
  val Rectify_AK: String = ""  // 不用ak

  // 调接口
  def runRectifyInteface(ak: String, obj: JSONObject): JSONObject = {
    val tracks = JSONUtil.getJsonArrayMulti(obj, "tracks")
    val un = JSONUtil.getJsonVal(obj, "un","")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("retflag", 1)
    param.put("addpoint", 1)
    param.put("ak", ak)
    param.put("roadinfo", 1)
    param.put("vehicle", 1)
    param.put("compensate", 1)
    param.put("compensate_time", 0)
    param.put("tracks", tracks)

    var retJSONObject = new JSONObject()
    var codeStatue = ""
    var retStr = ""
    try {
      retStr = HttpInvokeUtil.sendPost(Rectify_URL, param.toJSONString, 3)
      retJSONObject = JSON.parseObject(retStr)
      codeStatue = retJSONObject.getString("ret")

      logger.error("接口调用完毕 ==> un = "+un)
    } catch {
      case e: Exception => logger.error(e)
    }
    //新增接口返回值字段
    if (!"0".equalsIgnoreCase(codeStatue)) {
      obj.put("req", param.toJSONString)
      obj.put("err", "疑似纠偏异常")
      obj.put("rsp", retStr)
    }else{
      obj.put("req", "")
      obj.put("err", "")
      obj.put("rsp", retStr)
    }

    obj
  }

  def execute(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    val track_sql =
      s"""
         |select
         |  un,
         |  ak,
         |  tp,
         |  zx,
         |  zy,
         |  tm
         |from
         |  dm_gis.dm_vms_track_device_track_dtl_di
         |where
         |  inc_day = '$dayBefore1'
         |  and ak = '1'  -- 小哥轨迹
         |group by
         |  un,
         |  ak,
         |  tp,
         |  zx,
         |  zy,
         |  tm
         |""".stripMargin
    println(track_sql)

    val dept_sql =
      s"""
         |select
         |  emp_no as un,
         |  dept_code as bn
         |from
         |  dm_tc_waybillinfo.dm_sds_scheduling_result_dtl_df
         |where
         |  inc_day = '$dayBefore1'
         |group by
         |  emp_no,
         |  dept_code
         |""".stripMargin
    println(dept_sql)
    val df_dept = spark.sql(dept_sql)

    val df_tarcks = SparkUtils.getRowToJson(spark, track_sql)
      .map(data_obj => {
        val un = JSONUtil.getJsonVal(data_obj, "un", "")
        val ak = JSONUtil.getJsonVal(data_obj, "ak", "")
        val tp = JSONUtil.getJsonVal(data_obj, "tp", "")

        ((un, ak, tp), data_obj)
      }).groupByKey()
      .map(obj => {
        val (un, ak, tp) = obj._1
        val data_arr: Array[JSONObject] = obj._2.toArray.sortBy(JSONUtil.getJsonVal(_, "tm", ""))

        val tracks = new JSONArray()
        for (elem <- data_arr) {
          val coord = new JSONObject()
          val time = JSONUtil.getJsonLong(elem, "tm", 0L)
          val x = JSONUtil.getJsonDouble(elem, "zx", 0.0)
          val y = JSONUtil.getJsonDouble(elem, "zy", 0.0)

          coord.put("time", time)
          coord.put("x", x)
          coord.put("y", y)
          coord.put("speed", 0.0)

          tracks.add(coord)
        }

        (un, ak, tp, tracks.toJSONString)
      }).toDF("un", "ak", "tp", "tracks")
      .join(df_dept, Seq("un"), "left")

    val rdd_tarcks = SparkUtils.getDfToJson(spark, df_tarcks).persist(StorageLevel.MEMORY_AND_DISK)

    var cores = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    println("rdd_tarcks 数据总量 ：" +rdd_tarcks.count())
    // 调接口
    val rdd_path_fix = SparkNet.runInterfaceWithAkLimit(spark, rdd_tarcks, runRectifyInteface, 5, Rectify_AK, 100)

    val df_path_dist = rdd_path_fix.repartition(100).map(obj => {
      val un = JSONUtil.getJsonVal(obj, "un", "")
      val ak = JSONUtil.getJsonVal(obj, "ak", "")
      val tp = JSONUtil.getJsonVal(obj, "tp", "")
      val bn = JSONUtil.getJsonVal(obj, "bn", "")

      val req = JSONUtil.getJsonVal(obj, "req", "")
      val err = JSONUtil.getJsonVal(obj, "err", "")
      val rsp = JSONUtil.getJsonVal(obj, "rsp", "")

      (un, ak, tp, bn, req, err, rsp)
    }).toDF("un", "ak", "tp", "bn", "req", "err", "rsp")
      .withColumn("inc_day", lit(dayBefore1))

    val cols_all = spark.sql("""select * from dm_gis.dm_path_fix_dtl_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_path_dist.select(cols_all: _*), Seq("inc_day","tp"), "dm_gis.dm_path_fix_dtl_di")

    rdd_tarcks.unpersist()
  }

  /**
   * 把df数据按分区覆盖写入到hive
   * @param spark
   * @param dataframe
   * @param partitionCol 分区字段
   * @param resTableName hive表名
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
    logger.error(s"写入 $resTableName 成功！")
  }

  // 将df的每一行数据转为json
  def row2Json(r: Row): JSONObject = {
    val rowMap_tmp: Map[String, String] = r.getValuesMap(r.schema.fieldNames)
    val rowMap: Map[String, String] = rowMap_tmp.map(v => {
      if (v._2 == null) (v._1, "") else v
    })

    val obj: JSONObject = new JSONObject()
    for (m <- rowMap) obj.put(m._1, m._2)
    obj
  }


  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error("++++++++  任务开始 20231031  ++++")
    execute(spark, dayBefore1)
    logger.error("++++++++  任务完成 20231031  ++++")

    spark.stop()

  }

}