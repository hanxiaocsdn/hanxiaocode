package com.sf.gis.app


import com.sf.gis.app.GisVmsTrackDeviceTrack.writeToHive
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 泰国嘉里分单仓管审补地址自动化回收工艺需求_V1.0
 * 需求方：陈丽（01430458）
 * @author 徐游飞（01417347）
 * 任务ID：766206
 * 任务名称：嘉里分单仓管审补_地址识别
 */
object ThaiAoiShenBuDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def thaiAoiShenBuV1(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore8 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 8)
    val dayBefore7 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 7)

    import spark.implicits._
    val chk_sql =
      s"""
         |select
         |  batch_aoi,
         |  addresspin,
         |  pod_aoiid,
         |  '1' as join_flag
         |from
         |  dm_gis.dm_thai_distribute_burying_point_data_di
         |where
         |  inc_day = '$dayBefore8'
         |""".stripMargin
    println(chk_sql)
    val df_chk = spark.sql(chk_sql)

    val complete_sql =
      s"""
         |select
         |  city_code,
         |  zip_code,
         |  dc,
         |  wb_no,
         |  address ,
         |  aoi_id,
         |  aoi_code,
         |  aoi_dc,
         |  exc_type,
         |  mark_coor,
         |  task_state,
         |  get_by
         |from
         |  dm_gis.dm_waybill_task_complete_dtl_di
         |where
         |  inc_day >= '$dayBefore7'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println(complete_sql)
    val df_complete = spark.sql(complete_sql)

    val df_v1 = df_complete.alias("t1")
      .join(df_chk.alias("t2"), expr("t2.addresspin = t1.address"), "left")
      .withColumn("is_same_batch_aoi",when(isEmptyOrNull('batch_aoi) or isEmptyOrNull('aoi_code),"").when('batch_aoi.contains('aoi_code),"true").otherwise("false"))
      .withColumn("is_same_pod_aoiid",when(isEmptyOrNull('aoi_id),"").when('pod_aoiid.contains('aoi_id),"true").otherwise("false"))
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val cols_tmp = spark.sql("""select * from dm_gis.thai_aoi_shenbu_dc_staff limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_v1.select(cols_tmp: _*).coalesce(3), Seq("inc_day"), "dm_gis.thai_aoi_shenbu_dc_staff")

    df_v1.drop("inc_day")
  }

  // 判断 某个字符串是否为空或者null
  def isEmptyOrNull = udf((str: String) => {
    var flag: Boolean = false
    if (str == null) flag = true
    else if (str.isEmpty) flag = true
    flag
  })

  def thaiAoiKidAcc(spark: SparkSession, df_v1: DataFrame, inc_day:String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    // get_by 维度计算准确率
    val df_kid_acc = df_v1
      .groupBy("get_by")
      .agg(
        count(when(!isEmptyOrNull('aoi_id), 1).otherwise(null)) as "coverage_ret_num",
        count(when('task_state === "3", 1).otherwise(null)) as "coverage_all_num",
        count(when('is_same_batch_aoi === "true" or 'is_same_pod_aoiid === "true",1).otherwise(null)) as "accuracy_ret_num",
        count(when('join_flag === "1" and 'is_same_batch_aoi =!= "" and 'is_same_pod_aoiid =!= "",1).otherwise(null)) as "accuracy_all_num"
      )
      .withColumn("kid_cov",when('coverage_all_num =!= 0,'coverage_ret_num / 'coverage_all_num).otherwise(0.0))
      .withColumn("kid_acc",when('accuracy_all_num =!= 0,'accuracy_ret_num / 'accuracy_all_num).otherwise(0.0))
      .withColumn("inc_day",lit(dayBefore1))

    val cols_kid_acc = spark.sql("""select * from dm_gis.thai_aoi_kid_acc limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_kid_acc.select(cols_kid_acc: _*).coalesce(3), Seq("inc_day"), "dm_gis.thai_aoi_kid_acc")

    // DC 维度计算核实率 准确率
    val df_cg_acc = df_v1
      .groupBy("dc")
      .agg(
        count(when(!isEmptyOrNull('aoi_id), 1).otherwise(null)) as "verify_num", // 核实数量
        count(when('task_state === "3", 1).otherwise(null)) as "finish_num", // 完成数量
        count(when('is_same_batch_aoi === "true" or 'is_same_pod_aoiid === "true", 1).otherwise(null)) as "verify_accuracy_num", // 核实准确数量
        count(when('join_flag === "1" and 'is_same_batch_aoi =!= "" and 'is_same_pod_aoiid =!= "", 1).otherwise(null)) as "tracking_num" // 埋点数量
      )
      .withColumn("coverage", when('finish_num =!= 0, 'verify_num / 'finish_num).otherwise(0.0))
      .withColumn("accuracy", when('tracking_num =!= 0, 'verify_accuracy_num / 'tracking_num).otherwise(0.0))
      .withColumn("inc_day", lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 总体 核实率 准确率
    val df_total_acc = df_v1
      .withColumn("dc", lit("total"))
      .groupBy("dc")
      .agg(
        count(when(!isEmptyOrNull('aoi_id), 1).otherwise(null)) as "verify_num", // 核实数量
        count(when('task_state === "3", 1).otherwise(null)) as "finish_num", // 完成数量
        count(when('is_same_batch_aoi === "true" or 'is_same_pod_aoiid === "true", 1).otherwise(null)) as "verify_accuracy_num", // 核实准确数量
        count(when('join_flag === "1" and 'is_same_batch_aoi =!= "" and 'is_same_pod_aoiid =!= "", 1).otherwise(null)) as "tracking_num" // 埋点数量
      )
      .withColumn("coverage", when('finish_num =!= 0, 'verify_num / 'finish_num).otherwise(0.0))
      .withColumn("accuracy", when('tracking_num =!= 0, 'verify_accuracy_num / 'tracking_num).otherwise(0.0))
      .withColumn("inc_day", lit(dayBefore1))

    val df_all_acc = df_cg_acc.select("dc", "coverage", "accuracy", "verify_num", "finish_num", "verify_accuracy_num", "tracking_num", "inc_day")
      .union(df_total_acc.select("dc", "coverage", "accuracy", "verify_num", "finish_num", "verify_accuracy_num", "tracking_num", "inc_day"))

    val cols_cg_acc = spark.sql("""select * from dm_gis.thai_aoi_cg_acc limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_all_acc.select(cols_cg_acc: _*).coalesce(3), Seq("inc_day"), "dm_gis.thai_aoi_cg_acc")

    df_cg_acc
  }

  def CheckAddress(spark: SparkSession, df_cg_acc: DataFrame, df_v1: DataFrame, inc_day: String) = {
    import spark.implicits._
    val df_join = df_cg_acc.join(df_v1,Seq("dc"),"inner")

    println("df_join 数据量：" + df_join.count())

    val df_yes1 = df_join.filter('coverage >= 0.8 and 'accuracy >= 0.85)
      .filter(!isEmptyOrNull('aoi_id) and isEmptyOrNull('is_same_batch_aoi))
      .withColumn("is_compliant",lit("yes1"))
      .select("batch_aoi","addresspin","pod_aoiid","is_same_batch_aoi","is_same_pod_aoiid","city_code","zip_code","dc","wb_no","address",
        "aoi_id","aoi_code","aoi_dc","exc_type","mark_coor","task_state","get_by","coverage","accuracy","is_compliant","inc_day")

    println("df_yes1 数据量：" + df_yes1.count())

    val df_yes2 = df_join.filter('coverage < 0.8 and 'accuracy >= 0.85)
      .filter(!isEmptyOrNull('aoi_id) and isEmptyOrNull('is_same_batch_aoi))
      .withColumn("is_compliant",lit("yes2"))
      .select("batch_aoi","addresspin","pod_aoiid","is_same_batch_aoi","is_same_pod_aoiid","city_code","zip_code","dc","wb_no","address",
        "aoi_id","aoi_code","aoi_dc","exc_type","mark_coor","task_state","get_by","coverage","accuracy","is_compliant","inc_day")

    println("df_yes2 数据量：" + df_yes2.count())

    val df_no1 = df_join.filter('accuracy < 0.85)
      .filter(isEmptyOrNull('is_same_batch_aoi))
      .withColumn("is_compliant",lit("no1"))
      .select("batch_aoi","addresspin","pod_aoiid","is_same_batch_aoi","is_same_pod_aoiid","city_code","zip_code","dc","wb_no","address",
        "aoi_id","aoi_code","aoi_dc","exc_type","mark_coor","task_state","get_by","coverage","accuracy","is_compliant","inc_day")

    println("df_no1 数据量：" + df_no1.count())

    val df_no2 = df_join.filter('coverage < 0.8 and 'accuracy >= 0.85)
      .filter(isEmptyOrNull('aoi_id) and isEmptyOrNull('is_same_batch_aoi))
      .withColumn("is_compliant", lit("no2"))
      .select("batch_aoi", "addresspin", "pod_aoiid", "is_same_batch_aoi", "is_same_pod_aoiid", "city_code", "zip_code", "dc", "wb_no", "address",
        "aoi_id", "aoi_code", "aoi_dc", "exc_type", "mark_coor", "task_state", "get_by", "coverage", "accuracy", "is_compliant", "inc_day")

    println("df_no2 数据量：" + df_no2.count())

    val df_yes = df_yes1.union(df_yes2)
      .withColumn("x",split('mark_coor,",")(0))
      .withColumn("y",split('mark_coor,",")(1))

    println("df_yes 数据量：" + df_yes.count())

    val df_no = df_no1.union(df_no2)
      .withColumn("x",lit(""))
      .withColumn("y",lit(""))

    println("df_no 数据量：" + df_no.count())

    val df_shenbu_addr = df_yes.union(df_no).persist(StorageLevel.MEMORY_AND_DISK)

    println("df_shenbu_addr 数据量：" + df_shenbu_addr.count())

    val cols_addr = spark.sql("""select * from dm_gis.thai_aoi_shenbu_addr_dtl limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_shenbu_addr.select(cols_addr: _*).coalesce(3), Seq("inc_day"), "dm_gis.thai_aoi_shenbu_addr_dtl")

    df_shenbu_addr
  }

  def execute(spark: SparkSession, inc_day: String) = {

    // 核实地址关联aoi
    val df_v1 = thaiAoiShenBuV1(spark, inc_day)
    // 计算准确率和核实率
    val df_cg_acc = thaiAoiKidAcc(spark, df_v1, inc_day)
    // 判断地址是否符合回收和下发条件
    CheckAddress(spark, df_cg_acc, df_v1, inc_day)

    df_cg_acc.unpersist()
    df_v1.unpersist()
  }

  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
    val spark = Spark.getSparkSession(className)
    spark.sparkContext.setLogLevel("ERROR")

    logger.error(s"++++  任务开始 inc_day=$inc_day  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成 20240115  ++++")

    spark.stop()

  }

}
