package com.sf.gis.java.utils;

import java.io.File;
import java.io.InputStream;
import java.util.Properties;

public class ConfigUtil {


    public static Properties loadPropertiesConfiguration(String fileName) {
        Properties prpts = null;
        try (InputStream in = ConfigUtil.class.getResourceAsStream(File.separator + "conf/" + fileName)) {
            prpts = new Properties();
            prpts.load(in);
        } catch (Exception e) {

        }
        return prpts;
    }

}
