package com.sf.gis.java.service;

import com.obs.services.ObsClient;
import com.sf.gis.java.utils.HuaweiObsUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ChkQueryLogParse {
//    private static final Logger logger = LoggerFactory.getLogger(ChkQueryLogParse.class);
    private static String mgsocol_obs_ak = "KMHJBPAIWF1YN8719PJX";
    private static String mgsocol_obs_sk = "UHJtA5vHfl7sw0hY2bumChikOVjuwky3L29mRdzw";
    //    val mgsocol_obs_endPoint = "https://kex-gis-ird-core-os.obs.ap-southeast-2.myhuaweicloud.com"
    private static String mgsocol_obs_endPoint = "obs.ap-southeast-2.myhuaweicloud.com";
    public static void main(String[] args) {
        //ird_chk_query_systemLog
        //ird_chk_con_systemLog chkshou
        //ird_chk_dis_systemLog chkpai
        String outputpath=args[0];
        String end_date=args[1];
        String log_prefix=args[2];
        String bucketName="kex-gis-ird-core-os";
        ObsClient client = new ObsClient(mgsocol_obs_ak, mgsocol_obs_sk, mgsocol_obs_endPoint);
        List<String> objKeyList = HuaweiObsUtil.listAllDirs(client, bucketName);
//        System.err.println(" obj key --->"+objKeyList);
//        List<String> dataList = HuaweiObsUtil.getObsData(client, bucketName, objKey);
//        System.err.println("datalist--->"+dataList.size());
        for(int i=0;i<objKeyList.size();i++){
            String objKey=objKeyList.get(i);
            if(objKey.contains(end_date)&&objKey.contains(log_prefix)){
                HuaweiObsUtil.writeFileToLocal(client,bucketName,objKey,outputpath);
                System.err.println("写出成功----》bucketName "+bucketName+" ----- objKey----> "+objKey+" outputpath "+outputpath);
            }
        }


    }
}
