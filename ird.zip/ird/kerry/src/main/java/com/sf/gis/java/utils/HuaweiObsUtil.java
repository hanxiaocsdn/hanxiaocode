package com.sf.gis.java.utils;

import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.*;
import lombok.extern.slf4j.Slf4j;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

//@Component
//@Slf4j
public class HuaweiObsUtil {

//	@Autowired(required = false)
	private ObsClient obsClient;

	private static OkHttpClient httpClient = new OkHttpClient.Builder().followRedirects(false)
			.retryOnConnectionFailure(false).cache(null).build();

//	@Value("${deepview_obs_bucketName}")
//	private String deepview_obs_bucketName;
//
//	@Value("${mapdata_obs_bucketName}")
//	private String mapdata_obs_bucketName;
//	@Value("${app_obs_bucketName}")
//	private String app_obs_bucketName;
//	@Value("${mgsocol_obs_bucketName}")
//	private String mgsocol_obs_bucketName;
//	@Value("${lingdu_obs_bucketName}")
//	private String lingdu_obs_bucketName;
//	@Value("${didi_obs_bucketName}")
//	private String didi_obs_bucketName;

	public static void writeFileToLocal(ObsClient obsClient ,String bucketName,String objectKey,String outPutPath ){
		InputStream input=null;
		FileOutputStream output=null;
		try{
			GetObjectRequest getObjectRequest = new GetObjectRequest(bucketName, objectKey);
			ObsObject obsObject = obsClient.getObject(getObjectRequest);
			input=obsObject.getObjectContent();
			File file = new File(outPutPath+"/"+obsObject.getObjectKey().split("/")[obsObject.getObjectKey().split("/").length-1]);
			output = new FileOutputStream(file);
			byte[] buffer = new byte[1024];
			int len=input.read(buffer);
//			System.err.println("缓存池大小---》 "+len);
//			System.err.println("正在读取的ObjectKey "+obsObject.getObjectKey());

			while(len!=-1){
				output.write(buffer,0,len);
				len=input.read(buffer);

			}
		}catch (Exception e){
			System.err.println("写出失败");
//			System.err.println(e.getStackTrace());
			e.printStackTrace();

		}finally {
			try{

				input.close();
				output.close();

			}catch (Exception e){

			}

		}



	}

	public static List<String> getObsData(ObsClient obsClient,String bucketName,String path){
		List<String> dataList = new ArrayList<>();
		InputStreamReader read=null;
		BufferedReader bufferedReader=null;
		InputStream input=null;
		try {
			ObsObject obsObject = obsClient.getObject(bucketName,path);
			input =obsObject.getObjectContent();
			read = new InputStreamReader(input);
			bufferedReader = new BufferedReader(read);
			String line=bufferedReader.readLine();
			while(line!=null){
				dataList.add(new String(line.getBytes(),"utf-8"));
				line=bufferedReader.readLine();
			}
		} catch (Exception e) {

			System.err.println(e.getStackTrace());

		}	finally {
			try{
				bufferedReader.close();
				read.close();
				input.close();

			}catch (Exception e){

			}

		}
		return dataList;
	}

	public String getObsTempUrl(String bucketName,String objectKey,Integer expires) throws IOException {
		TemporarySignatureRequest req2 = new TemporarySignatureRequest(HttpMethodEnum.GET, expires == null?300:expires);
		req2.setBucketName(bucketName);
		req2.setObjectKey(objectKey);
		TemporarySignatureResponse res2 = obsClient.createTemporarySignature(req2);
		return res2.getSignedUrl();
	}

//	public void uploadMapdata(String objectKey,InputStream input) {
//		obsClient.putObject(mapdata_obs_bucketName, objectKey, input);
//	}
//
//	public void uploadAppCommand(String objectKey,InputStream input){
//		PutObjectResult putObjectResult = obsClient.putObject(app_obs_bucketName, objectKey, input);
//		putObjectResult.getStatusCode();
//	}

	public void uploadInputStream(String bucketName,String objectKey,InputStream input){
		obsClient.putObject(bucketName, objectKey, input);
	}
	/**
	 * 获取目录下子目录列表
	 * @param bucketName 桶名
	 * @param dirPrefix 目录路径
	 * @return 目录名列表
	 */
	public static List<String> listDirs(ObsClient obsClient,String bucketName,String dirPrefix){
		ObjectListing res;
		List<String> directories = new ArrayList();
		ListObjectsRequest req = new ListObjectsRequest();
		req.setBucketName(bucketName);
		req.setPrefix(dirPrefix);
		req.setDelimiter("/");
		do{
			res = obsClient.listObjects(req);
			for (String folder : res.getCommonPrefixes()) {
				directories.add(folder.substring(dirPrefix.length(),folder.length()-1));
			}
			req.setMarker(res.getNextMarker());
		}while(res.isTruncated());
		return directories;
	}

	public static List<String> listAllDirs(ObsClient obsClient,String bucketName){
		ObjectListing res;
		List<String> directories = new ArrayList();
		ListObjectsRequest req = new ListObjectsRequest(bucketName);
		do{
			res = obsClient.listObjects(req);
			for (ObsObject obsObject : res.getObjects()) {
				directories.add(obsObject.getObjectKey());
			}
			req.setMarker(res.getNextMarker());
		}while(res.isTruncated());
		return directories;
	}

	/**
	 * 获取目录下文件名列表
	 * @param bucketName 桶名
	 * @param dirPrefix 目录路径
	 * @return 文件名列表
	 */
	public List<ObsObject> listFiles(String bucketName,String dirPrefix){
		ObjectListing res;
		List<ObsObject> files = new ArrayList();
		ListObjectsRequest req = new ListObjectsRequest();
		req.setBucketName(bucketName);
		req.setPrefix(dirPrefix);
		req.setDelimiter("/");
		do{
			res = obsClient.listObjects(req);
			for (ObsObject obsObject : res.getObjects()) {
				if (!obsObject.getObjectKey().equals(dirPrefix)) {
					files.add(obsObject);
				}
			}
			req.setMarker(res.getNextMarker());
		}while(res.isTruncated());
		return files;
	}

	public Boolean deleteObject(String bucketName,String objectKey){
		DeleteObjectResult res = obsClient.deleteObject(bucketName, objectKey);
		return res.getStatusCode() == 200;
	}

	public Boolean createDirectory(String bucketName,String dirKey){
		PutObjectResult res = obsClient.putObject(bucketName, dirKey, new ByteArrayInputStream(new byte[0]));
		return res.getStatusCode() == 200;
	}

	public Boolean isFileExists(String bucketName,String path){
		try {
			ObjectMetadata objectMetadata = obsClient.getObjectMetadata(bucketName,path);
			if (objectMetadata == null)
				return false;
			return true;
		} catch (Exception e) {
//			log.error(e.getMessage(),e);
		}	finally {
		}
		return false;
	}

	public Long getContentLength(String bucketName,String path){
		try {
			ObjectMetadata objectMetadata = obsClient.getObjectMetadata(bucketName,path);
			if (objectMetadata == null)
				return 0L;
			return objectMetadata.getContentLength();
		} catch (Exception e) {
//			log.error(e.getMessage(),e);
		}	finally {
		}
		return 0L;
	}

//	public BufferedImage getObsImageBuffer(String bucketName,String path) {
//		InputStream inputStream = getInputStream(bucketName, path);
//		if (inputStream == null){
//			return null;
//		}
//		try {
//			return ImageIO.read(inputStream);
//		} catch (IOException e) {
//
//			return null;
//		}
//	}

//	public String getObsTempUrlClip(String bucketName,String objectKey,Integer expires,double rate){
//		TemporarySignatureRequest req2 = new TemporarySignatureRequest(HttpMethodEnum.GET, expires == null?300:expires);
//		req2.setBucketName(bucketName);
//		req2.setObjectKey(objectKey);
//		if(bucketName.equalsIgnoreCase(deepview_obs_bucketName)){
//			Map<String, Object> queryParams = new HashMap<>();
//			queryParams.put("x-image-process","style/watermark-fengtu");
//			req2.setQueryParams(queryParams);
//		}else{
//			BufferedImage bufferedImage = getObsImageBuffer(bucketName,objectKey);
//			if (bufferedImage == null)
//				return null;
//
//			int height = bufferedImage.getHeight();
//			int width = bufferedImage.getWidth();
//			Map<String, Object> queryParams = new HashMap<>();
//			queryParams.put("x-image-process","image/crop,x_0,y_10,w_"+(int) (width*rate) + ",h_"+(int) (height*rate));
//			req2.setQueryParams(queryParams);
//		}
//		TemporarySignatureResponse res2 = obsClient.createTemporarySignature(req2);
//		return res2.getSignedUrl();
//	}
//
//	public void uploadTrackDataFile(Long time, File file, boolean testenvir) {
//		try {
//			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd");
//			String filefolder = "tackFile";
//			if(testenvir){
//				filefolder = "tackFileTest";
//			}
//			obsClient.putObject(didi_obs_bucketName, filefolder + "/" + simpleDateFormat.format(new Date(time)) + "/" + file.getName() + ".csv", file);
//		} catch (ObsException e) {
//		}
//	}

	public ObjectMetadata getObjectMetadata(String bucketName, String path) {
		try {
			return obsClient.getObjectMetadata(bucketName, path);
		} catch (Exception e) {
			return null;
		}
	}
}
