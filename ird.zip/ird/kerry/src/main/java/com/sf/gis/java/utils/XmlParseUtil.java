package com.sf.gis.java.utils;

import com.alibaba.fastjson.JSONObject;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;

public class XmlParseUtil {

    public static JSONObject xmlParseSplit(String data){
        JSONObject dataObj = new JSONObject();

        try{
//            SAXReader saxReader = new SAXReader();
            //2.加载xml
//            Document document = saxReader.read(new File("F:\\data\\xml\\data.xml"));

            Document document = DocumentHelper.parseText(data);
            String splitResult = document.getRootElement().elementText("splitResult");
            String score =document.getRootElement().elementText("score");
            String status =document.getRootElement().elementText("status");
            String msg =document.getRootElement().elementText("msg");
            dataObj.put("splitresult",splitResult);
            dataObj.put("score",score);
            dataObj.put("status",status);
            dataObj.put("msg",msg);


        }catch (Exception e){
            e.printStackTrace();

        }

        return dataObj;




    }
}
