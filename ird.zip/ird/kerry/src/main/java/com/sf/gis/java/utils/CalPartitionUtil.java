package com.sf.gis.java.utils;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;

import java.util.List;

/**
 * 计算相关工具类
 * @author 01370539 Created on Mar.25 2021
 */
public class CalPartitionUtil {

    /**
     * 获取分区数量，默认取10000条用于计算
     * @param rdd 即将存储的数据内容
     * @return 分区数量
     */
	public static int getPartitionSize(JavaRDD<Row> rdd) {
        return getPartitionSize(rdd, null);
	}

    /**
     * 获取分区数量
     * @param rdd 即将存储的数据内容
     * @param num 用户期望的计算数量
     * @return 分区数量
     */
    public static int getPartitionSize(JavaRDD<Row> rdd, Integer num) {
        if (num == null) {
            num = 10000;
        }
        long count = rdd.count();
        List<Row> take = rdd.take(num);
        return startCalPartition(num, count, take);
    }

    /**
     *
     * @param dataset 即将存储的数据内容
     * @return 分区数量
     */
    public static int getPartitionSize(Dataset<Row> dataset) {
        return getPartitionSize(dataset, null);
    }

    /**
     *
     * @param dataset 即将存储的数据内容
     * @param num 用户期望的计算数量
     * @return 分区数量
     */
	public static int getPartitionSize(Dataset<Row> dataset, Integer num) {
        if (num == null) {
            num = 10000;
        }
		long count = dataset.count();
		List<Row> take = dataset.takeAsList(num);
        return startCalPartition(num, count, take);
    }

    private static int startCalPartition(Integer num, long count, List<Row> take) {
        long bytes = 0;
        for (Row row : take) {
            bytes += row.mkString().getBytes().length;
        }
        int numM = (int) (128 * num / (bytes * 1.2 / (2 << 19)));
        return (int) (count % numM == 0 ? count / numM : count / numM + 1);
    }


}
