package com.sf.gis.java.config;

import com.obs.services.ObsClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

//@Configuration
public class ObsConfig {
	
//	@Value("${mgsocol_obs_endPoint}")
//   	private String mgsocol_obs_endPoint;
//
//    @Value("${mgsocol_obs_ak}")
//    private String mgsocol_obs_ak;
//
//    @Value("${mgsocol_obs_sk}")
//    private String mgsocol_obs_sk;
//
//	@Bean
	String mgsocol_obs_ak="";
	String mgsocol_obs_sk="";
	String mgsocol_obs_endPoint="";
	public ObsClient obsClient(){
		return new ObsClient(mgsocol_obs_ak, mgsocol_obs_sk, mgsocol_obs_endPoint);
	}
}
